package com.manheim.ods.compx.charges.deserialize;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.io.IOException;
import java.net.URISyntaxException;

import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.charges.util.ChargesAuctionEvent;
import com.manheim.ods.compx.charges.util.ChargesEventDeserializer;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.helper.CompXJsonParser;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;

public class EventDeserializerTest {

	private ChargesEventDeserializer eventDeserializer;
	private DeserializationContext context;
	private LogWrapper logger;
	private JsonParser jsonParser;
	private ObjectMapper objectMapper;

	@Before
	public void setUp() throws Exception {
		logger = mock(LogWrapper.class);
		eventDeserializer = new ChargesEventDeserializer(logger, new CompXJsonParser("My App"));

		objectMapper= new ObjectMapper();
		context = objectMapper.getDeserializationContext();
	}

	@Test
	public void shouldLogEventDetailsWhenDeserializingEvent() throws Exception {

		jsonParser = objectMapper.getFactory()
				.createParser(new CompXFileReader().fetchFileAsString("eventDataPFVEHICLE.json"));
		eventDeserializer.deserialize(jsonParser, context);

		verify(logger).info(eq(ChargesEventDeserializer.class), anyString());
	}

	@Test
	public void shouldDeserializeEventRequestToAnEvent() throws IOException, URISyntaxException {

		jsonParser = objectMapper.getFactory()
				.createParser(new CompXFileReader().fetchFileAsString("eventDataPFVEHICLE.json"));

		AuctionEvent event = eventDeserializer.deserialize(jsonParser, context);

		assertThat(event.getHref(), is("https://api.manheim.com/events/id/1234"));
		assertThat(event.getEventType(), is("SELLER_CHARGES_CHANGED"));
		assertThat(event.getAuctionCode(), is("AUCTION"));
		assertThat(event.getWorkOrder(), is("1234"));
		assertThat(event.getSblu(), is("5678"));
		assertThat(event.getSaleYear(), is(2017));
		assertThat(event.getSaleNumber(), is(1));
		assertThat(event.getLaneNumber(), is(2));
		assertThat(event.getRunNumber(), is(3));
		assertThat(event.getHeartbeatseqno(), is("123"));
		assertThat(event.getCdcjournaltimestamp(), is("2017-09-07T14:02:25.764192000"));
		assertThat(event.getTboxtimestamp(), is("2017-09-07T14:03:03.764192000"));
		assertThat(event.getChangestatus(), is("I"));
		assertThat(event.getJsonMessage(), is("{}"));
        assertThat(event.getPrevSellerDealerId(), is("9098765"));
        assertThat(event.getPrevBuyerDealerId(), is("1234567"));
        assertThat(event.getSellerId(), is("12345"));
	}

	@Test
	public void shouldDeserializeVehicleExtEventRequestToAnEvent() throws IOException, URISyntaxException {

		jsonParser = objectMapper.getFactory()
				.createParser(new CompXFileReader().fetchFileAsString("eventDataPFVEHEXT.json"));

		AuctionEvent event = eventDeserializer.deserialize(jsonParser, context);

		assertThat(event.getHref(), is("https://api.manheim.com/events/id/1234"));
		assertThat(event.getEventType(), is("SELLER_CHARGES_CHANGED"));
		assertThat(event.getAuctionCode(), is("AUCTION"));
		assertThat(event.getSblu(), is("5678"));
		assertThat(event.getHeartbeatseqno(), is("123"));
		assertThat(event.getCdcjournaltimestamp(), is("2017-09-07T14:02:25.764192000"));
		assertThat(event.getTboxtimestamp(), is("2017-09-07T14:03:03.764192000"));
		assertThat(event.getChangestatus(), is("I"));
		assertThat(event.getJsonMessage(), is("{}"));
	}

	@Test
	public void shouldDeserializeReconEventRequestToAnEvent() throws IOException, URISyntaxException {

		jsonParser = objectMapper.getFactory()
				.createParser(new CompXFileReader().fetchFileAsString("eventDataPFRECON.json"));

		AuctionEvent event = eventDeserializer.deserialize(jsonParser, context);

		assertThat(event.getHref(), is("https://api.manheim.com/events/id/1234"));
		assertThat(event.getEventType(), is("SELLER_CHARGES_CHANGED"));
		assertThat(event.getAuctionCode(), is("AUCTION"));
		assertThat(event.getWorkOrder(), is("1234"));
		assertThat(event.getHeartbeatseqno(), is("123"));
		assertThat(event.getCdcjournaltimestamp(), is("2017-09-07T14:02:25.764192000"));
		assertThat(event.getTboxtimestamp(), is("2017-09-07T14:03:03.764192000"));
		assertThat(event.getChangestatus(), is("I"));
		assertThat(event.getJsonMessage(), is("{}"));
	}

	@Test
	public void shouldDeserializeAdjustmentsEventRequestToAnEvent() throws IOException, URISyntaxException {

		jsonParser = objectMapper.getFactory()
				.createParser(new CompXFileReader().fetchFileAsString("eventDataPFSADJDTL.json"));
		AuctionEvent event = eventDeserializer.deserialize(jsonParser, context);

		assertThat(event.getHref(), is("https://api.manheim.com/events/id/1234"));
		assertThat(event.getEventType(), is("BUYER_CHARGES_CHANGED"));
		assertThat(event.getAuctionCode(), is("AUCTION"));
		assertThat(event.getSaleYear(), is(2017));
		assertThat(event.getSaleNumber(), is(1));
		assertThat(event.getLaneNumber(), is(2));
		assertThat(event.getRunNumber(), is(3));
		assertThat(event.getHeartbeatseqno(), is("123"));
		assertThat(event.getCdcjournaltimestamp(), is("2017-09-07T14:02:25.764192000"));
		assertThat(event.getTboxtimestamp(), is("2017-09-07T14:03:03.764192000"));
		assertThat(event.getChangestatus(), is("I"));
		assertThat(event.getJsonMessage(), is("{}"));
	}

	@Test
	public void shouldDeserializeEventRequestWithoutSaleKey() throws IOException, URISyntaxException {
		jsonParser = objectMapper.getFactory()
				.createParser(new CompXFileReader().fetchFileAsString("eventDataWithoutSaleKey.json"));
		ChargesAuctionEvent event = eventDeserializer.deserialize(jsonParser, context);

		assertThat(event.getHref(), is("https://api.manheim.com/events/id/1234"));
		assertThat(event.getEventType(), is("BUYER_CHARGES_CHANGED"));
	}

    @Test
    public void shouldDeserializeEventRequest() throws IOException, URISyntaxException {

        jsonParser = objectMapper.getFactory()
                .createParser(new CompXFileReader().fetchFileAsString("eventDataPFVEHICLE-baddata.json"));

        AuctionEvent event = eventDeserializer.deserialize(jsonParser, context);

        assertThat(event.getHref(), is("https://api.manheim.com/events/id/1234"));
        assertThat(event.getEventType(), is("SELLER_CHARGES_CHANGED"));
    }	
}
