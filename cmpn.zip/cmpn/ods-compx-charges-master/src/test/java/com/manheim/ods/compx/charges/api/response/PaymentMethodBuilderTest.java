package com.manheim.ods.compx.charges.api.response;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

public class PaymentMethodBuilderTest {

  String howPaidCode;
  String flrType;
  String paidDate;

  PaymentMethodBuilder paymentMethodBuilder;

  @Before
  public void setup() {
    paymentMethodBuilder = new PaymentMethodBuilder();
  }

  @Test
  public void testKZHowPaidCodeWithNoPaidDateAndFlrType() {
    this.howPaidCode = "K";
    this.flrType = " ";
    this.paidDate = null;
    String paymentMethod = this.paymentMethodBuilder.build(howPaidCode, flrType, paidDate);
    assertThat(paymentMethod, is("K-NA"));
  }

  @Test
  public void testKZHowPaidCodeWithPaidDateAndFlrType() {
    this.howPaidCode = "K";
    this.flrType = "^";
    this.paidDate = "2018-01-01";
    String paymentMethod = this.paymentMethodBuilder.build(howPaidCode, flrType, paidDate);
    assertThat(paymentMethod, is("K^"));
  }

  @Test
  public void testKZHowPaidCodeWithoutPaidDateAndFlrType() {
    this.howPaidCode = "K";
    this.flrType = "^";
    this.paidDate = null;
    String paymentMethod = this.paymentMethodBuilder.build(howPaidCode, flrType, paidDate);
    assertThat(paymentMethod, is("K^"));
  }

  @Test
  public void testNonKZHowPaidCodeWithoutPaidDateAndFlrType() {
    this.howPaidCode = "A";
    this.flrType = "^";
    this.paidDate = "2018-01-01";
    String paymentMethod = this.paymentMethodBuilder.build(howPaidCode, flrType, paidDate);
    assertThat(paymentMethod, is("A"));
  }

  @Test
  public void testKZHowPaidCodeWithoutPaidDateAndWithoutFlrType() {
    this.howPaidCode = "K";
    this.flrType = "";
    this.paidDate = "2018-01-01";
    String paymentMethod = this.paymentMethodBuilder.build(howPaidCode, flrType, paidDate);
    assertThat(paymentMethod, is("K"));
  }
}
