package com.manheim.ods.compx.charges.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;

import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Test;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessagePostProcessor;

import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MessageGroupUtil;

public class TriggerServiceTest {
  TriggerService triggerService;
  LogWrapper logWrapper;
  JmsTemplate jmsTemplate;
  String destinationQueueName;
  ChargesQueueMessageBuilder chargesQueueMessageBuilder;
  String queueMessage =
      "<transactionId><transactionId>150150</transactionId><eventType>SELLER_CHARGES_CHANGED</eventType></transactionId>";
  MessagePostProcessor messageProperties;

  @Before
  public void setUp() throws Exception {
    chargesQueueMessageBuilder = mock(ChargesQueueMessageBuilder.class);

    destinationQueueName = "man.compx.charges.update.staging.event";
    logWrapper = mock(LogWrapper.class);
    jmsTemplate = mock(JmsTemplate.class);

    messageProperties = mock(MessagePostProcessor.class);
    when(chargesQueueMessageBuilder.messageProperties(anyString(), any(AuctionEvent.class), any(),
        any(Timestamp.class), any(Timestamp.class))).thenReturn(messageProperties);

    MessageGroupUtil messageGroupUtil = mock(MessageGroupUtil.class);
    when(messageGroupUtil.group(anyString())).thenReturn("grp1");
    this.triggerService = new TriggerService(chargesQueueMessageBuilder, destinationQueueName,
        logWrapper, jmsTemplate);

  }

  @Test
  public void shouldSendTriggerToSpecificAuctionRegionCodeQueue() throws JAXBException {
    AuctionEvent event = mock(AuctionEvent.class);
    Timestamp apiRequestTimestamp = new Timestamp(System.currentTimeMillis());
    ChargesProcessStatusLog chargesProcessStatusLog = mock(ChargesProcessStatusLog.class);
    when(chargesProcessStatusLog.getMessageGroupId()).thenReturn("grp1");
    when(chargesProcessStatusLog.getSblu()).thenReturn(1234L);
    when(event.getSblu()).thenReturn("1234");
    when(event.getWorkOrder()).thenReturn("35");
    when(event.getAuctionCode()).thenReturn("TEST_AUCTION");
    triggerService.sendTriggerToQueue(event, apiRequestTimestamp, chargesProcessStatusLog);
    verify(jmsTemplate).convertAndSend(eq(destinationQueueName), anyString(),
        eq(messageProperties));
  }

  @Test
  public void shouldSendTriggerWithMessageGroupIdWhenSbluIsMissing() throws JAXBException {
    AuctionEvent event = mock(AuctionEvent.class);
    Timestamp apiRequestTimestamp = new Timestamp(System.currentTimeMillis());
    ChargesProcessStatusLog chargesProcessStatusLog = mock(ChargesProcessStatusLog.class);
    when(chargesProcessStatusLog.getMessageGroupId()).thenReturn("grp1");
    when(chargesProcessStatusLog.getSblu()).thenReturn(null);
    when(chargesProcessStatusLog.getAuction()).thenReturn("TEST_AUCTION");
    when(event.getSblu()).thenReturn("1234");
    when(event.getWorkOrder()).thenReturn("35");
    when(event.getAuctionCode()).thenReturn("TEST_AUCTION");
    triggerService.sendTriggerToQueue(event, apiRequestTimestamp, chargesProcessStatusLog);
    verify(jmsTemplate).convertAndSend(eq(destinationQueueName), anyString(),
        eq(messageProperties));
  }
}
