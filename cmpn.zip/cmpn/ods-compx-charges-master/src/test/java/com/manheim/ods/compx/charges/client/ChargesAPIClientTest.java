package com.manheim.ods.compx.charges.client;


import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Matchers.anyString;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.sql.Timestamp;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.manheim.ods.compx.charges.api.ChargesAPIConfiguration;
import com.manheim.ods.compx.charges.api.ChargesAPIRequest;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLogRepository;
import com.manheim.ods.compx.charges.dao.MessageXrefRepository;
import com.manheim.ods.compx.client.Client;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.Sleeper;

import okhttp3.Request;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

@RunWith(MockitoJUnitRunner.class)
public class ChargesAPIClientTest {

  private static final String AUCTION_CODE = "AUCTION_CODE";
  private static final String SBLU = "SBLU";
  private static final String WORK_ORDER = "5678";
  private static final Integer YEAR = 2017;

  private static final String EXPECTED_CHARGES_MESSAGE =
      "{\"href\":\"http://auction-charges-api-silo1.aws-dev.manheim.com/charges/search/seller/auction/QLM1/sblu/14274690\",\"saleStatus\":\"SF\",\"requestTimestamp\":\"2017-10-11T21:44:07.693Z\",\"isVehicleTransfered\":false,\"consignment\":{\"unit\":{\"vehicleType\":\"V\",\"groupCode\":\"HYMF\",\"vin\":\"KMHDH4AE4FU377276\"},\"operatingLocation\":{\"href\":\"https://integration5.api.manheim.com/locations/id/QLM1\",\"locationCode\":\"QLM1\"},\"sblu\":14274690,\"workOrderNumber\":5510489,\"seller\":{\"href\":\"https://integration5.api.manheim.com/accounts/?acctNum=4905944\",\"dealerNumber\":4905944,\"dealerName\":\"HYUNDAI MOTOR FINANCE\",\"billToCustomerId\":4905944},\"receivedDate\":\"2017-08-22\"},\"offering\":{\"registrationDate\":\"2017-09-21\",\"saleTime\":102610,\"saleKey\":{\"saleYear\":2017,\"saleNumber\":38,\"laneNumber\":15,\"runNumber\":52}},\"arbitrationDate\":\"2017-09-22\",\"payment\":{\"method\":\" \",\"paidStatus\":\"PAID\",\"paidDate\":\"2017-09-21\",\"sellerCheckPrintedIndicator\":\" \"},\"charges\":{\"reconFees\":[{\"amount\":440.00,\"recordNumber\":1,\"subMenu\":10,\"subclass\":550,\"description\":\"NEW PORT RICHEY FL TO MAN ATL\",\"legacyReconDeductible\":\"Y\",\"chargeReportingDate\":\"2017-08-18T12:00:00.000Z\",\"sourceAuction\":\"AAA\",\"invoiceRequestedStatusCode\":\"RC\",\"lcode\":\"S\"},{\"amount\":80.00,\"recordNumber\":1,\"subMenu\":6,\"subclass\":660,\"description\":\"VALUE DETAIL $80\",\"legacyReconDeductible\":\"Y\",\"chargeReportingDate\":\"2017-09-09T12:00:00.000Z\",\"invoiceRequestedStatusCode\":\"RC\",\"lcode\":\"D\"},{\"amount\":80.00,\"recordNumber\":1,\"subMenu\":4,\"subclass\":440,\"description\":\"ICLT INTR\",\"legacyReconDeductible\":\"Y\",\"chargeReportingDate\":\"2017-09-20T12:00:00.000Z\",\"invoiceRequestedStatusCode\":\"RC\"}],\"dealerFees\":[{\"amount\":600.00,\"keyType\":\"FEE\",\"keyValue\":\"SCHGS\"}],\"totalFeeAmount\":600.00}}";

  private ChargesAPIClient chargesAPIClient;
  @Mock
  private ChargesAPIConfiguration chargesApiConfiguration;
  @Mock
  private Call call;
  @Mock
  private Client client;
  @Mock
  private Sleeper sleeper;
  @Mock
  private LogWrapper logWrapper;
  @Mock
  private ResponseBody responseBody;
  @Mock
  private AuctionEvent event;
  private Response<Object> errorResponse;
  private Response<Object> notFoundResponse;
  private Response<String> successfulResponse;
  private ChargesAPIRequest request;
  private Integer maxRetryCount;
  private String authorization;
  private Timestamp compxReqTimestamp;
  @Mock
  private ChargesProcessStatusLogRepository chargesProcessStatusLogRepository;
  @Mock
  private MessageXrefRepository msgXrefRepository;

  @Before
  public void setUp() throws Exception {
    maxRetryCount = 3;
    errorResponse = Response.error(403, responseBody);
    successfulResponse = Response.success(EXPECTED_CHARGES_MESSAGE);
    chargesAPIClient = new ChargesAPIClient(chargesApiConfiguration, client, maxRetryCount,
        logWrapper, sleeper, authorization);
    compxReqTimestamp = new Timestamp(System.currentTimeMillis());
    // request =
    // ChargesAPIRequest.builder().dealerType("SL").auctionCode(AUCTION_CODE).sblu(SBLU).build();
    request = new ChargesAPIRequest();
    request = new ChargesAPIRequest("SL", AUCTION_CODE, SBLU);
    when(call.clone()).thenReturn(call);
    when(call.request()).thenReturn(new Request.Builder().url("http://a.url/some/path").build());
    when(client.execute(call, ChargesAPIClient.class)).thenReturn(successfulResponse);
    when(chargesApiConfiguration.configureChargesCall(anyString(), anyString(), anyString(),
        anyString())).thenReturn(call);
    when(event.getAuctionCode()).thenReturn("AUCTION_CODE");
    when(event.getHref()).thenReturn("href");
    when(event.getEventType()).thenReturn("SELLER_CHARGES_CHANGED");
    notFoundResponse = Response.error(404, responseBody);
  }

  @Test
  public void shouldConfigurechargesApiConfigurationCallWhenGettingSellerChargesResponse()
      throws IOException {
    chargesAPIClient.getChargesResponse(request);
    verify(chargesApiConfiguration).configureChargesCall(anyString(), anyString(), anyString(),
        anyString());
  }

  @Test
  public void shouldConfigurechargesApiConfigurationCallWhenGettingBuyerChargesResponse()
      throws IOException {
    chargesAPIClient.getChargesResponse(request);
    verify(chargesApiConfiguration).configureChargesCall(anyString(), anyString(), anyString(),
        anyString());
  }

  @Test
  public void shouldExecuteClientWhenGettingChargesResponse() throws IOException {
    chargesAPIClient.getChargesResponse(request);
    verify(client).execute(call, ChargesAPIClient.class);
  }

  @Test
  public void shouldReturnChargesResponse() throws IOException {
    String response = chargesAPIClient.getChargesResponse(request);
    assertThat(response, is(EXPECTED_CHARGES_MESSAGE));
  }

  @Test
  public void shouldRetrychargesApiConfigurationWhenClientExecutionFails() throws IOException {
    when(client.execute(call, ChargesAPIClient.class)).thenReturn(errorResponse)
        .thenReturn(successfulResponse);
    chargesAPIClient.getChargesResponse(request);
    verify(client, times(2)).execute(call, ChargesAPIClient.class);
  }

  @Test
  public void shouldCloneCallWhenRetrying() throws Exception {
    when(client.execute(call, ChargesAPIClient.class)).thenReturn(errorResponse)
        .thenReturn(successfulResponse);
    chargesAPIClient.getChargesResponse(request);
    verify(call).clone();


  }

  @Test(expected = UnsuccessfulClientExecutionException.class)
  public void shouldRetrychargesApiConfigurationMaximumNumberOfTimesWhenClientExecutionAlwaysFails()
      throws IOException {
    when(client.execute(call, ChargesAPIClient.class))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")));

    chargesAPIClient.getChargesResponse(request);

    verify(client, times(maxRetryCount)).execute(call, ChargesAPIClient.class);
  }

  @Test(expected = UnsuccessfulClientExecutionException.class)
  public void shouldThrowUnsuccessfulClientExecutionWhenMaxRetriesAreReached() throws IOException {
    when(client.execute(call, ChargesAPIClient.class))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")));

    chargesAPIClient.getChargesResponse(request);
  }

  // @Test(expected = UnsuccessfulClientExecutionException.class)
  // public void shouldThrowUnsuccessfulClientExecutionClientExecuteFails() throws IOException {
  // when(client.execute(call, ChargesAPIClient.class)).thenThrow(IOException.class);
  //
  // chargesAPIClient.getChargesResponse(request);
  // }


  @Test
  public void shouldLogErrorWhenClientExecutionFailsWithErrorReadingResponse() throws IOException {
    when(client.execute(call, ChargesAPIClient.class)).thenReturn(errorResponse);
    try {
      chargesAPIClient.getChargesResponse(request);
    } catch (UnsuccessfulClientExecutionException e) {
    }
    verify(logWrapper).error(ChargesAPIClient.class,
        "Unsuccessful Auction Charges API call after 3 retries with HTTP Error 403 for Request: Request{method=GET, url=http://a.url/some/path, tag=null} for Input: Auction- AUCTION_CODE, sblu- SBLU. Response received: <Unknown>");
  }

  @Test
  public void shouldLogErrorWhenClientExecutionFails() throws IOException {
    when(client.execute(call, ChargesAPIClient.class))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")))
        .thenReturn(Response.error(403, ResponseBody.create(null, "Body of the error response")));

    try {
      chargesAPIClient.getChargesResponse(request);
    } catch (UnsuccessfulClientExecutionException e) {
    }

    verify(logWrapper).error(ChargesAPIClient.class,
        "Unsuccessful Auction Charges API call after 3 retries with HTTP Error 403 for Request: Request{method=GET, url=http://a.url/some/path, tag=null} for Input: Auction- AUCTION_CODE, sblu- SBLU. Response received: Body of the error response");
  }


  @Test
  public void shouldLogInfoWhenClientExecutionIsSuccessful() throws IOException {
    chargesAPIClient.getChargesResponse(request);

    verify(logWrapper).info(ChargesAPIClient.class,
        "Calling Auction Charges API with Request: Request{method=GET, url=http://a.url/some/path, tag=null} for Input: Auction- AUCTION_CODE, sblu- SBLU.");
  }


  @Test
  public void shouldLogInfoWhenClientIsExecutingCall() throws IOException {
    chargesAPIClient.getChargesResponse(request);
    verify(logWrapper).info(ChargesAPIClient.class, String.format(
        "Calling Auction Charges API with Request: Request{method=GET, url=http://a.url/some/path, tag=null} for Input: Auction- AUCTION_CODE, sblu- SBLU."));
  }

  @Test
  public void shouldSleepWhenClientExecutionFails() throws IOException {
    when(client.execute(call, ChargesAPIClient.class)).thenReturn(errorResponse)
        .thenReturn(successfulResponse);
    chargesAPIClient.getChargesResponse(request);
    verify(sleeper).sleep();
  }

  @Test(expected = UnsuccessfulClientExecutionException.class)
  public void testIOExceptionOnExecute() throws IOException {
    // request =
    // ChargesAPIRequest.builder().dealerType("SL").auctionCode(AUCTION_CODE).sblu("1234").build();

    request = new ChargesAPIRequest("SL", AUCTION_CODE, "1234");
    when(client.execute(call, ChargesAPIClient.class)).thenThrow(IOException.class);

    chargesAPIClient.getChargesResponse(request);
  }


  @Test
  public void testNotFoundOnExecute() throws IOException {
    // request =
    // ChargesAPIRequest.builder().dealerType("SL").auctionCode(AUCTION_CODE).sblu("1234").build();

    request = new ChargesAPIRequest("SL", AUCTION_CODE, "1234");
    when(client.execute(call, ChargesAPIClient.class)).thenReturn(notFoundResponse);

    try {
      chargesAPIClient.getChargesResponse(request);
    } catch (Exception ex) {
      assertEquals("RecordNotFoundException" , ex.getClass().getSimpleName());
      logWrapper.error(ChargesAPIClient.class, "Not Found Exception");
    }
  }

}
