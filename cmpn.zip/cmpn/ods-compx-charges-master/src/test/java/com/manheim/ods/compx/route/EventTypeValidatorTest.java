package com.manheim.ods.compx.route;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.Matchers.any;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.manheim.ods.compx.model.eventer.AuctionEvent;

@RunWith(MockitoJUnitRunner.class)
public class EventTypeValidatorTest {

	@Mock
	Exchange exchange;
	@Mock
	Message message;
	
	private AuctionEvent auctionEvent;
	private EventTypeValidator validator;
	
	@Before
	public void setup(){
		auctionEvent= new AuctionEvent();
		validator= new EventTypeValidator();
	}
	
	@Test
	public void testSellerChargesChangedEventValidation(){

		auctionEvent.setEventType("SELLER_CHARGES_CHANGED");
		when(exchange.getIn()).thenReturn(message);
		when(message.getBody(any())).thenReturn(auctionEvent);
		assertThat(validator.matches(exchange), is(true));
	}

	@Test
	public void testHeartbeatEventValidation(){

		auctionEvent.setEventType("HEARTBEAT");
		when(exchange.getIn()).thenReturn(message);
		when(message.getBody(any())).thenReturn(auctionEvent);
		assertThat(validator.matches(exchange), is(true));
	}

	@Test
	public void testSellerServiceOrderCreatedEventValidation(){

		auctionEvent.setEventType("SELLER_SERVICE_ORDER_CREATED");
		when(exchange.getIn()).thenReturn(message);
		when(message.getBody(any())).thenReturn(auctionEvent);
		assertThat(validator.matches(exchange), is(true));
	}
	
	@Test
	public void shouldReturnFalseIfReceivedAuctionEventIsNull(){

		auctionEvent= null;
		when(exchange.getIn()).thenReturn(message);
		when(message.getBody(any())).thenReturn(auctionEvent);
		assertThat(validator.matches(exchange), is(false));
	}
}
