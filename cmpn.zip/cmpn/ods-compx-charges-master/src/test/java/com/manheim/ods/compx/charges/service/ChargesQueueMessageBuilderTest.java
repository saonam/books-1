package com.manheim.ods.compx.charges.service;

import static org.hamcrest.core.Is.is;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.jms.core.MessagePostProcessor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.model.eventer.BaseEvent;
import com.manheim.ods.compx.setup.EventerValues;
import com.manheim.ods.compx.setup.JsonBuilder;
import com.manheim.ods.compx.setup.QueueMessageBuilder;
import com.manheim.ods.compx.util.LogWrapper;

public class ChargesQueueMessageBuilderTest {

  private String someJsonString;
  private String eventType;
  private String eventHref;
  private JsonBuilder jsonBuilder;
  private ChargesQueueMessageBuilder messageBuilder;
  private String auctionCode;
  private Message message;
  private AuctionEvent event;
  private Map<String, String> eventHeaders;
  private LogWrapper logWrapper;

  @Before
  public void setUp() throws Exception {
    someJsonString = new JSONObject().put("key", "value").toString();
    eventType = "SELLER_CHARGES_CHANGED";
    eventHref = "https://api.manheim.com/events/id/1234";
    logWrapper = mock(LogWrapper.class);
    jsonBuilder = mock(JsonBuilder.class);
    messageBuilder = new ChargesQueueMessageBuilder(jsonBuilder, logWrapper);
    auctionCode = "AUCTION";
    message = mock(Message.class);
    eventHeaders = new HashMap<String, String>();
    eventHeaders.put("originTimestamp", "2017-04-17 14:22:30.555");
    eventHeaders.put("transactionId", "1234");
    event = AuctionEvent.builder().auctionCode(auctionCode).eventType(eventType).cdcUserId("Aditya")
        .sblu("7687687").build();
    eventHeaders.put("JMSXGroupID", "AUCTION:7687687");


  }

  @Test
  public void shouldGenerateXMLWithHrefTypeAndResponseAttributes() throws Exception {
    QueueMessageBuilder messageBuilder =
        new QueueMessageBuilder(new JsonBuilder(mock(EventerValues.class)), logWrapper);

    String result = messageBuilder.messageXML(someJsonString, event);
    Assert.assertTrue(result
        .startsWith(String.format("<queueMessage><apiResponse><key>value</key></apiResponse>")));
    Assert.assertTrue(result.endsWith(String.format("</queueMessage>")));
    Assert.assertTrue(result.contains(String.format("<event>")));
    Assert.assertTrue(result.contains(String.format("</event>")));
    Assert.assertTrue(result.contains(String.format("<eventType>%s</eventType>", eventType)));
  }


  @Test
  public void shouldUseJsonBuilderToGenerateXML() throws JsonProcessingException {
    messageBuilder.messageXML(someJsonString, event);

    ArgumentCaptor<JSONObject> argumentCaptor1 = ArgumentCaptor.forClass(JSONObject.class);
    ArgumentCaptor<BaseEvent> argumentCaptor2 = ArgumentCaptor.forClass(BaseEvent.class);
    verify(jsonBuilder).buildQueueJson(argumentCaptor1.capture(), argumentCaptor2.capture());
    JSONObject apiResponse = argumentCaptor1.getValue();
    Assert.assertThat(apiResponse.toString(), is(someJsonString));
    BaseEvent event = argumentCaptor2.getValue();
    Assert.assertThat(event.getEventType(), is(eventType));
    Assert.assertThat(((AuctionEvent) event).getAuctionCode(), is(auctionCode));
  }

  @Test
  public void shouldReturnMessageWithSourceAsDQSWATWhenHrefIsEmpty() throws JMSException {
    event.setHref("");;
    MessagePostProcessor messagePostProcessor =
        messageBuilder.messageProperties(event.getAuctionCode(), event, eventHeaders,
            Timestamp.valueOf("2017-04-06 10:30:00"), Timestamp.valueOf("2017-04-06 10:30:01.055"));
    messagePostProcessor.postProcessMessage(message);

    verify(message).setStringProperty("Source", ChargesQueueMessageBuilder.DQSWAT_TOOL);

  }


  @Test
  public void shouldReturnMessageWithGroupId() throws JMSException {
    event.setHref("");
    MessagePostProcessor messagePostProcessor =
        messageBuilder.messageProperties(event.getAuctionCode(), event, eventHeaders,
            Timestamp.valueOf("2017-04-06 10:30:00"), Timestamp.valueOf("2017-04-06 10:30:01.055"));
    messagePostProcessor.postProcessMessage(message);

    verify(message).setStringProperty("JMSXGroupID",
        String.format("%s:%s", event.getAuctionCode(), event.getSblu()));

  }

  @Test
  public void shouldReturnSourceKeyWhenNotEmpty() {

    Assert.assertThat(messageBuilder.determineSourceCode(event, "randomSourceKey"),
        is("randomSourceKey"));
  }

  @Test
  public void shouldReturnCHARGESwhenSourceKeyIsEmpty() {
    event.setHref(eventHref);
    Assert.assertThat(messageBuilder.determineSourceCode(event, ""), is("CHARGES"));
  }

  @Test
  public void shouldReturnDQSWatWhenSourceKeyIsBlankAndHrefIsEmpty() {
    event = AuctionEvent.builder().auctionCode(auctionCode).eventType(eventType).build();
    event.setHref("");

    Assert.assertThat(messageBuilder.determineSourceCode(event, ""), is("DQSWAT-TOOL"));
  }

}
