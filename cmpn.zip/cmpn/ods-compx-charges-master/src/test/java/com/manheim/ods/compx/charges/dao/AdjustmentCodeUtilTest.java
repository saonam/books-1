package com.manheim.ods.compx.charges.dao;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;


public class AdjustmentCodeUtilTest {

  AdjustmentCodeUtil adjustmentCodeUtil;

  @Before
  public void setup() {
    this.adjustmentCodeUtil = new AdjustmentCodeUtil();
  }

  @Test
  public void testAdjustmentCode() {
    AdjustmentCodeEnum adjustmentCodeEnum = adjustmentCodeUtil.findAdjustmentCode("PSI01", "N");
    assertThat("7 DAY", is(adjustmentCodeEnum.getValue()));
  }

  @Test
  public void testAdjustmentCode14DayPSI() {
    AdjustmentCodeEnum adjustmentCodeEnum = adjustmentCodeUtil.findAdjustmentCode("PSI01", "Y");
    assertThat("14 DAY", is(adjustmentCodeEnum.getValue()));
  }

  @Test
  public void testAdjustmentCodePSI02() {
    AdjustmentCodeEnum adjustmentCodeEnum = adjustmentCodeUtil.findAdjustmentCode("PSI02", "N");
    assertThat("Sale Day Check", is(adjustmentCodeEnum.getValue()));
  }

  @Test
  public void testAdjustmentCodePSI03() {
    AdjustmentCodeEnum adjustmentCodeEnum = adjustmentCodeUtil.findAdjustmentCode("PSI03", "N");
    assertThat("Frame Check Only", is(adjustmentCodeEnum.getValue()));
  }

  @Test
  public void testAdjustmentCodePSI19() {
    AdjustmentCodeEnum adjustmentCodeEnum = adjustmentCodeUtil.findAdjustmentCode("PSI19", "N");
    assertThat("Limited Powertrain", is(adjustmentCodeEnum.getValue()));
  }

  @Test
  public void testAdjustmentCodePSI20() {
    AdjustmentCodeEnum adjustmentCodeEnum = adjustmentCodeUtil.findAdjustmentCode("PSI20", "N");
    assertThat("Limited Powertrain AR", is(adjustmentCodeEnum.getValue()));
  }

  @Test
  public void testAdjustmentCodeOther() {
    AdjustmentCodeEnum adjustmentCodeEnum = adjustmentCodeUtil.findAdjustmentCode("PSI21", null);
    assertThat("Other", is(adjustmentCodeEnum.getValue()));
  }
}
