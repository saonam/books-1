package com.manheim.ods.compx.charges;

import static org.mockito.Mockito.mock;

import java.net.UnknownHostException;

import javax.xml.bind.JAXBException;

import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jms.core.JmsTemplate;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.InitialPositionInStream;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;
import com.manheim.ods.compx.charges.api.ChargesAPIConfiguration;
import com.manheim.ods.compx.charges.client.ChargesAPIClient;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLogRepository;
import com.manheim.ods.compx.charges.dao.MessageXrefRepository;
import com.manheim.ods.compx.charges.dao.ServiceOrderRepository;
import com.manheim.ods.compx.charges.dao.StgAdjustmentsHelper;
import com.manheim.ods.compx.charges.service.ChargesQueueMessageBuilder;
import com.manheim.ods.compx.charges.service.StagingService;
import com.manheim.ods.compx.charges.service.TriggerService;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.route.error.StageExceptionHandler;
import com.manheim.ods.compx.route.error.UnsuccessfulClientExecutionExceptionHandler;
import com.manheim.ods.compx.setup.EventerManager;
import com.manheim.ods.compx.setup.EventerValues;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MessageGroupUtil;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.ods.stream.consumer.KinesisRecordProcessorFactory;

/**
 * @author tusule
 *
 */
@SpringBootConfiguration
@ComponentScan(
    basePackages = {"com.manheim.ods.compx.route", "com.manheim.ods.compx", "com.manheim.auction"},
    excludeFilters = @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE,
        value = {EventerManager.class}))
@PropertySource(ignoreResourceNotFound = true, value = "classpath:buildInfo.properties")
public class TestApplication {


  @Value("${spring.activemq.broker-url}")
  private String activeMQUrl;

  @Value("${spring.activemq.cache-size}")
  private Integer activeMQCacheSize;

  @Value("${spring.activemq.password}")
  private String activeMQPassword;

  @Value("${spring.activemq.user}")
  private String activeMQUserName;
  @Value("${seller.auction.codes}")
  private String[] auctions;
  @Value("${activemq.queue.name}")
  String destinationQueueName;

  @Mock
  ChargesProcessStatusLogRepository chargesProcessStatusLogRepository;

  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

  @Bean
  public ChargesAPIConfiguration buildChargesAPI() {
    return mock(ChargesAPIConfiguration.class);
  }


  @Bean
  @Primary
  public Worker buildKinesisClientWorker() throws UnknownHostException {
    KinesisRecordProcessorFactory chargesRecordProcessorFactory =
        mock(KinesisRecordProcessorFactory.class);
    return new Worker(chargesRecordProcessorFactory, configureKinesisClient());
  }

  @Bean
  public KinesisClientLibConfiguration configureKinesisClient() throws UnknownHostException {
    KinesisClientLibConfiguration kinesisClientLibConfiguration = new KinesisClientLibConfiguration(
        "TEST_APP", "TEST_STREAM", buildAWSCredentialsProvider(), "TEST_WORKER_ID");
    kinesisClientLibConfiguration.withInitialPositionInStream(InitialPositionInStream.LATEST);
    return kinesisClientLibConfiguration;


  }

  private AWSCredentialsProvider buildAWSCredentialsProvider() {
    return mock(AWSCredentialsProvider.class);
  }

  @Bean
  @Primary
  public ChargesAPIClient buildChargesAPIClient() {
    return mock(ChargesAPIClient.class);
  }



  @Bean
  public StagingService buildStagingService() throws StageException {
    StagingService stagingService =
        new StagingService(buildChargesProcessStatusLogRepository(), buildStgAdjustmentsHelper());

    return stagingService;
  }

  @Bean
  @Primary
  public ChargesProcessStatusLogRepository buildChargesProcessStatusLogRepository() {
    ChargesProcessStatusLogRepository chargesProcessStatusLogRepository =
        mock(ChargesProcessStatusLogRepository.class);

    return chargesProcessStatusLogRepository;
  }

  @Bean
  @Primary
  public ServiceOrderRepository buildServiceOrderRepository() {
    ServiceOrderRepository serviceOrderRepository = mock(ServiceOrderRepository.class);

    return serviceOrderRepository;
  }


  @Bean
  @Primary
  public MessageXrefRepository buildMessageXrefRepository() {
    MessageXrefRepository msgXrefRepository = mock(MessageXrefRepository.class);
    return msgXrefRepository;
  }

  @Bean
  @Primary
  public TriggerService buildTriggerService() throws JAXBException {
    TriggerService triggerService = new TriggerService(queueMessageBuilder(), destinationQueueName,
        mockLogWrapper(), buildJmsTemplate());
    return triggerService;
  }

  @Bean
  @Primary
  public LogWrapper mockLogWrapper() {
    return mock(LogWrapper.class);
  }

  @Bean
  public EventerValues buildEventerValues() {
    return mock(EventerValues.class);
  }

  @Bean
  @Primary
  public ChargesQueueMessageBuilder queueMessageBuilder() {
    return mock(ChargesQueueMessageBuilder.class);
  }

  @Bean
  @Primary
  public JmsTemplate buildJmsTemplate() {
    return mock(JmsTemplate.class);
  }

  @Bean
  @Primary
  public MessageGroupUtil buildMessageGroupUtil() {
    return new MessageGroupUtil(1);
  }

  @Bean
  @Primary
  public StageExceptionHandler buildStageExceptionHandler() throws StageException {
    return new StageExceptionHandler(buildMetricReporter(), buildStagingService());
  }


  @Bean
  @Primary
  public MetricReporter buildMetricReporter() {
    return mock(MetricReporter.class);
  }

  @Bean
  @Primary
  public UnsuccessfulClientExecutionExceptionHandler buildUnsuccessfulExecutionExceptionHandler()
      throws StageException {
    return new UnsuccessfulClientExecutionExceptionHandler(buildMetricReporter(),
        buildStagingService());
  }

  @Bean
  @Primary
  public StgAdjustmentsHelper buildStgAdjustmentsHelper() {
    return new StgAdjustmentsHelper();
  }

}
