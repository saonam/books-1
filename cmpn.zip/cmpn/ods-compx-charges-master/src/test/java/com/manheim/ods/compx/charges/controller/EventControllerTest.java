package com.manheim.ods.compx.charges.controller;

import static org.hamcrest.core.IsEqual.equalTo;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.slf4j.MDC;
import org.springframework.http.HttpStatus;

import com.manheim.ods.compx.charges.util.ChargesAuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

@RunWith(MockitoJUnitRunner.class)
public class EventControllerTest {


  @Mock
  private MetricReporter metricReporter;
  @Mock
  private ChargesAuctionEvent event;
  @Mock
  ProducerTemplate producerTemplate;
  private EventController eventController;

  @Before
  public void setUp() throws Exception {
    eventController = new EventController( metricReporter,producerTemplate);
    initializeAuctionEvent();
  }

  private void initializeAuctionEvent() {
    when(event.getEventType()).thenReturn("EventType");
    when(event.getAuctionCode()).thenReturn("ABC");
    when(event.getWorkOrder()).thenReturn("1234567");
    when(event.getSblu()).thenReturn("567890123");
  }

  @Test
  public void shouldProcessEvent() throws Exception {
    assertThat(eventController.receiveEvent(event, null).getStatusCodeValue(),
        equalTo(HttpStatus.OK.value()));
  }


  @Test
  public void shouldSetValuesInMDC() throws Exception {
    when(event.getAuctionCode()).thenReturn("Auction");
    when(event.getEventType()).thenReturn("EventType");
    when(event.getSblu()).thenReturn("123");
    when(event.getWorkOrder()).thenReturn("345");
    when(event.getSaleYear()).thenReturn(2017);
    when(event.getSaleNumber()).thenReturn(1);
    when(event.getLaneNumber()).thenReturn(2);
    when(event.getRunNumber()).thenReturn(3);
    eventController.receiveEvent(event, null);

    assertEquals("Auction", MDC.get("auctionCode"));
    assertEquals("EventType", MDC.get("eventType"));
    assertEquals("123", MDC.get("sblu"));
    assertEquals("345", MDC.get("workOrder"));
    assertEquals("2017", MDC.get("saleYear"));
    assertEquals("1", MDC.get("saleNumber"));
    assertEquals("2", MDC.get("laneNumber"));
    assertEquals("3", MDC.get("runNumber"));
  }


  @Test
  public void shouldSkipWorkorderInMDC() throws Exception {
    when(event.getAuctionCode()).thenReturn("Auction");
    when(event.getEventType()).thenReturn("EventType");
    when(event.getSblu()).thenReturn(null);
    when(event.getWorkOrder()).thenReturn(null);
    when(event.getSaleYear()).thenReturn(null);
    when(event.getSaleNumber()).thenReturn(1);
    when(event.getLaneNumber()).thenReturn(2);
    when(event.getRunNumber()).thenReturn(3);
    eventController.receiveEvent(event, null);

    assertEquals("Auction", MDC.get("auctionCode"));
    assertEquals("EventType", MDC.get("eventType"));
    assertNull(MDC.get("sblu"));
    assertNull(MDC.get("workOrder"));
    assertNull(MDC.get("saleNumber"));
  }

  @Test
	public void shouldSendHeartbeatMetrics() throws Exception {
		when(event.isHeartbeat()).thenReturn(true);

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("source", "heartbeat");
		
		eventController.receiveEvent(event, headers);
		metricReporter.incrementHeartbeatReceived("eventType:" + event.getEventType(),
				"auctionCode:" + event.getAuctionCode(), "sblu:" + event.getSblu(), "workOrder:" + event.getWorkOrder(),
				"SaleKey: 0:0:0:0");

		verify(metricReporter).incrementHeartbeatReceived("eventType:EventType", "auctionCode:ABC", "sblu:567890123",
				"workOrder:1234567", "SaleKey: 0:0:0:0");
	}
}
