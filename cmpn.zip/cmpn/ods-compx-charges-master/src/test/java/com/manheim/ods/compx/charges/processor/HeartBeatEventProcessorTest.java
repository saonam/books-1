package com.manheim.ods.compx.charges.processor;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyInt;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.slf4j.Logger;
import org.springframework.jms.JmsException;

import com.manheim.ods.compx.charges.api.ChargesAPIRequest;
import com.manheim.ods.compx.charges.client.ChargesAPIClient;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.charges.dao.InventoryItem;
import com.manheim.ods.compx.charges.dao.ServiceOrderRepository;
import com.manheim.ods.compx.charges.service.StagingService;
import com.manheim.ods.compx.charges.service.TriggerService;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

@RunWith(MockitoJUnitRunner.class)
public class HeartBeatEventProcessorTest {

  @Mock
  private StagingService stagingService;
  @Mock
  private TriggerService triggerService;

  @Mock
  private ChargesAPIClient chargesAPIClient;

  @Mock
  private MetricReporter metricReporter;

  @Mock
  ServiceOrderRepository soRepository;
  @Mock
  Logger log;

  private HeartbeatEventProcessor eventProcessor;
  @Mock
  private AuctionEvent event;
  @Mock
  private ChargesProcessStatusLog chargesProcessStatusLog;
  @Mock
  private List<InventoryItem> inventoryItemList;
  @Mock
  private InventoryItem inventoryItem;

  @Before
  public void setup() throws StageException {
    String[] auctionCodes = {"TEST_AUCTION"};
    String[] ignoreAuctions = {"IGNORE_AUCTION"};
    when(event.getAuctionCode()).thenReturn("TEST_AUCTION");
    when(event.getEventType()).thenReturn("TEST_EVENT_TYPE");
    when(event.getSblu()).thenReturn("TEST_SBLU");
    when(event.getWorkOrder()).thenReturn("TEST_WORK_ORDER");

    when(chargesProcessStatusLog.getTransactionId()).thenReturn(1000L);
    when(chargesProcessStatusLog.getEventType()).thenReturn("TEST_EVENT_TYPE");
    when(chargesProcessStatusLog.getMessageGroupId()).thenReturn("grp1");

    String chargesApiResponse = "Test API Response";

    when(chargesAPIClient.getChargesResponse(any(ChargesAPIRequest.class)))
        .thenReturn(chargesApiResponse);

    when(stagingService.saveHeartBeatMessage(any(AuctionEvent.class), any(Timestamp.class)))
        .thenReturn(chargesProcessStatusLog);


    Mockito.doAnswer(new Answer<Void>() {
      @Override
      public Void answer(InvocationOnMock invocation) throws Throwable {
        return null;
      }
    }).when(metricReporter).incrementHeartbeatProcessed(anyString(), anyString(), anyString());

    eventProcessor = new HeartbeatEventProcessor(chargesAPIClient, soRepository, stagingService,
        auctionCodes, triggerService, metricReporter, ignoreAuctions);
    when(inventoryItem.getSblu()).thenReturn("TEST_SBLU");
    when(inventoryItemList.get(0)).thenReturn(inventoryItem);
    when(soRepository.findServiceOrderByAuctionSblu(anyString(), anyString(), anyString()))
        .thenReturn(inventoryItemList);
  }

  @Test
  public void test() throws Exception {
    eventProcessor.processEvent(event);
    verify(triggerService).sendTriggerToQueue(eq(event), any(Timestamp.class),
        eq(chargesProcessStatusLog));
  }

  @Test
  public void testForNotAllowedAuction() throws Exception {
    when(event.getAuctionCode()).thenReturn("AUCTION");
    eventProcessor.processEvent(event);

    verify(triggerService, never()).sendTriggerToQueue(eq(event), any(Timestamp.class),
        eq(chargesProcessStatusLog));

  }

  @Test
  public void testHeartbeatForSOwithAuctionWO() throws Exception {
    when(event.getSblu()).thenReturn(null);
    when(soRepository.findServiceOrderByAuctionWO(anyString(), anyString(), anyString()))
        .thenReturn(inventoryItemList);

    eventProcessor.processEvent(event);
    verify(triggerService).sendTriggerToQueue(eq(event), any(Timestamp.class),
        eq(chargesProcessStatusLog));
  }

  @Test
  public void testHeartbeatForSOwithSaleKey() throws Exception {
    when(event.getSblu()).thenReturn(null);
    when(event.getWorkOrder()).thenReturn(null);
    when(soRepository.findServiceOrderByAuctionSaleKey(anyString(), anyInt(), anyInt(), anyInt(),
        anyInt())).thenReturn(inventoryItemList);

    eventProcessor.processEvent(event);
    verify(triggerService).sendTriggerToQueue(eq(event), any(Timestamp.class),
        eq(chargesProcessStatusLog));
  }

  @Test(expected = JAXBException.class)
  public void testProcessEventForJAXBException() throws Exception {
    when(triggerService.sendTriggerToQueue(eq(event), any(Timestamp.class),
        eq(chargesProcessStatusLog))).thenThrow(Mockito.mock(JAXBException.class));

    eventProcessor.processEvent(event);

  }

  @Test(expected = JmsException.class)
  public void testProcessEventForJmsException() throws Exception {
    when(triggerService.sendTriggerToQueue(eq(event), any(Timestamp.class),
        eq(chargesProcessStatusLog))).thenThrow(Mockito.mock(JmsException.class));

    eventProcessor.processEvent(event);

  }

  @Test
  public void testHeartbeatForMissingInventory() throws Exception {
    when(event.getSblu()).thenReturn(null);
    when(event.getWorkOrder()).thenReturn(null);
    when(soRepository.findServiceOrderByAuctionSaleKey(anyString(), anyInt(), anyInt(), anyInt(),
        anyInt())).thenReturn(null);

    eventProcessor.processEvent(event);
    verify(triggerService).sendTriggerToQueue(eq(event), any(Timestamp.class),
        eq(chargesProcessStatusLog));
  }

}
