package com.manheim.ods.compx.route.error;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.charges.service.StagingService;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

@RunWith(MockitoJUnitRunner.class)
public class UnsuccessfulClientExecutionExceptionHandlerTest {

  @Mock
  Exchange exchange;
  @Mock
  Message message;
  @Mock
  UnsuccessfulClientExecutionException exception;
  @Mock
  AuctionEvent auctionEvent;
  @Mock
  StagingService stagingService;
  @Mock
  ChargesProcessStatusLog chargesProcessStatusLog;
  @Mock
  MetricReporter metricReporter;

  UnsuccessfulClientExecutionExceptionHandler unsuccessfulClientExecutionExceptionHandler;

  @Before
  public void setup() throws StageException {
    when(exchange.getIn()).thenReturn(message);
    when(exception.getMessage()).thenReturn("Test Unsuccessful Client Execution Exception");
    when(exchange.getProperty(eq(Exchange.EXCEPTION_CAUGHT),
        eq(UnsuccessfulClientExecutionException.class))).thenReturn(exception);

    when(message.getBody(eq(AuctionEvent.class))).thenReturn(auctionEvent);


    when(auctionEvent.getAuctionCode()).thenReturn("TEST_AUCTION");
    when(auctionEvent.getSblu()).thenReturn("TEST_SBLU");
    when(auctionEvent.getWorkOrder()).thenReturn("TEST_WO");

    when(stagingService.save(eq(auctionEvent), anyString(), eq(true), any(Timestamp.class)))
        .thenReturn(chargesProcessStatusLog);

    unsuccessfulClientExecutionExceptionHandler =
        new UnsuccessfulClientExecutionExceptionHandler(metricReporter, stagingService);
  }

  @Test
  public void testProcess() {
    try {
      when(exchange.getProperty(eq(Exchange.EXCEPTION_CAUGHT),
          eq(UnsuccessfulClientExecutionException.class))).thenReturn(null);

      unsuccessfulClientExecutionExceptionHandler.process(exchange);
      assert (true);
    } catch (Exception e) {
      e.printStackTrace();
      assert (false);
    }
  }

  @Test
  public void testProcessWithException() {
    try {
      when(exchange.getProperty(Exchange.EXCEPTION_CAUGHT,
          UnsuccessfulClientExecutionException.class)).thenReturn(exception);
      unsuccessfulClientExecutionExceptionHandler.process(exchange);
      verify(stagingService).saveApiError(any(AuctionEvent.class), any(Exception.class),
          any(Integer.class));
    } catch (Exception e) {
      e.printStackTrace();
      assert (false);
    }
  }
}
