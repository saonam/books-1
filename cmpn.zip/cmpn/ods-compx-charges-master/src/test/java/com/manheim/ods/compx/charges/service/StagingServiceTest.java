package com.manheim.ods.compx.charges.service;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

import java.sql.Timestamp;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.runners.MockitoJUnitRunner;

import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLogRepository;
import com.manheim.ods.compx.charges.dao.MessageXref;
import com.manheim.ods.compx.charges.dao.StgAdjustments;
import com.manheim.ods.compx.charges.dao.StgAdjustmentsHelper;
import com.manheim.ods.compx.charges.dao.StgChargesHeader;
import com.manheim.ods.compx.charges.dao.StgFees;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MessageGroupUtil;

@RunWith(MockitoJUnitRunner.class)
public class StagingServiceTest {

  private static final String AUCTION_CODE = "AUCTION_CODE1";

  @Mock
  private ChargesProcessStatusLog chargesProcessStatusLog;
  @Mock
  private Set<StgChargesHeader> chargesHeader;
  @Mock
  private Set<StgAdjustments> adjustments;
  @Mock
  private Set<StgFees> fees;

  @Mock
  private ChargesProcessStatusLogRepository logRepository;
  @Mock
  private AuctionEvent event;
  private Timestamp compxReqTimestamp;
  @Mock
  private MessageGroupUtil messageGroupUtil;
  StgAdjustmentsHelper stgAdjustmentsHelper;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    when(logRepository.save(chargesProcessStatusLog)).thenReturn(chargesProcessStatusLog);
    when(event.getAuctionCode()).thenReturn(AUCTION_CODE);
    when(event.getHref()).thenReturn("HREF");
    when(event.getEventType()).thenReturn("EVENT_TYPE");
    when(event.getSblu()).thenReturn("45678");
    when(messageGroupUtil.group(anyString())).thenReturn("grp1");
    when(chargesProcessStatusLog.getAdjustments()).thenReturn(adjustments);
    when(chargesProcessStatusLog.getChargesHeader()).thenReturn(chargesHeader);
    when(chargesProcessStatusLog.getFees()).thenReturn(fees);
    compxReqTimestamp = new Timestamp(System.currentTimeMillis());
    stgAdjustmentsHelper = new StgAdjustmentsHelper();
  }

  @Test
  public void shouldReturnStatusLogRepositoryAfterSaveForSeller() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getEventType()).thenReturn("SELLER_CHARGES_CHANGED");
    when(event.getWorkOrder()).thenReturn("12345");
    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("validSellerChargesResponse.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryAfterSaveForBuyer() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getEventType()).thenReturn("BUYER_CHARGES_CHANGED");
    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("validBuyerChargesResponse.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void testBuyerResponsePaymentWithoutCharges() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getEventType()).thenReturn("BUYER_CHARGES_CHANGED");
    Assert
        .assertNotNull(
            service.save(event,
                new CompXFileReader()
                    .fetchFileAsString("validBuyerChargesResponsePaymentWithoutCharges.json"),
                true, compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryForAServiceOrderNotExistsInODS() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);

    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("validBuyerChargesResponse.json"), false,
        compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoSblu() throws Exception {
    when(event.getSblu()).thenReturn(null);
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);

    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("validSellerChargesResponseWithNoSblu.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoCharges() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);

    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("buyerChargesResponseWithNoCharges.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoConsignment() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("buyerChargesResponseWithNoConsignment.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoUnitInSellerResponse() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("sellerChargesResponseWithNoUnit.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoSellerInSellerResponse() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getEventType()).thenReturn("SELLER_CHARGES_CHANGED");
    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("sellerChargesResponseWithNoSeller.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoConsignmentInSellerResponse() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("sellerChargesResponseWithNoConsignment.json"),
        true, compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoOfferingInSellerResponse() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("sellerChargesResponseWithNoOffering.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoFeesInSellerResponse() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("validSellerChargesResponseWithNoFees.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryForOnlyTaxesInSellerResponse() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    Assert
        .assertNotNull(
            service.save(event,
                new CompXFileReader()
                    .fetchFileAsString("validSellerChargesResponseWithNoFeesOnlyTaxes.json"),
                true, compxReqTimestamp));
  }

  @Test
  public void testSellerResponseWithoutSaleKey() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("validSellerChargesResponseNoSaleKey.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void testSellerResponseWithoutOperatingLocation() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    Assert
        .assertNotNull(service.save(event,
            new CompXFileReader()
                .fetchFileAsString("validSellerChargesResponseWithoutOperatingLocation.json"),
            true, compxReqTimestamp));
  }


  @Test
  public void shouldReturnStatusLogRepositoryForNoFeesInSellerResponseWithCheckFeesNFlag()
      throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    ChargesProcessStatusLog log = service.save(event,
        new CompXFileReader().fetchFileAsString("validSellerChargesResponseWithNoFees.json"), true,
        compxReqTimestamp);
    Assert.assertEquals("N", log.getCheckFees());
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoReconsInSellerResponseWithCheckReconsNFlag()
      throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    ChargesProcessStatusLog log = service.save(event,
        new CompXFileReader().fetchFileAsString("validSellerChargesResponseWithNoRecons.json"),
        true, compxReqTimestamp);
    Assert.assertEquals("N", log.getCheckRecons());
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoAdjustmentsInSellerResponseWithCheckAdjustmentsNFlag()
      throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    ChargesProcessStatusLog log = service.save(event,
        new CompXFileReader().fetchFileAsString("validSellerChargesResponseWithNoRecons.json"),
        true, compxReqTimestamp);
    Assert.assertEquals("N", log.getCheckAdjustments());
  }

  @Test
  public void shouldReturnStatusLogRepositoryForNoTaxesInSellerResponse() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    Assert.assertNotNull(service.save(event,
        new CompXFileReader().fetchFileAsString("validSellerChargesResponseWithNoTaxes.json"), true,
        compxReqTimestamp));
  }

  @Test
  public void shouldReturnStatusLogRepositoryWithNegativeOneDefaultIfVINIsMissing()
      throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    ChargesProcessStatusLog log = service.save(event, new CompXFileReader().fetchFileAsString(
        "sellerChargesResponseWithNullForStagingDefaults.json"), true, compxReqTimestamp);
    Assert.assertEquals("-1", log.getVin());
  }

  @Test
  public void shouldReturnStatusLogRepositoryWithNegativeOneDefaultIfDealerIsMissing()
      throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    ChargesProcessStatusLog log = service.save(event, new CompXFileReader().fetchFileAsString(
        "sellerChargesResponseWithNullForStagingDefaults.json"), true, compxReqTimestamp);
    Assert.assertEquals("-1", log.getDealerNumber());
  }

  @Test
  public void shouldReturnStatusLogRepositoryWithNegativeOneDefaultIfSbluIsMissing()
      throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    ChargesProcessStatusLog log = service.save(event, new CompXFileReader().fetchFileAsString(
        "sellerChargesResponseWithNullForStagingDefaults.json"), true, compxReqTimestamp);
    Assert.assertEquals(new Long(-1), log.getSblu());
  }

  @Test
  public void shouldReturnStatusLogRepositoryWithNegativeOneDefaultIfWorkOrderIsMissing()
      throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    ChargesProcessStatusLog log = service.save(event, new CompXFileReader().fetchFileAsString(
        "sellerChargesResponseWithNullForStagingDefaults.json"), true, compxReqTimestamp);
    Assert.assertEquals(new Long(-1), log.getWorkOrder());
  }

  @Test
  public void shouldThrowErrorInvalidAPIResponseAfterSave() throws Exception {
    try {
      StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
      service.save(event,
          new CompXFileReader().fetchFileAsString("invalidAPIResponseSBLUAsString.json"), true,
          compxReqTimestamp);
    } catch (StageException e) {
      Assert.assertEquals(e.getMessage(), "Charges API returned an invalid response");
    }
  }

  @Test
  public void shouldThrowErrorParseReceivedDateAfterSave() throws Exception {
    try {
      StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
      service.save(event,
          new CompXFileReader().fetchFileAsString("apiResponsewithInvalidReceivedDate.json"), true,
          compxReqTimestamp);
    } catch (StageException e) {
      Assert.assertEquals(e.getMessage(), "Unable to parse date field: receivedDate");
    }
  }

  @Test
  public void shouldThrowErrorParsingReconFeesForDateEnteredAfterSave() throws Exception {
    try {
      StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
      service.save(event,
          new CompXFileReader().fetchFileAsString("apiResponsewithInvalidReconDateEntered.json"),
          true, compxReqTimestamp);
    } catch (StageException e) {
      Assert.assertEquals(e.getMessage(), "Unable to parse date field: receivedDate");
    }
  }

  private MessageXref getLocationDetails() {
    MessageXref locationInfo = new MessageXref();
    locationInfo.setMsgGroupId("grp1");;
    return locationInfo;
  }

  @Test
  public void shouldReturnStatusLogRepositoryAfterSaveHeartbeat() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getEventType()).thenReturn("HEARTBEAT");
    when(event.getWorkOrder()).thenReturn("12345");
    when(event.getCdcjournaltimestamp()).thenReturn("2017-11-06T19:37:03.515696000");
    when(event.getTboxtimestamp()).thenReturn("2017-11-06T19:37:04.911Z");
    when(event.getAuctionid()).thenReturn("xQMM11");
    when(event.getSblu()).thenReturn("67890");
    when(event.getHeartbeatseqno()).thenReturn("21171608");
    when(event.getAuctioniduniqueid()).thenReturn("xQMM1121171608");
    when(logRepository.save(any(ChargesProcessStatusLog.class)))
        .thenReturn(chargesProcessStatusLog);
    Assert
        .assertNotNull(service.saveHeartBeatMessage(event, DateUtils.getCurrentSystemTimestamp()));
  }

  @Test
  public void shouldReturnStatusLogRepositoryAfterSaveHeartbeatWithNoAuctionId() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getEventType()).thenReturn("HEARTBEAT");
    when(event.getWorkOrder()).thenReturn("12345");
    when(event.getCdcjournaltimestamp()).thenReturn("2017-11-06T19:37:03.515696000");
    when(event.getTboxtimestamp()).thenReturn("2017-11-06T19:37:04.911Z");
    when(event.getAuctionid()).thenReturn(null);
    when(event.getSblu()).thenReturn("67890");
    when(event.getHeartbeatseqno()).thenReturn("21171608");
    when(logRepository.save(any(ChargesProcessStatusLog.class)))
        .thenReturn(chargesProcessStatusLog);
    Assert
        .assertNotNull(service.saveHeartBeatMessage(event, DateUtils.getCurrentSystemTimestamp()));
  }

  @Test
  public void shouldReturnStatusLogRepositoryWithHeaderwithPreviousBuyerSellerValues()
      throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getPrevBuyerDealerId()).thenReturn("67890");
    when(event.getPrevSellerDealerId()).thenReturn("34443");
    ChargesProcessStatusLog log = service.save(event,
        new CompXFileReader().fetchFileAsString("validSellerChargesResponseWithNoFees.json"), true,
        compxReqTimestamp);
    Assert.assertNotNull(log);

  }

  @Test
  public void shouldReturnDealerNumberAfterSave() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getEventType()).thenReturn("HEARTBEAT");
    when(event.getWorkOrder()).thenReturn("12345");
    when(event.getCdcjournaltimestamp()).thenReturn("2017-11-06T19:37:03.515696000");
    when(event.getTboxtimestamp()).thenReturn("2017-11-06T19:37:04.911Z");
    when(event.getAuctionid()).thenReturn(null);
    when(event.getSblu()).thenReturn("67890");
    when(event.getHeartbeatseqno()).thenReturn("21171608");
    when(event.getSellerId()).thenReturn("5098861");
    when(logRepository.save(any(ChargesProcessStatusLog.class)))
        .thenReturn(chargesProcessStatusLog);
    ChargesProcessStatusLog cpsl = service.save(event, null, true, compxReqTimestamp);
    Assert.assertEquals("5098861", cpsl.getDealerNumber());

  }

  @Test
  public void shouldSaveWithNullSaleTime() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getPrevBuyerDealerId()).thenReturn("67890");
    when(event.getPrevSellerDealerId()).thenReturn("34443");
    ChargesProcessStatusLog log = service.save(event,
        new CompXFileReader().fetchFileAsString("validSellerChargesResponseWithoutSaleTime.json"),
        true, compxReqTimestamp);
    Assert.assertNotNull(log);

  }


  @Test
  public void shouldReturnStatusLogRepositoryAfterSaveForBuyerWithPaymentMethod() throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getEventType()).thenReturn("BUYER_CHARGES_CHANGED");
    when(event.getCdcjournaltimestamp()).thenReturn("2018-06-01T23:15:24.216192000");
    ChargesProcessStatusLog cpsl = service.save(event,
        new CompXFileReader().fetchFileAsString("validBuyerChargesResponse.json"), true,
        compxReqTimestamp);
    Set<StgFees> stgFees = cpsl.getFees();
    for (StgFees stgFee : stgFees) {
      if (stgFee.getKeyType().equals("PAYMENT")) {
        Assert.assertEquals("K^", stgFee.getKeyValue());
        Assert.assertEquals("AUCTION_CODE1", stgFee.getAuctionCode());
        Assert.assertEquals("PAYMENT", stgFee.getKeyType());
        Assert.assertEquals("RD", stgFee.getProcessFlag());
        Assert.assertEquals(Long.valueOf(3935221), stgFee.getSblu());
        Assert.assertNotNull(stgFee.getChargeModifiedTimestamp());
        Assert.assertNotNull(stgFee.getCreatedTimestamp());
        return;
      }
    }
    assert (false);
  }

  @Test
  public void shouldReturnStatusLogRepositoryAfterSaveForBuyerWithDiffPaymentMethod()
      throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getEventType()).thenReturn("BUYER_CHARGES_CHANGED");
    ChargesProcessStatusLog cpsl = service.save(event,
        new CompXFileReader().fetchFileAsString("validBuyerChargesResponseWithPaymentMethod.json"),
        true, compxReqTimestamp);
    Set<StgFees> stgFees = cpsl.getFees();
    for (StgFees stgFee : stgFees) {
      if (stgFee.getKeyType().equals("PAYMENT")) {
        Assert.assertEquals("V", stgFee.getKeyValue());
        return;
      }
    }
    assert (false);
  }

  @Test
  public void shouldReturnStatusLogRepositoryAfterSaveForBuyerWithFloorplanAgency()
      throws Exception {
    StagingService service = new StagingService(logRepository, stgAdjustmentsHelper);
    when(event.getEventType()).thenReturn("BUYER_CHARGES_CHANGED");
    ChargesProcessStatusLog cpsl = service.save(event, new CompXFileReader().fetchFileAsString(
        "validBuyerChargesResponseWithFloorplanagency.json"), true, compxReqTimestamp);
    Set<StgFees> stgFees = cpsl.getFees();
    for (StgFees stgFee : stgFees) {
      if (stgFee.getKeyType().equals("PAYMENT")) {
        Assert.assertEquals("V", stgFee.getKeyValue());
        return;
      }
    }
    assert (false);
  }

}
