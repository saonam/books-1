package com.manheim.ods.compx.route;

import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.argThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatcher;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessor;
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessorCheckpointer;
import com.amazonaws.services.kinesis.model.Record;
import com.manheim.ods.compx.charges.TestApplication;
import com.manheim.ods.compx.charges.api.ChargesAPIRequest;
import com.manheim.ods.compx.charges.client.ChargesAPIClient;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLogRepository;
import com.manheim.ods.compx.charges.dao.InventoryItem;
import com.manheim.ods.compx.charges.dao.ServiceOrderRepository;
import com.manheim.ods.compx.exception.RecordNotFoundException;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.ods.stream.consumer.KinesisRecordProcessorFactory;

import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.Appender;



@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class StreamReceiverRouteBuilderTest {
  @Autowired
  CamelContext camelContext;

  @Autowired
  ProducerTemplate producerTemplate;
  AuctionEvent auctionEvent;

  @Autowired
  ChargesAPIClient chargesAPIClient;

  @Autowired
  ServiceOrderRepository soRepository;

  @Autowired
  ChargesProcessStatusLogRepository cpslRepository;
  @Mock
  private ArrayList<InventoryItem> mockArrayList;

  @Mock
  private MetricReporter metricReporter;

  String partitionKey;

  Logger logger = LoggerFactory.getLogger(StreamReceiverRouteBuilderTest.class);

  @Before
  public void setup() throws Exception {
    // Make the mock returns a list of fake possibilities
    auctionEvent = AuctionEvent.builder().auctionCode("AUCTION").eventType("SELLER_CHARGES_CHANGED")
        .sblu("1234").vin("VIN").cdcjournaltimestamp("2017-10-17T17:04:35.663600000")
        .cdcUserId("USER").workOrder("5678").build();

    partitionKey = String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getVin());
    MockitoAnnotations.initMocks(this);


    when(chargesAPIClient.getChargesResponse(argThat(new ArgumentMatcher<ChargesAPIRequest>() {
      @Override
      public boolean matches(final Object argument) {
        if (argument == null)
          return false;
        String auctionCode = ((ChargesAPIRequest) argument).getAuctionCode();
        String sblu = ((ChargesAPIRequest) argument).getSblu();
        return "AUCTION".equals(auctionCode) && "9999999".equals(sblu);
      }
    }))).thenThrow(new RecordNotFoundException("test-error", 404));


    when(chargesAPIClient.getChargesResponse(argThat(new ArgumentMatcher<ChargesAPIRequest>() {
      @Override
      public boolean matches(final Object argument) {
        if (argument == null)
          return false;
        String auctionCode = ((ChargesAPIRequest) argument).getAuctionCode();
        String sblu = ((ChargesAPIRequest) argument).getSblu();
        return "AUCTION".equals(auctionCode) && "500".equals(sblu);
      }
    }))).thenThrow(new UnsuccessfulClientExecutionException("test-error", 500));

    when(chargesAPIClient.getChargesResponse(argThat(new ArgumentMatcher<ChargesAPIRequest>() {
      @Override
      public boolean matches(final Object argument) {
        if (argument == null)
          return false;
        String auctionCode = ((ChargesAPIRequest) argument).getAuctionCode();
        String sblu = ((ChargesAPIRequest) argument).getSblu();
        return "AUCTION".equals(auctionCode) && "1234".equals(sblu);
      }
    }))).thenReturn("TEST_RESPONSE");

  }

  @SuppressWarnings({"unchecked", "rawtypes"})
  @Test
  public void testSuccessfulProcess() throws StageException, InterruptedException {
    // Now verify our logging interactions
    ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory
        .getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
    final Appender mockAppender = mock(Appender.class);
    when(mockAppender.getName()).thenReturn("MOCK");
    root.addAppender(mockAppender);

    producerTemplate.sendBody("direct:postevent", auctionEvent);
    verify(mockAppender).doAppend(argThat(new ArgumentMatcher() {
      @Override
      public boolean matches(final Object argument) {
        return ((LoggingEvent) argument).getFormattedMessage()
            .contains("Event processed successfully!");
      }
    }));
  }


  @Test
  public void testUnSuccessfulApiCall() throws StageException {
    // Now verify our logging interactions
    auctionEvent =
        AuctionEvent.builder().auctionCode("AUCTION").eventType("SELLER_SERVICE_ORDER_CREATED")
            .sblu("500").vin("VIN").cdcjournaltimestamp("2017-10-17T17:04:35.663600000")
            .cdcUserId("USER").workOrder("5678").build();


    ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory
        .getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
    final Appender mockAppender = mock(Appender.class);
    when(mockAppender.getName()).thenReturn("MOCK");
    root.addAppender(mockAppender);
    try {
      producerTemplate.sendBody("direct:postevent", auctionEvent);
    } catch (Exception ex) {
      logger.error("Error sending event to directLpostevent {}", ex);
    }

    verify(mockAppender).doAppend(argThat(new ArgumentMatcher() {
      @Override
      public boolean matches(final Object argument) {
        return ((LoggingEvent) argument).getFormattedMessage()
            .contains("Saved Compx Charges Api error");
      }
    }));



  }


  @Test
  public void testUnSuccessfulCompXProcess() throws StageException {
    // Auction event with wrong cdcjournaltimestamp
    auctionEvent =
        AuctionEvent.builder().auctionCode("AUCTION").eventType("SELLER_SERVICE_ORDER_CREATED")
            .sblu("1234").vin("VIN").cdcjournaltimestamp("2017-10-17T17:04:35.663600000")
            .cdcUserId("USER").workOrder("5678").build();


    ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory
        .getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
    final Appender mockAppender = mock(Appender.class);
    when(mockAppender.getName()).thenReturn("MOCK");
    root.addAppender(mockAppender);

    try {
      producerTemplate.sendBody("direct:postevent", auctionEvent);
    } catch (Exception ex) {
      logger.error("Exception posting event to direct:postevent - {}", ex);
    }

    verify(mockAppender).doAppend(argThat(new ArgumentMatcher() {
      @Override
      public boolean matches(final Object argument) {
        return ((LoggingEvent) argument).getFormattedMessage()
            .contains("Saved Compx Charges Stage error");
      }
    }));



  }

  @Test
  public void testUnSuccessfulClientExceptionCompXProcess() throws StageException {

    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    auctionEvent = AuctionEvent.builder().auctionCode("AUCTION").eventType("SELLER_CHARGES_CHANGED")
        .sblu("500").vin("VIN").cdcjournaltimestamp("2017-10-17T17:04:35.663600000")
        .cdcUserId("USER").workOrder("5678").build();
    String auctionEventString =
        "{\"auctionCode\":\"AUCTION\",\"vin\":\"VIN\",\"workOrder\":\"123456\",\"sblu\":\"500\",\"heartbeatseqno\":null,\"auctionid\":null,\"eventType\":\"SELLER_CHARGES_CHANGED\",\"auctionuniqueid\":null,\"auctioniduniqueid\":null,\"cdcjournaltimestamp\":\"2017-10-18T03:16:46.332560000\",\"tboxtimestamp\":null,\"changestatus\":null,\"jsonMessage\":null,\"saleYear\":2017,\"saleNumber\":10,\"laneNumber\":10,\"runNumber\":20,\"cdcUserId\":\"USER\",\"messageGroupId\":null,\"sourceTableName\":null,\"sourceEventCreatedTimestamp\":null,\"prevBuyerDealerId\":null,\"prevSellerDealerId\":null,\"sellerId\":null,\"redeemedDate\":null,\"sourceEventName\":null,\"href\":null,\"heartbeat\":false}";

    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);

    List<InventoryItem> iiList = new ArrayList();
    InventoryItem invItem = mock(InventoryItem.class);
    when(invItem.getSblu()).thenReturn("500");
    iiList.add(invItem);

    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);
    KinesisRecordProcessorFactory krpf = new KinesisRecordProcessorFactory(producerTemplate,
        metricReporter, 300L, 3, 30000L, new String[] {"TEST_AUCTION"}, null);

    IRecordProcessor kinesisRecordProcessor = krpf.createProcessor();


    when(soRepository.findServiceOrderByAuctionSblu(anyString(), anyString(), anyString()))
        .thenReturn(iiList);

    ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory
        .getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
    final Appender mockAppender = mock(Appender.class);
    when(mockAppender.getName()).thenReturn("MOCK");
    root.addAppender(mockAppender);
    kinesisRecordProcessor.processRecords(recordsList, checkPointer);

    // producerTemplate.sendBody("direct:postevent", auctionEvent);

    verify(mockAppender, times(3)).doAppend(argThat(new ArgumentMatcher() {
      @Override
      public boolean matches(final Object argument) {
        return ((LoggingEvent) argument).getFormattedMessage()
            .contains("Saved Compx Charges Api error");
      }
    }));

  }


  @Test
  public void testRecordNotFoundExceptionCompXProcess() throws StageException {

    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    auctionEvent = AuctionEvent.builder().auctionCode("AUCTION").eventType("SELLER_CHARGES_CHANGED")
        .sblu("9999999").vin("VIN").cdcjournaltimestamp("2017-10-17T17:04:35.663600000")
        .cdcUserId("USER").workOrder("123456").build();
    String auctionEventString =
        "{\"auctionCode\":\"AUCTION\",\"vin\":\"VIN\",\"workOrder\":\"123456\",\"sblu\":\"9999999\",\"heartbeatseqno\":null,\"auctionid\":null,\"eventType\":\"SELLER_CHARGES_CHANGED\",\"auctionuniqueid\":null,\"auctioniduniqueid\":null,\"cdcjournaltimestamp\":\"2017-10-18T03:16:46.332560000\",\"tboxtimestamp\":null,\"changestatus\":null,\"jsonMessage\":null,\"saleYear\":2017,\"saleNumber\":10,\"laneNumber\":10,\"runNumber\":20,\"cdcUserId\":\"USER\",\"messageGroupId\":null,\"sourceTableName\":null,\"sourceEventCreatedTimestamp\":null,\"prevBuyerDealerId\":null,\"prevSellerDealerId\":null,\"sellerId\":null,\"redeemedDate\":null,\"sourceEventName\":null,\"href\":null,\"heartbeat\":false}";

    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);

    List<InventoryItem> iiList = new ArrayList();
    InventoryItem invItem = mock(InventoryItem.class);
    when(invItem.getSblu()).thenReturn("9999999");
    iiList.add(invItem);

    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);
    KinesisRecordProcessorFactory krpf = new KinesisRecordProcessorFactory(producerTemplate,
        metricReporter, 300L, 3, 30000L, new String[] {"TEST_AUCTION"}, null);

    IRecordProcessor kinesisRecordProcessor = krpf.createProcessor();

    when(soRepository.findServiceOrderByAuctionSblu(anyString(), anyString(), anyString()))
        .thenReturn(iiList);

    ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory
        .getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
    final Appender mockAppender = mock(Appender.class);
    when(mockAppender.getName()).thenReturn("MOCK");
    root.addAppender(mockAppender);
    kinesisRecordProcessor.processRecords(recordsList, checkPointer);

    // producerTemplate.sendBody("direct:postevent", auctionEvent);

    verify(mockAppender, times(1)).doAppend(argThat(new ArgumentMatcher() {
      @Override
      public boolean matches(final Object argument) {
        return ((LoggingEvent) argument).getFormattedMessage()
            .contains("Saved Compx Charges Api error");
      }
    }));

  }
}
