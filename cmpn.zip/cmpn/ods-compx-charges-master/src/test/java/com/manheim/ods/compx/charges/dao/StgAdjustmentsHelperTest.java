package com.manheim.ods.compx.charges.dao;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.manheim.ods.compx.charges.api.response.Adjustment;
import com.manheim.ods.compx.charges.api.response.Buyer;
import com.manheim.ods.compx.charges.api.response.Charges;
import com.manheim.ods.compx.charges.api.response.ChargesResponse;
import com.manheim.ods.compx.charges.api.response.Consignment;
import com.manheim.ods.compx.charges.api.response.Offering;
import com.manheim.ods.compx.charges.api.response.SaleKey;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

public class StgAdjustmentsHelperTest extends Mockito {

  @Mock
  ChargesResponse chargesResponse;
  @Mock
  Adjustment adjustment;
  @Mock
  Iterator<Adjustment> adjustmentIterator;

  @Mock
  Charges charges;

  @Mock
  AuctionEvent auctionEvent;

  StgAdjustmentsHelper stgAdjustmentsHelper = new StgAdjustmentsHelper();

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    when(chargesResponse.getArbitrationDate()).thenReturn("2018-01-10");
    when(chargesResponse.getArbitrationDispositionCode()).thenReturn("BW");
    when(chargesResponse.getBuyer()).thenReturn(mock(Buyer.class));
    when(chargesResponse.getConsignment()).thenReturn(mock(Consignment.class));
    when(chargesResponse.getInvoiceDate()).thenReturn("2018-01-10");
    when(chargesResponse.getInvoiceNumber()).thenReturn("20180110");
    when(chargesResponse.getSaleStatus()).thenReturn("SF");
    when(chargesResponse.getRequestTimestamp()).thenReturn("2018-04-09T14:07:35.644Z");
    Offering offering = mock(Offering.class);
    SaleKey saleKey = mock(SaleKey.class);
    when(saleKey.getLaneNumber()).thenReturn(1);
    when(saleKey.getSaleNumber()).thenReturn(1);
    when(saleKey.getRunNumber()).thenReturn(1);
    when(saleKey.getSaleYear()).thenReturn(2018);
    when(offering.getSaleKey()).thenReturn(mock(SaleKey.class));
    when(chargesResponse.getOffering()).thenReturn(offering);


    adjustment = new Adjustment(new BigDecimal(1004), 1, "INTBUY", null, null, 315100, "skannan",
        "2018-01-04", null);

    when(chargesResponse.getCharges()).thenReturn(charges);
    List<Adjustment> adjustmentsList = new ArrayList();
    adjustmentsList.add(adjustment);
    when(charges.getAdjustments()).thenReturn(adjustmentsList);

    when(auctionEvent.getAuctionCode()).thenReturn("TEST");
  }

  @Test
  public void testStgAdjustments() throws ParseException {
    Set<StgAdjustments> stgAdjustmentSet =
        stgAdjustmentsHelper.buildAdjustments(chargesResponse, auctionEvent);

    for (StgAdjustments stgAdjustment : stgAdjustmentSet) {
      assert (true);
      return;
    }
    assert (false);
  }

  @Test
  public void testStgAdjustmentsWithPSI() throws ParseException {

    adjustment = new Adjustment(new BigDecimal(1004), 1, "PSI01", "DESCRIPTION", "USER DESCRIPTION",
        315100, "skannan", "2018-01-04", "Y");

    when(chargesResponse.getCharges()).thenReturn(charges);
    List<Adjustment> adjustmentsList = new ArrayList();
    adjustmentsList.add(adjustment);
    when(charges.getAdjustments()).thenReturn(adjustmentsList);
    Set<StgAdjustments> stgAdjustmentSet =
        stgAdjustmentsHelper.buildAdjustments(chargesResponse, auctionEvent);

    for (StgAdjustments stgAdjustment : stgAdjustmentSet) {
      if (stgAdjustment.getAdjustmentCode().equals("14 DAY")) {
        assert (true);
        Assert.assertEquals("RD", stgAdjustment.getProcessFlag());
        Assert.assertNotNull(stgAdjustment.getProcessedTimestamp());
        Assert.assertNotNull(stgAdjustment.getCreatedTimestamp());
        Assert.assertEquals("TEST", stgAdjustment.getAuctionCode());
        Assert.assertEquals(BigDecimal.valueOf(1004), stgAdjustment.getAdjustmentAmount());
        Assert.assertEquals("14 DAY", stgAdjustment.getAdjustmentCode());
        Assert.assertEquals("RD", stgAdjustment.getProcessFlag());
        Assert.assertEquals(Integer.valueOf(1), stgAdjustment.getArRecordNumber());
        Assert.assertEquals("USER DESCRIPTION", stgAdjustment.getUserDefinedDescription());
        Assert.assertEquals("DESCRIPTION", stgAdjustment.getDescription());
        return;
      }
    }
    assert (false);
  }

  @Test
  public void testStgAdjustmentsWithoutSaleKey() throws ParseException {
    Offering offering = mock(Offering.class);
    when(chargesResponse.getOffering()).thenReturn(offering);
    when(offering.getSaleKey()).thenReturn(null);
    Set<StgAdjustments> stgAdjustmentSet =
        stgAdjustmentsHelper.buildAdjustments(chargesResponse, auctionEvent);
    assert (true);

  }

  @Test
  public void testStgAdjustmentsWithoutOffering() throws ParseException {
    when(chargesResponse.getOffering()).thenReturn(null);
    Set<StgAdjustments> stgAdjustmentSet =
        stgAdjustmentsHelper.buildAdjustments(chargesResponse, auctionEvent);
    assert (true);

  }

}
