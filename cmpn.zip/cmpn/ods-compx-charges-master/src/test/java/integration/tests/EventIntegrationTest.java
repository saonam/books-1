package integration.tests;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.contains;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.NotifyBuilder;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessagePostProcessor;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessor;
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessorCheckpointer;
import com.amazonaws.services.kinesis.model.Record;
import com.jayway.restassured.RestAssured;
import com.manheim.ods.compx.charges.TestApplication;
import com.manheim.ods.compx.charges.api.ChargesAPIRequest;
import com.manheim.ods.compx.charges.client.ChargesAPIClient;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLogRepository;
import com.manheim.ods.compx.charges.dao.InventoryItem;
import com.manheim.ods.compx.charges.dao.MessageXref;
import com.manheim.ods.compx.charges.dao.MessageXrefRepository;
import com.manheim.ods.compx.charges.dao.ServiceOrderRepository;
import com.manheim.ods.compx.charges.service.TriggerService;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.BaseEvent;
import com.manheim.ods.compx.setup.QueueMessageBuilder;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MessageGroupUtil;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.ods.stream.consumer.KinesisRecordProcessorFactory;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.Appender;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class EventIntegrationTest {

  @Value("${local.server.port}")
  private Integer port;


  MetricReporter metricReporter;
  Appender<ILoggingEvent> mockAppender;
  IRecordProcessor chargesRecordProcessor;


  @Autowired
  ServiceOrderRepository serviceOrderRepository;
  @Autowired
  MessageXrefRepository msgXrefRepository;
  @Autowired
  ChargesProcessStatusLogRepository chargesProcessStatusLogRepository;
  @Autowired
  TriggerService triggerService;

  @Autowired
  ChargesAPIClient chargesAPIClient;
  @Autowired
  ProducerTemplate producerTemplate;

  @Autowired
  QueueMessageBuilder queueMessageBuilder;

  @Autowired
  JmsTemplate jmsTemplate;

  @Autowired
  LogWrapper logWrapper;

  @Autowired
  MessageGroupUtil messageGroupUtil;

  @Before
  public void setUp() throws JAXBException {
    RestAssured.port = port;
    metricReporter = mock(MetricReporter.class);
    String[] allowedAuctions = {"AUCTION"};
    String[] ignoreAuctions = {"INVALID_AUCTION"};

    KinesisRecordProcessorFactory krpf = new KinesisRecordProcessorFactory(producerTemplate,
        metricReporter, 300L, 3, 30000L, allowedAuctions, ignoreAuctions);
    chargesRecordProcessor = krpf.createProcessor();
    List iiList = mock(List.class);
    when(iiList.get(0)).thenReturn(mock(InventoryItem.class));
    when(iiList.size()).thenReturn(1);
    when(
        serviceOrderRepository.findServiceOrderByAuctionSblu(anyObject(), anyObject(), anyObject()))
            .thenReturn(iiList);
    MessageXref locationInfo = mock(MessageXref.class);
    when(locationInfo.getMsgGroupId()).thenReturn("grp1");

    when(msgXrefRepository.findMsgGroupIdByAuctionCode(any())).thenReturn(locationInfo);

  }

  @After
  public void tearDown() {}


  @Test
  public void testChargesRecordProcessor() throws URISyntaxException, IOException {
    String inputMessage = new CompXFileReader().fetchFileAsString("seller-charges-changed.json");
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    record.setData(ByteBuffer.wrap(inputMessage.getBytes()));
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);

    String validJsonResponse =
        new CompXFileReader().fetchFileAsString("validSellerChargesResponse.json");
    when(chargesAPIClient.getChargesResponse(any(ChargesAPIRequest.class)))
        .thenReturn(validJsonResponse);

    MessagePostProcessor messagePostProcessor = mock(MessagePostProcessor.class);

    when(queueMessageBuilder.messageProperties(anyString(), any(BaseEvent.class), any(),
        any(java.sql.Timestamp.class), any(Timestamp.class))).thenReturn(messagePostProcessor);

    doAnswer(new Answer<Void>() {
      public Void answer(InvocationOnMock invocation) {

        return null;
      }
    }).when(jmsTemplate).convertAndSend(anyString(), anyString(), any(MessagePostProcessor.class));

    chargesRecordProcessor.processRecords(recordsList, checkPointer);
    NotifyBuilder notify = new NotifyBuilder(producerTemplate.getCamelContext())
        .from("direct:seller-charges-changed*").whenDone(1).create();
    verify(logWrapper, atLeastOnce()).info(eq(TriggerService.class),
        contains("Successfully published message to queue."));
  }


  @Test
  public void testChargesRecordProcessorWithAPIException() throws URISyntaxException, IOException {
    String inputMessage = new CompXFileReader().fetchFileAsString("seller-charges-changed.json");
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    record.setData(ByteBuffer.wrap(inputMessage.getBytes()));
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);

    String validJsonResponse =
        new CompXFileReader().fetchFileAsString("validSellerChargesResponse.json");
    when(chargesAPIClient.getChargesResponse(any(ChargesAPIRequest.class)))
        .thenThrow(new UnsuccessfulClientExecutionException("auction-charges-api", 404));

    MessagePostProcessor messagePostProcessor = mock(MessagePostProcessor.class);

    when(queueMessageBuilder.messageProperties(anyString(), any(BaseEvent.class), any(),
        any(java.sql.Timestamp.class), any(Timestamp.class))).thenReturn(messagePostProcessor);

    doAnswer(new Answer<Void>() {
      public Void answer(InvocationOnMock invocation) {

        return null;
      }
    }).when(jmsTemplate).convertAndSend(anyString(), anyString(), any(MessagePostProcessor.class));

    chargesRecordProcessor.processRecords(recordsList, checkPointer);
  }

  @Test
  public void testHeartbeatRecordProcessor() throws URISyntaxException, IOException {
    String inputMessage = new CompXFileReader().fetchFileAsString("heartbeat.json");
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    record.setData(ByteBuffer.wrap(inputMessage.getBytes()));
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);

    String validJsonResponse =
        new CompXFileReader().fetchFileAsString("validSellerChargesResponse.json");
    when(chargesAPIClient.getChargesResponse(any(ChargesAPIRequest.class)))
        .thenReturn(validJsonResponse);

    MessagePostProcessor messagePostProcessor = mock(MessagePostProcessor.class);

    when(queueMessageBuilder.messageProperties(anyString(), any(BaseEvent.class), any(),
        any(java.sql.Timestamp.class), any(Timestamp.class))).thenReturn(messagePostProcessor);

    doAnswer(new Answer<Void>() {
      public Void answer(InvocationOnMock invocation) {
        Object[] args = invocation.getArguments();
        return null;
      }
    }).when(jmsTemplate).convertAndSend(anyString(), anyString(), any(MessagePostProcessor.class));
    ChargesProcessStatusLog chargesProcessStatusLog = mock(ChargesProcessStatusLog.class);
    when(chargesProcessStatusLog.getSblu()).thenReturn(1234L);
    when(chargesProcessStatusLog.getMessageGroupId()).thenReturn(null);
    when(chargesProcessStatusLogRepository.save(any(ChargesProcessStatusLog.class)))
        .thenReturn(chargesProcessStatusLog);

    chargesRecordProcessor.processRecords(recordsList, checkPointer);
    NotifyBuilder notify = new NotifyBuilder(producerTemplate.getCamelContext())
        .from("direct:seller-charges-changed*").whenDone(1).create();
    verify(logWrapper, atLeastOnce()).info(eq(TriggerService.class),
        contains("Successfully published message to queue. Queue name: test.queue"));
  }


  @Test
  public void testSellerChargesRecordProcessorWithSingleQueue()
      throws URISyntaxException, IOException {
    String inputMessage = new CompXFileReader().fetchFileAsString("seller-charges-changed.json");
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    record.setData(ByteBuffer.wrap(inputMessage.getBytes()));
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);

    String validJsonResponse =
        new CompXFileReader().fetchFileAsString("validSellerChargesResponse.json");
    when(chargesAPIClient.getChargesResponse(any(ChargesAPIRequest.class)))
        .thenReturn(validJsonResponse);

    MessagePostProcessor messagePostProcessor = mock(MessagePostProcessor.class);

    when(queueMessageBuilder.messageProperties(anyString(), any(BaseEvent.class), any(),
        any(java.sql.Timestamp.class), any(Timestamp.class))).thenReturn(messagePostProcessor);

    doAnswer(new Answer<Void>() {
      public Void answer(InvocationOnMock invocation) {

        return null;
      }
    }).when(jmsTemplate).convertAndSend(anyString(), anyString(), any(MessagePostProcessor.class));

    chargesRecordProcessor.processRecords(recordsList, checkPointer);
    NotifyBuilder notify = new NotifyBuilder(producerTemplate.getCamelContext())
        .from("direct:seller-charges-changed*").whenDone(1).create();
    verify(logWrapper, atLeastOnce()).info(eq(TriggerService.class),
        contains("Successfully published message to queue."));
  }


  @Test
  public void testChargesRecordProcessorForBuyerServiceOrder()
      throws URISyntaxException, IOException {
    String inputMessage =
        new CompXFileReader().fetchFileAsString("buyer-serviceorder-seller-charges-changed.json");
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    record.setData(ByteBuffer.wrap(inputMessage.getBytes()));
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);

    String validJsonResponse =
        new CompXFileReader().fetchFileAsString("validSellerChargesResponse.json");
    when(chargesAPIClient.getChargesResponse(any(ChargesAPIRequest.class)))
        .thenReturn(validJsonResponse);

    MessagePostProcessor messagePostProcessor = mock(MessagePostProcessor.class);

    when(queueMessageBuilder.messageProperties(anyString(), any(BaseEvent.class), any(),
        any(java.sql.Timestamp.class), any(Timestamp.class))).thenReturn(messagePostProcessor);

    doAnswer(new Answer<Void>() {
      public Void answer(InvocationOnMock invocation) {

        return null;
      }
    }).when(jmsTemplate).convertAndSend(anyString(), anyString(), any(MessagePostProcessor.class));

    chargesRecordProcessor.processRecords(recordsList, checkPointer);
    NotifyBuilder notify = new NotifyBuilder(producerTemplate.getCamelContext())
        .from("direct:seller-charges-changed*").whenDone(1).create();
    verify(logWrapper, atLeastOnce()).info(eq(TriggerService.class),
        contains("Successfully published message to queue."));
  }


  @Test
  public void testChargesRecordProcessorForInventoryDeleted()
      throws URISyntaxException, IOException {
    String inputMessage = new CompXFileReader().fetchFileAsString("inventory-deleted.json");
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    record.setData(ByteBuffer.wrap(inputMessage.getBytes()));
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);


    MessagePostProcessor messagePostProcessor = mock(MessagePostProcessor.class);

    when(queueMessageBuilder.messageProperties(anyString(), any(BaseEvent.class), any(),
        any(java.sql.Timestamp.class), any(Timestamp.class))).thenReturn(messagePostProcessor);

    doAnswer(new Answer<Void>() {
      public Void answer(InvocationOnMock invocation) {

        return null;
      }
    }).when(jmsTemplate).convertAndSend(anyString(), anyString(), any(MessagePostProcessor.class));

    chargesRecordProcessor.processRecords(recordsList, checkPointer);
    NotifyBuilder notify = new NotifyBuilder(producerTemplate.getCamelContext())
        .from("direct:inventory-deleted*").whenDone(1).create();
    verify(logWrapper, atLeastOnce()).info(eq(TriggerService.class),
        contains("Successfully published message to queue."));
  }

  @Test
  public void testBuyerChargesRecordProcessorWithSingleQueue()
      throws URISyntaxException, IOException {
    String inputMessage = new CompXFileReader().fetchFileAsString("buyer-charges-changed.json");
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    record.setData(ByteBuffer.wrap(inputMessage.getBytes()));
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);

    String validJsonResponse =
        new CompXFileReader().fetchFileAsString("validBuyerChargesResponse.json");
    when(chargesAPIClient.getChargesResponse(any(ChargesAPIRequest.class)))
        .thenReturn(validJsonResponse);

    MessagePostProcessor messagePostProcessor = mock(MessagePostProcessor.class);

    when(queueMessageBuilder.messageProperties(anyString(), any(BaseEvent.class), any(),
        any(java.sql.Timestamp.class), any(Timestamp.class))).thenReturn(messagePostProcessor);

    doAnswer(new Answer<Void>() {
      public Void answer(InvocationOnMock invocation) {

        return null;
      }
    }).when(jmsTemplate).convertAndSend(anyString(), anyString(), any(MessagePostProcessor.class));

    chargesRecordProcessor.processRecords(recordsList, checkPointer);
    NotifyBuilder notify = new NotifyBuilder(producerTemplate.getCamelContext())
        .from("direct:cbs-buyer-charges-changed*").whenDone(1).create();
    verify(logWrapper, atLeastOnce()).info(eq(TriggerService.class),
        contains("Successfully published message to queue."));
  }


  @Test
  public void testCBSBuyerChargesRecordProcessorWithSingleQueue()
      throws URISyntaxException, IOException {
    String inputMessage = new CompXFileReader().fetchFileAsString("cbs-buyer-charges-changed.json");
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    record.setData(ByteBuffer.wrap(inputMessage.getBytes()));
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);

    String validJsonResponse =
        new CompXFileReader().fetchFileAsString("validBuyerChargesResponse.json");
    when(chargesAPIClient.getChargesResponse(any(ChargesAPIRequest.class)))
        .thenReturn(validJsonResponse);

    MessagePostProcessor messagePostProcessor = mock(MessagePostProcessor.class);

    when(queueMessageBuilder.messageProperties(anyString(), any(BaseEvent.class), any(),
        any(java.sql.Timestamp.class), any(Timestamp.class))).thenReturn(messagePostProcessor);

    doAnswer(new Answer<Void>() {
      public Void answer(InvocationOnMock invocation) {

        return null;
      }
    }).when(jmsTemplate).convertAndSend(anyString(), anyString(), any(MessagePostProcessor.class));

    chargesRecordProcessor.processRecords(recordsList, checkPointer);
    NotifyBuilder notify = new NotifyBuilder(producerTemplate.getCamelContext())
        .from("direct:buyer-charges-changed*").whenDone(1).create();
    verify(logWrapper, atLeastOnce()).info(eq(TriggerService.class),
        contains("Successfully published message to queue."));
  }

  @Test
  public void testBuyerChargesRecordWithIfSaleFlag()
      throws URISyntaxException, IOException, JAXBException {
    String inputMessage = new CompXFileReader().fetchFileAsString("buyer-charges-changed.json");
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    record.setData(ByteBuffer.wrap(inputMessage.getBytes()));
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    IRecordProcessorCheckpointer checkPointer = mock(IRecordProcessorCheckpointer.class);

    String validJsonResponse =
        new CompXFileReader().fetchFileAsString("validBuyerChargesResponseWithIfSale.json");
    when(chargesAPIClient.getChargesResponse(any(ChargesAPIRequest.class)))
        .thenReturn(validJsonResponse);

    MessagePostProcessor messagePostProcessor = mock(MessagePostProcessor.class);

    when(queueMessageBuilder.messageProperties(anyString(), any(BaseEvent.class), any(),
        any(java.sql.Timestamp.class), any(Timestamp.class))).thenReturn(messagePostProcessor);

    doAnswer(new Answer<Void>() {
      public Void answer(InvocationOnMock invocation) {

        return null;
      }
    }).when(jmsTemplate).convertAndSend(anyString(), anyString(), any(MessagePostProcessor.class));

    chargesRecordProcessor.processRecords(recordsList, checkPointer);
    verify(logWrapper, atLeastOnce()).info(eq(TriggerService.class),
        contains("Successfully published message to queue."));
  }

}
