package com.manheim.ods.compx.charges.processor;

import java.sql.Timestamp;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.jms.JmsException;
import org.springframework.stereotype.Service;

import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.charges.dao.ServiceOrderRepository;
import com.manheim.ods.compx.charges.service.StagingService;
import com.manheim.ods.compx.charges.service.TriggerService;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

@Service
@RefreshScope
public class InventoryDeletedProcessor extends EventProcessor {
  private StagingService stagingService;
  private TriggerService triggerService;
  Logger log = LoggerFactory.getLogger(this.getClass());
  private static final String ALLOWED_AUCTIONS_PARAM = "${seller.auction.codes}";
  private static final String IGNORED_AUCTIONS_PARAM = "${seller.ignore.auction.codes}";

  public InventoryDeletedProcessor(ServiceOrderRepository soRepository,
      StagingService stagingService, @Value(ALLOWED_AUCTIONS_PARAM) String[] auctions,
      TriggerService triggerService, MetricReporter metricReporter,
      @Value(IGNORED_AUCTIONS_PARAM) String[] ignoreAuctions) {
    super(auctions, metricReporter, ignoreAuctions, soRepository);
    this.stagingService = stagingService;
    this.triggerService = triggerService;
  }

  @Override
  protected void process(AuctionEvent event) throws JAXBException, StageException {
    Timestamp compxReqTimestamp = new Timestamp(System.currentTimeMillis());

    // save staging
    ChargesProcessStatusLog processStatusLog =
        stagingService.save(event, null, true, new Timestamp(System.currentTimeMillis()));

    // send trigger message for ETL to process staging records
    try {
      triggerService.sendTriggerToQueue(event, compxReqTimestamp, processStatusLog);
    } catch (JAXBException | JmsException e) {
      String message = "Failed to build trigger event to ETL!!";
      log.error(message, e);
      throw e;
    }
  }
}
