package com.manheim.ods.compx.charges.api.response;

import org.apache.commons.lang3.StringUtils;

public class PaymentMethodBuilder {
  public String build(String howPaidCode, String flrType, String paidDate) {
    if (StringUtils.equalsAny(howPaidCode, "K", "Z")) {
      if (StringUtils.isNotBlank(flrType.trim())) {
        return StringUtils.appendIfMissing(howPaidCode, flrType.trim());
      } else if (paidDate == null) {
        return StringUtils.appendIfMissing(howPaidCode, "-NA");
      } else {
        return howPaidCode;
      }
    }
    return howPaidCode;
  }
}
