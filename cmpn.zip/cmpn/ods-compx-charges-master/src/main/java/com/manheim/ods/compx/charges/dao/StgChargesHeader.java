package com.manheim.ods.compx.charges.dao;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Setter;

@Entity
@Setter
@Table(name = "STG_CHARGES_HEADER")
public class StgChargesHeader implements Serializable {

  private static final long serialVersionUID = 278990150956670738L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_CHARGES_STAGING_ID")
  @SequenceGenerator(name = "SEQ_CHARGES_STAGING_ID", sequenceName = "SEQ_CHARGES_STAGING_ID")
  @Setter(AccessLevel.NONE)
  private Long stgChargesHeaderId;
  @Setter(AccessLevel.NONE)
  @Column(name = "TRANSACTION_ID")
  private Long transactionId;
  @Column(name = "AUCTION_CODE")
  private String auctionCode;
  @Column(name = "SBLU")
  private Long sblu;
  @Column(name = "WORK_ORDER_NUMBER")
  private Long workOrder;
  @Column(name = "VIN")
  private String vin;
  @Column(name = "SELLER_DEALER_NUMBER")
  private Long sellerDealerNumber;
  @Column(name = "PREV_SELLER_DEALER_NUMBER")
  private Long prevSellerDealerNumber;
  @Column(name = "PREV_BUYER_DEALER_NUMBER")
  private Long prevBuyerDealerNumber;
  @Column(name = "BILL_TO_DEALER_NUMBER")
  private Long billToCustomerId;
  @Column(name = "INVOICE_DATE")
  private Date invoiceDate;
  @Column(name = "PAID_DATE")
  private Date paidDate;
  @Column(name = "FLOOR_PLAN_AGENCY_CODE")
  private String floorPlanAgencyCode;
  @Column(name = "SELLER_CHECK_CLEARED_DATE")
  private Date sellerCheckClearedDate;
  @Column(name = "SELLER_CHECK_STOP_PAY_DATE")
  private Date sellerCheckStopPayDate;
  @Column(name = "SELLER_CHECK_VOID_DATE")
  private Date sellerCheckVoidDate;
  @Column(name = "SELLER_CHECK_PRINTED_IND")
  private String sellerCheckPrintIndicator;
  @Column(name = "INVOICE_NUMBER")
  private String invoiceNumber;
  @Column(name = "SELLER_DEALER_NAME")
  private String sellerDealerName;
  @Column(name = "BUYER_DEALER_NUMBER")
  private Long buyerDealerNumber;
  @Column(name = "BUYER_DEALER_NAME")
  private String buyerDealerName;
  @Column(name = "RECEIVED_DATE")
  private Date receivedDate;
  @Column(name = "REGISTRATION_DATE")
  private Date registrationDate;
  @Column(name = "SALE_DATE")
  private Date saleDate;
  @Column(name = "SALE_TIME")
  private String saleTime;
  @Column(name = "REDEEMED_DATE")
  private Date redeemedDate;
  @Column(name = "ARBITRATION_DATE")
  private Date arbitrationDate;
  @Column(name = "ARBITRATION_DISPOSITION_CODE")
  private String arbitrationDispositionCode;
  @Column(name = "SALE_YEAR")
  private Integer saleYear;
  @Column(name = "SALE_NUMBER")
  private Integer saleNumber;
  @Column(name = "SALE_LANE")
  private Integer saleLane;
  @Column(name = "SALE_RUN")
  private Integer saleRun;
  @Column(name = "SALE_PRICE")
  private Integer salePrice;
  @Column(name = "GROUP_CODE")
  private String groupCode;

  @Column(name = "PROCESS_FLAG")
  private String processFlag;
  @Column(name = "CREATED_TIMESTAMP")
  private Timestamp createdTimestamp;
  @Column(name = "PROCESSED_TIMESTAMP")
  private Timestamp processedTimestamp;

}
