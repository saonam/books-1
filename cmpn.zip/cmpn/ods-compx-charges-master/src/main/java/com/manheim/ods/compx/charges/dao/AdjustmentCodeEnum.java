package com.manheim.ods.compx.charges.dao;

import lombok.Getter;

@Getter
public enum AdjustmentCodeEnum {
  PSI_01_7DAY("PSI01", "N", "7 DAY"), 
  PSI_01_14DAY("PSI01", "Y", "14 DAY"), 
  PSI_02("PSI02", "N", "Sale Day Check"), 
  PSI_03("PSI03", "N",  "Frame Check Only"), 
  PSI_19("PSI19", "N",  "Limited Powertrain"), 
  PSI_20("PSI20", "N",  "Limited Powertrain AR"), 
  OTHER(null, null, "Other");

  private final String legacyAdjustmentCode;
  private final String psi14DayFlag;
  private final String value;

  AdjustmentCodeEnum(String legacyAdjustmentCode, String psi14DayFlag, String value) {
    this.legacyAdjustmentCode = legacyAdjustmentCode;
    this.psi14DayFlag = psi14DayFlag;
    this.value = value;
  }
}
