package com.manheim.ods.compx.charges.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;

@Entity
@Table(name = "INVENTORY_ITEM")
public class InventoryItem implements Serializable {

  private static final long serialVersionUID = 8969678988944840757L;

  @Id
  @Column(name = "INVENTORY_ITEM_ID")
  private Long inventoryItemId;

  @Column(name = "auction_code")
  private String auctionCode;

  @Getter
  @Column(name = "sblu")
  private String sblu;

}
