package com.manheim.ods.compx.charges.processor;

import java.sql.Timestamp;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.jms.JmsException;
import org.springframework.stereotype.Service;

import com.manheim.ods.compx.charges.api.ChargesAPIRequest;
import com.manheim.ods.compx.charges.client.ChargesAPIClient;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.charges.dao.InventoryItem;
import com.manheim.ods.compx.charges.dao.ServiceOrderRepository;
import com.manheim.ods.compx.charges.service.StagingService;
import com.manheim.ods.compx.charges.service.TriggerService;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

@Service
@RefreshScope
public class BuyerChargesChangedEventProcessor extends EventProcessor {

  private StagingService stagingService;
  private TriggerService triggerService;
  private static final String BUYER_ENDPOINT_PARAM = "buyer";
  private ChargesAPIClient chargesAPIClient;
  MetricReporter metricReporter;
  private static final String AUCTION_CODE_LABEL = "auctionCode:";
  Logger log = LoggerFactory.getLogger(this.getClass());
  protected static final String ALLOWED_AUCTIONS_PARAM = "${buyer.auction.codes}";
  protected static final String IGNORED_AUCTIONS_PARAM = "${buyer.ignore.auction.codes}";

  public BuyerChargesChangedEventProcessor(ChargesAPIClient chargesAPIClient,
      ServiceOrderRepository soRepository, StagingService stagingService,
      @Value(ALLOWED_AUCTIONS_PARAM) String[] auctions, TriggerService triggerService,
      MetricReporter metricReporter, @Value(IGNORED_AUCTIONS_PARAM) String[] ignoreAuctions) {
    super(auctions, metricReporter, ignoreAuctions, soRepository);
    this.triggerService = triggerService;
    this.stagingService = stagingService;
    this.chargesAPIClient = chargesAPIClient;
    this.metricReporter = metricReporter;
  }


  protected String callBuyerAuctionChargesAPI(AuctionEvent event, String sblu) {
    log.info("callBuyerAuctionChargesAPI - sblu: {}", sblu);
    long startTime = System.currentTimeMillis();
    ChargesAPIRequest apiRequest =
        new ChargesAPIRequest(BUYER_ENDPOINT_PARAM, event.getAuctionCode(), sblu);
    String chargesResponse = chargesAPIClient.getChargesResponse(apiRequest);
    metricReporter.recordExternalCallTime(System.currentTimeMillis() - startTime,
        "service-name:compx-charges", "service-uri:charges/search/buyer",
        AUCTION_CODE_LABEL + event.getAuctionCode());
    log.info("End callBuyerAuctionChargesAPI");

    return chargesResponse;
  }

  @Override
  protected void process(AuctionEvent event) throws JAXBException, StageException {

    log.info("Process AuctionEvent: {}", event);
    Timestamp compxReqTimestamp = new Timestamp(System.currentTimeMillis());
    String auctionChargesAPIResponse = null;

    // does service order exist
    InventoryItem ii = retrieveODSInventoryItem(event, "BR");
    boolean soExists = false;

    // call Auction API
    if (null != ii) {
      auctionChargesAPIResponse = callBuyerAuctionChargesAPI(event, ii.getSblu());
      soExists = true;
    }

    // save staging
    ChargesProcessStatusLog processStatusLog =
        stagingService.save(event, auctionChargesAPIResponse, soExists, compxReqTimestamp);


    // send trigger message for ETL to process staging records
    if (soExists) {
      try {
        triggerService.sendTriggerToQueue(event, compxReqTimestamp, processStatusLog);
      } catch (JAXBException | JmsException e) {
        String message = "Failed to build trigger event to ETL!!";
        log.error(message, e);
        throw e;
      }
    }

    log.info("Event processed successfully!");
  }


}
