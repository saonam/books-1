package com.manheim.ods.compx.route;

import java.util.Arrays;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@Component
public class EventTypeValidator implements Predicate {
  @Autowired
  ObjectMapper objectMapper;
  String[] validEventTypes = {"SELLER_CHARGES_CHANGED", "BUYER_CHARGES_CHANGED", "HEARTBEAT",
      "SELLER_SERVICE_ORDER_CREATED"};

  Logger logger = LoggerFactory.getLogger(this.getClass());

  @Override
  public boolean matches(Exchange exchange) {
    AuctionEvent event = exchange.getIn().getBody(AuctionEvent.class);
    boolean eventTypeGood = false;
    if (event != null) {
      eventTypeGood = Arrays.asList(validEventTypes).contains(event.getEventType());
      logger.info("EventType Validator for {} matches ? {}", event.getEventType(), eventTypeGood);
    }

    return eventTypeGood;
  }

}
