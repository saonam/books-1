package com.manheim.ods.compx.charges.api;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.Path;

@FunctionalInterface
public interface ChargesAPIConfiguration {

    @GET("/charges/search/{dealerType}/auction/{auction}/sblu/{sblu}")
    Call<String> configureChargesCall(@Header("Authorization") String authorization,
        @Path("dealerType") String dealerType,
        @Path("auction") String auction, @Path("sblu") String sblu);
}
