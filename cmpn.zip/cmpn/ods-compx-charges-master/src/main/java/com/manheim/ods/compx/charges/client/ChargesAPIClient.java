package com.manheim.ods.compx.charges.client;


import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.charges.api.ChargesAPIConfiguration;
import com.manheim.ods.compx.charges.api.ChargesAPIRequest;
import com.manheim.ods.compx.client.Client;
import com.manheim.ods.compx.exception.RecordNotFoundException;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.Sleeper;

import retrofit2.Call;
import retrofit2.Response;

@Component
@RefreshScope
public class ChargesAPIClient {

  public static final String CLIENT_NAME = "Auction Charges API";

  private final ChargesAPIConfiguration apiConfiguration;
  private Client client;
  private String authorization;

  private final Integer maxRetryCount;
  private LogWrapper logWrapper;
  private Sleeper sleeper;

  @Autowired
  public ChargesAPIClient(ChargesAPIConfiguration apiConfiguration, Client client,
      @Value("${auction.charges.api.max.retry.count}") Integer maxRetryCount, LogWrapper logWrapper,
      Sleeper sleeper, @Value("${charges.api.authorization}") String authorization)
      throws IOException {

    this.apiConfiguration = apiConfiguration;
    this.client = client;
    this.authorization = authorization;
    this.maxRetryCount = maxRetryCount;
    this.logWrapper = logWrapper;
    this.sleeper = sleeper;
  }

  public String getChargesResponse(ChargesAPIRequest request) {

    Call<String> call = apiConfiguration.configureChargesCall(authorization,
        request.getDealerType(), request.getAuctionCode(), request.getSblu());
    Response<String> response = null;
    int responseCode = HttpStatus.INTERNAL_SERVER_ERROR.value();
    try {
      response = executeChargesClientCall(call, request);
      responseCode = response.code();
      if (isSuccessfulResponse(response)) {
        logSuccessfulCall(request, call, response);

        return response.body();
      }
    } catch (Exception e) {
      logWrapper.error(this.getClass(), e);
    }
    logFailedCall(request, call, response, responseCode);
    if (responseCode == HttpStatus.NOT_FOUND.value()) {
      throw new RecordNotFoundException(CLIENT_NAME, responseCode);
    }
    throw new UnsuccessfulClientExecutionException(CLIENT_NAME, responseCode);
  }


  private Response<String> executeChargesClientCall(Call<String> call, ChargesAPIRequest request)
      throws IOException {
    logExecutionOfCall(call, request);
    Response<String> response = client.execute(call, this.getClass());
    if (isSuccessfulResponse(response)) {
      return response;
    }
    return retryChargesAPICall(response, call, request);
  }

  private Response<String> retryChargesAPICall(Response<String> response, Call<String> call,
      ChargesAPIRequest request) throws IOException {
    Response<String> currentResponse = response;
    Call<String> currentCall = call;
    for (Integer currentRetries = 0; currentRetries < maxRetryCount; currentRetries++) {
      logUnSuccessfulCall(currentCall, request, currentResponse);
      sleeper.sleep();
      currentCall = currentCall.clone();
      currentResponse = client.execute(currentCall, this.getClass());
      if (isSuccessfulResponse(currentResponse)) {
        return currentResponse;
      }

    }
    return currentResponse;
  }

  private void logFailedCall(ChargesAPIRequest request, Call<String> call,
      Response<String> response, int responseCode) {
    try {
      logWrapper.error(this.getClass(), String.format(
          "Unsuccessful Auction Charges API call after %s retries with HTTP Error %s for Request: %s for Input: Auction- %s, sblu- %s. Response received: %s",
          maxRetryCount, response.code(), call.request().toString(), request.getAuctionCode(),
          request.getSblu(), response.errorBody().string()));
    } catch (Exception e) {
      logWrapper.error(this.getClass(), String.format(
          "Unsuccessful Auction Charges API call after %s retries with HTTP Error %s for Request: %s for Input: Auction- %s, sblu- %s. Response received: <Unknown>",
          maxRetryCount, responseCode, call.request().toString(), request.getAuctionCode(),
          request.getSblu()));
      logWrapper.error(this.getClass(), e);
    }
  }

  private void logSuccessfulCall(ChargesAPIRequest request, Call<String> call,
      Response<String> response) {
    logWrapper.info(this.getClass(), String.format(
        "Successful Auction Charges API call for Request: %s for Input: Auction- %s, sblu- %s. Response received: %s",
        call.request().toString(), request.getAuctionCode(), request.getSblu(), response.body()));
  }

  private void logUnSuccessfulCall(Call<String> call, ChargesAPIRequest request,
      Response<String> response) {
    try {
      logWrapper.info(this.getClass(), String.format(
          "Unsuccessful Auction Charges API call with HTTP Error %s for Request: %s for Input: Auction- %s, sblu- %s. Response received: %s",
          response.code(), call.request().toString(), request.getAuctionCode(), request.getSblu(),
          response.errorBody().string()));
    } catch (Exception e) {
      logWrapper.info(this.getClass(), String.format(
          "Unsuccessful Auction Charges API call with HTTP Error %s for Request: %s for Input: Auction- %s, sblu- %s. Response received: <Unknown>",
          response.code(), call.request().toString(), request.getAuctionCode(), request.getSblu()));
      logWrapper.error(this.getClass(), e);
    }
  }

  private void logExecutionOfCall(Call<String> call, ChargesAPIRequest request) {
    logWrapper.info(this.getClass(),
        String.format(
            "Calling Auction Charges API with Request: %s for Input: Auction- %s, sblu- %s.",
            call.request().toString(), request.getAuctionCode(), request.getSblu()));
  }

  private boolean isSuccessfulResponse(Response<String> response) {
    return response.isSuccessful();
  }
}
