package com.manheim.ods.compx.route;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.charges.processor.HeartbeatEventProcessor;

@Component
public class HeartbeatRouteBuilder extends ChargesRouteBuilder {

  @Autowired
  HeartbeatEventProcessor heartbeatEventProcessor;

  public HeartbeatRouteBuilder(HeartbeatEventProcessor heartbeatEventProcessor) {
    this.heartbeatEventProcessor = heartbeatEventProcessor;
  }

  @Override
  public void configure() throws Exception {
    super.configure();
    from("direct:heartbeat").bean("heartbeatEventProcessor", "processEvent(${body})");

  }

}
