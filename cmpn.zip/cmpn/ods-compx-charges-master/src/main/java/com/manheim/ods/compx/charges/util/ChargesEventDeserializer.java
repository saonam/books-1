package com.manheim.ods.compx.charges.util;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.manheim.ods.compx.helper.CompXJsonParser;
import com.manheim.ods.compx.util.LogWrapper;

public class ChargesEventDeserializer extends JsonDeserializer<ChargesAuctionEvent> {

  private LogWrapper logger;
  private CompXJsonParser parser;

  @Autowired
  public ChargesEventDeserializer(LogWrapper logger, CompXJsonParser parser) {
    this.logger = logger;
    this.parser = parser;
  }

  @Override
  public ChargesAuctionEvent deserialize(JsonParser jsonParser, DeserializationContext context)
      throws IOException {

    JsonNode node = jsonParser.readValueAsTree();
    logger.info(ChargesEventDeserializer.class,
        String.format("Event Received: %s", node.toString()));

    ChargesAuctionEvent event = new ChargesAuctionEvent();
    event.setHref(parser.getNonNullValueForKey(node, "href"));
    event.setEventType(parser.getRequiredValueForKey(node, "eventType"));
    event.setAuctionCode(parser.getRequiredValueForKey(node, "auctionCode"));
    event.setSblu(parser.getValueForKey(node, "sblu"));
    event.setWorkOrder(parser.getValueForKey(node, "workOrder"));
    event.setHeartbeatseqno(parser.getValueForKey(node, "heartbeatseqno"));
    event.setCdcUserId(parser.getValueForKey(node, "cdcUserId"));
    event.setCdcjournaltimestamp(parser.getValueForKey(node, "cdcjournaltimestamp"));
    event.setTboxtimestamp(parser.getValueForKey(node, "tboxtimestamp"));
    event.setChangestatus(parser.getValueForKey(node, "changestatus"));
    event.setSourceTableName(parser.getValueForKey(node, "sourceTableName"));
    event.setJsonMessage(parser.getValueForKey(node, "jsonMessage"));
    String saleYear = parser.getValueForKey(node, "saleYear");
    String saleNumber = parser.getValueForKey(node, "saleNumber");
    String laneNumber = parser.getValueForKey(node, "laneNumber");
    String runNumber = parser.getValueForKey(node, "runNumber");
    String prevBuyerDealerId = parser.getValueForKey(node, "prevBuyerDealerId");
    String prevSellerDealerId = parser.getValueForKey(node, "prevSellerDealerId");
    String sellerId = parser.getValueForKey(node, "sellerId");
    String sourceEventName = parser.getValueForKey(node, "sourceEventName");
    event.setSourceEventName(sourceEventName);
    if (null != saleYear) {
      event.setSaleYear(Integer.parseInt(saleYear));
    }
    if (null != saleNumber) {
      event.setSaleNumber(Integer.parseInt(saleNumber));
    }
    if (null != laneNumber) {
      event.setLaneNumber(Integer.parseInt(laneNumber));
    }
    if (null != runNumber) {
      event.setRunNumber(Integer.parseInt(runNumber));
    }

    if (null != prevBuyerDealerId) {
      event.setPrevBuyerDealerId(prevBuyerDealerId);
    }
    if (null != prevSellerDealerId) {
      event.setPrevSellerDealerId(prevSellerDealerId);
    }
    if (null != sellerId) {
      event.setSellerId(sellerId);
    }


    return event;
  }

}
