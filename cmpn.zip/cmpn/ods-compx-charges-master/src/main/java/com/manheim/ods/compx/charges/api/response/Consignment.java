package com.manheim.ods.compx.charges.api.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter

public class Consignment {

  private Unit unit;
  private Location operatingLocation;
  private Long sblu;
  private Long workOrderNumber;
  private Seller seller;
  private String receivedDate;
  private String redeemedDate;
}
