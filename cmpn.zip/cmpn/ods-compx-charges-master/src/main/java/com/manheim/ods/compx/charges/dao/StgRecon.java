package com.manheim.ods.compx.charges.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Setter;

@Entity
@Setter
@Table(name= "STG_RECONS")
public class StgRecon implements Serializable{

	private static final long serialVersionUID = 1467071147170586230L;

	@Id
	@GeneratedValue(strategy= GenerationType.SEQUENCE, generator="SEQ_CHARGES_STAGING_ID")
	@SequenceGenerator(name= "SEQ_CHARGES_STAGING_ID", sequenceName= "SEQ_CHARGES_STAGING_ID")
	@Setter(AccessLevel.NONE)
	private Long stgReconsId;
	@Setter(AccessLevel.NONE) 
	@Column(name= "TRANSACTION_ID")
	private Long transactionId;
	@Column(name= "AUCTION_CODE")
	private String auctionCode;
	@Column(name= "WORK_ORDER_NUMBER")
	private Long workOrderNumber;
	@Column(name= "RECORD_NUMBER")
	private Integer recordNumber;
	@Column(name= "SUB_MENU")
	private Integer subMenu;
	@Column(name= "AMOUNT")
	private BigDecimal amount;
	@Column(name= "SUB_CLASS")
	private Integer subclass;
	@Column(name= "L_CODE")
	private String lCode;
	@Column(name= "DESCRIPTION")
	private String description;
	@Column(name= "LEGACY_RECON_DEDUCTIBLE")
	private String legacyReconDeductible;
	@Column(name= "SOURCE_USER_NAME")
	private String sourceUserName;
	@Column(name= "DATE_ENTERED")
	private Timestamp dateEntered;
	@Column(name= "ORIGINATION_SOURCE")
	private String originationSource;
	@Column(name= "SOURCE_OF_EDI_INFO")
	private String sourceOfEDIInfo;
	@Column(name= "PROCESS_FLAG")  // initial value: RD
	private String processFlag;
	@Column(name= "PROCESSED_TIMESTAMP")
	private Timestamp processedTimestamp;
	@Column(name= "CREATED_TIMESTAMP")
	private Timestamp createdTimestamp;
	
}
