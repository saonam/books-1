package com.manheim.ods.compx.charges.api.response;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class Buyer {

    private Long dealerNumber;
    private String dealerName;
}