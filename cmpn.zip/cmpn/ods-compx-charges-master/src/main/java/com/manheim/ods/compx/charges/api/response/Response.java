package com.manheim.ods.compx.charges.api.response;

public interface Response {

}
