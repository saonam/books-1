package com.manheim.ods.compx.charges.api.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class SaleKey {

  private Integer saleYear;
  private Integer saleNumber;
  private Integer laneNumber;
  private Integer runNumber;
}
