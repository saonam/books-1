package com.manheim.ods.compx.charges.api.response;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class Charges {

  private List<Recon> reconFees;
  private List<Fee> taxes;
  private List<Fee> dealerFees;
  private List<Adjustment> adjustments;
}
