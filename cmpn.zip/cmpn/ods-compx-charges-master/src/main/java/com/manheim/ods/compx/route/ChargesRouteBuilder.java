package com.manheim.ods.compx.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.charges.service.StagingService;
import com.manheim.ods.compx.exception.RecordNotFoundException;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.route.error.StageExceptionHandler;
import com.manheim.ods.compx.route.error.UnsuccessfulClientExecutionExceptionHandler;
import com.manheim.ods.compx.util.MetricReporter;

@Component
public class ChargesRouteBuilder extends RouteBuilder {
  @Autowired
  @Qualifier("stagingService")
  StagingService stagingService;

  @Autowired
  MetricReporter metricReporter;

  @Autowired
  StageExceptionHandler stageExceptionHandler;

  @Autowired
  UnsuccessfulClientExecutionExceptionHandler unsuccessfulClientExecutionExceptionHandler;

  public ChargesRouteBuilder() {
    // constructor
  }

  @Override
  public void configure() throws Exception {

    onException(UnsuccessfulClientExecutionException.class)
        .process(unsuccessfulClientExecutionExceptionHandler);
    onException(RecordNotFoundException.class).handled(true)
        .process(unsuccessfulClientExecutionExceptionHandler);
    onException(StageException.class).process(stageExceptionHandler);
  }

}
