package com.manheim.ods.compx.charges.dao;

import org.apache.commons.lang3.StringUtils;

public class AdjustmentCodeUtil {
  public AdjustmentCodeEnum findAdjustmentCode(String legacyAdjustmentCode, String psi14DayFlag) {
    AdjustmentCodeEnum[] adjustmentCodeEnums = AdjustmentCodeEnum.values();
    for (AdjustmentCodeEnum adjustmentCodeEnum : adjustmentCodeEnums) {
      boolean legacyAdjustmentCodeMatches =
          StringUtils.equals(adjustmentCodeEnum.getLegacyAdjustmentCode(), legacyAdjustmentCode);
      boolean psi14DayFlagMatches =
          StringUtils.equals(adjustmentCodeEnum.getPsi14DayFlag(), psi14DayFlag);

      if (legacyAdjustmentCodeMatches && psi14DayFlagMatches)
        return adjustmentCodeEnum;
    }
    return AdjustmentCodeEnum.OTHER;
  }

}
