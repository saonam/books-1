package com.manheim.ods.compx.charges.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class ChargesAPIRequest {

	private String dealerType;
	private String auctionCode;
	private String sblu;
}
