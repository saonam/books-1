package com.manheim.ods.compx.charges.api.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class Offering {

  private String registrationDate;
  private String saleDate;
  private Long saleTime;
  private Integer salePrice;
  private SaleKey saleKey;
  private String ifSaleFlag;

}
