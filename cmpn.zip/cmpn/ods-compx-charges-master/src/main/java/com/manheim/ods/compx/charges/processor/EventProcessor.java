package com.manheim.ods.compx.charges.processor;

import java.util.List;

import javax.xml.bind.JAXBException;

import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.manheim.ods.compx.charges.dao.InventoryItem;
import com.manheim.ods.compx.charges.dao.ServiceOrderRepository;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

public class EventProcessor {

  private MetricReporter metricReporter;
  private Logger log = LoggerFactory.getLogger(this.getClass());
  private static final String AUCTION_CODE_LABEL = "auctionCode:";
  private static final String EVENT_TYPE_LABEL = "eventType:";
  private static final String VIN_LABEL = "vin:";
  static final String SERVICE_NAME_SERVICEORDER = "service-name:serviceorder";
  ServiceOrderRepository soRepository;
  private String[] allowedAuctions;
  private String[] ignoreAuctions;


  public EventProcessor(String[] auctions, MetricReporter metricReporter, String[] ignoreAuctions,
      ServiceOrderRepository soRepository) {
    super();
    this.allowedAuctions = auctions;
    this.metricReporter = metricReporter;
    this.ignoreAuctions = ignoreAuctions;
    this.soRepository = soRepository;
  }

  public void processEvent(AuctionEvent auctionEvent) throws StageException, JAXBException {
    if (allowedAuctions(auctionEvent.getAuctionCode())) {
      // log
      log.info("Received Auction Event: {}", auctionEvent);
      long startTime = System.currentTimeMillis();
      process(auctionEvent);
      metricReporter.recordExternalCallTime(System.currentTimeMillis() - startTime,
          "service-name:compx_process_event", EVENT_TYPE_LABEL + auctionEvent.getEventType());
      recordEventProcessed(auctionEvent);
    } else {
      log.info(
          "Event not processed, auction code is inactive: {}, active codes: {}, ignored auctions: {}",
          auctionEvent.getAuctionCode(), allowedAuctions, ignoreAuctions);
    }
  }


  protected void recordEventProcessed(AuctionEvent auctionEvent) {
    metricReporter.incrementEventProcessed(EVENT_TYPE_LABEL + auctionEvent.getEventType(),
        VIN_LABEL + auctionEvent.getVin(), AUCTION_CODE_LABEL + auctionEvent.getAuctionCode());

  }

  protected void process(AuctionEvent auctionEvent) throws JAXBException, StageException {
    // actual processor will override and provide implementation
  }

  private boolean allowedAuctions(String auction) {
    return !ArrayUtils.contains(ignoreAuctions, auction)
        && ((allowedAuctions.length == 1 && ArrayUtils.contains(allowedAuctions, "*"))
            || ArrayUtils.contains(allowedAuctions, auction));
  }

  protected InventoryItem retrieveODSInventoryItem(AuctionEvent event, String dealerTypeCode) {
    log.info("retrieveODSInventoryItem - auctionEvent:{} ", event);

    List<InventoryItem> iiList = null;
    long startTime = System.currentTimeMillis();

    if (null != event.getSblu()) {
      iiList = soRepository.findServiceOrderByAuctionSblu(event.getAuctionCode(), event.getSblu(),
          dealerTypeCode);
      metricReporter.recordExternalCallTime(System.currentTimeMillis() - startTime,
          SERVICE_NAME_SERVICEORDER, "service-method:findServiceOrderByAuctionSblu");
    } else if (null != event.getWorkOrder()) {
      iiList = soRepository.findServiceOrderByAuctionWO(event.getAuctionCode(),
          event.getWorkOrder(), dealerTypeCode);
      metricReporter.recordExternalCallTime(System.currentTimeMillis() - startTime,
          SERVICE_NAME_SERVICEORDER, "service-method:findServiceOrderByAuctionWO");
    } else if (null != event.getSaleYear() && null != event.getSaleNumber()
        && null != event.getLaneNumber() && null != event.getRunNumber()) {
      iiList = soRepository.findServiceOrderByAuctionSaleKey(event.getAuctionCode(),
          event.getSaleYear(), event.getSaleNumber(), event.getLaneNumber(), event.getRunNumber());
      metricReporter.recordExternalCallTime(System.currentTimeMillis() - startTime,
          SERVICE_NAME_SERVICEORDER, "service-method:findServiceOrderByAuctionSaleKey");
    }
    InventoryItem ii = null;
    if (null != iiList && !CollectionUtils.isEmpty(iiList)) {
      ii = iiList.get(0);
    }
    log.info("end retrieveODSInventoryItem ");

    return ii;
  }



}
