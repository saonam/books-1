package com.manheim.ods.compx.charges.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("serviceOrderRepository")
public interface ServiceOrderRepository extends JpaRepository<InventoryItem, Long>{

	@Query(value= 
			 "SELECT II.INVENTORY_ITEM_ID " 
			+"	,SELL_SVO.SERVICE_ORDER_ID SELL_SVO_ID " 
			+"	,II.AUCTION_CODE " 
			+"	,II.SBLU " 
			+"	,II.WORK_ORDER_NUMBER " 
			+" FROM INVENTORY_ITEM II " 
			+" INNER JOIN SERVICE_ORDER SELL_SVO " 
			+"	ON II.INVENTORY_ITEM_ID = SELL_SVO.INVENTORY_ITEM_ID " 
			+"		AND SELL_SVO.SERVICE_ORDER_TYPE_CODE = :soTypeCode " 
			+"		AND SELL_SVO.SERVICE_ORDER_STATUS_CODE NOT IN ('RJ','CN') " 
			+" WHERE II.AUCTION_CODE = :auctionCode " 
			+" AND " 
			+" ( " 
			+"		II.SBLU = :sblu " 
			+" ) ORDER BY II.CREATED_TIMESTAMP DESC "
			, nativeQuery= true)
	public List<InventoryItem> findServiceOrderByAuctionSblu(@Param("auctionCode") String auctionCode, @Param("sblu") String sblu,
				@Param("soTypeCode") String soTypeCode);

	@Query(value= 
			 "SELECT II.INVENTORY_ITEM_ID " 
			+"	,SELL_SVO.SERVICE_ORDER_ID SELL_SVO_ID " 
			+"	,II.AUCTION_CODE " 
			+"	,II.SBLU " 
			+"	,II.WORK_ORDER_NUMBER " 
			+" FROM INVENTORY_ITEM II " 
			+" INNER JOIN SERVICE_ORDER SELL_SVO " 
			+"	ON II.INVENTORY_ITEM_ID = SELL_SVO.INVENTORY_ITEM_ID " 
			+"		AND SELL_SVO.SERVICE_ORDER_TYPE_CODE = :soTypeCode " 
			+"		AND SELL_SVO.SERVICE_ORDER_STATUS_CODE NOT IN ('RJ','CN') " 
			+" WHERE II.AUCTION_CODE = :auctionCode " 
			+" AND " 
			+" ( " 
			+"		II.WORK_ORDER_NUMBER = :workOrder " 
			+" ) ORDER BY II.CREATED_TIMESTAMP DESC "
			, nativeQuery= true)
	public List<InventoryItem> findServiceOrderByAuctionWO(@Param("auctionCode") String auctionCode, @Param("workOrder") String workOrder,
				@Param("soTypeCode") String soTypeCode);
	
	
	@Query(value= 
			 "SELECT /*+ index(PUR IX1_PURCHASE) */ " 
			+" 	 II.INVENTORY_ITEM_ID " 
			+"	,BUY_SVO.SERVICE_ORDER_ID BUY_SVO_ID " 
			+"	,II.AUCTION_CODE " 
			+"	,II.SBLU " 
			+"	,II.WORK_ORDER_NUMBER " 
			+" FROM INVENTORY_ITEM II " 
			+" INNER JOIN " 
			+" ( " 
			+"	SELECT BSVO.* " 
			+"		,ROW_NUMBER() OVER ( " 
			+"			PARTITION BY BSVO.INVENTORY_ITEM_ID ORDER BY BSVO.CREATED_TIMESTAMP DESC " 
			+"			) RN " 
			+"	FROM SERVICE_ORDER BSVO " 
			+"	WHERE BSVO.SERVICE_ORDER_TYPE_CODE = 'BR' " 
			+"		AND BSVO.SERVICE_ORDER_STATUS_CODE NOT IN ('RJ','CN') " 
			+" ) BUY_SVO " 
			+"	ON II.INVENTORY_ITEM_ID = BUY_SVO.INVENTORY_ITEM_ID " 
			+"	AND BUY_SVO.RN = 1 " 
			+" INNER JOIN PURCHASE PUR " 
			+"		ON BUY_SVO.SERVICE_ORDER_ID = PUR.SERVICE_ORDER_ID " 
			+" WHERE II.AUCTION_CODE = :auctionCode " 
			+"        AND PUR.TEMP_SALE_YEAR = NVL(:saleYear, - 1) " 
			+"		AND PUR.TEMP_SALE_NUMBER = NVL(:saleNumber, - 1) " 
			+"		AND PUR.TEMP_SALE_LANE = NVL(:laneNumber, - 1) " 
			+"		AND PUR.TEMP_SALE_RUN = NVL(:runNumber, - 1) "
			+" ORDER BY II.CREATED_TIMESTAMP DESC "
			, nativeQuery= true)
	
	public List<InventoryItem> findServiceOrderByAuctionSaleKey(@Param("auctionCode") String auctionCode, @Param("saleYear") Integer saleYear,
			@Param("saleNumber") Integer saleNumber, @Param("laneNumber") Integer laneNumber, @Param("runNumber") Integer runNumber);
	
}