package com.manheim.ods.compx.route;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.charges.processor.BuyerServiceOrderCreatedProcessor;


@Component
public class BuyerServiceOrderCreatedRouteBuilder extends ChargesRouteBuilder {

  @Autowired
  BuyerServiceOrderCreatedProcessor serviceOrderCreatedProcessor;

  @Autowired
  public BuyerServiceOrderCreatedRouteBuilder(
      BuyerServiceOrderCreatedProcessor serviceOrderCreatedProcessor) {
    this.serviceOrderCreatedProcessor = serviceOrderCreatedProcessor;
  }

  @Override
  public void configure() throws Exception {
    super.configure();
    from("direct:buyer-service-order-created").bean("buyerServiceOrderCreatedProcessor",
        "processEvent(${body})");

  }

}
