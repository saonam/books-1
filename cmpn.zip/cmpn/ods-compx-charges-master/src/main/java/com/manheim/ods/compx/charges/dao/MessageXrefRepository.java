package com.manheim.ods.compx.charges.dao;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository("messageXrefRepository")
public interface MessageXrefRepository extends JpaRepository<MessageXref, String> {

  @Query("SELECT mx FROM MessageXref mx WHERE mx.auctionCode= :auctionCode ")
  @Cacheable
  public MessageXref findMsgGroupIdByAuctionCode(@Param("auctionCode") String auctionCode);

}
