package com.manheim.ods.compx.charges.api.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class Seller {

  private Long dealerNumber;
  private String dealerName;
  private Long billToCustomerId;
}
