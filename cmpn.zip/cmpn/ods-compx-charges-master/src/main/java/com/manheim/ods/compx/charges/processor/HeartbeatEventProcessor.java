package com.manheim.ods.compx.charges.processor;

import java.sql.Timestamp;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.jms.JmsException;
import org.springframework.stereotype.Service;

import com.manheim.ods.compx.charges.client.ChargesAPIClient;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.charges.dao.InventoryItem;
import com.manheim.ods.compx.charges.dao.ServiceOrderRepository;
import com.manheim.ods.compx.charges.service.StagingService;
import com.manheim.ods.compx.charges.service.TriggerService;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

@Service
@RefreshScope
public class HeartbeatEventProcessor extends SellerChargesChangedEventProcessor {
  private StagingService stagingService;
  private TriggerService triggerService;
  private MetricReporter metricReporter;
  Logger logger = LoggerFactory.getLogger(this.getClass());
  private static final String AUCTION_CODE_LABEL = "auctionCode:";
  private static final String EVENT_TYPE_LABEL = "eventType:";
  private static final String VIN_LABEL = "vin:";

  public HeartbeatEventProcessor(ChargesAPIClient chargesAPIClient,
      ServiceOrderRepository soRepository, StagingService stagingService,
      @Value("${seller.auction.codes}") String[] auctions, TriggerService triggerService,
      MetricReporter metricReporter,
      @Value("${seller.ignore.auction.codes}") String[] ignoreAuctions) {
    super(chargesAPIClient, soRepository, stagingService, auctions, triggerService, metricReporter,
        ignoreAuctions);
    this.triggerService = triggerService;
    this.stagingService = stagingService;
    this.metricReporter = metricReporter;
  }

  @Override
  protected void process(AuctionEvent event) throws JAXBException, StageException {

    Timestamp apiTimestamp = null;
    InventoryItem ii = retrieveODSInventoryItem(event, "SL");
    if (null != ii) {
      // call Auction API
      callSellerAuctionChargesAPI(event, ii.getSblu());
      apiTimestamp = new Timestamp(System.currentTimeMillis());
    }
    // save staging
    ChargesProcessStatusLog processStatusLog =
        stagingService.saveHeartBeatMessage(event, apiTimestamp);


    Timestamp compxReqTimestamp = DateUtils.getCurrentSystemTimestamp();
    // send trigger message for ETL to process staging records
    try {
      triggerService.sendTriggerToQueue(event, compxReqTimestamp, processStatusLog);
    } catch (JAXBException | JmsException e) {
      String message = "Failed to build trigger event to ETL!!";
      logger.error(message, e);
      throw e;
    }


  }

  @Override
  public void recordEventProcessed(AuctionEvent auctionEvent) {
    metricReporter.incrementHeartbeatProcessed(EVENT_TYPE_LABEL + auctionEvent.getEventType(),
        VIN_LABEL + auctionEvent.getVin(), AUCTION_CODE_LABEL + auctionEvent.getAuctionCode());

  }


}
