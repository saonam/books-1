package com.manheim.ods.compx.charges.controller;

import java.util.Map;

import org.apache.camel.ProducerTemplate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.manheim.ods.compx.charges.util.ChargesAuctionEvent;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

@RequestMapping("/event")
@RestController
public class EventController {

  private MetricReporter metricReporter;
  private Logger log = LoggerFactory.getLogger(this.getClass().getName());

  private ProducerTemplate producerTemplate;

  @Autowired
  public EventController(MetricReporter metricReporter, ProducerTemplate producerTemplate) {
    this.metricReporter = metricReporter;
    this.producerTemplate = producerTemplate;
  }

  @RequestMapping(method = RequestMethod.POST)
  public ResponseEntity<HttpStatus> receiveEvent(@RequestBody ChargesAuctionEvent event,
      @RequestHeader(required = false) Map<String, String> eventHeaders) {


    long eventProcessStartTime = System.currentTimeMillis();
    String eventDetails = eventDetailsStringFormat(event);

    setMDCValuesForLogging(event);
    logCAISTransactionMarker(event, " Started");

    event.setHeartbeat(StringUtils
        .containsIgnoreCase(eventHeaders != null ? eventHeaders.get("source") : "", "heartbeat"));
    if (eventHeaders != null) {
      String retryCountHeader = eventHeaders.get("retrycount");
      int retryCount = retryCountHeader == null ? 0 : Integer.valueOf(retryCountHeader);
      event.setRetryCount(retryCount);
    }

    publishEventReceivedDetailsToMetricReporter(event, eventDetails);
    producerTemplate.sendBody("direct:postevent", event);
    publishEventProcessedDetailsToMetricReporter(event, eventDetails);

    recordExternalCallTime(eventProcessStartTime, "compx_process_event");
    logCAISTransactionMarker(event, " Completed");

    return new ResponseEntity<>(HttpStatus.OK);
  }

  private void publishEventReceivedDetailsToMetricReporter(ChargesAuctionEvent event,
      String eventDetails) {
    if (event.isHeartbeat()) {
      metricReporter.incrementHeartbeatReceived(eventDetails);
    } else {
      metricReporter.incrementEventReceived(eventDetails);
    }
  }

  private void publishEventProcessedDetailsToMetricReporter(ChargesAuctionEvent event,
      String eventDetails) {
    if (event.isHeartbeat()) {
      metricReporter.incrementHeartbeatProcessed(eventDetails);
    } else {
      metricReporter.incrementEventProcessed(eventDetails);
    }
  }

  private String eventDetailsStringFormat(ChargesAuctionEvent event) {
    return String.format("EventType: %s, Auction: %s", event.getEventType(),
        event.getAuctionCode());
  }


  private void setMDCValuesForLogging(AuctionEvent event) {
    MDC.clear();
    MDC.put("eventType", event.getEventType());
    MDC.put("auctionCode", event.getAuctionCode());
    if (null != event.getWorkOrder()) {
      MDC.put("workOrder", event.getWorkOrder());
    }
    if (null != event.getSblu()) {
      MDC.put("sblu", event.getSblu());
    }
    if (null != event.getSaleYear()) {
      MDC.put("saleYear", String.valueOf(event.getSaleYear()));
      MDC.put("saleNumber", String.valueOf(event.getSaleNumber()));
      MDC.put("laneNumber", String.valueOf(event.getLaneNumber()));
      MDC.put("runNumber", String.valueOf(event.getRunNumber()));
    }
  }

  private void logCAISTransactionMarker(AuctionEvent event, String status) {
    log.info(
        "time={} logtype=CAISTransactionMarker eventType={} auction={} sblu={} workorder={} system=ODS error=false status={}",
        DateUtils.getCurrentSystemTimestamp(), event.getEventType(), event.getAuctionCode(),
        event.getSblu(), event.getWorkOrder(), status + " Processing CompX Charges");
  }

  private void recordExternalCallTime(long eventProcessStartTime, String serviceName) {
    long timeTakenInMillis = System.currentTimeMillis() - eventProcessStartTime;
    metricReporter.recordExternalCallTime(timeTakenInMillis,
        String.format("service-name:%s", serviceName), "service-uri:/event", "http-method:POST",
        "http-status:200");
  }

}
