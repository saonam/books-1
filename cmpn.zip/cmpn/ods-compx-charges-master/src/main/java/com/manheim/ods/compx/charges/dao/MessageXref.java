package com.manheim.ods.compx.charges.dao;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name= "MESSAGE_XREF")

public class MessageXref implements Serializable{

	private static final long serialVersionUID = -6445862956408830926L;

	@Id
	@Column(name="MESSAGE_XREF_ID")
	private Long messageXrefId;
	
	@Column(name= "AUCTION_CODE")
	private String auctionCode;

	@Getter
	@Setter
	@Column(name= "MESSAGE_GROUP_ID")
	private String msgGroupId;
	
}
