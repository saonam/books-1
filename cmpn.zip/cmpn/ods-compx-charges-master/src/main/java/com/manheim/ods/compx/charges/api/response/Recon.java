package com.manheim.ods.compx.charges.api.response;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter

public class Recon {

	private Long workOrderNumber;
    private BigDecimal amount;
    private Integer recordNumber;
    private Integer subMenu;
    private Integer subclass;
    private String lcode;
    private String description;
    private String legacyReconDeductible;
    private String chargeReportingDate;
    private String sourceOfEDIInfo;
    private String sourceAuction;
}