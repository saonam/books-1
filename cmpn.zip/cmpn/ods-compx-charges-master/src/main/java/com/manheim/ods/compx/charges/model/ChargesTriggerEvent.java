package com.manheim.ods.compx.charges.model;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@XmlRootElement(name = "transactionId")
public class ChargesTriggerEvent {

  @XmlElement(name = "transactionId", required = true)
  public Long transactionId;
  @XmlElement(name = "eventType", required = true)
  public String eventType;
}
