package com.manheim.ods.compx.route;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.charges.processor.InventoryDeletedProcessor;

@Component
public class InventoryDeletedRouteBuilder extends ChargesRouteBuilder {

  @Autowired
  InventoryDeletedProcessor inventoryDeletedProcessor;

  public InventoryDeletedRouteBuilder(InventoryDeletedProcessor inventoryDeletedProcessor) {
    this.inventoryDeletedProcessor = inventoryDeletedProcessor;
  }

  @Override
  public void configure() throws Exception {
    super.configure();
    from("direct:inventory-deleted").bean("inventoryDeletedProcessor", "processEvent(${body})");

  }

}
