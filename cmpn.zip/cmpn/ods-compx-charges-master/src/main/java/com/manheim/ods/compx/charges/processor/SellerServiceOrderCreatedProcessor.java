package com.manheim.ods.compx.charges.processor;

import java.sql.Timestamp;

import javax.xml.bind.JAXBException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.jms.JmsException;
import org.springframework.stereotype.Service;

import com.manheim.ods.compx.charges.client.ChargesAPIClient;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.charges.dao.ServiceOrderRepository;
import com.manheim.ods.compx.charges.service.StagingService;
import com.manheim.ods.compx.charges.service.TriggerService;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

@Service
@RefreshScope
public class SellerServiceOrderCreatedProcessor extends SellerChargesChangedEventProcessor {
  private StagingService stagingService;
  private TriggerService triggerService;
  Logger logger = LoggerFactory.getLogger(this.getClass());

  public SellerServiceOrderCreatedProcessor(ChargesAPIClient chargesAPIClient,
      ServiceOrderRepository soRepository, StagingService stagingService,
      @Value(ALLOWED_AUCTIONS_PARAM) String[] auctions, TriggerService triggerService,
      MetricReporter metricReporter, @Value(IGNORED_AUCTIONS_PARAM) String[] ignoreAuctions) {
    super(chargesAPIClient, soRepository, stagingService, auctions, triggerService, metricReporter,
        ignoreAuctions);
    this.triggerService = triggerService;
    this.stagingService = stagingService;
  }

  @Override
  protected void process(AuctionEvent event) throws JAXBException, StageException {

    Timestamp compxReqTimestamp = new Timestamp(System.currentTimeMillis());

    // call Auction API
    String auctionChargesAPIResponse = callSellerAuctionChargesAPI(event, event.getSblu());

    // save staging
    ChargesProcessStatusLog processStatusLog =
        stagingService.save(event, auctionChargesAPIResponse, true, compxReqTimestamp);

    // send trigger message for ETL to process staging records
    try {
      triggerService.sendTriggerToQueue(event, compxReqTimestamp, processStatusLog);
    } catch (JAXBException | JmsException e) {
      String message = "Failed to build trigger event to ETL!!";
      logger.error(message, e);
      throw e;
    }
  }
}
