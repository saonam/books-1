package com.manheim.ods.compx.charges.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
@Table(name = "STG_FEES")
public class StgFees implements Serializable {

  private static final long serialVersionUID = 3767701309447132463L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_CHARGES_STAGING_ID")
  @SequenceGenerator(name = "SEQ_CHARGES_STAGING_ID", sequenceName = "SEQ_CHARGES_STAGING_ID")
  @Setter(AccessLevel.NONE)
  private Long stgFeesId;
  @Setter(AccessLevel.NONE)
  @Column(name = "TRANSACTION_ID")
  private Long transactionId;
  @Column(name = "AUCTION_CODE")
  private String auctionCode;
  @Column(name = "SBLU")
  private Long sblu;
  @Column(name = "AMOUNT")
  private BigDecimal amount;
  @Column(name = "KEY_TYPE")
  private String keyType;
  @Column(name = "KEY_VALUE")
  private String keyValue;
  @Column(name = "SOURCE_USER_NAME")
  private String sourceUserName;
  @Column(name = "CHARGE_MODIFIED_TIMESTAMP")
  private Timestamp chargeModifiedTimestamp;
  @Column(name = "PROCESS_FLAG")
  private String processFlag;
  @Column(name = "PROCESSED_TIMESTAMP")
  private Timestamp processedTimestamp;
  @Column(name = "CREATED_TIMESTAMP")
  private Timestamp createdTimestamp;

}
