package com.manheim.ods.compx.route;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.charges.processor.SellerServiceOrderCreatedProcessor;


@Component
public class SellerServiceOrderCreatedRouteBuilder extends ChargesRouteBuilder {

  @Autowired
  SellerServiceOrderCreatedProcessor serviceOrderCreatedProcessor;

  @Autowired
  public SellerServiceOrderCreatedRouteBuilder(
      SellerServiceOrderCreatedProcessor serviceOrderCreatedProcessor) {
    this.serviceOrderCreatedProcessor = serviceOrderCreatedProcessor;
  }

  @Override
  public void configure() throws Exception {
    super.configure();
    from("direct:seller-service-order-created").bean("sellerServiceOrderCreatedProcessor",
        "processEvent(${body})");

  }

}
