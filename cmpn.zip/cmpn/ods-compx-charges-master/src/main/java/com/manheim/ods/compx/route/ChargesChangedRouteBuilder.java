package com.manheim.ods.compx.route;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.charges.processor.BuyerChargesChangedEventProcessor;
import com.manheim.ods.compx.charges.processor.CbsBuyerChargesChangedEventProcessor;
import com.manheim.ods.compx.charges.processor.SellerChargesChangedEventProcessor;

@Component
public class ChargesChangedRouteBuilder extends ChargesRouteBuilder {

  private static final String PROCESS_EVENT_METHOD_CALL = "processEvent(${body})";

  @Autowired
  SellerChargesChangedEventProcessor sellerChargesChangedEventProcessor;

  @Autowired
  BuyerChargesChangedEventProcessor buyerChargesChangedEventProcessor;

  @Autowired
  CbsBuyerChargesChangedEventProcessor cbsBuyerChargesChangedEventProcessor;

  public ChargesChangedRouteBuilder(
      SellerChargesChangedEventProcessor sellerChargesChangedEventProcessor,
      BuyerChargesChangedEventProcessor buyerChargesChangedEventProcessor,
      CbsBuyerChargesChangedEventProcessor cbsBuyerChargesChangedEventProcessor) {
    this.sellerChargesChangedEventProcessor = sellerChargesChangedEventProcessor;
    this.buyerChargesChangedEventProcessor = buyerChargesChangedEventProcessor;
    this.cbsBuyerChargesChangedEventProcessor = cbsBuyerChargesChangedEventProcessor;

  }

  @Override
  public void configure() throws Exception {
    super.configure();
    from("direct:seller-charges-changed").bean("sellerChargesChangedEventProcessor",
        PROCESS_EVENT_METHOD_CALL);


    from("direct:buyer-charges-changed").choice().when()
        .simple("${body.sourceEventName} == 'CBS_BUYER_CHARGES_CHANGED'")
        .bean("cbsBuyerChargesChangedEventProcessor", PROCESS_EVENT_METHOD_CALL).otherwise()
        .to("direct:process-buyer-charges-changed");

    from("direct:process-buyer-charges-changed").bean("buyerChargesChangedEventProcessor",
        PROCESS_EVENT_METHOD_CALL);

  }
}
