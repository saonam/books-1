package com.manheim.ods.compx.charges.service;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.manheim.ods.compx.model.eventer.BaseEvent;
import com.manheim.ods.compx.setup.JsonBuilder;
import com.manheim.ods.compx.setup.QueueMessageBuilder;
import com.manheim.ods.compx.util.LogWrapper;

@Service
public class ChargesQueueMessageBuilder extends QueueMessageBuilder {

  static final String DQSWAT_TOOL = "DQSWAT-TOOL";
  static final String CHARGES = "CHARGES";

  @Autowired
  public ChargesQueueMessageBuilder(JsonBuilder jsonBuilder, LogWrapper logWrapper) {
    super(jsonBuilder, logWrapper);
  }

  @Override
  public String determineSourceCode(BaseEvent event, String sourceKey) {
    if (StringUtils.isNotEmpty(sourceKey)) {
      return sourceKey;
    } else {
      return StringUtils.isEmpty(event.getHref()) ? DQSWAT_TOOL : CHARGES;
    }
  }
}
