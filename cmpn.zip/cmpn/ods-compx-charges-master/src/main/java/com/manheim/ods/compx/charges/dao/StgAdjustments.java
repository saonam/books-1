package com.manheim.ods.compx.charges.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "STG_ADJUSTMENTS")
public class StgAdjustments implements Serializable {

  private static final long serialVersionUID = -6191399448246072806L;

  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_CHARGES_STAGING_ID")
  @SequenceGenerator(name = "SEQ_CHARGES_STAGING_ID", sequenceName = "SEQ_CHARGES_STAGING_ID")
  @Setter(AccessLevel.NONE)
  private Long stgAdjustmentsId;
  @Setter(AccessLevel.NONE)
  @Column(name = "TRANSACTION_ID")
  private Long transactionId;
  @Column(name = "AUCTION_CODE")
  private String auctionCode;
  @Column(name = "ADJUSTMENT_AMOUNT")
  private BigDecimal adjustmentAmount;
  @Column(name = "AR_RECORD_NUMBER")
  private Integer arRecordNumber;
  @Column(name = "ADJUSTMENT_CODE")
  private String adjustmentCode;
  @Column(name = "DESCRIPTION")
  private String description;
  @Column(name = "USER_DEFINED_DESCRIPTION")
  private String userDefinedDescription;
  @Column(name = "GL_ACCOUNT_NUMBER")
  private Integer glAccountNumber;
  @Column(name = "ADJUSTMENT_CREATED_BY")
  private String adjustmentCreatedBy;
  @Column(name = "ADJUSTMENT_CREATED_DATE")
  private Date adjustmentCreatedDate;
  @Column(name = "SALE_YEAR")
  private Integer saleYear;
  @Column(name = "SALE_NUMBER")
  private Integer saleNumber;
  @Column(name = "SALE_LANE")
  private Integer laneNumber;
  @Column(name = "SALE_RUN")
  private Integer runNumber;
  @Column(name = "PROCESS_FLAG")
  private String processFlag; // initial value: RD
  @Column(name = "LEGACY_ADJUSTMENT_CODE")
  private String legacyAdjustmentCode;
  @Column(name = "PROCESSED_TIMESTAMP")
  private Timestamp processedTimestamp;
  @Column(name = "CREATED_TIMESTAMP")
  private Timestamp createdTimestamp;

}
