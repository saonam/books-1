package com.manheim.ods.compx.charges.dao;

import java.text.ParseException;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.manheim.ods.compx.charges.api.response.Adjustment;
import com.manheim.ods.compx.charges.api.response.ChargesResponse;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@Component
public class StgAdjustmentsHelper {
  private static final String READY_FLAG = "RD";

  public Set<StgAdjustments> buildAdjustments(ChargesResponse chargesResponse, AuctionEvent event)
      throws ParseException {

    Set<StgAdjustments> stgAdjustments = new LinkedHashSet<>();

    List<Adjustment> adjustments = chargesResponse.getCharges().getAdjustments();
    for (Adjustment adjustment : adjustments) {
      StgAdjustments stgAdjustment = new StgAdjustments();
      stgAdjustment.setProcessFlag(READY_FLAG);
      stgAdjustment.setProcessedTimestamp(DateUtils.getCurrentSystemTimestamp());
      stgAdjustment.setCreatedTimestamp(DateUtils.getCurrentSystemTimestamp());
      stgAdjustment.setAuctionCode(event.getAuctionCode());
      stgAdjustment.setAdjustmentAmount(adjustment.getAmount());

      /**
       * Find if PSI exists. If yes, setup the adjustment code as 7DAY or 14DAY
       */
      stgAdjustment.setLegacyAdjustmentCode(adjustment.getAdjustmentCode());
      stgAdjustment.setAdjustmentCode(adjustment.getAdjustmentCode());
      if (adjustment.getAdjustmentCode().startsWith("PSI")) {
        handlePSI(adjustment, stgAdjustment);
      }
      stgAdjustment.setArRecordNumber(adjustment.getRecordNumber());
      stgAdjustment.setDescription(adjustment.getDescription());
      stgAdjustment.setUserDefinedDescription(adjustment.getUserDefinedDescription());
      stgAdjustment.setGlAccountNumber(adjustment.getGlAccountNumber());
      stgAdjustment.setAdjustmentCreatedBy(adjustment.getAdjustmentCreatedBy());
      stgAdjustment.setAdjustmentCreatedDate(
          DateUtils.toDate(adjustment.getChargeReportingDate(), "adjustmentCreatedDate"));
      if (null != chargesResponse.getOffering()
          && null != chargesResponse.getOffering().getSaleKey()) {
        stgAdjustment.setSaleYear(chargesResponse.getOffering().getSaleKey().getSaleYear());
        stgAdjustment.setSaleNumber(chargesResponse.getOffering().getSaleKey().getSaleNumber());
        stgAdjustment.setLaneNumber(chargesResponse.getOffering().getSaleKey().getLaneNumber());
        stgAdjustment.setRunNumber(chargesResponse.getOffering().getSaleKey().getRunNumber());
      }
      stgAdjustments.add(stgAdjustment);
    }
    return stgAdjustments;
  }

  private void handlePSI(Adjustment adjustment, StgAdjustments stgAdjustment) {

    AdjustmentCodeEnum adjustmentCodeEnum = new AdjustmentCodeUtil()
        .findAdjustmentCode(adjustment.getAdjustmentCode(), adjustment.getPsi14DayFlag());

    stgAdjustment.setAdjustmentCode(adjustmentCodeEnum.getValue());
  }

}
