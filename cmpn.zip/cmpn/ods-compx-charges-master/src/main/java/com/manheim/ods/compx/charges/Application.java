package com.manheim.ods.compx.charges;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.camel.CamelContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessorFactory;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.InitialPositionInStream;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;
import com.amazonaws.services.kinesis.metrics.interfaces.MetricsLevel;
import com.manheim.ods.compx.api.EventerAPI;
import com.manheim.ods.compx.api.MasheryAPI;
import com.manheim.ods.compx.charges.api.ChargesAPIConfiguration;
import com.manheim.ods.compx.setup.EventerManager;
import com.manheim.ods.compx.util.MessageGroupUtil;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.ods.stream.consumer.KinesisReceiver;
import com.manheim.ods.stream.consumer.KinesisWorkerFactory;
import com.manheim.ods.stream.consumer.WorkerAlreadyRunningException;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.jackson.JacksonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

@SpringBootApplication
@ComponentScan(
    basePackages = {"com.manheim.ods.compx.route", "com.manheim.ods.compx", "com.manheim.auction",
        "com.manheim.ods.stream"},
    excludeFilters = @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE,
        value = {EventerManager.class}))
@PropertySource(ignoreResourceNotFound = true, value = "classpath:buildInfo.properties")
public class Application {

  public static void main(String[] args) throws WorkerAlreadyRunningException {
    ConfigurableApplicationContext context = SpringApplication.run(Application.class, args);
    KinesisReceiver chargesReceiver = context.getBean(KinesisReceiver.class);
    chargesReceiver.start();
  }

  @Value("${auction.charges.api.host}")
  private String auctionChargesHost;

  @Value("${auction.charges.api.millisecond.timeout}")
  private long auctionChargesApiTimeout;

  @Value("${manheim.api}")
  private String manheimApi;

  @Value("${email.smtp.host}")
  private String mailHost;

  @Value("${email.smtp.port}")
  private int mailPort;

  @Value("${email.smtp.protocol}")
  private String protocol;

  @Value("${email.smtp.username}")
  private String username;

  @Value("${email.smtp.password}")
  private String password;

  @Value("${spring.activemq.broker-url}")
  private String activeMQUrl;

  @Value("${spring.activemq.cache-size}")
  private Integer activeMQCacheSize;

  @Value("${spring.activemq.password}")
  private String activeMQPassword;

  @Value("${spring.activemq.user}")
  private String activeMQUserName;
  @Autowired
  @Value("${spring.profiles.active}")
  String springProfile;

  @Value("${spring.application.name}")
  private String appName;

  @Value("${stream.name.prefix}")
  private String streamNamePrefix;
  @Value("${stream.receiver.max.records}")
  private int maxRecordsFromKinesisPerCall;
  @Value("${record.processor.threads}")
  private int recordProcessorThreadCount;

  @Autowired
  IRecordProcessorFactory chargesRecordProcessorFactory;

  @Autowired
  KinesisWorkerFactory chargesWorkerFactory;

  @Autowired
  CamelContext context;


  @Autowired
  MetricReporter metricReporter;


  // Initial position in the stream when the application starts up for the first time.
  // Position can be one of LATEST (most recent data) or TRIM_HORIZON (oldest available data)
  private static final InitialPositionInStream CHARGES_INITIAL_POSITION_IN_STREAM =
      InitialPositionInStream.LATEST;

  private static final int METRICS_BUFFER_TIME_MILLIS = 20000;

  private static final int METRICS_MAX_QUEUE_SIZE = 5000;


  Logger LOG = LoggerFactory.getLogger(Application.class);

  @Bean
  public MasheryAPI buildMasheryAPI() {
    Retrofit restAdapter = new Retrofit.Builder().baseUrl(manheimApi)
        .addConverterFactory(JacksonConverterFactory.create()).build();
    return restAdapter.create(MasheryAPI.class);
  }

  @Bean
  public EventerAPI buildEventerAPI() {
    Retrofit restAdapter = new Retrofit.Builder().baseUrl(manheimApi)
        .addConverterFactory(JacksonConverterFactory.create()).build();
    return restAdapter.create(EventerAPI.class);
  }

  @Bean
  public JavaMailSender javaMailSender() {
    JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
    mailSender.setHost(mailHost);
    mailSender.setPort(mailPort);
    mailSender.setProtocol(protocol);
    mailSender.setUsername(username);
    mailSender.setPassword(password);
    return mailSender;
  }

  @Bean
  public CommonsRequestLoggingFilter getCommonsRequest() {
    CommonsRequestLoggingFilter loggingFilter = new CommonsRequestLoggingFilter();
    loggingFilter.setIncludeQueryString(true);
    loggingFilter.setIncludePayload(true);
    return loggingFilter;
  }

  @Bean
  @Primary
  public ConnectionFactory getConnectionFactory() {
    ActiveMQConnectionFactory targetConnectionFactory = new ActiveMQConnectionFactory(activeMQUrl);
    targetConnectionFactory.setAlwaysSyncSend(true);
    targetConnectionFactory.setUserName(activeMQUserName);
    targetConnectionFactory.setPassword(activeMQPassword);
    CachingConnectionFactory cachingConnectionFactory =
        new CachingConnectionFactory(targetConnectionFactory);
    cachingConnectionFactory.setSessionCacheSize(activeMQCacheSize);
    return cachingConnectionFactory;
  }

  @Bean
  public ChargesAPIConfiguration buildChargesAPI() {
    OkHttpClient client = new OkHttpClient.Builder()
        .readTimeout(auctionChargesApiTimeout, TimeUnit.MILLISECONDS).build();
    Retrofit restAdapter = new Retrofit.Builder().client(client).baseUrl(auctionChargesHost)
        .addConverterFactory(ScalarsConverterFactory.create()).build();
    return restAdapter.create(ChargesAPIConfiguration.class);
  }

  @Bean
  public KinesisClientLibConfiguration configureKinesisClient() throws UnknownHostException {
    String workerId = "0";
    workerId = InetAddress.getLocalHost().getCanonicalHostName() + ":" + UUID.randomUUID();
    String streamName = String.format("%s-%s", streamNamePrefix, springProfile);
    String appEnvName = String.format("%s-%s", appName, springProfile);
    KinesisClientLibConfiguration kinesisClientLibConfiguration =
        new KinesisClientLibConfiguration(appEnvName, streamName, buildAWSCredentialsProvider(),
            workerId).withInitialPositionInStream(CHARGES_INITIAL_POSITION_IN_STREAM)
                .withMaxRecords(maxRecordsFromKinesisPerCall)
                .withMetricsBufferTimeMillis(METRICS_BUFFER_TIME_MILLIS)
                .withMetricsLevel(MetricsLevel.SUMMARY)
                .withMetricsMaxQueueSize(METRICS_MAX_QUEUE_SIZE);
    LOG.info("Kinesis Client - appEnvName:{}, streamName:{}, workerId:{}", appEnvName, streamName,
        workerId);
    return kinesisClientLibConfiguration;
  }

  @Bean
  public Worker buildWorker() throws UnknownHostException {
    return new Worker(chargesRecordProcessorFactory, configureKinesisClient());
  }

  private AWSCredentialsProvider buildAWSCredentialsProvider() {
    // Ensure the JVM will refresh the cached IP values of AWS resources (e.g. service endpoints).
    java.security.Security.setProperty("networkaddress.cache.ttl", "60");

    /*
     * The ProfileCredentialsProvider will return your [default] credential profile by reading from
     * the credentials file located at (~/.aws/credentials).
     */
    AWSCredentialsProvider credentialsProvider = new DefaultAWSCredentialsProviderChain();
    try {
      credentialsProvider.getCredentials();
    } catch (Exception e) {

      throw new AmazonClientException("Error connecting to Kinesis", e);
    }
    return credentialsProvider;
  }

  @Bean
  public MessageGroupUtil buildMessageGroupUtil() {
    return new MessageGroupUtil(recordProcessorThreadCount);
  }



}
