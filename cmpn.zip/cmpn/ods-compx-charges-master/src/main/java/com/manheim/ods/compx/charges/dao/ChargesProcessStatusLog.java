package com.manheim.ods.compx.charges.dao;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Table(name = "CHARGES_PROCESS_STATUS_LOG")
public class ChargesProcessStatusLog implements Serializable {

  private static final long serialVersionUID = 5456214526297210897L;
  @Id
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SEQ_TRANSACTION_CHARGES")
  @SequenceGenerator(name = "SEQ_TRANSACTION_CHARGES", sequenceName = "SEQ_TRANSACTION_CHARGES")
  @Getter
  private Long transactionId;
  @Column(name = "STATUS")
  private String status;
  @Column(name = "TRANSACTION_LOG_MSG")
  private String transactionLogMessage;
  @Column(name = "EVENT_TYPE")
  @Getter
  private String eventType;
  @Column(name = "SCODE")
  private String scode;
  @Getter
  @Column(name = "AUCTION_CODE")
  private String auction;
  @Getter
  @Column(name = "SBLU")
  private Long sblu;
  @Getter
  @Column(name = "WORK_ORDER_NUMBER")
  private Long workOrder;
  @Getter
  @Column(name = "VIN")
  private String vin;
  @Getter
  @Column(name = "DEALER_NUMBER")
  private String dealerNumber;
  @Getter
  @Column(name = "TRANSFER_IND")
  private String transferIndicator;
  @Column(name = "SOURCE_SYSTEM_NAME")
  private String sourceSystemName;
  @Getter
  @Column(name = "PROCESS_FLAG")
  private String processFlag;
  @Column(name = "TBOX_TIMESTAMP")
  private Timestamp tBoxTimestamp;
  @Column(name = "CDC_TIMESTAMP")
  private Timestamp cdcTimestamp;
  @Column(name = "API_TIMESTAMP")
  private Timestamp apiTimestamp;
  @Column(name = "COMPX_TIMESTAMP")
  private Timestamp compxTimestamp;
  @Column(name = "CREATED_TIMESTAMP")
  private Timestamp createdTimestamp;
  @Column(name = "UPDATED_TIMESTAMP")
  private Timestamp updatedTimestamp;
  @Column(name = "PROCESSED_TIMESTAMP")
  private Timestamp processedTimestamp;
  @Column(name = "SOURCE_TABLE")
  private String sourceTable;
  @Getter
  @Column(name = "MESSAGE_GROUP_ID")
  private String messageGroupId;
  @Getter
  @Column(name = "CHECK_RECONS")
  private String checkRecons;
  @Getter
  @Column(name = "CHECK_FEES")
  private String checkFees;
  @Getter
  @Column(name = "CHECK_ADJUSTMENTS")
  private String checkAdjustments;
  @Getter
  @Column(name = "DEALER_TYPE")
  private String dealerType;
  @Column(name = "CHANGE_CODE")
  private String changeCode;
  @Column(name = "ERROR_CD")
  private String errorCode;
  @Column(name = "UPDATED_BY")
  private String updatedBy;
  @Column(name = "JSON_MESSAGE", columnDefinition = "CLOB")
  private String jsonResponse;
  @Column(name = "HEARTBEAT_UNIQUE_ID")
  private String heartbeatUniqueId;
  @Column(name = "COMMENTS")
  private String comments;
  @Column(name = "PREV_SELLER_DEALER_NUMBER")
  private String prevSellerDealerNumber;
  @Column(name = "PREV_BUYER_DEALER_NUMBER")
  private String prevBuyerDealerNumber;
  @Column(name = "CDC_USER_ID")
  private String cdcUserId;
  @Column(name = "RETRY_COUNT")
  private Integer retryCount;
  @Getter
  @Column(name = "IFSALE_IND")
  private String ifSaleInd;



  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "TRANSACTION_ID")
  @Getter
  private Set<StgChargesHeader> chargesHeader;

  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "TRANSACTION_ID")
  @Getter
  private Set<StgRecon> recon;

  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "TRANSACTION_ID")
  @Getter
  private Set<StgFees> fees;

  @OneToMany(cascade = CascadeType.ALL)
  @JoinColumn(name = "TRANSACTION_ID")
  @Getter
  private Set<StgAdjustments> adjustments;
  @Column(name = "SOURCE_EVENT_TYPE")
  private String sourceEventType;


}
