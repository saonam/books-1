package com.manheim.ods.compx.charges.api.response;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class Adjustment {

  private BigDecimal amount;
  private Integer recordNumber;
  private String adjustmentCode;
  private String description;
  private String userDefinedDescription;
  private Integer glAccountNumber;
  private String adjustmentCreatedBy;
  private String chargeReportingDate;
  private String psi14DayFlag;

}
