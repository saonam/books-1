package com.manheim.ods.compx.charges.service;

import java.io.StringWriter;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessagePostProcessor;
import org.springframework.stereotype.Service;

import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.charges.model.ChargesTriggerEvent;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;

@Service
@RefreshScope
public class TriggerService {

  static final String APPLICATION_NAME = "compxcharges";
  private ChargesQueueMessageBuilder queueMessageBuilder;
  private String destinationQueueName;
  private JmsTemplate jmsTemplate;
  private LogWrapper logWrapper;

  @Autowired
  public TriggerService(ChargesQueueMessageBuilder chargesQueueMessageBuilder,
      @Value("${activemq.queue.name}") String destinationQueueName, LogWrapper logWrapper,
      JmsTemplate jmsTemplate) {

    this.logWrapper = logWrapper;
    this.queueMessageBuilder = chargesQueueMessageBuilder;
    this.destinationQueueName = destinationQueueName;
    this.jmsTemplate = jmsTemplate;
  }

  public boolean sendTriggerToQueue(AuctionEvent event, Timestamp apiRequestTimestamp,
      ChargesProcessStatusLog cpStatusLog) throws JAXBException {
    Timestamp apiResponseTimestamp = new Timestamp(System.currentTimeMillis());

    String queueMessage = buildChargesQueueMessage(cpStatusLog);
    Map<String, String> eventHeaders = new HashMap<>();
    String messageGroupId;
    if (cpStatusLog.getSblu() != null) {
      messageGroupId = String.format("%s:%d", cpStatusLog.getAuction(), cpStatusLog.getSblu());
    } else {
      messageGroupId = String.format("%s:%s", cpStatusLog.getAuction(), event.getWorkOrder());
    }
    eventHeaders.put("JMSXGroupID", messageGroupId);
    eventHeaders.put("source", APPLICATION_NAME);
    MessagePostProcessor messageProperties = queueMessageBuilder.messageProperties(
        event.getAuctionCode(), event, eventHeaders, apiRequestTimestamp, apiResponseTimestamp);

    jmsTemplate.convertAndSend(destinationQueueName, queueMessage, messageProperties);
    logWrapper.info(TriggerService.class,
        String.format("Successfully published message to queue. Queue name: %s. Message: %s",
            destinationQueueName, queueMessage));
    return true;
  }

  private String buildChargesQueueMessage(ChargesProcessStatusLog cpStatusLog)
      throws JAXBException {
    ChargesTriggerEvent chargesTriggerEvent =
        new ChargesTriggerEvent(cpStatusLog.getTransactionId(), cpStatusLog.getEventType());
    JAXBContext jaxbContext;
    StringWriter stringWriter = new StringWriter();
    jaxbContext = JAXBContext.newInstance(ChargesTriggerEvent.class);
    Marshaller marshaller = jaxbContext.createMarshaller();
    marshaller.marshal(chargesTriggerEvent, stringWriter);
    return stringWriter.toString();
  }
}
