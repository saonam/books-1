package com.manheim.ods.compx.charges.service;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.time.format.DateTimeParseException;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.math.NumberUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.charges.api.response.ChargesResponse;
import com.manheim.ods.compx.charges.api.response.Fee;
import com.manheim.ods.compx.charges.api.response.Payment;
import com.manheim.ods.compx.charges.api.response.PaymentMethodBuilder;
import com.manheim.ods.compx.charges.api.response.Recon;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLog;
import com.manheim.ods.compx.charges.dao.ChargesProcessStatusLogRepository;
import com.manheim.ods.compx.charges.dao.StgAdjustmentsHelper;
import com.manheim.ods.compx.charges.dao.StgChargesHeader;
import com.manheim.ods.compx.charges.dao.StgFees;
import com.manheim.ods.compx.charges.dao.StgRecon;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@Service
public class StagingService {

  private final Logger log = LoggerFactory.getLogger(this.getClass().getName());

  private static final String YES_FLAG = "Y";
  private static final String NO_FLAG = "N";

  private static final String DEFAULT = "DEFAULT";
  private static final String BUYER = "BUYER";
  private static final String INVALID_API_RESPONSE_MSG = "Charges API returned an invalid response";
  private static final String SO_NOT_FOUND_MSG =
      "Service Order not created in ODS. Awaiting BEE SO Created Event.";
  private static final String DATE_PARSE_ERROR = "Unable to parse date field: ";
  private static final String STAGING_SUCCEEDED = "Staging Succeeded";
  private static final String STAGING_FAILED = "Staging Failed";
  private static final String STAGING_SO_NOT_FOUND = "Awaiting SO Creation";
  private static final String AUCTION_CHARGES = "AUCTION_CHARGES";
  private static final String READY_FLAG = "RD";
  private static final String FAILED_FLAG = "FL";
  private static final String HOLD_FLAG = "HD";


  @Autowired
  private ChargesProcessStatusLogRepository chargesProcessStatusLogRepository;

  @Autowired
  private StgAdjustmentsHelper stgAdjustmentsHelper;

  @Autowired
  public StagingService(ChargesProcessStatusLogRepository chargesProcessStatusLogRepository,
      StgAdjustmentsHelper stgAdjustmentsHelper) {
    this.chargesProcessStatusLogRepository = chargesProcessStatusLogRepository;
    this.stgAdjustmentsHelper = stgAdjustmentsHelper;
  }

  public ChargesProcessStatusLog save(AuctionEvent event, String apiResponse, boolean soExists,
      Timestamp compxReqTimestamp) throws StageException {
    ChargesProcessStatusLog cpStatusLog = new ChargesProcessStatusLog();
    buildChargesProcessStatusLog(event, apiResponse, cpStatusLog, soExists, compxReqTimestamp);
    setDefaultValuesBeforeSave(cpStatusLog, event);
    log.info("Stage charges for event: {}", event);
    chargesProcessStatusLogRepository.save(cpStatusLog);
    log.info("Charges staged successfully - transactionid: {}", cpStatusLog.getTransactionId());
    return cpStatusLog;
  }

  public ChargesProcessStatusLog saveApiError(AuctionEvent event, Exception ex, int responseCode)
      throws StageException {

    ChargesProcessStatusLog cpStatusLog = new ChargesProcessStatusLog();

    cpStatusLog.setStatus("ERROR");
    cpStatusLog.setProcessFlag(FAILED_FLAG);
    cpStatusLog.setTransactionLogMessage(ex.getMessage());
    setValuesFromTboxEvent(event, cpStatusLog);
    cpStatusLog.setCompxTimestamp(DateUtils.getCurrentSystemTimestamp());
    cpStatusLog.setErrorCode(String.valueOf(responseCode));
    setDefaultValuesBeforeSave(cpStatusLog, event);
    chargesProcessStatusLogRepository.save(cpStatusLog);
    log.info("Saved Compx Charges Api error {} - {}", ex.getMessage(), event);
    return cpStatusLog;
  }

  public ChargesProcessStatusLog saveStageError(AuctionEvent event, Exception ex) {

    ChargesProcessStatusLog cpStatusLog = new ChargesProcessStatusLog();

    cpStatusLog.setStatus("ERROR");
    cpStatusLog.setProcessFlag(FAILED_FLAG);
    cpStatusLog.setTransactionLogMessage(ex.getMessage());
    setValuesFromTboxEvent(event, cpStatusLog);
    cpStatusLog.setCompxTimestamp(DateUtils.getCurrentSystemTimestamp());
    setDefaultValuesBeforeSave(cpStatusLog, event);
    chargesProcessStatusLogRepository.save(cpStatusLog);
    log.info("Saved Compx Charges Stage error {} - {}", ex.getMessage(), event);
    return cpStatusLog;
  }

  public ChargesProcessStatusLog saveHeartBeatMessage(AuctionEvent event, Timestamp apiReqTimestamp)
      throws StageException {

    ChargesProcessStatusLog cpStatusLog = new ChargesProcessStatusLog();

    setValuesFromTboxEvent(event, cpStatusLog);

    cpStatusLog.setProcessFlag(READY_FLAG);
    cpStatusLog.setStatus(STAGING_SUCCEEDED);

    cpStatusLog.setAuction(getAuctionCode(event.getAuctionid()));
    cpStatusLog.setWorkOrder(Long.valueOf(event.getHeartbeatseqno()));
    cpStatusLog.setCompxTimestamp(DateUtils.getCurrentSystemTimestamp());
    cpStatusLog.setApiTimestamp(apiReqTimestamp);
    cpStatusLog.setJsonResponse(event.getJsonMessage());
    cpStatusLog.setHeartbeatUniqueId(event.getAuctionuniqueid());

    log.debug("Heartbeat - {}", cpStatusLog);

    setDefaultValuesBeforeSave(cpStatusLog, event);

    ChargesProcessStatusLog savedCPStatusLog = chargesProcessStatusLogRepository.save(cpStatusLog);
    log.info("Heartbeat saved successfully - {}", savedCPStatusLog);

    return savedCPStatusLog;
  }

  private void buildChargesProcessStatusLog(AuctionEvent event, String apiResponse,
      ChargesProcessStatusLog cpStatusLog, boolean soExists, Timestamp compxReqTimestamp)
      throws StageException {

    setValuesFromTboxEvent(event, cpStatusLog);

    cpStatusLog.setDealerType(determineSellerOrBuyer(event));
    cpStatusLog.setCompxTimestamp(compxReqTimestamp);
    if (!soExists) {
      cpStatusLog.setProcessFlag(HOLD_FLAG);
      cpStatusLog.setStatus(STAGING_SO_NOT_FOUND);
      cpStatusLog.setTransactionLogMessage(SO_NOT_FOUND_MSG);
    } else {

      if (apiResponse != null) {
        setStatusLogFromChargesResponse(event, apiResponse, cpStatusLog);
      }
      cpStatusLog.setProcessFlag(READY_FLAG);
      cpStatusLog.setStatus(STAGING_SUCCEEDED);
    }

    cpStatusLog.setRetryCount(event.getRetryCount());
  }

  private void setStatusLogFromChargesResponse(AuctionEvent event, String apiResponse,
      ChargesProcessStatusLog cpStatusLog) throws StageException {
    ChargesResponse chargesResponse;
    ObjectMapper mapper = new ObjectMapper();
    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    try {
      chargesResponse = mapper.readValue(apiResponse, ChargesResponse.class);
    } catch (IOException ie) {
      log.error(INVALID_API_RESPONSE_MSG, ie);
      cpStatusLog.setProcessFlag(FAILED_FLAG);
      cpStatusLog.setStatus(STAGING_FAILED);
      cpStatusLog.setTransactionLogMessage(INVALID_API_RESPONSE_MSG);
      throw new StageException(INVALID_API_RESPONSE_MSG);
    }

    cpStatusLog.setScode(chargesResponse.getSaleStatus());

    Long sblu = null;
    if (null != chargesResponse.getConsignment()) {
      sblu = chargesResponse.getConsignment().getSblu();
      cpStatusLog.setSblu(sblu);
      cpStatusLog.setWorkOrder(chargesResponse.getConsignment().getWorkOrderNumber());
      cpStatusLog.setDealerNumber(deduceDealerNumber(event, chargesResponse));
      if (null != chargesResponse.getConsignment().getUnit()) {
        cpStatusLog.setVin(chargesResponse.getConsignment().getUnit().getVin());
      }
    }

    cpStatusLog.setTransferIndicator(chargesResponse.isVehicleTransfered() ? YES_FLAG : NO_FLAG);

    cpStatusLog.setJsonResponse(apiResponse);
    if(chargesResponse.getOffering()!=null) {
      /*
       * Set the if sale flag indicator
       */
      cpStatusLog.setIfSaleInd(chargesResponse.getOffering().getIfSaleFlag());

    }
    try {
      cpStatusLog.setApiTimestamp(
          DateUtils.toTimestampWithMsPrecision(chargesResponse.getRequestTimestamp()));
      Set<StgChargesHeader> chargesHeader = buildChargesHeader(chargesResponse, event);
      cpStatusLog.setChargesHeader(chargesHeader);

      if (null != chargesResponse.getCharges()) {
        buildChildRecords(event, cpStatusLog, chargesResponse, sblu);
      } else if (null == chargesResponse.getPayment()) {
        // if there are no charges, payments then set all check child record flags to N
        cpStatusLog.setCheckRecons(NO_FLAG);
        cpStatusLog.setCheckFees(NO_FLAG);
        cpStatusLog.setCheckAdjustments(NO_FLAG);
      }
    } catch (ParseException e) {
      log.error(DATE_PARSE_ERROR, e);
      cpStatusLog.setTransactionLogMessage(DATE_PARSE_ERROR + e.getMessage());
      cpStatusLog.setProcessFlag(FAILED_FLAG);
      cpStatusLog.setStatus(STAGING_FAILED);
      throw new StageException(DATE_PARSE_ERROR + e.getMessage());
    }
  }

  private void buildChildRecords(AuctionEvent event, ChargesProcessStatusLog cpStatusLog,
      ChargesResponse chargesResponse, Long sblu) throws ParseException {
    if (null != chargesResponse.getCharges().getDealerFees()
        || null != chargesResponse.getCharges().getTaxes()) {
      cpStatusLog.setFees(buildFees(chargesResponse, event, sblu));
      cpStatusLog.setCheckFees(YES_FLAG);
    } else {
      cpStatusLog.setCheckFees(NO_FLAG);
    }

    if (null != chargesResponse.getCharges().getReconFees()) {
      cpStatusLog.setRecon(buildRecon(chargesResponse, event));
      cpStatusLog.setCheckRecons(YES_FLAG);
    } else {
      cpStatusLog.setCheckRecons(NO_FLAG);
    }
    if (null != chargesResponse.getCharges().getAdjustments()) {
      cpStatusLog.setAdjustments(stgAdjustmentsHelper.buildAdjustments(chargesResponse, event));
      cpStatusLog.setCheckAdjustments(YES_FLAG);
    } else {
      cpStatusLog.setCheckAdjustments(NO_FLAG);
    }
  }

  private String deduceDealerNumber(AuctionEvent event, ChargesResponse chargesResponse) {
    String dealerNumber = null;
    if (event.getEventType().startsWith("BUYER")) {
      if (null != chargesResponse.getBuyer()) {
        dealerNumber = String.valueOf(chargesResponse.getBuyer().getDealerNumber());
      }
    } else {
      if (null != chargesResponse.getConsignment().getSeller()) {
        dealerNumber =
            String.valueOf(chargesResponse.getConsignment().getSeller().getDealerNumber());
      }
    }
    return dealerNumber;
  }

  private Set<StgChargesHeader> buildChargesHeader(ChargesResponse chargesResponse,
      AuctionEvent event) throws ParseException {

    StgChargesHeader chargesHeader = new StgChargesHeader();

    chargesHeader.setCreatedTimestamp(DateUtils.getCurrentSystemTimestamp());
    chargesHeader.setProcessedTimestamp(DateUtils.getCurrentSystemTimestamp());
    chargesHeader.setProcessFlag(READY_FLAG);
    setPaymentInHeader(chargesResponse, chargesHeader);
    chargesHeader.setInvoiceDate(DateUtils.toDate(chargesResponse.getInvoiceDate(), "invoiceDate"));
    chargesHeader.setInvoiceNumber(chargesResponse.getInvoiceNumber());
    chargesHeader.setArbitrationDispositionCode(chargesResponse.getArbitrationDispositionCode());
    chargesHeader.setArbitrationDate(
        DateUtils.toDate(chargesResponse.getArbitrationDate(), "arbitrationDate"));
    if (null != chargesResponse.getOffering()) {
      chargesHeader.setRegistrationDate(DateUtils
          .toDate(chargesResponse.getOffering().getRegistrationDate(), "registrationDate"));
      chargesHeader
          .setSaleDate(DateUtils.toDate(chargesResponse.getOffering().getSaleDate(), "saleDate"));
      chargesHeader.setSalePrice(chargesResponse.getOffering().getSalePrice());
      if (chargesResponse.getOffering().getSaleTime() != null) {
        chargesHeader.setSaleTime(String.valueOf(chargesResponse.getOffering().getSaleTime()));
      }
      /*
       * Set the if sale flag indicator
       */
      

      if (null != chargesResponse.getOffering().getSaleKey()) {
        chargesHeader.setSaleYear(chargesResponse.getOffering().getSaleKey().getSaleYear());
        chargesHeader.setSaleNumber(chargesResponse.getOffering().getSaleKey().getSaleNumber());
        chargesHeader.setSaleLane(chargesResponse.getOffering().getSaleKey().getLaneNumber());
        chargesHeader.setSaleRun(chargesResponse.getOffering().getSaleKey().getRunNumber());
      }
    }
    setConsignmentInHeader(chargesResponse, chargesHeader);
    if (null != chargesResponse.getBuyer()) {
      chargesHeader.setBuyerDealerNumber(chargesResponse.getBuyer().getDealerNumber());
      chargesHeader.setBuyerDealerName(chargesResponse.getBuyer().getDealerName());
    }
    if (null != event.getPrevBuyerDealerId()) {
      chargesHeader.setPrevBuyerDealerNumber(Long.valueOf(event.getPrevBuyerDealerId()));
    }
    if (null != event.getPrevSellerDealerId()) {
      chargesHeader.setPrevSellerDealerNumber(Long.valueOf(event.getPrevSellerDealerId()));
    }

    Set<StgChargesHeader> chargesHeaderSet = new HashSet<>();
    chargesHeaderSet.add(chargesHeader);
    return chargesHeaderSet;
  }

  private Set<StgFees> buildFees(ChargesResponse chargesResponse, AuctionEvent event, Long sblu)
      throws ParseException {
    Set<StgFees> stgFees = new LinkedHashSet<>();

    List<Fee> fees = chargesResponse.getCharges().getDealerFees();
    List<Fee> taxes = chargesResponse.getCharges().getTaxes();


    if (null != fees) {

      if (null != taxes) {
        fees.addAll(taxes);
      }

      for (Fee fee : fees) {
        StgFees stgFee = new StgFees();
        stgFee.setAuctionCode(event.getAuctionCode());
        stgFee.setSblu(sblu);
        stgFee.setAmount(fee.getAmount());
        stgFee.setKeyType(fee.getKeyType());
        stgFee.setKeyValue(fee.getKeyValue());
        stgFee.setSourceUserName(event.getCdcUserId());
        stgFee.setProcessedTimestamp(DateUtils.getCurrentSystemTimestamp());
        stgFee.setChargeModifiedTimestamp(DateUtils.toTimestamp(event.getCdcjournaltimestamp()));
        stgFee.setCreatedTimestamp(DateUtils.getCurrentSystemTimestamp());
        stgFee.setProcessFlag(READY_FLAG);
        stgFees.add(stgFee);
      }
      // payments
      Payment payment = chargesResponse.getPayment();
      if (null != payment) {
        StgFees stgFee = new StgFees();
        stgFee.setAuctionCode(event.getAuctionCode());
        stgFee.setSblu(sblu);
        stgFee.setAmount(payment.getPaidAmount());
        stgFee.setKeyType("PAYMENT");
        String paidDate = payment.getPaidDate();
        String paidMethod = payment.getPaidMethod();
        String paymentType = payment.getPaymentType();

        String paymentMethod = new PaymentMethodBuilder().build(paidMethod, paymentType, paidDate);

        stgFee.setKeyValue(paymentMethod);
        stgFee.setSourceUserName(event.getCdcUserId());
        stgFee.setProcessedTimestamp(DateUtils.getCurrentSystemTimestamp());
        stgFee.setChargeModifiedTimestamp(DateUtils.toTimestamp(event.getCdcjournaltimestamp()));
        stgFee.setCreatedTimestamp(DateUtils.getCurrentSystemTimestamp());
        stgFee.setProcessFlag(READY_FLAG);
        stgFees.add(stgFee);
      }
    }
    return stgFees;
  }

  private Set<StgRecon> buildRecon(ChargesResponse chargesResponse, AuctionEvent event) {

    Set<StgRecon> stgRecons = new LinkedHashSet<>();

    List<Recon> reconFees = chargesResponse.getCharges().getReconFees();
    for (Recon reconFee : reconFees) {
      StgRecon stgRecon = new StgRecon();
      stgRecon.setWorkOrderNumber(reconFee.getWorkOrderNumber());
      stgRecon.setAuctionCode(event.getAuctionCode());
      stgRecon.setRecordNumber(reconFee.getRecordNumber());
      stgRecon.setSubMenu(reconFee.getSubMenu());
      stgRecon.setAmount(reconFee.getAmount());
      stgRecon.setSubclass(reconFee.getSubclass());
      stgRecon.setLCode(reconFee.getLcode());
      stgRecon.setDescription(reconFee.getDescription());
      stgRecon.setLegacyReconDeductible(reconFee.getLegacyReconDeductible());
      stgRecon.setSourceUserName(event.getCdcUserId());
      try {
        stgRecon.setDateEntered(
            DateUtils.toTimestampWithMsPrecision(reconFee.getChargeReportingDate()));
      } catch (DateTimeParseException e) {
        log.error("Unable to parse date field: chargeReportingDate", e);
      }
      stgRecon.setOriginationSource(reconFee.getSourceAuction());
      stgRecon.setSourceOfEDIInfo(reconFee.getSourceOfEDIInfo());
      stgRecon.setProcessFlag(READY_FLAG);
      stgRecon.setProcessedTimestamp(DateUtils.getCurrentSystemTimestamp());
      stgRecon.setCreatedTimestamp(DateUtils.getCurrentSystemTimestamp());
      stgRecons.add(stgRecon);
    }
    return stgRecons;
  }

  private String determineSellerOrBuyer(AuctionEvent event) {
    return event.getEventType().startsWith(BUYER) ? BUYER : "SELLER";
  }

  private void setPaymentInHeader(ChargesResponse chargesResponse, StgChargesHeader chargesHeader)
      throws ParseException {
    Payment payment = chargesResponse.getPayment();
    if (null != payment) {
      chargesHeader.setPaidDate(DateUtils.toDate(payment.getPaidDate(), "paidDate"));
      chargesHeader.setSellerCheckClearedDate(
          DateUtils.toDate(payment.getSellerCheckClearedDate(), "sellerCheckClearedDate"));
      chargesHeader.setSellerCheckStopPayDate(
          DateUtils.toDate(payment.getSellerCheckStopPayDate(), "sellerCheckStopPayDate"));
      chargesHeader.setSellerCheckVoidDate(
          DateUtils.toDate(payment.getSellerCheckVoidDate(), "sellerCheckVoidDate"));
      chargesHeader.setSellerCheckPrintIndicator(payment.getSellerCheckPrintedIndicator());
      if (payment.getFloorPlanAgencyCode() != null) {
        chargesHeader.setFloorPlanAgencyCode(String.valueOf(payment.getFloorPlanAgencyCode()));
      }
    }
  }

  private void setConsignmentInHeader(ChargesResponse chargesResponse,
      StgChargesHeader chargesHeader) throws ParseException {
    if (null != chargesResponse.getConsignment()) {

      chargesHeader.setSblu(chargesResponse.getConsignment().getSblu());
      chargesHeader.setWorkOrder(chargesResponse.getConsignment().getWorkOrderNumber());
      chargesHeader.setReceivedDate(
          DateUtils.toDate(chargesResponse.getConsignment().getReceivedDate(), "receivedDate"));
      chargesHeader.setRedeemedDate(
          DateUtils.toDate(chargesResponse.getConsignment().getRedeemedDate(), "redeemedDate"));
      if (null != chargesResponse.getConsignment().getOperatingLocation()) {
        chargesHeader.setAuctionCode(
            chargesResponse.getConsignment().getOperatingLocation().getLocationCode());
      }
      if (null != chargesResponse.getConsignment().getUnit()) {
        chargesHeader.setVin(chargesResponse.getConsignment().getUnit().getVin());
        chargesHeader.setGroupCode(chargesResponse.getConsignment().getUnit().getGroupCode());
      }
      if (null != chargesResponse.getConsignment().getSeller()) {
        chargesHeader
            .setSellerDealerNumber(chargesResponse.getConsignment().getSeller().getDealerNumber());
        chargesHeader
            .setSellerDealerName(chargesResponse.getConsignment().getSeller().getDealerName());
        chargesHeader.setBillToCustomerId(
            chargesResponse.getConsignment().getSeller().getBillToCustomerId());
      }
    }
  }


  private void setDefaultValuesBeforeSave(ChargesProcessStatusLog cpStatusLog, AuctionEvent event) {

    Long sblu = cpStatusLog.getSblu();
    Long workOrder = cpStatusLog.getWorkOrder();
    String vin = cpStatusLog.getVin();
    String dealerNumber = cpStatusLog.getDealerNumber();
    String checkRecons = cpStatusLog.getCheckRecons();
    String checkFees = cpStatusLog.getCheckFees();
    String checkAdjs = cpStatusLog.getCheckAdjustments();
    String transferIndicator = cpStatusLog.getTransferIndicator();
    String processFlag = cpStatusLog.getProcessFlag();
    String dealerType = cpStatusLog.getDealerType();
    setNegativeOnesAsDefaultsForETL(cpStatusLog, sblu, workOrder, vin, dealerNumber);

    cpStatusLog.setCheckRecons(null == checkRecons ? YES_FLAG : checkRecons);
    cpStatusLog.setCheckFees(null == checkFees ? YES_FLAG : checkFees);
    cpStatusLog.setCheckAdjustments(null == checkAdjs ? YES_FLAG : checkAdjs);
    cpStatusLog.setTransferIndicator(null == transferIndicator ? NO_FLAG : transferIndicator);
    cpStatusLog.setProcessFlag(null == processFlag ? READY_FLAG : processFlag);
    cpStatusLog.setDealerType(null == dealerType ? DEFAULT : dealerType);
    cpStatusLog.setProcessedTimestamp(DateUtils.getCurrentSystemTimestamp());
    cpStatusLog.setCreatedTimestamp(DateUtils.getCurrentSystemTimestamp());
    cpStatusLog.setUpdatedTimestamp(DateUtils.getCurrentSystemTimestamp());
    cpStatusLog.setUpdatedBy("COMPX");
    cpStatusLog.setSourceSystemName(AUCTION_CHARGES);
    try {
      cpStatusLog.setTBoxTimestamp(DateUtils.toTimestampWithMsPrecision(event.getTboxtimestamp()));
      cpStatusLog.setCdcTimestamp(DateUtils.toTimestamp(event.getCdcjournaltimestamp()));
    } catch (DateTimeParseException e) {
      log.warn(DATE_PARSE_ERROR, e);
    }
  }

  private void setNegativeOnesAsDefaultsForETL(ChargesProcessStatusLog cpStatusLog, Long sblu,
      Long workOrder, String vin, String dealerNumber) {
    // default values set to -1 instead of null as per ETL
    String defaultValue = "-1";
    if (null == sblu) {
      cpStatusLog.setSblu(-1L);
    }
    if (null == workOrder) {
      cpStatusLog.setWorkOrder(-1L);
    }
    cpStatusLog.setVin(null == vin ? defaultValue : vin);
    cpStatusLog.setDealerNumber(
        (null == dealerNumber || "null" == dealerNumber) ? defaultValue : dealerNumber);
  }

  private void setValuesFromTboxEvent(AuctionEvent event, ChargesProcessStatusLog cpStatusLog) {
    cpStatusLog.setEventType(event.getEventType());
    cpStatusLog.setAuction(event.getAuctionCode());
    cpStatusLog.setSblu(NumberUtils.createLong(event.getSblu()));
    cpStatusLog.setWorkOrder(NumberUtils.createLong(event.getWorkOrder()));
    cpStatusLog.setVin(event.getVin());
    cpStatusLog.setSourceTable(event.getSourceTableName());
    cpStatusLog.setChangeCode(event.getChangestatus());
    cpStatusLog.setPrevSellerDealerNumber(event.getPrevSellerDealerId());
    cpStatusLog.setPrevBuyerDealerNumber(event.getPrevBuyerDealerId());
    String defaultValue = "-";
    cpStatusLog.setComments(defaultValue);
    cpStatusLog.setWorkOrder(NumberUtils.createLong(event.getWorkOrder()));
    cpStatusLog.setDealerNumber(event.getSellerId());
    cpStatusLog.setCdcUserId(event.getCdcUserId());
    cpStatusLog.setSourceEventType(event.getSourceEventName());
  }

  private String getAuctionCode(String auctionId) {

    if (null != auctionId && auctionId.length() > 0) {
      return auctionId.substring(1, auctionId.length() - 1);
    }
    return "";
  }
}
