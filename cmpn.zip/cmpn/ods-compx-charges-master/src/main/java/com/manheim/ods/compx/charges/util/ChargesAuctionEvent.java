package com.manheim.ods.compx.charges.util;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@JsonDeserialize(using = ChargesEventDeserializer.class)
public class ChargesAuctionEvent extends AuctionEvent {

}
