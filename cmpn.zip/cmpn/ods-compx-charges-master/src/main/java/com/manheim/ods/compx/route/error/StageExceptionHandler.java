package com.manheim.ods.compx.route.error;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.charges.service.StagingService;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

@Component
public class StageExceptionHandler implements Processor {
  Logger logger = LoggerFactory.getLogger(this.getClass());
  private static final String AUCTION_CODE_LABEL = "auctionCode:";
  private static final String EVENT_TYPE_LABEL = "eventType:";
  private static final String VIN_LABEL = "vin:";
  @Autowired
  MetricReporter metricReporter;
  @Autowired
  StagingService stagingService;


  public StageExceptionHandler(MetricReporter metricReporter, StagingService stagingService) {
    this.metricReporter = metricReporter;
    this.stagingService = stagingService;
  }

  @Override
  public void process(Exchange exchange) throws Exception {
    StageException exception =
        exchange.getProperty(Exchange.EXCEPTION_CAUGHT, StageException.class);
    AuctionEvent auctionEvent = exchange.getIn().getBody(AuctionEvent.class);
    if (exception != null) {
      metricReporter.incrementEventError(EVENT_TYPE_LABEL + auctionEvent.getEventType(),
          VIN_LABEL + auctionEvent.getVin(), AUCTION_CODE_LABEL + auctionEvent.getAuctionCode());
      logger.error("Stream Receiver Route Builder Error : {}", exception);
      stagingService.saveStageError(auctionEvent, exception);
    }

  }

}
