package com.manheim.ods.compx.charges.api.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class ChargesResponse implements Response {

  private String saleStatus;
  private String requestTimestamp;
  private boolean isVehicleTransfered;
  private String invoiceDate;
  private String invoiceNumber;
  private Consignment consignment;
  private Offering offering;
  private String arbitrationDate;
  private String arbitrationDispositionCode;
  private Buyer buyer;
  private Charges charges;
  private Payment payment;
}
