package com.manheim.ods.compx.route;

import org.apache.camel.builder.RouteBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.charges.service.StagingService;

@Component
public class StreamReceiverRouteBuilder extends RouteBuilder {

  @Autowired
  @Qualifier("stagingService")
  StagingService stagingService;


  Logger logger = LoggerFactory.getLogger(this.getClass());

  public StreamReceiverRouteBuilder(@Autowired StagingService stagingService) {
    this.stagingService = stagingService;
  }

  @Override
  public void configure() throws Exception {

    from("direct:postevent").id("directpostevent").choice().when()
        .simple("${body.eventType} == 'SELLER_CHARGES_CHANGED'").to("direct:seller-charges-changed")
        .when().simple("${body.eventType} == 'BUYER_CHARGES_CHANGED'")
        .to("direct:buyer-charges-changed").when()
        .simple("${body.eventType} == 'SELLER_SERVICE_ORDER_CREATED'")
        .to("direct:seller-service-order-created").when()
        .simple("${body.eventType} == 'BUYER_SERVICE_ORDER_CREATED'")
        .to("direct:buyer-service-order-created").when()
        .simple("${body.eventType} == 'INVENTORY_DELETED'").to("direct:inventory-deleted").when()
        .simple("${body.eventType} == 'HEARTBEAT'").to("direct:heartbeat");


  }

}
