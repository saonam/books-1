package com.manheim.ods.compx.charges.api.response;

import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Getter
public class Payment {

  private BigDecimal paidAmount;
  private String paidDate;
  private String sellerCheckClearedDate;
  private String sellerCheckStopPayDate;
  private String sellerCheckVoidDate;
  private String sellerCheckPrintedIndicator;
  private Integer floorPlanAgencyCode;
  private String paidMethod;
  private String paymentType;
}
