package com.manheim.ods.compx.consumer.processor.vehicle;

import javax.xml.bind.JAXBContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.EventProcessor;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;
import com.manheim.xods.entity.Pfvehicle;

@Component
public class VehicleEventProcessor extends EventProcessor {

  @Autowired
  public VehicleEventProcessor(AuctionEventsRuleManager auctionEventsRuleManager,
      LogWrapper logWrapper, JAXBContext jaxbContext, MetricReporter metricReporter) {
    super(auctionEventsRuleManager, logWrapper, metricReporter, jaxbContext);
  }

  @Override
  public String[] getRules() {
    return new String[] {"com.manheim.attc.checkin", "com.manheim.attc.checkin.updated",
        "com.manheim.attc.listing", "com.manheim.attc.cross.the.block",
        "com.manheim.tbox.vehicle.deleted"};
  }

  @Override
  public String[] getValidEventTypes() {
    return new String[] {"CHECK_IN", "CHECK_IN_UPDATED", "LISTING", "CROSS_BLOCK",
        "INVENTORY_DELETED"};
  }

  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {
    Pfvehicle pfvehicle = (Pfvehicle) cdcEntity;
    String vin = String.format("%s%s%s%s%s%s%s%s%s%s%s%s", pfvehicle.getSser1s(),
        pfvehicle.getSser2n(), pfvehicle.getSser3t(), pfvehicle.getSser4t(), pfvehicle.getSser5t(),
        pfvehicle.getSser6t(), pfvehicle.getSser7t(), pfvehicle.getSser8t(), pfvehicle.getSsercd(),
        pfvehicle.getSsermy(), pfvehicle.getSser11(), pfvehicle.getSserl6());

    return AuctionEvent.builder().auctionCode(pfvehicle.getId().getSauci())
        .vin(vin.contains("null") ? vin.replace("null", "") : vin)
        .workOrder(String.valueOf(pfvehicle.getId().getSwo()))
        .sblu(String.valueOf(pfvehicle.getId().getSblu()))
        .cdcjournaltimestamp(pfvehicle.getCdctimestamp()).cdcUserId(pfvehicle.getUpdatedby())
        .saleYear(pfvehicle.getSsleyr()).saleNumber(pfvehicle.getSsale())
        .laneNumber(pfvehicle.getSlane()).runNumber(pfvehicle.getSrun())
        .prevBuyerDealerId(pfvehicle.getPrevSbuyer()).prevSellerDealerId(pfvehicle.getPrevSsellr())
        .sellerId(String.valueOf(pfvehicle.getSsellr())).build();
  }

  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));

  }



}
