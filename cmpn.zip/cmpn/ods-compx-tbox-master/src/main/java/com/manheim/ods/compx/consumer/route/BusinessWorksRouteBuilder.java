package com.manheim.ods.compx.consumer.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
@EnableJms
public class BusinessWorksRouteBuilder extends RouteBuilder {
  @Value("${inbound.bee.queue}")
  private String inboundBeeQueues;

  @Override
  public void configure() throws Exception {

    String[] activemqBeeSourceQueuesArray =
        StringUtils.commaDelimitedListToStringArray(inboundBeeQueues);
    int startupOrder = 200;
    for (String activemqBeeSourceQueue : activemqBeeSourceQueuesArray) {
      from(String.format("ods-bee-inbound-jms:%s?concurrentConsumers=1", activemqBeeSourceQueue))
          .autoStartup(true).startupOrder(startupOrder++).to("direct:processBeeMessage");

    }
  }
}
