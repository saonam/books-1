package com.manheim.xods.entity;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class PfvehextId implements java.io.Serializable {

  private static final long serialVersionUID = 8105521624004236683L;
  private String vauci;
  private int vblu;

}
