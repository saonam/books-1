package com.manheim.xods.entity;


import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
public abstract class CdcEntity implements java.io.Serializable {

  private static final long serialVersionUID = -5825349518733066343L;
  private ChangeDataCapture dataEventChgIndList;
  private String cdctimestamp;
  private String changestatus;

  public abstract String getPartitionKey();

}
