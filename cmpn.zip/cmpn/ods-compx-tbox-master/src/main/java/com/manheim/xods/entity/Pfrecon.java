package com.manheim.xods.entity;


import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
@XmlRootElement(name = "PFRECON")
public class Pfrecon extends CdcEntity {
  private static final long serialVersionUID = 8364993733109322764L;
  private PfreconId id;
  private String rcdcde;
  private int rcdtee;
  private int rcdtes;
  private short rcscls;
  private BigDecimal rccost;
  private BigDecimal rcretl;
  private short rcqty;
  private String rcpart;
  private String rcdesc;
  private short rcage;
  private int rcdtep;
  private String rcnew;
  private String rcsled;
  private int rcemp;
  private BigDecimal rchrs;
  private BigDecimal rcrate;
  private BigDecimal rcbrat;
  private String rcsubn;
  private String rclr;
  private int rcvnd;
  private String rcvdin;
  private int rcvddt;
  private int rcdtpo;
  private int rcapck;
  private int rcper;
  private int rcgla;
  private int rcgld;
  private int rcdtrd;
  private String rcrfl;
  private String rcediref;
  private int rcdtelb;
  private int rcfeeid;
  private int rcbatno;
  private String updatedby;

  @Override
  public String getPartitionKey() {
    return String.format("%s:%s", this.id.getRcauci(), this.id.getRcwo());
  }

}
