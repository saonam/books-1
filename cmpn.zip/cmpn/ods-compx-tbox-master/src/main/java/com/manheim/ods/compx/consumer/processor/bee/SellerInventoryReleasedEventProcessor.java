package com.manheim.ods.compx.consumer.processor.bee;


import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.manheim.bee.entity.BusinessEvent;
import com.manheim.bee.entity.BusinessEventMessageControl;
import com.manheim.bee.entity.InventoryItem;
import com.manheim.bee.entity.ReferenceId;
import com.manheim.ods.compx.consumer.processor.NoRulesEventProcessor;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;

@Component
public class SellerInventoryReleasedEventProcessor extends NoRulesEventProcessor {

  public static final Logger LOG =
      LoggerFactory.getLogger(SellerInventoryReleasedEventProcessor.class);
  @Value("${invreleased.ignore.older.than}")
  private int ignoreOlderThan;

  @Autowired
  public SellerInventoryReleasedEventProcessor(LogWrapper logWrapper, JAXBContext jaxbContext,
      MetricReporter metricReporter,
      @Value("${invreleased.ignore.older.than}") int ignoreOlderThan) {
    super(null, logWrapper, metricReporter, jaxbContext);
    this.ignoreOlderThan = ignoreOlderThan;
  }

  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {

    BusinessEvent beeEvent = (BusinessEvent) cdcEntity;

    ReferenceId referenceId =
        beeEvent.getEntityInformation().getEntityIdentification().getReferenceId();

    BusinessEventMessageControl messageControl = beeEvent.getMessageControl();

    InventoryItem inventoryItem = beeEvent.getEntityInformation().getInventoryItem();
    String redeemedDate = null;
    if (inventoryItem != null) {
      redeemedDate = inventoryItem.getLegacyRedeemedDate();
    }

    String eventType = "SELLER_CHARGES_CHANGED";

    return AuctionEvent.builder().auctionCode(referenceId.getAuctionCode())
        .sblu(String.valueOf(referenceId.getSblu())).vin(referenceId.getVin())
        .workOrder(String.valueOf(referenceId.getWorkOrder()))
        .tboxtimestamp(DateUtils.getCurrentSystemTimestampInString()).eventType(eventType)
        .cdcjournaltimestamp(
            DateUtils.fromSecondsToNanosTimestampString(messageControl.getEventTimestamp()))
        .cdcUserId(beeEvent.getMessageControl().getModifiedBy()).redeemedDate(redeemedDate)
        .sourceTableName("SELLER_INVENTORY_RELEASED").sourceEventName("SELLER_INVENTORY_RELEASED")
        .build();
  }

  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
  }

  @Override
  protected List<AuctionEvent> executeRules(CdcEntity cdcEntity) {
    List<AuctionEvent> auctionEventList = new ArrayList<>();
    AuctionEvent auctionEvent = buildAuctionEvent(cdcEntity);
    logWrapper.info(this.getClass(), auctionEvent.toString());
    if (valid(auctionEvent)) {
      setMessageGroupId(auctionEvent);
      auctionEventList.add(auctionEvent);
    }
    return auctionEventList;
  }

  @Override
  public boolean valid(AuctionEvent auctionEvent) {
    boolean isValidEvent = super.valid(auctionEvent);
    // evaluate redeemed date
    if (isValidEvent && auctionEvent.getRedeemedDate() != null) {
      try {
        long diffDays = DateUtils.daysDifferenceFromNow(
            DateUtils.toDate(auctionEvent.getRedeemedDate(), "Redeemed Date"));
        return diffDays < ignoreOlderThan;
      } catch (ParseException e) {
        LOG.warn("Error parsing Redeemed Date for {}", auctionEvent.getRedeemedDate());
        return true;
      }
    }
    return isValidEvent;
  }

}
