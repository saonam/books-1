package com.manheim.ods.compx.consumer.route;

import org.apache.camel.builder.RouteBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.vehicle.VehicleExtEventProcessor;

@Component
public class VehicleExtRouteBuilder extends RouteBuilder {
  @Autowired
  VehicleExtEventProcessor vehicleExtEventProcessor;

  Logger logger = LoggerFactory.getLogger(this.getClass());

  @Override
  public void configure() throws Exception {
    from("direct:compx-vehicle-ext-route").bean(vehicleExtEventProcessor)
        .to("direct:send-tbox-events");
  }

}
