package com.manheim.ods.compx.consumer.processor.vehicle;

import javax.xml.bind.JAXBContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.EventProcessor;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;
import com.manheim.xods.entity.Tprmktbl;

@Component
public class ThirdPartyRemarketingEventProcessor extends EventProcessor {


  @Autowired
  public ThirdPartyRemarketingEventProcessor(AuctionEventsRuleManager auctionEventsRuleManager,
      LogWrapper logWrapper, JAXBContext jaxbContext, MetricReporter metricReporter) {
    super(auctionEventsRuleManager, logWrapper, metricReporter, jaxbContext);
  }

  @Override
  public String[] getRules() {
    return new String[] {"com.manheim.tbox.tprmktbl.charges.changed"};
  }


  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {
    Tprmktbl tprmktbl = (Tprmktbl) cdcEntity;
    return AuctionEvent.builder().auctionCode(tprmktbl.getId().getTpauci())
        .cdcjournaltimestamp(tprmktbl.getCdctimestamp()).cdcUserId(tprmktbl.getUpdatedby())
        .sourceTableName("TPRMKTBL").workOrder(String.valueOf(tprmktbl.getId().getTpwo())).build();

  }

  @Override
  public String[] getValidEventTypes() {
    return new String[] {"SELLER_CHARGES_CHANGED"};
  }

  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));

  }

}
