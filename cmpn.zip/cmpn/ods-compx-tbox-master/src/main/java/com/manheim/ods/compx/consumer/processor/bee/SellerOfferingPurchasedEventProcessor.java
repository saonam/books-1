package com.manheim.ods.compx.consumer.processor.bee;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.bee.entity.BusinessEvent;
import com.manheim.bee.entity.BusinessEventMessageControl;
import com.manheim.bee.entity.ReferenceId;
import com.manheim.ods.compx.consumer.processor.NoRulesEventProcessor;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;

@Component
public class SellerOfferingPurchasedEventProcessor extends NoRulesEventProcessor {

  @Autowired
  public SellerOfferingPurchasedEventProcessor(LogWrapper logWrapper, JAXBContext jaxbContext,
      MetricReporter metricReporter) {
    super(null, logWrapper, metricReporter, jaxbContext);
  }

  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {
    return null;
  }

  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity, String eventType) {

    BusinessEvent beeEvent = (BusinessEvent) cdcEntity;

    ReferenceId referenceId =
        beeEvent.getEntityInformation().getEntityIdentification().getReferenceId();

    BusinessEventMessageControl messageControl = beeEvent.getMessageControl();


    String strEventTimestamp = messageControl.getEventTimestamp();
    String timestampFormat = "yyyy-MM-dd'T'HH:mm:ss";
    String eventTimezone = "GMT";
    String requiredTimezone = "America/New_York";
    String eventTimestampEST = DateUtils.convertToTimezone(strEventTimestamp, timestampFormat,
        eventTimezone, requiredTimezone);


    return AuctionEvent.builder().auctionCode(referenceId.getAuctionCode())
        .sblu(String.valueOf(referenceId.getSblu())).vin(referenceId.getVin())
        .workOrder(String.valueOf(referenceId.getWorkOrder()))
        .tboxtimestamp(DateUtils.getCurrentSystemTimestampInString())
        .sourceTableName("SELLER_OFFERING_PURCHASED").sourceEventName("SELLER_OFFERING_PURCHASED")
        .eventType(eventType)
        .cdcjournaltimestamp(DateUtils.fromSecondsToNanosTimestampString(eventTimestampEST))
        .cdcUserId(beeEvent.getMessageControl().getModifiedBy()).build();
  }



  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
  }


  @Override
  protected List<AuctionEvent> executeRules(CdcEntity cdcEntity) {
    List<AuctionEvent> auctionEventList = new ArrayList<>();
    AuctionEvent sellerAuctionEvent = buildAuctionEvent(cdcEntity, "SELLER_CHARGES_CHANGED");
    logWrapper.info(this.getClass(), sellerAuctionEvent.toString());
    setMessageGroupId(sellerAuctionEvent);
    AuctionEvent buyerAuctionEvent = buildAuctionEvent(cdcEntity, "BUYER_CHARGES_CHANGED");
    logWrapper.info(this.getClass(), buyerAuctionEvent.toString());
    setMessageGroupId(buyerAuctionEvent);
    auctionEventList.add(sellerAuctionEvent);
    auctionEventList.add(buyerAuctionEvent);
    return auctionEventList;
  }

}
