package com.manheim.xods.entity;


import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 */
@Getter
@Setter
@NoArgsConstructor
@XmlRootElement(name = "TPRMKTBL")
public class Tprmktbl extends CdcEntity {
  private static final long serialVersionUID = 8364993733109322764L;
  private TprmktblId id;

  private String updatedby;
  private int tpsellr;
  private String tpgroup;
  private String flag1;
  private String flag2;
  private String crtbyts;
  private String updbyts;

  @Override
  public String getPartitionKey() {
    return String.format("%s:%s", this.id.getTpauci(), this.id.getTpwo());
  }

}
