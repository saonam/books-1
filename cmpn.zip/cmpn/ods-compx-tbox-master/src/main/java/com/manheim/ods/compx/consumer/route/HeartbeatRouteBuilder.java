package com.manheim.ods.compx.consumer.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.heartbeat.HeartbeatProcessor;

@Component
public class HeartbeatRouteBuilder extends RouteBuilder {
  @Autowired
  HeartbeatProcessor heatbeatProcessor;

  @Override
  public void configure() throws Exception {
    from("direct:heartbeat-route").autoStartup(true).startupOrder(3).bean(heatbeatProcessor)
        .to("log:com.manheim.auctionheartbeat?level=info").to("direct:send-tbox-events");
  }

}
