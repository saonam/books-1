package com.manheim.xods.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PfsadjdtlId implements java.io.Serializable {

  private static final long serialVersionUID = -5390493330395277202L;

  private int ajsleyr;
  private int ajsale;
  private int ajlane;
  private int ajrun;
  private String ajauci;
}
