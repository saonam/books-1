package com.manheim.ods.compx.consumer.util;

public class Constants {


  // Events
  public static final String CHECK_IN = "CHECK_IN";
  public static final String CHECK_IN_UPDATED = "CHECK_IN_UPDATED";
  public static final String LISTING = "LISTING";
  public static final String CROSS_BLOCK = "CROSS_BLOCK";
  public static final String MMR_HEARTBEAT = "MMR_HEARTBEAT";

  // BPMN
  public static final String CHECK_IN_BPMN = "com.manheim.attc.checkin";
  public static final String CHECK_IN_UPDATED_BPMN = "com.manheim.attc.checkin.updated";
  public static final String LISTING_BPMN = "com.manheim.attc.listing";
  public static final String CROSS_BLOCK_BPMN = "com.manheim.attc.cross.the.block";

  private Constants() {
    // restrict instantiation
  }
}
