package com.manheim.bee.entity;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@XmlRootElement(namespace = "http://webservices.manheim.com/", name = "messageControl")
@XmlAccessorType(XmlAccessType.FIELD)
public class BusinessEventMessageControl implements Serializable {
  private static final long serialVersionUID = -8974242793237836473L;
  String modifiedBy;
  String eventTimestamp;

}
