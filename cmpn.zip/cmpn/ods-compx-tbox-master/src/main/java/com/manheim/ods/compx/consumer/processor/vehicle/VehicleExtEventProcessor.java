package com.manheim.ods.compx.consumer.processor.vehicle;

import javax.xml.bind.JAXBContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.EventProcessor;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;
import com.manheim.xods.entity.Pfvehext;

@Component
public class VehicleExtEventProcessor extends EventProcessor {

  @Autowired
  public VehicleExtEventProcessor(AuctionEventsRuleManager auctionEventsRuleManager,
      LogWrapper logWrapper, JAXBContext jaxbContext, MetricReporter metricReporter) {
    super(auctionEventsRuleManager, logWrapper, metricReporter, jaxbContext);
  }

  @Override
  public String[] getValidEventTypes() {
    return new String[] {"SELLER_CHARGES_CHANGED", "BUYER_CHARGES_CHANGED"};
  }

  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {
    Pfvehext pfvehext = (Pfvehext) cdcEntity;
    AuctionEvent auctionEvent = AuctionEvent.builder().auctionCode(pfvehext.getId().getVauci())
        .cdcjournaltimestamp(pfvehext.getCdctimestamp()).cdcUserId(pfvehext.getUpdatedby())
        .sblu(String.valueOf(pfvehext.getId().getVblu())).build();
    auctionEvent.setMessageGroupId(String.format("%s:%s:%s", auctionEvent.getAuctionCode(),
        auctionEvent.getSblu(), auctionEvent.getEventType()));
    return auctionEvent;
  }

  @Override
  public String[] getRules() {
    return new String[] {"com.manheim.tbox.vehicle.extension.seller.charges.changed",
        "com.manheim.tbox.vehicle.extension.buyer.charges.changed",
        "com.manheim.tbox.vehicle.extension.deleted"};
  }

  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getSblu()));

  }

}
