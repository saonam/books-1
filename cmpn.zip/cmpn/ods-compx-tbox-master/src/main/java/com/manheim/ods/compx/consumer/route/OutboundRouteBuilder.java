package com.manheim.ods.compx.consumer.route;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.consumer.processor.vehicle.VehicleEventProcessor;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@Component
public class OutboundRouteBuilder extends RouteBuilder {
  @Autowired
  VehicleEventProcessor vehicleEventProcessor;
  @Value("${compxmmr.authorization}")
  String compxMmrAuthorization;
  @Value("${compxcharges.authorization}")
  String compxChargesAuthorization;

  @Autowired
  ObjectMapper objectMapper;
  @Value("${compxmmr.api.endpoint}")
  String compxMmrApiEndpoint;
  @Value("${compxcharges.api.endpoint}")
  String compxChargesApiEndpoint;
  @Value("${aggregate.completion.size}")
  int aggregateCompletionSize;
  @Value("${aggregate.completion.timeout}")
  long aggregateCompletionTimeout;
  @Autowired
  EventTypeValidator eventTypeValidator;

  @Override
  public void configure() throws Exception {

    from("direct:send-tbox-events").id("send-tbox-events").autoStartup(true).startupOrder(5)
        .split(body()).convertBodyTo(AuctionEvent.class).filter(eventTypeValidator).choice().when()
        .simple("${body.eventType} == 'HEARTBEAT'").to("direct:stream").otherwise()
        .to("direct:aggregate-tbox-events").end();
    from("direct:aggregate-tbox-events").id("aggregate-tbox-events")
        .aggregate(simple("${body.messageGroupId}"), new AuctionEventAggregationStrategy())
        .completionSize(aggregateCompletionSize).completionTimeout(aggregateCompletionTimeout)
        .split(body())
        .log(LoggingLevel.INFO, LoggerFactory.getLogger(this.getClass()),
            "Aggregated ${header.CamelAggregatedSize} on ${body.messageGroupId}")
        .to("direct:stream");

  }

}
