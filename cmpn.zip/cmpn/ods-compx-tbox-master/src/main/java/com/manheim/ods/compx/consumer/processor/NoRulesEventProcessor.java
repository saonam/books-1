package com.manheim.ods.compx.consumer.processor;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;

import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;

@Component
public abstract class NoRulesEventProcessor extends EventProcessor {


  public NoRulesEventProcessor(AuctionEventsRuleManager auctionEventsRuleManager,
      LogWrapper logWrapper, MetricReporter metricReporter, JAXBContext jaxbContext) {
    super(auctionEventsRuleManager, logWrapper, metricReporter, jaxbContext);
  }

  @Override
  protected void executeBpm(String ruleDef, CdcEntity cdcEntity, AuctionEvent auctionEvent) {
    logWrapper.info(this.getClass(), "No rules here !!");
  }

  @Override
  public String[] getRules() {
    return new String[] {this.getClass().getName()};
  }

  @Override
  public String[] getValidEventTypes() {
    return new String[] {"SELLER_CHARGES_CHANGED", "SELLER_SERVICE_ORDER_CREATED"};
  }

  @Override
  protected List<AuctionEvent> executeRules(CdcEntity cdcEntity) {
    List<AuctionEvent> auctionEventList = new ArrayList<>();
    AuctionEvent auctionEvent = buildAuctionEvent(cdcEntity);
    logWrapper.info(this.getClass(), auctionEvent.toString());
    setMessageGroupId(auctionEvent);
    auctionEventList.add(auctionEvent);
    return auctionEventList;
  }

}
