package com.manheim.xods.entity;


import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
@XmlRootElement(name = "PFVEHICLE")
@XmlAccessorType(XmlAccessType.FIELD)
public class Pfvehicle extends CdcEntity {

  private static final long serialVersionUID = -5825349518733066343L;
  private PfvehicleId id;
  private String scode;
  private short stsley;
  private short stsale;
  private byte stlane;
  private short strun;
  private String sstk;
  private String slseac;
  private int sselck;
  private String sbuyen;
  private byte sbysg;
  private String sserun;
  private String sser1s;
  private String sser2n;
  private String sser3t;
  private String sser4t;
  private String sser5t;
  private String sser6t;
  private String sser7t;
  private String sser8t;
  private String ssercd;
  private String ssermy;
  private String sser11;
  private String sserl6;
  private String smake;
  private String smodel;
  private String smod15;
  private String ssubse;
  private String sbody;
  private String snonvn;
  private String scolor;
  private String sintco;
  private String seng;
  private String sradio;
  private String strn;
  private String sps;
  private String spb;
  private String sac;
  private String sew;
  private String ses;
  private String stop;
  private String scc;
  private String sel;
  private String s4x4;
  private String stilt;
  private String sab;
  private String spass;
  private String sext1;
  private String sext2;
  private String sext3;
  private String sannou;
  private String slic;
  private String sltab;
  private String slight;
  private String sbox1;
  private String scksen;
  private int sprime;
  private BigDecimal sadj;
  private BigDecimal smts;
  private BigDecimal sadj2;
  private String shwpd;
  private BigDecimal sardue;
  private BigDecimal sgsts;
  private BigDecimal sgstf;
  private BigDecimal sckord;
  private String stiton;
  private String smsoti;
  private String saddr;
  private String scity;
  private String sprov;
  private String szip;
  private String scnty;
  private String srfl;
  private String smktpr;
  private String snock;
  private String sdraft;
  private String sprint;
  private String spaid;
  private String sruntm;
  private String slease;
  private String sanniv;
  private int stimer;
  private int stimef;
  private int stimed;
  private int stimec;
  private int sbyck;
  private String sinitl;
  private byte stmrun;
  private String saucin;
  private String sclse;
  private String sfetyp;
  private String sswaa;
  private int sopera;
  private String stlic;
  private String sflrty;
  private String sflndr;
  private String sautfx;
  private String swsid;
  private String srcnde;
  private short sdiv;
  private int sdtecn;
  private int sdtepu;
  private int sdtetr;
  private int sdteis;
  private int sdteos;
  private int sdteac;
  private int sdtecr;
  private int sdteso;
  private int sdtecs;
  private int sdteci;
  private int sdtecl;
  private int sdtetm;
  private int sdtecb;
  private int sdtesp;
  private int sdtets;
  private int sdteab;
  private int sdteec;
  private int sdteli;
  private int sdtefc;
  private int scoll;
  private int shslep;
  private int shbuyf;
  private int shdftf;
  private BigDecimal shadj;
  private BigDecimal shbuyn;
  private String shhwpd;
  private BigDecimal shbald;
  private int shchgd;
  private short slotln;
  private short slotrn;
  private String sremar;
  private String sopern;
  private String sta;
  private int sbnker;
  private byte sbnksg;
  private BigDecimal sbaldu;
  private String sgrpsb;
  private String sidchk;
  private String siddep;
  private String sidreg;
  private String sintn1;
  private String sintn2;
  private String strnbk;
  private String sdryrn;
  private String smafs;
  private int simag;
  private String simage;
  private int sextdte;
  private BigDecimal sextamt;
  private String sextyn1;
  private String sextyn2;
  private String sextyn3;
  private String sairco;
  private String sair;
  private String scamrp;
  private int sbarcd;
  private int sautotc;
  private int sdtest;
  private String mflag3;
  private int sdteclup;
  private String sbuytyp;
  private int sdtesi;
  private int sdwkcmp;
  private String sbags;
  private String sdhsid;
  private String sdstkid;
  private String sdtdpid;
  private String sdtclid;
  private String sdtrtid;
  private String sdteho;
  private String saia2;
  private int sticket;
  private int sflragcy;
  private int sotbfe1;
  private int sotbfe2;
  private int sotsfe1;
  private int sdtedprm;
  private String sdprmusr;
  private int sdteadjp;
  private String sadjusr;
  private String ssmrterr;
  private String saupnfe;
  private String sshipco;
  private String sairbl;
  private String shdout;
  private String sgsasl;
  private int stabex;
  private String saasc;
  private String created;
  private String updated;
  private String updatedby;
  private String sser17;
  private int sentfe;
  private BigDecimal sflat;
  private BigDecimal ssletx;
  private int stilfe;
  private String stitle;
  private int sdterd;
  private int sdtesb;
  private int sdtesa;
  private int sdtesl;
  private int sdtedp;
  private int sdtepd;
  private int sdtert;
  private int sdtevd;
  private int sdteco;
  private int sdtein;
  private int sdtemt;
  private String scond;
  private String sarbhist;
  private int mstcym;
  private int sotsfe2;
  private String srdefr;
  private String sint;

  // -------------------

  private String msubse;
  private int sautotcb;
  private int sbuyu;
  private int sbuybid;
  private int sbuyer;
  private int sbuyfe;
  private BigDecimal sbuyne;
  private int scaryr;
  private BigDecimal schgs;
  private int sckdr;
  private int sdftfe;
  private int sdtefo;
  private int sdtere;
  private BigDecimal sfloor;
  private String sgroup;
  private String sifsle;
  private int sinv;
  private String smanfe;
  private int smiles;
  private String sododig;
  private BigDecimal sothfe;
  private String sprimcd;
  private int ssleyr;
  private int ssale;
  private int slane;
  private int srun;
  private int sselfe;
  private String sselln;
  private int ssellr;
  private BigDecimal sselne;
  private int sslepr;
  private int sslru;
  private String stile;
  private int stimes;
  private String svehic;

  @XmlElement(name = "prev_sdtere")
  private int prevSdtere;
  @XmlElement(name = "prev_scode")
  private String prevScode;

  @XmlElement(name = "prev_sbuyer")
  private String prevSbuyer;
  @XmlElement(name = "prev_ssellr")
  private String prevSsellr;
  @XmlElement(name = "prev_sruntm")
  private String prevSruntm;

  @Override
  public String getPartitionKey() {
    return String.format("%s:%s", this.id.getSauci(), this.id.getSwo());
  }

}
