package com.manheim.xods.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PfpsiId implements java.io.Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  private String piauci;
  private int pislyr;
  private int pisle;
  private int pilne;
  private int pirun;
}
