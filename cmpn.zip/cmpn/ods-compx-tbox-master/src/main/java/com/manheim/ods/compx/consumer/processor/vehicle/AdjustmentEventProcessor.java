package com.manheim.ods.compx.consumer.processor.vehicle;

import javax.xml.bind.JAXBContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.EventProcessor;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;
import com.manheim.xods.entity.Pfsadjdtl;

@Component
public class AdjustmentEventProcessor extends EventProcessor {


  @Autowired
  public AdjustmentEventProcessor(AuctionEventsRuleManager auctionEventsRuleManager,
      LogWrapper logWrapper, JAXBContext jaxbContext, MetricReporter metricReporter) {
    super(auctionEventsRuleManager, logWrapper, metricReporter, jaxbContext);
  }

  @Override
  public String[] getRules() {
    return new String[] {"com.manheim.tbox.adjustment.charges.changed"};
  }


  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {
    Pfsadjdtl pfsadjdtl = (Pfsadjdtl) cdcEntity;
    AuctionEvent auctionEvent = AuctionEvent.builder().auctionCode(pfsadjdtl.getId().getAjauci())
        .cdcjournaltimestamp(pfsadjdtl.getCdctimestamp()).cdcUserId(pfsadjdtl.getUpdatedby())
        .saleNumber(pfsadjdtl.getId().getAjsale()).saleYear(pfsadjdtl.getId().getAjsleyr())
        .laneNumber(pfsadjdtl.getId().getAjlane()).runNumber(pfsadjdtl.getId().getAjrun()).build();

    auctionEvent.setMessageGroupId(String.format("%s:%s:%s", auctionEvent.getAuctionCode(),
        auctionEvent.getWorkOrder(), auctionEvent.getEventType()));
    return auctionEvent;
  }

  @Override
  public String[] getValidEventTypes() {
    return new String[] {"BUYER_CHARGES_CHANGED"};
  }

  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));

  }

}
