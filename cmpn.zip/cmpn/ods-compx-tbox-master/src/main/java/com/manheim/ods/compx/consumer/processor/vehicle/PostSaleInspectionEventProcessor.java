package com.manheim.ods.compx.consumer.processor.vehicle;

import javax.xml.bind.JAXBContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.manheim.ods.compx.consumer.processor.EventProcessor;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;
import com.manheim.xods.entity.Pfpsi;


@Component
public class PostSaleInspectionEventProcessor extends EventProcessor {


  @Autowired
  public PostSaleInspectionEventProcessor(AuctionEventsRuleManager auctionEventsRuleManager,
      LogWrapper logWrapper, JAXBContext jaxbContext, MetricReporter metricReporter) {
    super(auctionEventsRuleManager, logWrapper, metricReporter, jaxbContext);
  }

  @Override
  public String[] getRules() {
    return new String[] {"com.manheim.tbox.psi.charges.changed"};
  }


  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {
    Pfpsi pfpsi = (Pfpsi) cdcEntity;
    return AuctionEvent.builder().auctionCode(pfpsi.getId().getPiauci())
        .cdcjournaltimestamp(pfpsi.getCdctimestamp()).cdcUserId(pfpsi.getUpdatedby())
        .sourceTableName("PFPSI").saleYear(pfpsi.getId().getPislyr())
        .saleNumber(pfpsi.getId().getPisle()).laneNumber(pfpsi.getId().getPilne())
        .runNumber(pfpsi.getId().getPirun()).build();
  }

  @Override
  public String[] getValidEventTypes() {
    return new String[] {"BUYER_CHARGES_CHANGED"};
  }

  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(
        String.format("%s:%s:%s:%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getSaleYear(),
            auctionEvent.getSaleYear(), auctionEvent.getLaneNumber(), auctionEvent.getRunNumber()));
  }

}
