package com.manheim.ods.compx.consumer.route;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class StreamingRouteBuilder extends RouteBuilder {

  @Value("${spring.profiles.active}")
  String springProfile;

  @Value("${spring.application.name}")
  private String appName;

  @Value("${camel.springboot.name}")
  private String springBootName;

  @Override
  public void configure() throws Exception {
    // app name - combination of app name and env
    String kinesisClientName = String.format(appName.trim(), springProfile);
    // stream name - compX-tbox-silo1
    String streamName = String.format("%s-%s", springBootName, springProfile);
    String kinesisRouteUrl =
        String.format("aws-kinesis://%s?amazonKinesisClient=#%s", streamName, kinesisClientName);

    from("direct:stream").id("tbox-stream").log(LoggingLevel.INFO, "Reached direct:stream")
        .autoStartup(true).startupOrder(1).bean(ObjectMapper.class, "writeValueAsString")
        .to(kinesisRouteUrl);
  }


}
