package com.manheim.ods.compx.consumer.route;

import java.util.Arrays;

import org.apache.camel.Exchange;
import org.apache.camel.Predicate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@Component
@RefreshScope
public class EventTypeValidator implements Predicate {
  @Autowired
  ObjectMapper objectMapper;

  @Value("${valid.event.types}")
  String[] validEventTypes;

  Logger logger = LoggerFactory.getLogger(this.getClass());

  public EventTypeValidator(String[] validEventTypes) {
    this.validEventTypes = validEventTypes;
  }

  public EventTypeValidator() {

  }

  @Override
  public boolean matches(Exchange exchange) {
    AuctionEvent event = exchange.getIn().getBody(AuctionEvent.class);
    boolean eventTypeGood = Arrays.asList(validEventTypes).contains(event.getEventType());
    logger.info("EventType Validator for {} matches ? {}", event.getEventType(), eventTypeGood);
    return eventTypeGood;

  }

}
