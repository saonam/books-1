package com.manheim.bee.entity;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@XmlRootElement(namespace = "http://webservices.manheim.com/", name = "serviceOrderCreated")
@XmlAccessorType(XmlAccessType.FIELD)
public class ServiceOrderCreated implements Serializable {

  private static final long serialVersionUID = -7907306241643361069L;
  private String vin;
  private String auctionCode;
  private long workOrder;
  private long sblu;
  private String serviceOrderTypeCode;
  private String timeOfCreation;
  private String cdcEventTimestamp;


}
