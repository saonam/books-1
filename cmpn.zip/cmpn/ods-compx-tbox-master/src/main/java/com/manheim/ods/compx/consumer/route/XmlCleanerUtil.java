package com.manheim.ods.compx.consumer.route;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang3.StringEscapeUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class XmlCleanerUtil implements Processor {
  private static final Logger LOG = LoggerFactory.getLogger(XmlCleanerUtil.class);


  @Override
  public void process(Exchange exchange) throws Exception {

    String inputXmlMessage = exchange.getIn().getBody(String.class);
    String validXmlMessage = sanitiseXml(inputXmlMessage);

    exchange.getIn().setBody(validXmlMessage);
    LOG.info("Previous XML Message {}", inputXmlMessage);
    LOG.info("Converted XML Message {}", validXmlMessage);
  }


  private String sanitiseXml(String xml) {
    // Match the pattern <something>text</something>
    Pattern xmlCleanerPattern = Pattern.compile("(<[^/<>]*>)([^<>]*)(</[^<>]*>)");

    StringBuilder xmlStringBuilder = new StringBuilder();

    Matcher matcher = xmlCleanerPattern.matcher(xml);
    int lastEnd = 0;
    while (matcher.find()) {
      // Include any non-matching text between this result and the previous result
      if (matcher.start() > lastEnd) {
        xmlStringBuilder.append(xml.substring(lastEnd, matcher.start()));
      }
      lastEnd = matcher.end();

      // Sanitise the characters inside the tags and append the sanitised version
      String cleanText = StringEscapeUtils.escapeXml10(matcher.group(2));
      String cleanerText = cleanText.replaceAll("[^\\x20-\\x7e]", "");
      xmlStringBuilder.append(matcher.group(1)).append(cleanerText).append(matcher.group(3));
    }
    // Include any leftover text after the last result
    xmlStringBuilder.append(xml.substring(lastEnd));

    return xmlStringBuilder.toString();
  }
}
