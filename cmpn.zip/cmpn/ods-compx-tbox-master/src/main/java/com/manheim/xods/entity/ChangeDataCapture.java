package com.manheim.xods.entity;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * <dataEventChgIndList> <item> <dataEventField>SFLOOR</dataEventField> </item>
 * </dataEventChgIndList>
 * 
 * @author SKannan
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class ChangeDataCapture implements Serializable {
  private static final long serialVersionUID = 2935716376461454944L;
  private ChangeDataCaptureItem[] item;
}
