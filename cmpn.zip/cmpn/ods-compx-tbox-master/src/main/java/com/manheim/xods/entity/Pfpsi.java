package com.manheim.xods.entity;


import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@XmlRootElement(name = "PFPSI")
@XmlAccessorType(XmlAccessType.FIELD)
public class Pfpsi extends CdcEntity {

  private static final long serialVersionUID = 1042577018620821962L;

  private PfpsiId id;
  private short pirec;
  private String pircd;
  private String pipgmc;
  private String pidscc;
  private int pidlr;
  private String pibysl;
  private int pidtrq;
  private int pitmrq;
  private int pidtmk;
  private int pitmmk;
  private int pislepr;
  private BigDecimal pifamt;
  private BigDecimal pidamt;
  private String pi14dy;
  private String pictcd;
  private String pifile;
  private String piarbf;
  private String piinsp;
  private int piarinv;
  private short piarrec;
  private int piardinv;
  private short piardrec;
  private int pidtps;
  private String pilegt;
  private byte pifeet;
  private int pidtsl;
  private String piscode;
  private int pisblu;
  private String piflg1;
  private String piflg2;
  private String piusrm1;
  private String piusrm2;
  private int pidte1;
  private int pidte2;
  private String piuser;
  private String picrpg;
  private int pidate;
  private int pitime;
  @XmlElement(name = "prev_pipgmc")
  private String prevPipgmc;
  private String updatedby;

  @Override
  public String getPartitionKey() {
    return String.format("%s:%s:%s:%s:%s", this.id.getPiauci(), this.id.getPislyr(),
        this.id.getPisle(), this.id.getPilne(), this.id.getPirun());
  }

}
