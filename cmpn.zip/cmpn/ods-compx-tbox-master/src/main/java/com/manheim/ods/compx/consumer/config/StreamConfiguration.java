package com.manheim.ods.compx.consumer.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;

@Configuration
public class StreamConfiguration {


  @Bean(name = "aws-kinesis")
  public AmazonKinesis eventsClient() {

    AmazonKinesisClientBuilder clientBuilder = AmazonKinesisClientBuilder.standard();
    clientBuilder.withRegion(Regions.US_EAST_1);
    clientBuilder.withCredentials(new DefaultAWSCredentialsProviderChain());
    return clientBuilder.build();

  }
}
