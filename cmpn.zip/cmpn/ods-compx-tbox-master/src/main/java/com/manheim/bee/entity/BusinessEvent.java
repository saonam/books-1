package com.manheim.bee.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import com.manheim.xods.entity.CdcEntity;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@XmlRootElement(namespace = "http://webservices.manheim.com/", name = "BusinessEvent")
@XmlAccessorType(XmlAccessType.FIELD)
public class BusinessEvent extends CdcEntity {

  private static final long serialVersionUID = -7907306241643361069L;
  private BusinessEventEntityInformation entityInformation;

  private BusinessEventMessageControl messageControl;

  @Override
  public String getPartitionKey() {
    ReferenceId referenceId = this.entityInformation.getEntityIdentification().getReferenceId();
    return String.format("%s:%s", referenceId.getAuctionCode(), referenceId.getSblu());
  }
}
