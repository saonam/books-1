package com.manheim.ods.compx.consumer.rules;

import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.rule.FactHandle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class AuctionEventsRuleManager {
  private static final Logger LOG = LoggerFactory.getLogger(AuctionEventsRuleManager.class);


  @Autowired
  private KieSession kieSession;

  @Value("${cbs.source.event.name}")
  String cbsSourceEventName;


  public AuctionEventsRuleManager(KieSession kieSession) {
    this.kieSession = kieSession;
  }

  public void process(String rulesProcessName, Object... contextArguments) {
    for (Object contextArg : contextArguments) {
      kieSession.insert(contextArg);
    }
    kieSession.setGlobal("logger", LOG);
    kieSession.setGlobal("cbsSourceEventName", cbsSourceEventName);
    
    // setup the audit logging
    kieSession.startProcess(rulesProcessName);

    for (FactHandle factHandle : kieSession.getFactHandles()) {
      kieSession.delete(factHandle);
    }
  }
}
