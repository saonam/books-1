package com.manheim.ods.compx.consumer.processor;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.aws.kinesis.KinesisConstants;
import org.apache.commons.lang.ArrayUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;

@Component
public abstract class EventProcessor implements Processor {
  protected LogWrapper logWrapper;
  @Autowired
  private AuctionEventsRuleManager auctionEventsRuleManager;
  private MetricReporter metricReporter;

  @Autowired
  private JAXBContext jaxbContext;


  private static final String AUCTION_CODE_LABEL = "auctionCode:";
  private static final String EVENT_TYPE_LABEL = "eventType:";
  private static final String VIN_LABEL = "vin:";

  public EventProcessor(AuctionEventsRuleManager auctionEventsRuleManager, LogWrapper logWrapper,
      MetricReporter metricReporter, JAXBContext jaxbContext) {
    this.logWrapper = logWrapper;
    this.auctionEventsRuleManager = auctionEventsRuleManager;
    this.metricReporter = metricReporter;
    this.jaxbContext = jaxbContext;
  }

  @Override
  public void process(Exchange exchange) throws Exception {

    long eventProcessStartTime = System.currentTimeMillis();
    CdcEntity cdcEntity = getCdcEntity(exchange);
    // process Business Rules
    // find each rule and execute
    // ruledef - "ex) com.manheim.attc.listing"
    List<AuctionEvent> auctionEventList = executeRules(cdcEntity);
    exchange.getIn().setBody(auctionEventList);
    exchange.getIn().setHeader(KinesisConstants.PARTITION_KEY, cdcEntity.getPartitionKey());
    recordExternalCallTime(eventProcessStartTime, "tbox_process_event");
  }

  protected abstract void setMessageGroupId(AuctionEvent auctionEvent);


  protected List<AuctionEvent> executeRules(CdcEntity cdcEntity) {
    List<AuctionEvent> auctionEventList = new ArrayList<>();
    for (String ruleDef : getRules()) {
      AuctionEvent auctionEvent = buildAuctionEvent(cdcEntity);
      auctionEvent.setSourceTableName(
          AnnotationUtils.findAnnotation(cdcEntity.getClass(), XmlRootElement.class).name());

      auctionEvent.setTboxtimestamp(DateUtils.getCurrentSystemTimestampInString());
      if (cdcEntity.getDataEventChgIndList() != null)
        auctionEvent.setChangestatus(cdcEntity.getChangestatus());
      setMDCValuesForLogging(auctionEvent);
      executeBpm(ruleDef, cdcEntity, auctionEvent);
      if (valid(auctionEvent)) {
        auctionEventList.add(auctionEvent);
        logWrapper.info(this.getClass(), auctionEvent.toString());
        setMessageGroupId(auctionEvent);

        if (auctionEvent.getSourceEventName() == null) {
          auctionEvent.setSourceEventName(auctionEvent.getEventType());
        }


        if (auctionEvent.isHeartbeat()) {
          metricReporter.incrementHeartbeatProcessed(EVENT_TYPE_LABEL + auctionEvent.getEventType(),
              AUCTION_CODE_LABEL + auctionEvent.getAuctionCode(),
              VIN_LABEL + auctionEvent.getVin());
        } else {
          metricReporter.incrementEventProcessed(EVENT_TYPE_LABEL + auctionEvent.getEventType(),
              AUCTION_CODE_LABEL + auctionEvent.getAuctionCode(),
              VIN_LABEL + auctionEvent.getVin());

        }
      }
    }
    return auctionEventList;
  }

  protected void executeBpm(String ruleDef, CdcEntity cdcEntity, AuctionEvent auctionEvent) {
    auctionEventsRuleManager.process(ruleDef, cdcEntity, auctionEvent);

  }


  private CdcEntity getCdcEntity(Exchange exchange) throws JAXBException {
    String inputMessage = exchange.getIn().getBody(String.class);
    return extractCdcEntityFromMessage(inputMessage);
  }

  public abstract AuctionEvent buildAuctionEvent(CdcEntity cdcEntity);

  public boolean valid(AuctionEvent auctionEvent) {
    String eventType = auctionEvent.getEventType();


    if (eventType != null) {
      String[] validEventTypes = getValidEventTypes();
      return ArrayUtils.contains(validEventTypes, eventType);
    } else {
      return false;
    }
  }

  public abstract String[] getValidEventTypes();


  /**
   * Override this method in subclasses based on Event processing requirements
   * 
   * @return
   */
  public String[] getRules() {
    return new String[] {};
  }

  private void setMDCValuesForLogging(AuctionEvent event) {
    MDC.put("eventType", event.getEventType());
    MDC.put("auctionCode", event.getAuctionCode());
    if (null != event.getWorkOrder()) {
      MDC.put("workOrder", event.getWorkOrder());
    }
    if (null != event.getSblu()) {
      MDC.put("sblu", event.getSblu());
    }
    if (null != event.getVin()) {
      MDC.put("vin", event.getVin());
    }
    if (null != event.getSaleYear()) {
      MDC.put("saleYear", String.valueOf(event.getSaleYear()));
      MDC.put("saleNumber", String.valueOf(event.getSaleNumber()));
      MDC.put("laneNumber", String.valueOf(event.getLaneNumber()));
      MDC.put("runNumber", String.valueOf(event.getRunNumber()));
    }
  }


  private void recordExternalCallTime(long eventProcessStartTime, String serviceName) {
    long timeTakenInMillis = System.currentTimeMillis() - eventProcessStartTime;
    metricReporter.recordExternalCallTime(timeTakenInMillis,
        String.format("service-name:%s", serviceName), "service-uri:/", "http-method:POST",
        "http-status:200");
  }


  public CdcEntity extractCdcEntityFromMessage(String inputMessage) throws JAXBException {
    Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
    return (CdcEntity) unmarshaller.unmarshal(new StringReader(inputMessage));
  }
}
