package com.manheim.ods.compx.consumer.route;

import org.apache.camel.builder.RouteBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.consumer.processor.vehicle.VehicleChargesEventProcessor;
import com.manheim.ods.compx.consumer.processor.vehicle.VehicleEventProcessor;

@Component
public class VehicleRouteBuilder extends RouteBuilder {
  @Autowired
  VehicleEventProcessor vehicleEventProcessor;
  @Autowired
  VehicleChargesEventProcessor vehicleChargesEventProcessor;

  @Autowired
  ObjectMapper objectMapper;

  Logger logger = LoggerFactory.getLogger(this.getClass());

  @Override
  public void configure() throws Exception {
    from("direct:compx-vehicle-route").id("compx-vehicle-route").autoStartup(true).startupOrder(10).multicast()
        .stopOnException()
        .to("direct:compx-inventory-route", "direct:compx-inventory-charges-route");

    from("direct:compx-inventory-route").bean(vehicleEventProcessor).to("direct:send-tbox-events");

    from("direct:compx-inventory-charges-route").bean(vehicleChargesEventProcessor)
        .to("direct:send-tbox-events");

  }

}
