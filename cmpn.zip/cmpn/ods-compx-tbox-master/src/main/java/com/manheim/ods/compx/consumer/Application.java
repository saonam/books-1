package com.manheim.ods.compx.consumer;

import javax.jms.ConnectionFactory;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.activemq.spring.ActiveMQConnectionFactory;
import org.apache.camel.component.jms.JmsComponent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.manheim.bee.entity.BusinessEvent;
import com.manheim.ods.compx.consumer.config.StreamConfiguration;
import com.manheim.ods.compx.consumer.route.EventTypeValidator;
import com.manheim.ods.compx.consumer.rules.DroolsAutoConfiguration;
import com.manheim.ods.compx.setup.ApplicationConfig;
import com.manheim.xods.entity.Auctionheartbeat;
import com.manheim.xods.entity.Pfpsi;
import com.manheim.xods.entity.Pfrecon;
import com.manheim.xods.entity.Pfsadjdtl;
import com.manheim.xods.entity.Pfvehext;
import com.manheim.xods.entity.Pfvehicle;
import com.manheim.xods.entity.Tprmktbl;

/**
 * A sample Spring Boot application that starts the Camel routes.
 */
@SpringBootApplication
@EnableJms
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class})
@Configuration
@Import({DroolsAutoConfiguration.class, StreamConfiguration.class, ApplicationConfig.class})
@ComponentScan(basePackages = {"com.manheim.ods.compx.route", "com.manheim.ods.compx.consumer",
    "com.manheim.ods.compx.util", "com.manheim.ods.compx.web"})
public class Application {

  @Value("${spring.activemq.password}")
  private String activeMQPassword;

  @Value("${spring.activemq.user}")
  private String activeMQUserName;
  @Autowired
  @Value("${spring.activemq.broker-url}")
  String activeMQUrl;
  @Autowired
  @Value("${bee.activemq.broker-url}")
  String beeActiveMQUrl;
  @Value("${valid.event.types}")
  String[] validEventTypes;

  /**
   * A main method to start this application.
   */
  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

  @Bean(name = "activemq-cf")
  @Primary
  public ConnectionFactory buildConnectionFactory() {
    ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory();
    activeMQConnectionFactory.setBrokerURL(activeMQUrl);
    activeMQConnectionFactory.setUserName(activeMQUserName);
    activeMQConnectionFactory.setPassword(activeMQPassword);
    return new CachingConnectionFactory(activeMQConnectionFactory);

  }


  @Bean(name = "bee-activemq-cf")
  public ConnectionFactory buildBeeActiveMQConnectionFactory() {
    ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory();
    activeMQConnectionFactory.setBrokerURL(beeActiveMQUrl);
    activeMQConnectionFactory.setUserName(activeMQUserName);
    activeMQConnectionFactory.setPassword(activeMQPassword);
    return new CachingConnectionFactory(activeMQConnectionFactory);

  }

  @Bean(name = "ods-bee-inbound-jms")
  public JmsComponent buildBeeJmsComponent() {
    return JmsComponent.jmsComponentAutoAcknowledge(buildBeeActiveMQConnectionFactory());
  }

  @Bean(name = "ods-compx-jms")
  @Primary
  public JmsComponent buildJmsComponent() {
    return JmsComponent.jmsComponentAutoAcknowledge(buildConnectionFactory());
  }

  @Bean
  @Primary
  public RestTemplate restTemplate() {
    return new RestTemplate();
  }

  @Bean

  public JAXBContext buildJaxbContext() throws JAXBException {
    Class[] marshallingRequiredClasses = {Pfvehicle.class, Pfrecon.class, Pfvehext.class,
        Auctionheartbeat.class, BusinessEvent.class, Tprmktbl.class, Pfsadjdtl.class, Pfpsi.class};
    JAXBContext jc = JAXBContext.newInstance(marshallingRequiredClasses);
    return jc;

  }

  @Bean
  public ObjectMapper buildObjectMapper() {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
    return objectMapper;

  }

  @Bean(name = "tbox")
  public AmazonKinesis eventsClient() {

    AmazonKinesisClientBuilder clientBuilder = AmazonKinesisClientBuilder.standard();
    clientBuilder.withRegion(Regions.US_EAST_1);
    clientBuilder.withCredentials(new DefaultAWSCredentialsProviderChain());
    return clientBuilder.build();

  }

  @Bean(name = "eventTypeValidator")
  public EventTypeValidator buildEventTypeValidator() {
    return new EventTypeValidator(validEventTypes);
  }

}
