package com.manheim.bee.entity;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@XmlRootElement(namespace = "http://webservices.manheim.com/", name = "inventoryItem")
@XmlAccessorType(XmlAccessType.FIELD)
public class InventoryItem implements Serializable {
  private static final long serialVersionUID = -2229751526127511644L;
  private String legacyRedeemedDate;
}
