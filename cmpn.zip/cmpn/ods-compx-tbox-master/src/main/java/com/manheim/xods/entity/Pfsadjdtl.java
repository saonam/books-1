package com.manheim.xods.entity;


import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
@XmlRootElement(name = "PFSADJDTL")
public class Pfsadjdtl extends CdcEntity {
  private static final long serialVersionUID = 8364993733109322764L;
  private PfsadjdtlId id;
  private String ajcode;
  private String ajdesc;
  private String ajnote;
  private BigDecimal ajamt;
  private int ajglacct;
  private String ajusradd;
  private int ajdteadd;
  private int ajtmeadd;
  private String ajpgmadd;
  private String ajusrpfn;
  private int ajdtepfn;
  private int ajtmepfn;
  private String ajpgmpfn;
  private String ajusrpst;
  private int ajdtepst;
  private int ajtmepst;
  private String ajpgmpst;
  private char ajvehhist;
  private char ajflag1;
  private char ajflag2;
  private char ajflag3;
  private int ajdte1;
  private int ajdte2;
  private int ajdte3;
  private String ajuser1;
  private String ajuser2;
  private String ajuser3;
  private String updatedby;

  @Override
  public String getPartitionKey() {
    return String.format("%s:%s", this.id.getAjauci(), this.id.getAjsale());
  }

}