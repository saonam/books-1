package com.manheim.ods.compx.consumer.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.stereotype.Component;

@Component
@EnableJms
public class ChangeDataCaptureRouteBuilder extends RouteBuilder {
  private static final String CDC_MSG_ROUTE = "direct:processCdcMessage";

  @Override
  public void configure() throws Exception {
    from(CDC_MSG_ROUTE).id("process-cdc-message").autoStartup(true).startupOrder(15)
        .to("direct:cdc-message-filter");

    from("direct:cdc-message-filter").choice()
        .when(xpath("/*[updatedby='HISTUSER' and (changestatus='I' or changestatus='D')]"))
        .to("log:com.manheim?level=WARN&groupSize=100")
        .when(xpath("/*[updatedby='BEEUSER' or updatedby='MMRUSER']"))
        .to("log:com.manheim?level=WARN&groupSize=100").otherwise()
        .to("direct:handle-exceptions");

    /*
     * G2GBUYSELL updates on PFVEHICLE need to be processed. 
     * Any other table updates by G2GBUYSELL can be ignored.  
     */
    from("direct:handle-exceptions")
        .choice()
            .when(xpath("name(/*)='PFVEHICLE'"))
                .to("direct:process-valid-updates")
            .otherwise()
                .choice()
                    .when(xpath("/*[updatedby='G2GBUYSELL']")).to("log:com.manheim?level=WARN")
                    .otherwise().to("direct:process-valid-updates");

    from("direct:process-valid-updates").autoStartup(true).startupOrder(25)
        .to("log:com.manheim?level=INFO&showAll=true&multiline=true").choice()
        .when(xpath("name(/*)='PFVEHICLE'")).to("direct:compx-vehicle-route")
        .when(xpath("name(/*)='PFRECON'")).to("direct:compx-recon-route")
        .when(xpath("name(/*)='PFVEHEXT'")).to("direct:compx-vehicle-ext-route")
        .when(xpath("name(/*)='TPRMKTBL'")).to("direct:compx-thirdparty-remarketing-route")
        .when(xpath("name(/*)='PFSADJDTL'")).to("direct:compx-adjustment-route")
        .when(xpath("name(/*)='PFPSI'")).to("direct:compx-postsale-inspection-route")
        .when(xpath("name(/*)='AUCTIONHEARTBEAT'")).to("direct:heartbeat-route").otherwise()
        .to("log:com.manheim?level=DEBUG");


  }
}
