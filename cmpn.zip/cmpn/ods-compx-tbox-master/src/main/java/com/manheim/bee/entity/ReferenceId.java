package com.manheim.bee.entity;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@NoArgsConstructor
@ToString
@XmlRootElement(namespace = "http://webservices.manheim.com/", name = "ReferenceId")
@XmlAccessorType(XmlAccessType.FIELD)
public class ReferenceId implements Serializable {

  private static final long serialVersionUID = 7940988510525292307L;
  /*
   * <referenceId> <auctionCode>NAA</auctionCode> <sblu>11690345</sblu>
   * <workOrder>3926298</workOrder> <listingId>0</listingId> <vin>WBA3B5C52FF961987</vin>
   * </referenceId>
   * 
   */
  private String vin;
  private String auctionCode;
  private long workOrder;
  private long sblu;
}
