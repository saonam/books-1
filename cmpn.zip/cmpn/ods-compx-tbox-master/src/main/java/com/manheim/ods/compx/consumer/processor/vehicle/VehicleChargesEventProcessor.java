package com.manheim.ods.compx.consumer.processor.vehicle;

import java.util.Optional;

import javax.xml.bind.JAXBContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.EventProcessor;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;
import com.manheim.xods.entity.Pfvehicle;

@Component
public class VehicleChargesEventProcessor extends EventProcessor {


  @Autowired
  public VehicleChargesEventProcessor(AuctionEventsRuleManager auctionEventsRuleManager,
      LogWrapper logWrapper, JAXBContext jaxbContext, MetricReporter metricReporter) {
    super(auctionEventsRuleManager, logWrapper, metricReporter, jaxbContext);
  }

  @Override
  public String[] getRules() {
    return new String[] {"com.manheim.attc.vehicle.seller.charges.changed",
        "com.manheim.attc.vehicle.buyer.charges.changed"};
  }

  @Override
  public String[] getValidEventTypes() {
    return new String[] {"SELLER_CHARGES_CHANGED", "BUYER_CHARGES_CHANGED"};
  }

  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {
    Pfvehicle pfvehicle = (Pfvehicle) cdcEntity;

    String vin = String.format("%s%s%s%s%s%s%s%s%s%s%s%s", checkNullString(pfvehicle.getSser1s()),
        checkNullString(pfvehicle.getSser2n()), checkNullString(pfvehicle.getSser3t()),
        checkNullString(pfvehicle.getSser4t()), checkNullString(pfvehicle.getSser5t()),
        checkNullString(pfvehicle.getSser6t()), checkNullString(pfvehicle.getSser7t()),
        checkNullString(pfvehicle.getSser8t()), checkNullString(pfvehicle.getSsercd()),
        checkNullString(pfvehicle.getSsermy()), checkNullString(pfvehicle.getSser11()),
        checkNullString(pfvehicle.getSserl6()));
    AuctionEvent auctionEvent = AuctionEvent.builder().auctionCode(pfvehicle.getId().getSauci())
        .vin(vin).workOrder(String.valueOf(pfvehicle.getId().getSwo()))
        .sblu(String.valueOf(pfvehicle.getId().getSblu()))
        .cdcjournaltimestamp(pfvehicle.getCdctimestamp()).cdcUserId(pfvehicle.getUpdatedby())
        .prevBuyerDealerId(pfvehicle.getPrevSbuyer()).prevSellerDealerId(pfvehicle.getPrevSsellr())
        .build();


    auctionEvent.setMessageGroupId(String.format("%s:%s:%s", auctionEvent.getAuctionCode(),
        auctionEvent.getSblu(), auctionEvent.getEventType()));
    return auctionEvent;
  }

  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(String.format("%s:%s:%s", auctionEvent.getAuctionCode(),
        auctionEvent.getWorkOrder(), auctionEvent.getEventType()));

  }


  private String checkNullString(String field) {
    return Optional.ofNullable(field).orElse("");

  }
}
