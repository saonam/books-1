package com.manheim.xods.entity;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
@XmlRootElement(name = "AUCTIONHEARTBEAT")
@XmlAccessorType(XmlAccessType.FIELD)
public class Auctionheartbeat extends CdcEntity {

  private static final long serialVersionUID = -9099199033929514229L;

  private AuctionheartbeatId id;

  private String auctionid;

  private String auctionuniqueid;

  private String auctioniduniqueid;

  private String cdcjournaltimestamp;

  @Override
  public String getPartitionKey() {
    return auctioniduniqueid;
  }
}
