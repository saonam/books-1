package com.manheim.ods.compx.consumer.route;

import org.apache.camel.TypeConversionException;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
@EnableJms
public class ExchangeRouteBuilder extends RouteBuilder {
  @Value("${activemq.source.queues}")
  private String activemqSourceQueues;
  @Autowired
  XmlCleanerUtil xmlCleanerUtil;
  private static final String CDC_MSG_ROUTE = "direct:processCdcMessage";

  @Override
  public void configure() throws Exception {

    // identify the xml message and route to respective table router
    String[] activemqSourceQueuesArray =
        StringUtils.commaDelimitedListToStringArray(activemqSourceQueues);
    int startupOrder = 100;

    onException(TypeConversionException.class).filter(header("message.retry").isNotEqualTo("true"))
        .bean(xmlCleanerUtil).setHeader("message.retry", simple("true")).to(CDC_MSG_ROUTE)
        .log(String.format("Reprocess for TypeConversionException %s", body()));
    for (String activemqSourceQueue : activemqSourceQueuesArray) {
      from(String.format("ods-compx-jms:%s?concurrentConsumers=1", activemqSourceQueue))
          .autoStartup(true).startupOrder(startupOrder++).to(CDC_MSG_ROUTE);
    }



  }
}
