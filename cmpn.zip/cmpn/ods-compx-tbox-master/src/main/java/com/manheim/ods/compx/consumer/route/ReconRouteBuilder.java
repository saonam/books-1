package com.manheim.ods.compx.consumer.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.vehicle.ReconEventProcessor;

@Component
public class ReconRouteBuilder extends RouteBuilder {
  @Autowired
  ReconEventProcessor reconEventProcessor;

  @Override
  public void configure() throws Exception {
    from("direct:compx-recon-route").autoStartup(true).startupOrder(11).bean(reconEventProcessor)
        .to("direct:send-tbox-events").to("log:com.manheim?level=info");

  }

}
