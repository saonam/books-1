package com.manheim.xods.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PfreconId implements java.io.Serializable {

  private static final long serialVersionUID = 2703212378672179251L;
  private String rcauci;
  private int rcwo;
  private int rcmenu;
  private short rcrec;
}
