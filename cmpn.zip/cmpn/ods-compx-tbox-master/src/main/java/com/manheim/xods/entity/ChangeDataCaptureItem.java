package com.manheim.xods.entity;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class ChangeDataCaptureItem implements Serializable {
private static final long serialVersionUID = 1757593163162466713L;
private String dataEventField;
}
