package com.manheim.ods.compx.consumer.processor.vehicle;

import javax.xml.bind.JAXBContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.EventProcessor;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;
import com.manheim.xods.entity.Pfrecon;

@Component
public class ReconEventProcessor extends EventProcessor {


  @Autowired
  public ReconEventProcessor(AuctionEventsRuleManager auctionEventsRuleManager,
      LogWrapper logWrapper, JAXBContext jaxbContext, MetricReporter metricReporter) {
    super(auctionEventsRuleManager, logWrapper, metricReporter, jaxbContext);
  }

  @Override
  public String[] getRules() {
    return new String[] {"com.manheim.tbox.recon.charges.changed"};
  }


  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {
    Pfrecon pfrecon = (Pfrecon) cdcEntity;
    AuctionEvent auctionEvent = AuctionEvent.builder().auctionCode(pfrecon.getId().getRcauci())
        .cdcjournaltimestamp(pfrecon.getCdctimestamp()).cdcUserId(pfrecon.getUpdatedby())
        .workOrder(String.valueOf(pfrecon.getId().getRcwo())).build();


    auctionEvent.setMessageGroupId(String.format("%s:%s:%s", auctionEvent.getAuctionCode(),
        auctionEvent.getWorkOrder(), auctionEvent.getEventType()));
    return auctionEvent;
  }

  @Override
  public String[] getValidEventTypes() {
    return new String[] {"SELLER_CHARGES_CHANGED", "BUYER_CHARGES_CHANGED"};
  }

  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(String.format("%s:%s:%s", auctionEvent.getAuctionCode(),
        auctionEvent.getWorkOrder(), auctionEvent.getEventType()));

  }

}
