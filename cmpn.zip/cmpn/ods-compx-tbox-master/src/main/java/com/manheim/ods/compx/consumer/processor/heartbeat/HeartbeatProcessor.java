package com.manheim.ods.compx.consumer.processor.heartbeat;

import javax.xml.bind.JAXBContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.EventProcessor;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.Auctionheartbeat;
import com.manheim.xods.entity.CdcEntity;

@Component
@RefreshScope
public class HeartbeatProcessor extends EventProcessor {

  String testAuctionCode;
  String testVin;
  String testSblu;
  String testWorkOrder;


  @Autowired
  public HeartbeatProcessor(LogWrapper logWrapper, JAXBContext jaxbContext,
      @Value("${heartbeat.test.auction}") String testAuctionCode,
      @Value("${heartbeat.test.vin}") String testVin,
      @Value("${heartbeat.test.sblu}") String testSblu,
      @Value("${heartbeat.test.workOrder}") String testWorkOrder, MetricReporter metricReporter) {
    super(null, logWrapper, metricReporter, jaxbContext);
    this.testAuctionCode = testAuctionCode;
    this.testVin = testVin;
    this.testSblu = testSblu;
    this.testWorkOrder = testWorkOrder;
  }

  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {

    Auctionheartbeat auctionHeartbeat = (Auctionheartbeat) cdcEntity;


    AuctionEvent auctionEvent = AuctionEvent.builder().auctionid(auctionHeartbeat.getAuctionid())
        .heartbeatseqno(auctionHeartbeat.getId().getHeartbeatseqno()).eventType("HEARTBEAT")
        .auctionuniqueid(auctionHeartbeat.getAuctionuniqueid())
        .auctioniduniqueid(auctionHeartbeat.getAuctioniduniqueid())
        .auctionid(auctionHeartbeat.getAuctionid())
        .cdcjournaltimestamp(auctionHeartbeat.getCdcjournaltimestamp())
        .tboxtimestamp(DateUtils.getCurrentSystemTimestampInString()).auctionCode(testAuctionCode)
        .vin(testVin).workOrder(testWorkOrder).sblu(testSblu).build();

    auctionEvent.setHeartbeat(true);

    return auctionEvent;
  }

  @Override
  public boolean valid(AuctionEvent auctionEvent) {

    String auctionId = auctionEvent.getAuctionid();
    // xQNM41 - Valid auctionId
    return null != auctionId && auctionId.startsWith("x") && auctionId.endsWith("1");
  }


  @Override
  public void executeBpm(String ruleDef, CdcEntity cdcEntity, AuctionEvent auctionEvent) {
    // do nothing here. Since we dont have a bpm for Service Order Created Event
    logWrapper.info(this.getClass(), "Heartbeat process Event rules");
  }

  @Override
  public String[] getRules() {
    return new String[] {"com.manheim.attc.heartbeat"};
  }


  @Override
  public String[] getValidEventTypes() {
    return new String[] {};
  }

  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(String.format("%s:%s:%s", auctionEvent.getAuctionCode(),
        auctionEvent.getSblu(), auctionEvent.getEventType()));


  }

}
