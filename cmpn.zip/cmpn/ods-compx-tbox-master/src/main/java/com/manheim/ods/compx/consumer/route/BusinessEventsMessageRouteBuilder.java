package com.manheim.ods.compx.consumer.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.bee.BuyerOrderBuyerNumberChangedEventProcessor;
import com.manheim.ods.compx.consumer.processor.bee.SellerInventoryReleasedEventProcessor;
import com.manheim.ods.compx.consumer.processor.bee.SellerOfferingPurchasedEventProcessor;
import com.manheim.ods.compx.consumer.processor.bee.ServiceOrderCreatedEventProcessor;

@Component
@EnableJms
public class BusinessEventsMessageRouteBuilder extends RouteBuilder {
  private static final String SEND_TBOX_EVENTS_ROUTE = "direct:send-tbox-events";
  private static final String MSG_TYPE = "MSG_TYPE";
  @Autowired
  ServiceOrderCreatedEventProcessor serviceOrderCreatedEventProcessor;
  @Autowired
  SellerInventoryReleasedEventProcessor sellerInventoryReleasedEventProcessor;
  @Autowired
  SellerOfferingPurchasedEventProcessor sellerOfferingPurchasedEventProcessor;
  @Autowired
  BuyerOrderBuyerNumberChangedEventProcessor buyerOrderBuyerNumberChangedEventProcessor;

  @Override
  public void configure() throws Exception {

    from("direct:processBeeMessage").id("process-bee-message").autoStartup(true).startupOrder(20)
        .to("log:com.manheim?level=INFO&showAll=true&multiline=true").choice()
        .when(header(MSG_TYPE).isEqualTo("Service Order Created"))
        .bean(serviceOrderCreatedEventProcessor).to(SEND_TBOX_EVENTS_ROUTE)
        .when(header(MSG_TYPE).isEqualTo("Seller Inventory Released"))
        .bean(sellerInventoryReleasedEventProcessor).to(SEND_TBOX_EVENTS_ROUTE)
        .when(header(MSG_TYPE).isEqualTo("Seller Offering Purchased"))
        .bean(sellerOfferingPurchasedEventProcessor).to(SEND_TBOX_EVENTS_ROUTE)
        .when(header(MSG_TYPE).isEqualTo("Buyer Order Buyer Number Changed"))
        .bean(buyerOrderBuyerNumberChangedEventProcessor).to(SEND_TBOX_EVENTS_ROUTE).otherwise()
        .to("log:com.manheim?level=WARN&showAll=true&multiline=true");


  }
}
