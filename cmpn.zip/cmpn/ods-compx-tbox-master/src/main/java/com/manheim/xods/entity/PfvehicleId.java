package com.manheim.xods.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PfvehicleId implements java.io.Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  private String sauci;
  private int swo;
  private int sblu;
}
