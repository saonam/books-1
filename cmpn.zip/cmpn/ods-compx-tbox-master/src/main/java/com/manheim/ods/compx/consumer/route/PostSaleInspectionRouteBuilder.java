package com.manheim.ods.compx.consumer.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.manheim.ods.compx.consumer.processor.vehicle.PostSaleInspectionEventProcessor;

@Component
public class PostSaleInspectionRouteBuilder extends RouteBuilder {
  @Autowired
  PostSaleInspectionEventProcessor psiEventProcessor;

  @Override
  public void configure() throws Exception {
    from("direct:compx-postsale-inspection-route").autoStartup(true).startupOrder(28).bean(psiEventProcessor)
        .to("direct:send-tbox-events").to("log:com.manheim?level=info");

  }

}
