package com.manheim.xods.entity;


import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 */
@Getter
@Setter
@NoArgsConstructor
@ToString
@XmlRootElement(name = "PFVEHEXT")
public class Pfvehext extends CdcEntity {

  private static final long serialVersionUID = 7268694370604786448L;
  private PfvehextId id;
  private int vsfafee;
  private int vbfafee;
  private int vbsufee;
  private int vssufee;
  private String updatedby;

  @Override
  public String getPartitionKey() {
    return String.format("%s:%s", this.id.getVauci(), this.id.getVblu());
  }
}
