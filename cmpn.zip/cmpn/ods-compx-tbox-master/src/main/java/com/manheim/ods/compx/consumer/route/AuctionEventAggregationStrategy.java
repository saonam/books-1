package com.manheim.ods.compx.consumer.route;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.processor.aggregate.AggregationStrategy;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.manheim.ods.compx.model.eventer.AuctionEvent;

public class AuctionEventAggregationStrategy implements AggregationStrategy {
  Logger logger = LoggerFactory.getLogger(AuctionEventAggregationStrategy.class);

  @Override
  public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {

    Message newIn = newExchange.getIn();
    // handle first message in the aggregate
    if (oldExchange == null) {
      // No action to take since we dont have an existing list to work upon
      List<AuctionEvent> auctionEventList = new ArrayList<>();
      auctionEventList.add(newExchange.getIn().getBody(AuctionEvent.class));
      newExchange.getIn().setBody(auctionEventList);
      return newExchange;
    }

    // the existing aggregated list
    List<AuctionEvent> oldAggregatedAuctionEventList = oldExchange.getIn().getBody(List.class);
    // incoming event
    AuctionEvent newAuctionEvent = newIn.getBody(AuctionEvent.class);

    /*
     * verify if new Auction Event has same event type as the last record in the old aggregated list
     * If same, replace latest auction event with the new Auction Event If not same, add the auction
     * event to the list
     */
    AuctionEvent latestRecordInOldAggregatedList =
        oldAggregatedAuctionEventList.get(oldAggregatedAuctionEventList.size() - 1);
    oldAggregatedAuctionEventList =
        findAndRemoveEvent(oldAggregatedAuctionEventList, newAuctionEvent);
    if (eligible(oldAggregatedAuctionEventList, newAuctionEvent)) {
      oldAggregatedAuctionEventList.add(newAuctionEvent);
    }

    newExchange.getIn().setBody(oldAggregatedAuctionEventList);

    logger.info("Aggregation Complete for {}", newAuctionEvent.getMessageGroupId());
    logger.info("[Aggregated Output] : {}", newExchange.getIn().getBody());
    logger.info("Logging complete for Aggregation {}, Table: {}, Size: {}",
        newAuctionEvent.getMessageGroupId(), newAuctionEvent.getSourceTableName(),
        oldAggregatedAuctionEventList.size());

    return newExchange;
  }

  private List<AuctionEvent> findAndRemoveEvent(List<AuctionEvent> oldAggregatedAuctionEventList,
      AuctionEvent newAuctionEvent) {
    return oldAggregatedAuctionEventList.stream()
        .filter(oldAggregatedAuctionEvent -> !same(oldAggregatedAuctionEvent, newAuctionEvent))
        .collect(Collectors.toList());
  }

  private boolean same(AuctionEvent oldAuctionEvent, AuctionEvent newAuctionEvent) {
    boolean sameEventType =
        StringUtils.equals(oldAuctionEvent.getEventType(), newAuctionEvent.getEventType());

    // ignore if the new auction event's prev buyer dealer id is empy.
    // True if old and new auction event has the same prev buyer dealer id
    boolean emptyPrevBuyerDealerId = oldAuctionEvent.getPrevBuyerDealerId() == null;
    return sameEventType && emptyPrevBuyerDealerId;
  }

  private boolean eligible(List<AuctionEvent> oldAggregatedAuctionEventList,
      AuctionEvent newAuctionEvent) {
    Optional<AuctionEvent> oldAuctionEvent = oldAggregatedAuctionEventList.stream()
        .filter(oldAggregatedAuctionEvent -> oldAggregatedAuctionEvent.getEventType()
            .equals(newAuctionEvent.getEventType()))
        .findFirst();

    if (oldAuctionEvent.isPresent()) {
      return newAuctionEvent.getPrevBuyerDealerId() != null && !StringUtils.equals(
          newAuctionEvent.getPrevBuyerDealerId(), oldAuctionEvent.get().getPrevBuyerDealerId());
    } else {
      return true;
    }
  }

}
