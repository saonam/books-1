package com.manheim.xods.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 */
@Getter
@Setter
@NoArgsConstructor
public class TprmktblId implements java.io.Serializable {

  private static final long serialVersionUID = 2703212378672179251L;
  private String tpauci;
  private int tpwo;
  private String active;
  private int tpbillr;

}
