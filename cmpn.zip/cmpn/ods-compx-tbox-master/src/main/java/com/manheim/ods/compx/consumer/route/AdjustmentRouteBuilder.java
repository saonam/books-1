package com.manheim.ods.compx.consumer.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.manheim.ods.compx.consumer.processor.vehicle.AdjustmentEventProcessor;


@Component
public class AdjustmentRouteBuilder extends RouteBuilder {
  @Autowired
  AdjustmentEventProcessor adjustmentEventProcessor;

  @Override
  public void configure() throws Exception {
    from("direct:compx-adjustment-route").autoStartup(true).startupOrder(26).bean(adjustmentEventProcessor)
        .to("direct:send-tbox-events").to("log:com.manheim?level=info");

  }

}
