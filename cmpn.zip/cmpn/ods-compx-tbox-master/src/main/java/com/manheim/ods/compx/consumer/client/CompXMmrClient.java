package com.manheim.ods.compx.consumer.client;

import java.net.MalformedURLException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;


@Component
public class CompXMmrClient {

  private RestTemplate restTemplate;
  private String compxMmrAuthorization;
  private String compxMmrApiEndpoint;
  private MetricReporter metricReporter;
  private ObjectMapper jacksonObjectMapper;

  @Autowired
  private static final Logger LOG = LoggerFactory.getLogger(CompXMmrClient.class);

  @Autowired
  public CompXMmrClient(RestTemplate restTemplate, MetricReporter metricReporter,
      @Value("${compxmmr.api.endpoint}") String compxMmrApiEndpoint,
      @Value("${compxmmr.authorization}") String compxMmrAuthorization,
      ObjectMapper jacksonObjectMapper) {
    this.restTemplate = restTemplate;
    this.metricReporter = metricReporter;
    this.compxMmrApiEndpoint = compxMmrApiEndpoint;
    this.compxMmrAuthorization = compxMmrAuthorization;
    this.jacksonObjectMapper = jacksonObjectMapper;
  }

  public Integer postToCompXMmr(AuctionEvent auctionEvent, Class originClass)
      throws JsonProcessingException {
    long startApiCall = System.currentTimeMillis();
    String requestBody = jacksonObjectMapper.writeValueAsString(auctionEvent);

    HttpHeaders headers = new HttpHeaders();
    headers.add("Authorization", compxMmrAuthorization);

    if (auctionEvent.isHeartbeat()) {
      headers.add("Shard-Id",
          String.format("%s:%s", auctionEvent.getAuctionid(), auctionEvent.getVin()));
      headers.add("source", "heartbeat");
    } else {
      headers.add("Shard-Id",
          String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getVin()));
    }
    headers.setContentType(MediaType.APPLICATION_JSON);
    HttpEntity<String> httpEntity = new HttpEntity<>(requestBody, headers);

    ResponseEntity<String> responseEntity =
        restTemplate.exchange(compxMmrApiEndpoint, HttpMethod.POST, httpEntity, String.class);
    URL url;
    try {
      url = new URL(compxMmrApiEndpoint);
      long timeTaken = System.currentTimeMillis() - startApiCall;
      metricReporter.recordExternalCallTime(timeTaken,
          "service-name:" + originClass.getSimpleName(), "service-host:" + url.getHost(),
          "service-uri:" + url.getPath(), "http-method:POST",
          "http-status:" + responseEntity.getStatusCode().value());
    } catch (MalformedURLException e) {
      LOG.warn(String.format("Unable to log metrics. Bad CompX MMR URL : %s", compxMmrApiEndpoint),
          e);
    }


    return responseEntity.getStatusCode().value();
  }

}
