package com.manheim.ods.compx.consumer.route;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.consumer.processor.vehicle.ThirdPartyRemarketingEventProcessor;

@Component
public class ThirdPartyRemarketingRouteBuilder extends RouteBuilder {
  @Autowired
  ThirdPartyRemarketingEventProcessor thirdPartyRemarketingEventProcessor;

  @Override
  public void configure() throws Exception {
    from("direct:compx-thirdparty-remarketing-route").autoStartup(true)
        .bean(thirdPartyRemarketingEventProcessor).to("direct:send-tbox-events")
        .to("log:com.manheim?level=info");

  }

}
