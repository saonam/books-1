package com.manheim.ods.compx.consumer.processor.bee;

import javax.xml.bind.JAXBContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.bee.entity.BusinessEvent;
import com.manheim.bee.entity.BusinessEventMessageControl;
import com.manheim.bee.entity.ServiceOrderCreated;
import com.manheim.ods.compx.consumer.processor.NoRulesEventProcessor;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.CdcEntity;

@Component
public class ServiceOrderCreatedEventProcessor extends NoRulesEventProcessor {

  @Autowired
  public ServiceOrderCreatedEventProcessor(LogWrapper logWrapper, JAXBContext jaxbContext,
      MetricReporter metricReporter) {
    super(null, logWrapper, metricReporter, jaxbContext);
  }

  @Override
  public AuctionEvent buildAuctionEvent(CdcEntity cdcEntity) {

    BusinessEvent beeEvent = (BusinessEvent) cdcEntity;

    ServiceOrderCreated serviceOrderCreated =
        beeEvent.getEntityInformation().getServiceOrderCreated();

    String serviceOrderTypeCode = serviceOrderCreated.getServiceOrderTypeCode();

    String eventType = null;

    if ("SL".equals(serviceOrderTypeCode)) {
      eventType = "SELLER_SERVICE_ORDER_CREATED";
    }

    switch (serviceOrderTypeCode) {
      case "SL":
        eventType = "SELLER_SERVICE_ORDER_CREATED";
        break;
      case "BR":
        eventType = "BUYER_SERVICE_ORDER_CREATED";
        break;
    }

    BusinessEventMessageControl messageControl = beeEvent.getMessageControl();
    String strEventTimestamp = messageControl.getEventTimestamp();
    String timestampFormat = "yyyy-MM-dd'T'HH:mm:ss";
    String eventTimezone = "GMT";
    String requiredTimezone = "America/New_York";
    String eventTimestampEST = DateUtils.convertToTimezone(strEventTimestamp, timestampFormat,
        eventTimezone, requiredTimezone);

    return AuctionEvent.builder().auctionCode(serviceOrderCreated.getAuctionCode())
        .sblu(String.valueOf(serviceOrderCreated.getSblu())).vin(serviceOrderCreated.getVin())
        .workOrder(String.valueOf(serviceOrderCreated.getWorkOrder()))
        .tboxtimestamp(DateUtils.getCurrentSystemTimestampInString())
        .sourceTableName("SERVICE_ORDER").sourceEventName("SERVICE_ORDER_CREATED")
        .eventType(eventType)
        .cdcjournaltimestamp(DateUtils.fromSecondsToNanosTimestampString(eventTimestampEST))
        .sourceEventCreatedTimestamp(serviceOrderCreated.getTimeOfCreation())
        .cdcUserId(beeEvent.getMessageControl().getModifiedBy()).build();
  }

  @Override
  protected void setMessageGroupId(AuctionEvent auctionEvent) {
    auctionEvent.setMessageGroupId(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));


  }

}
