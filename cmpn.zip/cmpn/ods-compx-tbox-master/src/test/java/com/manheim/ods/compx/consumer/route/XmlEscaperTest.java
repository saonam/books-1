package com.manheim.ods.compx.consumer.route;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class XmlEscaperTest {
  XmlCleanerUtil xmlEscaper;

  @Mock
  Exchange exchange;
  @Mock
  Message message;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    xmlEscaper = new XmlCleanerUtil();
    when(exchange.getIn()).thenReturn(message);


  }

  @Test
  public void testXmlForSpecialCharacters() {
    String inputMessage =
        "<PFVEHICLE xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">    <scode>SR</scode>   <sdterd>0</sdterd>  <sdtere>2017214</sdtere>    <prev_sdtere>0</prev_sdtere>    <sdtesl>0</sdtesl>  <stimer>0</stimer>  <sser1s>1</sser1s>  <sser2n>C</sser2n>  <sser3t>4</sser3t>  <sser4t>N</sser4t>  <sser5t>J</sser5t>  <sser6t>P</sser6t>  <sser7t>B</sser7t>  <sser8t>B</sser8t>  <ssercd>2</ssercd>  <ssermy>F</ssermy>  <sser11>D</sser11>  <sserl6>178956</sserl6>     <sser17>1C4NJPBB2FD178956</sser17>  <sselln>CAPROCK AUTO REMARKETING & GREGS RV</sselln>  <ssellr>4T1BF1FK0GU189866</ssellr>  <prev_scode>RC</prev_scode>     <changestatus>U</changestatus>  <id>        <sblu>11748073</sblu>       <swo>5493964</swo>      <sauci>BIGH</sauci>     </id>   <dataEventChgIndList>       <item>          <dataEventField>SDTESL</dataEventField>         </item>         <item>          <dataEventField>SDTERD</dataEventField>         </item>         <item>          <dataEventField>SDTERE</dataEventField>         </item>     </dataEventChgIndList> </PFVEHICLE>";
    when(message.getBody(any())).thenReturn(inputMessage);

    try {
      xmlEscaper.process(exchange);
    } catch (Exception e) {

    }
  }


}
