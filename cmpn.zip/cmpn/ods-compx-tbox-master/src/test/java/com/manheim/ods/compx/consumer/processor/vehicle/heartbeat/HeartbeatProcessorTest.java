package com.manheim.ods.compx.consumer.processor.vehicle.heartbeat;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.contains;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.xml.bind.JAXBContext;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.processor.heartbeat.HeartbeatProcessor;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class HeartbeatProcessorTest {

  private AuctionEvent event;
  private Exchange exchange;
  private Message message;
  private HeartbeatProcessor heartbeatProcessor;
  private MetricReporter metricReporter;

  String testAuctionCode;
  String testVin;
  String testSblu;
  String testWorkOrder;

  private LogWrapper logWrapper;

  @Autowired
  JAXBContext jaxbContext;


  @Before
  public void setUp() throws Exception {

    event = mock(AuctionEvent.class);
    when(event.getAuctionCode()).thenReturn("QGM5");
    when(event.getVin()).thenReturn("2FMGK5CC7CA55B124");
    when(event.getSblu()).thenReturn("1262767");
    when(event.getWorkOrder()).thenReturn("3866393");
    when(event.getEventType()).thenReturn("HEARTBEAT");
    logWrapper = mock(LogWrapper.class);
    exchange = mock(Exchange.class);
    message = mock(Message.class);
    metricReporter = mock(MetricReporter.class);
    testAuctionCode = "QGM5";
    testVin = "2FMGK5CC7CA55B124";
    testSblu = "1262767";
    testWorkOrder = "3866393";
    heartbeatProcessor = new HeartbeatProcessor(logWrapper, jaxbContext, testAuctionCode, testVin,
        testSblu, testWorkOrder, metricReporter);
    when(exchange.getIn()).thenReturn(message);
  }

  @Test
  public void verifyProcess() throws Exception {

    String auctionHeartbeatXmlResponse =
        new CompXFileReader().fetchFileAsString("auctionheartbeat.xml");
    when(message.getBody(String.class)).thenReturn(auctionHeartbeatXmlResponse);

    heartbeatProcessor.process(exchange);
    verify(logWrapper).info(eq(HeartbeatProcessor.class), contains("eventType=HEARTBEAT"));
  }

  @Test
  public void testValidAuction() throws Exception {

    String auctionId = "xQNM41";
    String invalidAuctionId = "xQNM44";
    AuctionEvent auctionEvent = new AuctionEvent();
    auctionEvent.setAuctionid(auctionId);
    heartbeatProcessor.valid(auctionEvent);
    assertEquals(Boolean.TRUE, heartbeatProcessor.valid(auctionEvent));

    auctionEvent.setAuctionid(invalidAuctionId);
    assertEquals(Boolean.FALSE, heartbeatProcessor.valid(auctionEvent));
  }

}

