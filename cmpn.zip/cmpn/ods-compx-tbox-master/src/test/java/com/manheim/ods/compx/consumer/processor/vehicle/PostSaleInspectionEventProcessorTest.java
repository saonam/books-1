package com.manheim.ods.compx.consumer.processor.vehicle;

import static org.mockito.Matchers.contains;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.xml.bind.JAXBContext;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class PostSaleInspectionEventProcessorTest {
 
  private AuctionEvent event;
  private Exchange exchange;
  private Message message;
  private PostSaleInspectionEventProcessor psiEventProcessor;

  private LogWrapper logWrapper;

  @Autowired
  AuctionEventsRuleManager auctionEventsRuleManager;

  @Autowired
  JAXBContext jaxbContext;

  @Mock
  MetricReporter metricReporter;

  @Before
  public void setUp() throws Exception {

    event = mock(AuctionEvent.class);
    when(event.getAuctionCode()).thenReturn("QGM5");
    when(event.getSaleNumber()).thenReturn(12);
    when(event.getSaleYear()).thenReturn(2018);
    when(event.getLaneNumber()).thenReturn(78);
    when(event.getRunNumber()).thenReturn(23);
    when(event.getEventType()).thenReturn("BUYER_CHARGES_CHANGED");

    logWrapper = mock(LogWrapper.class);
    exchange = mock(Exchange.class);
    CamelContext camelContext = mock(CamelContext.class);
    when(camelContext.createProducerTemplate()).thenReturn(mock(ProducerTemplate.class));
    when(exchange.getContext()).thenReturn(camelContext);
    message = mock(Message.class);
    psiEventProcessor = new PostSaleInspectionEventProcessor(auctionEventsRuleManager, logWrapper,
        jaxbContext, metricReporter);

    when(exchange.getIn()).thenReturn(message);
  }

  @Test
  public void verifyPSIAdjustmentInsert() throws Exception {

    String pfpsiXmlResponse = new CompXFileReader().fetchFileAsString("pfpsi-insert.xml");
    when(message.getBody(String.class)).thenReturn(pfpsiXmlResponse);

    psiEventProcessor.process(exchange);
    verify(logWrapper).info(eq(PostSaleInspectionEventProcessor.class), contains("BUYER_CHARGES_CHANGED"));
  }

  @Test
  public void verifyPSIAdjustmentUpdate() throws Exception {

    String pfpsiXmlResponse = new CompXFileReader().fetchFileAsString("pfpsi-update.xml");
    System.out.println();
    when(message.getBody(String.class)).thenReturn(pfpsiXmlResponse);
    psiEventProcessor.process(exchange);
    verify(logWrapper).info(eq(PostSaleInspectionEventProcessor.class), contains("BUYER_CHARGES_CHANGED"));
  }

  @Test
  public void verifyPSIAdjustmentDelete() throws Exception {

    String pfpsiXmlResponse = new CompXFileReader().fetchFileAsString("pfpsi-delete.xml");
    when(message.getBody(String.class)).thenReturn(pfpsiXmlResponse);
    psiEventProcessor.process(exchange);
    verify(logWrapper).info(eq(PostSaleInspectionEventProcessor.class), contains("BUYER_CHARGES_CHANGED"));
  }

}
