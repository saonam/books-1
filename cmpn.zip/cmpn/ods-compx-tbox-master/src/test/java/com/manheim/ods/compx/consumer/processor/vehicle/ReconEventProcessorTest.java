package com.manheim.ods.compx.consumer.processor.vehicle;

import static org.mockito.Matchers.contains;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.xml.bind.JAXBContext;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class ReconEventProcessorTest {

  private AuctionEvent event;
  private Exchange exchange;
  private Message message;
  private ReconEventProcessor reconEventProcessor;

  private LogWrapper logWrapper;

  @Autowired
  AuctionEventsRuleManager auctionEventsRuleManager;

  @Autowired
  JAXBContext jaxbContext;

  @Mock
  MetricReporter metricReporter;

  @Before
  public void setUp() throws Exception {

    event = mock(AuctionEvent.class);
    // new AuctionEvent("QGM5", "2FMGK5CC7CA55B124", "1262767", "3866393");
    when(event.getAuctionCode()).thenReturn("QGM5");
    when(event.getWorkOrder()).thenReturn("3866393");
    when(event.getEventType()).thenReturn("SELLER_CHARGES_CHANGED");
    logWrapper = mock(LogWrapper.class);
    exchange = mock(Exchange.class);
    CamelContext camelContext = mock(CamelContext.class);
    when(camelContext.createProducerTemplate()).thenReturn(mock(ProducerTemplate.class));
    when(exchange.getContext()).thenReturn(camelContext);
    message = mock(Message.class);
    reconEventProcessor =
        new ReconEventProcessor(auctionEventsRuleManager, logWrapper, jaxbContext, metricReporter);

    when(exchange.getIn()).thenReturn(message);
  }

  @Test
  public void verifyReconInsert() throws Exception {

    String pfreconXmlResponse = new CompXFileReader().fetchFileAsString("pfrecon-insert.xml");
    when(message.getBody(String.class)).thenReturn(pfreconXmlResponse);

    reconEventProcessor.process(exchange);
    verify(logWrapper).info(eq(ReconEventProcessor.class), contains("SELLER_CHARGES_CHANGED"));
  }

  @Test
  public void verifyReconUpdate() throws Exception {

    String pfreconXmlResponse = new CompXFileReader().fetchFileAsString("pfrecon-update.xml");
    when(message.getBody(String.class)).thenReturn(pfreconXmlResponse);
    reconEventProcessor.process(exchange);
    verify(logWrapper).info(eq(ReconEventProcessor.class), contains("SELLER_CHARGES_CHANGED"));
  }

  @Test
  public void verifyReconDelete() throws Exception {

    String pfreconXmlResponse = new CompXFileReader().fetchFileAsString("pfrecon-delete.xml");
    when(message.getBody(String.class)).thenReturn(pfreconXmlResponse);
    reconEventProcessor.process(exchange);
    verify(logWrapper).info(eq(ReconEventProcessor.class), contains("SELLER_CHARGES_CHANGED"));
  }

}
