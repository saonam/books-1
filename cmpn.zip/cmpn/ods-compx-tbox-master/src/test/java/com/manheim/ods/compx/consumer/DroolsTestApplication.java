package com.manheim.ods.compx.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import com.manheim.ods.compx.consumer.rules.DroolsAutoConfiguration;

@Configuration
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class})
@Import(DroolsAutoConfiguration.class)
public class DroolsTestApplication {

  public static void main(String[] args) {
    SpringApplication.run(DroolsTestApplication.class, args);
  }
}
