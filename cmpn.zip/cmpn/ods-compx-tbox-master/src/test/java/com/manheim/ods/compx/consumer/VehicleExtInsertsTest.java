package com.manheim.ods.compx.consumer;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.xods.entity.Pfvehext;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class VehicleExtInsertsTest {

  @Autowired
  private AuctionEventsRuleManager vehicleEventsRuleManager;

  AuctionEvent auctionEvent;
  Pfvehext pfvehext;

  @Before
  public void setup() {
	  auctionEvent = AuctionEvent.builder().auctionCode("QGM5").vin("2FMGK5CC7CA55B124").workOrder("1262767").sblu("3866393").build();
	  pfvehext= new Pfvehext();
	  pfvehext.setChangestatus("I");
  }

  @Test
  public void vehicleExtInsertMsgShouldTriggerSellerChargesChangedEventWhenSellerSuccessFeesIsNotZero() {
	  pfvehext.setVssufee(25);
	  runBPMForSeller(auctionEvent, pfvehext);
	  
	  assertEquals("Positive test case, Event Type matched", "SELLER_CHARGES_CHANGED", auctionEvent.getEventType());
  }
  
  @Test
  public void vehicleExtInsertMsgShouldTriggerSellerChargesChangedEventWhenSellerFacilitationFeesIsNotZero() {
	  pfvehext.setVsfafee(10);
	  runBPMForSeller(auctionEvent, pfvehext);
	  
	  assertEquals("Positive test case, Event Type matched", "SELLER_CHARGES_CHANGED", auctionEvent.getEventType());
  }
  
  @Test
  public void vehicleExtInsertMsgShouldNotTriggerSellerChargesChangedEventWhenExtensionFeesIsZero() {
	  runBPMForSeller(auctionEvent, pfvehext);
	  
	  assertEquals("Negative test case, Event Type is null", null, auctionEvent.getEventType());
  }
  
  @Test
  public void vehicleExtInsertMsgShouldTriggerBuyerChargesChangedEventWhenBuyerFacilitationFeesIsNotZero() {
	  pfvehext.setVbfafee(10);
	  runBPMForBuyer(auctionEvent, pfvehext);
	  
	  assertEquals("Positive test case, Event Type matched", "BUYER_CHARGES_CHANGED", auctionEvent.getEventType());
  }
  
  @Test
  public void vehicleExtInsertMsgShouldTriggerBuyerChargesChangedEventWhenBuyerSuccessFeesIsNotZero() {
	  pfvehext.setVbsufee(30);
	  runBPMForBuyer(auctionEvent, pfvehext);
	  
	  assertEquals("Positive test case, Event Type matched", "BUYER_CHARGES_CHANGED", auctionEvent.getEventType());
  }
  
  @Test
  public void vehicleExtInsertMsgShouldNotTriggerBuyerChargesChangedEventWhenExtensionFeesIsZero() {
	  pfvehext.setVssufee(0);
	  pfvehext.setVsfafee(0);
	  pfvehext.setVbsufee(0);
	  pfvehext.setVbfafee(0);
	  runBPMForBuyer(auctionEvent, pfvehext);
	  assertEquals("Positive test case, Event Type matched", null, auctionEvent.getEventType());
  }
  
  @Test
  public void vehicleExtInvalidChangeStatusShouldNotTriggerChargesChangedEvent() {
	pfvehext.setChangestatus("X");
    runBPMForSeller(auctionEvent, pfvehext);

    assertEquals("Negative test case, Event Type is null", null, auctionEvent.getEventType());
  }

  private void runBPMForSeller(AuctionEvent auctionEvent, Pfvehext pfvehext) {
    vehicleEventsRuleManager.process("com.manheim.tbox.vehicle.extension.seller.charges.changed", pfvehext, auctionEvent);
  }

  private void runBPMForBuyer(AuctionEvent auctionEvent, Pfvehext pfvehext) {
    vehicleEventsRuleManager.process("com.manheim.tbox.vehicle.extension.buyer.charges.changed", pfvehext, auctionEvent);
  }
  
}