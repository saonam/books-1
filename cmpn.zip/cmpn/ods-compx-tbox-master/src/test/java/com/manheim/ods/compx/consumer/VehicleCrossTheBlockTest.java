package com.manheim.ods.compx.consumer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.xods.entity.ChangeDataCapture;
import com.manheim.xods.entity.ChangeDataCaptureItem;
import com.manheim.xods.entity.Pfvehicle;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class VehicleCrossTheBlockTest {

  private static final Logger LOG = LoggerFactory.getLogger(VehicleCrossTheBlockTest.class);

  @Autowired
  private AuctionEventsRuleManager vehicleEventsRuleManager;
  AuctionEvent auctionEvent;
  Pfvehicle pfvehicle;

  @Before
  public void setup() {
    auctionEvent = AuctionEvent.builder().auctionCode("QGM5").vin("2FMGK5CC7CA55B124").workOrder("1262767").sblu("3866393").build();
    pfvehicle = new Pfvehicle();
    pfvehicle.setStimes(1212);
  }

  @Test
  public void vehicleCrossTheBlockTest() {
    pfvehicle.setScode("SR");

    ChangeDataCaptureItem changeDataCaptureItem = new ChangeDataCaptureItem();
    changeDataCaptureItem.setDataEventField("STIMES");

    ChangeDataCaptureItem[] items = new ChangeDataCaptureItem[] {changeDataCaptureItem};
    ChangeDataCapture changeDataCapture = new ChangeDataCapture();
    changeDataCapture.setItem(items);

    pfvehicle.setDataEventChgIndList(changeDataCapture);

    applyRules(auctionEvent, pfvehicle);

    LOG.debug("Event Type Generated: {}", auctionEvent.getEventType());
    assertEquals("Event Type is CROSS_BLOCK", "CROSS_BLOCK", auctionEvent.getEventType());
  }

  @Test
  public void vehicleNotCrossTheBlockTest() {

    ChangeDataCaptureItem changeDataCaptureItem = new ChangeDataCaptureItem();
    changeDataCaptureItem.setDataEventField("SSER17");

    ChangeDataCaptureItem[] items = new ChangeDataCaptureItem[] {changeDataCaptureItem};
    ChangeDataCapture changeDataCapture = new ChangeDataCapture();
    changeDataCapture.setItem(items);

    pfvehicle.setDataEventChgIndList(changeDataCapture);

    applyRules(auctionEvent, pfvehicle);

    LOG.debug("Event Type Generated: {}", auctionEvent.getEventType());
    assertNotEquals("Event Type is CROSS_BLOCK", "CROSS_BLOCK",
        auctionEvent.getEventType());
  }

  private void applyRules(AuctionEvent auctionEvent, Pfvehicle pfvehicle) {
    vehicleEventsRuleManager.process("com.manheim.attc.cross.the.block", pfvehicle, auctionEvent);
  }

}
