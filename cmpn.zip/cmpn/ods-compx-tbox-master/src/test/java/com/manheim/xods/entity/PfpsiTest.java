package com.manheim.xods.entity;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.StringContains.containsString;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.net.URISyntaxException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.helper.CompXFileReader;

public class PfpsiTest {
  Pfpsi pfpsi;

  @Before
  public void setup() throws URISyntaxException, IOException, JAXBException {
    String pfpsiXmlResponse = new CompXFileReader().fetchFileAsString("pfpsi-test.xml");
    JAXBContext jc = JAXBContext.newInstance(Pfpsi.class);

    Unmarshaller unmarshaller = jc.createUnmarshaller();
    pfpsi = (Pfpsi) unmarshaller.unmarshal(new StringReader(pfpsiXmlResponse));

  }

  @Test
  public void testAuction() {
    assertThat(pfpsi.getId().getPiauci(), is("AAA"));
  }

  @Test
  public void testChangeIndicator() {

    boolean pictcdExists = false;
    for (ChangeDataCaptureItem changeDataCaptureItem : pfpsi.getDataEventChgIndList().getItem()) {
      if (changeDataCaptureItem.getDataEventField().equals("PICTCD")) {
        pictcdExists = true;
        break;
      }

    }

    assertTrue(pictcdExists);
  }

  @Test
  public void testSaleYear() {
    assertNotNull(pfpsi.getId().getPislyr());
  }

  @Test
  public void testToString() {
    assertThat(pfpsi.toString(), containsString("KGRELL"));
  }
}
