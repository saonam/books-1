package com.manheim.ods.compx.consumer.route;

import javax.jms.ConnectionFactory;

import org.apache.activemq.spring.ActiveMQConnectionFactory;
import org.apache.camel.EndpointInject;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.jms.JmsComponent;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.stereotype.Component;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.helper.CompXFileReader;

@Component
@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
@EnableJms
public class ExchangeRouteBuilderTest extends CamelTestSupport {
  @EndpointInject(uri = "mock:processCdcMessage")
  protected MockEndpoint cdcMessageProcessEndpoint;
  @Value("${activemq.source.queues}")
  private String activemqSourceQueues;
  @Autowired
  ExchangeRouteBuilder exchangeRouteBuilder;
  @Value("${spring.activemq.broker-url}")
  private String activeMQUrl;

  @Before
  public void setup() throws Exception {
    context.addComponent("ods-compx-jms", buildJmsComponent());
    context.addRoutes(new RouteBuilder() {
      @Override
      public void configure() throws Exception {
        from("direct:processCdcMessage").to("mock:result").to("log:com.manheim?level=INFO");
      }
    });
    context.addRoutes(exchangeRouteBuilder);
  }


  @Test
  public void test() {
    MockEndpoint mockEndpoint = (MockEndpoint) context.getEndpoint("mock:result");
    mockEndpoint.expectedBodiesReceived(
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><entity name=\"PFVEHICLE\"/>");
    ProducerTemplate template = context.createProducerTemplate();
    template.sendBody("ods-compx-jms:TST1?concurrentConsumers=1",
        "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><entity name=\"PFVEHICLE\"/>");
    assert (true);
  }

  public JmsComponent buildJmsComponent() {
    return JmsComponent.jmsComponentAutoAcknowledge(buildConnectionFactory());
  }

  public ConnectionFactory buildConnectionFactory() {
    ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory();
    activeMQConnectionFactory.setBrokerURL(activeMQUrl);
    return new CachingConnectionFactory(activeMQConnectionFactory);
  }

  @Test
  public void verifyEventsForPfrecon() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(context);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfrecon-seller-charges.xml");

      body.setBody(inputMessage);
      exchange.setIn(body);
      ProducerTemplate template = context.createProducerTemplate();
      template.send("ods-compx-jms:TST1?concurrentConsumers=1", exchange);

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }

}
