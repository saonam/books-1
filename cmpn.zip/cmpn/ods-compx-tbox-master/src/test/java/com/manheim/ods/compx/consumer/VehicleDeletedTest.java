package com.manheim.ods.compx.consumer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.xods.entity.Pfvehicle;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class VehicleDeletedTest {

  private static final Logger LOG = LoggerFactory.getLogger(VehicleDeletedTest.class);

  @Autowired
  private AuctionEventsRuleManager vehicleEventsRuleManager;

  AuctionEvent auctionEvent;
  Pfvehicle pfvehicle;

  @Before
  public void setup() {
    auctionEvent = AuctionEvent.builder().auctionCode("QGM5").vin("2FMGK5CC7CA55B124").workOrder("1262767").sblu("3866393").build();
	pfvehicle= new Pfvehicle();
  }

  @Test
  public void vehicleDeletedMessageShouldTriggerInventoryItemDeletedEvent() {
	  pfvehicle.setChangestatus("D");
	  manageRules(auctionEvent, pfvehicle);
	  
	  LOG.debug("Event Type Generated: {}", auctionEvent.getEventType());
	  assertEquals("Positive test case, Event Type matched", "INVENTORY_DELETED", auctionEvent.getEventType());
  }

  @Test
  public void vehicleNotDeletedShouldNotTriggerInventoryItemDeletedEvent() {
    pfvehicle.setChangestatus("I");
    manageRules(auctionEvent, pfvehicle);

    LOG.debug("Event Type Generated: {}", auctionEvent.getEventType());
    assertNotEquals("Negative test case, Event Type not matched", "INVENTORY_DELETED", auctionEvent.getEventType());
  }

  private void manageRules(AuctionEvent auctionEvent, Pfvehicle pfvehicle) {
    vehicleEventsRuleManager.process("com.manheim.tbox.vehicle.deleted", pfvehicle, auctionEvent);
  }

}
