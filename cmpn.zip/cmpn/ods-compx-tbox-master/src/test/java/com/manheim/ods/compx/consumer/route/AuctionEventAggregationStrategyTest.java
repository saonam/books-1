package com.manheim.ods.compx.consumer.route;


import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.manheim.ods.compx.model.eventer.AuctionEvent;

public class AuctionEventAggregationStrategyTest {

  @Mock
  Exchange oldExchange;
  Exchange newExchange;
  @Mock
  CamelContext camelContext;

  @Mock
  Message newMessage;
  @Mock
  Message oldMessage;
  AuctionEvent newAuctionEvent;

  AuctionEvent oldSellerChargesChangedAuctionEvent;
  AuctionEvent oldInventoryDeletedAuctionEvent;
  AuctionEvent oldBuyerCharges1ChangedAuctionEvent;
  AuctionEvent oldBuyerCharges2ChangedAuctionEvent;
  AuctionEvent oldBuyerChargesDiffOldBuyerAuctionEvent;
  AuctionEvent newBuyerChargesEmptyOldBuyerAuctionEvent;

  List<AuctionEvent> oldAggregatedAuctionEventList;

  AuctionEventAggregationStrategy auctionEventAggregationStrategy;

  Logger logger = LoggerFactory.getLogger(AuctionEventAggregationStrategy.class);

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    newAuctionEvent = new AuctionEvent();
    newAuctionEvent.setEventType("BUYER_CHARGES_CHANGED");
    newAuctionEvent.setAuctionCode("TEST_AUCTION");
    newAuctionEvent.setSblu("TEST_SBLU");
    newAuctionEvent.setTboxtimestamp("2017-11-02T10:50:14.858");
    newAuctionEvent.setMessageGroupId("TEST_AUCTION:TEST_SBLU:BUYER_CHARGES_CHANGED");
    Message newMessage = new DefaultMessage();
    newExchange = new DefaultExchange(camelContext);
    newExchange.setIn(newMessage);
    newMessage.setBody(newAuctionEvent);
    // when(newExchange.getIn()).thenReturn(newMessage);

    oldSellerChargesChangedAuctionEvent = new AuctionEvent();
    oldSellerChargesChangedAuctionEvent.setAuctionCode("TEST_AUCTION");
    oldSellerChargesChangedAuctionEvent.setSblu("TEST_SBLU");
    oldSellerChargesChangedAuctionEvent.setEventType("SELLER_CHARGES_CHANGED");
    oldSellerChargesChangedAuctionEvent
        .setMessageGroupId("TEST_AUCTION:TEST_SBLU:SELLER_CHARGES_CHANGED");
    oldSellerChargesChangedAuctionEvent.setTboxtimestamp("2017-11-02T10:48:14.858");

    oldInventoryDeletedAuctionEvent = new AuctionEvent();
    oldInventoryDeletedAuctionEvent.setAuctionCode("TEST_AUCTION");
    oldInventoryDeletedAuctionEvent.setSblu("TEST_SBLU");
    oldInventoryDeletedAuctionEvent.setEventType("INVENTORY_DELETED");
    oldInventoryDeletedAuctionEvent.setMessageGroupId("TEST_AUCTION:TEST_SBLU:INVENTORY_DELETED");
    oldInventoryDeletedAuctionEvent.setTboxtimestamp("2017-11-02T10:49:14.858");

    oldBuyerCharges1ChangedAuctionEvent = new AuctionEvent();
    oldBuyerCharges1ChangedAuctionEvent.setAuctionCode("TEST_AUCTION");
    oldBuyerCharges1ChangedAuctionEvent.setSblu("TEST_SBLU");
    oldBuyerCharges1ChangedAuctionEvent.setEventType("BUYER_CHARGES_CHANGED");
    oldBuyerCharges1ChangedAuctionEvent.setTboxtimestamp("2017-11-02T10:48:16.858");
    oldBuyerCharges1ChangedAuctionEvent
        .setMessageGroupId("TEST_AUCTION:TEST_SBLU:BUYER_CHARGES_CHANGED");

    oldBuyerCharges2ChangedAuctionEvent = new AuctionEvent();
    oldBuyerCharges2ChangedAuctionEvent.setAuctionCode("TEST_AUCTION");
    oldBuyerCharges2ChangedAuctionEvent.setSblu("TEST_SBLU");
    oldBuyerCharges2ChangedAuctionEvent.setEventType("BUYER_CHARGES_CHANGED");
    oldBuyerCharges2ChangedAuctionEvent.setTboxtimestamp("2017-11-02T10:48:24.858");
    oldBuyerCharges2ChangedAuctionEvent
        .setMessageGroupId("TEST_AUCTION:TEST_SBLU:BUYER_CHARGES_CHANGED");


    oldAggregatedAuctionEventList = new ArrayList<AuctionEvent>();
    oldAggregatedAuctionEventList.add(oldSellerChargesChangedAuctionEvent);
    oldAggregatedAuctionEventList.add(oldBuyerCharges1ChangedAuctionEvent);
    oldAggregatedAuctionEventList.add(oldBuyerCharges2ChangedAuctionEvent);
    oldAggregatedAuctionEventList.add(oldInventoryDeletedAuctionEvent);

    oldBuyerChargesDiffOldBuyerAuctionEvent = new AuctionEvent();
    oldBuyerChargesDiffOldBuyerAuctionEvent.setAuctionCode("TEST_AUCTION");
    oldBuyerChargesDiffOldBuyerAuctionEvent.setSblu("TEST_SBLU");
    oldBuyerChargesDiffOldBuyerAuctionEvent.setEventType("BUYER_CHARGES_CHANGED");
    oldBuyerChargesDiffOldBuyerAuctionEvent.setTboxtimestamp("2017-11-02T10:48:16.858");
    oldBuyerChargesDiffOldBuyerAuctionEvent.setPrevBuyerDealerId("5098861");
    oldBuyerChargesDiffOldBuyerAuctionEvent
        .setMessageGroupId("TEST_AUCTION:TEST_SBLU:BUYER_CHARGES_CHANGED");


    oldAggregatedAuctionEventList = new ArrayList<AuctionEvent>();
    oldAggregatedAuctionEventList.add(oldSellerChargesChangedAuctionEvent);
    oldAggregatedAuctionEventList.add(oldBuyerCharges1ChangedAuctionEvent);
    oldAggregatedAuctionEventList.add(oldBuyerCharges2ChangedAuctionEvent);
    oldAggregatedAuctionEventList.add(oldInventoryDeletedAuctionEvent);
    when(oldMessage.getBody(List.class)).thenReturn(oldAggregatedAuctionEventList);
    when(oldExchange.getIn()).thenReturn(oldMessage);

    auctionEventAggregationStrategy = new AuctionEventAggregationStrategy();
  }

  @Test
  public void test() {

    Exchange aggregatedExchange =
        auctionEventAggregationStrategy.aggregate(oldExchange, newExchange);
    List<AuctionEvent> auctionEventList =
        (List<AuctionEvent>) aggregatedExchange.getIn().getBody(List.class);
    assert (auctionEventList.stream().anyMatch(
        auctionEvent -> StringUtils.equals("BUYER_CHARGES_CHANGED", auctionEvent.getEventType())));

  }


  @Test
  public void testSameBuyerDealerIdAggregation() {
    oldAggregatedAuctionEventList.clear();
    oldAggregatedAuctionEventList.add(oldBuyerChargesDiffOldBuyerAuctionEvent);

    when(oldMessage.getBody(List.class)).thenReturn(oldAggregatedAuctionEventList);
    when(oldExchange.getIn()).thenReturn(oldMessage);


    Exchange aggregatedExchange =
        auctionEventAggregationStrategy.aggregate(oldExchange, newExchange);
    List<AuctionEvent> auctionEvents = aggregatedExchange.getIn().getBody(List.class);
    Predicate<AuctionEvent> p1 =
        ae -> StringUtils.equals("BUYER_CHARGES_CHANGED", ae.getEventType());

  }


  @Test
  public void testNullBuyerDealerIdInLatestEventAggregation() {
    oldAggregatedAuctionEventList.clear();
    oldAggregatedAuctionEventList.add(oldBuyerChargesDiffOldBuyerAuctionEvent);
    when(oldMessage.getBody(List.class)).thenReturn(oldAggregatedAuctionEventList);
    when(oldExchange.getIn()).thenReturn(oldMessage);



    Exchange aggregatedExchange =
        auctionEventAggregationStrategy.aggregate(oldExchange, newExchange);


    List<AuctionEvent> auctionEvents = aggregatedExchange.getIn().getBody(List.class);
    Predicate<AuctionEvent> p1 = ae -> StringUtils.equals("5098861", ae.getPrevBuyerDealerId());

    assert (auctionEvents.stream().anyMatch(p1));


  }

}
