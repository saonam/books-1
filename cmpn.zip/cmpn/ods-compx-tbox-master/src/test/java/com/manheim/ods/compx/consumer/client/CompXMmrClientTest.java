package com.manheim.ods.compx.consumer.client;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

public class CompXMmrClientTest {

  private CompXMmrClient client;
  private MetricReporter metricReporter;
  private AuctionEvent auctionEvent;
  private RestTemplate restTemplate;
  private ResponseEntity<String> responseEntity;
  private ObjectMapper objectMapper;

  @Before
  public void setUp() throws Exception {

    restTemplate = mock(RestTemplate.class);
    responseEntity = mock(ResponseEntity.class);
    when(responseEntity.getStatusCode()).thenReturn(HttpStatus.OK);
    when(restTemplate.exchange(anyString(), any(HttpMethod.class), any(), any(Class.class)))
        .thenReturn(responseEntity);
    String compxMmrApiEndpoint = "http://localhost:8080/event";
    String compxMmrAuthorization = "TEST AUTH";
    metricReporter = mock(MetricReporter.class);
    // objectMapper = mock(ObjectMapper.class);
    objectMapper = new ObjectMapper();
    client = new CompXMmrClient(restTemplate, metricReporter, compxMmrApiEndpoint,
        compxMmrAuthorization, objectMapper);
    auctionEvent = AuctionEvent.builder().auctionCode("AUCTION").vin("VIN").workOrder("12345")
        .sblu("987654").eventType("CHECK_IN").cdcjournaltimestamp("2017-09-19T22:38:02.945168000")
        .auctionid("xAUCTION1").build();
  }

  @Test
  public void shouldReturnResponseWhenCallExecutionIsSuccessful() throws IOException {
    Integer responseCode = client.postToCompXMmr(auctionEvent, this.getClass());

    assertThat(responseCode, is(200));
  }

  @Test
  public void shouldExecuteCall() throws IOException {
    client.postToCompXMmr(auctionEvent, this.getClass());

    verify(restTemplate).exchange(anyString(), eq(HttpMethod.POST), any(HttpEntity.class),
        eq(String.class));
  }

  @Test
  public void shouldReportMetricsWhenExecuting() throws IOException {
    client.postToCompXMmr(auctionEvent, this.getClass());

    verify(metricReporter).recordExternalCallTime(anyLong(), eq("service-name:CompXMmrClientTest"),
        eq("service-host:localhost"), eq("service-uri:/event"), eq("http-method:POST"),
        eq("http-status:200"));

  }

  @Test
  public void verifyForMalformedApiEndpoint() throws IOException {
    String compxMmrApiEndpoint = "abc:localhost:8080:event";
    String compxMmrAuthorization = "TEST AUTH";
    client = new CompXMmrClient(restTemplate, metricReporter, compxMmrApiEndpoint,
        compxMmrAuthorization, objectMapper);
    client.postToCompXMmr(auctionEvent, this.getClass());
    verify(metricReporter, times(0)).recordExternalCallTime(anyLong(),
        eq("service-name:CompXMmrClientTest"), eq("service-host:localhost"),
        eq("service-uri:/event"), eq("http-method:POST"), eq("http-status:200"));

  }


  @Test
  public void shouldReturnResponseWhenHeartbeatCallExecutionIsSuccessful() throws IOException {
    auctionEvent = AuctionEvent.builder().auctionCode("AUCTION").vin("VIN").workOrder("12345")
        .sblu("987654").eventType("HEARTBEAT").cdcjournaltimestamp("2017-09-19T22:38:02.945168000")
        .auctionid("xAUCTION1").build();
    auctionEvent.setHeartbeat(true);
    Integer responseCode = client.postToCompXMmr(auctionEvent, this.getClass());

    assertThat(responseCode, is(200));
  }

}


