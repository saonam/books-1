package com.manheim.ods.compx;

import org.apache.commons.lang3.StringUtils;
import org.junit.Test;

public class UtilsTest {

  @Test
  public void test() {
    String scode = "SS";
    assert (StringUtils.containsAny(scode, "SS", "SF"));
  }

}
