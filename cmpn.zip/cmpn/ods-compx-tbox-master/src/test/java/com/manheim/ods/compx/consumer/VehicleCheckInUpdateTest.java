package com.manheim.ods.compx.consumer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.xods.entity.ChangeDataCapture;
import com.manheim.xods.entity.ChangeDataCaptureItem;
import com.manheim.xods.entity.Pfvehicle;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class VehicleCheckInUpdateTest {

  @Autowired
  private AuctionEventsRuleManager vehicleEventsRuleManager;
  AuctionEvent auctionEvent;
  Pfvehicle pfvehicle;

  @Before
  public void setup() {
    auctionEvent = AuctionEvent.builder().auctionCode("QGM5").vin("2FMGK5CC7CA55B124")
        .workOrder("1262767").sblu("3866393").build();
    pfvehicle= new Pfvehicle();
    pfvehicle.setScode("RC");
  }

  @Test
  public void vehicleCheckedInUpdateTest() {
    
    pfvehicle.setPrevSdtere(20170716);

    ChangeDataCaptureItem changeDataCaptureItem = new ChangeDataCaptureItem();
    changeDataCaptureItem.setDataEventField("MSUBSE");

    ChangeDataCaptureItem changeDataCaptureItem1 = new ChangeDataCaptureItem();
    changeDataCaptureItem.setDataEventField("SSER16");

    ChangeDataCaptureItem[] items =
        new ChangeDataCaptureItem[] {changeDataCaptureItem, changeDataCaptureItem1};
    ChangeDataCapture changeDataCapture = new ChangeDataCapture();
    changeDataCapture.setItem(items);

    pfvehicle.setDataEventChgIndList(changeDataCapture);
    applyRules(auctionEvent, pfvehicle);

    assertEquals("Event Type is CHECK_IN_UPDATED", "CHECK_IN_UPDATED", auctionEvent.getEventType());
  }


  @Test
  public void vehicleNotCheckedInUpdateTest() {
	
    pfvehicle.setPrevSdtere(0);

    ChangeDataCaptureItem changeDataCaptureItem = new ChangeDataCaptureItem();
    changeDataCaptureItem.setDataEventField("SSER17");

    ChangeDataCaptureItem[] items = new ChangeDataCaptureItem[] {changeDataCaptureItem};
    ChangeDataCapture changeDataCapture = new ChangeDataCapture();
    changeDataCapture.setItem(items);

    pfvehicle.setDataEventChgIndList(changeDataCapture);

    applyRules(auctionEvent, pfvehicle);

    assertNotEquals("Event Type is CHECK_IN_UPDATED", "CHECK_IN_UPDATED",
        auctionEvent.getEventType());
  }

  private void applyRules(AuctionEvent auctionEvent, Pfvehicle pfvehicle) {
    vehicleEventsRuleManager.process("com.manheim.attc.checkin.updated", pfvehicle, auctionEvent);
  }

}
