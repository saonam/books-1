package com.manheim.ods.compx.consumer.route;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.manheim.ods.compx.model.eventer.AuctionEvent;

public class EventTypeValidatorTest {

  @Mock
  Exchange exchange;
  @Mock
  AuctionEvent event;

  EventTypeValidator eventTypeValidator;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    Message message = mock(Message.class);
    
    when(exchange.getIn()).thenReturn(message);
    when(message.getBody(AuctionEvent.class)).thenReturn(event);
    when(event.getAuctionCode()).thenReturn("TEST_AUCTION");
    when(event.getSblu()).thenReturn("TEST_SBLU");
    when(event.getWorkOrder()).thenReturn("1234567");
    eventTypeValidator = new EventTypeValidator(new String[] {"CHECK_IN", "CHECK_IN_UPDATED",
        "LISTING", "CROSS_BLOCK", "SELLER_CHARGES_CHANGED", "HEARTBEAT",
        "SELLER_SERVICE_ORDER_CREATED", "INVENTORY_DELETED", "BUYER_CHARGES_CHANGED"});

  }

  @Test
  public void testMatches() {
    when(event.getEventType()).thenReturn("SELLER_CHARGES_CHANGED");
    eventTypeValidator.matches(exchange);
  }

  @Test
  public void testDoesNotMatch() {
    when(event.getEventType()).thenReturn("INVALID_EVENT_TYPE");
    eventTypeValidator.matches(exchange);
  }
}
