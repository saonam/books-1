package com.manheim.ods.compx.consumer.processor.vehicle;

import static org.mockito.Matchers.contains;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.xml.bind.JAXBContext;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class VehicleChargesEventProcessorTest {

  private AuctionEvent event;
  private Exchange exchange;
  private Message message;
  private VehicleChargesEventProcessor vehicleChargesEventProcessor;

  private LogWrapper logWrapper;

  @Mock
  MetricReporter metricReporter;

  @Autowired
  JAXBContext jaxbContext;

  @Autowired
  AuctionEventsRuleManager auctionEventsRuleManager;


  @Before
  public void setUp() throws Exception {

    event = mock(AuctionEvent.class);
    // new AuctionEvent("QGM5", "2FMGK5CC7CA55B124", "1262767", "3866393");
    when(event.getAuctionCode()).thenReturn("QGM5");
    when(event.getVin()).thenReturn("2FMGK5CC7CA55B124");
    when(event.getSblu()).thenReturn("1262767");
    when(event.getWorkOrder()).thenReturn("3866393");
    when(event.getEventType()).thenReturn("CHECK_IN");
    logWrapper = mock(LogWrapper.class);
    exchange = mock(Exchange.class);
    CamelContext camelContext = mock(CamelContext.class);
    when(camelContext.createProducerTemplate()).thenReturn(mock(ProducerTemplate.class));
    when(exchange.getContext()).thenReturn(camelContext);
    message = mock(Message.class);

    when(exchange.getIn()).thenReturn(message);

  }

  @Test
  public void verifySellerChangedEvent() throws Exception {

    String pfvehicleXmlResponse =
        new CompXFileReader().fetchFileAsString("pfvehicle-seller-charges.xml");
    when(message.getBody(String.class)).thenReturn(pfvehicleXmlResponse);



    vehicleChargesEventProcessor = new VehicleChargesEventProcessor(auctionEventsRuleManager,
        logWrapper, jaxbContext, metricReporter);

    vehicleChargesEventProcessor.process(exchange);
    verify(logWrapper).info(eq(VehicleChargesEventProcessor.class),
        contains("SELLER_CHARGES_CHANGED"));
  }

  @Test
  public void verifySellerChangedEventForScode() throws Exception {

    String pfvehicleXmlResponse =
        new CompXFileReader().fetchFileAsString("pfvehicle-scode-change.xml");
    when(message.getBody(String.class)).thenReturn(pfvehicleXmlResponse);



    vehicleChargesEventProcessor = new VehicleChargesEventProcessor(auctionEventsRuleManager,
        logWrapper, jaxbContext, metricReporter);

    vehicleChargesEventProcessor.process(exchange);
    verify(logWrapper).info(eq(VehicleChargesEventProcessor.class),
        contains("SELLER_CHARGES_CHANGED"));
  }

  @Test
  public void verifySellerChangedEventForRollback() throws Exception {

    String pfvehicleXmlResponse = new CompXFileReader().fetchFileAsString("pfvehicle-rollback.xml");
    when(message.getBody(String.class)).thenReturn(pfvehicleXmlResponse);



    vehicleChargesEventProcessor = new VehicleChargesEventProcessor(auctionEventsRuleManager,
        logWrapper, jaxbContext, metricReporter);

    vehicleChargesEventProcessor.process(exchange);
    verify(logWrapper).info(eq(VehicleChargesEventProcessor.class),
        contains("SELLER_CHARGES_CHANGED"));
  }

  @Test
  public void verifyBuyerChangedEvent() throws Exception {

    String pfvehicleXmlResponse =
        new CompXFileReader().fetchFileAsString("pfvehicle-buyer-charges.xml");
    when(message.getBody(String.class)).thenReturn(pfvehicleXmlResponse);

    vehicleChargesEventProcessor = new VehicleChargesEventProcessor(auctionEventsRuleManager,
        logWrapper, jaxbContext, metricReporter);

    vehicleChargesEventProcessor.process(exchange);
    verify(logWrapper).info(eq(VehicleChargesEventProcessor.class),
        contains("BUYER_CHARGES_CHANGED"));
  }

}

