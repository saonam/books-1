package com.manheim.xods.entity;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.StringContains.containsString;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.net.URISyntaxException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.helper.CompXFileReader;

public class PfsadjdtlTest {
  Pfsadjdtl pfsadjdtl;

  @Before
  public void setup() throws URISyntaxException, IOException, JAXBException {
    String pfsadjdtlXmlResponse = new CompXFileReader().fetchFileAsString("pfsadjdtl-test.xml");
    JAXBContext jc = JAXBContext.newInstance(Pfsadjdtl.class);

    Unmarshaller unmarshaller = jc.createUnmarshaller();
    pfsadjdtl = (Pfsadjdtl) unmarshaller.unmarshal(new StringReader(pfsadjdtlXmlResponse));

  }

  @Test
  public void testAuction() {
    assertThat(pfsadjdtl.getId().getAjauci(), is("TESTAUCTION"));
  }

  @Test
  public void testChangeIndicator() {
    boolean rcDescExists = false;
    for (ChangeDataCaptureItem changeDataCaptureItem : pfsadjdtl.getDataEventChgIndList().getItem()) {
      if (changeDataCaptureItem.getDataEventField().equals("AJCODE")) {
        rcDescExists = true;
        break;
      }

    }

    assertTrue(rcDescExists);
  }

  @Test
  public void testSaleYear() {
    assertNotNull(pfsadjdtl.getId().getAjsleyr());
  }

  @Test
  public void testToString() {
    assertThat(pfsadjdtl.toString(), containsString("315000"));
  }
}
