package com.manheim.xods.entity;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.StringContains.containsString;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.net.URISyntaxException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.helper.CompXFileReader;

public class PfreconTest {
  Pfrecon pfrecon;

  @Before
  public void setup() throws URISyntaxException, IOException, JAXBException {
    String pfreconXmlResponse = new CompXFileReader().fetchFileAsString("pfrecon-test.xml");
    JAXBContext jc = JAXBContext.newInstance(Pfrecon.class);

    Unmarshaller unmarshaller = jc.createUnmarshaller();
    pfrecon = (Pfrecon) unmarshaller.unmarshal(new StringReader(pfreconXmlResponse));

  }

  @Test
  public void testAuction() {
    assertThat(pfrecon.getId().getRcauci(), is("TESTAUCTION"));
  }

  @Test
  public void testChangeIndicator() {


    boolean rcDescExists = false;
    for (ChangeDataCaptureItem changeDataCaptureItem : pfrecon.getDataEventChgIndList().getItem()) {
      if (changeDataCaptureItem.getDataEventField().equals("RCDESC")) {
        rcDescExists = true;
        break;
      }

    }

    assertTrue(rcDescExists);
  }

  @Test
  public void testWorkorder() {
    assertNotNull(pfrecon.getId().getRcwo());
  }

  @Test
  public void testToString() {
    assertThat(pfrecon.toString(), containsString("7012912"));
  }
}
