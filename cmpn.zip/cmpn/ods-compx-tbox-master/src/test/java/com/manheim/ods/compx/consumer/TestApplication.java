package com.manheim.ods.compx.consumer;

import static org.mockito.Mockito.mock;

import javax.jms.ConnectionFactory;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import org.apache.activemq.spring.ActiveMQConnectionFactory;
import org.apache.camel.component.jms.JmsComponent;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Primary;
import org.springframework.jms.connection.CachingConnectionFactory;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.client.RestTemplate;

import com.amazonaws.services.kinesis.AmazonKinesis;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.bee.entity.BusinessEvent;
import com.manheim.ods.compx.consumer.client.CompXMmrClient;
import com.manheim.ods.compx.consumer.config.StreamConfiguration;
import com.manheim.ods.compx.consumer.processor.vehicle.VehicleEventProcessor;
import com.manheim.ods.compx.consumer.route.EventTypeValidator;
import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.consumer.rules.DroolsAutoConfiguration;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import com.manheim.xods.entity.Auctionheartbeat;
import com.manheim.xods.entity.Pfpsi;
import com.manheim.xods.entity.Pfrecon;
import com.manheim.xods.entity.Pfsadjdtl;
import com.manheim.xods.entity.Pfvehext;
import com.manheim.xods.entity.Pfvehicle;
import com.manheim.xods.entity.Tprmktbl;

@ComponentScan(basePackages = {"com.manheim.ods.compx.consumer", "com.manheim.xods"})
@Configuration
@EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class})
@Import({DroolsAutoConfiguration.class, StreamConfiguration.class})
@SpringBootApplication
public class TestApplication {

  @Value("${spring.activemq.password}")
  private String activeMQPassword;

  @Value("${spring.activemq.user}")
  private String activeMQUserName;
  @Autowired
  @Value("${spring.activemq.broker-url}")
  String activeMQUrl;
  @Value("${activemq.source.queues}")
  private String activemqSourceQueues;
  @Value("${compxmmr.authorization}")
  private String compxMmrAuthorization;
  @Value("${compxmmr.api.endpoint}")
  private String compxMmrApiEndpoint;
  private ObjectMapper objectMapper;
  @Value("${invreleased.ignore.older.than}")
  private int invReleasedIgnoreOlderThan;


  @Value("${valid.event.types}")
  String[] validEventTypes;

  @Autowired
  private KieSession kieSession;

  @Value("${spring.profiles.active}")
  String springProfile;

  @Value("${spring.application.name}")
  private String appName;

  
  public static void main(String[] args) {
    SpringApplication.run(Application.class, args);
  }

  @Bean
  public RestTemplate buildRestTemplate() {
    return mock(RestTemplate.class);
  }

  @Bean
  public JavaMailSender javaMailSender() {
    return mock(JavaMailSender.class);
  }

  @Bean
  public ObjectMapper buildObjectMapper() {
    return new ObjectMapper();
  }

  @Bean
  public CompXMmrClient buildCompXMmrClient() {
    return new CompXMmrClient(buildRestTemplate(), buildMetricReporter(), compxMmrApiEndpoint,
        compxMmrAuthorization, objectMapper);
  }

  @Bean
  @Primary

  public JAXBContext buildJaxbContext() throws JAXBException {
    Class[] marshallingRequiredClasses = {Pfvehicle.class, Auctionheartbeat.class, Pfrecon.class,
        Pfvehext.class, BusinessEvent.class, Tprmktbl.class, Pfsadjdtl.class, Pfpsi.class};
    JAXBContext jc = JAXBContext.newInstance(marshallingRequiredClasses);
    return jc;

  }

  @Bean
  @Primary
  public AuctionEventsRuleManager buildAuctionEventsRuleManager() {
    return new AuctionEventsRuleManager(kieSession);
  }

  @Bean
  @Primary
  public VehicleEventProcessor buildVehicleEventProcessor() throws JAXBException {
    return new VehicleEventProcessor(buildAuctionEventsRuleManager(), buildLogWrapper(),
        buildJaxbContext(), buildMetricReporter());
  }

  @Bean(name = "mockLogWrapper")
  @Primary
  public LogWrapper buildLogWrapper() {
    return mock(LogWrapper.class);
  }


  @Bean(name = "mockMetricReporter")
  @Primary
  public MetricReporter buildMetricReporter() {
    return mock(MetricReporter.class);
  }


  @Bean(name = "tbox")
  public AmazonKinesis eventsClient() {

    return mock(AmazonKinesis.class);

  }

  @Bean(name = "ods-compx-jms")
  @Primary
  public JmsComponent buildJmsComponent() {
    return JmsComponent.jmsComponentAutoAcknowledge(buildConnectionFactory());
  }

  @Bean(name = "activemq-cf")
  @Primary
  public ConnectionFactory buildConnectionFactory() {
    ActiveMQConnectionFactory activeMQConnectionFactory = new ActiveMQConnectionFactory();
    activeMQConnectionFactory.setBrokerURL(activeMQUrl);
    return new CachingConnectionFactory(activeMQConnectionFactory);
  }

  @Bean(name = "eventTypeValidator")
  public EventTypeValidator buildEventTypeValidator() {
    return new EventTypeValidator(validEventTypes);
  }

}
