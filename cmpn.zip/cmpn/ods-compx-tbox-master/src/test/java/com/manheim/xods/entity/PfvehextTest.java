package com.manheim.xods.entity;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.StringContains.containsString;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.net.URISyntaxException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.helper.CompXFileReader;

public class PfvehextTest {
  Pfvehext pfvehext;

  @Before
  public void setup() throws URISyntaxException, IOException, JAXBException {
    String pfvehextXmlResponse = new CompXFileReader().fetchFileAsString("pfvehext-test.xml");
    JAXBContext jc = JAXBContext.newInstance(Pfvehext.class);

    Unmarshaller unmarshaller = jc.createUnmarshaller();
    pfvehext = (Pfvehext) unmarshaller.unmarshal(new StringReader(pfvehextXmlResponse));

  }

  @Test
  public void testAuction() {
    assertThat(pfvehext.getId().getVauci(), is("TESTAUCTION"));
  }

  @Test
  public void testChangeIndicator() {


    boolean rcDescExists = false;
    for (ChangeDataCaptureItem changeDataCaptureItem : pfvehext.getDataEventChgIndList()
        .getItem()) {
      if (changeDataCaptureItem.getDataEventField().equals("VSSUFEE")) {
        rcDescExists = true;
        break;
      }

    }

    assertTrue(rcDescExists);
  }

  @Test
  public void testWorkorder() {
    assertNotNull(pfvehext.getId().getVblu());
  }

  @Test
  public void testToString() {
    assertThat(pfvehext.toString(), containsString("12768549"));
  }
}
