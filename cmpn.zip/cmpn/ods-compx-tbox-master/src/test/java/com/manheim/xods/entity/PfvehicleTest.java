package com.manheim.xods.entity;

import static org.hamcrest.core.Is.is;
import static org.hamcrest.core.StringContains.containsString;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringReader;
import java.net.URISyntaxException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.helper.CompXFileReader;

public class PfvehicleTest {
  Pfvehicle pfvehicle;

  @Before
  public void setup() throws URISyntaxException, IOException, JAXBException {
    String pfvehicleXmlResponse = new CompXFileReader().fetchFileAsString("pfvehicle-test.xml");
    JAXBContext jc = JAXBContext.newInstance(Pfvehicle.class);

    Unmarshaller unmarshaller = jc.createUnmarshaller();
    pfvehicle = (Pfvehicle) unmarshaller.unmarshal(new StringReader(pfvehicleXmlResponse));

  }

  @Test
  public void testAuction() {
    assertThat(pfvehicle.getId().getSauci(), is("QGM5"));
  }

  @Test
  public void testChangeIndicator() {


    boolean smilesExists = false;
    for (ChangeDataCaptureItem changeDataCaptureItem : pfvehicle.getDataEventChgIndList()
        .getItem()) {
      if (changeDataCaptureItem.getDataEventField().equals("SMILES")) {
        smilesExists = true;
        break;
      }

    }

    assertTrue(smilesExists);
  }

  @Test
  public void testSblu() {
    assertNotNull(pfvehicle.getId().getSblu());
  }

  @Test
  public void testToString() {
    assertThat(pfvehicle.toString(), containsString("3866393"));
  }



}
