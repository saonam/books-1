package com.manheim.ods.compx.consumer;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.xods.entity.ChangeDataCapture;
import com.manheim.xods.entity.ChangeDataCaptureItem;
import com.manheim.xods.entity.Pfvehext;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class VehicleExtUpdatedTest {

	@Autowired
	private AuctionEventsRuleManager vehicleEventsRuleManager;

	AuctionEvent auctionEvent;
	Pfvehext pfvehext;

	@Before
	public void setup() {
		auctionEvent = AuctionEvent.builder().auctionCode("QGM5").vin("2FMGK5CC7CA55B124").workOrder("1262767").sblu("3866393").build();
		pfvehext= new Pfvehext();
		pfvehext.setChangestatus("U");
	}

	@Test
	public void vehicleExtUpdatedMsgShouldTriggerSellerChargesChangedEventWhenSellerSuccessFeesIsChanged() {
		pfvehext.setVssufee(25);
		ChangeDataCapture changeDataCapture = populateChangeDataCapture("VSSUFEE");
		pfvehext.setDataEventChgIndList(changeDataCapture);
		runBPMForSeller(auctionEvent, pfvehext);

		assertEquals("Positive test case, Event Type matched", "SELLER_CHARGES_CHANGED", auctionEvent.getEventType());
	}

	@Test
	public void vehicleExtUpdatedMsgShouldTriggerSellerChargesChangedEventWhenSellerFacilitationFeesIsChanged() {
		pfvehext.setVsfafee(10);
		ChangeDataCapture changeDataCapture = populateChangeDataCapture("VSFAFEE");
		pfvehext.setDataEventChgIndList(changeDataCapture);
		runBPMForSeller(auctionEvent, pfvehext);

		assertEquals("Positive test case, Event Type matched", "SELLER_CHARGES_CHANGED", auctionEvent.getEventType());
	}

	@Test
	public void vehicleExtUpdatedMsgShouldTriggerBuyerChargesChangedEventWhenBuyerFacilitationFeesIsChanged() {
		pfvehext.setVbfafee(10);
		ChangeDataCapture changeDataCapture = populateChangeDataCapture("VBFAFEE");
		pfvehext.setDataEventChgIndList(changeDataCapture);
		runBPMForBuyer(auctionEvent, pfvehext);

		assertEquals("Positive test case, Event Type matched", "BUYER_CHARGES_CHANGED", auctionEvent.getEventType());
	}

	@Test
	public void vehicleExtUpdatedMsgShouldTriggerBuyerChargesChangedEventWhenBuyerSuccessFeesIsChanged() {
		pfvehext.setVbsufee(30);
		ChangeDataCapture changeDataCapture = populateChangeDataCapture("VBSUFEE");
		pfvehext.setDataEventChgIndList(changeDataCapture);
		runBPMForBuyer(auctionEvent, pfvehext);

		assertEquals("Positive test case, Event Type matched", "BUYER_CHARGES_CHANGED", auctionEvent.getEventType());
	}

	@Test
	public void vehicleExtUpdatedMsgShouldNotTriggerAnyChargesEventWhenANonFeeFieldIsChanged() {
		pfvehext.setVbsufee(30);
		ChangeDataCapture changeDataCapture = populateChangeDataCapture("VXXXX");
		pfvehext.setDataEventChgIndList(changeDataCapture);
		runBPMForBuyer(auctionEvent, pfvehext);

		assertEquals("Negative test case, Event Type is null", null, auctionEvent.getEventType());
	}

	@Test
	public void vehicleExtInvalidChangeStatusShouldNotTriggerChargesChangedEvent() {
		pfvehext.setChangestatus("X");
		runBPMForSeller(auctionEvent, pfvehext);

		assertEquals("Negative test case, Event Type is null", null, auctionEvent.getEventType());
	}

	private void runBPMForSeller(AuctionEvent auctionEvent, Pfvehext pfvehext) {
		vehicleEventsRuleManager.process("com.manheim.tbox.vehicle.extension.seller.charges.changed", pfvehext, auctionEvent);
	}

	private void runBPMForBuyer(AuctionEvent auctionEvent, Pfvehext pfvehext) {
		vehicleEventsRuleManager.process("com.manheim.tbox.vehicle.extension.buyer.charges.changed", pfvehext, auctionEvent);
	}
	
	private ChangeDataCapture populateChangeDataCapture(String item) {

		ChangeDataCaptureItem cdcItem= new ChangeDataCaptureItem();
		cdcItem.setDataEventField(item);

		ChangeDataCaptureItem[] items =
				new ChangeDataCaptureItem[] {cdcItem};
		ChangeDataCapture changeDataCapture = new ChangeDataCapture();
		changeDataCapture.setItem(items);
		return changeDataCapture;
	}

}
