package com.manheim.ods.compx.consumer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.manheim.ods.compx.consumer.rules.AuctionEventsRuleManager;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.xods.entity.ChangeDataCapture;
import com.manheim.xods.entity.ChangeDataCaptureItem;
import com.manheim.xods.entity.Pfvehicle;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class VehicleListingTest {

  private static final Logger LOG = LoggerFactory.getLogger(VehicleListingTest.class);

  @Autowired
  private AuctionEventsRuleManager vehicleEventsRuleManager;
  AuctionEvent auctionEvent;
  Pfvehicle pfvehicle;

  @Before
  public void setup() {
    auctionEvent = AuctionEvent.builder().auctionCode("QGM5").vin("2FMGK5CC7CA55B124")
        .workOrder("1262767").sblu("3866393").build();
    pfvehicle = new Pfvehicle();
    pfvehicle.setScode("SR");
  }

  @Test
  public void vehicleListingTest() {
    pfvehicle.setPrevScode("RC");
    pfvehicle.setSsleyr(2015);
    pfvehicle.setSsale(25);
    pfvehicle.setSlane(15);
    pfvehicle.setSrun(108);

    ChangeDataCaptureItem changeDataCaptureItem = new ChangeDataCaptureItem();
    changeDataCaptureItem.setDataEventField("SSLEYR");

    ChangeDataCaptureItem[] items = new ChangeDataCaptureItem[] {changeDataCaptureItem};
    ChangeDataCapture changeDataCapture = new ChangeDataCapture();
    changeDataCapture.setItem(items);

    pfvehicle.setDataEventChgIndList(changeDataCapture);

    applyRules(auctionEvent, pfvehicle);

    LOG.debug("Event Type Generated: {}", auctionEvent.getEventType());
    assertEquals("Event Type is LISTING", "LISTING", auctionEvent.getEventType());
  }

  @Test
  public void vehicleNotListingTest() {
    pfvehicle.setPrevScode("SS");
    pfvehicle.setSsleyr(0);
    pfvehicle.setSsale(0);
    pfvehicle.setSlane(0);
    pfvehicle.setSrun(0);

    ChangeDataCaptureItem changeDataCaptureItem = new ChangeDataCaptureItem();
    changeDataCaptureItem.setDataEventField("SCODE");

    ChangeDataCaptureItem[] items = new ChangeDataCaptureItem[] {changeDataCaptureItem};
    ChangeDataCapture changeDataCapture = new ChangeDataCapture();
    changeDataCapture.setItem(items);

    pfvehicle.setDataEventChgIndList(changeDataCapture);

    applyRules(auctionEvent, pfvehicle);

    LOG.debug("Event Type Generated: {}", auctionEvent.getEventType());
    assertNotEquals("Event Type is LISTING", "LISTING", auctionEvent.getEventType());
  }

  private void applyRules(AuctionEvent auctionEvent, Pfvehicle pfvehicle) {
    vehicleEventsRuleManager.process("com.manheim.attc.listing", pfvehicle, auctionEvent);
  }

}
