package integration;

import static org.mockito.Matchers.contains;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.processor.vehicle.VehicleChargesEventProcessor;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.util.LogWrapper;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class SellerNumberChangedEventProcessorTest {

  @Autowired
  CamelContext camelContext;

  @Autowired
  private LogWrapper mockLogWrapper;

  Logger logger = LoggerFactory.getLogger(this.getClass());

  @Test
  public void verifySellerNumberChanged() throws Exception {
    Exchange exchange = new DefaultExchange(camelContext);
    DefaultMessage body = new DefaultMessage();

    try {
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehicle-seller-number-changed.xml");
      body.setBody(inputMessage);
      ProducerTemplate template = exchange.getContext().createProducerTemplate();

      template.sendBodyAndHeader("direct:processCdcMessage", inputMessage, "MSG_TYPE", "PFVEHICLE");

      verify(mockLogWrapper, atLeastOnce()).info(eq(VehicleChargesEventProcessor.class),
          contains("SELLER_CHARGES_CHANGED"));

    } catch (Exception e) {
      logger.error("Error processing seller offering purchased event", e);
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifySellerNumberChangedWithSruntmChangeOnly() throws Exception {
    Exchange exchange = new DefaultExchange(camelContext);
    DefaultMessage body = new DefaultMessage();

    try {
      String inputMessage = new CompXFileReader().fetchFileAsString("pfvehicle-sopera-changed.xml");
      body.setBody(inputMessage);
      ProducerTemplate template = exchange.getContext().createProducerTemplate();

      template.sendBodyAndHeader("direct:processCdcMessage", inputMessage, "MSG_TYPE", "PFVEHICLE");

      verify(mockLogWrapper, atLeastOnce()).info(eq(VehicleChargesEventProcessor.class),
          contains("SELLER_CHARGES_CHANGED"));

    } catch (Exception e) {
      logger.error("Error processing seller offering purchased event", e);
      Assert.fail(e.getMessage());
    }
  }

}

