package integration;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.processor.bee.ServiceOrderCreatedEventProcessor;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class ServiceOrderCreatedEventProcessorTest {

  @Autowired
  ServiceOrderCreatedEventProcessor serviceOrderCreatedEventProcessor;

  @Autowired
  CamelContext camelContext;

  Logger logger = LoggerFactory.getLogger(this.getClass());

  @Test
  public void verifyServiceOrderCreated() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("service-order-created.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      serviceOrderCreatedEventProcessor.process(exchange);
      AuctionEvent auctionEvent = exchange.getIn().getBody(AuctionEvent.class);
      logger.info("Auction Event - {}", auctionEvent);
      assertEquals("SELLER_SERVICE_ORDER_CREATED", auctionEvent.getEventType());
    } catch (Exception e) {
      logger.error("Error processing service order created event", e);
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifyCDCUseridPopulated() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("service-order-created.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      serviceOrderCreatedEventProcessor.process(exchange);
      AuctionEvent auctionEvent = exchange.getIn().getBody(AuctionEvent.class);
      logger.info("Auction Event - {}", auctionEvent);
      assertEquals("ETL", auctionEvent.getCdcUserId());
    } catch (Exception e) {
      logger.error("Error processing service order created event", e);
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifySellerChargesChangedForBuyerServiceOrder() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("buyer-service-order-created.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      serviceOrderCreatedEventProcessor.process(exchange);
      AuctionEvent auctionEvent = exchange.getIn().getBody(AuctionEvent.class);
      logger.info("Auction Event - {}", auctionEvent);
      assertNotEquals("SELLER_CHARGES_CHANGED", auctionEvent.getEventType());
    } catch (Exception e) {
      logger.error("Error processing service order created event", e);
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifyBuyerChargesChangedForBuyerServiceOrder() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("buyer-service-order-created.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      serviceOrderCreatedEventProcessor.process(exchange);
      AuctionEvent auctionEvent = exchange.getIn().getBody(AuctionEvent.class);
      logger.info("Auction Event - {}", auctionEvent);
      assertEquals("BUYER_SERVICE_ORDER_CREATED", auctionEvent.getEventType());
    } catch (Exception e) {
      logger.error("Error processing service order created event", e);
      Assert.fail(e.getMessage());
    }
  }

}

