package integration;

import static org.mockito.Matchers.contains;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.log4j.Appender;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.processor.vehicle.AdjustmentEventProcessor;
import com.manheim.ods.compx.consumer.processor.vehicle.PostSaleInspectionEventProcessor;
import com.manheim.ods.compx.consumer.processor.vehicle.ReconEventProcessor;
import com.manheim.ods.compx.consumer.processor.vehicle.ThirdPartyRemarketingEventProcessor;
import com.manheim.ods.compx.consumer.processor.vehicle.VehicleChargesEventProcessor;
import com.manheim.ods.compx.consumer.processor.vehicle.VehicleEventProcessor;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;



@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class ExchangeRouteBuilderIntegrationTest extends CamelTestSupport {
  @Autowired
  CamelContext camelContext;
  @Autowired
  private LogWrapper mockLogWrapper;

  @Mock
  private Appender mockAppender;
  @Captor
  private ArgumentCaptor<org.apache.log4j.spi.LoggingEvent> captorLoggingEvent;


  @Before
  public void mockEndpoints() throws Exception {
    AdviceWithRouteBuilder mockStreamRoute = new AdviceWithRouteBuilder() {

      @Override
      public void configure() throws Exception {
        // mock the for testing
        interceptSendToEndpoint("direct:stream").skipSendToOriginalEndpoint()
            .to("mock:catchStreamMessages").log("Stream messages caught - ${body}");

      }
    };

    camelContext.getRouteDefinition("aggregate-tbox-events").adviceWith(camelContext,
        mockStreamRoute);
  }

  @Test
  public void verifyEventsForSpecialCharactersInSourceData() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehicle-funky-characters.xml");

      body.setBody(inputMessage);
      exchange.setIn(body);
      ProducerTemplate template = camelContext.createProducerTemplate();
      template.send("direct:processCdcMessage", exchange);
      verify(mockLogWrapper, atLeastOnce()).info(eq(VehicleEventProcessor.class),
          contains("eventType=CHECK_IN"));

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }


  @Test
  public void verifyEventsForPfrecon() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfrecon-seller-charges-test.xml");

      body.setBody(inputMessage);
      exchange.setIn(body);
      ProducerTemplate template = camelContext.createProducerTemplate();
      template.send("direct:processCdcMessage", exchange);
      verify(mockLogWrapper, atLeastOnce()).info(eq(ReconEventProcessor.class),
          contains("eventType=SELLER_CHARGES_CHANGED"));

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }


  @Test
  public void verifyEventsForTprmktbl() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("tprmktbl-seller-charges.xml");

      body.setBody(inputMessage);
      exchange.setIn(body);
      ProducerTemplate template = camelContext.createProducerTemplate();
      template.send("direct:processCdcMessage", exchange);
      verify(mockLogWrapper, atLeastOnce()).info(eq(ThirdPartyRemarketingEventProcessor.class),
          contains("eventType=SELLER_CHARGES_CHANGED"));

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }

  @Test
  public void verifyEventsForHistUserChanges() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehicle-histuser-updates.xml");

      body.setBody(inputMessage);
      exchange.setIn(body);
      ProducerTemplate template = camelContext.createProducerTemplate();
      template.send("direct:processCdcMessage", exchange);
      verify(mockLogWrapper, atLeastOnce()).info(eq(VehicleChargesEventProcessor.class),
          contains("eventType=SELLER_CHARGES_CHANGED"));

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }


  @Test
  public void verifyEventsForAdjustmentChanges() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfsadjdtl-update.xml");

      body.setBody(inputMessage);
      exchange.setIn(body);
      ProducerTemplate template = camelContext.createProducerTemplate();
      template.send("direct:processCdcMessage", exchange);
      verify(mockLogWrapper, atLeastOnce()).info(eq(AdjustmentEventProcessor.class),
          contains("eventType=BUYER_CHARGES_CHANGED"));

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }



  @Test
  public void verifyEventsForPfpsi() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfpsi-update.xml");

      body.setBody(inputMessage);
      exchange.setIn(body);
      ProducerTemplate template = camelContext.createProducerTemplate();
      template.send("direct:processCdcMessage", exchange);
      verify(mockLogWrapper, atLeastOnce()).info(eq(PostSaleInspectionEventProcessor.class),
          contains("eventType=BUYER_CHARGES_CHANGED"));

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }

  @Test
  public void verifyEventsForG2gBuySell() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfvehicle-cr1272-updates.xml");

      body.setBody(inputMessage);
      exchange.setIn(body);
      ProducerTemplate template = camelContext.createProducerTemplate();
      template.send("direct:processCdcMessage", exchange);
      verify(mockLogWrapper, atLeastOnce()).info(eq(VehicleChargesEventProcessor.class),
          contains("eventType=BUYER_CHARGES_CHANGED"));

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }


  @Test
  public void verifyEventsForAggregation() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage pfvehicleMessageBody = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehicle-aggregation-update1.xml");

      pfvehicleMessageBody.setBody(inputMessage);
      exchange.setIn(pfvehicleMessageBody);
      ProducerTemplate template = camelContext.createProducerTemplate();
      template.send("direct:processCdcMessage", exchange);

      String pfvehextMessage =
          new CompXFileReader().fetchFileAsString("pfrecon-aggregation-update2.xml");

      DefaultMessage pfvehextMessageBody = new DefaultMessage();

      pfvehextMessageBody.setBody(pfvehextMessage);
      exchange.setIn(pfvehextMessageBody);
      MockEndpoint resultEndpoint =
          camelContext.getEndpoint("mock:catchStreamMessages", MockEndpoint.class);

      resultEndpoint.expectedMessageCount(2);
      template.send("direct:processCdcMessage", exchange);
      Thread.sleep(2000);
      assertMockEndpointsSatisfied();
      List<Exchange> exchanges = resultEndpoint.getExchanges();
      List<Message> messages = exchanges.stream().map(Exchange::getIn).collect(Collectors.toList());
      assert (messages.stream().anyMatch(
          m -> m.getBody(AuctionEvent.class).getEventType().equals("SELLER_CHARGES_CHANGED")));
      assert (messages.stream().anyMatch(
          m -> m.getBody(AuctionEvent.class).getEventType().equals("BUYER_CHARGES_CHANGED")));
      assert (messages.size() == 2);

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }

}

