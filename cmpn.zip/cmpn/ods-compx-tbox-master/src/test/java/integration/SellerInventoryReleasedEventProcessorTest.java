package integration;


import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.route.BusinessEventsMessageRouteBuilder;
import com.manheim.ods.compx.consumer.route.OutboundRouteBuilder;
import com.manheim.ods.compx.helper.CompXFileReader;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class SellerInventoryReleasedEventProcessorTest extends CamelTestSupport {

  @Autowired
  OutboundRouteBuilder outboundRouteBuilder;
  @Autowired
  BusinessEventsMessageRouteBuilder beeRouteBuilder;
  @Autowired
  @Value("${invreleased.ignore.older.than}")
  private int invReleasedIgnoreOlderThan;

  Logger logger = LoggerFactory.getLogger(this.getClass());

  @Before
  public void setUp() throws Exception {
    super.setUp();
    MockitoAnnotations.initMocks(this);

    context.addRoutes(new RouteBuilder() {
      @Override
      public void configure() throws Exception {
        from("direct:stream").to("mock:stream").log("Mock received: $body");
      }
    });

    context.addRoutes(outboundRouteBuilder);
    context.addRoutes(beeRouteBuilder);
  }

  @Test
  public void verifySellerInventoryReleased() throws Exception {
    DefaultMessage body = new DefaultMessage();

    try {
      String inputMessage =
          new CompXFileReader().fetchFileAsString("seller-inventory-released.xml");
      body.setBody(inputMessage);
      getMockEndpoint("mock:stream").expectedMessageCount(1);
      ProducerTemplate template = context.createProducerTemplate();
      template.sendBodyAndHeader("direct:processBeeMessage", inputMessage, "MSG_TYPE",
          "Seller Inventory Released");
      getMockEndpoint("mock:stream").assertIsSatisfied();


    } catch (Exception e) {
      logger.error("Error processing seller inventory removed event.", e);
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifySellerInventoryReleasedWithoutRedeemedDate() throws Exception {
    DefaultMessage body = new DefaultMessage();

    try {
      String inputMessage =
          new CompXFileReader().fetchFileAsString("seller-inventory-released-no-redeemeddate.xml");
      body.setBody(inputMessage);
      getMockEndpoint("mock:stream").expectedMessageCount(1);
      ProducerTemplate template = context.createProducerTemplate();
      template.sendBodyAndHeader("direct:processBeeMessage", inputMessage, "MSG_TYPE",
          "Seller Inventory Released");
      getMockEndpoint("mock:stream").assertIsSatisfied();


    } catch (Exception e) {
      logger.error("Error processing seller inventory removed event.", e);
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifySellerInventoryReleasedWithBadRedeemedDate() throws Exception {
    DefaultMessage body = new DefaultMessage();

    try {
      String inputMessage =
          new CompXFileReader().fetchFileAsString("seller-inventory-released-bad-redeemeddate.xml");
      body.setBody(inputMessage);
      getMockEndpoint("mock:stream").expectedMessageCount(1);
      ProducerTemplate template = context.createProducerTemplate();
      template.sendBodyAndHeader("direct:processBeeMessage", inputMessage, "MSG_TYPE",
          "Seller Inventory Released");
      getMockEndpoint("mock:stream").assertIsSatisfied();


    } catch (Exception e) {
      logger.error("Error processing seller inventory removed event.", e);
      Assert.fail(e.getMessage());
    }
  }


  @Test
  public void verifySellerInventoryReleasedForHistory() throws Exception {
    DefaultMessage body = new DefaultMessage();

    try {
      String inputMessage =
          new CompXFileReader().fetchFileAsString("seller-inventory-released-history.xml");
      body.setBody(inputMessage);
      getMockEndpoint("mock:stream").expectedMessageCount(0);
      ProducerTemplate template = context.createProducerTemplate();
      template.sendBodyAndHeader("direct:processBeeMessage", inputMessage, "MSG_TYPE",
          "Seller Inventory Released");

      getMockEndpoint("mock:stream").assertIsSatisfied();

    } catch (Exception e) {
      logger.error("Error processing seller inventory removed event.", e);
      Assert.fail(e.getMessage());
    }
  }

}

