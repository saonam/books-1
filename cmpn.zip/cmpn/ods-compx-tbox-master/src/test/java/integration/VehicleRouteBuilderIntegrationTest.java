package integration;

import static org.hamcrest.Matchers.hasItems;
import static org.mockito.Matchers.contains;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWithRouteBuilder;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.processor.vehicle.VehicleChargesEventProcessor;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;

import ch.qos.logback.classic.spi.LoggingEvent;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class VehicleRouteBuilderIntegrationTest extends CamelTestSupport {
  @Captor
  private ArgumentCaptor<LoggingEvent> captorLoggingEvent;
  @Autowired
  CamelContext camelContext;
  @Autowired
  private LogWrapper mockLogWrapper;

  @Test
  public void verifyMultipleEvents() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehicle-listing-checkin-charges.xml");

      body.setBody(inputMessage);
      exchange.setIn(body);
      ProducerTemplate template = exchange.getContext().createProducerTemplate();
      template.send("direct:compx-inventory-charges-route", exchange);

      // verify(mockLogWrapper, atLeastOnce()).info(eq(VehicleEventProcessor.class),
      // contains("CHECK_IN"));
      // Check log level
      verify(mockLogWrapper, atLeastOnce()).info(eq(VehicleChargesEventProcessor.class),
          contains("BUYER_CHARGES_CHANGED"));

      verify(mockLogWrapper, atLeastOnce()).info(eq(VehicleChargesEventProcessor.class),
          contains("SELLER_CHARGES_CHANGED"));

      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      List<String> eventTypes = new ArrayList<String>();
      for (AuctionEvent auctionEvent : auctionEvents) {
        eventTypes.add(auctionEvent.getEventType());

      }
      assertThat(eventTypes, hasItems("BUYER_CHARGES_CHANGED", "SELLER_CHARGES_CHANGED"));
    } catch (Exception ex) {
      fail("Vehicle seller processing failed!!!");
    }
  }


  @Before
  public void mockEndpoints() throws Exception {
    AdviceWithRouteBuilder mockStreamRoute = new AdviceWithRouteBuilder() {

      @Override
      public void configure() throws Exception {
        // mock the for testing
        interceptSendToEndpoint("direct:stream").skipSendToOriginalEndpoint()
            .to("mock:catchStreamMessages").to("log:com.manheim?level=WARN");
      }
    };
    camelContext.getRouteDefinition("send-tbox-events").adviceWith(camelContext, mockStreamRoute);
  }

}

