package integration;


import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.processor.bee.BuyerOrderBuyerNumberChangedEventProcessor;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class BuyerOrderBuyerNumberChangedEventProcessorIntegrationTest {

  @Autowired
  BuyerOrderBuyerNumberChangedEventProcessor buyerOrderBuyerNumberChangedEventProcessor;

  @Autowired
  CamelContext camelContext;

  @Test
  public void verifyBuyerOrderBuyerNumberChargesUpdated() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("buyer-order-buyer-number-changed.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      buyerOrderBuyerNumberChangedEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      for (AuctionEvent auctionEvent : auctionEvents) {
        assertThat(auctionEvent.getEventType(), is("BUYER_CHARGES_CHANGED"));

      }
    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }
  }


}

