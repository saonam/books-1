package integration;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.apache.log4j.Appender;
import org.apache.log4j.LogManager;
import org.apache.log4j.spi.LoggingEvent;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.route.ChangeDataCaptureRouteBuilder;
import com.manheim.ods.compx.consumer.route.HeartbeatRouteBuilder;
import com.manheim.ods.compx.consumer.route.OutboundRouteBuilder;
import com.manheim.ods.compx.consumer.route.ReconRouteBuilder;
import com.manheim.ods.compx.consumer.route.StreamingRouteBuilder;
import com.manheim.ods.compx.consumer.route.VehicleExtRouteBuilder;
import com.manheim.ods.compx.consumer.route.VehicleRouteBuilder;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class MessageAggregatorIntegrationTest extends CamelTestSupport {


  @Mock
  private Appender appender;
  @Captor
  private ArgumentCaptor<LoggingEvent> captor;

  @Autowired
  StreamingRouteBuilder streamingRouteBuilder;
  @Autowired
  OutboundRouteBuilder outboundRouteBuilder;
  @Autowired
  VehicleRouteBuilder vehicleRouteBuilder;
  @Autowired
  ReconRouteBuilder reconRouteBuilder;
  @Autowired
  VehicleExtRouteBuilder vehicleExtRouteBuilder;
  @Autowired
  HeartbeatRouteBuilder heartbeatRouteBuilder;
  @Autowired
  ChangeDataCaptureRouteBuilder changeDataCaptureRouteBuilder;
  @Value("${activemq.source.queues}")
  private String activemqSourceQueues;

  @Test
  public void verifyEventsAggregation() throws Exception {

    try {
      String allMessages =
          new CompXFileReader().fetchFileAsString("pfvehicle-aggregate-messages.txt");
      String[] pfvehicleCdcMessages = allMessages.split("\n");

      MockEndpoint resultEndpoint = getMockEndpoint("mock:stream", false);
      resultEndpoint.expectedMessageCount(4);
      for (String inputMessage : pfvehicleCdcMessages) {
        Exchange exchange = new DefaultExchange(context);
        exchange.getIn().setBody(inputMessage);
        ProducerTemplate template = context.createProducerTemplate();
        template.send("direct:processCdcMessage", exchange);
      }
      Thread.sleep(3000);
      List<Exchange> exchanges = resultEndpoint.getExchanges();
      log.info("Aggregation Log: ");
      for (Exchange exchange : exchanges) {
        AuctionEvent auctionEvent = exchange.getIn().getBody(AuctionEvent.class);
        log.info("AuctionEvent - {}", auctionEvent);
      }
      log.info("Completed Aggregation Log: ");
      resultEndpoint.assertIsSatisfied();
    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }


  @Test
  public void verifyHeartbeatEventsDoNotAggregate() throws Exception {

    try {
      String allMessages =
          new CompXFileReader().fetchFileAsString("heartbeat-donot-aggregate-messages.txt");
      String[] heartbeatMessages = allMessages.split("\n");

      MockEndpoint resultEndpoint = getMockEndpoint("mock:stream", false);
      resultEndpoint.expectedMessageCount(4);
      for (String inputMessage : heartbeatMessages) {
        Exchange exchange = new DefaultExchange(context);
        exchange.getIn().setBody(inputMessage);
        ProducerTemplate template = context.createProducerTemplate();
        template.send("direct:processCdcMessage", exchange);
      }
      Thread.sleep(3000);
      List<Exchange> exchanges = resultEndpoint.getReceivedExchanges();
      log.info("Aggregation Log: ");
      for (Exchange exchange : exchanges) {
        AuctionEvent auctionEvent = exchange.getIn().getBody(AuctionEvent.class);
        log.info("AuctionEvent - {}", auctionEvent);
      }
      log.info("End Aggregation Log: ");
      resultEndpoint.assertIsSatisfied();
    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }


  @Before
  public void setUp() throws Exception {
    super.setUp();
    MockitoAnnotations.initMocks(this);
    LogManager.getRootLogger().addAppender(appender);

    context.addRoutes(new RouteBuilder() {
      @Override
      public void configure() throws Exception {
        from("direct:stream").to("mock:stream").log("Mock received: ${body}");
      }
    });

    context.addRoutes(outboundRouteBuilder);
    context.addRoutes(vehicleRouteBuilder);
    context.addRoutes(reconRouteBuilder);
    context.addRoutes(vehicleExtRouteBuilder);
    context.addRoutes(heartbeatRouteBuilder);
    context.addRoutes(changeDataCaptureRouteBuilder);
  }

}
