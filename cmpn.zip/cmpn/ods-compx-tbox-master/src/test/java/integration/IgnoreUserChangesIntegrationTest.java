package integration;


import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.test.junit4.CamelTestSupport;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.route.ChangeDataCaptureRouteBuilder;
import com.manheim.ods.compx.consumer.route.HeartbeatRouteBuilder;
import com.manheim.ods.compx.consumer.route.OutboundRouteBuilder;
import com.manheim.ods.compx.consumer.route.ReconRouteBuilder;
import com.manheim.ods.compx.consumer.route.StreamingRouteBuilder;
import com.manheim.ods.compx.consumer.route.VehicleExtRouteBuilder;
import com.manheim.ods.compx.consumer.route.VehicleRouteBuilder;
import com.manheim.ods.compx.helper.CompXFileReader;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class IgnoreUserChangesIntegrationTest extends CamelTestSupport {
  @Autowired
  StreamingRouteBuilder streamingRouteBuilder;
  @Autowired
  OutboundRouteBuilder outboundRouteBuilder;
  @Autowired
  VehicleRouteBuilder vehicleRouteBuilder;
  @Autowired
  ReconRouteBuilder reconRouteBuilder;
  @Autowired
  VehicleExtRouteBuilder vehicleExtRouteBuilder;
  @Autowired
  HeartbeatRouteBuilder heartbeatRouteBuilder;
  @Autowired
  ChangeDataCaptureRouteBuilder changeDataCaptureRouteBuilder;


  @Test
  public void verifyVehicleEventsForHistUserUpdates() throws Exception {
    try {
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehicle-histuser-seller-charges.xml");
      getMockEndpoint("mock:direct:send-tbox-events", false).expectedMessageCount(0);
      template.sendBody("direct:processCdcMessage", inputMessage);
      getMockEndpoint("mock:direct:send-tbox-events", false).assertIsSatisfied();


    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }

  @Test
  public void verifyReconEventsForHistUserUpdates() throws Exception {

    try {
      String inputMessage = new CompXFileReader().fetchFileAsString("pfrecon-insert-histuser.xml");
      getMockEndpoint("mock:direct:send-tbox-events").expectedMessageCount(0);
      template.sendBody("direct:processCdcMessage", inputMessage);
      getMockEndpoint("mock:direct:send-tbox-events").assertIsSatisfied();

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }

  public void verifyVehextEventsForHistUserUpdates() throws Exception {

    try {
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehext-insert-charges-histuser.xml");

      getMockEndpoint("mock:direct:send-tbox-events").expectedMessageCount(0);
      template.sendBody("direct:processCdcMessage", inputMessage);
      getMockEndpoint("mock:direct:send-tbox-events").assertIsSatisfied();

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }

  @Test
  public void verifyVehicleEventsForBEEUserUpdates() throws Exception {

    try {
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehicle-beeuser-updates.xml");
      getMockEndpoint("mock:direct:send-tbox-events").expectedMessageCount(0);
      template.sendBody("direct:processCdcMessage", inputMessage);
      getMockEndpoint("mock:direct:send-tbox-events").assertIsSatisfied();

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }

  @Test
  public void verifyVehicleEventsForMMRUserUpdates() throws Exception {

    try {
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehicle-mmruser-updates.xml");
      getMockEndpoint("mock:direct:send-tbox-events").expectedMessageCount(0);
      template.sendBody("direct:processCdcMessage", inputMessage);
      getMockEndpoint("mock:direct:send-tbox-events").assertIsSatisfied();

    } catch (Exception ex) {
      ex.printStackTrace();
      fail("Vehicle seller processing failed!!!");
    }
  }

  @Before
  public void before() throws Exception {
    super.setUp();
    MockitoAnnotations.initMocks(this);

    context.addRoutes(new RouteBuilder() {
      @Override
      public void configure() throws Exception {
        from("direct:send-tbox-events").to("mock:direct:send-tbox-events")
            .log("Mock received: $body");
      }
    });

    context.addRoutes(vehicleRouteBuilder);
    context.addRoutes(reconRouteBuilder);
    context.addRoutes(vehicleExtRouteBuilder);
    context.addRoutes(heartbeatRouteBuilder);
    context.addRoutes(changeDataCaptureRouteBuilder);
  }



}

