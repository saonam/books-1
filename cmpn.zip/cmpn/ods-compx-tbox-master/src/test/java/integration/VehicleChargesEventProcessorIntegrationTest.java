package integration;


import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.processor.vehicle.VehicleChargesEventProcessor;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class VehicleChargesEventProcessorIntegrationTest {

  @Autowired
  VehicleChargesEventProcessor vehicleChargesEventProcessor;

  @Autowired
  CamelContext camelContext;

  @Test
  public void verifySellerChargesUpdated() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfvehicle-seller-charges.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleChargesEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      for (AuctionEvent auctionEvent : auctionEvents) {
        assertThat(auctionEvent.getEventType(), is("SELLER_CHARGES_CHANGED"));

      }
    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifyBuyerChargesUpdated() throws Exception {
    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfvehicle-buyer-charges.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleChargesEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      for (AuctionEvent auctionEvent : auctionEvents) {
        assertThat(auctionEvent.getEventType(), is("BUYER_CHARGES_CHANGED"));

      }
    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }

  }


  @Test
  public void verifyBothBuyerChargesUpdated() throws Exception {
    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehicle-seller-and-buyer-charges.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleChargesEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      List<String> eventTypes = new ArrayList<String>();
      for (AuctionEvent auctionEvent : auctionEvents) {
        eventTypes.add(auctionEvent.getEventType());

      }
      assertThat(eventTypes, hasItems("BUYER_CHARGES_CHANGED", "SELLER_CHARGES_CHANGED"));

    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }

  }

  @Test
  public void verifyIfSaleSellerChargesChangedEvent() throws Exception {
    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfvehicle-ifsale.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleChargesEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      List<String> eventTypes = new ArrayList<String>();
      for (AuctionEvent auctionEvent : auctionEvents) {
        eventTypes.add(auctionEvent.getEventType());

      }
      assertThat(eventTypes, hasItem("SELLER_CHARGES_CHANGED"));

    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }

  }

  @Test
  public void verifyIfSaleBuyerChargesChangedEvent() throws Exception {
    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfvehicle-ifsale-ss.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleChargesEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      List<String> eventTypes = new ArrayList<String>();
      for (AuctionEvent auctionEvent : auctionEvents) {
        eventTypes.add(auctionEvent.getEventType());

      }
      assertThat(eventTypes, hasItems("BUYER_CHARGES_CHANGED", "SELLER_CHARGES_CHANGED"));

    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }

  }

  @Test
  public void verifyBuyerAndSellerChargesChangedEventWhenVehicleTypeChangedAfterSale()
      throws Exception {
    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehicle-vehicletype-changed.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleChargesEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      List<String> eventTypes = new ArrayList<String>();
      for (AuctionEvent auctionEvent : auctionEvents) {
        eventTypes.add(auctionEvent.getEventType());

      }
      assertThat(eventTypes, hasItems("BUYER_CHARGES_CHANGED", "SELLER_CHARGES_CHANGED"));

    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }

  }

  @Test
  public void verifyBuyerAndSellerChargesChangedEventWhenCBSBuyerChanged() throws Exception {
    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfvehicle-cr1272-updates.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleChargesEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      List<String> eventTypes = new ArrayList<String>();
      List<String> sourceEventNames = new ArrayList<String>();
      for (AuctionEvent auctionEvent : auctionEvents) {
        eventTypes.add(auctionEvent.getEventType());
        sourceEventNames.add(auctionEvent.getSourceEventName());

      }
      assertThat(eventTypes, hasItems("BUYER_CHARGES_CHANGED", "SELLER_CHARGES_CHANGED"));
      assertThat(sourceEventNames, hasItems("CBS_BUYER_CHARGES_CHANGED"));

    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }

  }

}

