package integration;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.impl.DefaultExchange;
import org.apache.camel.impl.DefaultMessage;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import com.manheim.ods.compx.consumer.TestApplication;
import com.manheim.ods.compx.consumer.processor.vehicle.VehicleExtEventProcessor;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.model.eventer.AuctionEvent;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,
    classes = TestApplication.class)
@ActiveProfiles(profiles = "test")
public class VehicleExtEventProcessorIntegrationTest {

  @Autowired
  VehicleExtEventProcessor vehicleExtEventProcessor;

  @Autowired
  CamelContext camelContext;

  @Test
  public void verifySellerChargesChangedEventInInsert() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehext-insert-seller-charges.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleExtEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      for (AuctionEvent auctionEvent : auctionEvents) {
        assertThat(auctionEvent.getEventType(), is("SELLER_CHARGES_CHANGED"));
      }
    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifySellerChargesChangedEventInUpdate() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehext-update-seller-charges.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleExtEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      for (AuctionEvent auctionEvent : auctionEvents) {
        assertThat(auctionEvent.getEventType(), is("SELLER_CHARGES_CHANGED"));
      }
    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifyBuyerChargesChangedEventInInsert() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehext-insert-buyer-charges.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleExtEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      for (AuctionEvent auctionEvent : auctionEvents) {
        assertThat(auctionEvent.getEventType(), is("BUYER_CHARGES_CHANGED"));
      }
    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifyBuyerChargesChangedEventInUpdate() throws Exception {

    try {
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage =
          new CompXFileReader().fetchFileAsString("pfvehext-update-buyer-charges.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleExtEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      for (AuctionEvent auctionEvent : auctionEvents) {
        assertThat(auctionEvent.getEventType(), is("BUYER_CHARGES_CHANGED"));
      }
    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifyBothSellerAndBuyerChargesChangedEventInUpdate() throws Exception {

    try {
      StringBuilder events = new StringBuilder();
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfvehext-update-charges.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleExtEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      for (AuctionEvent auctionEvent : auctionEvents) {
        events.append(auctionEvent.getEventType());
        events.append(", ");
      }
      assertThat(events.substring(0, events.length()),
          is("SELLER_CHARGES_CHANGED, BUYER_CHARGES_CHANGED, "));
    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }
  }

  @Test
  public void verifyBothSellerAndBuyerChargesChangedEventInInsert() throws Exception {

    try {
      StringBuilder events = new StringBuilder();
      Exchange exchange = new DefaultExchange(camelContext);
      DefaultMessage body = new DefaultMessage();
      String inputMessage = new CompXFileReader().fetchFileAsString("pfvehext-insert-charges.xml");
      body.setBody(inputMessage);
      exchange.setIn(body);
      vehicleExtEventProcessor.process(exchange);
      Object messageBody = exchange.getIn().getBody();
      List<AuctionEvent> auctionEvents = (List<AuctionEvent>) messageBody;
      for (AuctionEvent auctionEvent : auctionEvents) {
        events.append(auctionEvent.getEventType());
        events.append(", ");
      }
      assertThat(events.substring(0, events.length()),
          is("SELLER_CHARGES_CHANGED, BUYER_CHARGES_CHANGED, "));
    } catch (Exception e) {
      Assert.fail(e.getMessage());
    }
  }

}
