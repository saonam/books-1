package com.manheim.ods.compx.web;

import com.manheim.ods.compx.util.LogWrapper;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import java.io.IOException;

@Component
public class LoggingFilter implements Filter {

    private LogWrapper logger;

    @Autowired
    public LoggingFilter(LogWrapper logger) {
        this.logger = logger;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        try {
            logger.debug(LoggingFilter.class, "Clearing MDC before request");
            // Make sure the MDC is empty at the start of this request
            MDC.clear();
            chain.doFilter(request, response);
        } finally {
            logger.debug(LoggingFilter.class, "Clearing MDC after request");
            // Tear down MDC data: (Important! Cleans up the ThreadLocal data again)
            MDC.clear();
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Nothing to do here
    }

    @Override
    public void destroy() {
        // Nothing to do here
    }
}
