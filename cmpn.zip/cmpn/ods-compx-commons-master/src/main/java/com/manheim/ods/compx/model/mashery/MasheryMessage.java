package com.manheim.ods.compx.model.mashery;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class MasheryMessage {

    @Getter
    @JsonProperty("accessToken")
    private String masheryAccessToken;
}
