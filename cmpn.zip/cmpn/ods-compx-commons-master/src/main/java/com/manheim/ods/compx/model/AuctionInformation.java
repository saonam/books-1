package com.manheim.ods.compx.model;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public class AuctionInformation {

  @Getter
  public String[] auctions;

}
