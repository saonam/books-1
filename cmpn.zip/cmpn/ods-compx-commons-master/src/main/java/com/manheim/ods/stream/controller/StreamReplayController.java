package com.manheim.ods.stream.controller;

import java.net.UnknownHostException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import javax.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.manheim.ods.stream.consumer.KinesisReceiver;
import com.manheim.ods.stream.consumer.WorkerAlreadyRunningException;
import com.manheim.ods.stream.model.ReplayRequest;

@RequestMapping("/stream/replay")
@RestController
@EnableAsync
public class StreamReplayController {

  private KinesisReceiver kinesisReceiver;

  Logger logger = LoggerFactory.getLogger(StreamReplayController.class);

  @Autowired
  public StreamReplayController(KinesisReceiver kinesisReceiver) {
    this.kinesisReceiver = kinesisReceiver;
  }

  /**
   * 
   * @param timestampString yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS'
   * @return
   * @throws UnknownHostException
   * @throws InterruptedException
   * @throws WorkerAlreadyRunningException
   * @throws ExecutionException
   */

  @PostMapping("/start")
  @ResponseStatus(HttpStatus.CREATED)
  public ResponseEntity<String> replay(@Valid @RequestBody ReplayRequest request)
      throws UnknownHostException {

    /*
     * Stop the receiver from processing records before replaying
     */
    this.kinesisReceiver.shutdown();

    /*
     * stop any existing running replay processes
     */
    this.kinesisReceiver.stopReplayTime();
    /*
     * replay starting from time and duration in minutes
     */

    Future<String> completableFuture = this.kinesisReceiver.replayTime(request.getStartTimestamp(),
        request.getDurationInMinutes());


    if (null != completableFuture) {
      return new ResponseEntity<>("Kinesis replay worker started", HttpStatus.CREATED);
    } else {
      return new ResponseEntity<>("Failed to replay Kinesis records",
          HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

  @GetMapping("/stop")
  public ResponseEntity<String> stop() throws UnknownHostException {

    this.kinesisReceiver.stopReplayTime();

    return new ResponseEntity<>("Kinesis replay worker shutdown", HttpStatus.OK);
  }
}
