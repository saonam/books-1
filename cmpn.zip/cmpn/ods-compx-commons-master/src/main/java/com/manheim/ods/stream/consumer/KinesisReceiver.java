package com.manheim.ods.stream.consumer;

import java.net.UnknownHostException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;

import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;

@Component
@EnableAsync
public class KinesisReceiver {

  @Autowired
  KinesisWorkerFactory workerFactory;
  @Autowired
  KinesisRecordProcessorFactory kinesisRecordProcessorFactory;

  @Autowired
  KinesisClientLibConfiguration kinesisClientLibConfiguration;
  boolean isrunning = false;
  Logger logger = LoggerFactory.getLogger(KinesisReceiver.class);

  Worker worker;
  Worker replayWorker;

  public KinesisReceiver(KinesisWorkerFactory kinesisWorkerFactory,
      KinesisRecordProcessorFactory chargesRecordProcessorFactory,
      KinesisClientLibConfiguration kinesisClientLibConfiguration, Worker worker) {
    this.workerFactory = kinesisWorkerFactory;
    this.kinesisRecordProcessorFactory = chargesRecordProcessorFactory;
    this.kinesisClientLibConfiguration = kinesisClientLibConfiguration;
    this.worker = worker;
  }

  private void startWorker() throws WorkerAlreadyRunningException {

    if (isrunning)
      throw new WorkerAlreadyRunningException(
          String.format("Kinesis worker %s is running, stop it if you want to restart!! ",
              worker.getApplicationName()));
    worker = workerFactory.newWorker();
    logger.info("Start worker {}", worker.getApplicationName());
    new Thread(worker).start();

    isrunning = true;
  }

  private void shutdownWorker() {
    logger.info("Shutdown worker {}", worker.getApplicationName());
    worker.shutdown();
    isrunning = false;
  }


  public void start() throws WorkerAlreadyRunningException {
    startWorker();
  }

  public void restart() throws WorkerAlreadyRunningException {
    shutdownWorker();
    startWorker();

  }

  public void shutdown() {
    shutdownWorker();
  }

  @Async
  public Future<String> replayTime(String startTimestamp, int durationInMinutes)
      throws UnknownHostException {

    replayWorker = workerFactory.newReplayWorker(startTimestamp);
    logger.info("Replay worker {} from {} started", replayWorker.getApplicationName(),
        startTimestamp);

    new Thread(replayWorker).start();

    CompletableFuture<String> completableFuture = new CompletableFuture<>();

    try {
      logger.info("thread sleep for {} minutes ", durationInMinutes);
      Thread.sleep(durationInMinutes * 60 * 1000L);
      logger.info("thread activated after {} minutes ", durationInMinutes);
      stopReplayTime();
      completableFuture.complete("success");
      startWorker();
    } catch (InterruptedException e) {
      logger.warn("Interrupted Exception", this.getClass(), e);
      Thread.currentThread().interrupt();
    } catch (WorkerAlreadyRunningException we) {
      logger.warn("Interrupted Exception", this.getClass(), we);
      return null;
    }

    return completableFuture;
  }

  public void stopReplayTime() throws UnknownHostException {
    if (replayWorker != null) {
      logger.info("Replay worker {} shutdown", replayWorker.getApplicationName());
      replayWorker.shutdown();
    }
  }

}
