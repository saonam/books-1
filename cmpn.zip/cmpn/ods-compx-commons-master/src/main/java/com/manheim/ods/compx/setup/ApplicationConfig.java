package com.manheim.ods.compx.setup;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.manheim.ods.compx.web.LoggingFilter;

@Configuration
public class ApplicationConfig {

  @Bean
  public FilterRegistrationBean loggingFilterRegistrationBean(LoggingFilter loggingFilter) {
    FilterRegistrationBean registrationBean = new FilterRegistrationBean();
    registrationBean.setFilter(loggingFilter);
    registrationBean.setOrder(1);
    return registrationBean;
  }



}
