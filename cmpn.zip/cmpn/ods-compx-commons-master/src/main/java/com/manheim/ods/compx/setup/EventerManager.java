package com.manheim.ods.compx.setup;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.client.CreateSubscriberClient;
import com.manheim.ods.compx.client.CreateSubscriptionClient;
import com.manheim.ods.compx.client.GetSubscriberClient;
import com.manheim.ods.compx.client.MasheryClient;
import com.manheim.ods.compx.exception.EventerSubscriptionException;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.model.eventer.MySubscriberMessage;
import com.manheim.ods.compx.service.MailService;
import com.manheim.ods.compx.util.LoadIfNotTestOrDevProfile;
import com.manheim.ods.compx.util.LogWrapper;

@Component
@Conditional(LoadIfNotTestOrDevProfile.class)
public class EventerManager {

  private static final String SUBJECT = "Failed To Call Eventer";
  private static final String EMAIL_WARNING = "Failed to call Eventer when creating a subscription";

  private MasheryClient masheryClient;
  private CreateSubscriptionClient createSubscriptionClient;
  private List<String> messagePatterns;
  private MailService mailService;
  private final LogWrapper logger;
  private CreateSubscriberClient createSubscriberClient;
  private GetSubscriberClient getSubscriberClient;

  private String accessToken = "";
  private String subscriberHref = "";

  @Autowired
  public EventerManager(MasheryClient masheryClient, CreateSubscriberClient createSubscriberClient,
      GetSubscriberClient getSubscriberClient, CreateSubscriptionClient createSubscriptionClient,
      @Value("${eventer.message.patterns}") String[] messagePatterns, MailService mailService,
      LogWrapper logger) {
    this.masheryClient = masheryClient;
    this.createSubscriberClient = createSubscriberClient;
    this.getSubscriberClient = getSubscriberClient;
    this.createSubscriptionClient = createSubscriptionClient;
    this.messagePatterns = Arrays.asList(messagePatterns);
    this.mailService = mailService;
    this.logger = logger;
  }

  @PostConstruct
  public void setUp() throws EventerSubscriptionException {
    try {
      getAccessToken();
    } catch (IOException e) {
      logger.error(EventerManager.class, e);
      throw new EventerSubscriptionException("IOException calling MasheryClient access token!!");
    }
    subscribe();
  }

  private void getAccessToken() throws IOException {
    accessToken = masheryClient.fetchAccessToken();
  }

  private void subscribe() throws EventerSubscriptionException {
    try {
      MySubscriberMessage subscriberMessage =
          getSubscriberClient.getEventerSubscribers(accessToken);

      if (hasSubscribers(subscriberMessage)) {
        subscriberHref = subscriberMessage.getSubscribers().get(0).getHref();
      } else {
        createSubscriber();
      }

      createSubscriptions();
    } catch (UnsuccessfulClientExecutionException e) {
      mailService.sendMessage(SUBJECT, EMAIL_WARNING);
      logger.error(this.getClass(), e);
    }
  }

  private void createSubscriber() throws EventerSubscriptionException {
    subscriberHref = createSubscriberClient.createSubscriber(accessToken);

  }

  private void createSubscriptions() throws EventerSubscriptionException {
    for (String messagePattern : messagePatterns) {
      createSubscriptionClient.createSubscription(accessToken, subscriberHref, messagePattern);
    }
  }

  private boolean hasSubscribers(MySubscriberMessage subscriberMessage) {
    return !subscriberMessage.getSubscribers().isEmpty();
  }
}
