package com.manheim.ods.compx.api;

import com.manheim.ods.compx.model.eventer.MySubscriberMessage;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface EventerAPI {
    @POST("/subscribers")
    Call<Void> configureEventerSubscriberCall(@Header("Authorization") String token, @Body RequestBody object);

    @GET("/subscribers/mine")
    Call<MySubscriberMessage> configureEventerMySubscribersCall(@Header("Authorization") String token);

    @POST("/subscriptions")
    Call<Void> configureEventerSubscriptionCall(@Header("Authorization") String token, @Body RequestBody object);
}