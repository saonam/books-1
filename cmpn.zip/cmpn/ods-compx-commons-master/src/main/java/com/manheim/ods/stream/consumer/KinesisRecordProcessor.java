package com.manheim.ods.stream.consumer;

import java.util.List;

import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.amazonaws.services.kinesis.clientlibrary.exceptions.InvalidStateException;
import com.amazonaws.services.kinesis.clientlibrary.exceptions.ShutdownException;
import com.amazonaws.services.kinesis.clientlibrary.exceptions.ThrottlingException;
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessor;
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessorCheckpointer;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.ShutdownReason;
import com.amazonaws.services.kinesis.model.Record;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.helper.DateUtils;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MetricReporter;

public class KinesisRecordProcessor implements IRecordProcessor {
  private static final Logger LOG = LoggerFactory.getLogger(KinesisRecordProcessor.class);
  private static final String AUCTION_CODE_LABEL = "auctionCode:";
  private static final String EVENT_TYPE_LABEL = "eventType:";
  private static final String VIN_LABEL = "vin:";
  private static final String KINESIS_SHARDID_LABEL = "shardId:";
  private String kinesisShardId;

  private long nextCheckpointTimeInMillis;

  private long backoffTime;
  private int numRetries;
  private long checkPointInterval;
  private MetricReporter metricReporter;
  private ProducerTemplate producerTemplate;
  @SuppressWarnings("unused")
  private String[] allowedAuctions;
  @SuppressWarnings("unused")
  private String[] ignoreAuctions;

  public KinesisRecordProcessor(ProducerTemplate producerTemplate, MetricReporter metricReporter,
      long backOffTime, int numRetries, long checkPointInterval, String[] allowedAuctions,
      String[] ignoreAuctions) {
    this.metricReporter = metricReporter;
    this.backoffTime = backOffTime;
    this.numRetries = numRetries;
    this.checkPointInterval = checkPointInterval;
    this.producerTemplate = producerTemplate;
    this.allowedAuctions = allowedAuctions;
    this.ignoreAuctions = ignoreAuctions;
  }


  @Override
  public void initialize(String shardId) {
    LOG.info("Initializing record processor for shard: " + shardId);
    this.kinesisShardId = shardId;
  }

  @Override
  public void processRecords(List<Record> records, IRecordProcessorCheckpointer checkPointer) {
    LOG.info("Processing " + records.size() + " records from " + kinesisShardId);


    // Process records and perform all exception handling.
    processRecordsWithRetries(records);

    // Checkpoint once every checkpoint interval.
    if (System.currentTimeMillis() > nextCheckpointTimeInMillis) {
      checkpoint(checkPointer);

      nextCheckpointTimeInMillis = System.currentTimeMillis() + checkPointInterval;
    }
  }


  /**
   * Process records performing retries as needed. Skip "poison pill" records.
   * 
   * @param records Data records to be processed.
   */
  private void processRecordsWithRetries(List<Record> records) {
    for (Record record : records) {
      boolean processedSuccessfully = false;
      for (int i = 0; i < numRetries; i++) {
        try {
          processSingleRecord(record);

          processedSuccessfully = true;
          break;
        } catch (Exception ex) {
          LOG.warn("Caught exception while processing record " + record, ex);
        }

        // backoff if we encounter an exception.
        try {
          Thread.sleep(backoffTime);
        } catch (InterruptedException e) {
          LOG.error("Interrupted sleep", e);
          Thread.currentThread().interrupt();
        }
      }

      if (!processedSuccessfully) {
        metricReporter.incrementEventFailed();
        LOG.error("Couldn't process record " + record + ". Skipping the record.");
      }
    }
  }

  /**
   * Process a single record.
   * 
   * @param record The record to be processed.
   * @throws StageException
   */
  private void processSingleRecord(Record record) throws StageException {

    try {
      // For this app, we interpret the payload as UTF-8 chars.
      JsonParser jsonParser = new JsonParser();
      JsonElement element = jsonParser.parse(new String(record.getData().array()));
      JsonObject jsonObject = element.getAsJsonObject();

      String auctionCode = getRequiredValueFromJsonObject(jsonObject, "auctionCode");
      String sblu = getValueFromJsonObject(jsonObject, "sblu");
      String workorder = getValueFromJsonObject(jsonObject, "workOrder");
      AuctionEvent auctionEvent = AuctionEvent.builder().auctionCode(auctionCode)
          .eventType(getRequiredValueFromJsonObject(jsonObject, "eventType")).sblu(sblu)
          .vin(getValueFromJsonObject(jsonObject, "vin"))
          .cdcjournaltimestamp(getRequiredValueFromJsonObject(jsonObject, "cdcjournaltimestamp"))
          .cdcUserId(getValueFromJsonObject(jsonObject, "cdcUserId"))
          .tboxtimestamp(getValueFromJsonObject(jsonObject, "tboxtimestamp"))
          .sourceTableName(getValueFromJsonObject(jsonObject, "sourceTableName"))
          .changestatus(getValueFromJsonObject(jsonObject, "changestatus"))
          .prevSellerDealerId(getValueFromJsonObject(jsonObject, "prevSellerDealerId"))
          .prevBuyerDealerId(getValueFromJsonObject(jsonObject, "prevBuyerDealerId"))
          .workOrder(workorder).build();
      String saleYearString = getValueFromJsonObject(jsonObject, "saleYear");
      if (saleYearString != null) {
        auctionEvent.setSaleYear(Integer.valueOf(saleYearString));
        auctionEvent
            .setSaleNumber(Integer.valueOf(getValueFromJsonObject(jsonObject, "saleNumber")));
        auctionEvent
            .setLaneNumber(Integer.valueOf(getValueFromJsonObject(jsonObject, "laneNumber")));
        auctionEvent.setRunNumber(Integer.valueOf(getValueFromJsonObject(jsonObject, "runNumber")));
      }
      auctionEvent.setHeartbeat(Boolean.valueOf(getValueFromJsonObject(jsonObject, "heartbeat")));

      /*
       * Set seller id if available
       */
      String sellerId = getValueFromJsonObject(jsonObject, "sellerId");
      if (sellerId != null) {
        auctionEvent.setSellerId(sellerId);
      }
      if (auctionEvent.isHeartbeat()) {
        auctionEvent.setAuctionid(getValueFromJsonObject(jsonObject, "auctionid"));
        auctionEvent.setAuctioniduniqueid(getValueFromJsonObject(jsonObject, "auctioniduniqueid"));
        auctionEvent.setAuctionuniqueid(getValueFromJsonObject(jsonObject, "auctionuniqueid"));
        auctionEvent.setHeartbeatseqno(getValueFromJsonObject(jsonObject, "heartbeatseqno"));

        metricReporter.incrementHeartbeatReceived(EVENT_TYPE_LABEL + auctionEvent.getEventType(),
            VIN_LABEL + auctionEvent.getVin(), AUCTION_CODE_LABEL + auctionEvent.getAuctionCode());

      } else {
        metricReporter.incrementEventReceived(EVENT_TYPE_LABEL + auctionEvent.getEventType(),
            VIN_LABEL + auctionEvent.getVin(), AUCTION_CODE_LABEL + auctionEvent.getAuctionCode());
      }

      setMDCValuesForLogging(auctionEvent);


      metricReporter.recordLatency(
          DateUtils.timeDifferenceFromNow(record.getApproximateArrivalTimestamp()),
          AUCTION_CODE_LABEL + auctionEvent.getAuctionCode(),
          KINESIS_SHARDID_LABEL + kinesisShardId);

      postEvent(auctionEvent);
      LOG.info(
          "Received Event: ShardId - {},Seq# - {}, Partition Key - {}, Arrival Time - {}, Data - {}",
          this.kinesisShardId, record.getSequenceNumber(), record.getPartitionKey(),
          record.getApproximateArrivalTimestamp(), auctionEvent);

    } catch (NumberFormatException e) {
      LOG.error("Record does not match sample record format. Ignoring record with data; "
          + record.getData(), e);
      throw new StageException(String.format("Bad Input Data for AuctionEvent - %s !!",
          new String(record.getData().array())));
    }
  }

  private void postEvent(AuctionEvent auctionEvent) {
    this.producerTemplate.sendBody("direct:postevent", auctionEvent);
  }

  private String getValueFromJsonObject(JsonObject jsonObject, String key) {
    JsonElement jsonElement = jsonObject.get(key);
    if (jsonElement == null)
      return null;
    else if (jsonElement instanceof JsonNull)
      return null;
    else
      return getRequiredValueFromJsonObject(jsonObject, key);
  }

  private String getRequiredValueFromJsonObject(JsonObject jsonObject, String key) {
    return jsonObject.get(key).getAsString();
  }


  /**
   * {@inheritDoc}
   */
  @Override
  public void shutdown(IRecordProcessorCheckpointer checkpointer, ShutdownReason reason) {
    LOG.info("Shutting down record processor for shard: " + kinesisShardId);
    // Important to checkpoint after reaching end of shard, so we can start processing data from
    // child shards.
    if (reason == ShutdownReason.TERMINATE) {
      checkpoint(checkpointer);
    }
  }

  /**
   * Checkpoint with retries.
   * 
   * @param checkpointer
   */
  private void checkpoint(IRecordProcessorCheckpointer checkpointer) {
    LOG.info("Checkpointing shard " + kinesisShardId);
    try {
      retryCheckpointIfThrottled(checkpointer);
    } catch (ShutdownException se) {
      // Ignore checkpoint if the processor instance has been shutdown (fail over).
      LOG.info("Caught shutdown exception, skipping checkpoint.", se);
    } catch (InvalidStateException e) {
      // This indicates an issue with the DynamoDB table (check for table, provisioned IOPS).
      LOG.error(
          "Cannot save checkpoint to the DynamoDB table used by the Amazon Kinesis Client Library.",
          e);
    }

  }


  private void retryCheckpointIfThrottled(IRecordProcessorCheckpointer checkpointer)
      throws InvalidStateException, ShutdownException {
    for (int i = 0; i < numRetries; i++) {
      try {
        checkpointer.checkpoint();
        break;

      } catch (ThrottlingException e) {
        // Backoff and re-attempt checkpoint upon transient failures
        if (i >= (numRetries - 1)) {
          LOG.error("Checkpoint failed after " + (i + 1) + " attempts.", e);
          break;
        } else {
          LOG.info("Transient issue when checkpointing - attempt " + (i + 1) + " of " + numRetries,
              e);
        }
      }
      try {
        Thread.sleep(backoffTime);
      } catch (InterruptedException e) {
        LOG.error("Interrupted sleep", e);
        Thread.currentThread().interrupt();
      }
    }
  }


  private void setMDCValuesForLogging(AuctionEvent event) {
    MDC.put("eventType", event.getEventType());
    MDC.put("auctionCode", event.getAuctionCode());
    if (null != event.getWorkOrder()) {
      MDC.put("workOrder", event.getWorkOrder());
    }
    if (null != event.getSblu()) {
      MDC.put("sblu", event.getSblu());
    }
    if (null != event.getVin()) {
      MDC.put("vin", event.getVin());
    }
    if (null != event.getSaleYear()) {
      MDC.put("saleYear", String.valueOf(event.getSaleYear()));
      MDC.put("saleNumber", String.valueOf(event.getSaleNumber()));
      MDC.put("laneNumber", String.valueOf(event.getLaneNumber()));
      MDC.put("runNumber", String.valueOf(event.getRunNumber()));
    }
  }

}
