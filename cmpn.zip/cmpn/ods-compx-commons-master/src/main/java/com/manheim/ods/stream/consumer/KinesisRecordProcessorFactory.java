package com.manheim.ods.stream.consumer;

import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessor;
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessorFactory;
import com.manheim.ods.compx.util.MetricReporter;

@Component
@RefreshScope
public class KinesisRecordProcessorFactory implements IRecordProcessorFactory {


  @Autowired
  private ProducerTemplate producerTemplate;

  @Autowired
  private MetricReporter metricReporter;

  @Value("${recordprocessor.backoff.time}")
  private long backoffTime;
  @Value("${recordprocessor.num.retries}")
  private int numRetries;
  @Value("${recordprocessor.checkpoint.interval}")
  private long checkPointInterval;
  @Value("${auction.codes}")
  private String[] allowedAuctions;
  @Value("${ignore.auction.codes}")
  private String[] ignoreAuctions;


  public KinesisRecordProcessorFactory(ProducerTemplate producerTemplate,
      MetricReporter metricReporter, @Value("${recordprocessor.backoff.time}") long backoffTime,
      @Value("${recordprocessor.num.retries}") int numRetries,
      @Value("${recordprocessor.checkpoint.interval}") long checkPointInterval,
      @Value("${auction.codes}") String[] allowedAuctions,
      @Value("${ignore.auction.codes}") String[] ignoreAuctions) {
    this.producerTemplate = producerTemplate;
    this.metricReporter = metricReporter;
    this.backoffTime = backoffTime;
    this.numRetries = numRetries;
    this.checkPointInterval = checkPointInterval;
    this.allowedAuctions = allowedAuctions;
    this.ignoreAuctions = ignoreAuctions;
  }

  @Override
  public IRecordProcessor createProcessor() {
    return new KinesisRecordProcessor(producerTemplate, metricReporter, backoffTime, numRetries,
        checkPointInterval, allowedAuctions, ignoreAuctions);
  }

}