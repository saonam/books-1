package com.manheim.ods.compx.helper;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class DateUtils {

  static Logger log = LoggerFactory.getLogger(DateUtils.class);
  static final String TIMESTAMP_NANOSECONDS_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS";
  static final String TIMESTAMP_MILLISECONDS_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
  static final String TIMESTAMP_SECONDS_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";

  private DateUtils() {} // to prevent instantiation

  public static Date toDate(String dateString, String fieldName) throws ParseException {

    if (StringUtils.isEmpty(dateString)) {
      return null;
    }

    DateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    Date date;
    try {
      date = df.parse(dateString);
    } catch (Exception e) {
      log.error(String.format("Unable to parse date - %s", dateString), e);
      throw new ParseException(fieldName, 0);
    }
    return date;
  }

  public static Timestamp toTimestamp(String timestampString) {
    if (StringUtils.isEmpty(timestampString)) {
      return null;
    }
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern(TIMESTAMP_NANOSECONDS_FORMAT);
    LocalDateTime d = LocalDateTime.parse(timestampString, dtf);
    return Timestamp.valueOf(d);
  }


  public static Timestamp toTimestampWithSecondsPrecision(String timestampString) {
    if (StringUtils.isEmpty(timestampString)) {
      return null;
    }
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern(TIMESTAMP_SECONDS_FORMAT);
    LocalDateTime d = LocalDateTime.parse(timestampString, dtf);
    return Timestamp.valueOf(d);
  }

  public static Timestamp toTimestampWithMsPrecision(String timestampString) {
    if (StringUtils.isEmpty(timestampString)) {
      return null;
    }
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern(TIMESTAMP_MILLISECONDS_FORMAT);
    LocalDateTime d = LocalDateTime.parse(timestampString, dtf);
    return Timestamp.valueOf(d);
  }

  public static Timestamp getCurrentSystemTimestamp() {
    return new Timestamp(System.currentTimeMillis());
  }

  public static String getCurrentSystemTimestampInString() {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern(TIMESTAMP_MILLISECONDS_FORMAT);
    LocalDateTime now = LocalDateTime.now();
    return now.format(dtf);
  }

  public static String toNanosTimestampString(String timestampString) {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern(TIMESTAMP_MILLISECONDS_FORMAT);
    LocalDateTime ldt = LocalDateTime.parse(timestampString, dtf);
    DateTimeFormatter fmt = DateTimeFormatter.ofPattern(TIMESTAMP_NANOSECONDS_FORMAT);
    return ldt.format(fmt);

  }


  public static String fromSecondsToNanosTimestampString(String timestampString) {
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern(TIMESTAMP_SECONDS_FORMAT);
    LocalDateTime ldt = LocalDateTime.parse(timestampString, dtf);
    DateTimeFormatter fmt = DateTimeFormatter.ofPattern(TIMESTAMP_NANOSECONDS_FORMAT);
    return ldt.format(fmt);

  }


  public static long timeDifferenceFromNow(Date occurredWhen) {
    return Calendar.getInstance().getTimeInMillis() - occurredWhen.getTime();

  }

  public static long daysDifferenceFromNow(Date occurredWhen) {
    return TimeUnit.DAYS.convert(timeDifferenceFromNow(occurredWhen), TimeUnit.MILLISECONDS);
  }

  /**
   * @param strEventTimestamp - 2018-04-25T19:40:58
   * @param dateformat - yyyy-MM-dd'T'HH24:mm:ss
   * @param timezone - America/New_York
   * @return Time in EST
   * 
   *         Convert given time in local timezone to EST
   */
  public static String convertToTimezone(String strEventTimestamp, String dateformat,
      String from_timezone, String to_timezone) {

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(dateformat);
    LocalDateTime eventTimestampLocalTime = LocalDateTime.parse(strEventTimestamp, formatter);

    ZonedDateTime eventTimestampLocal = eventTimestampLocalTime.atZone(ZoneId.of(from_timezone));
    ZonedDateTime eventTimestampDestTimezone =
        eventTimestampLocal.withZoneSameInstant(ZoneId.of(to_timezone));


    String strEventTimestampInEst = eventTimestampDestTimezone.format(formatter);
    return strEventTimestampInEst;
  }
}
