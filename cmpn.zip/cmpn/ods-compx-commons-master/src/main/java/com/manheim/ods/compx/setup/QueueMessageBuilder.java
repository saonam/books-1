package com.manheim.ods.compx.setup;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.MessagePostProcessor;

import com.manheim.ods.compx.model.eventer.BaseEvent;
import com.manheim.ods.compx.util.LogWrapper;

public class QueueMessageBuilder {
  private static final String JMSX_GROUP_ID = "JMSXGroupID";
  private LogWrapper logWrapper;
  private JsonBuilder jsonBuilder;

  @Autowired
  public QueueMessageBuilder(JsonBuilder jsonBuilder, LogWrapper logWrapper) {
    this.jsonBuilder = jsonBuilder;
    this.logWrapper = logWrapper;
  }

  public String messageXML(String apiResponse, BaseEvent event) throws JSONException {
    return XML.toString(this.jsonBuilder.buildQueueJson(new JSONObject(apiResponse), event));
  }

  public String messageXML(String apiResponse, int responseCode, BaseEvent event)
      throws JSONException {
    JSONObject apiResponseJson = apiResponse == null ? null : new JSONObject(apiResponse);
    return XML.toString(jsonBuilder.buildQueueJson(apiResponseJson, responseCode, event));
  }

  public MessagePostProcessor messageProperties(String auctionCode, BaseEvent event,
      Map<String, String> eventHeaders, Timestamp apiRequestTimestamp,
      Timestamp apiResponseTimestamp) {
    DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");

    return message -> {
      if (eventHeaders != null) {
        String sourceKey = eventHeaders.get("source");
        message.setStringProperty("Source", determineSourceCode(event, sourceKey));
        String uniqueId = eventHeaders.get("uniqueid");
        String originTimestamp = eventHeaders.get("origintimestamp");
        message.setStringProperty("uniqueId", uniqueId);
        message.setStringProperty("originTimestamp", originTimestamp);
        String jmsxGroupID = eventHeaders.get(JMSX_GROUP_ID);
        if (jmsxGroupID != null) {
          message.setStringProperty(JMSX_GROUP_ID, jmsxGroupID);
        }
      }
      message.setStringProperty("EventType", event.getEventType());
      message.setStringProperty("Auction", auctionCode);
      message.setStringProperty("apiRequestTimestamp", df.format(apiRequestTimestamp));
      message.setStringProperty("apiResponseTimestamp", df.format(apiResponseTimestamp));
      logMessageProperties(message);
      return message;
    };
  }

  private void logMessageProperties(Message message) throws JMSException {
    logWrapper.info(QueueMessageBuilder.class, String.format(
        "JMS Properties: {Auction: %s, Source: %s, EventType: %s, uniqueId: %s, originTimestamp: %s, apiRequestTimestamp: %s, apiResponseTimestamp: %s, JMSXGroupID: %s}",
        message.getStringProperty("Auction"), message.getStringProperty("Source"),
        message.getStringProperty("EventType"), message.getStringProperty("uniqueId"),
        message.getStringProperty("originTimestamp"),
        message.getStringProperty("apiRequestTimestamp"),
        message.getStringProperty("apiResponseTimestamp"),
        message.getStringProperty(JMSX_GROUP_ID)));
  }

  public String determineSourceCode(BaseEvent event, String sourceKey) {
    // this method is not implemented and meant to be overridden by subclasses
    String source;
    if (sourceKey != null) {
      source = sourceKey;
    } else {
      source = event.getHref().isEmpty() ? "DQSWAT" : "N/A";
    }
    return source;
  }
}
