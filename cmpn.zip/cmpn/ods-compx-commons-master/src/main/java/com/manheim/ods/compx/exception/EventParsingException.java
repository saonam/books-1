package com.manheim.ods.compx.exception;

public class EventParsingException extends RuntimeException {

    private final String jsonKey;
    private final String applicationName;

    public EventParsingException(String jsonKey, String applicationName) {
        this.jsonKey = jsonKey;
        this.applicationName = applicationName;
    }

    @Override
    public String getMessage() {
        return String.format("[%s] No JSON attribute found for key %s when parsing event.", applicationName, jsonKey);
    }
}
