package com.manheim.ods.stream.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public class ReplayRequest {

  @Getter
  @NotNull
  public String startTimestamp;

  @Getter
  @NotNull
  @Min(1)
  public int durationInMinutes;

}
