package com.manheim.ods.compx.controller;

import org.apache.commons.io.IOUtils;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.io.InputStream;

@RequestMapping("/xsd")
@RestController
public class XSDController {

    @GetMapping(produces = MediaType.APPLICATION_ATOM_XML_VALUE)
    public String getSchema() throws IOException {
        return fetchFileAsString("xsd/schema1.xsd");
    }

    public String fetchFileAsString(String filename) throws IOException {
        InputStream inputStream = Thread.currentThread().getContextClassLoader().getResource(filename).openStream();
        String output = IOUtils.toString(inputStream);
        inputStream.close();
        return output;
    }
}
