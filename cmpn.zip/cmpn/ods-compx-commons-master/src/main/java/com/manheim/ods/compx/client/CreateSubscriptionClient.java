package com.manheim.ods.compx.client;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.api.EventerAPI;
import com.manheim.ods.compx.exception.EventerSubscriptionException;
import com.manheim.ods.compx.service.Retry;
import com.manheim.ods.compx.setup.JsonBuilder;
import com.manheim.ods.compx.util.LogWrapper;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Response;

@Component
public class CreateSubscriptionClient {

  private EventerAPI eventerAPI;
  private JsonBuilder jsonBuilder;
  private Retry retry;
  private LogWrapper logWrapper;

  public CreateSubscriptionClient(EventerAPI eventerAPI, JsonBuilder jsonBuilder, Retry retry,
      LogWrapper logWrapper) {
    this.eventerAPI = eventerAPI;
    this.jsonBuilder = jsonBuilder;
    this.retry = retry;
    this.logWrapper = logWrapper;
  }

  public void createSubscription(String accessToken, String subscriberHref, String messagePattern)
      throws EventerSubscriptionException {
    try {
      JSONObject subscriptionJson = jsonBuilder.buildSubscription(subscriberHref, messagePattern);
      Call<Void> subscriptionCall = eventerAPI.configureEventerSubscriptionCall(
          "Bearer " + accessToken, buildRequestBody(subscriptionJson));
      logExecutionOfCall();
      retry.execute(subscriptionCall, this::logUnsuccessfulCall, this);
      logSuccessfulCall();
    } catch (JSONException e) {
      logWrapper.error(CreateSubscriptionClient.class, e);
      throw new EventerSubscriptionException("Failed creating JSON request body!!");
    } catch (IOException e) {
      logWrapper.error(CreateSubscriptionClient.class, e);
      throw new EventerSubscriptionException("Failed subscribing to Eventer!!");
    }

  }

  private RequestBody buildRequestBody(JSONObject json) {
    return RequestBody.create(MediaType.parse("text/plain"), json.toString());
  }

  @SuppressWarnings("squid:UnusedPrivateMethod")
  private void logUnsuccessfulCall(Response<?> response) {
    logWrapper.debug(this.getClass(),
        String.format("Unsuccessful Eventer API call to create subscription with HTTP Error %s.",
            response.code()));
  }

  private void logExecutionOfCall() {
    logWrapper.info(CreateSubscriptionClient.class, "Creating Subscription");
  }

  private void logSuccessfulCall() {
    logWrapper.info(this.getClass(), "Successful response to create subscription.");
  }

}
