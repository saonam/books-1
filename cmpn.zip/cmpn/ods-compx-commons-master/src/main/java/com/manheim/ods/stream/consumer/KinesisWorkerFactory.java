package com.manheim.ods.stream.consumer;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.amazonaws.AmazonClientException;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;
import com.manheim.ods.compx.helper.DateUtils;

@Component
public class KinesisWorkerFactory {
  @Autowired
  KinesisRecordProcessorFactory recordProcessorFactory;

  @Autowired
  KinesisClientLibConfiguration kinesisClientLibConfiguration;

  @Value("${spring.profiles.active}")
  String springProfile;

  @Value("${spring.application.name}")
  private String appName;
  @Value("${stream.name.prefix}")
  private String streamNamePrefix;

  Logger logger = LoggerFactory.getLogger(KinesisWorkerFactory.class);

  public KinesisWorkerFactory(KinesisRecordProcessorFactory recordProcessorFactory,
      KinesisClientLibConfiguration kinesisClientLibConfiguration) {
    this.recordProcessorFactory = recordProcessorFactory;
    this.kinesisClientLibConfiguration = kinesisClientLibConfiguration;
  }


  public Worker newWorker() {
    return new Worker.Builder().recordProcessorFactory(recordProcessorFactory)
        .config(kinesisClientLibConfiguration).build();
  }

  public Worker newReplayWorker(String startAtTimestampString) throws UnknownHostException {
    return new Worker.Builder().recordProcessorFactory(recordProcessorFactory)
        .config(configureKinesisClientForReplay(startAtTimestampString)).build();
  }

  /**
   * 
   * @param timestampString in format yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS';
   * @return
   * @throws UnknownHostException
   */
  private KinesisClientLibConfiguration configureKinesisClientForReplay(String timestampString)
      throws UnknownHostException {
    String workerId ;
    workerId = InetAddress.getLocalHost().getCanonicalHostName() + ":" + UUID.randomUUID();
    String streamName = String.format("%s-%s", streamNamePrefix, springProfile);
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH");
    LocalDateTime now = LocalDateTime.now();
    String timestampToTheHour = now.format(dtf);

    String appEnvName =
        String.format("%s-%s-%s-%s", appName, springProfile, "replay", timestampToTheHour);
    KinesisClientLibConfiguration kinesisClientLibConfigurationReplay =
        new KinesisClientLibConfiguration(appEnvName, streamName, buildAWSCredentialsProvider(),
            workerId)
                .withTimestampAtInitialPositionInStream(
                    DateUtils.toTimestampWithSecondsPrecision(timestampString))
                .withMaxRecords(10);
    logger.info("Kinesis Client - appEnvName:{}, streamName:{}, workerId:{}", appEnvName,
        streamName, workerId);
    return kinesisClientLibConfigurationReplay;
  }

  private AWSCredentialsProvider buildAWSCredentialsProvider() {
    // Ensure the JVM will refresh the cached IP values of AWS resources (e.g. service endpoints).
    java.security.Security.setProperty("networkaddress.cache.ttl", "60");

    /*
     * The ProfileCredentialsProvider will return your [default] credential profile by reading from
     * the credentials file located at (~/.aws/credentials).
     */
    AWSCredentialsProvider credentialsProvider = new DefaultAWSCredentialsProviderChain();
    try {
      credentialsProvider.getCredentials();
    } catch (Exception e) {

      throw new AmazonClientException("Error connecting to Kinesis", e);
    }
    return credentialsProvider;
  }

}
