package com.manheim.ods.compx.api;

import com.manheim.ods.compx.model.mashery.MasheryMessage;
import retrofit2.Call;
import retrofit2.http.Header;
import retrofit2.http.POST;

@FunctionalInterface
public interface MasheryAPI {
    @POST("/oauth2/token")
    Call<MasheryMessage> configureMasheryCall(@Header("Authorization") String authorization);
}
