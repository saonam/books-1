package com.manheim.ods.compx.helper;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class CompXFileReader {
    public String fetchFileAsString(String filename) throws IOException, URISyntaxException {
        ClassLoader classloader = Thread.currentThread().getContextClassLoader();
        String path = Paths.get(classloader.getResource(filename).toURI()).toString();
        return new String(Files.readAllBytes(Paths.get(path)));
    }
}
