package com.manheim.ods.compx.util;

import java.util.ArrayList;
import java.util.List;

public class MessageGroupUtil {

  int numberOfGroups;
  static final String GROUP_PREFIX = "grp";

  public MessageGroupUtil(int numberOfGroups) {
    this.numberOfGroups = numberOfGroups;
  }

  public String group(String partitionKey) {
    if (numberOfGroups <= 1)
      return null;
    if (partitionKey == null)
      return String.format("%s%s", GROUP_PREFIX, "1");

    int hashCode = partitionKey.hashCode();
    return group(hashCode);
  }

  private String group(long partitionKey) {

    int groupSequence = (int) (Math.abs(partitionKey) % numberOfGroups);

    return buildMessageGroupId(++groupSequence);
  }

  private String buildMessageGroupId(int groupSequence) {
    return String.format("%s%s", GROUP_PREFIX, groupSequence);
  }

  public List<String> allMessageGroups() {
    List<String> messageGroups = new ArrayList<>();
    for (int i = 1; i <= numberOfGroups; i++) {
      messageGroups.add(buildMessageGroupId(i));
    }

    return messageGroups;
  }
}
