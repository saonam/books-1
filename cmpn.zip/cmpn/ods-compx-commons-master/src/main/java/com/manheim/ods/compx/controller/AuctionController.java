package com.manheim.ods.compx.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.manheim.ods.compx.model.AuctionInformation;

@RequestMapping("/auctions")
@RestController
@RefreshScope
public class AuctionController {


    private String[] auctions;

    @Autowired
    public AuctionController(@Value("${auction.codes}") String[] auctions) {

        this.auctions = auctions;
    }

    @RequestMapping(method = RequestMethod.GET)
    public AuctionInformation auctions() {
        return new AuctionInformation(auctions);
    }
}
