package com.manheim.ods.compx.client;

import java.io.IOException;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.manheim.ods.compx.api.EventerAPI;
import com.manheim.ods.compx.exception.EventerSubscriptionException;
import com.manheim.ods.compx.service.Retry;
import com.manheim.ods.compx.setup.JsonBuilder;
import com.manheim.ods.compx.util.LogWrapper;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Response;


@Component
public class CreateSubscriberClient {

  private EventerAPI eventerAPI;
  private LogWrapper logger;
  private JsonBuilder jsonBuilder;
  private Retry retry;

  @Autowired
  public CreateSubscriberClient(EventerAPI eventerAPI, LogWrapper logger, JsonBuilder jsonBuilder,
      Retry retry) {
    this.eventerAPI = eventerAPI;
    this.logger = logger;
    this.jsonBuilder = jsonBuilder;
    this.retry = retry;
  }

  public String createSubscriber(String accessToken) throws EventerSubscriptionException {
    JSONObject subscriberJson;
    try {
      subscriberJson = jsonBuilder.buildSubscriber();
      Call<Void> call = eventerAPI.configureEventerSubscriberCall("Bearer " + accessToken,
          buildRequestBody(subscriberJson));
      logExecutionOfCall();
      Response<?> response = retry.execute(call, this::logUnsuccessfulCall, this);
      logSuccessfulCall();
      return response.headers().get("Location");
    } catch (JSONException e) {
      logger.error(CreateSubscriberClient.class, e);
      throw new EventerSubscriptionException("Failed creating JSON request body!!");
    } catch (IOException e) {
      logger.error(CreateSubscriberClient.class, e);
      throw new EventerSubscriptionException("Failed subscribing to Eventer!!");
    }
  }

  private RequestBody buildRequestBody(JSONObject json) {
    return RequestBody.create(MediaType.parse("text/plain"), json.toString());
  }

  @SuppressWarnings("squid:UnusedPrivateMethod")
  private void logUnsuccessfulCall(Response<?> response) {
    logger.debug(this.getClass(), String.format(
        "Unsuccessful Eventer API call to create subscriber with HTTP Error %s.", response.code()));
  }

  private void logSuccessfulCall() {
    logger.info(this.getClass(), "Successfully created subscriber.");
  }

  private void logExecutionOfCall() {
    logger.info(this.getClass(), "Creating subscriber.");
  }
}
