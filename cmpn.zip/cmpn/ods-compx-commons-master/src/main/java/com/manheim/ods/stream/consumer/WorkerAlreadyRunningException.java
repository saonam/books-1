package com.manheim.ods.stream.consumer;

public class WorkerAlreadyRunningException extends Exception {
  public WorkerAlreadyRunningException(String exceptionMessage) {
    super(exceptionMessage);
  }
}
