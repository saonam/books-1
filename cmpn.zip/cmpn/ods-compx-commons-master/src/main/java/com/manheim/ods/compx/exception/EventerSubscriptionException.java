package com.manheim.ods.compx.exception;

public class EventerSubscriptionException extends Exception {
  /**
   * 
   */
  private static final long serialVersionUID = -5932344231083144723L;
  private final String message;

  public EventerSubscriptionException(String message) {
    this.message = message;
  }

  @Override
  public String getMessage() {
    return this.message;
  }


}
