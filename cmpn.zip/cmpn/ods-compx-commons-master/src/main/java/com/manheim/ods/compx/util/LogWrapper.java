package com.manheim.ods.compx.util;


import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class LogWrapper {

  private ObjectMapper objectMapper;

  @Autowired
  public LogWrapper(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper;
  }


  public void logResponse(String responseName, Class<?> originClass, Object object)
      throws JsonProcessingException {
    info(originClass,
        String.format("%s response: %s", responseName, objectMapper.writeValueAsString(object)));
  }

  public void info(Class<?> originClass, String message) {
    LoggerFactory.getLogger(originClass).info(message);
  }

  public void error(Class<?> originClass, String message) {
    LoggerFactory.getLogger(originClass).error(message);
  }

  public void debug(Class<?> originClass, String message) {
    LoggerFactory.getLogger(originClass).debug(message);
  }

  public void error(Class<?> originClass, Throwable thr) {
    LoggerFactory.getLogger(originClass).error(thr.getMessage(), thr);
  }

  public void error(Class<?> originClass, String message, Throwable thr) {
    LoggerFactory.getLogger(originClass).error(message, thr);
  }

}
