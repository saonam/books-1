package com.manheim.ods.compx.model.eventer;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
public class BaseEvent {

    @Getter @Setter
    private boolean isHeartbeat;
    @Getter @Setter
    private String href;
    @Getter @Setter
    private String eventType;

    @Override
    public String toString() {
        return String.format("heartbeat=%s, href=%s, eventType=%s", isHeartbeat, href, eventType);
    }
}
