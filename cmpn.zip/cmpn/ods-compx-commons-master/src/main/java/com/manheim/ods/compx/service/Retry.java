package com.manheim.ods.compx.service;

import com.manheim.ods.compx.client.Client;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.setup.EventerValues;
import com.manheim.ods.compx.util.Sleeper;
import org.springframework.stereotype.Component;
import retrofit2.Call;
import retrofit2.Response;

import java.io.IOException;
import java.util.function.Consumer;

@Component
public class Retry {

    private Client client;
    private EventerValues eventerValues;
    private Sleeper sleeper;

    public Retry(Client client, EventerValues eventerValues, Sleeper sleeper) {
        this.client = client;
        this.eventerValues = eventerValues;
        this.sleeper = sleeper;
    }

    public Response execute(Call call, Consumer<Response> logUnsuccessfulCall, Object parent) throws IOException {
        Response response = client.execute(call, parent.getClass());
        int currentRetries = 0;
        while(!response.isSuccessful()){
            logUnsuccessfulCall.accept(response);
            if(currentRetries < eventerValues.getMaxRetryCount()){
                sleeper.sleep();
                response = client.execute(call.clone(), parent.getClass());
                currentRetries++;
            }else{
                throw new UnsuccessfulClientExecutionException(parent.getClass().getCanonicalName(), response.code());
            }
        }
        return response;
    }

}
