package com.manheim.ods.compx.setup;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Base64;
import java.util.List;

@Component
@Profile("!test")
public class EventerValues {

    @Getter
    private final List<String> messagePatterns;
    private final Integer maxRetryCount;
    @Getter
    private final String supportEmail;
    @Getter
    private final String callback;
    private final String xFlowUsername;
    private final String xFlowPassword;

    public EventerValues(@Value("${eventer.message.patterns}") List<String> messagePatterns, @Value("${eventer.max.retry.count}") Integer maxRetryCount,
                         @Value("${email.smtp.to}") String supportEmail, @Value("${eventer.callback}") String callback,
                         @Value("${security.user.name}") String xFlowUsername, @Value("${security.user.password}") String xFlowPassword) {
        this.messagePatterns = messagePatterns;
        this.maxRetryCount = maxRetryCount;
        this.supportEmail = supportEmail;
        this.callback = callback;
        this.xFlowUsername = xFlowUsername;
        this.xFlowPassword = xFlowPassword;
    }

    public Integer getMaxRetryCount() {
        if(maxRetryCount >= 0) {
            return maxRetryCount;
        }
        return 0;
    }

    public String getBasicAuthentication() {
        String usernamePassword = String.format("%s:%s", xFlowUsername, xFlowPassword);
        String encoded = Base64.getEncoder().encodeToString(usernamePassword.getBytes());
        return String.format("Basic %s", encoded);
    }
}
