package com.manheim.ods.compx.helper;

import com.fasterxml.jackson.databind.JsonNode;
import com.manheim.ods.compx.exception.EventParsingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class CompXJsonParser {

	private String applicationName;

	@Autowired
	public CompXJsonParser(@Value("${spring.application.name}") String applicationName) {
		this.applicationName = applicationName;
	}

	public String getNonNullValueForKey(JsonNode node, String key) {
		JsonNode value = node.findValue(key);
		if (isNull(value)) {
			throw new EventParsingException(key, applicationName);
		}
		return value.asText();
	}

	public String getRequiredValueForKey(JsonNode node, String key) {
		JsonNode value = node.findValue(key);
		if (isNullOrEmpty(value)) {
			throw new EventParsingException(key, applicationName);
		}
		return value.asText();
	}

	public String getValueForKey(JsonNode node, String key) {
		JsonNode value = node.findValue(key);
		if (isNullOrEmpty(value)) {
			return null;
		}
		return value.asText();
	}

	private boolean isNullOrEmpty(JsonNode value) {
		return isNull(value) || value.asText().isEmpty();
	}

	private boolean isNull(JsonNode value) {
		return value == null || "null".equals(value.asText());
	}
}
