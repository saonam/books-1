package com.manheim.ods.compx.setup;

import com.manheim.ods.compx.model.eventer.BaseEvent;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class JsonBuilder {

    private EventerValues eventerValues;

    @Autowired
    public JsonBuilder(EventerValues eventerValues) {
        this.eventerValues = eventerValues;
    }

    public JSONObject buildSubscription(String subscriberLocation, String messagePattern) throws JSONException {
        return new JSONObject()
                .put("subscriber", new JSONObject()
                        .put("href", subscriberLocation))
                .put("criteria", new JSONArray()
                        .put(new JSONObject()
                                .put("type", new JSONObject()
                                        .put("pattern", messagePattern))));
    }

    public JSONObject buildSubscriber() throws JSONException {
        return new JSONObject()
                .put("callback", eventerValues.getCallback())
                .put("headers", new JSONObject()
                        .put("Authorization", eventerValues.getBasicAuthentication()))
                .put("emails", new JSONArray().put(eventerValues.getSupportEmail()));
    }

    public JSONObject buildQueueJson(JSONObject apiResponse, BaseEvent event) throws JSONException {
        return this.buildQueueJson(apiResponse, 200, event);
    }

    public JSONObject buildQueueJson(JSONObject apiResponse, int responseCode, BaseEvent event) throws JSONException {
        JSONObject queueMessage = new JSONObject();

        if (apiResponse != null) {
            queueMessage.put("apiResponse", apiResponse);
        }
        if (responseCode >= 300) {
            queueMessage.put("error", new JSONObject().put("errorCode", responseCode));
        }
        queueMessage.put("eventType", event.getEventType())
                .put("eventHref", event.getHref())
                .put("event", new JSONObject(event));

        return new JSONObject().put("queueMessage", queueMessage);
    }

}
