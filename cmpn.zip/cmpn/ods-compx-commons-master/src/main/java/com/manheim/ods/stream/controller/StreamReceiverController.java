package com.manheim.ods.stream.controller;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.manheim.ods.stream.consumer.KinesisReceiver;
import com.manheim.ods.stream.consumer.WorkerAlreadyRunningException;

@RequestMapping("/stream/receiver")
@RestController
public class StreamReceiverController {

  private KinesisReceiver kinesisReceiver;

  Logger logger = LoggerFactory.getLogger(StreamReceiverController.class);

  @Autowired
  public StreamReceiverController(KinesisReceiver kinesisReceiver) {
    this.kinesisReceiver = kinesisReceiver;
  }

  @RequestMapping(method = RequestMethod.GET, value = "/stop")
  public ResponseEntity<String> stop() {

    this.kinesisReceiver.shutdown();

    return new ResponseEntity<>("Kinesis worker shutdown", HttpStatus.OK);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/start")
  public ResponseEntity<String> start() {

    try {
      this.kinesisReceiver.start();
    } catch (WorkerAlreadyRunningException e) {
      logger.error("Worker already running!! Execute stop first if you want to restart the worker.",
          e);
      return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
    }

    return new ResponseEntity<>("Kinesis worker started", HttpStatus.OK);
  }

  @RequestMapping(method = RequestMethod.GET, value = "/restart")
  public ResponseEntity<String> restart() {

    try {
      this.kinesisReceiver.restart();
    } catch (WorkerAlreadyRunningException e) {
      logger.error("Worker already running!! Execute stop first if you want to restart the worker.",
          e);
      return new ResponseEntity<>(e.getMessage(), HttpStatus.OK);
    }

    return new ResponseEntity<>("Kinesis worker restarted", HttpStatus.OK);
  }
}
