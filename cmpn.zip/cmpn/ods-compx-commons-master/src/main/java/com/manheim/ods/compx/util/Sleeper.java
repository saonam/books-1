package com.manheim.ods.compx.util;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.stereotype.Component;

@Component
@RefreshScope
public class Sleeper {
    private Integer retryWait;
    private LogWrapper logger;

    public Sleeper(@Value("${millisecond.retry.wait}") Integer retryWait, LogWrapper logger) {
        this.retryWait = retryWait;
        this.logger = logger;
    }

    public void sleep() {
        try {
            Thread.sleep(retryWait);
        } catch (InterruptedException e) {
            logger.info(Sleeper.class, e.getMessage());
        }
    }
}


