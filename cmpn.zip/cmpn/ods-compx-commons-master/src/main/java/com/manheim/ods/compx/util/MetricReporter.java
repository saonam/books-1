package com.manheim.ods.compx.util;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.timgroup.statsd.NonBlockingStatsDClient;
import com.timgroup.statsd.StatsDClient;

@Component
public class MetricReporter {

  @Autowired
  private LogWrapper logWrapper;

  private StatsDClient statsDClient;

  @Autowired
  public MetricReporter(@Value("${metric.reporter.host}") String metricHost,
      @Autowired LogWrapper logWrapper) {
    statsDClient = new NonBlockingStatsDClient("ODS.compX", metricHost, 8125);
    this.logWrapper = logWrapper;
  }

  public void recordExternalCallTime(double time, String... tags) {
    logWrapper.info(MetricReporter.class,
        String.format("Recording timing metric %s with time %f with tags %s",
            "external-call.latency", time, Arrays.toString(tags)));
    statsDClient.recordGaugeValue("external-call.latency", time, tags);
    statsDClient.recordHistogramValue("external-call.histogram", time, tags);
    statsDClient.recordExecutionTime("external-call.executiontime", Math.round(time), tags);
  }

  public void recordExternalCallTime(long time, String... tags) {
    logWrapper.info(MetricReporter.class,
        String.format("Recording timing metric %s with time %d with tags %s",
            "external-call.latency", time, Arrays.toString(tags)));
    statsDClient.recordGaugeValue("external-call.latency", time, tags);
    statsDClient.recordHistogramValue("external-call.histogram", time, tags);
    statsDClient.recordExecutionTime("external-call.executiontime", time, tags);
  }

  public void incrementHeartbeatReceived(String... tags) {
    incrementCounter("inbound-heartbeat-received.count", tags);
  }

  public void incrementHeartbeatProcessed(String... tags) {
    incrementCounter("inbound-heartbeat-processed.count", tags);
  }

  public void incrementEventReceived(String... tags) {
    incrementCounter("inbound-event-received.count", tags);
  }

  public void incrementEventProcessed(String... tags) {
    incrementCounter("inbound-event-processed.count", tags);
  }

  public void incrementEventFailed(String... tags) {
    incrementCounter("inbound-event-failed.count", tags);
  }

  public void incrementEventResourceNotFound(String... tags) {
    incrementCounter("inbound-event-resource-not-found.count", tags);
  }

  public void incrementEventError(String... tags) {
    incrementCounter("inbound-event-error.count", tags);
  }

  private void incrementCounter(String metricName, String... tags) {
    logWrapper.debug(MetricReporter.class, String
        .format("Incrementing counter metric %s with tags %s", metricName, Arrays.toString(tags)));
    statsDClient.incrementCounter(metricName, tags);
  }


  public void recordLatency(long age, String... tags) {
    logWrapper.info(MetricReporter.class,
        String.format("Recording timing metric %s with age %d with tags %s",
            "external-read.latency", age, Arrays.toString(tags)));
    statsDClient.recordGaugeValue("consumer-read.latency", age, tags);
    statsDClient.recordHistogramValue("consumer-read.histogram", age, tags);
  }

  public StatsDClient getStatsDClient() {
    return this.statsDClient;
  }

}
