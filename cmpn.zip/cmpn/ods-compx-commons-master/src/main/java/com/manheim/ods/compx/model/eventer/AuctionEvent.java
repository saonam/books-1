package com.manheim.ods.compx.model.eventer;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.manheim.ods.compx.serialize.EventDeserializer;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@JsonDeserialize(using = EventDeserializer.class)
public class AuctionEvent extends BaseEvent {

  private String auctionCode;
  private String vin;
  private String workOrder;
  private String sblu;
  private String heartbeatseqno;
  private String auctionid;
  private String eventType;
  private String auctionuniqueid;
  private String auctioniduniqueid;
  private String cdcjournaltimestamp;
  private String tboxtimestamp;
  private String changestatus;
  private String jsonMessage;
  private Integer saleYear;
  private Integer saleNumber;
  private Integer laneNumber;
  private Integer runNumber;
  private String cdcUserId;
  private String messageGroupId;
  private String sourceTableName;
  private String sourceEventCreatedTimestamp;

  private String prevBuyerDealerId;
  private String prevSellerDealerId;

  private String sellerId;
  private String redeemedDate;

  private String sourceEventName;
  private int retryCount;
}
