package com.manheim.ods.compx.exception;

public class UnsuccessfulClientExecutionException extends RuntimeException {
  private final String clientName;
  private final Integer errorCode;

  public UnsuccessfulClientExecutionException(String clientName, Integer errorCode) {
    this.clientName = clientName;
    this.errorCode = errorCode;
  }

  @Override
  public String getMessage() {
    return String.format("HTTP Error %s while executing %s.", errorCode, clientName);
  }

  public Integer getErrorCode() {
    return this.errorCode;
  }
}
