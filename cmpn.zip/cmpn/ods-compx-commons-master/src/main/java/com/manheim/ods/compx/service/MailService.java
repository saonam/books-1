package com.manheim.ods.compx.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class MailService {

	private JavaMailSender javaMailSender;
	private boolean mailEnabled;
	private String recipient;
	private String from;

	@Autowired
	public MailService(JavaMailSender javaMailSender, @Value("${email.enabled}") boolean mailEnabled, @Value("${email.smtp.to}") String recipient, @Value("${email.smtp.from}") String from) {
		this.javaMailSender = javaMailSender;
		this.mailEnabled = mailEnabled;
		this.recipient = recipient;
		this.from = from;
	}

	public void sendMessage(String subject, String mailBody) {
		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setFrom(from);
		mailMessage.setTo(recipient);
		mailMessage.setSubject(subject);
		mailMessage.setText(mailBody);
		if(mailEnabled) {
			javaMailSender.send(mailMessage);
		}
	}
}
