package com.manheim.ods.compx.model.eventer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.List;
import java.util.stream.Collectors;

@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class MySubscriberMessage {

    @Getter
    @JsonProperty("items")
    private List<EventerSubscriber> subscribers;

    @Override
    public String toString() {
        return subscribers.stream().map(subscriber -> subscriber.getHref()).collect(Collectors.joining(","));
    }

}
