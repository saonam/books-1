package com.manheim.ods.compx.exception;

public class RecordNotFoundException extends UnsuccessfulClientExecutionException {

  public RecordNotFoundException(String clientName, Integer errorCode) {
    super(clientName, errorCode);
  }
}
