package com.manheim.ods.compx.exception;

import com.manheim.ods.compx.service.MailService;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.MetricReporter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.jms.JMSException;
import java.net.SocketException;

@ControllerAdvice
public class EventExceptionHandler {

    private LogWrapper logger;
    private MailService mailService;
    private MetricReporter metricReporter;

    @Autowired
    public EventExceptionHandler(LogWrapper logger, MailService mailService, MetricReporter metricReporter) {
        this.logger = logger;
        this.mailService = mailService;
        this.metricReporter = metricReporter;
    }

    @ResponseStatus(HttpStatus.ACCEPTED)
    @ExceptionHandler(value = EventParsingException.class)
    public void handleParsingException(EventParsingException exception) {
        logger.error(exception.getClass(), exception.getMessage());
        metricReporter.incrementEventFailed();
        mailService.sendMessage("Unable to parse event", exception.getMessage());
    }

    @ResponseStatus(HttpStatus.NO_CONTENT)
    @ExceptionHandler(value = ResourceNotFoundException.class)
    public void handleNotFoundException(ResourceNotFoundException exception) {
        logger.error(exception.getClass(), exception.getMessage());
        metricReporter.incrementEventResourceNotFound();
    }

    @ExceptionHandler(value = {JMSException.class, UnsuccessfulClientExecutionException.class, SocketException.class})
    public void handleExecutionException(Exception exception) throws Exception {
        logger.error(exception.getClass(), exception.getMessage());
        metricReporter.incrementEventError();
        mailService.sendMessage("Unable to process event", exception.getMessage());
        throw exception;
    }
}
