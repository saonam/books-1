package com.manheim.ods.compx.client;

import java.io.IOException;

import org.springframework.stereotype.Component;

import com.manheim.ods.compx.api.EventerAPI;
import com.manheim.ods.compx.exception.EventerSubscriptionException;
import com.manheim.ods.compx.model.eventer.MySubscriberMessage;
import com.manheim.ods.compx.service.Retry;
import com.manheim.ods.compx.util.LogWrapper;

import retrofit2.Call;
import retrofit2.Response;

@Component
public class GetSubscriberClient {

  private EventerAPI eventerAPI;
  private Retry retry;
  private LogWrapper logger;

  public GetSubscriberClient(EventerAPI eventerAPI, Retry retry, LogWrapper logger) {
    this.eventerAPI = eventerAPI;
    this.retry = retry;
    this.logger = logger;
  }

  public MySubscriberMessage getEventerSubscribers(String accessToken)
      throws EventerSubscriptionException {
    try {
      Call<?> call = eventerAPI.configureEventerMySubscribersCall("Bearer " + accessToken);
      logExecutionOfCall();
      Response<MySubscriberMessage> response = retry.execute(call, this::logUnsuccessfulCall, this);
      logSuccessfulCall(response);
      return response.body();
    } catch (IOException e) {
      logger.error(GetSubscriberClient.class, e);
      throw new EventerSubscriptionException("Failed subscribing to Eventer!!");
    }

  }

  private void logExecutionOfCall() {
    logger.info(this.getClass(), "Retrieving Current Subscribers");
  }

  @SuppressWarnings("squid:UnusedPrivateMethod")
  private void logUnsuccessfulCall(Response<?> response) {
    logger.debug(this.getClass(),
        String.format("Unsuccessful Eventer API to get current subscribers with HTTP Error %s.",
            response.code()));
  }

  private void logSuccessfulCall(Response<MySubscriberMessage> response) {
    logger.info(this.getClass(),
        String.format("Successful response to get current subscribers. Response: %s",
            response.body().toString()));
  }
}

