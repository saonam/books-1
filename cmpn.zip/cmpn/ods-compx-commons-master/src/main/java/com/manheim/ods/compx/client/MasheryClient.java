package com.manheim.ods.compx.client;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.manheim.ods.compx.api.MasheryAPI;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.model.mashery.MasheryMessage;
import com.manheim.ods.compx.service.MailService;
import com.manheim.ods.compx.util.LogWrapper;

import retrofit2.Call;
import retrofit2.Response;

@Service
public class MasheryClient {

  public static final String CLIENT_NAME = "Mashery API";
  private static final String SUBJECT = "Mashery call failed";
  private static final String BODY =
      "Mashery call failed while retrieving the mashery token.  Application is not registered with Eventer.";

  private String authorization;
  private MasheryAPI masheryAPI;
  private Client client;
  private LogWrapper logger;
  private MailService mailService;

  @Autowired
  public MasheryClient(MasheryAPI masheryAPI, Client client,
      @Value("${mashery.authorization}") String authorization, MailService mailService,
      LogWrapper logger) {
    this.masheryAPI = masheryAPI;
    this.client = client;
    this.authorization = authorization;
    this.logger = logger;
    this.mailService = mailService;
  }

  public String fetchAccessToken() throws IOException {
    Call<MasheryMessage> call = masheryAPI.configureMasheryCall(authorization);
    logger.info(this.getClass(), "Executing mashery request.");
    Response<MasheryMessage> response = client.execute(call, this.getClass());
    if (!response.isSuccessful()) {
      mailService.sendMessage(SUBJECT, BODY);
      logger.error(this.getClass(),
          String.format("Unsuccessful Mashery API call with HTTP Error %s.", response.code()));
      throw new UnsuccessfulClientExecutionException(CLIENT_NAME, response.code());
    }
    logger.info(this.getClass(), "Obtained access token!");
    return response.body().getMasheryAccessToken();

  }
}
