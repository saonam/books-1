package com.manheim.ods.compx.helper;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import javax.jms.Message;


@Component
public class ActiveMQHelper {

    private JmsTemplate jmsTemplate;
    private String destinationQueue;

    @Autowired
    public ActiveMQHelper(JmsTemplate jmsTemplate, @Value("${activemq.queue.name}") String destinationQueue) {
        this.jmsTemplate = jmsTemplate;
        this.destinationQueue = destinationQueue;
        jmsTemplate.setReceiveTimeout(3000);
    }

    public ActiveMQTextMessage popQueueMessage(){
        return (ActiveMQTextMessage) jmsTemplate.receive(destinationQueue);
    }

    public void clearQueue(){
        Message messageReceive = jmsTemplate.receive(destinationQueue);
        while(messageReceive != null){
            messageReceive = jmsTemplate.receive(destinationQueue);
        }
    }
}
