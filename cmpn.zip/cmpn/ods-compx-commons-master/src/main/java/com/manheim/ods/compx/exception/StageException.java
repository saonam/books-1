package com.manheim.ods.compx.exception;

public class StageException extends Exception {
	private static final long serialVersionUID = -8367436996093327774L;

	public StageException(String message) {
		super(message);
	}
}
