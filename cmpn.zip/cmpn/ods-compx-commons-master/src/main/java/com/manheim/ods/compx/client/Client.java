package com.manheim.ods.compx.client;

import com.manheim.ods.compx.util.MetricReporter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import retrofit2.Call;
import retrofit2.Response;

import java.io.IOException;

@Service
public class Client {

    private MetricReporter metricReporter;

    @Autowired
    public Client(MetricReporter metricReporter) {
        this.metricReporter = metricReporter;
    }

    public Response execute(Call call, Class originClass) throws IOException {
        long startApiCall = System.currentTimeMillis();
        Response response = call.execute();
        metricReporter.recordExternalCallTime(System.currentTimeMillis() - startApiCall,
                "service-name:" + originClass.getSimpleName(),
                "service-host:" + call.request().url().host(),
                "service-uri:" + call.request().url().uri().getPath(),
                "http-method:" + call.request().method(),
                "http-status:" + response.code());
        return response;
    }
}
