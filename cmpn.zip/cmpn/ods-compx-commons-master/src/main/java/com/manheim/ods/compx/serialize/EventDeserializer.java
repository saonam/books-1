package com.manheim.ods.compx.serialize;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;
import com.manheim.ods.compx.helper.CompXJsonParser;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;

public class EventDeserializer extends JsonDeserializer<AuctionEvent> {

  private LogWrapper logger;
  private CompXJsonParser parser;

  @Autowired
  public EventDeserializer(LogWrapper logger, CompXJsonParser parser) {
    this.logger = logger;
    this.parser = parser;
  }

  @Override
  public AuctionEvent deserialize(JsonParser jsonParser,
      DeserializationContext deserializationContext) throws IOException {
    JsonNode node = jsonParser.readValueAsTree();
    logger.info(EventDeserializer.class, String.format("Event Received: %s", node.toString()));

    String vin = parser.getRequiredValueForKey(node, "vin");
    String sblu = parser.getRequiredValueForKey(node, "sblu");
    String workOrder = parser.getRequiredValueForKey(node, "workOrder");
    String auctionCode = parser.getRequiredValueForKey(node, "auctionCode");
    String auctionid = parser.getValueForKey(node, "auctionid");
    String cdcjournaltimestamp = parser.getValueForKey(node, "cdcjournaltimestamp");
    String cdcUserId = parser.getValueForKey(node, "cdcUserId");
    String tboxtimestamp = parser.getValueForKey(node, "tboxtimestamp");
    String heartbeatseqno = parser.getValueForKey(node, "heartbeatseqno");
    String auctionuniqueid = parser.getValueForKey(node, "auctionuniqueid");
    String auctioniduniqueid = parser.getValueForKey(node, "auctioniduniqueid");
    String eventType = parser.getRequiredValueForKey(node, "eventType");
    String sourceTableName = parser.getValueForKey(node, "sourceTableName");
    String changeStatus = parser.getValueForKey(node, "changestatus");
    String sourceEventName = parser.getValueForKey(node, "sourceEventName");

    AuctionEvent event = AuctionEvent.builder().auctionCode(auctionCode).auctionid(auctionid)
        .vin(vin).workOrder(workOrder).sblu(sblu).cdcjournaltimestamp(cdcjournaltimestamp)
        .tboxtimestamp(tboxtimestamp).heartbeatseqno(heartbeatseqno)
        .auctionuniqueid(auctionuniqueid).auctioniduniqueid(auctioniduniqueid).eventType(eventType)
        .cdcUserId(cdcUserId).jsonMessage(node.toString()).sourceTableName(sourceTableName)
        .sourceEventName(sourceEventName).changestatus(changeStatus).build();

    event.setHref(parser.getValueForKey(node, "href"));

    return event;
  }
}
