package com.manheim.ods.compx.helper;

import org.apache.activemq.command.ActiveMQTextMessage;
import org.junit.Test;
import org.springframework.jms.core.JmsTemplate;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

public class ActiveMQHelperTest {
	@Test
	public void shouldPopMessageFromActiveMQ() throws Exception {
		JmsTemplate jmsTemplate = mock(JmsTemplate.class);
		String queueName = "destination.queue";
		ActiveMQTextMessage expectedQueueMessage = new ActiveMQTextMessage();
		when(jmsTemplate.receive(queueName)).thenReturn(expectedQueueMessage);
		ActiveMQHelper activeMQHelper = new ActiveMQHelper(jmsTemplate, queueName);

		ActiveMQTextMessage message = activeMQHelper.popQueueMessage();

		assertThat(message, is(expectedQueueMessage));
	}

	@Test
	public void shouldClearQueue() throws Exception{
		JmsTemplate jmsTemplate = mock(JmsTemplate.class);
		String queueName = "destination.queue";
		ActiveMQTextMessage firstQueueMessage = new ActiveMQTextMessage();
		ActiveMQTextMessage secondQueueMessage = new ActiveMQTextMessage();
		when(jmsTemplate.receive(queueName)).thenReturn(firstQueueMessage).thenReturn(secondQueueMessage).thenReturn(null);
		ActiveMQHelper activeMQHelper = new ActiveMQHelper(jmsTemplate, queueName);

		activeMQHelper.clearQueue();

		verify(jmsTemplate, times(3)).receive(queueName);
	}


}