package com.manheim.ods.compx.client;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.function.Consumer;

import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.api.EventerAPI;
import com.manheim.ods.compx.exception.EventerSubscriptionException;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.model.eventer.MySubscriberMessage;
import com.manheim.ods.compx.service.Retry;
import com.manheim.ods.compx.setup.EventerValues;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.Sleeper;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class GetSubscriberClientTest {

  private EventerAPI eventerAPI;
  private GetSubscriberClient getSubscriberClient;
  private String accessToken;
  private Client client;
  private Call<?> call;
  private MySubscriberMessage mySubscriberMessage;
  private Response<MySubscriberMessage> successfulResponse;
  private Response<Object> errorResponse;
  private LogWrapper logWrapper;
  private Retry retry;

  @Before
  public void setUp() throws Exception {
    accessToken = "AccessToken";
    eventerAPI = mock(EventerAPI.class);
    mock(EventerValues.class);
    client = mock(Client.class);
    call = mock(Call.class);
    retry = mock(Retry.class);
    mySubscriberMessage = mock(MySubscriberMessage.class);
    successfulResponse = Response.success(mySubscriberMessage);
    logWrapper = mock(LogWrapper.class);
    errorResponse = Response.error(403, mock(ResponseBody.class));

    getSubscriberClient = new GetSubscriberClient(eventerAPI, retry, logWrapper);

    when(mySubscriberMessage.toString()).thenReturn("my subscriber message");
    when(eventerAPI.configureEventerMySubscribersCall("Bearer AccessToken"))
        .thenReturn((Call<MySubscriberMessage>) call);
    when(client.execute(call, GetSubscriberClient.class)).thenReturn(successfulResponse);
    when(retry.execute(eq(call), any(Consumer.class), eq(getSubscriberClient)))
        .thenReturn(successfulResponse);
  }

  @Test
  public void shouldConfigureSubscribersCall() throws IOException, EventerSubscriptionException {
    getSubscriberClient.getEventerSubscribers(accessToken);

    verify(eventerAPI).configureEventerMySubscribersCall("Bearer AccessToken");
  }

  @Test
  public void shouldCallExecuteWhenGettingEventerSubscribers()
      throws IOException, EventerSubscriptionException {
    getSubscriberClient.getEventerSubscribers(accessToken);

    verify(retry).execute(eq(call), any(Consumer.class), any(GetSubscriberClient.class));
  }

  @Test
  public void shouldReturnMySubscriberMessageWhenExecutionIsSuccessful()
      throws IOException, EventerSubscriptionException {
    MySubscriberMessage mySubscriberMessage =
        getSubscriberClient.getEventerSubscribers(accessToken);

    assertThat(mySubscriberMessage, is(mySubscriberMessage));
  }

  @Test
  public void shouldRetryCallWhenExecuteFails() throws Exception {
    when(client.execute(call, GetSubscriberClient.class)).thenReturn(errorResponse);

    getSubscriberClient.getEventerSubscribers(accessToken);

    verify(retry).execute(eq(call), any(Consumer.class), eq(getSubscriberClient));
  }

  @Test
  public void shouldLogInfoWhenClientIsExecutingCall()
      throws IOException, EventerSubscriptionException {
    getSubscriberClient.getEventerSubscribers(accessToken);

    verify(logWrapper).info(GetSubscriberClient.class, "Retrieving Current Subscribers");
  }


  @Test
  public void shouldLogInfoWhenClientExecutionIsSuccessful()
      throws IOException, EventerSubscriptionException {
    getSubscriberClient.getEventerSubscribers(accessToken);

    verify(logWrapper).info(GetSubscriberClient.class,
        String.format("Successful response to get current subscribers. Response: %s",
            successfulResponse.body().toString()));
  }


  @Test
  public void shouldLogErrorWhenClientExecutionFails() {
    IOException ioException = mock(IOException.class);
    try {
      when(retry.execute(eq(call), any(Consumer.class), eq(getSubscriberClient)))
          .thenThrow(ioException);
      getSubscriberClient.getEventerSubscribers(accessToken);
    } catch (IOException e) {
    } catch (EventerSubscriptionException e) {
    }


    verify(logWrapper).error(GetSubscriberClient.class, ioException);
  }

  @Test
  public void shouldLogInfoWhenClientExecutionIsUnSuccessful() throws Exception {
    when(client.execute(call, GetSubscriberClient.class)).thenReturn(errorResponse);
    retry = new Retry(client, mock(EventerValues.class), mock(Sleeper.class));

    getSubscriberClient = new GetSubscriberClient(eventerAPI, retry, logWrapper);
    String accessToken = "AccessToken";
    try {
      when(eventerAPI.configureEventerMySubscribersCall(anyString()))
          .thenReturn((Call<MySubscriberMessage>) call);

      getSubscriberClient.getEventerSubscribers(accessToken);
    } catch (EventerSubscriptionException e) {
    } catch (UnsuccessfulClientExecutionException e) {
    }
    verify(logWrapper).debug(eq(GetSubscriberClient.class),
        eq("Unsuccessful Eventer API to get current subscribers with HTTP Error 403."));

  }

}
