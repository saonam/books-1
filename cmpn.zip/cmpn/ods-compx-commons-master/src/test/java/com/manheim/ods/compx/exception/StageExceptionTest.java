package com.manheim.ods.compx.exception;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

public class StageExceptionTest {

  @Test
  public void test() {
    StageException stageException = new StageException("Failed to update staging");

    assertThat(stageException.getMessage(), is("Failed to update staging"));
  }

}
