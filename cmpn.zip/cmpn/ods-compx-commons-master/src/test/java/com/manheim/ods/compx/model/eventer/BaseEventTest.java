package com.manheim.ods.compx.model.eventer;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

public class BaseEventTest {

	@Test
	public void shouldLogAnEvent() {
		BaseEvent event = new BaseEvent();
		assertThat(event.toString(), is("heartbeat=false, href=null, eventType=null"));

		event = new BaseEvent(true, "http://some.href", "eventType");
		assertThat(event.toString(), is("heartbeat=true, href=http://some.href, eventType=eventType"));
	}
}