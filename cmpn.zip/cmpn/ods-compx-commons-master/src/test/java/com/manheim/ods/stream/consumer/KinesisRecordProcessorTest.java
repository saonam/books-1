package com.manheim.ods.stream.consumer;



import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.argThat;
import static org.mockito.Matchers.contains;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentMatcher;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.amazonaws.services.kinesis.clientlibrary.exceptions.InvalidStateException;
import com.amazonaws.services.kinesis.clientlibrary.exceptions.KinesisClientLibDependencyException;
import com.amazonaws.services.kinesis.clientlibrary.exceptions.ShutdownException;
import com.amazonaws.services.kinesis.clientlibrary.exceptions.ThrottlingException;
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessor;
import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessorCheckpointer;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.ShutdownReason;
import com.amazonaws.services.kinesis.model.Record;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.exception.StageException;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.MessageGroupUtil;
import com.manheim.ods.compx.util.MetricReporter;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.Appender;


public class KinesisRecordProcessorTest {

  AuctionEvent auctionEvent;
  IRecordProcessor iRecordProcessor;
  IRecordProcessorCheckpointer checkPointer;

  ProducerTemplate producerTemplate;

  MetricReporter metricReporter;
  Appender<ILoggingEvent> mockAppender;
  MessageGroupUtil messageGroupUtil;

  @SuppressWarnings("unchecked")
  @Before
  public void setup() throws KinesisClientLibDependencyException, InvalidStateException,
      ThrottlingException, ShutdownException {
    metricReporter = mock(MetricReporter.class);
    producerTemplate = mock(ProducerTemplate.class);
    when(producerTemplate.send(any(Exchange.class))).thenReturn(mock(Exchange.class));
    when(producerTemplate.getCamelContext()).thenReturn(mock(CamelContext.class));

    auctionEvent = AuctionEvent.builder().auctionCode("TEST_AUCTION").eventType("EVENT_TYPE")
        .vin("VIN").sblu("SBLU").workOrder("WORK_ORDER")
        .cdcjournaltimestamp("2017-10-18T03:16:46.332560000").cdcUserId("USER").saleYear(2017)
        .saleNumber(10).laneNumber(10).runNumber(20).build();
    String[] allowedAuctions = {"TEST_AUCTION"};
    String[] ignoreAuctions = {"INVALID_AUCTION"};
    iRecordProcessor = (new KinesisRecordProcessorFactory(producerTemplate, metricReporter, 300L, 3,
        30000L, allowedAuctions, ignoreAuctions)).createProcessor();
    checkPointer = mock(IRecordProcessorCheckpointer.class);

    Mockito.doAnswer(new Answer<Object>() {
      public Object answer(InvocationOnMock invocation) {
        Object[] args = invocation.getArguments();
        return "called with arguments: " + args;
      }
    }).when(checkPointer).checkpoint();
    ch.qos.logback.classic.Logger root = (ch.qos.logback.classic.Logger) LoggerFactory
        .getLogger(ch.qos.logback.classic.Logger.ROOT_LOGGER_NAME);
    mockAppender = mock(Appender.class);
    when(mockAppender.getName()).thenReturn("MOCK");
    root.addAppender(mockAppender);
  }

  @Test
  public void testProcessRecords() throws JsonProcessingException {
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    ObjectMapper jsonMapper = new ObjectMapper();
    String auctionEventString = jsonMapper.writeValueAsString(auctionEvent);
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    iRecordProcessor.processRecords(recordsList, checkPointer);
    verify(producerTemplate).sendBody(contains("direct:postevent"), any(AuctionEvent.class));
  }

  @Test
  public void testProcessHeartbeatRecords() throws JsonProcessingException, InterruptedException {
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    ObjectMapper jsonMapper = new ObjectMapper();
    auctionEvent.setHeartbeat(true);
    String auctionEventString = jsonMapper.writeValueAsString(auctionEvent);
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    iRecordProcessor.processRecords(recordsList, checkPointer);

    verify(producerTemplate).sendBody(contains("direct:postevent"), any(AuctionEvent.class));
  }

  @Test
  public void tesRecordProcessorShutdown()
      throws JsonProcessingException, KinesisClientLibDependencyException, InvalidStateException,
      ThrottlingException, ShutdownException {
    iRecordProcessor.shutdown(checkPointer, ShutdownReason.TERMINATE);
    verify(checkPointer).checkpoint();
  }

  @Test
  public void tesRecordProcessorShutdownRequested()
      throws JsonProcessingException, KinesisClientLibDependencyException, InvalidStateException,
      ThrottlingException, ShutdownException {
    iRecordProcessor.shutdown(checkPointer, ShutdownReason.REQUESTED);
    verify(checkPointer, never()).checkpoint();
  }

  @Test
  public void testShutdownException() throws KinesisClientLibDependencyException,
      InvalidStateException, ThrottlingException, ShutdownException {

    Mockito.doThrow(ShutdownException.class).when(checkPointer).checkpoint();
    iRecordProcessor.shutdown(checkPointer, ShutdownReason.TERMINATE);
    verifyLog("Caught shutdown exception, skipping checkpoint.");

  }

  @Test
  public void testThrottlingException() throws KinesisClientLibDependencyException,
      InvalidStateException, ThrottlingException, ShutdownException {

    Mockito.doThrow(ThrottlingException.class).when(checkPointer).checkpoint();
    iRecordProcessor.shutdown(checkPointer, ShutdownReason.TERMINATE);
    verifyLog("Checkpoint failed after 3 attempts");
  }

  @Test
  public void testInvalidStateException() throws KinesisClientLibDependencyException,
      InvalidStateException, ThrottlingException, ShutdownException {

    Mockito.doThrow(InvalidStateException.class).when(checkPointer).checkpoint();
    iRecordProcessor.shutdown(checkPointer, ShutdownReason.TERMINATE);
    verifyLog(
        "Cannot save checkpoint to the DynamoDB table used by the Amazon Kinesis Client Library");
  }

  @Test
  public void testNumRetriesOnException() throws JsonProcessingException {

    Mockito.doThrow(Exception.class).when(producerTemplate).sendBody(contains("direct:postevent"),
        any(AuctionEvent.class));
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    ObjectMapper jsonMapper = new ObjectMapper();
    String auctionEventString = jsonMapper.writeValueAsString(auctionEvent);
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setApproximateArrivalTimestamp(new Date());
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    recordsList.add(record);
    iRecordProcessor.processRecords(recordsList, checkPointer);
    verifyLog("Skipping the record.");
  }

  @Test
  public void testRetriesOnOtherException() throws JsonProcessingException {

    Mockito.doThrow(StageException.class).when(producerTemplate)
        .sendBody(contains("direct:postevent"), any(AuctionEvent.class));
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    ObjectMapper jsonMapper = new ObjectMapper();
    String auctionEventString = jsonMapper.writeValueAsString(auctionEvent);
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);

    iRecordProcessor.processRecords(recordsList, checkPointer);
    verifyLog("Skipping the record.");
  }

  private void verifyLog(String logMessage) {
    verify(mockAppender).doAppend((ILoggingEvent) argThat(new ArgumentMatcher<Object>() {
      @Override
      public boolean matches(final Object argument) {
        return ((LoggingEvent) argument).getFormattedMessage().contains(logMessage);
      }
    }));
  }

  @Test
  public void shouldSetValuesInMDC() throws Exception {
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    ObjectMapper jsonMapper = new ObjectMapper();
    String auctionEventString = jsonMapper.writeValueAsString(auctionEvent);
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    iRecordProcessor.processRecords(recordsList, checkPointer);
    assertEquals("TEST_AUCTION", MDC.get("auctionCode"));
    assertEquals("EVENT_TYPE", MDC.get("eventType"));
    assertEquals("SBLU", MDC.get("sblu"));
    assertEquals("WORK_ORDER", MDC.get("workOrder"));
    assertEquals("2017", MDC.get("saleYear"));
    assertEquals("10", MDC.get("saleNumber"));
    assertEquals("10", MDC.get("laneNumber"));
    assertEquals("20", MDC.get("runNumber"));
  }

  @Test
  public void shouldProcessEventWithEmptySblu() throws Exception {
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    ObjectMapper jsonMapper = new ObjectMapper();
    String auctionEventString =
        "{\"auctionCode\":\"TEST_AUCTION\",\"workOrder\":\"WORK_ORDER\",\"eventType\":\"EVENT_TYPE\",\"cdcjournaltimestamp\":\"2017-10-18T03:16:46.332560000\",\"cdcUserId\":\"USER\",\"heartbeat\":false}";
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setApproximateArrivalTimestamp(new Date());
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    recordsList.add(record);
    iRecordProcessor.processRecords(recordsList, checkPointer);
    assert (true);

  }

  @Test
  public void shouldProcessEventWithEmptyWorkOrder() throws Exception {
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    String auctionEventString =
        "{\"auctionCode\":\"TEST_AUCTION\",\"sblu\":\"SBLU\",\"eventType\":\"EVENT_TYPE\",\"cdcjournaltimestamp\":\"2017-10-18T03:16:46.332560000\",\"cdcUserId\":\"USER\",\"heartbeat\":false}";
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setApproximateArrivalTimestamp(new Date());
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    recordsList.add(record);
    iRecordProcessor.processRecords(recordsList, checkPointer);
    assert (true);

  }

  @Test
  public void shouldProcessEventWithEmptySbluAndWorkOrder() throws Exception {
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    String auctionEventString =
        "{\"auctionCode\":\"TEST_AUCTION\",\"eventType\":\"EVENT_TYPE\",\"saleYear\":2017,\"saleNumber\":10,\"laneNumber\":10,\"runNumber\":20,\"cdcjournaltimestamp\":\"2017-10-18T03:16:46.332560000\",\"cdcUserId\":\"USER\",\"heartbeat\":false}";
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    recordsList.add(record);
    record.setApproximateArrivalTimestamp(new Date());
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    iRecordProcessor.processRecords(recordsList, checkPointer);
    assert (true);

  }

  @Test
  public void testSkipRecordWithInvalidAuction() throws JsonProcessingException {
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    ObjectMapper jsonMapper = new ObjectMapper();
    AuctionEvent auctionEvent = AuctionEvent.builder().auctionCode("INVALID_AUCTION")
        .eventType("EVENT_TYPE").vin("VIN").sblu("SBLU").workOrder("WORK_ORDER")
        .cdcjournaltimestamp("2017-10-18T03:16:46.332560000").cdcUserId("USER").saleYear(2017)
        .saleNumber(10).laneNumber(10).runNumber(20).build();

    String auctionEventString = jsonMapper.writeValueAsString(auctionEvent);
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);
    iRecordProcessor.processRecords(recordsList, checkPointer);
    verify(producerTemplate, never()).sendBody(contains("seda:postevent"), any(AuctionEvent.class));
  }

  @Test
  public void testRecordWithAllAuctions() throws JsonProcessingException {
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    ObjectMapper jsonMapper = new ObjectMapper();
    AuctionEvent auctionEvent = AuctionEvent.builder().auctionCode("ANY_AUCTION")
        .eventType("EVENT_TYPE").vin("VIN").sblu("SBLU").workOrder("WORK_ORDER")
        .cdcjournaltimestamp("2017-10-18T03:16:46.332560000").cdcUserId("USER").saleYear(2017)
        .saleNumber(10).laneNumber(10).runNumber(20).sellerId("5098861").build();

    String auctionEventString = jsonMapper.writeValueAsString(auctionEvent);
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);

    String[] allowedAuctions = {"*"};
    String[] ignoreAuctions = {"IGNORE_AUCTION"};
    iRecordProcessor = (new KinesisRecordProcessorFactory(producerTemplate, metricReporter, 300L, 3,
        30000L, allowedAuctions, ignoreAuctions)).createProcessor();

    iRecordProcessor.processRecords(recordsList, checkPointer);
    verify(producerTemplate, times(1)).sendBody(contains("direct:postevent"),
        any(AuctionEvent.class));
  }

  @Test
  public void testRecordWithIgnoreAuction() throws JsonProcessingException {
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();
    ObjectMapper jsonMapper = new ObjectMapper();
    AuctionEvent auctionEvent = AuctionEvent.builder().auctionCode("IGNORE_AUCTION")
        .eventType("EVENT_TYPE").vin("VIN").sblu("SBLU").workOrder("WORK_ORDER")
        .cdcjournaltimestamp("2017-10-18T03:16:46.332560000").cdcUserId("USER").saleYear(2017)
        .saleNumber(10).laneNumber(10).runNumber(20).build();

    String auctionEventString = jsonMapper.writeValueAsString(auctionEvent);
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);

    String[] allowedAuctions = {"*"};
    String[] ignoreAuctions = {"IGNORE_AUCTION"};
    iRecordProcessor = (new KinesisRecordProcessorFactory(producerTemplate, metricReporter, 300L, 3,
        30000L, allowedAuctions, ignoreAuctions)).createProcessor();

    iRecordProcessor.processRecords(recordsList, checkPointer);
    verify(producerTemplate, never()).sendBody(contains("seda:postevent"), any(AuctionEvent.class));
  }

  @Test
  public void testBadRecordWithIgnoreAuction() throws JsonProcessingException {
    List<Record> recordsList = new ArrayList<Record>();
    Record record = new Record();

    String auctionEventString =
        "{\"auctionCode\":\"IGNORE_AUCTION\",\"vin\":\"VIN\",\"workOrder\":\"WORK_ORDER\",\"sblu\":\"SBLU\",\"heartbeatseqno\":null,\"auctionid\":null,\"eventType\":\"EVENT_TYPE\",\"auctionuniqueid\":null,\"auctioniduniqueid\":null,\"cdcjournaltimestamp\":\"2017-10-18T03:16:46.332560000\",\"tboxtimestamp\":null,\"changestatus\":null,\"jsonMessage\":null,\"saleYear\":2017,\"saleNumber\":10,\"laneNumber\":\"ERROR_NUMBER\",\"runNumber\":20,\"cdcUserId\":\"USER\",\"messageGroupId\":null,\"sourceTableName\":null,\"sourceEventCreatedTimestamp\":null,\"prevBuyerDealerId\":null,\"prevSellerDealerId\":null,\"sellerId\":null,\"redeemedDate\":null,\"sourceEventName\":null,\"href\":null,\"heartbeat\":false}";
    record.setData(ByteBuffer.wrap(auctionEventString.getBytes()));
    record.setPartitionKey(
        String.format("%s:%s", auctionEvent.getAuctionCode(), auctionEvent.getWorkOrder()));
    record.setSequenceNumber("123762344s");
    record.setPartitionKey("TEST_AUCTION:WORK_ORDER");
    record.setApproximateArrivalTimestamp(new Date());
    recordsList.add(record);

    String[] allowedAuctions = {"*"};
    String[] ignoreAuctions = {"TEST_AUCTION"};
    iRecordProcessor = (new KinesisRecordProcessorFactory(producerTemplate, metricReporter, 300L, 3,
        30000L, allowedAuctions, ignoreAuctions)).createProcessor();

    iRecordProcessor.processRecords(recordsList, checkPointer);
    verifyLog("Couldn't process record");
    verify(producerTemplate, never()).sendBody(contains("seda:postevent"), any(AuctionEvent.class));
  }

}
