package com.manheim.ods.compx.controller;


import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItemInArray;

import org.junit.Test;

import com.manheim.ods.compx.controller.AuctionController;
import com.manheim.ods.compx.model.AuctionInformation;

public class AuctionControllerTest {

    @Test
    public void shouldReturnValidAuctionCodes() {
        AuctionController auctionController = new AuctionController(new String[]{"QGM4"});

        AuctionInformation auctionInformation = auctionController.auctions();

        assertThat(auctionInformation.getAuctions(), hasItemInArray("QGM4"));
    }
}
