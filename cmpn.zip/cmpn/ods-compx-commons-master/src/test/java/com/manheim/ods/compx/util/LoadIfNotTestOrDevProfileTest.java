package com.manheim.ods.compx.util;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.context.annotation.ConfigurationCondition;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotatedTypeMetadata;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


public class LoadIfNotTestOrDevProfileTest {

    private ConditionContext mockContext;
    private AnnotatedTypeMetadata mockMetadata;
    private Environment environment;

    @Before
    public void setup() {

        mockContext = mock(ConditionContext.class);
        mockMetadata = mock(AnnotatedTypeMetadata.class);
        environment = mock(Environment.class);
    }

    @Test
    public void shouldReturnParseConfigurationAsConfigurationPhase() {
        assertThat(new LoadIfNotTestOrDevProfile().getConfigurationPhase(), is(ConfigurationCondition.ConfigurationPhase.PARSE_CONFIGURATION));
    }

    @Test
    public void shouldReturnFalseIfTestActiveProfile() {

        when(environment.getActiveProfiles()).thenReturn(new String[]{"test"});
        when(mockContext.getEnvironment()).thenReturn(environment);

        boolean result = new LoadIfNotTestOrDevProfile().matches(mockContext, mockMetadata);

        assertThat(result, is(false));
    }

    @Test
    public void shouldReturnFalseIfDevActiveProfile() throws Exception {

        when(environment.getActiveProfiles()).thenReturn(new String[]{"dev"});
        when(mockContext.getEnvironment()).thenReturn(environment);

        boolean result = new LoadIfNotTestOrDevProfile().matches(mockContext, mockMetadata);

        assertThat(result, is(false));
    }

    @Test
    public void shouldReturnTrueIfNotDevOrTestActiveProfile() throws Exception {

        when(environment.getActiveProfiles()).thenReturn(new String[]{"silo4"});
        when(mockContext.getEnvironment()).thenReturn(environment);

        boolean result = new LoadIfNotTestOrDevProfile().matches(mockContext, mockMetadata);

        assertThat(result, is(true));
    }

}