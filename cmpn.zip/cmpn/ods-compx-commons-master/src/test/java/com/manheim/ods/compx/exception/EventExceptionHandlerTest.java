package com.manheim.ods.compx.exception;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import javax.jms.JMSException;

import com.manheim.ods.compx.service.MailService;
import com.manheim.ods.compx.util.MetricReporter;
import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.util.LogWrapper;

import java.net.SocketException;

public class EventExceptionHandlerTest {
	
	private EventExceptionHandler eventExceptionHandler;
	private LogWrapper logger;
	private MailService mailService;
	private MetricReporter metricReporter;

	@Before
	public void setup()    {
		logger = mock(LogWrapper.class);
		mailService = mock(MailService.class);
		metricReporter = mock(MetricReporter.class);
		eventExceptionHandler = new EventExceptionHandler(logger, mailService, metricReporter);
	}

	@Test
	public void shouldLogErrorWhenJMSExceptionIsThrown() {
		try {
			eventExceptionHandler.handleExecutionException(new JMSException("Exception Message"));
		} catch (Exception ex){}

		verify(logger).error(JMSException.class, "Exception Message");
	}

	@Test(expected = JMSException.class)
	public void shouldThrowJMSException() throws Exception {
		eventExceptionHandler.handleExecutionException(new JMSException("Exception Message"));
	}

	@Test(expected = UnsuccessfulClientExecutionException.class)
	public void shouldThrowUnsuccessfulClientExecutionException() throws Exception {
		eventExceptionHandler.handleExecutionException(new UnsuccessfulClientExecutionException("Some Client", 500));
	}

	@Test(expected = SocketException.class)
	public void shouldThrowSocketException() throws Exception {
		eventExceptionHandler.handleExecutionException(new SocketException("Exception Socket Message"));
	}

	@Test
	public void shouldSendMailWhenExceptionIsThrown() throws Exception {
		try {
			eventExceptionHandler.handleExecutionException(new UnsuccessfulClientExecutionException("Some Client", 500));
		} catch (UnsuccessfulClientExecutionException ex) {
			// Ignore
		}

		verify(mailService).sendMessage("Unable to process event", "HTTP Error 500 while executing Some Client.");
	}

	@Test
	public void shouldSendMetricWhenEventParsingFails() throws Exception {
		eventExceptionHandler.handleParsingException(new EventParsingException("", "Application Name"));

		verify(metricReporter).incrementEventFailed();
	}

	@Test
	public void shouldLogErrorWhenEventParsingFails() throws Exception {
		eventExceptionHandler.handleParsingException(new EventParsingException("", "Application Name"));

		verify(logger).error(EventParsingException.class, "[Application Name] No JSON attribute found for key  when parsing event.");
	}

	@Test
	public void shouldSendMailWhenEventParsingFails() throws Exception {
		String jsonKey = "some key";
		String applicationName = "app";
		eventExceptionHandler.handleParsingException(new EventParsingException(jsonKey, applicationName));

		verify(mailService).sendMessage(anyString(), anyString());
	}

	@Test
	public void shouldSendMetricWhenEventResourceNotFound() throws Exception {
		eventExceptionHandler.handleNotFoundException(new ResourceNotFoundException("Some Client"));

		verify(metricReporter).incrementEventResourceNotFound();
	}

	@Test
	public void shouldLogErrorWhenEventResourceNotFound() throws Exception {
		eventExceptionHandler.handleNotFoundException(new ResourceNotFoundException("Some Client"));

		verify(logger).error(ResourceNotFoundException.class, "Resource not found while executing Some Client.");
	}
}
