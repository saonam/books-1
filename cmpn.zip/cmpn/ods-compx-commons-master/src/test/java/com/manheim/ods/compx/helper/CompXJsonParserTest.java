package com.manheim.ods.compx.helper;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.exception.EventParsingException;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;
import java.net.URISyntaxException;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

public class CompXJsonParserTest {

	private CompXJsonParser compXJsonParser;
	private JsonNode node;

	@Before
	public void setUp() throws Exception {
		compXJsonParser = new CompXJsonParser("My App");
		JsonParser jsonParser = getJsonParser("commonEventData.json");
		node = jsonParser.readValueAsTree();
	}

	@Test(expected = EventParsingException.class)
	public void shouldThrowAnExceptionWhenARequiredKeyIsNULL() throws IOException, URISyntaxException {
		JsonParser jsonParser = getJsonParser("nullConsignmentIdEventData.json");
		JsonNode node = jsonParser.readValueAsTree();

		compXJsonParser.getNonNullValueForKey(node, "consignmentId");
	}

	@Test
	public void shouldReturnValueWhenARequiredKeyIsNotNull() throws Exception {
		String value = compXJsonParser.getNonNullValueForKey(node, "auctionCode");

		assertThat(value, is("NOAA"));
	}

	@Test(expected = EventParsingException.class)
	public void shouldThrowAnExceptionWhenARequiredKeyIsEmptyString() throws IOException, URISyntaxException {
		JsonParser jsonParser = getJsonParser("emptyAuctionEventData.json");
		JsonNode node = jsonParser.readValueAsTree();

		compXJsonParser.getRequiredValueForKey(node, "auctionCode");
	}

	@Test
	public void shouldReturnValueWhenARequiredKeyIsNotEmpty() throws Exception {
		String value = compXJsonParser.getRequiredValueForKey(node, "auctionCode");

		assertThat(value, is("NOAA"));
	}

	@Test(expected = EventParsingException.class)
	public void shouldThrowAnExceptionWhenARequiredKeyIsMissing() throws IOException, URISyntaxException {
		JsonParser jsonParser = getJsonParser("missingEventTypeEventData.json");
		JsonNode node = jsonParser.readValueAsTree();

		compXJsonParser.getRequiredValueForKey(node, "eventType");
	}

	@Test
	public void eventParsingExceptionShouldContainApplicationName() throws IOException, URISyntaxException {
		JsonParser jsonParser = getJsonParser("missingEventTypeEventData.json");
		JsonNode node = jsonParser.readValueAsTree();

		try {
			compXJsonParser.getRequiredValueForKey(node, "eventType");
		} catch (EventParsingException e) {
			assertTrue(e.getMessage().contains("My App"));
		}
	}

	@Test
	public void shouldReturnNullWhenKeyIsEmptyString() throws IOException, URISyntaxException {
		JsonParser jsonParser = getJsonParser("emptyAuctionEventData.json");
		JsonNode node = jsonParser.readValueAsTree();

		assertNull(compXJsonParser.getValueForKey(node, "auctionCode"));
	}

	@Test
	public void shouldReturnValueWhenAKeyIsNotEmpty() throws Exception {
		String value = compXJsonParser.getValueForKey(node, "auctionCode");

		assertThat(value, is("NOAA"));
	}

	private JsonParser getJsonParser(String file) throws IOException, URISyntaxException {
		return new ObjectMapper().getFactory().createParser(new CompXFileReader().fetchFileAsString(file));
	}
}