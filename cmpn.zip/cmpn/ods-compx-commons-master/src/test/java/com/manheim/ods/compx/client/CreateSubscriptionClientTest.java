package com.manheim.ods.compx.client;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.function.Consumer;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.api.EventerAPI;
import com.manheim.ods.compx.exception.EventerSubscriptionException;
import com.manheim.ods.compx.service.Retry;
import com.manheim.ods.compx.setup.EventerValues;
import com.manheim.ods.compx.setup.JsonBuilder;
import com.manheim.ods.compx.util.LogWrapper;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class CreateSubscriptionClientTest {

  public static final String ACCESS_TOKEN = "Eventer Access Token";

  private CreateSubscriptionClient createSubscriptionClient;
  private Client client;
  private JsonBuilder jsonBuilder;
  private String location;
  private String messagePattern;
  private EventerAPI eventerAPI;
  private Call call;
  private LogWrapper logWrapper;
  private Response<String> successfulResponse;
  private Response<Object> errorResponse;
  private EventerValues eventerValues;
  private Retry retry;

  @Before
  public void setUp() throws Exception {
    client = mock(Client.class);
    jsonBuilder = mock(JsonBuilder.class);
    eventerAPI = mock(EventerAPI.class);
    JSONObject requestBody = mock(JSONObject.class);
    logWrapper = mock(LogWrapper.class);
    call = mock(Call.class);
    errorResponse = Response.error(403, mock(ResponseBody.class));
    eventerValues = mock(EventerValues.class);
    retry = mock(Retry.class);
    location = "href value";
    messagePattern = "First Pattern";
    successfulResponse = Response.success("success");

    createSubscriptionClient =
        new CreateSubscriptionClient(eventerAPI, jsonBuilder, retry, logWrapper);

    when(requestBody.toString()).thenReturn("");
    when(jsonBuilder.buildSubscriber()).thenReturn(requestBody);
    when(jsonBuilder.buildSubscription(anyString(), anyString())).thenReturn(requestBody);
    when(eventerAPI.configureEventerSubscriptionCall(eq("Bearer " + ACCESS_TOKEN),
        any(RequestBody.class))).thenReturn(call);
    when(client.execute(call, CreateSubscriptionClient.class)).thenReturn(successfulResponse);
  }

  @Test
  public void shouldCreateRequestBodyWithPatternWhenCreatingSubscriptions() throws Exception {
    when(jsonBuilder.buildSubscription(eq(location), anyString()))
        .thenReturn(mock(JSONObject.class));

    createSubscriptionClient.createSubscription(ACCESS_TOKEN, location, messagePattern);

    verify(jsonBuilder).buildSubscription(eq("href value"), eq("First Pattern"));
  }

  @Test
  public void shouldConfigureEventerAPICallWhenCreatingSubscription() throws Exception {
    createSubscriptionClient.createSubscription(ACCESS_TOKEN, location, messagePattern);

    verify(eventerAPI).configureEventerSubscriptionCall(
        eq(String.format("Bearer %s", ACCESS_TOKEN)), any(RequestBody.class));
  }

  @Test
  public void shouldRetryCallWhenCreateSubscriptionCallFails() throws Exception {
    when(client.execute(call, CreateSubscriptionClient.class)).thenReturn(errorResponse);
    when(retry.execute(eq(call), any(Consumer.class), eq(createSubscriptionClient)))
        .thenReturn(successfulResponse);
    when(eventerValues.getMaxRetryCount()).thenReturn(1);

    createSubscriptionClient.createSubscription(ACCESS_TOKEN, location, messagePattern);

    verify(retry).execute(eq(call), any(Consumer.class), eq(createSubscriptionClient));
  }

  @Test
  public void shouldLogInfoWhenClientIsExecutingCall() throws Exception {
    createSubscriptionClient.createSubscription(ACCESS_TOKEN, location, messagePattern);

    verify(logWrapper).info(CreateSubscriptionClient.class, "Creating Subscription");
  }

  @Test
  public void shouldLogInfoWhenClientExecutionIsSuccessful() throws Exception {
    createSubscriptionClient.createSubscription(ACCESS_TOKEN, location, messagePattern);

    verify(logWrapper).info(CreateSubscriptionClient.class,
        "Successful response to create subscription.");
  }

  @Test
  public void shouldLogInfoWhenClientExecutionFailsWithJsonException() {
    JSONException jsonException = mock(JSONException.class);
    try {
      when(jsonBuilder.buildSubscription(location, messagePattern)).thenThrow(jsonException);
    } catch (JSONException e1) {

    }
    try {
      createSubscriptionClient.createSubscription(ACCESS_TOKEN, location, messagePattern);
    } catch (EventerSubscriptionException e) {
    }
    verify(logWrapper).error(CreateSubscriptionClient.class, jsonException);
  }

  @Test
  public void shouldLogInfoWhenRetryFailsWithIOException() throws Exception {
    IOException ioException = mock(IOException.class);

    try {

      when(eventerAPI.configureEventerSubscriptionCall(anyString(), any(RequestBody.class)))
          .thenReturn(call);

      when(retry.execute(eq(call), any(Consumer.class), eq(createSubscriptionClient)))
          .thenThrow(ioException);
      createSubscriptionClient.createSubscription(ACCESS_TOKEN, location, messagePattern);
    } catch (IOException e) {
    } catch (EventerSubscriptionException e) {
    }
    verify(logWrapper).error(CreateSubscriptionClient.class, ioException);

  }

  @Test
  public void shouldLogInfoWhenRetryFailsWithJSONException() throws Exception {
    IOException ioException = mock(IOException.class);

    try {

      when(eventerAPI.configureEventerSubscriptionCall(anyString(), any(RequestBody.class)))
          .thenReturn(call);

      when(retry.execute(eq(call), any(Consumer.class), eq(createSubscriptionClient)))
          .thenThrow(ioException);
      createSubscriptionClient.createSubscription(ACCESS_TOKEN, location, messagePattern);
    } catch (IOException e) {
    } catch (EventerSubscriptionException e) {
    }
    verify(logWrapper).error(CreateSubscriptionClient.class, ioException);

  }

}
