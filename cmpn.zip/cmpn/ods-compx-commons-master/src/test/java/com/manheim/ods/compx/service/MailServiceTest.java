package com.manheim.ods.compx.service;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.*;

public class MailServiceTest {

	@Autowired
	private JavaMailSender javaMailSender;
	private MailService mailService;
	private String subject;
	private String message;
	private boolean mailEnabled;
	private String recipient;
	private String from;

	@Before
	public void setUp() throws Exception {
		javaMailSender = mock(JavaMailSender.class);
		recipient = "test@pagerduty.com";
		from = "test@manheim.com";
		subject = "Eventer Setup Error";
		message = "Creating subscription failed";
	}

	@Test
	public void shouldSendCreatedMessage() throws Exception {
		mailEnabled = true;
		mailService = new MailService(javaMailSender, mailEnabled, recipient, from);

		SimpleMailMessage expectedMessage = new SimpleMailMessage();
		expectedMessage.setFrom(from);
		expectedMessage.setTo(recipient);
		expectedMessage.setSubject(subject);
		expectedMessage.setText(message);

		mailService.sendMessage(subject, message);

		verify(javaMailSender).send(eq(expectedMessage));
	}

	@Test
	public void shouldOnlySendMailWhenEmailEnabled() throws Exception {
		mailEnabled = false;
		mailService = new MailService(javaMailSender, mailEnabled, recipient, from);

		mailService.sendMessage(subject, message);

		verify(javaMailSender, never()).send(any(SimpleMailMessage.class));
	}
}