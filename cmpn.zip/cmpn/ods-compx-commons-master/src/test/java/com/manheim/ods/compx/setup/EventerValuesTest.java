package com.manheim.ods.compx.setup;

import org.junit.Test;

import java.util.Collections;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

public class EventerValuesTest {
    @Test
    public void shouldCreateBasicAuthEncodedValue() {
        EventerValues eventerValues = new EventerValues(Collections.<String>emptyList(), 1, "email", "callback", "username", "password");

        String basicAuth = eventerValues.getBasicAuthentication();

        assertThat(basicAuth, is("Basic dXNlcm5hbWU6cGFzc3dvcmQ="));
    }

    @Test
    public void shouldReturnMaxRetryCountWhenGreaterOrEqualToZero() {
        EventerValues eventerValues = new EventerValues(Collections.<String>emptyList(), 1, "email", "callback", "username", "password");

        Integer maxRetryCount = eventerValues.getMaxRetryCount();

        assertThat(maxRetryCount, is(1));
    }

    @Test
    public void shouldReturnZeroWhenMaxRetryCountIsNegative() {
        EventerValues eventerValues = new EventerValues(Collections.<String>emptyList(), -5, "email", "callback", "username", "password");

        Integer maxRetryCount = eventerValues.getMaxRetryCount();

        assertThat(maxRetryCount, is(0));
    }
}