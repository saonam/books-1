package com.manheim.ods.compx.exception;

import org.junit.Test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;

public class EventParsingExceptionTest {
    @Test
    public void shouldHaveMessageWhenExceptionIsCreated() {
        EventParsingException eventParsingException = new EventParsingException("jsonKey", "Some Application");

        assertThat(eventParsingException.getMessage(), is("[Some Application] No JSON attribute found for key jsonKey when parsing event."));
    }
}