package com.manheim.ods.compx.util;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import org.junit.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class LogWrapperTest {

  @Test
  public void shouldWriteAnObjectsValueToStringWhenLogged() throws JsonProcessingException {
    ObjectMapper objectMapper = mock(ObjectMapper.class);
    LogWrapper logWrapper = new LogWrapper(objectMapper);

    Object objectToSerialize = mock(Object.class);
    logWrapper.logResponse(anyString(), LogWrapperTest.class, objectToSerialize);

    verify(objectMapper).writeValueAsString(objectToSerialize);
  }

  @Test
  public void shouldWriteDebugStringWhenLogged() throws JsonProcessingException {
    ObjectMapper objectMapper = mock(ObjectMapper.class);
    LogWrapper logWrapper = new LogWrapper(objectMapper);

    Object objectToSerialize = mock(Object.class);
    logWrapper.debug(LogWrapperTest.class, String.format("%s response: %s", anyString(),
        objectMapper.writeValueAsString(objectToSerialize)));

    verify(objectMapper).writeValueAsString(objectToSerialize);
  }

  @Test
  public void shouldWriteErrorStringWhenLogged() throws JsonProcessingException {
    ObjectMapper objectMapper = mock(ObjectMapper.class);
    LogWrapper logWrapper = new LogWrapper(objectMapper);

    Object objectToSerialize = mock(Object.class);

    logWrapper.error(LogWrapperTest.class, String.format("%s response: %s", anyString(),
        objectMapper.writeValueAsString(objectToSerialize)));

    verify(objectMapper).writeValueAsString(objectToSerialize);
  }

  @Test
  public void testLogWrapperException() throws JsonProcessingException {
    ObjectMapper objectMapper = mock(ObjectMapper.class);
    LogWrapper logWrapper = new LogWrapper(objectMapper);


    logWrapper.error(LogWrapperTest.class, "Test logger", new Exception("Any exception"));
    logWrapper.error(LogWrapperTest.class, new Exception("Any exception"));
  }

}
