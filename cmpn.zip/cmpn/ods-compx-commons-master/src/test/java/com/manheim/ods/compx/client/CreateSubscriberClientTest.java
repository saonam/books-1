package com.manheim.ods.compx.client;


import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.function.Consumer;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.api.EventerAPI;
import com.manheim.ods.compx.exception.EventerSubscriptionException;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.service.Retry;
import com.manheim.ods.compx.setup.EventerValues;
import com.manheim.ods.compx.setup.JsonBuilder;
import com.manheim.ods.compx.util.LogWrapper;
import com.manheim.ods.compx.util.Sleeper;

import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.mock.Calls;

public class CreateSubscriberClientTest {

  public static final String ACCESS_TOKEN = "Eventer Access Token";
  private EventerAPI eventerAPI;
  private LogWrapper logWrapper;
  private Client client;
  private CreateSubscriberClient createSubscriberClient;
  private Call<Void> call;
  private JsonBuilder jsonBuilder;
  private Response<Object> successfulResponse;
  private Response<Object> unsuccessfulResponse;
  private Retry retry;

  @Before
  public void setUp() throws Exception {
    eventerAPI = mock(EventerAPI.class);
    logWrapper = mock(LogWrapper.class);
    client = mock(Client.class);
    call = Calls.response(null);
    jsonBuilder = mock(JsonBuilder.class);
    successfulResponse = Response.success(null);
    unsuccessfulResponse =
        Response.error(500, ResponseBody.create(MediaType.parse("text/plain"), "test"));
    retry = mock(Retry.class);
    JSONObject requestBody = mock(JSONObject.class);

    createSubscriberClient = new CreateSubscriberClient(eventerAPI, logWrapper, jsonBuilder, retry);

    when(requestBody.toString()).thenReturn("");
    when(jsonBuilder.buildSubscriber()).thenReturn(requestBody);
    when(eventerAPI.configureEventerSubscriberCall(eq("Bearer " + ACCESS_TOKEN),
        any(RequestBody.class))).thenReturn(call);
    when(client.execute(call, CreateSubscriberClient.class)).thenReturn(successfulResponse);
    when(retry.execute(eq(call), any(Consumer.class), eq(createSubscriberClient)))
        .thenReturn(successfulResponse);
  }

  @Test
  public void shouldCreateRequestBodyWhenCreatingSubscriber()
      throws JSONException, EventerSubscriptionException {
    when(jsonBuilder.buildSubscriber()).thenReturn(mock(JSONObject.class));

    createSubscriberClient.createSubscriber(ACCESS_TOKEN);

    verify(jsonBuilder).buildSubscriber();
  }

  @Test
  public void shouldConfigureEventerAPICallWhenCreatingSubscriber()
      throws IOException, JSONException, EventerSubscriptionException {
    createSubscriberClient.createSubscriber(ACCESS_TOKEN);

    verify(eventerAPI).configureEventerSubscriberCall(eq(String.format("Bearer %s", ACCESS_TOKEN)),
        any(RequestBody.class));
  }

  @Test
  public void shouldExecuteClientWhenCreatingSubscriber()
      throws IOException, JSONException, EventerSubscriptionException {
    createSubscriberClient.createSubscriber(ACCESS_TOKEN);

    verify(retry).execute(eq(call), any(Consumer.class), eq(createSubscriberClient));
  }

  @Test
  public void shouldRetrieveLocationFromResponse() throws Exception {
    Response response = Response.success(null, Headers.of("Location", "someLocation"));
    when(retry.execute(eq(call), any(Consumer.class), eq(createSubscriberClient)))
        .thenReturn(response);

    String location = createSubscriberClient.createSubscriber(ACCESS_TOKEN);

    assertThat(location, is("someLocation"));
  }

  @Test
  public void shouldLogInfoWhenClientIsExecutingCall() throws Exception {
    createSubscriberClient.createSubscriber(ACCESS_TOKEN);

    verify(logWrapper).info(CreateSubscriberClient.class, "Creating subscriber.");
  }

  @Test
  public void shouldLogInfoWhenClientExecutionIsSuccessful() throws Exception {
    createSubscriberClient.createSubscriber(ACCESS_TOKEN);

    verify(logWrapper).info(CreateSubscriberClient.class, "Successfully created subscriber.");
  }

  @Test
  public void shouldLogErrorWhenClientExecutionGetsIOException() throws Exception {
    IOException ioException = mock(IOException.class);
    // retry = new Retry(client, mock(EventerValues.class), mock(Sleeper.class));
    retry = mock(Retry.class);

    createSubscriberClient = new CreateSubscriberClient(eventerAPI, logWrapper, jsonBuilder, retry);
    String accessToken = "AccessToken";
    try {
      when(eventerAPI.configureEventerSubscriberCall(anyString(), any(RequestBody.class)))
          .thenReturn(call);

      when(retry.execute(eq(call), any(Consumer.class), eq(createSubscriberClient)))
          .thenThrow(ioException);
      createSubscriberClient.createSubscriber(accessToken);
    } catch (IOException e) {
    } catch (EventerSubscriptionException e) {
      Assert.assertEquals(e.getMessage(), "Failed subscribing to Eventer!!");
    }
    verify(logWrapper).error(CreateSubscriberClient.class, ioException);

  }

  @Test
  public void shouldLogInfoWhenClientExecutionFailsWithJsonException() {
    JSONException jsonException = mock(JSONException.class);
    try {
      when(jsonBuilder.buildSubscriber()).thenThrow(jsonException);
    } catch (JSONException e1) {

    }
    try {
      createSubscriberClient.createSubscriber(ACCESS_TOKEN);
    } catch (EventerSubscriptionException e) {
    }
    verify(logWrapper).error(CreateSubscriberClient.class, jsonException);
  }

  @Test
  public void shouldLogInfoWhenClientExecutionIsUnSuccessful() throws Exception {
    when(client.execute(call, CreateSubscriberClient.class)).thenReturn(unsuccessfulResponse);
    retry = new Retry(client, mock(EventerValues.class), mock(Sleeper.class));

    createSubscriberClient = new CreateSubscriberClient(eventerAPI, logWrapper, jsonBuilder, retry);
    String accessToken = "AccessToken";
    try {
      when(eventerAPI.configureEventerSubscriberCall(anyString(), any(RequestBody.class)))
          .thenReturn(call);

      createSubscriberClient.createSubscriber(accessToken);
    } catch (EventerSubscriptionException e) {
    } catch (UnsuccessfulClientExecutionException e) {
    }
    verify(logWrapper).debug(eq(CreateSubscriberClient.class),
        eq("Unsuccessful Eventer API call to create subscriber with HTTP Error 500."));

  }

}
