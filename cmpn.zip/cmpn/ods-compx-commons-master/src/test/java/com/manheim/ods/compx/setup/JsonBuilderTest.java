package com.manheim.ods.compx.setup;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.model.eventer.BaseEvent;

public class JsonBuilderTest {

	private JsonBuilder jsonBuilder;
	private Integer MAX_RETRY_COUNT = 3;
	private String EVENTER_SUPPORT_EMAIL = "email";
	private String EVENTER_CALLBACK_URL = "callback";
	private String EVENTER_AUTHENTICATION = "auth";

	@Before
	public void setUp() throws Exception {
		EventerValues eventerValues = stubEventerValues();
		jsonBuilder = new JsonBuilder(eventerValues);
	}

	@Test
	public void shouldHaveSubscriberLocationAndResourceInSubscriptionJson() throws JSONException {
		JSONObject result = jsonBuilder.buildSubscription("subscriberLocation", "patternType");

		assertThat(result.getJSONObject("subscriber").get("href"), is("subscriberLocation"));
		assertThat(result.getJSONArray("criteria").getJSONObject(0).getJSONObject("type").get("pattern"),
				is("patternType"));
	}

	@Test
	public void shouldHaveCallBackAndEmailKeysInSubscriberJson() throws JSONException {
		JSONObject result = jsonBuilder.buildSubscriber();

		assertThat(result.getJSONArray("emails").get(0), is("email"));
		assertThat(result.get("callback"), is("callback"));
		assertThat(result.getJSONObject("headers").get("Authorization"), is("auth"));
	}

	@Test
	public void shouldHaveEventTypeEventHrefAndAPIResponseWhenNotGivenResponsecode() throws Exception {
		String type = "some type";
		String href = "some href";
		BaseEvent event = new BaseEvent(false, href, type);
		JSONObject response = new JSONObject().put("key", "value");

		JSONObject result = jsonBuilder.buildQueueJson(response, event);

		assertThat(result.getJSONObject("queueMessage").get("apiResponse"), is(response));
		assertThat(result.getJSONObject("queueMessage").get("eventType"), is(type));
		assertThat(result.getJSONObject("queueMessage").get("eventHref"), is(href));
		assertTrue(result.getJSONObject("queueMessage").isNull("error"));
		assertEquals(result.getJSONObject("queueMessage").get("event").toString(), new JSONObject(event).toString());
	}

	@Test
	public void shouldHaveEventTypeEventHrefAndAPIResponse() throws Exception {
		int responseCode = 200;
		String type = "some type";
		String href = "some href";
		BaseEvent event = new BaseEvent(false, href, type);
		JSONObject response = new JSONObject().put("key", "value");

		JSONObject result = jsonBuilder.buildQueueJson(response, responseCode, event);

		assertThat(result.getJSONObject("queueMessage").get("apiResponse"), is(response));
		assertThat(result.getJSONObject("queueMessage").get("eventType"), is(type));
		assertThat(result.getJSONObject("queueMessage").get("eventHref"), is(href));
		assertTrue(result.getJSONObject("queueMessage").isNull("error"));
		assertEquals(result.getJSONObject("queueMessage").get("event").toString(), new JSONObject(event).toString());
	}

	@Test
	public void shouldHaveEventTypeEventHrefAndErrorCode() throws Exception {
		int responseCode = 404;
		String type = "some type";
		String href = "some href";
		BaseEvent event = new BaseEvent(false, href, type);

		JSONObject result = jsonBuilder.buildQueueJson(null, responseCode, event);

		assertTrue(result.getJSONObject("queueMessage").isNull("apiResponse"));
		assertThat(result.getJSONObject("queueMessage").get("eventType"), is(type));
		assertThat(result.getJSONObject("queueMessage").get("eventHref"), is(href));
		assertThat(result.getJSONObject("queueMessage").getJSONObject("error").get("errorCode"), is(responseCode));
		assertEquals(result.getJSONObject("queueMessage").get("event").toString(), new JSONObject(event).toString());
	}

	private EventerValues stubEventerValues() {
		EventerValues eventerValues = mock(EventerValues.class);
		when(eventerValues.getMaxRetryCount()).thenReturn(MAX_RETRY_COUNT);
		when(eventerValues.getSupportEmail()).thenReturn(EVENTER_SUPPORT_EMAIL);
		when(eventerValues.getCallback()).thenReturn(EVENTER_CALLBACK_URL);
		when(eventerValues.getBasicAuthentication()).thenReturn(EVENTER_AUTHENTICATION);
		return eventerValues;
	}
}