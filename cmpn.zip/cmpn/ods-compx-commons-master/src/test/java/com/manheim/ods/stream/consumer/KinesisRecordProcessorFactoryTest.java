package com.manheim.ods.stream.consumer;

import static org.junit.Assert.assertNotNull;

import org.apache.camel.ProducerTemplate;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import com.amazonaws.services.kinesis.clientlibrary.interfaces.IRecordProcessor;
import com.manheim.ods.compx.util.MetricReporter;

public class KinesisRecordProcessorFactoryTest {
  @Mock
  private ProducerTemplate producerTemplate;
  @Mock
  private MetricReporter metricReporter;

  KinesisRecordProcessorFactory chargesRecordProcessorFactory;


  @Before
  public void setup() {
    String[] allowedAuctions = {"VALID_AUCTION"};
    String[] ignoredAuctions = {"INVALID_AUCTION"};
    chargesRecordProcessorFactory = new KinesisRecordProcessorFactory(producerTemplate,
        metricReporter, 300L, 3, 30000L, allowedAuctions, ignoredAuctions);
  }

  @Test
  public void testCreateProcessor() {
    IRecordProcessor chargesRecordProcessor = chargesRecordProcessorFactory.createProcessor();
    chargesRecordProcessor.initialize("TEST_SHARD_ID");
    assertNotNull(chargesRecordProcessor);
  }

}
