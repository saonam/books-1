package com.manheim.ods.compx.helper;

import org.junit.Test;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

public class CompXFileReaderTest {
	@Test
	public void shouldReadAFile() throws Exception {
		CompXFileReader fileReader = new CompXFileReader();

		String fileContents = fileReader.fetchFileAsString("testfile.txt");

		assertThat(fileContents, is("hello world"));
	}
}