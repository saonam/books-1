package com.manheim.ods.stream.consumer;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.net.UnknownHostException;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.ClientConfigurationFactory;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;

public class KinesisWorkerFactoryTest {

  KinesisWorkerFactory kinesisWorkerFactory;
  @Mock
  KinesisRecordProcessorFactory kinesisRecordProcessorFactory;
  @Mock
  KinesisClientLibConfiguration kinesisClientLibConfiguration;

  @Before
  public void setup() {
    MockitoAnnotations.initMocks(this);
    ClientConfiguration clientConfiguration = (new ClientConfigurationFactory()).getConfig();
    when(kinesisClientLibConfiguration.getKinesisClientConfiguration())
        .thenReturn(clientConfiguration);
    when(kinesisClientLibConfiguration.getDynamoDBClientConfiguration())
        .thenReturn(clientConfiguration);
    when(kinesisClientLibConfiguration.getCloudWatchClientConfiguration())
        .thenReturn(clientConfiguration);
    when(kinesisClientLibConfiguration.getMetricsMaxQueueSize()).thenReturn(10000);
    when(kinesisClientLibConfiguration.getMetricsBufferTimeMillis()).thenReturn(10000L);
    when(kinesisClientLibConfiguration.getTableName()).thenReturn("TEST_TABLE");
    when(kinesisClientLibConfiguration.getMaxLeaseRenewalThreads()).thenReturn(2);
    when(kinesisClientLibConfiguration.getMaxLeasesForWorker()).thenReturn(1);
    when(kinesisClientLibConfiguration.getMaxLeasesToStealAtOneTime()).thenReturn(1);
    when(kinesisClientLibConfiguration.getInitialLeaseTableReadCapacity()).thenReturn(1);
    when(kinesisClientLibConfiguration.getInitialLeaseTableWriteCapacity()).thenReturn(1);
    kinesisWorkerFactory =
        new KinesisWorkerFactory(kinesisRecordProcessorFactory, kinesisClientLibConfiguration);

  }

  @Test
  public void test() {
    Worker worker = kinesisWorkerFactory.newWorker();
    assertNotNull(worker);
  }

  @Test
  public void testReplayWorker() throws UnknownHostException {
    Worker worker = kinesisWorkerFactory.newReplayWorker("2018-03-27T11:45:10");
    assertNotNull(worker);
  }

}
