package com.manheim.ods.stream.controller;



import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.when;

import java.net.UnknownHostException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;
import com.manheim.ods.stream.consumer.KinesisReceiver;
import com.manheim.ods.stream.consumer.KinesisRecordProcessorFactory;
import com.manheim.ods.stream.consumer.KinesisWorkerFactory;
import com.manheim.ods.stream.model.ReplayRequest;

@RunWith(MockitoJUnitRunner.class)
public class StreamReplayControllerTest {

  private KinesisReceiver kinesisReceiver;
  @Mock
  private KinesisWorkerFactory kinesisWorkerFactory;
  @Mock
  private KinesisRecordProcessorFactory kinesisRecordProcessorFactory;
  @Mock
  private KinesisClientLibConfiguration kinesisClientLibConfiguration;
  @Mock
  private Worker worker;

  private StreamReceiverController streamReceiverController;

  private StreamReplayController streamReplayController;

  @Before
  public void setUp() throws Exception {
    when(kinesisWorkerFactory.newReplayWorker(anyString())).thenReturn(worker);
    when(kinesisWorkerFactory.newWorker()).thenReturn(worker);
    kinesisReceiver = new KinesisReceiver(kinesisWorkerFactory, kinesisRecordProcessorFactory,
        kinesisClientLibConfiguration, worker);
    doAnswer((Answer) invocation -> {
      return null;
    }).when(worker).run();
    when(worker.getApplicationName()).thenReturn("REPLAY_APPLICATION");
    streamReplayController = new StreamReplayController(kinesisReceiver);
  }

  @Test
  public void testReplay() {
    ResponseEntity responseEntity;
    try {
      ReplayRequest replayInfo = new ReplayRequest("2018-01-23T02:10:29", 1);
      responseEntity = streamReplayController.replay(replayInfo);
      assertEquals(HttpStatus.CREATED, responseEntity.getStatusCode());
    } catch (UnknownHostException e) {
      assert (false);
    }
  }


  @Test
  public void testStop() {
    ResponseEntity responseEntity;
    try {
      ReplayRequest replayInfo = new ReplayRequest("2018-01-23T02:10:29", 1);
      streamReplayController.replay(replayInfo);
      responseEntity = streamReplayController.stop();
      assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
    } catch (UnknownHostException e) {
      assert (false);
    }
  }


  @Test
  public void testReplayWithFailure() {
    ResponseEntity responseEntity;
    try {
      ReplayRequest replayInfo = new ReplayRequest("2018-01-23T02:10:29", 1);
      kinesisReceiver = Mockito.mock(KinesisReceiver.class);
      when(kinesisReceiver.replayTime(anyString(), eq(1))).thenReturn(null);
      streamReplayController = new StreamReplayController(kinesisReceiver);
      responseEntity = streamReplayController.replay(replayInfo);
      assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());
    } catch (UnknownHostException e) {
      assert (false);
    }

  }

  @Test
  public void testReplayWithWorkerAlreadyException()
      throws UnknownHostException, InterruptedException, ExecutionException {
    kinesisReceiver = new KinesisReceiver(kinesisWorkerFactory, kinesisRecordProcessorFactory,
        kinesisClientLibConfiguration, worker);
    streamReceiverController = new StreamReceiverController(kinesisReceiver);
    streamReplayController = new StreamReplayController(kinesisReceiver);

    streamReceiverController.start();
    Future<String> completableFuture = kinesisReceiver.replayTime("2018-01-23T02:10:29", 1);
    assertNull(completableFuture);
  }

}
