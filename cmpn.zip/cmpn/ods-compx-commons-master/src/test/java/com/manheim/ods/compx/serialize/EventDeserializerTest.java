package com.manheim.ods.compx.serialize;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.io.IOException;
import java.net.URISyntaxException;

import org.junit.Before;
import org.junit.Test;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.manheim.ods.compx.helper.CompXFileReader;
import com.manheim.ods.compx.helper.CompXJsonParser;
import com.manheim.ods.compx.model.eventer.AuctionEvent;
import com.manheim.ods.compx.util.LogWrapper;

public class EventDeserializerTest {

  private EventDeserializer eventDeserializer;
  private DeserializationContext context;
  private LogWrapper logger;
  private JsonParser jsonParser;

  @Before
  public void setUp() throws Exception {
    logger = mock(LogWrapper.class);
    eventDeserializer = new EventDeserializer(logger, new CompXJsonParser("My App"));

    ObjectMapper objectMapper = new ObjectMapper();
    context = objectMapper.getDeserializationContext();
    jsonParser = objectMapper.getFactory()
        .createParser(new CompXFileReader().fetchFileAsString("eventData.json"));
  }

  @Test
  public void shouldLogEventDetailsWhenDeserializingEvent() throws Exception {
    eventDeserializer.deserialize(jsonParser, context);

    verify(logger).info(eq(EventDeserializer.class), anyString());
  }

  @Test
  public void shouldDeserializeEventerRequestToAnEvent() throws IOException, URISyntaxException {
    AuctionEvent event = eventDeserializer.deserialize(jsonParser, context);

    assertThat(event.getHref(), is("https://api.manheim.com/events/id/1234"));
    assertThat(event.getEventType(), is("CHECK_IN"));
    assertThat(event.getVin(), is("VIN"));
  }

  @Test
  public void verifyAuctionEventToString() throws Exception {
    AuctionEvent event = eventDeserializer.deserialize(jsonParser, context);

    assertTrue(event.toString().contains("1234"));

  }

}
