package com.manheim.ods.compx.model.eventer;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

public class MySubscriberMessageTest {

  @Test
  public void shouldReturnStringContainingLocations() throws Exception {
    List<EventerSubscriber> subscribers = new ArrayList<>();
    subscribers.add(new EventerSubscriber("Href Value"));
    subscribers.add(new EventerSubscriber("Second Href"));
    MySubscriberMessage mySubscriberMessage = new MySubscriberMessage(subscribers);

    String result = mySubscriberMessage.toString();

    assertThat(result, is("Href Value,Second Href"));
  }

}

