package com.manheim.ods.compx.builder;

import com.manheim.ods.compx.model.eventer.BaseEvent;

public class BaseEventBuilder {

	private String href = "http://some.href";
	private String eventType = "eventType";

	public BaseEvent build() {
		BaseEvent event = new BaseEvent(false, href, eventType);
		event.setHref(href);
		event.setEventType(eventType);
		return event;
	}

	public BaseEventBuilder withHref(String href) {
		this.href = href;
		return this;
	}

	public BaseEventBuilder withEventType(String eventType) {
		this.eventType = eventType;
		return this;
	}

}
