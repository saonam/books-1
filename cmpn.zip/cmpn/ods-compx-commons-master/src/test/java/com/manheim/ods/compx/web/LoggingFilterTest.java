package com.manheim.ods.compx.web;


import static org.mockito.Mockito.verify;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockFilterChain;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.web.context.support.HttpRequestHandlerServlet;

import com.manheim.ods.compx.util.LogWrapper;

@RunWith(MockitoJUnitRunner.class)
public class LoggingFilterTest {

  @Mock
  private LogWrapper logger;

  @InjectMocks
  private LoggingFilter loggingFilter = new LoggingFilter(logger);


  private MockHttpServletRequest httpServletRequest;

  private MockHttpServletResponse httpServletResponse;

  private MockFilterChain filterChain;

  @Before
  public void setUp() throws Exception {

    httpServletRequest = new MockHttpServletRequest("GET", "http://localhost:8080/test");
    httpServletRequest.addHeader("Accept", "application/json");
    httpServletRequest.addParameter("param1", "1000");
    httpServletRequest.setContent("Test request body".getBytes());
    httpServletRequest.setContentType(MediaType.TEXT_PLAIN_VALUE);

    httpServletResponse = new MockHttpServletResponse();
    httpServletResponse.setContentType(MediaType.TEXT_PLAIN_VALUE);

    filterChain = new MockFilterChain(new HttpRequestHandlerServlet(), new TestFilter());
  }

  @Test
  public void testDoFilter_Full() throws Exception {


    loggingFilter.doFilter(httpServletRequest, httpServletResponse, filterChain);
    verify(logger).debug(LoggingFilter.class, "Clearing MDC before request");
    verify(logger).debug(LoggingFilter.class, "Clearing MDC after request");

  }

  private class TestFilter implements Filter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
        throws IOException, ServletException {
      response.getOutputStream().write("Test response body".getBytes());
    }

    @Override
    public void destroy() {}
  }
}
