package com.manheim.ods.compx.setup;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.core.Is.is;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;

import org.apache.activemq.command.ActiveMQMessage;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.jms.core.MessagePostProcessor;

import com.manheim.ods.compx.builder.BaseEventBuilder;
import com.manheim.ods.compx.model.eventer.BaseEvent;
import com.manheim.ods.compx.util.LogWrapper;

public class QueueMessageBuilderTest {

	private JsonBuilder jsonBuilder;
	private QueueMessageBuilder messageBuilder;
	private Message message;
	private BaseEvent event;
	public static final String EVENT_TYPE = "some type";
	public static final String EVENT_HREF = "some href";
	public static final String SOURCE_KEY = "EBIZ";
	public static final String UNIQUE_ID = "1234";
	public static final String AUCTION = "AUCTION";
	public static final String SBLU = "SBLU";
	private String someJsonString = null;
	private Map<String, String> eventHeaders;
	private LogWrapper logWrapper;

	@Before
	public void setUp() throws Exception {
		logWrapper = mock(LogWrapper.class);
		jsonBuilder = mock(JsonBuilder.class);
		messageBuilder = new QueueMessageBuilder(jsonBuilder, logWrapper);
		message = mock(Message.class);
		eventHeaders = new HashMap<String, String>();
		eventHeaders.put("uniqueid", "1234");
		eventHeaders.put("origintimestamp", "2017-04-17 14:22:30.555");
		eventHeaders.put("JMSXGroupID", "AUCTION:SBLU");
		someJsonString = new JSONObject().put("key", "value").toString();
		event = new BaseEventBuilder().withHref(EVENT_HREF).withEventType(EVENT_TYPE).build();
	}

	@Test
	public void shouldGenerateXMLWithHrefTypeAndResponseAttributes() throws Exception {
		QueueMessageBuilder messageBuilder = new QueueMessageBuilder(new JsonBuilder(mock(EventerValues.class)),
				logWrapper);

		String result = messageBuilder.messageXML(someJsonString, event);
		Assert.assertTrue(result.startsWith(String.format("<queueMessage><apiResponse><key>value</key></apiResponse>")));
		Assert.assertTrue(result.endsWith(String.format("</queueMessage>")));
		Assert.assertFalse(result.contains(String.format("<error><errorCode>404</errorCode></error>")));
		Assert.assertTrue(result.contains(String.format("<event>")));
		Assert.assertTrue(result.contains(String.format("</event>")));
		Assert.assertTrue(result.contains(String.format("<eventType>%s</eventType>", EVENT_TYPE)));
		Assert.assertTrue(result.contains(String.format("<eventHref>%s</eventHref>", EVENT_HREF)));
		Assert.assertTrue(result.contains(String.format("<href>%s</href>", EVENT_HREF)));
	}

	@Test
	public void shouldGenerateXMLWithHrefTypeAndResponseAttributesWhenErrorResponseCodeIsGiven() throws Exception {
		QueueMessageBuilder messageBuilder = new QueueMessageBuilder(new JsonBuilder(mock(EventerValues.class)),
				logWrapper);

		String result = messageBuilder.messageXML(someJsonString, 404, event);
		Assert.assertTrue(result.startsWith(String.format("<queueMessage><apiResponse><key>value</key></apiResponse>")));
		Assert.assertTrue(result.endsWith(String.format("</queueMessage>")));
		Assert.assertTrue(result.contains(String.format("<error><errorCode>404</errorCode></error>")));
		Assert.assertTrue(result.contains(String.format("<event>")));
		Assert.assertTrue(result.contains(String.format("</event>")));
		Assert.assertTrue(result.contains(String.format("<eventType>%s</eventType>", EVENT_TYPE)));
		Assert.assertTrue(result.contains(String.format("<eventHref>%s</eventHref>", EVENT_HREF)));
		Assert.assertTrue(result.contains(String.format("<href>%s</href>", EVENT_HREF)));
	}

	@Test
	public void shouldUseJsonBuilderToGenerateXML() throws JSONException {
		messageBuilder.messageXML(someJsonString, event);

		ArgumentCaptor<JSONObject> argumentCaptor1 = ArgumentCaptor.forClass(JSONObject.class);
		ArgumentCaptor<BaseEvent> argumentCaptor2 = ArgumentCaptor.forClass(BaseEvent.class);
		verify(jsonBuilder).buildQueueJson(argumentCaptor1.capture(), argumentCaptor2.capture());
		JSONObject apiResponse = argumentCaptor1.getValue();
		Assert.assertThat(apiResponse.toString(), is(someJsonString));
		BaseEvent event = argumentCaptor2.getValue();
		Assert.assertThat(event.getHref(), is(EVENT_HREF));
		Assert.assertThat(event.getEventType(), is(EVENT_TYPE));
	}

	@Test
	public void shouldUseJsonBuilderToGenerateXMLWhenGivenResponseCode() throws JSONException {
		messageBuilder.messageXML(someJsonString, 404, event);

		ArgumentCaptor<JSONObject> argumentCaptor1 = ArgumentCaptor.forClass(JSONObject.class);
		ArgumentCaptor<BaseEvent> argumentCaptor2 = ArgumentCaptor.forClass(BaseEvent.class);
		verify(jsonBuilder).buildQueueJson(argumentCaptor1.capture(), eq(404), argumentCaptor2.capture());
		JSONObject apiResponse = argumentCaptor1.getValue();
		Assert.assertThat(apiResponse.toString(), is(someJsonString));
		BaseEvent event = argumentCaptor2.getValue();
		Assert.assertThat(event.getHref(), is(EVENT_HREF));
		Assert.assertThat(event.getEventType(), is(EVENT_TYPE));
	}

	@Test
	public void shouldReturnMessagePostProcessorClassWithDefinedMethod() throws JMSException {
		MessagePostProcessor messagePostProcessor = messageBuilder.messageProperties("AUCTION", event, eventHeaders,
				Timestamp.valueOf("2017-04-06 10:30:00"), Timestamp.valueOf("2017-04-06 10:30:01.055"));

		Assert.assertThat(messagePostProcessor.postProcessMessage(message), instanceOf(Message.class));
	}

	@Test
	public void shouldReturnMessageWithEventTypeAsAProperty() throws JMSException {
		MessagePostProcessor messagePostProcessor = messageBuilder.messageProperties("AUCTION", event, eventHeaders,
				Timestamp.valueOf("2017-04-06 10:30:00"), Timestamp.valueOf("2017-04-06 10:30:01.055"));
		messagePostProcessor.postProcessMessage(message);

		verify(message).setStringProperty("EventType", EVENT_TYPE);
	}

	@Test
	public void shouldReturnMessageWithSourceFromHeaderWhenNotEmpty() throws JMSException {
		event = new BaseEventBuilder().withHref("").build();
		String sourceKey = "HEART_BEAT";
		eventHeaders.put("source", sourceKey);
		MessagePostProcessor messagePostProcessor = messageBuilder.messageProperties("AUCTION", event, eventHeaders,
				Timestamp.valueOf("2017-04-06 10:30:00"), Timestamp.valueOf("2017-04-06 10:30:01.055"));
		messagePostProcessor.postProcessMessage(message);

		verify(message).setStringProperty("Source", sourceKey);

	}

	@Test
	public void shouldReturnMessageWithUniqueIdAsAProperty() throws JMSException {
		MessagePostProcessor messagePostProcessor = messageBuilder.messageProperties("AUCTION", event, eventHeaders,
				Timestamp.valueOf("2017-04-06 10:30:00"), Timestamp.valueOf("2017-04-06 10:30:01.055"));
		messagePostProcessor.postProcessMessage(message);

		verify(message).setStringProperty("uniqueId", UNIQUE_ID);
	}

	@Test
	public void shouldReturnMessageWithSourceAsDQSWATWhenHrefIsEmpty() throws JMSException {
		event = new BaseEventBuilder().withHref("").build();
		MessagePostProcessor messagePostProcessor = messageBuilder.messageProperties("AUCTION", event, eventHeaders,
				Timestamp.valueOf("2017-04-06 10:30:00"), Timestamp.valueOf("2017-04-06 10:30:01.055"));
		messagePostProcessor.postProcessMessage(message);

		verify(message).setStringProperty("Source", "DQSWAT");

	}

	@Test
	public void shouldLogMessageProperties() throws JMSException {
		MessagePostProcessor messagePostProcessor = messageBuilder.messageProperties("AUCTION", event, eventHeaders,
				Timestamp.valueOf("2017-04-06 10:30:00"), Timestamp.valueOf("2017-04-06 10:30:01.055"));

		messagePostProcessor.postProcessMessage(new ActiveMQMessage());
		verify(logWrapper).info(QueueMessageBuilder.class, "JMS Properties: {Auction: AUCTION"
				+ ", Source: N/A, EventType: " + event.getEventType()
				+ ", uniqueId: 1234, originTimestamp: 2017-04-17 14:22:30.555, apiRequestTimestamp: 2017-04-06 10:30:00.000, apiResponseTimestamp: 2017-04-06 10:30:01.055, JMSXGroupID: AUCTION:SBLU}");
	}
}
