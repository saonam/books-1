package com.manheim.ods.compx.helper;



import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateUtilsTest {
  Logger logger = LoggerFactory.getLogger(this.getClass());

  @Test
  public void testToTimestamp() throws ParseException {
    String timestampstr = "2017-10-12T12:11:42.282456565";
    LoggerFactory.getLogger(this.getClass()).info("testtime - Input: {}", timestampstr);
    Timestamp timestamp = DateUtils.toTimestamp(timestampstr);
    LoggerFactory.getLogger(this.getClass()).info("testtime - Output: {}", timestamp);
    assertNotNull(timestamp);
  }

  @Test
  public void testToTimestampWithNullValue() throws ParseException {
    String timestampstr = null;
    logger.info("testtime - Input: {}", timestampstr);
    Timestamp timestamp = DateUtils.toTimestamp(timestampstr);
    logger.info("testtime - Output: {}", timestamp);
    assertNull(timestamp);
  }

  @Test
  public void testToDateWithNullValue() throws ParseException {
    String datestr = null;
    logger.info("testtime - Input: {}", datestr);
    Date date = DateUtils.toDate(datestr, "fieldname");
    logger.info("testtime - Output: {}", date);
    assertNull(date);
  }


  @Test
  public void testToTimestampWithMsPrecision() throws ParseException {
    String timestampstr = "2017-11-07T19:10:03.212Z";
    logger.info("testothertime - Input: {}", timestampstr);
    Timestamp timestamp = DateUtils.toTimestampWithMsPrecision(timestampstr);
    logger.info("testothertime - Output: {}", timestamp);
    assertNotNull(timestamp);
  }

  @Test
  public void testNullToTimestampWithMsPrecision() throws ParseException {
    String timestampstr = null;
    logger.info("testothertime - Input: {}", timestampstr);
    Timestamp timestamp = DateUtils.toTimestampWithMsPrecision(timestampstr);
    logger.info("testothertime - Output: {}", timestamp);
    assertNull(timestamp);
  }

  @Test
  public void testCurrentTimestampString() {
    String currentSystemTimestampInString = DateUtils.getCurrentSystemTimestampInString();
    logger.info("testCurrentSystemTimestampString - {}", currentSystemTimestampInString);

    assertNotNull(currentSystemTimestampInString);
  }


  @Test
  public void testCurrentSystemTimestamp() {
    Timestamp currentSystemTimestamp = DateUtils.getCurrentSystemTimestamp();
    logger.info("testCurrentSystemTimestamp - {}", currentSystemTimestamp);

    assertNotNull(currentSystemTimestamp);
  }

  @Test
  public void testGetTimestampInString() throws ParseException {
    String timestampstr = "2017-11-07T19:10:03.212Z";
    logger.info("testGetTimestampInString - Input: {}", timestampstr);
    String nanoSecondsTimestampString = DateUtils.toNanosTimestampString(timestampstr);
    logger.info("testGetTimestampInString - Output: {}", nanoSecondsTimestampString);
    assertNotNull(nanoSecondsTimestampString);
  }


  @Test
  public void testToDate() throws ParseException {
    String timestampstr = "2017-10-12";
    logger.info("testToDate - Input: {}", timestampstr);
    Date date = DateUtils.toDate(timestampstr, "fieldname");
    logger.info("testToDate - Output: {}", date);
    assertNotNull(date);
  }

  @Test
  public void testToDateWithInvalidInput() {
    String datestr = "102017-12";
    logger.info("testToDate - Input: {}", datestr);
    Date date;
    try {
      date = DateUtils.toDate(datestr, "fieldname");
    } catch (ParseException e) {
      assert (true);
      return;
    }
    assert (false);
  }

  @Test
  public void testTimeDifferenceFromEpoch() {
    Date recordArrivalDate = Date.from(Instant.EPOCH);
    long timediff = DateUtils.timeDifferenceFromNow(recordArrivalDate);
    logger.info("Time Difference from Epoch(1970-01-01T00:00:00Z): {}", timediff);

    assert (true);
  }


  @Test
  public void testDaysDifferenceFromNow() throws ParseException {
    SimpleDateFormat myFormat = new SimpleDateFormat("MM/dd/yyyy");
    Date recordArrivalDate = myFormat.parse("02/25/2018");
    long daysdiff = DateUtils.daysDifferenceFromNow(recordArrivalDate);
    logger.info("Time Difference from {}: {}", recordArrivalDate, daysdiff);

    assert (true);
  }

  @Test
  public void testMillis() {
    // Timestamp ts = new Timestamp(1521656699261L);
    Timestamp ts = new Timestamp(1522076546660L); // 2018-02-21T18:02:35.299
    SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
  }

  @Test
  public void testToTimestampWithSecondsPrecision() throws ParseException {
    String timestampstr = "2017-10-12T12:25:22";
    logger.info("testToDate - Input: {}", timestampstr);
    Timestamp timestamp = DateUtils.toTimestampWithSecondsPrecision(timestampstr);
    logger.info("testToTimestampWithSecondsPrecision - Output: {}", timestamp);
    assertNotNull(timestamp);
  }


  @Test
  public void testToTimestampWithSecondsPrecisionWithEmptyTs() throws ParseException {
    String timestampstr = "";
    logger.info("testToDate - Input: {}", timestampstr);
    Timestamp timestamp = DateUtils.toTimestampWithSecondsPrecision(timestampstr);
    logger.info("testToTimestampWithSecondsPrecision - Output: {}", timestamp);
    assertNull(timestamp);
  }

  @Test
  public void testFromSecondsToNanosPrecision() throws ParseException {
    String timestampstr = "2017-10-12T12:25:22";
    logger.info("testToDate - Input: {}", timestampstr);
    String timestampInNanos = DateUtils.fromSecondsToNanosTimestampString(timestampstr);
    logger.info("testFromSecondsToNanosPrecision - Output: {}", timestampInNanos);
    assertNotNull(timestampInNanos);
  }

  @Test
  /**
   * @param strEventTimestamp - 2018-04-25T19:40:58
   * @param dateformat - yyyy-MM-dd'T'HH24:mm:ss
   * @param timezone - America/New_York
   * @return Time in EST
   * 
   *         Convert given time in local timezone to EST
   */

  public void testTimezoneConversionGMTToPST() {
    String input = "2018-04-26T02:01:00";
    String inputFormat = "yyyy-MM-dd'T'HH:mm:ss";

    String outputTimezone = "America/Los_Angeles";
    String inputTimezone = "GMT";

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(inputFormat);
    LocalDateTime inputLocalTime = LocalDateTime.parse(input, formatter);

    String output = DateUtils.convertToTimezone(input, inputFormat, inputTimezone, outputTimezone);
    LocalDateTime outputLocalTime = LocalDateTime.parse(output, formatter);

    long hours = Duration.between(outputLocalTime, inputLocalTime).getSeconds() / 60 / 60;

    logger.info("Input Time - {}, Output in {} - {}. Time difference {} hours", inputLocalTime,
        outputTimezone, outputLocalTime, hours);

    assertEquals(7, hours);
  }

  @Test
  public void testTimezoneConversionGMTToCST() {
    String input = "2018-04-26T02:01:00";
    String inputFormat = "yyyy-MM-dd'T'HH:mm:ss";

    String inputTimezone = "GMT";
    String outputTimezone = "America/Chicago";

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(inputFormat);
    LocalDateTime inputLocalTime = LocalDateTime.parse(input, formatter);

    String output = DateUtils.convertToTimezone(input, inputFormat, inputTimezone, outputTimezone);
    LocalDateTime outputLocalTime = LocalDateTime.parse(output, formatter);

    long hours = Duration.between(outputLocalTime, inputLocalTime).getSeconds() / 60 / 60;

    logger.info("Input Time - {}, Output in {} - {}. Time difference {} hours", inputLocalTime,
        outputTimezone, outputLocalTime, hours);

    assertEquals(5, hours);
  }

  @Test
  public void testTimezoneConversionGMTToEST() {
    String input = "2018-04-26T02:01:00";
    String inputFormat = "yyyy-MM-dd'T'HH:mm:ss";

    String inputTimezone = "GMT";
    String outputTimezone = "America/New_York";

    DateTimeFormatter formatter = DateTimeFormatter.ofPattern(inputFormat);
    LocalDateTime inputLocalTime = LocalDateTime.parse(input, formatter);

    String output = DateUtils.convertToTimezone(input, inputFormat, inputTimezone, outputTimezone);
    LocalDateTime outputLocalTime = LocalDateTime.parse(output, formatter);

    long hours = Duration.between(outputLocalTime, inputLocalTime).getSeconds() / 60 / 60;

    logger.info("Input Time - {}, Output in {} - {}. Time difference {} hours", inputLocalTime,
        outputTimezone, outputLocalTime, hours);

    assertEquals(4, hours);
  }

}
