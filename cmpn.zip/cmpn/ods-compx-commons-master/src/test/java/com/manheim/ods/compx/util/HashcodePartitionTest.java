package com.manheim.ods.compx.util;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.manheim.ods.compx.util.MessageGroupUtil;

public class HashcodePartitionTest {

  String[] vehicleList;
  Logger log = LoggerFactory.getLogger(this.getClass());

  MessageGroupUtil messageGroupUtil;

  List<String> allMessageGroups;

  final static int numberOfGroups = 5;

  @Before
  public void setup() {
    vehicleList = new String[] {"QLM1:4688600", "QLM1:4688599", "QLM1:4688598", "QLM1:4688601",
        "QLM1:4688595", "QLM1:4688594", "QLM1:4688600", "QLM1:4688599", "QLM1:4588600",
        "QLM1:4488599","xQMM1000000000000009380551"};
    messageGroupUtil = new MessageGroupUtil(numberOfGroups);
    allMessageGroups = messageGroupUtil.allMessageGroups();
  }

  @Test
  public void testWithAListOfPartitionKeys() {

    for (String vehicleKey : vehicleList) {
      String group = messageGroupUtil.group(vehicleKey);
      log.debug("{} for vehicle {} ", group, vehicleKey);

      assertTrue(allMessageGroups.contains(group));
    }
  }
  

  @Test
  public void testWithNullPartitionKey() {

      String group = messageGroupUtil.group(null);

      assertTrue(allMessageGroups.contains(group));
  }

}
