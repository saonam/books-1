package com.manheim.ods.compx.exception;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import com.manheim.ods.stream.consumer.WorkerAlreadyRunningException;

public class WorkerAlreadyRunningExceptionTest {

  @Test
  public void test() {
    WorkerAlreadyRunningException workerAlreadyRunningException =
        new WorkerAlreadyRunningException("Worker already running !!");

    assertThat(workerAlreadyRunningException.getMessage(), is("Worker already running !!"));
  }

}
