package com.manheim.ods.stream.controller;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.mockito.stubbing.Answer;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;
import com.manheim.ods.stream.consumer.KinesisReceiver;
import com.manheim.ods.stream.consumer.KinesisRecordProcessorFactory;
import com.manheim.ods.stream.consumer.KinesisWorkerFactory;
import com.manheim.ods.stream.controller.StreamReceiverController;

@RunWith(MockitoJUnitRunner.class)
public class StreamReceiverControllerTest {

  private KinesisReceiver kinesisReceiver;
  @Mock
  private KinesisWorkerFactory kinesisWorkerFactory;
  @Mock
  private KinesisRecordProcessorFactory kinesisRecordProcessorFactory;
  @Mock
  private KinesisClientLibConfiguration kinesisClientLibConfiguration;
  @Mock
  private Worker worker;

  private StreamReceiverController streamReceiverController;

  @Before
  public void setUp() throws Exception {
    when(kinesisWorkerFactory.newWorker()).thenReturn(worker);
    kinesisReceiver = new KinesisReceiver(kinesisWorkerFactory, kinesisRecordProcessorFactory,
        kinesisClientLibConfiguration, worker);
    doAnswer((Answer) invocation -> {
      return null;
    }).when(worker).run();
    when(worker.getApplicationName()).thenReturn("TEST_APPLICATION");
    streamReceiverController = new StreamReceiverController(kinesisReceiver);
  }

  @Test
  public void testRun() {
    ResponseEntity responseEntity = streamReceiverController.start();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

  @Test
  public void testStop() {
    ResponseEntity responseEntity = streamReceiverController.stop();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

  @Test
  public void testRestart() {
    ResponseEntity responseEntity = streamReceiverController.restart();
    assertEquals(HttpStatus.OK, responseEntity.getStatusCode());
  }

  @Test
  public void testStartWhenAlreadyRunning() {
    streamReceiverController.start();
    ResponseEntity responseEntity = streamReceiverController.start();
    assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
  }
}
