package com.manheim.ods.compx.exception;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import org.junit.Test;

public class UnsuccessfulClientExecutionExceptionTest {

  @Test
  public void shouldProduceAMessageWithAnErrorCodeAndAClient() {
    UnsuccessfulClientExecutionException exception =
        new UnsuccessfulClientExecutionException("Some Client", 404);

    assertThat(exception.getMessage(), is("HTTP Error 404 while executing Some Client."));
    assertThat(exception.getErrorCode().intValue(), is(404));
  }
}
