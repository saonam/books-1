package com.manheim.ods.compx.util;

import static org.mockito.Mockito.mock;

import org.junit.Before;
import org.junit.Test;

public class MetricReporterTest {

  MetricReporter metricReporter;
  LogWrapper logWrapper;
  private static final String AUCTION_CODE_LABEL = "auctionCode:";
  private static final String EVENT_TYPE_LABEL = "eventType:";
  private static final String VIN_LABEL = "vin:";

  final static String EVENT_TYPE = "TEST_EVENT_TYPE";
  final static String AUCTION_CODE = "TEST_AUCTION_CODE";
  final static String VIN = "TEST_VIN";


  String eventTypeTag;
  String auctionCodeTag;
  String vinTag;

  @Before
  public void setup() {
    logWrapper = mock(LogWrapper.class);
    metricReporter = new MetricReporter("127.0.0.1", logWrapper);
    eventTypeTag = String.format("%s %s", EVENT_TYPE_LABEL, EVENT_TYPE);
    auctionCodeTag = String.format("%s %s", AUCTION_CODE_LABEL, AUCTION_CODE);
    vinTag = String.format("%s %s", VIN_LABEL, VIN);
  }

  @Test
  public void testRecordExternalCallTimeDoubleStringArray() {
    metricReporter.recordExternalCallTime(1234, eventTypeTag, vinTag, auctionCodeTag);
    assert (true);
  }

  @Test
  public void testRecordExternalCallTimeLongStringArray() {
    metricReporter.recordExternalCallTime(1234L, eventTypeTag, vinTag, auctionCodeTag);
    assert (true);
  }

  @Test
  public void testIncrementHeartbeatReceived() {
    metricReporter.incrementHeartbeatReceived(eventTypeTag, vinTag, auctionCodeTag);
    assert (true);
  }

  @Test
  public void testIncrementHeartbeatProcessed() {
    metricReporter.incrementHeartbeatProcessed(eventTypeTag, vinTag, auctionCodeTag);
    assert (true);
  }

  @Test
  public void testIncrementEventReceived() {
    metricReporter.incrementEventReceived(eventTypeTag, vinTag, auctionCodeTag);
    assert (true);

  }

  @Test
  public void testIncrementEventProcessed() {
    metricReporter.incrementEventProcessed(eventTypeTag, vinTag, auctionCodeTag);
    assert (true);
  }

  @Test
  public void testIncrementEventFailed() {
    metricReporter.incrementEventFailed(eventTypeTag, vinTag, auctionCodeTag);
    assert (true);

  }

  @Test
  public void testIncrementEventResourceNotFound() {
    metricReporter.incrementEventResourceNotFound(eventTypeTag, vinTag, auctionCodeTag);
    assert (true);

  }

  @Test
  public void testIncrementEventError() {
    metricReporter.incrementEventError(eventTypeTag, vinTag, auctionCodeTag);
    assert (true);
  }

  @Test
  public void testRecordLatency() {
    metricReporter.recordLatency(1515771076750L, eventTypeTag, vinTag, auctionCodeTag);
    assert (true);
  }

}
