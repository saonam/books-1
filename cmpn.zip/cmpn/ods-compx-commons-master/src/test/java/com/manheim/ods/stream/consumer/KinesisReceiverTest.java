package com.manheim.ods.stream.consumer;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doAnswer;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.slf4j.LoggerFactory;

import com.amazonaws.services.kinesis.clientlibrary.lib.worker.KinesisClientLibConfiguration;
import com.amazonaws.services.kinesis.clientlibrary.lib.worker.Worker;
import com.manheim.ods.stream.consumer.KinesisReceiver;
import com.manheim.ods.stream.consumer.KinesisRecordProcessorFactory;
import com.manheim.ods.stream.consumer.KinesisWorkerFactory;
import com.manheim.ods.stream.consumer.WorkerAlreadyRunningException;

import ch.qos.logback.classic.Level;
import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.Appender;

public class KinesisReceiverTest {



  KinesisReceiver kinesisReceiver;
  // Captor is genericised with ch.qos.logback.classic.spi.LoggingEvent
  @Captor
  private ArgumentCaptor<LoggingEvent> captorLoggingEvent;
  Appender mockedAppender;

  @Mock
  KinesisRecordProcessorFactory recordProcessorFactory;
  @Mock
  KinesisClientLibConfiguration kinesisClientLibConfiguration;

  @Before
  public void setup() {

    Worker worker = mock(Worker.class);
    KinesisWorkerFactory kinesisWorkerFactory = mock(KinesisWorkerFactory.class);
    doAnswer(new Answer<Boolean>() {
      @Override
      public Boolean answer(InvocationOnMock invocation) throws Throwable {
        return true;
      }
    }).when(worker).run();
    when(worker.getApplicationName()).thenReturn("compx-charges");
    when(kinesisWorkerFactory.newWorker()).thenReturn(worker);
    kinesisReceiver = new KinesisReceiver(kinesisWorkerFactory, recordProcessorFactory,
        kinesisClientLibConfiguration, worker);
    final Logger logger = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
    mockedAppender = Mockito.mock(Appender.class);
    logger.addAppender(mockedAppender);
  }

  @After
  public void teardown() {
    final Logger logger = (Logger) LoggerFactory.getLogger(Logger.ROOT_LOGGER_NAME);
    logger.detachAppender(mockedAppender);
  }


  @Test
  public void testStart() throws WorkerAlreadyRunningException {
    kinesisReceiver.start();
    // Now verify our logging interactions
    ArgumentCaptor<Appender> argumentCaptor = ArgumentCaptor.forClass(Appender.class);
    verify(mockedAppender).doAppend(argumentCaptor.capture());
    // Having a genricised captor means we don't need to cast
    final LoggingEvent loggingEvent = (LoggingEvent) argumentCaptor.getAllValues().get(0);
    // Check log level is correct
    assertThat(loggingEvent.getLevel(), is(Level.INFO));
    // Check the message being logged is correct
    assertThat(loggingEvent.getFormattedMessage(), is("Start worker compx-charges"));

  }

  @Test
  public void testDuplicateStart() throws WorkerAlreadyRunningException {
    kinesisReceiver.start();
    try {
      kinesisReceiver.start();
    } catch (WorkerAlreadyRunningException wex) {
      assert (true);
    }
    // Now verify our logging interactions
    ArgumentCaptor<Appender> argumentCaptor = ArgumentCaptor.forClass(Appender.class);
    verify(mockedAppender).doAppend(argumentCaptor.capture());
    // Having a genricised captor means we don't need to cast
    final LoggingEvent loggingEvent = (LoggingEvent) argumentCaptor.getAllValues().get(0);
    // Check log level is correct
    assertThat(loggingEvent.getLevel(), is(Level.INFO));
    // Check the message being logged is correct
    assertThat(loggingEvent.getFormattedMessage(), is("Start worker compx-charges"));

  }


  @Test
  public void restart() throws WorkerAlreadyRunningException {
    kinesisReceiver.restart();
    // Now verify our logging interactions
    ArgumentCaptor<Appender> argumentCaptor = ArgumentCaptor.forClass(Appender.class);
    verify(mockedAppender, times(2)).doAppend(argumentCaptor.capture());
    // Having a genricised captor means we don't need to cast
    final LoggingEvent loggingEvent1 = (LoggingEvent) argumentCaptor.getAllValues().get(0);
    final LoggingEvent loggingEvent2 = (LoggingEvent) argumentCaptor.getAllValues().get(1);
    // Check log level is correct
    assertThat(loggingEvent1.getLevel(), is(Level.INFO));
    // Check the message being logged is correct
    assertThat(loggingEvent1.getFormattedMessage(), is("Shutdown worker compx-charges"));
    assertThat(loggingEvent2.getFormattedMessage(), is("Start worker compx-charges"));

  }

  @Test
  public void shutdown() {
    kinesisReceiver.shutdown();
    // Now verify our logging interactions
    ArgumentCaptor<Appender> argumentCaptor = ArgumentCaptor.forClass(Appender.class);
    verify(mockedAppender).doAppend(argumentCaptor.capture());
    // Having a genricised captor means we don't need to cast
    final LoggingEvent loggingEvent = (LoggingEvent) argumentCaptor.getAllValues().get(0);
    // Check log level is correct
    assertThat(loggingEvent.getLevel(), is(Level.INFO));
    // Check the message being logged is correct
    assertThat(loggingEvent.getFormattedMessage(), is("Shutdown worker compx-charges"));

  }

}
