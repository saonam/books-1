package com.manheim.ods.compx.setup;

import static org.mockito.Matchers.anyString;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.RETURNS_DEEP_STUBS;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.client.CreateSubscriberClient;
import com.manheim.ods.compx.client.CreateSubscriptionClient;
import com.manheim.ods.compx.client.GetSubscriberClient;
import com.manheim.ods.compx.client.MasheryClient;
import com.manheim.ods.compx.exception.EventerSubscriptionException;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.model.eventer.EventerSubscriber;
import com.manheim.ods.compx.model.eventer.MySubscriberMessage;
import com.manheim.ods.compx.service.MailService;
import com.manheim.ods.compx.util.LogWrapper;


public class EventerManagerTest {

  private static final String SUBJECT = "Failed To Call Eventer";
  private static final String EMAIL_WARNING = "Failed to call Eventer when creating a subscription";

  private EventerManager eventerManager;
  private MasheryClient masheryClient;
  private CreateSubscriberClient createSubscriberClient;
  private final String[] messagePatterns = new String[] {"First Pattern", "Second Pattern"};
  private List<EventerSubscriber> subscribers;
  private EventerSubscriber eventerSubscriber;
  private MailService mailService;
  private MySubscriberMessage mySubscriberMessage;
  private String accessToken;
  private String location;
  private GetSubscriberClient getSubscriberClient;
  private CreateSubscriptionClient createSubscriptionClient;
  private LogWrapper logger;
  private EventerSubscriptionException eventerSubscriptionException;

  @Before
  public void setUp() throws Exception {
    masheryClient = mock(MasheryClient.class);
    createSubscriberClient = mock(CreateSubscriberClient.class);
    getSubscriberClient = mock(GetSubscriberClient.class);
    createSubscriptionClient = mock(CreateSubscriptionClient.class);
    mailService = mock(MailService.class);
    mySubscriberMessage = mock(MySubscriberMessage.class, RETURNS_DEEP_STUBS);
    accessToken = "Secret Token";
    location = "href value";
    logger = mock(LogWrapper.class);

    eventerSubscriber = new EventerSubscriber("href value");

    when(mySubscriberMessage.getSubscribers().size()).thenReturn(1);
    when(mySubscriberMessage.getSubscribers().get(0).getHref()).thenReturn("An Href");

    when(masheryClient.fetchAccessToken()).thenReturn(accessToken);
    when(getSubscriberClient.getEventerSubscribers(accessToken)).thenReturn(mySubscriberMessage);

    eventerManager = new EventerManager(masheryClient, createSubscriberClient, getSubscriberClient,
        createSubscriptionClient, messagePatterns, mailService, logger);
    subscribers = new ArrayList<>();
  }

  //////////////// MASHERY //////////////////////

  @Test
  public void shouldGetMasheryAccessTokenInSetup()
      throws IOException, EventerSubscriptionException {
    stubCurrentSubscriberWithSubscribers();

    eventerManager.setUp();
    verify(masheryClient).fetchAccessToken();
  }

  @Test(expected = NullPointerException.class)
  public void shouldNotCreateSubscribersOrSubscriptionIfNoAccessToken()
      throws IOException, EventerSubscriptionException {
    when(masheryClient.fetchAccessToken()).thenReturn(null);

    eventerManager.setUp();
  }

  //////////////// SUBSCRIBERS //////////////////////

  @Test
  public void shouldCatchUnsuccessfulExecutionExceptionWhenRetrievingSubscribersFails()
      throws IOException, EventerSubscriptionException {
    UnsuccessfulClientExecutionException exception =
        mock(UnsuccessfulClientExecutionException.class);
    when(getSubscriberClient.getEventerSubscribers(accessToken)).thenThrow(exception);
    when(exception.getMessage()).thenReturn("Error Message");

    eventerManager.setUp();

    verify(mailService).sendMessage(SUBJECT, EMAIL_WARNING);
    verify(logger).error(EventerManager.class, exception);
  }

  @Test
  public void shouldCreateSubscriberWhenThereAreNoSubscribersPresent() throws Exception {
    stubSubscriberCreationOnSecondAttempt();

    eventerManager.setUp();

    verify(createSubscriberClient).createSubscriber(accessToken);
  }

  @Test
  public void shouldNotCreateSubscriberWhenThereAreExistingSubscribers() throws Exception {
    stubCurrentSubscriberWithSubscribers();

    eventerManager.setUp();

    verify(createSubscriberClient, never()).createSubscriber(accessToken);
  }

  @Test
  public void shouldSendEmailWhenUnableToCreateASubscriber() throws Exception {
    stubCurrentSubscriberCallWithoutSubscribers();
    doThrow(mock(UnsuccessfulClientExecutionException.class)).when(createSubscriberClient)
        .createSubscriber(accessToken);

    eventerManager.setUp();

    verify(mailService).sendMessage(SUBJECT, EMAIL_WARNING);
  }

  //////////////// SUBSCRIPTION //////////////////////

  @Test
  public void shouldCreateSubscriptionWithFirstMessagePatter() throws Exception {
    stubCurrentSubscriberWithSubscribers();

    eventerManager.setUp();

    verify(createSubscriptionClient).createSubscription(accessToken, location, "First Pattern");
  }

  @Test
  public void shouldCreateSubscriptionWithSecondMessagePatter() throws Exception {
    stubCurrentSubscriberWithSubscribers();

    eventerManager.setUp();

    verify(createSubscriptionClient).createSubscription(accessToken, location, "Second Pattern");
  }

  @Test
  public void shouldCreateAllSubscriptionsIfHrefIsPresent() throws Exception {
    stubCurrentSubscriberWithSubscribers();

    eventerManager.setUp();

    verify(createSubscriptionClient, times(2)).createSubscription(eq(accessToken), eq(location),
        anyString());
  }

  @Test
  public void shouldNotCreateAnySubscriptionsIfHrefIsMissing() throws Exception {
    subscribers.add(new EventerSubscriber(null));
    stubCurrentSubscriberCallWithoutSubscribers();

    eventerManager.setUp();

    verify(createSubscriptionClient, never()).createSubscription(eq(accessToken), eq(location),
        anyString());
  }

  @Test
  public void shouldSendEmailWhenCallFailsToCreateSubscription() throws Exception {
    stubCurrentSubscriberWithSubscribers();
    doThrow(mock(UnsuccessfulClientExecutionException.class)).when(createSubscriptionClient)
        .createSubscription(eq(accessToken), eq(location), anyString());

    eventerManager.setUp();

    verify(mailService).sendMessage(SUBJECT, EMAIL_WARNING);
  }

  //////////////////

  private void stubCurrentSubscriberCallWithoutSubscribers()
      throws IOException, EventerSubscriptionException {
    MySubscriberMessage mySubscriberMessage = new MySubscriberMessage(subscribers);
    when(getSubscriberClient.getEventerSubscribers(accessToken)).thenReturn(mySubscriberMessage);
  }

  private void stubCurrentSubscriberWithSubscribers()
      throws IOException, EventerSubscriptionException {
    subscribers.add(eventerSubscriber);
    stubCurrentSubscriberCallWithoutSubscribers();
  }

  private void stubSubscriberCreationOnSecondAttempt()
      throws IOException, EventerSubscriptionException {
    MySubscriberMessage myEmptySubscriberMessage = new MySubscriberMessage(subscribers);
    List<EventerSubscriber> mySubscribers =
        Collections.singletonList(new EventerSubscriber("href"));
    MySubscriberMessage mySubscriberMessage = new MySubscriberMessage(mySubscribers);
    when(getSubscriberClient.getEventerSubscribers(accessToken))
        .thenReturn(myEmptySubscriberMessage).thenReturn(mySubscriberMessage);
  }

  @Test
  public void testSetup() throws IOException {
    when(masheryClient.fetchAccessToken()).thenThrow(IOException.class);
    try {
      eventerManager.setUp();
    } catch (EventerSubscriptionException e) {
      assert (true);
      return;
    }
    assert (false);
  }
}
