package com.manheim.ods.compx.model.eventer;

import static org.hamcrest.core.StringContains.containsString;
import static org.junit.Assert.assertThat;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;

public class AuctionEventTest {

  AuctionEvent auctionEvent;
  SimpleDateFormat dateFormat;
  Date parsedDate;
  Timestamp timestamp;

  @Before
  public void setup() {
    auctionEvent = new AuctionEvent();
    auctionEvent.setAuctionCode("QGM5");
    auctionEvent.setVin("2FMGK5CC7CA55B124");
    auctionEvent.setWorkOrder("1262767");
    auctionEvent.setSblu("3866393");
  }

  @Test
  public void shouldLogAnHeartbeatAuctionEvent() throws ParseException {

    dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
    parsedDate = dateFormat.parse("2017-08-29T16:33:10.202");
    timestamp = new java.sql.Timestamp(parsedDate.getTime());

    auctionEvent.setAuctionid("xQGM5");
    auctionEvent.setAuctionuniqueid("00000000000000949966");
    auctionEvent.setAuctioniduniqueid("xQGM5000000000000009499664");
    auctionEvent.setCdcjournaltimestamp("2017-09-19T20:50:00.571344000");
    auctionEvent.setHeartbeatseqno("27123286");
    auctionEvent.setTboxtimestamp("2017-09-19T20:50:00.571344000");
    auctionEvent.setChangestatus("U");
    auctionEvent.setEventType("MMR_HEARTBEAT");

    auctionEvent.setPrevBuyerDealerId("5098861");
    auctionEvent.setPrevSellerDealerId("4898790");
    assertThat(auctionEvent.toString(), containsString("vin=2FMGK5CC7CA55B124"));


  }
}
