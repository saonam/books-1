package com.manheim.ods.compx.service;

import com.manheim.ods.compx.client.Client;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.setup.EventerValues;
import com.manheim.ods.compx.util.Sleeper;
import okhttp3.ResponseBody;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InOrder;
import retrofit2.Call;
import retrofit2.Response;

import java.io.IOException;
import java.util.function.Consumer;

import static org.mockito.Mockito.*;

public class RetryTest {

    private EventerValues eventerValues;
    private Client client;
    private Sleeper sleeper;
    private Retry retry;
    private Call call;
    private Response errorResponse;
    private Response successfulResponse;
    private Consumer<Response> logMethod;

    @Before
    public void setUp() throws Exception {
        client = mock(Client.class);
        sleeper = mock(Sleeper.class);
        eventerValues = mock(EventerValues.class);
        retry = new Retry(client, eventerValues, sleeper);

        call = mock(Call.class);
        successfulResponse = Response.success("success");
        errorResponse = Response.error(403, mock(ResponseBody.class));
        logMethod = mock(Consumer.class);

        when(client.execute(call, this.getClass())).thenReturn(errorResponse).thenReturn(successfulResponse);
        when(call.clone()).thenReturn(call);
        when(eventerValues.getMaxRetryCount()).thenReturn(3);
    }

    @Test
    public void shouldCallExecuteWhenRetryingCall() throws Exception {
        retry.execute(call, logMethod, this);

        verify(client, times(2)).execute(call,this.getClass());
    }

    @Test
    public void shouldSleepBeforeExecuteRetryCall() throws Exception {
        InOrder inOrder = inOrder(client, sleeper, client);

        retry.execute(call, logMethod, this);

        inOrder.verify(client).execute(call, this.getClass());
        inOrder.verify(sleeper).sleep();
        inOrder.verify(client).execute(call, this.getClass());
    }

    @Test
    public void shouldRunLogMethodWhenRetryingCall() throws Exception {
        retry.execute(call, logMethod, this);

        verify(logMethod, atLeast(1)).accept(errorResponse);
    }

    @Test
    public void shouldRetryOneMoreTimeThanMaxRetryCount() throws Exception {
        int maxRetryCount = 1;
        when(eventerValues.getMaxRetryCount()).thenReturn(maxRetryCount);
        when(client.execute(call, this.getClass())).thenReturn(errorResponse);

        try {
            retry.execute(call,logMethod,this);
        } catch(UnsuccessfulClientExecutionException e) {}

        int actualRetryCount = maxRetryCount + 1;
        verify(client, times(actualRetryCount)).execute(call, this.getClass());
    }

    @Test
    public void shouldLogErrorWhenClientExecutionFails() throws IOException {
        when(client.execute(call, this.getClass())).thenReturn(errorResponse);

        try {
            retry.execute(call,logMethod,this);
        } catch (UnsuccessfulClientExecutionException e) {}

        verify(logMethod, times(4)).accept(errorResponse);
    }

    @Test(expected = UnsuccessfulClientExecutionException.class)
    public void shouldThrowUnsuccessfulClientExceptionWhenAllRetriesFail() throws IOException {
        when(client.execute(call, this.getClass())).thenReturn(errorResponse);

        retry.execute(call, logMethod, this);
    }

    @Test
    public void shouldCloneCallDuringRetry() throws Exception {
        retry.execute(call, logMethod, this);

        verify(call).clone();
    }
}