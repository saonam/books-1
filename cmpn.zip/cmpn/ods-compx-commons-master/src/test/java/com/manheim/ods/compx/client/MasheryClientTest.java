package com.manheim.ods.compx.client;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.api.MasheryAPI;
import com.manheim.ods.compx.exception.EventerSubscriptionException;
import com.manheim.ods.compx.exception.UnsuccessfulClientExecutionException;
import com.manheim.ods.compx.model.mashery.MasheryMessage;
import com.manheim.ods.compx.service.MailService;
import com.manheim.ods.compx.util.LogWrapper;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Response;

public class MasheryClientTest {

  private MasheryAPI masheryAPI;
  private MasheryClient manager;
  private Call call;
  private MasheryMessage masheryMessage;
  private Client client;
  private MailService mailService;
  private LogWrapper logger;

  @Before
  public void setUp() throws Exception {
    mailService = mock(MailService.class);
    masheryAPI = mock(MasheryAPI.class);
    call = mock(Call.class);
    client = mock(Client.class);
    logger = mock(LogWrapper.class);
    manager = new MasheryClient(masheryAPI, client, "authorization", mailService, logger);
    masheryMessage = mock(MasheryMessage.class);
    when(masheryAPI.configureMasheryCall(anyString())).thenReturn(call);
    when(client.execute(call, MasheryClient.class)).thenReturn(Response.success(masheryMessage));
    when(masheryMessage.getMasheryAccessToken()).thenReturn("secretToken");
  }

  @Test
  public void shouldExecuteClientWhenGettingAccessToken()
      throws IOException, EventerSubscriptionException {
    manager.fetchAccessToken();

    verify(client).execute(call, MasheryClient.class);
  }

  @Test
  public void shouldReturnAMasherMessageWhenClientExecuteIsSucessful() throws Exception {
    String responseString = manager.fetchAccessToken();

    assertThat(responseString, is("secretToken"));
  }

  @Test
  public void shouldGetAccessToken() throws IOException, EventerSubscriptionException {
    manager.fetchAccessToken();

    verify(masheryMessage).getMasheryAccessToken();
  }

  @Test
  public void shouldInvokeMasheryAPIWhenConfiguringMasheryCall()
      throws IOException, EventerSubscriptionException {
    manager.fetchAccessToken();

    verify(masheryAPI).configureMasheryCall("authorization");
  }

  @Test
  public void shouldAlertViaMailServiceWhenMasheryExecutionFails()
      throws IOException, EventerSubscriptionException {
    when(client.execute(call, MasheryClient.class))
        .thenReturn(Response.error(403, mock(ResponseBody.class)));

    try {
      manager.fetchAccessToken();
    } catch (UnsuccessfulClientExecutionException e) {
    }

    verify(mailService).sendMessage("Mashery call failed",
        "Mashery call failed while retrieving the mashery token.  Application is not registered with Eventer.");
  }

  @Test(expected = UnsuccessfulClientExecutionException.class)
  public void shouldThrowUnsuccessfulClientExecutionExceptionWhenExecutionFails()
      throws IOException, EventerSubscriptionException {
    when(client.execute(call, MasheryClient.class))
        .thenReturn(Response.error(403, mock(ResponseBody.class)));

    manager.fetchAccessToken();
  }

  @Test
  public void shouldLogInfoWhenExecutingMasheryCall()
      throws IOException, EventerSubscriptionException {
    manager.fetchAccessToken();

    verify(logger).info(MasheryClient.class, "Executing mashery request.");
  }

  @Test
  public void shouldLogInfoWhenSuccssfulExecutionOfMasheryClient()
      throws IOException, EventerSubscriptionException {
    manager.fetchAccessToken();

    verify(logger).info(MasheryClient.class, "Obtained access token!");
  }

  @Test
  public void shouldLogErrorWhenUnsuccessfulExecutionOfMasheryClient()
      throws IOException, EventerSubscriptionException {
    when(client.execute(call, MasheryClient.class))
        .thenReturn(Response.error(403, mock(ResponseBody.class)));

    try {
      manager.fetchAccessToken();
    } catch (UnsuccessfulClientExecutionException e) {
    }

    verify(logger).error(MasheryClient.class, "Unsuccessful Mashery API call with HTTP Error 403.");
  }
}
