package com.manheim.ods.compx.controller;

import static org.junit.Assert.assertThat;

import java.io.IOException;
import java.net.URISyntaxException;

import org.hamcrest.core.Is;
import org.junit.Test;

import com.manheim.ods.compx.controller.XSDController;
import com.manheim.ods.compx.helper.CompXFileReader;

public class XSDControllerTest {

	@Test
	public void shouldReturnXSDFile() throws IOException, URISyntaxException {
		XSDController xsdController = new XSDController();

		String result = xsdController.getSchema();

		assertThat(result, Is.is(new CompXFileReader().fetchFileAsString("xsd/schema1.xsd")));
	}
}