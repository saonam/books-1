package com.manheim.ods.compx.client;

import static org.hamcrest.core.IsNull.nullValue;
import static org.junit.Assert.assertThat;

import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.model.mashery.MasheryMessage;

public class MasheryMessageTest {

  MasheryMessage masheryMessage;

  @Before
  public void setUp() throws Exception {
    masheryMessage = new MasheryMessage();

  }

  @Test
  public void shouldReturnAMasherMessage() throws Exception {

    assertThat(masheryMessage.getMasheryAccessToken(), nullValue());
  }

}
