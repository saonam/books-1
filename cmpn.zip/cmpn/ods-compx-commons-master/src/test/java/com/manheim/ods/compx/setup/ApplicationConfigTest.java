package com.manheim.ods.compx.setup;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;

import org.junit.Before;
import org.junit.Test;
import org.springframework.boot.web.servlet.FilterRegistrationBean;

import com.manheim.ods.compx.web.LoggingFilter;

public class ApplicationConfigTest {

  ApplicationConfig applicationConfig;

  @Before
  public void setup() {
    this.applicationConfig = new ApplicationConfig();
  }

  @Test
  public void testLoggingFilterRegistrationBean() {
    LoggingFilter loggingFilter = mock(LoggingFilter.class);
    FilterRegistrationBean filterRegistrationBean =
        applicationConfig.loggingFilterRegistrationBean(loggingFilter);
    assertNotNull(filterRegistrationBean);
  }

}
