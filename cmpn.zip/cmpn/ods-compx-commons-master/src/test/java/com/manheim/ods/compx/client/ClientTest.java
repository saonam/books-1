package com.manheim.ods.compx.client;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;
import static org.mockito.Matchers.anyLong;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import com.manheim.ods.compx.setup.QueueMessageBuilder;
import com.manheim.ods.compx.util.MetricReporter;

import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Response;

public class ClientTest {

  private Client client;
  private Call call;
  private Request request;
  private MetricReporter metricReporter;
  private Response<QueueMessageBuilder> successfulResponse;

  @Before
  public void setUp() throws Exception {
    call = mock(Call.class);
    request = new Request.Builder().url("http://a.url/some/path").build();
    metricReporter = mock(MetricReporter.class);
    successfulResponse = Response.success(mock(QueueMessageBuilder.class));

    when(call.execute()).thenReturn(successfulResponse);
    when(call.request()).thenReturn(request);

    client = new Client(metricReporter);
  }

  @Test
  public void shouldReturnResponseWhenCallExecutionIsSuccessful() throws IOException {
    Response response = client.execute(call, Client.class);

    assertThat(response, is(successfulResponse));
  }

  @Test
  public void shouldExecuteCall() throws IOException {
    client.execute(call, Client.class);

    verify(call).execute();
  }

  @Test
  public void shouldReportMetricsWhenExecuting() throws IOException {
    client.execute(call, Client.class);

    verify(metricReporter).recordExternalCallTime(anyLong(), eq("service-name:Client"),
        eq("service-host:a.url"), eq("service-uri:/some/path"), eq("http-method:GET"),
        eq("http-status:200"));
  }
  
}
