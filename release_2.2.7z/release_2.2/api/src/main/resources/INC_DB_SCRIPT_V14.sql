UPDATE `hydro`.`observation_master` OM 
set site_id = (select EM.site_id from `hydro`.equipment_master EM where EM.equipment_id=OM.equipment_id) , 
lm2_seq = (select EM.lm2_seq from `hydro`.equipment_master EM where EM.equipment_id=OM.equipment_id),
modified_date=modified_date;