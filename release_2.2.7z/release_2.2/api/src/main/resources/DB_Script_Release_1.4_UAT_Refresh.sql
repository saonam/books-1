UPDATE `hydro`.`role_master` SET `org_type`='SITE' WHERE `role_id`='7';
UPDATE `hydro`.`role_master` SET `org_type`='SITE' WHERE `role_id`='8';


UPDATE `hydro`.`user_master` SET `org_type`='SITE' WHERE `role_id`='7';
UPDATE `hydro`.`user_master` SET `org_type`='SITE' WHERE `role_id`='8';

UPDATE `hydro`.`role_master` SET `user_role`='HYDRO ADMIN' WHERE `role_id`='1';
UPDATE `hydro`.`role_master` SET `user_role`='CHEMICAL COMPANY ADMIN' WHERE `role_id`='2';
UPDATE `hydro`.`role_master` SET `user_role`='CHEMICAL COMPANY MANAGER' WHERE `role_id`='3';
UPDATE `hydro`.`role_master` SET `user_role`='CHEMICAL COMPANY USER' WHERE `role_id`='4';
UPDATE `hydro`.`role_master` SET `user_role`='CHEMICAL COMPANY DISTRIBUTOR MANAGER' WHERE `role_id`='5';
UPDATE `hydro`.`role_master` SET `user_role`='CHEMICAL COMPANY DISTRIBUTOR USER' WHERE `role_id`='6';

UPDATE `hydro`.`user_master` SET `user_role`='HYDRO ADMIN' WHERE `role_id`='1';
UPDATE `hydro`.`user_master` SET `user_role`='CHEMICAL COMPANY ADMIN' WHERE `role_id`='2';
UPDATE `hydro`.`user_master` SET `user_role`='CHEMICAL COMPANY MANAGER' WHERE `role_id`='3';
UPDATE `hydro`.`user_master` SET `user_role`='CHEMICAL COMPANY USER' WHERE `role_id`='4';
UPDATE `hydro`.`user_master` SET `user_role`='CHEMICAL COMPANY DISTRIBUTOR MANAGER' WHERE `role_id`='5';
UPDATE `hydro`.`user_master` SET `user_role`='CHEMICAL COMPANY DISTRIBUTOR USER' WHERE `role_id`='6';
