ALTER TABLE `hydro`.`role_master` 
CHANGE COLUMN `role_id` `role_id` VARCHAR(100) NOT NULL ;

ALTER TABLE `hydro`.`role_master_bckp` 
CHANGE COLUMN `role_id` `role_id` VARCHAR(100) NOT NULL ;

ALTER TABLE `hydro`.`user_master` 
CHANGE COLUMN `role_id` `role_id` VARCHAR(100) NOT NULL ;

ALTER TABLE `hydro`.`user_master_bckp` 
CHANGE COLUMN `role_id` `role_id` VARCHAR(100) NOT NULL ;

DROP TABLE `hydro`.`privilege_master`;
DROP TABLE `hydro`.`privilege_master_bckp`;

CREATE TABLE IF NOT EXISTS `hydro`.`privilege_master` (
  `privilege_id` VARCHAR(100) NOT NULL,
  `privilege_name` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`privilege_id`))
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`privilege_master_bckp` (
  `privilege_id` VARCHAR(100) NULL,
  `privilege_name` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_Privilege_UPDATE
after update on `hydro`.`privilege_master`
for each row
insert into `hydro`.`privilege_master_bckp`(privilege_id, privilege_name, created_by, created_date, modified_by, modified_date)
values(NEW.privilege_id, NEW.privilege_name, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_Privilege_DELETE
after delete on `hydro`.`privilege_master`
for each row
insert into `hydro`.`privilege_master_bckp`(privilege_id, privilege_name, created_by, created_date, modified_by, modified_date)
values(old.privilege_id, old.privilege_name, old.created_by, old.created_date, old.modified_by, old.modified_date);

INSERT INTO `hydro`.`privilege_master` (`privilege_id`,`privilege_name`) VALUES 
('1','SITE-LIST'),
('2','SITE-VIEW'),
('3','SITE-UPDATE'),
('4','SITE-CREATE'),
('5','SITE-DELETE'),
('6','ACCOUNT-DELETE'),
('7','ACCOUNT-LIST'),
('8','ACCOUNT-UPDATE'),
('9','ACCOUNT-CREATE'),
('10','ACCOUNT-VIEW'),
('11','COMPANY-LIST'),
('12','COMPANY-VIEW'),
('13','COMPANY-DELETE'),
('14','COMPANY-CREATE'),
('15','COMPANY-UPDATE'),
('16','USER-LIST'),
('17','USER-VIEW'),
('18','USER-DELETE'),
('19','USER-CREATE'),
('20','USER-UPDATE'),
('21','OBS-REC-VIEW'),
('22','OBS-REC-UPDATE'),
('23','OBS-REC-DELETE'),
('24','OBS-REC-CREATE'),
('25','FILE-UPLOAD'),
('26','FILE-HISTORY'),
('27','GENERATE-REPORT');

CREATE TABLE IF NOT EXISTS `hydro`.`role_privilege_association` (
  `privilege_id` VARCHAR(100) NOT NULL,
  `role_id` VARCHAR(100) NOT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `RoleConstraint_idx` (`role_id` ASC),
  CONSTRAINT `PrivilegeConstraint`
    FOREIGN KEY (`privilege_id`)
    REFERENCES `hydro`.`privilege_master` (`privilege_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `RoleConstraint`
    FOREIGN KEY (`role_id`)
    REFERENCES `hydro`.`role_master` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`role_privilege_association_bckp` (
  `privilege_id` VARCHAR(100) NULL,
  `role_id` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_Role_Privilege_UPDATE
after update on `hydro`.`role_privilege_association`
for each row
insert into `hydro`.`role_privilege_association_bckp`(privilege_id, role_id, created_by, created_date, modified_by, modified_date)
values(NEW.privilege_id, NEW.role_id, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_Role_Privilege_DELETE
after delete on `hydro`.`role_privilege_association`
for each row
insert into `hydro`.`role_privilege_association_bckp`(privilege_id, role_id, created_by, created_date, modified_by, modified_date)
values(old.privilege_id, old.role_id, old.created_by, old.created_date, old.modified_by, old.modified_date);

INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('1', '1'),('2', '1'),('3', '1'),('4', '1'),('5', '1'),('6', '1'),('7', '1'),('8', '1'),('9', '1'),('10', '1'),('11', '1'),('12', '1'),('13', '1'),('14', '1'),('15', '1'),('16', '1'),('17', '1'),('18', '1'),('19', '1'),('20', '1'),('21', '1'),('22', '1'),('23', '1'),('24', '1'),('25', '1'),('26', '1'),('27', '1'),
('1', '2'),('2', '2'),('7', '2'),('10', '2'),('11', '2'),('12', '2'),('16', '2'),('17', '2'),('19', '2'),('20', '2'),('21', '2'),('25', '2'),('26', '2'),('27', '2')
