INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('28', '4'),('33', '4'),('34', '4'),('38','4');
