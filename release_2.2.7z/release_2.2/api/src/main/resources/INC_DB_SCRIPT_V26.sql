SET SQL_SAFE_UPDATES = 0;
UPDATE hydro.preference_master SET site_id=null where site_id="";
