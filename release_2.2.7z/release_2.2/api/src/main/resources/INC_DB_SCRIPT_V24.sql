ALTER TABLE `hydro`.`preference_master` 
DROP COLUMN `month_first_alarm_time`,
DROP COLUMN `month_counter`,
DROP COLUMN `week_first_alarm_time`,
DROP COLUMN `week_counter`,
DROP COLUMN `day_first_alarm_time`,
DROP COLUMN `day_counter`;

ALTER TABLE `hydro`.`preference_master_bckp` 
DROP COLUMN `month_first_alarm_time`,
DROP COLUMN `month_counter`,
DROP COLUMN `week_first_alarm_time`,
DROP COLUMN `week_counter`,
DROP COLUMN `day_first_alarm_time`,
DROP COLUMN `day_counter`;

ALTER TABLE `hydro`.`preference_master` 
CHANGE COLUMN `shift_counter` `alarm_counter` INT(11) NULL DEFAULT '0' ,
CHANGE COLUMN `shift_first_alarm_time` `alarm_first_date_time` DATETIME NOT NULL DEFAULT NULL ;

ALTER TABLE `hydro`.`preference_master_bckp` 
CHANGE COLUMN `shift_counter` `alarm_counter` INT(11) NULL DEFAULT '0' ,
CHANGE COLUMN `shift_first_alarm_time` `alarm_first_date_time` DATETIME NOT NULL DEFAULT NULL ;

DROP trigger hydro.TRIG_PREFERENCE_MASTER_UPDATE;
DROP trigger hydro.TRIG_PREFERENCE_MASTER_DELETE;

create trigger `hydro`.`TRIG_PREFERENCE_MASTER_UPDATE`
after update on `hydro`.`PREFERENCE_MASTER`
for each row 
insert into `hydro`.`PREFERENCE_MASTER_BCKP`(id, business_id, role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, alarm_counter, alarm_first_date_time, created_by, created_date, modified_by, modified_date)
values (NEW.id, NEW.business_id, NEW.role_id, NEW.alarm_id, NEW.sms, NEW.email, NEW.threshold, NEW.threshold_refresh_interval, NEW.alarm_counter, NEW.alarm_first_date_time, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_PREFERENCE_MASTER_DELETE`
after delete on `hydro`.`PREFERENCE_MASTER`
for each row
insert into `hydro`.`PREFERENCE_MASTER_BCKP`(id, business_id, role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, alarm_counter, alarm_first_date_time, created_by, created_date, modified_by, modified_date)
values (old.id, old.business_id, old.role_id, old.alarm_id, old.sms, old.email, old.threshold, old.threshold_refresh_interval, old.alarm_counter, old.alarm_first_date_time, old.created_by, old.created_date, old.modified_by, old.modified_date);

UPDATE `hydro`.`alarm_master` SET `alarm_id`='11' WHERE `alarm_id`='9';
UPDATE `hydro`.`alarm_master` SET `alarm_id`='16' WHERE `alarm_id`='6';
UPDATE `hydro`.`alarm_master` SET `alarm_id`='33' WHERE `alarm_id`='4';
UPDATE `hydro`.`alarm_master` SET `alarm_id`='32' WHERE `alarm_id`='5';
UPDATE `hydro`.`alarm_master` SET `alarm_id`='10' WHERE `alarm_id`='3';
UPDATE `hydro`.`alarm_master` SET `alarm_id`='9' WHERE `alarm_id`='2';
UPDATE `hydro`.`alarm_master` SET `alarm_id`='2' WHERE `alarm_id`='7';
DELETE FROM `hydro`.`alarm_master` WHERE `alarm_id`='8';
UPDATE `hydro`.`alarm_master` SET `alarm_id`='8' WHERE `alarm_id`='1';
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('1', 'Unfinished Cycles','The washer is started for a new load without the Dositec System receiving an end of load signal from the previous load');



