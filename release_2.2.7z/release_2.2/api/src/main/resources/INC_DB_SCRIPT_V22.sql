ALTER TABLE `hydro`.`site_master` 
ADD COLUMN `alert_setting` TINYINT NULL DEFAULT 0 AFTER `time_zone`;

ALTER TABLE `hydro`.`site_master_bckp` 
ADD COLUMN `alert_setting` TINYINT(4) NULL DEFAULT '0' AFTER `time_zone`;

DROP trigger `hydro`.`TRIG_Site_Master_UPDATE`;
DROP trigger `hydro`.`TRIG_Site_Master_DELETE`;

create trigger `hydro`.`TRIG_Site_Master_UPDATE`
after update on `hydro`.`SITE_MASTER`
for each row 
insert into `hydro`.`SITE_MASTER_BCKP`(site_id, site_owner, business_id, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit,washer_turn_minute,washer_idle_minute,washer_efficiency_threshold,tunnel_turn_minute,tunnel_idle_minute,tunnel_efficiency_threshold,time_zone,alert_setting)
values (NEW.site_id, NEW.site_owner, business_id, NEW.site_name, NEW.latitude, NEW.longitude, NEW.description, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.is_active, NEW.is_deleted, NEW.address1, NEW.address2, NEW.city, NEW.state, NEW.zipcode, NEW.site_unique_id, NEW.country,NEW.file_id,NEW.index_created,NEW.metric_unit,NEW.washer_turn_minute,NEW.washer_idle_minute,NEW.washer_efficiency_threshold,NEW.tunnel_turn_minute,NEW.tunnel_idle_minute,NEW.tunnel_efficiency_threshold,NEW.time_zone, NEW.alert_setting);

CREATE trigger `hydro`.`TRIG_Site_Master_DELETE`
after delete on `hydro`.`SITE_MASTER`
for each row
insert into `hydro`.`SITE_MASTER_BCKP`(site_id, site_owner, business_id, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit,washer_turn_minute,washer_idle_minute,washer_efficiency_threshold,tunnel_turn_minute,tunnel_idle_minute,tunnel_efficiency_threshold,time_zone,alert_setting)
values (old.site_id, old.site_owner, business_id, old.site_name, old.latitude, old.longitude, old.description, old.created_by, old.created_date, old.modified_by, old.modified_date, 0, 1, old.address1, old.address2, old.city, old.state, old.zipcode, old.site_unique_id,old.file_id,old.index_created,old.metric_unit,old.washer_turn_minute,old.washer_idle_minute,old.washer_efficiency_threshold,old.tunnel_turn_minute,old.tunnel_idle_minute,old.tunnel_efficiency_threshold,old.time_zone,old.alert_setting);

CREATE TABLE IF NOT EXISTS `hydro`.`ALARM_MASTER` (
  `alarm_id` VARCHAR(100) NOT NULL,
  `alarm_name` VARCHAR(100) NULL,
  `description` VARCHAR(1000) NULL,
  `threshold` INT NOT NULL DEFAULT 1,
  `threshold_refresh_interval` INT NOT NULL DEFAULT 1,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`alarm_id`))
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`ALARM_MASTER_BCKP` (
  `alarm_id` VARCHAR(100) NOT NULL,
  `alarm_name` VARCHAR(100) NULL,
  `description` VARCHAR(1000) NULL,
  `threshold` INT NOT NULL DEFAULT 1,
  `threshold_refresh_interval` INT NOT NULL DEFAULT 1,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.`TRIG_ALARM_MASTER_UPDATE`
after update on `hydro`.`ALARM_MASTER`
for each row 
insert into `hydro`.`ALARM_MASTER_BCKP`(alarm_id, alarm_name, description,threshold,threshold_refresh_interval, created_by, created_date, modified_by, modified_date)
values (NEW.alarm_id, NEW.alarm_name, NEW.description,NEW.threshold,NEW.threshold_refresh_interval, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_ALARM_MASTER_DELETE`
after delete on `hydro`.`ALARM_MASTER`
for each row
insert into `hydro`.`ALARM_MASTER_BCKP`(alarm_id, alarm_name, description,threshold,threshold_refresh_interval, created_by, created_date, modified_by, modified_date)
values (old.alarm_id, old.alarm_name, old.description,old.threshold,old.threshold_refresh_interval, old.created_by, old.created_date, old.modified_by, old.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`PREFERENCE_MASTER` (
  `id` VARCHAR(100) NOT NULL,
  `business_id` VARCHAR(100) NULL,
  `role_id` VARCHAR(100) NULL,
  `alarm_id` VARCHAR(100) NULL,
  `sms` TINYINT NULL,
  `email` TINYINT NULL,
  `threshold` INT NOT NULL DEFAULT 1,
  `threshold_refresh_interval` INT NOT NULL DEFAULT 1,
  `shift_counter` INT NULL DEFAULT 0,
  `shift_first_alarm_time` DATE NULL,
  `day_counter` INT NULL,
  `day_first_alarm_time` DATE NULL,
  `week_counter` INT NULL DEFAULT 0,
  `week_first_alarm_time` DATE NULL,
  `month_counter` INT NULL DEFAULT 0,
  `month_first_alarm_time` DATE NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `Ref_alarmIdColumn_idx` (`alarm_id` ASC),
  INDEX `Ref_businessId_idx` (`business_id` ASC),
  INDEX `Ref_roleIdref_idx` (`role_id` ASC),
  PRIMARY KEY (`id`),
  CONSTRAINT `Ref_alarmIdColumn`
    FOREIGN KEY (`alarm_id`)
    REFERENCES `hydro`.`ALARM_MASTER` (`alarm_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `Ref_roleIdref`
    FOREIGN KEY (`role_id`)
    REFERENCES `hydro`.`ROLE_MASTER` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `Ref_businessId`
    FOREIGN KEY (`business_id`)
    REFERENCES `hydro`.`BUSINESS_MASTER` (`business_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`PREFERENCE_MASTER_BCKP` (
  `id` VARCHAR(100) NULL,
  `business_id` VARCHAR(100) NULL,
  `role_id` VARCHAR(100) NULL,
  `alarm_id` VARCHAR(100) NULL,
  `sms` TINYINT NULL,
  `email` TINYINT NULL,
  `threshold` INT NOT NULL DEFAULT 1,
  `threshold_refresh_interval` INT NOT NULL DEFAULT 1,
  `shift_counter` INT NULL DEFAULT 0,
  `shift_first_alarm_time` DATE NULL,
  `day_counter` INT NULL,
  `day_first_alarm_time` DATE NULL,
  `week_counter` INT NULL DEFAULT 0,
  `week_first_alarm_time` DATE NULL,
  `month_counter` INT NULL DEFAULT 0,
  `month_first_alarm_time` DATE NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.`TRIG_PREFERENCE_MASTER_UPDATE`
after update on `hydro`.`PREFERENCE_MASTER`
for each row 
insert into `hydro`.`PREFERENCE_MASTER_BCKP`(id, business_id, role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, shift_counter, shift_first_alarm_time, day_counter, day_first_alarm_time, week_counter, week_first_alarm_time, month_counter, month_first_alarm_time, created_by, created_date, modified_by, modified_date)
values (NEW.id, NEW.business_id, NEW.role_id, NEW.alarm_id, NEW.sms, NEW.email, NEW.threshold, NEW.threshold_refresh_interval, NEW.shift_counter, NEW.shift_first_alarm_time, NEW.day_counter, NEW.day_first_alarm_time, NEW.week_counter, NEW.week_first_alarm_time, NEW.month_counter, NEW.month_first_alarm_time, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_PREFERENCE_MASTER_DELETE`
after delete on `hydro`.`PREFERENCE_MASTER`
for each row
insert into `hydro`.`PREFERENCE_MASTER_BCKP`(id, business_id, role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, shift_counter, shift_first_alarm_time, day_counter, day_first_alarm_time, week_counter, week_first_alarm_time, month_counter, month_first_alarm_time, created_by, created_date, modified_by, modified_date)
values (old.id, old.business_id, old.role_id, old.alarm_id, old.sms, old.email, old.threshold, old.threshold_refresh_interval, old.shift_counter, old.shift_first_alarm_time, old.day_counter, old.day_first_alarm_time, old.week_counter, old.week_first_alarm_time, old.month_counter, old.month_first_alarm_time, old.created_by, old.created_date, old.modified_by, old.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`USER_ALARM_PREFERENCE` (
`id` VARCHAR(45) NOT NULL,
  `user_id` VARCHAR(45) NULL,
  `alarm_id` VARCHAR(45) NULL,
  `active` TINYINT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `Ref_alarmIdColumn_idx` (`alarm_id` ASC),
  INDEX `Ref_userIdColumn_idx` (`user_id` ASC),
	PRIMARY KEY (`id`),
  CONSTRAINT `Ref_alarmIdColumn0`
    FOREIGN KEY (`alarm_id`)
    REFERENCES `hydro`.`ALARM_MASTER` (`alarm_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `Ref_userIdColumn`
    FOREIGN KEY (`user_id`)
    REFERENCES `hydro`.`USER_MASTER` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`USER_ALARM_PREFERENCE_BCKP` (
`id` VARCHAR(45) NOT NULL,
  `user_id` VARCHAR(45) NULL,
  `alarm_id` VARCHAR(45) NULL,
  `active` TINYINT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.`TRIG_USER_ALARM_PREFERENCE_UPDATE`
after update on `hydro`.`USER_ALARM_PREFERENCE`
for each row 
insert into `hydro`.`USER_ALARM_PREFERENCE_BCKP`(id,user_id, alarm_id, active, created_by, created_date, modified_by, modified_date)
values (NEW.id,NEW.user_id, NEW.alarm_id, NEW.active, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_USER_ALARM_PREFERENCE_DELETE`
after delete on `hydro`.`USER_ALARM_PREFERENCE`
for each row
insert into `hydro`.`USER_ALARM_PREFERENCE_BCKP`(id,user_id, alarm_id, active, created_by, created_date, modified_by, modified_date)
values (old.id,old.user_id, old.alarm_id, old.active, old.created_by, old.created_date, old.modified_by, old.modified_date);

INSERT INTO `hydro`.`privilege_master` (`privilege_id`, `privilege_name`) VALUES ('45', 'ALERT-SETTING');

INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('45', '1'), ('45', '2'),('15', '2');

INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('1', 'Leak Test Alarm','The test performed prior to every product dose to see if there are flowmeter counts when the channel is pressurized with water.');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('2', 'Water Test Alarm','A water flow test performed after the leak test and prior to every product dose');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('3', 'Flow Meter/Dosing Alarm','The programmed dosage of product did not occur in the time allowed. The time allowed is based on a value determined by calibration plus an added % of that time');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('4', 'Air Pressure Failure Alarm','A drop in air pressure below the minimum requirement to operate the Air Assist');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('5', 'Emergency Stop/Unit Lock Alarm','EMERGENCY STOP button is depressed.');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('6', 'Minimum Level of Product/Drum Lance Alarm','Float switch in the drum lance is reading low levels or product');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('7', 'Cycles with Missed Phases','A load that has sent an end of load signal without completing all the programmed phases. A phase is a dose request within a formula.');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('8', 'Unfinished Cycles','The washer is started for a new load without the Dositec System receiving an end of load signal from the previous load');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('9', 'Flow Meter/Flush Alarm','The programmed amount of water for flushing did not occur in the time allowed. The time allowed is based on a value determined by calibration.');






