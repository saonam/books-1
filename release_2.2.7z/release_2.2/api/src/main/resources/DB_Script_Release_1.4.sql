DELETE FROM `hydro`.`role_privilege_association` WHERE `role_id`='1' and `privilege_id`='5';

DELETE FROM `hydro`.`role_privilege_association` WHERE `role_id`='1' and `privilege_id`='6';

DELETE FROM `hydro`.`role_privilege_association` WHERE `role_id`='1' and `privilege_id`='13';

DELETE FROM `hydro`.`role_privilege_association` WHERE `role_id`='1' and `privilege_id`='18';

INSERT INTO `hydro`.`privilege_master` (`privilege_id`,`privilege_name`) VALUES 
('43','OBS-REC-REPORT');

INSERT INTO `hydro`.`role_master` (`role_id`, `user_role`, `clearance_level`,`org_type`) VALUES 
('5', 'CHEMICAL COMPANY DISTRIBUTOR MANAGER', '5','CHEMICAL COMPANY'),
('6', 'CHEMICAL COMPANY DISTRIBUTOR USER', '6','CHEMICAL COMPANY'),
('7', 'SITE MANAGER', '7','SITE'),
('8', 'SITE USER', '8','SITE');

INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES 
('43','1'),('43','2'),('43','3'),('43','4'),

('17','4'),('19','4'),('20','4'),

('1','5'),('2','5'),('3','5'),('7','5'),
('10','5'),('11','5'),('12','5'),('16','5'),
('17','5'),('19','5'),('20','5'),('25','5'),
('26','5'),('27','5'),('28','5'),('29','5'),('30','5'),
('31','5'),('32','5'),('33','5'),('34','5'),('35','5'),
('36','5'),('37','5'),('38','5'),('39','5'),


('1','6'),('2','6'),('7','6'),('10','6'),
('11','6'),('12','6'),('16','6'),('17','6'),
('19','6'),('25','6'),('26','6'),('27','6'),('28','6'),
('29','6'),('30','6'),('31','6'),('32','6'),('33','6'),
('34','6'),('35','6'),('36','6'),
('37','6'),('38','6'),('39','6'),


('1','7'),('2','7'),('3','7'),('7','7'),
('10','7'),('11','7'),('12','7'),('16','7'),
('17','7'),('19','7'),('25','7'),('26','7'),
('27','7'),('29','7'),('30','7'),('31','7'),
('36','7'),('37','7'),('39','7'),

('1','8'),('2','8'),('7','8'),('10','8'),
('11','8'),('12','8'),('16','8'),('17','8'),
('25','8'),('26','8'),('27','8'),('29','8'),
('30','8'),('31','8'),('36','8'),('37','8'),('39','8');

UPDATE `hydro`.`role_master` SET `org_type`='CHEMICAL COMPANY' WHERE `role_id`='2';
UPDATE `hydro`.`role_master` SET `org_type`='CHEMICAL COMPANY' WHERE `role_id`='3';
UPDATE `hydro`.`role_master` SET `org_type`='CHEMICAL COMPANY' WHERE `role_id`='4';

UPDATE `hydro`.`user_master` SET `org_type`='CHEMICAL COMPANY' WHERE `org_type`='COMPANY';

UPDATE `hydro`.`role_master` SET `user_role`='HYDRO ADMIN' WHERE `role_id`='1';
UPDATE `hydro`.`role_master` SET `user_role`='CHEMICAL COMPANY ADMIN' WHERE `role_id`='2';
UPDATE `hydro`.`role_master` SET `user_role`='CHEMICAL COMPANY MANAGER' WHERE `role_id`='3';
UPDATE `hydro`.`role_master` SET `user_role`='CHEMICAL COMPANY USER' WHERE `role_id`='4';

UPDATE `hydro`.`user_master` SET `user_role`='HYDRO ADMIN' WHERE `role_id`='1';
UPDATE `hydro`.`user_master` SET `user_role`='CHEMICAL COMPANY ADMIN' WHERE `role_id`='2';
UPDATE `hydro`.`user_master` SET `user_role`='CHEMICAL COMPANY MANAGER' WHERE `role_id`='3';
UPDATE `hydro`.`user_master` SET `user_role`='CHEMICAL COMPANY USER' WHERE `role_id`='4';

