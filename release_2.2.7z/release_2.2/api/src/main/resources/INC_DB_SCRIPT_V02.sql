ALTER TABLE `hydro`.`site_master` 
ADD COLUMN `metric_unit` VARCHAR(20) NULL DEFAULT '1' AFTER `index_created`;

ALTER TABLE `hydro`.`site_master_bckp` 
ADD COLUMN `metric_unit` VARCHAR(20) NULL DEFAULT '1' AFTER `index_created`;

DROP Trigger `hydro`.TRIG_Site_UPDATE;

create trigger `hydro`.TRIG_Site_UPDATE
after update on `hydro`.SITE_MASTER
for each row 
insert into `hydro`.SITE_MASTER_BCKP(site_id, site_owner, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit)
values (NEW.site_id, NEW.site_owner, NEW.site_name, NEW.latitude, NEW.longitude, NEW.description, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.is_active, NEW.is_deleted, NEW.address1, NEW.address2, NEW.city, NEW.state, NEW.zipcode, NEW.site_unique_id, NEW.country,NEW.file_id,NEW.index_created,NEW.metric_unit);

DROP trigger `hydro`.TRIG_Site_DELETE;

CREATE trigger `hydro`.TRIG_Site_DELETE
after delete on `hydro`.SITE_MASTER
for each row
insert into `hydro`.SITE_MASTER_BCKP(site_id, site_owner, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit)
values (old.site_id, old.site_owner, old.site_name, old.latitude, old.longitude, old.description, old.created_by, old.created_date, old.modified_by, old.modified_date, 0, 1, old.address1, old.address2, old.city, old.state, old.zipcode, old.site_unique_id,old.file_id,old.index_created,old.metric_unit);

/*Alter existing tables with utf character set and collasion*/
set foreign_key_checks=0;
ALTER TABLE hydro.business_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.business_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.contact_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.contact_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.equipment_formula CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.equipment_formula_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.equipment_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.equipment_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.equipment_pump CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.equipment_pump_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.equipment_pump_machinery CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.equipment_pump_machinery_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.equipment_tunnel_channel CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.equipment_tunnel_channel_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.file_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.file_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.formula_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.formula_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.formula_pdb CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.formula_pdb_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.observation_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.observation_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.privilege_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.privilege_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.product_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.product_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.role_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.role_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.site_business_association CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.site_business_association_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.site_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.site_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.tunnel_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.tunnel_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.tunnel_products CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.tunnel_products_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.user_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.user_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.washer_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.washer_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.water_master CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.water_master_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.es_error_log CHANGE COLUMN es_error es_error LONGTEXT NULL DEFAULT NULL , CHANGE COLUMN es_document es_document LONGTEXT NULL DEFAULT NULL ;
ALTER TABLE hydro.es_error_log CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER TABLE hydro.es_error_log_bckp CHANGE COLUMN es_error es_error LONGTEXT NULL DEFAULT NULL , CHANGE COLUMN es_document es_document LONGTEXT NULL DEFAULT NULL ;
ALTER TABLE hydro.es_error_log_bckp CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;
set foreign_key_checks=1;
