INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_name`, `description`) VALUES ('101', 'Machine Idle Too long', 'The amount of time after a load is finished has exceeded a pre-set value that is set by the Chemical Company or Site Manager.');

ALTER TABLE `hydro`.`alarm_master` 
ADD COLUMN `alarm_type` VARCHAR(100) NULL AFTER `alarm_id`;

ALTER TABLE `hydro`.`alarm_master_bckp` 
ADD COLUMN `alarm_type` VARCHAR(100) NULL AFTER `alarm_id`;

DROP trigger `hydro`.TRIG_ALARM_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_ALARM_MASTER_DELETE;

create trigger `hydro`.`TRIG_ALARM_MASTER_UPDATE`
after update on `hydro`.`ALARM_MASTER`
for each row 
insert into `hydro`.`ALARM_MASTER_BCKP`(alarm_id, alarm_type, alarm_name, description,created_by, created_date, modified_by, modified_date)
values (NEW.alarm_id, NEW.alarm_type, NEW.alarm_name, NEW.description, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_ALARM_MASTER_DELETE`
after delete on `hydro`.`ALARM_MASTER`
for each row
insert into `hydro`.`ALARM_MASTER_BCKP`(alarm_id, alarm_type, alarm_name, description,created_by, created_date, modified_by, modified_date)
values (old.alarm_id, old.alarm_type, old.alarm_name, old.description,old.created_by, old.created_date, old.modified_by, old.modified_date);

UPDATE `hydro`.`alarm_master` SET `alarm_type`='0' WHERE `alarm_id`='1';
UPDATE `hydro`.`alarm_master` SET `alarm_type`='0' WHERE `alarm_id`='10';
UPDATE `hydro`.`alarm_master` SET `alarm_type`='1' WHERE `alarm_id`='101';
UPDATE `hydro`.`alarm_master` SET `alarm_type`='0' WHERE `alarm_id`='11';
UPDATE `hydro`.`alarm_master` SET `alarm_type`='0' WHERE `alarm_id`='16';
UPDATE `hydro`.`alarm_master` SET `alarm_type`='0' WHERE `alarm_id`='2';
UPDATE `hydro`.`alarm_master` SET `alarm_type`='0' WHERE `alarm_id`='32';
UPDATE `hydro`.`alarm_master` SET `alarm_type`='0' WHERE `alarm_id`='33';
UPDATE `hydro`.`alarm_master` SET `alarm_type`='0' WHERE `alarm_id`='8';
UPDATE `hydro`.`alarm_master` SET `alarm_type`='0' WHERE `alarm_id`='9';

ALTER TABLE `hydro`.`preference_master` 
ADD COLUMN `unit_id` VARCHAR(100) NULL AFTER `site_id`,
ADD COLUMN `machine_id` VARCHAR(100) NULL AFTER `unit_id`;

ALTER TABLE `hydro`.`preference_master_bckp` 
ADD COLUMN `unit_id` VARCHAR(100) NULL AFTER `site_id`,
ADD COLUMN `machine_id` VARCHAR(100) NULL AFTER `unit_id`;

DROP trigger `hydro`.TRIG_PREFERENCE_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_PREFERENCE_MASTER_DELETE;

create trigger `hydro`.`TRIG_PREFERENCE_MASTER_UPDATE`
after update on `hydro`.`PREFERENCE_MASTER`
for each row 
insert into `hydro`.`PREFERENCE_MASTER_BCKP`(id, business_id, site_id, unit_id, machine_id, role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, alarm_counter, alarm_first_date_time, created_by, created_date, modified_by, modified_date)
values (NEW.id, NEW.business_id, NEW.site_id, NEW.unit_id, NEW.machine_id, NEW.role_id, NEW.alarm_id, NEW.sms, NEW.email, NEW.threshold, NEW.threshold_refresh_interval, NEW.alarm_counter, NEW.alarm_first_date_time, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_PREFERENCE_MASTER_DELETE`
after delete on `hydro`.`PREFERENCE_MASTER`
for each row
insert into `hydro`.`PREFERENCE_MASTER_BCKP`(id, business_id, site_id, unit_id, machine_id, role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, alarm_counter, alarm_first_date_time, created_by, created_date, modified_by, modified_date)
values (old.id, old.business_id, old.site_id, old.unit_id, old.machine_id, old.role_id, old.alarm_id, old.sms, old.email, old.threshold, old.threshold_refresh_interval, old.alarm_counter, old.alarm_first_date_time, old.created_by, old.created_date, old.modified_by, old.modified_date);





