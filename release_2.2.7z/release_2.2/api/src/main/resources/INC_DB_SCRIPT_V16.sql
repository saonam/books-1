UPDATE `hydro`.`role_master` SET `org_type`='CHEMICAL COMPANY' WHERE `role_id`='2';
UPDATE `hydro`.`role_master` SET `org_type`='CHEMICAL COMPANY' WHERE `role_id`='3';
UPDATE `hydro`.`role_master` SET `org_type`='CHEMICAL COMPANY' WHERE `role_id`='4';
UPDATE `hydro`.`role_master` SET `org_type`='CHEMICAL COMPANY' WHERE `role_id`='5';
UPDATE `hydro`.`role_master` SET `org_type`='CHEMICAL COMPANY' WHERE `role_id`='6';
UPDATE `hydro`.`role_master` SET `org_type`='CHEMICAL COMPANY' WHERE `role_id`='7';
UPDATE `hydro`.`role_master` SET `org_type`='CHEMICAL COMPANY' WHERE `role_id`='8';

UPDATE `hydro`.`user_master` SET `org_type`='CHEMICAL COMPANY' WHERE `org_type`='COMPANY';

