INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES 
('17','4');