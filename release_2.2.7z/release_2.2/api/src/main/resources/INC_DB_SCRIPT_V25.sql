ALTER TABLE `hydro`.`product_master` 
CHANGE COLUMN `kf` `kf` DOUBLE NULL,
CHANGE COLUMN `flow` `flow` DOUBLE NULL;

ALTER TABLE `hydro`.`product_master_bckp` 
CHANGE COLUMN `kf` `kf` DOUBLE NULL,
CHANGE COLUMN `flow` `flow` DOUBLE NULL;

ALTER TABLE `hydro`.`preference_master` 
DROP FOREIGN KEY `Ref_businessId`;
ALTER TABLE `hydro`.`preference_master` 
CHANGE COLUMN `business_id` `business_id` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_unicode_ci' NOT NULL ,
ADD COLUMN `site_id` VARCHAR(100) NOT NULL AFTER `business_id`;
ALTER TABLE `hydro`.`preference_master` 
ADD CONSTRAINT `Ref_businessId`
  FOREIGN KEY (`business_id`)
  REFERENCES `hydro`.`business_master` (`business_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `hydro`.`preference_master_bckp` 
CHANGE COLUMN `business_id` `business_id` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_unicode_ci' NOT NULL ,
ADD COLUMN `site_id` VARCHAR(100) NOT NULL AFTER `business_id`;

Drop trigger hydro.TRIG_PREFERENCE_MASTER_UPDATE;
Drop trigger hydro.TRIG_PREFERENCE_MASTER_DELETE;

create trigger `hydro`.`TRIG_PREFERENCE_MASTER_UPDATE`
after update on `hydro`.`PREFERENCE_MASTER`
for each row 
insert into `hydro`.`PREFERENCE_MASTER_BCKP`(id, business_id, site_id,role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, alarm_counter, alarm_first_date_time, created_by, created_date, modified_by, modified_date)
values (NEW.id, NEW.business_id, NEW.site_id,NEW.role_id, NEW.alarm_id, NEW.sms, NEW.email, NEW.threshold, NEW.threshold_refresh_interval, NEW.alarm_counter, NEW.alarm_first_date_time, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_PREFERENCE_MASTER_DELETE`
after delete on `hydro`.`PREFERENCE_MASTER`
for each row
insert into `hydro`.`PREFERENCE_MASTER_BCKP`(id, business_id, site_id,role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, alarm_counter, alarm_first_date_time, created_by, created_date, modified_by, modified_date)
values (old.id, old.business_id,old.site_id, old.role_id, old.alarm_id, old.sms, old.email, old.threshold, old.threshold_refresh_interval, old.alarm_counter, old.alarm_first_date_time, old.created_by, old.created_date, old.modified_by, old.modified_date);

