DROP TRIGGER `hydro`.TRIG_Role_UPDATE;
DROP TRIGGER `hydro`.TRIG_Role_DELETE;

ALTER TABLE `hydro`.`role_master` 
ADD COLUMN `org_type` VARCHAR(100) NULL AFTER `clearance_level`;

UPDATE `hydro`.`role_master` SET `clearance_level`='0' WHERE `role_id`='0';
UPDATE `hydro`.`role_master` SET `clearance_level`='1' WHERE `role_id`='1';
UPDATE `hydro`.`role_master` SET `clearance_level`='2' WHERE `role_id`='2';
UPDATE `hydro`.`role_master` SET `user_role`='ADMIN', `org_type`='HYDRO' WHERE `role_id`='1';
UPDATE `hydro`.`role_master` SET `user_role`='ADMIN', `org_type`='COMPANY' WHERE `role_id`='2';

INSERT INTO `hydro`.`role_master` (`role_id`, `user_role`, `clearance_level`,`org_type`) VALUES ('3', 'MANAGER', '3','COMPANY'),('4', 'USER', '4','COMPANY');

create trigger `hydro`.TRIG_Role_UPDATE
after update on `hydro`.ROLE_MASTER
for each row
insert into `hydro`.ROLE_MASTER_BCKP(role_id, user_role, clearance_level, org_type, created_by, created_date, modified_by, modified_date)
values(NEW.role_id, NEW.user_role, NEW.clearance_level, NEW.org_type, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_Role_DELETE
after delete on `hydro`.ROLE_MASTER
for each row
insert into `hydro`.ROLE_MASTER_BCKP(role_id, user_role, clearance_level, org_type, created_by, created_date, modified_by, modified_date)
values(old.role_id, old.user_role, old.clearance_level, old.org_type,old.created_by, old.created_date, old.modified_by, old.modified_date);

INSERT INTO `hydro`.`privilege_master` (`privilege_id`,`privilege_name`) VALUES 
('28','COST-SUMMARY-EST-COST'),
('29','PRODUCTION-SUMMARY-LBS-WASHED'),
('30','PRODUCTION-SUMMARY-LOADS-WASHED'),
('31','CHEMICAL-SUMMARY-ACTUAL-USAGE'),
('32', 'CHEMICAL-SUMMARY-EST-USAGE'),
('33','COST-SUMMARY-ABS-COST'),
('34','COST-SUMMARY-COST-PER-CWT'),
('35','COST-SUMMARY-ERROR'),
('36','WASHER-PRODUCTION-SUMMARY-REPORT'),
('37','CHEMICAL-SUMMARY-REPORT'),
('38','COST-SUMMARY-REPORT'),
('39','ALARM-SUMMARY-REPORT'),
('40', 'FULL-PRIVILEGE');

INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES 
('28', '1'),('29', '1'),('30', '1'),('31', '1'),('32', '1'),('33', '1'),('34', '1'),('35', '1'),('36','1'),('37','1'),('38','1'),('39','1'),('40', '1'),
('3','2'),('28', '2'),('29', '2'),('30', '2'),('31', '2'),('32', '2'),('33', '2'),('34', '2'),('35', '2'),('36','2'),('37','2'),('38','2'),('39','2'),('40', '2'),('41','2')
('1', '3'), ('2', '3'), ('3', '3'), ('7', '3'), ('10', '3'),('11', '3'),('12', '3'), ('16', '3'), ('17', '3'), ('19', '3'), ('20', '3'),('21', '3'),('25','3'),('26','3'),('27','3'),('28','3'),('29', '3'), ('30', '3'), ('31', '3'), ('32','3'),('33', '3'), 
('34', '3'), ('35', '3'), ('36', '3'), ('37', '3'), ('38', '3'), ('39', '3'),
('1','4'),('2','4'),('7','4'),('10','4'),('11','4'),('12', '4'),('16','4'),('17', '3'),('19','4'),('21','4'),('25','4'),('26','4'),('27','4'),('29','4'),('30','4'),('31','4'),('36','4'),('37','4'),('39','4');

DROP TRIGGER `hydro`.TRIG_Site_UPDATE;
DROP TRIGGER `hydro`.TRIG_Site_DELETE;

ALTER TABLE `hydro`.`site_master` 
ADD COLUMN `business_id` VARCHAR(100) NULL DEFAULT NULL AFTER `site_owner`;

ALTER TABLE `hydro`.`site_master` 
ADD INDEX `businessIDConst_idx` (`business_id` ASC);
ALTER TABLE `hydro`.`site_master` 
ADD CONSTRAINT `businessIDConst`
  FOREIGN KEY (`business_id`)
  REFERENCES `hydro`.`business_master` (`business_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

ALTER TABLE `hydro`.`site_master_bckp` 
ADD COLUMN `business_id` VARCHAR(100) NULL AFTER `site_owner`;

create trigger `hydro`.TRIG_Site_Master_UPDATE
after update on `hydro`.SITE_MASTER
for each row 
insert into `hydro`.SITE_MASTER_BCKP(site_id, site_owner, business_id, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit)
values (NEW.site_id, NEW.site_owner, business_id, NEW.site_name, NEW.latitude, NEW.longitude, NEW.description, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.is_active, NEW.is_deleted, NEW.address1, NEW.address2, NEW.city, NEW.state, NEW.zipcode, NEW.site_unique_id, NEW.country,NEW.file_id,NEW.index_created,NEW.metric_unit);

CREATE trigger `hydro`.TRIG_Site_Master_DELETE
after delete on `hydro`.SITE_MASTER
for each row
insert into `hydro`.SITE_MASTER_BCKP(site_id, site_owner, business_id, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit)
values (old.site_id, old.site_owner, business_id, old.site_name, old.latitude, old.longitude, old.description, old.created_by, old.created_date, old.modified_by, old.modified_date, 0, 1, old.address1, old.address2, old.city, old.state, old.zipcode, old.site_unique_id,old.file_id,old.index_created,old.metric_unit);

UPDATE `hydro`.`site_master`, `hydro`.site_business_association
SET `hydro`.site_master.business_id = (select `hydro`.site_business_association.business_id from `hydro`.site_business_association
where `hydro`.site_business_association.site_id=`hydro`.site_master.site_id
order by `hydro`.site_business_association.created_date DESC
limit 1);

UPDATE `hydro`.`site_master_bckp`, `hydro`.`site_business_association`
SET `hydro`.site_master_bckp.business_id = (select `hydro`.site_business_association.business_id from `hydro`.site_business_association
where `hydro`.site_business_association.site_id=`hydro`.site_master_bckp.site_id
order by `hydro`.site_business_association.created_date DESC
limit 1);

CREATE TABLE IF NOT EXISTS `hydro`.`USER_SITE_ASSOCIATION` (
  `user_id` VARCHAR(100) NOT NULL,
  `site_id` VARCHAR(100) NOT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `userConstraint_idx` (`user_id` ASC),
  INDEX `siteConstraint_idx` (`site_id` ASC),
  CONSTRAINT `UserConstraintForAssociation`
    FOREIGN KEY (`user_id`)
    REFERENCES `hydro`.`USER_MASTER` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `SiteConstraintForAssociation`
    FOREIGN KEY (`site_id`)
    REFERENCES `hydro`.`SITE_MASTER` (`site_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`USER_SITE_ASSOCIATION_BCKP` (
  `user_id` VARCHAR(100) NULL,
  `site_id` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_User_Site_Association_UPDATE
after update on `hydro`.USER_SITE_ASSOCIATION
for each row 
insert into `hydro`.USER_SITE_ASSOCIATION_BCKP(user_id, site_id, created_by, created_date, modified_by, modified_date)
values (NEW.user_id, NEW.site_id, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.TRIG_User_Site_Association_DELETE
after delete on `hydro`.USER_SITE_ASSOCIATION
for each row
insert into `hydro`.USER_SITE_ASSOCIATION_BCKP(user_id, site_id, created_by, created_date, modified_by, modified_date)
values (old.user_id, old.site_id, old.created_by, old.created_date, old.modified_by, old.modified_date);