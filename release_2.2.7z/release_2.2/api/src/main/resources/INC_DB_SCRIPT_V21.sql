ALTER TABLE `hydro`.`site_master` 
ADD COLUMN `time_zone` VARCHAR(100) NULL AFTER `tunnel_efficiency_threshold`;

ALTER TABLE `hydro`.`site_master_bckp` 
ADD COLUMN `time_zone` VARCHAR(100) NULL AFTER `tunnel_efficiency_threshold`;

DROP trigger `hydro`.`TRIG_Site_Master_UPDATE`;

DROP trigger `hydro`.`TRIG_Site_Master_DELETE`;

create trigger `hydro`.`TRIG_Site_Master_UPDATE`
after update on `hydro`.`SITE_MASTER`
for each row 
insert into `hydro`.`SITE_MASTER_BCKP`(site_id, site_owner, business_id, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit,washer_turn_minute,washer_idle_minute,washer_efficiency_threshold,tunnel_turn_minute,tunnel_idle_minute,tunnel_efficiency_threshold,time_zone)
values (NEW.site_id, NEW.site_owner, business_id, NEW.site_name, NEW.latitude, NEW.longitude, NEW.description, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.is_active, NEW.is_deleted, NEW.address1, NEW.address2, NEW.city, NEW.state, NEW.zipcode, NEW.site_unique_id, NEW.country,NEW.file_id,NEW.index_created,NEW.metric_unit,NEW.washer_turn_minute,NEW.washer_idle_minute,NEW.washer_efficiency_threshold,NEW.tunnel_turn_minute,NEW.tunnel_idle_minute,NEW.tunnel_efficiency_threshold,NEW.time_zone);

CREATE trigger `hydro`.`TRIG_Site_Master_DELETE`
after delete on `hydro`.`SITE_MASTER`
for each row
insert into `hydro`.`SITE_MASTER_BCKP`(site_id, site_owner, business_id, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit,washer_turn_minute,washer_idle_minute,washer_efficiency_threshold,tunnel_turn_minute,tunnel_idle_minute,tunnel_efficiency_threshold,time_zone)
values (old.site_id, old.site_owner, business_id, old.site_name, old.latitude, old.longitude, old.description, old.created_by, old.created_date, old.modified_by, old.modified_date, 0, 1, old.address1, old.address2, old.city, old.state, old.zipcode, old.site_unique_id,old.file_id,old.index_created,old.metric_unit,old.washer_turn_minute,old.washer_idle_minute,old.washer_efficiency_threshold,old.tunnel_turn_minute,old.tunnel_idle_minute,old.tunnel_efficiency_threshold,old.time_zone);
