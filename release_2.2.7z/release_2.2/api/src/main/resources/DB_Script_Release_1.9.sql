ALTER TABLE `hydro`.`file_master` 
ADD COLUMN `device_id` VARCHAR(100) NULL AFTER `file_type`,
ADD COLUMN `is_active` TINYINT NULL DEFAULT 0 AFTER `device_id`;

ALTER TABLE `hydro`.`file_master_bckp` 
ADD COLUMN `device_id` VARCHAR(100) CHARACTER SET 'utf8' COLLATE 'utf8_unicode_ci' NULL DEFAULT NULL AFTER `file_type`,
ADD COLUMN `is_active` TINYINT(4) NULL DEFAULT '0' AFTER `device_id`;

DROP trigger `hydro`.TRIG_FILE_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_FILE_MASTER_DELETE;

create trigger `hydro`.TRIG_FILE_MASTER_UPDATE
after update on `hydro`.FILE_MASTER
for each row
insert into `hydro`.FILE_MASTER_BCKP(file_id, name, created_by, created_date, status, site_id, description, detailed_description,version,modified_by,modified_date, file_type,device_id,is_active)
values(NEW.file_id, NEW.name, NEW.created_by, NEW.created_date, NEW.status, NEW.site_id, NEW.description, NEW.detailed_description, NEW.version, NEW.modified_by,NEW.modified_date, NEW.file_type, NEW.device_id, NEW.is_active);

create trigger `hydro`.TRIG_FILE_MASTER_DELETE
after delete on `hydro`.FILE_MASTER
for each row
insert into `hydro`.FILE_MASTER_BCKP(file_id, name, created_by, created_date, status, site_id, description, detailed_description, version,modified_by,modified_date, file_type,device_id,is_active)
values(old.file_id, old.name, old.created_by, old.created_date, old.status, old.site_id, old.description, old.detailed_description, old.version, old.modified_by,old.modified_date, old.file_type, old.device_id, old.is_active);

ALTER TABLE `hydro`.`equipment_master` 
ADD COLUMN `device_id` VARCHAR(100) NULL AFTER `file_id`;

ALTER TABLE `hydro`.`equipment_master_bckp` 
ADD COLUMN `device_id` VARCHAR(100) DEFAULT NULL AFTER `file_id`;

DROP trigger `hydro`.TRIG_EQUIPMENT_UPDATE;
DROP trigger `hydro`.TRIG_EQUIPMENT_DELETE;

create trigger `hydro`.TRIG_EQUIPMENT_UPDATE
after update on `hydro`.EQUIPMENT_MASTER
for each row
insert into `hydro`.EQUIPMENT_MASTER_BCKP(equipment_id, lm2_seq, site_id, alias, equipment_type, slave, ip_address, observations, washer_count, tunnel_count, w_machine_chnl_count, pump_count, channel_count, is_active, created_by, created_date, modified_by, modified_date, version, file_id, device_id)
values(NEW.equipment_id, NEW.lm2_seq, NEW.site_id, NEW.alias, NEW.equipment_type, NEW.slave, NEW.ip_address, NEW.observations, NEW.washer_count, NEW.tunnel_count, NEW.w_machine_chnl_count, NEW.pump_count, NEW.channel_count, NEW.is_active, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.version, NEW.file_id, NEW.device_id);

create trigger `hydro`.TRIG_EQUIPMENT_DELETE
after delete on `hydro`.EQUIPMENT_MASTER
for each row
insert into `hydro`.EQUIPMENT_MASTER_BCKP(equipment_id, lm2_seq, site_id, alias, equipment_type, slave, ip_address, observations, washer_count, tunnel_count, w_machine_chnl_count, pump_count,channel_count, is_active, created_by, created_date, modified_by, modified_date, version, file_id, device_id)
values(old.equipment_id, old.lm2_seq, old.site_id, old.alias, old.equipment_type, old.slave, old.ip_address, old.observations, old.washer_count, old.tunnel_count, old.w_machine_chnl_count, old.pump_count,old.channel_count, old.is_active, old.created_by, old.created_date, old.modified_by, old.modified_date, old.version, old.file_id, old.device_id);

ALTER TABLE `hydro`.`tunnel_master` 
ADD COLUMN `uid` VARCHAR(100) NULL AFTER `modified_date`;

ALTER TABLE `hydro`.`tunnel_master_bckp` 
ADD COLUMN `uid` VARCHAR(100) NULL AFTER `modified_date`;

DROP trigger `hydro`.TRIG_TUNNEL_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_TUNNEL_MASTER_DELETE;

create trigger `hydro`.TRIG_TUNNEL_MASTER_UPDATE
after update on `hydro`.TUNNEL_MASTER
for each row
insert into `hydro`.TUNNEL_MASTER_BCKP(tunnel_id, equipment_id, lm2_seq, name, `load`, modules_count, module_count_dosif, load_min, load_max, formula_id, ltr, cellular_minutes, modules_per_channel, created_by, created_date, modified_by, modified_date, uid)
values(NEW.tunnel_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.load, NEW.modules_count, NEW.module_count_dosif, NEW.load_min, NEW.load_max, NEW.formula_id, NEW.ltr, NEW.cellular_minutes, NEW.modules_per_channel, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid);

create trigger `hydro`.TRIG_TUNNEL_MASTER_DELETE
after delete on `hydro`.TUNNEL_MASTER
for each row
insert into `hydro`.TUNNEL_MASTER_BCKP(tunnel_id, equipment_id, lm2_seq, name, `load`, modules_count, module_count_dosif, load_min, load_max, formula_id, ltr, cellular_minutes, modules_per_channel, created_by, created_date, modified_by, modified_date,uid)
values(old.tunnel_id, old.equipment_id, old.lm2_seq, old.name, old.load, old.modules_count, old.module_count_dosif, old.load_min, old.load_max, old.formula_id, old.ltr, old.cellular_minutes, old.modules_per_channel, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid);

ALTER TABLE `hydro`.`washer_master` 
ADD COLUMN `uid` VARCHAR(100) NULL AFTER `modified_date`;

ALTER TABLE `hydro`.`washer_master_bckp` 
ADD COLUMN `uid` VARCHAR(100) NULL AFTER `modified_date`;

DROP trigger `hydro`.TRIG_WASHER_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_WASHER_MASTER_DELETE;

create trigger `hydro`.TRIG_WASHER_MASTER_UPDATE
after update on `hydro`.WASHER_MASTER
for each row
insert into `hydro`.WASHER_MASTER_BCKP(washer_id, equipment_id, lm2_seq, name, `load`, modifiable_load, ltr_drag, cellular_minutes, id_formula, work_mode, reset_mode, reset_signal, reset_formula, unused_machine, unused_time_delay, unused_timeout, t_acceptation, t_repetition, t_lock, type_programmer, signal_count, signal_voltage, signal_connection, observation, created_by, created_date, modified_by, modified_date, uid)
values(NEW.washer_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.load, NEW.modifiable_load, NEW.ltr_drag, NEW.cellular_minutes, NEW.id_formula, NEW.work_mode, NEW.reset_mode, NEW.reset_signal, NEW.reset_formula, NEW.unused_machine, NEW.unused_time_delay, NEW.unused_timeout, NEW.t_acceptation, NEW.t_repetition, NEW.t_lock, NEW.type_programmer, NEW.signal_count, NEW.signal_voltage, NEW.signal_connection, NEW.observation, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid);

create trigger `hydro`.TRIG_WASHER_MASTER_DELETE
after delete on `hydro`.WASHER_MASTER
for each row
insert into `hydro`.WASHER_MASTER_BCKP(washer_id, equipment_id, lm2_seq, name, `load`, modifiable_load, ltr_drag, cellular_minutes, id_formula, work_mode, reset_mode, reset_signal, reset_formula, unused_machine, unused_time_delay, unused_timeout, t_acceptation, t_repetition, t_lock, type_programmer, signal_count, signal_voltage, signal_connection, observation, created_by, created_date, modified_by, modified_date, uid)
values(old.washer_id, old.equipment_id, old.lm2_seq, old.name, old.load, old.modifiable_load, old.ltr_drag, old.cellular_minutes, old.id_formula, old.work_mode, old.reset_mode, old.reset_signal, old.reset_formula, old.unused_machine, old.unused_time_delay, old.unused_timeout, old.t_acceptation, old.t_repetition, old.t_lock, old.type_programmer, old.signal_count, old.signal_voltage, old.signal_connection, old.observation, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid);

ALTER TABLE `hydro`.`product_master` 
ADD COLUMN `uid` VARCHAR(100) NULL AFTER `modified_date`;

ALTER TABLE `hydro`.`product_master_bckp` 
ADD COLUMN `uid` VARCHAR(100) NULL AFTER `modified_date`;

DROP trigger `hydro`.TRIG_PRODUCT_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_PRODUCT_MASTER_DELETE;

create trigger `hydro`.TRIG_PRODUCT_MASTER_UPDATE
after update on `hydro`.PRODUCT_MASTER
for each row
insert into `hydro`.PRODUCT_MASTER_BCKP(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow, frequency, docification_mode, priority, contact, alarms_ignored, percentage, drag_type, pump_speed, format, price, calibration, color1, color2, created_by, created_date, modified_by, modified_date, uid)
values(NEW.product_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.density, NEW.concentration, NEW.kf, NEW.flow, NEW.frequency, NEW.docification_mode, NEW.priority, NEW.contact, NEW.alarms_ignored, NEW.percentage, NEW.drag_type, NEW.pump_speed, NEW.format, NEW.price, NEW.calibration, NEW.color1, NEW.color2, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid);

create trigger `hydro`.TRIG_PRODUCT_MASTER_DELETE
after delete on `hydro`.PRODUCT_MASTER
for each row
insert into `hydro`.PRODUCT_MASTER_BCKP(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow, frequency, docification_mode, priority, contact, alarms_ignored, percentage, drag_type, pump_speed, format, price, calibration, color1, color2, created_by, created_date, modified_by, modified_date, uid)
values(old.product_id, old.equipment_id, old.lm2_seq, old.name, old.density, old.concentration, old.kf, old.flow, old.frequency, old.docification_mode, old.priority, old.contact, old.alarms_ignored, old.percentage, old.drag_type, old.pump_speed, old.format, old.price, old.calibration, old.color1, old.color2, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid);

ALTER TABLE `hydro`.`formula_master` 
ADD COLUMN `uid` VARCHAR(100) NULL AFTER `modified_date`;

ALTER TABLE `hydro`.`formula_master_bckp` 
ADD COLUMN `uid` VARCHAR(100) NULL AFTER `modified_date`;

DROP trigger `hydro`.TRIG_FORMULA_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_FORMULA_MASTER_DELETE;

create trigger `hydro`.TRIG_FORMULA_MASTER_UPDATE
after update on `hydro`.FORMULA_MASTER
for each row
insert into `hydro`.FORMULA_MASTER_BCKP(formula_id, equipment_id, lm2_seq, name, `load`, phases, color, created_by, created_date, modified_by, modified_date, uid)
values(NEW.formula_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.load, NEW.phases, NEW.color, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid);

create trigger `hydro`.TRIG_FORMULA_MASTER_DELETE
after delete on `hydro`.FORMULA_MASTER
for each row
insert into `hydro`.FORMULA_MASTER_BCKP(formula_id, equipment_id, lm2_seq, name, `load`, phases, color, created_by, created_date, modified_by, modified_date, uid)
values(old.formula_id, old.equipment_id, old.lm2_seq, old.name, old.load, old.phases, old.color, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid);

ALTER TABLE `hydro`.`water_master` 
ADD COLUMN `uid` VARCHAR(100) NULL AFTER `modified_date`;

ALTER TABLE `hydro`.`water_master_bckp` 
ADD COLUMN `uid` VARCHAR(100) NULL AFTER `modified_date`;

DROP trigger `hydro`.TRIG_WATER_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_WATER_MASTER_DELETE;

create trigger `hydro`.TRIG_WATER_MASTER_UPDATE
after update on `hydro`.WATER_MASTER
for each row
insert into `hydro`.WATER_MASTER_BCKP(water_id, equipment_id, name, kf,lm2_seq, flow, water_time, cellphone_minute, docification_mode, seperation_ml, ignored_alarms, percentage, diameter, pump_type, created_by, created_date, modified_by, modified_date, uid)
values(NEW.water_id, NEW.equipment_id, NEW.name, NEW.kf,NEW.lm2_seq, NEW.flow, NEW.water_time, NEW.cellphone_minute, NEW.docification_mode, NEW.seperation_ml, NEW.ignored_alarms, NEW.percentage, NEW.diameter, NEW.pump_type, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid);

create trigger `hydro`.TRIG_WATER_MASTER_DELETE
after delete on `hydro`.WATER_MASTER
for each row
insert into `hydro`.WATER_MASTER_BCKP(water_id, equipment_id, name, kf,lm2_seq, flow, water_time, cellphone_minute, docification_mode, seperation_ml, ignored_alarms, percentage, diameter, pump_type, created_by, created_date, modified_by, modified_date, uid)
values(old.water_id, old.equipment_id, old.name, old.kf, old.lm2_seq,old.flow, old.water_time, old.cellphone_minute, old.docification_mode, old.seperation_ml, old.ignored_alarms, old.percentage, old.diameter, old.pump_type, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid);

CREATE TABLE IF NOT EXISTS `hydro`.`tunnel_module_product_association` (
  `id` VARCHAR(50) NOT NULL,
  `tunnel_id` VARCHAR(50) NULL,
  `module_id` VARCHAR(50) NULL,
  `product_id` VARCHAR(45) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `tunnel_id_ref_idx` (`tunnel_id` ASC),
  CONSTRAINT `tunnel_id_ref`
    FOREIGN KEY (`tunnel_id`)
    REFERENCES `hydro`.`TUNNEL_MASTER` (`tunnel_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`tunnel_module_product_association_bckp` (
  `id` VARCHAR(50) NOT NULL,
  `tunnel_id` VARCHAR(50) NULL,
  `module_id` VARCHAR(50) NULL,
  `product_id` VARCHAR(45) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`))
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_Module_Product_UPDATE
AFTER UPDATE ON `hydro`.`tunnel_module_product_association`
for each row
insert into `hydro`.`tunnel_module_product_association_bckp`(id, tunnel_id, module_id, product_id, created_by, created_date, modified_by, modified_date)
values(NEW.id, NEW.tunnel_id, NEW.module_id, NEW.product_id,  NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE TRIGGER `hydro`.TRIG_Module_Product_DELETE
after delete on `hydro`.`tunnel_module_product_association`
for each row
insert into `hydro`.`tunnel_module_product_association_bckp`(id, tunnel_id, module_id, product_id, created_by, created_date, modified_by, modified_date)
values(old.id, old.tunnel_id, old.module_id, old.product_id, old.created_by, old.created_date, old.modified_by, old.modified_date);

ALTER TABLE `hydro`.`observation_master` 
ADD COLUMN `device_id` VARCHAR(100) NULL AFTER `year`;

ALTER TABLE `hydro`.`observation_master_bckp` 
ADD COLUMN `device_id` VARCHAR(100) NULL AFTER `year`;

DROP trigger `hydro`.TRIG_OBSERVATION_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_OBSERVATION_MASTER_DELETE;

create trigger `hydro`.TRIG_OBSERVATION_MASTER_UPDATE
after update on `hydro`.OBSERVATION_MASTER
for each row
insert into `hydro`.OBSERVATION_MASTER_BCKP(observation_id,site_id,lm2_seq, observation, recommendation, created_by, created_date, modified_by, modified_date, equipment_id, month, year, device_id)
values(NEW.observation_id,NEW.site_id,NEW.lm2_seq, NEW.observation, NEW.recommendation, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.equipment_id, NEW.month, NEW.year, NEW.device_id);

create trigger `hydro`.TRIG_OBSERVATION_MASTER_DELETE
after delete on `hydro`.OBSERVATION_MASTER
for each row
insert into `hydro`.OBSERVATION_MASTER_BCKP(observation_id,site_id,lm2_seq, observation, recommendation, created_by, created_date, modified_by, modified_date, equipment_id, month, year, device_id)
values(old.observation_id,old.site_id,old.lm2_seq, old.observation, old.recommendation, old.created_by, old.created_date, old.modified_by, old.modified_date, old.equipment_id, old.month, old.year, old.device_id);

ALTER TABLE `hydro`.`site_master` 
ADD COLUMN `streaming_enabled` TINYINT(4) NULL DEFAULT 0 AFTER `alert_setting`;

ALTER TABLE `hydro`.`site_master_bckp` 
ADD COLUMN `streaming_enabled` TINYINT(4) NULL DEFAULT 0 AFTER `alert_setting`;

DROP trigger `hydro`.`TRIG_Site_Master_UPDATE`;
DROP trigger `hydro`.`TRIG_Site_Master_DELETE`;

create trigger `hydro`.`TRIG_Site_Master_UPDATE`
after update on `hydro`.`SITE_MASTER`
for each row 
insert into `hydro`.`SITE_MASTER_BCKP`(site_id, site_owner, business_id, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit,washer_turn_minute,washer_idle_minute,washer_efficiency_threshold,tunnel_turn_minute,tunnel_idle_minute,tunnel_efficiency_threshold,time_zone,alert_setting, streaming_enabled)
values (NEW.site_id, NEW.site_owner, business_id, NEW.site_name, NEW.latitude, NEW.longitude, NEW.description, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.is_active, NEW.is_deleted, NEW.address1, NEW.address2, NEW.city, NEW.state, NEW.zipcode, NEW.site_unique_id, NEW.country,NEW.file_id,NEW.index_created,NEW.metric_unit,NEW.washer_turn_minute,NEW.washer_idle_minute,NEW.washer_efficiency_threshold,NEW.tunnel_turn_minute,NEW.tunnel_idle_minute,NEW.tunnel_efficiency_threshold,NEW.time_zone, NEW.alert_setting, NEW.streaming_enabled);

CREATE trigger `hydro`.`TRIG_Site_Master_DELETE`
after delete on `hydro`.`SITE_MASTER`
for each row
insert into `hydro`.`SITE_MASTER_BCKP`(site_id, site_owner, business_id, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit,washer_turn_minute,washer_idle_minute,washer_efficiency_threshold,tunnel_turn_minute,tunnel_idle_minute,tunnel_efficiency_threshold,time_zone,alert_setting,streaming_enabled)
values (old.site_id, old.site_owner, business_id, old.site_name, old.latitude, old.longitude, old.description, old.created_by, old.created_date, old.modified_by, old.modified_date, 0, 1, old.address1, old.address2, old.city, old.state, old.zipcode, old.site_unique_id,old.file_id,old.index_created,old.metric_unit,old.washer_turn_minute,old.washer_idle_minute,old.washer_efficiency_threshold,old.tunnel_turn_minute,old.tunnel_idle_minute,old.tunnel_efficiency_threshold,old.time_zone,old.alert_setting,old.streaming_enabled);


























