CREATE TABLE IF NOT EXISTS `hydro`.`BUSINESS_MASTER` (
  `business_id` VARCHAR(100) NOT NULL,
  `name` VARCHAR(100) NULL,
  `business_type` VARCHAR(100) NULL,
  `headquarters` VARCHAR(100) NULL,
  `description` VARCHAR(1000) NULL,
  `address1` VARCHAR(500) NULL,
  `address2` VARCHAR(500) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_active` TINYINT NULL DEFAULT 1,
  `is_deleted` TINYINT NULL DEFAULT 0,
  `state` VARCHAR(100) NULL,
  `zipcode` VARCHAR(20) NULL,
  `city` VARCHAR(100) NULL,
  `country` VARCHAR(100) NULL,
  PRIMARY KEY (`business_id`))
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`BUSINESS_MASTER_BCKP` (
  `business_id` VARCHAR(100) NOT NULL,
  `name` VARCHAR(100) NULL,
  `business_type` VARCHAR(100) NULL,
  `headquarters` VARCHAR(100) NULL,
  `description` VARCHAR(1000) NULL,
  `address1` VARCHAR(500) NULL,
  `address2` VARCHAR(500) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_active` TINYINT NULL DEFAULT 1,
  `is_deleted` TINYINT NULL DEFAULT 0,
  `state` VARCHAR(100) NULL,
  `zipcode` VARCHAR(20) NULL,
  `city` VARCHAR(100) NULL,
  `country` VARCHAR(100) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_Business_UPDATE
AFTER UPDATE ON `hydro`.BUSINESS_MASTER
for each row
insert into `hydro`.BUSINESS_MASTER_BCKP(business_id, name, business_type, headquarters, description, address1, address2, created_by, created_date, modified_by, modified_date, is_active, is_deleted, state, zipcode, city, country)
values(NEW.business_id, NEW.name, NEW.business_type, NEW.headquarters, NEW.description, NEW.address1, NEW.address2, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.is_active, NEW.is_deleted, NEW.state, NEW.zipcode, NEW.city, NEW.country);

CREATE TRIGGER `hydro`.TRIG_Business_DELETE
after delete on `hydro`.BUSINESS_MASTER
for each row
insert into `hydro`.BUSINESS_MASTER_BCKP(business_id, name, business_type, headquarters, description, address1, address2, created_by, created_date, modified_by, modified_date, is_active, is_deleted, state, zipcode, city, country)
values(old.business_id, old.name, old.business_type, old.headquarters, old.description, old.address1, old.address2, old.created_by, old.created_date, old.modified_by, old.modified_date, 0, 1, old.state, old.zipcode, old.city, old.country);

CREATE TABLE IF NOT EXISTS `hydro`.`SITE_MASTER` (
  `site_id` VARCHAR(100) NOT NULL,
  `site_owner` VARCHAR(100) NULL,
  `business_id` VARCHAR(100) NULL,
  `site_name` VARCHAR(100) NULL,
  `latitude` DOUBLE NULL,
  `longitude` DOUBLE NULL,
  `description` VARCHAR(1000) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_active` TINYINT NULL DEFAULT 1,
  `is_deleted` TINYINT NULL DEFAULT 0,
  `address1` VARCHAR(500) NULL,
  `address2` VARCHAR(500) NULL,
  `city` VARCHAR(100) NULL,
  `state` VARCHAR(100) NULL,
  `zipcode` VARCHAR(20) NULL,
  `site_unique_id` VARCHAR(100) NULL,
  `country` VARCHAR(100) NULL,
  `file_id` VARCHAR(100) NULL,
  `index_created` TINYINT NULL,
  `metric_unit` VARCHAR(20) NULL DEFAULT '1',
  `washer_turn_minute` INT(100) NULL DEFAULT 10,
  `washer_idle_minute` INT(100) NULL DEFAULT 20,
  `washer_efficiency_threshold` DOUBLE NULL DEFAULT 80,
  `tunnel_turn_minute` INT(100) NULL DEFAULT 2,
  `tunnel_idle_minute` INT NULL DEFAULT 5,
  `tunnel_efficiency_threshold` DOUBLE NULL DEFAULT 80,
  `time_zone` VARCHAR(100) NULL,
  `alert_setting` TINYINT NULL DEFAULT 0,
  `streaming_enabled` TINYINT(4) NULL DEFAULT 0,
  PRIMARY KEY (`site_id`),
  INDEX `Business Foreign Key_idx` (`site_owner` ASC),
  INDEX `businessIDConst_idx` (`business_id`),
  CONSTRAINT `BusinessForeignKey0`
    FOREIGN KEY (`site_owner`)
    REFERENCES `hydro`.`BUSINESS_MASTER` (`business_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `businessIDConst` 
	FOREIGN KEY (`business_id`) 
	REFERENCES `hydro`.`business_master` (`business_id`) 
	ON DELETE NO ACTION 
	ON UPDATE NO ACTION)
  ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;
  
CREATE TABLE IF NOT EXISTS `hydro`.`SITE_MASTER_BCKP` (
  `site_id` VARCHAR(100) NOT NULL,
  `site_owner` VARCHAR(100) NULL,
  `business_id` VARCHAR(100) NULL,
  `site_name` VARCHAR(100) NULL,
  `latitude` DOUBLE NULL,
  `longitude` DOUBLE NULL,
  `description` VARCHAR(1000) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_active` TINYINT NULL DEFAULT 1,
  `is_deleted` TINYINT NULL DEFAULT 0,
  `address1` VARCHAR(500) NULL,
  `address2` VARCHAR(500) NULL,
  `city` VARCHAR(100) NULL,
  `state` VARCHAR(100) NULL,
  `zipcode` VARCHAR(20) NULL,
  `site_unique_id` VARCHAR(100) NULL,
  `country` VARCHAR(100) NULL,
  `file_id` VARCHAR(100) NULL,
  `index_created` TINYINT NULL,
  `metric_unit` VARCHAR(20) NULL DEFAULT '1',
  `washer_turn_minute` INT(100) NULL DEFAULT 0,
  `washer_idle_minute` INT(100) NULL DEFAULT 0,
  `washer_efficiency_threshold` DOUBLE NULL DEFAULT 0,
  `tunnel_turn_minute` INT(100) NULL DEFAULT 0,
  `tunnel_idle_minute` INT NULL DEFAULT 0,
  `tunnel_efficiency_threshold` DOUBLE NULL DEFAULT 0,
  `time_zone` VARCHAR(100) NULL,
  `alert_setting` TINYINT NULL DEFAULT 0,
  `streaming_enabled` TINYINT(4) NULL DEFAULT 0,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
  ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.`TRIG_Site_Master_UPDATE`
after update on `hydro`.`SITE_MASTER`
for each row 
insert into `hydro`.`SITE_MASTER_BCKP`(site_id, site_owner, business_id, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit,washer_turn_minute,washer_idle_minute,washer_efficiency_threshold,tunnel_turn_minute,tunnel_idle_minute,tunnel_efficiency_threshold,time_zone,alert_setting, streaming_enabled)
values (NEW.site_id, NEW.site_owner, business_id, NEW.site_name, NEW.latitude, NEW.longitude, NEW.description, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.is_active, NEW.is_deleted, NEW.address1, NEW.address2, NEW.city, NEW.state, NEW.zipcode, NEW.site_unique_id, NEW.country,NEW.file_id,NEW.index_created,NEW.metric_unit,NEW.washer_turn_minute,NEW.washer_idle_minute,NEW.washer_efficiency_threshold,NEW.tunnel_turn_minute,NEW.tunnel_idle_minute,NEW.tunnel_efficiency_threshold,NEW.time_zone, NEW.alert_setting, NEW.streaming_enabled);

CREATE trigger `hydro`.`TRIG_Site_Master_DELETE`
after delete on `hydro`.`SITE_MASTER`
for each row
insert into `hydro`.`SITE_MASTER_BCKP`(site_id, site_owner, business_id, site_name, latitude, longitude, description, created_by, created_date, modified_by, modified_date, is_active, is_deleted, address1, address2, city, state, zipcode, site_unique_id, country, file_id, index_created, metric_unit,washer_turn_minute,washer_idle_minute,washer_efficiency_threshold,tunnel_turn_minute,tunnel_idle_minute,tunnel_efficiency_threshold,time_zone,alert_setting,streaming_enabled)
values (old.site_id, old.site_owner, business_id, old.site_name, old.latitude, old.longitude, old.description, old.created_by, old.created_date, old.modified_by, old.modified_date, 0, 1, old.address1, old.address2, old.city, old.state, old.zipcode, old.site_unique_id,old.file_id,old.index_created,old.metric_unit,old.washer_turn_minute,old.washer_idle_minute,old.washer_efficiency_threshold,old.tunnel_turn_minute,old.tunnel_idle_minute,old.tunnel_efficiency_threshold,old.time_zone,old.alert_setting,old.streaming_enabled);

CREATE TABLE IF NOT EXISTS `hydro`.`USER_MASTER` (
  `user_id` VARCHAR(100) NOT NULL,
  `user_role` VARCHAR(100) NULL,
  `business_id` VARCHAR(100) NULL,
  `password_hash` VARCHAR(100) NULL,
  `first_name` VARCHAR(100) NULL,
  `last_name` VARCHAR(100) NULL,
  `user_name` VARCHAR(100) NULL,
  `middle_name` VARCHAR(100) NULL,
  `profile_image` VARCHAR(250) NULL,
  `email` VARCHAR(100) NULL,
  `change_password` TINYINT NULL,
  `org_type` VARCHAR(100) NULL,
  `site_id` VARCHAR(100) NULL,
  `jwt_token` VARCHAR(1000) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_active` TINYINT NULL DEFAULT 1,
  `is_deleted` TINYINT NULL DEFAULT 0,
  `phone_number` VARCHAR(100) NULL,
  `address1` VARCHAR(500) NULL,
  `address2` VARCHAR(500) NULL,
  `state` VARCHAR(100) NULL,
  `zipcode` VARCHAR(20) NULL,
  `city` VARCHAR(100) NULL,
  `country` VARCHAR(100) NULL,
  `role_id` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`user_id`),
  INDEX `Business_idx` (`business_id` ASC),
  INDEX `Site_idx` (`site_id` ASC),
  CONSTRAINT `Business`
    FOREIGN KEY (`business_id`)
    REFERENCES `hydro`.`BUSINESS_MASTER` (`business_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `Site`
    FOREIGN KEY (`site_id`)
    REFERENCES `hydro`.`SITE_MASTER` (`site_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`USER_MASTER_BCKP` (
 `user_id` VARCHAR(100) NOT NULL,
  `user_role` VARCHAR(100) NULL,
  `business_id` VARCHAR(100) NULL,
  `password_hash` VARCHAR(100) NULL,
  `first_name` VARCHAR(100) NULL,
  `last_name` VARCHAR(100) NULL,
  `user_name` VARCHAR(100) NULL,
  `middle_name` VARCHAR(100) NULL,
  `profile_image` VARCHAR(250) NULL,
  `email` VARCHAR(100) NULL,
  `change_password` TINYINT NULL,
  `org_type` VARCHAR(100) NULL,
  `site_id` VARCHAR(100) NULL,
  `jwt_token` VARCHAR(1000) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `is_active` TINYINT NULL DEFAULT 1,
  `is_deleted` TINYINT NULL DEFAULT 0,
  `phone_number` VARCHAR(100) NULL,
  `address1` VARCHAR(500) NULL,
  `address2` VARCHAR(500) NULL,
  `state` VARCHAR(100) NULL,
  `zipcode` VARCHAR(20) NULL,
  `city` VARCHAR(100) NULL,
  `country` VARCHAR(100) NULL,
  `role_id` VARCHAR(100) NOT NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_User_Update
after update on `hydro`.USER_MASTER
for each row 
insert into `hydro`.USER_MASTER_BCKP(user_id, user_role, business_id, password_hash, first_name, last_name,user_name, middle_name, profile_image, email, change_password, org_type, site_id, jwt_token, created_by, created_date, modified_by, modified_date, is_active, is_deleted, phone_number, address1, address2, state, zipcode, city, country,role_id)
values(New.user_id, New.user_role, New.business_id, New.password_hash, New.first_name, New.last_name,NEW.user_name,NEW.middle_name, New.profile_image, New.email, New.change_password, New.org_type, New.site_id, New.jwt_token, New.created_by, New.created_date, New.modified_by, New.modified_date, New.is_active, New.is_deleted, New.phone_number, New.address1, New.address2, New.state, New.zipcode, New.city, NEW.country, NEW.role_id);

create trigger `hydro`.TRIG_User_DELETE
after delete on `hydro`.USER_MASTER 
for each row 
insert into `hydro`.USER_MASTER_BCKP(user_id, user_role, business_id, password_hash, first_name, last_name,user_name, middle_name, profile_image, email, change_password, org_type, site_id, jwt_token, created_by, created_date, modified_by, modified_date, is_active, is_deleted, phone_number, address1, address2, state, zipcode, city, country, role_id)
values(old.user_id, old.user_role, old.business_id, old.password_hash, old.first_name, old.last_name, old.user_name,old.middle_name, old.profile_image, old.email, old.change_password, old.org_type, old.site_id, old.jwt_token, old.created_by, old.created_date, old.modified_by, old.modified_date, 0, 1, old.phone_number, old.address1, old.address2, old.state, old.zipcode, old.city, old.country, old.role_id);

CREATE TABLE IF NOT EXISTS `hydro`.ROLE_MASTER (
  `role_id` VARCHAR(100) NOT NULL,
  `user_role` VARCHAR(100) DEFAULT NULL,
  `clearance_level` int(11) DEFAULT NULL,
  `org_type` VARCHAR(100) DEFAULT NULL,
  `created_by` VARCHAR(100) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) DEFAULT NULL,
  `modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.ROLE_MASTER_BCKP (
  `role_id` VARCHAR(100) NOT NULL,
  `user_role` VARCHAR(100) DEFAULT NULL,
  `clearance_level` int(11) DEFAULT NULL,
  `org_type` VARCHAR(100) DEFAULT NULL,
  `created_by` VARCHAR(100) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) DEFAULT NULL,
  `modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

INSERT INTO `hydro`.`role_master` (`role_id`, `user_role`, `clearance_level`,`org_type`) VALUES ('1', 'HYDRO ADMIN', '1','HYDRO'),
('2', 'CHEMICAL COMPANY ADMIN', '4','CHEMICAL COMPANY'),
('3', 'CHEMICAL COMPANY MANAGER', '5','CHEMICAL COMPANY'),
('4', 'CHEMICAL COMPANY USER', '6','CHEMICAL COMPANY'),
('5', 'CHEMICAL COMPANY DISTRIBUTOR MANAGER', '7','CHEMICAL COMPANY'),
('6', 'CHEMICAL COMPANY DISTRIBUTOR USER', '8','CHEMICAL COMPANY'),
('7', 'SITE MANAGER', '9','SITE'),
('8', 'SITE USER', '10','SITE'),
('9', 'HYDRO TECHNICIAN', '2', 'HYDRO'),
('10', 'HYDRO USER', '3', 'HYDRO');


create trigger `hydro`.TRIG_Role_UPDATE
after update on `hydro`.ROLE_MASTER
for each row
insert into `hydro`.ROLE_MASTER_BCKP(role_id, user_role, clearance_level, org_type, created_by, created_date, modified_by, modified_date)
values(NEW.role_id, NEW.user_role, NEW.clearance_level, NEW.org_type, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_Role_DELETE
after delete on `hydro`.ROLE_MASTER
for each row
insert into `hydro`.ROLE_MASTER_BCKP(role_id, user_role, clearance_level, org_type, created_by, created_date, modified_by, modified_date)
values(old.role_id, old.user_role, old.clearance_level, old.org_type,old.created_by, old.created_date, old.modified_by, old.modified_date);



CREATE TABLE IF NOT EXISTS `hydro`.`privilege_master` (
  `privilege_id` VARCHAR(100) NOT NULL,
  `privilege_name` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`privilege_id`))
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`privilege_master_bckp` (
  `privilege_id` VARCHAR(100) NULL,
  `privilege_name` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_Privilege_UPDATE
after update on `hydro`.`privilege_master`
for each row
insert into `hydro`.`privilege_master_bckp`(privilege_id, privilege_name, created_by, created_date, modified_by, modified_date)
values(NEW.privilege_id, NEW.privilege_name, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_Privilege_DELETE
after delete on `hydro`.`privilege_master`
for each row
insert into `hydro`.`privilege_master_bckp`(privilege_id, privilege_name, created_by, created_date, modified_by, modified_date)
values(old.privilege_id, old.privilege_name, old.created_by, old.created_date, old.modified_by, old.modified_date);

INSERT INTO `hydro`.`privilege_master` (`privilege_id`,`privilege_name`) VALUES 
    ('1', 'SITE_LIST'),
    ('2', 'SITE_VIEW'),
    ('3', 'SITE_UPDATE'),
    ('4', 'SITE_CREATE'),
    ('5', 'SITE_DELETE'),
    ('6', 'ACCOUNT_DELETE'),
    ('7', 'ACCOUNT_LIST'),
    ('8', 'ACCOUNT_UPDATE'),
    ('9', 'ACCOUNT_CREATE'),
    ('10', 'ACCOUNT_VIEW'),
    ('11', 'COMPANY_LIST'),
    ('12', 'COMPANY_VIEW'),
    ('13', 'COMPANY_DELETE'),
    ('14', 'COMPANY_CREATE'),
    ('15', 'COMPANY_UPDATE'),
    ('16', 'USER_LIST'),
    ('17', 'USER_VIEW'),
    ('18', 'USER_DELETE'),
    ('19', 'USER_CREATE'),
    ('20', 'USER_UPDATE'),
    ('21', 'OBSERVATION_RECOMMENDATION_VIEW'),
    ('22', 'OBSERVATION_RECOMMENDATION_UPDATE'),
    ('23', 'OBSERVATION_RECOMMENDATION_DELETE'),
    ('24', 'OBSERVATION_RECOMMENDATION_CREATE'),
    ('25', 'FILE_UPLOAD'),
    ('26', 'FILE_HISTORY'),
    ('27', 'GENERATE_REPORT'),
    ('28', 'COST_SUMMARY_EST_COST'),
    ('29', 'PRODUCTION_SUMMARY_LBS_WASHED'),
    ('30', 'PRODUCTION_SUMMARY_LOADS_WASHED'),
    ('31', 'CHEMICAL_SUMMARY_ACTUAL_USAGE'),
    ('32', 'CHEMICAL_SUMMARY_EST_USAGE'),
    ('33', 'COST_SUMMARY_ABS_COST'),
    ('34', 'COST_SUMMARY_COST_PER_CWT'),
    ('35', 'COST_SUMMARY_ERROR'),
    ('36', 'WASHER_PRODUCTION_SUMMARY_REPORT'),
    ('37', 'CHEMICAL_SUMMARY_REPORT'),
    ('38', 'COST_SUMMARY_REPORT'),
    ('39', 'ALARM_SUMMARY_REPORT'),
    ('40', 'FULL_PRIVILEGE'),
    ('41', 'CREATE_SAME_LEVEL_USER'),
    ('42', 'SITE_FULL_EDIT'),
    ('43', 'OBS_REC_REPORT'),
    ('44', 'REAL_TIME_REPORT'),
    ('45', 'ALERT_SETTING'),
    ('46', 'DEVICE_MANAGEMENT_CREATE'),
    ('47', 'DEVICE_MANAGEMENT_DELETE'),
    ('48', 'DEVICE_MANAGEMENT_LIST'),
    ('49', 'DEVICE_MANAGEMENT_UPDATE'),
    ('50', 'DEVICE_MANAGEMENT_VIEW');


CREATE TABLE IF NOT EXISTS `hydro`.`role_privilege_association` (
  `privilege_id` VARCHAR(100) NOT NULL,
  `role_id` VARCHAR(100) NOT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `RoleConstraint_idx` (`role_id` ASC),
  CONSTRAINT `PrivilegeConstraint`
    FOREIGN KEY (`privilege_id`)
    REFERENCES `hydro`.`privilege_master` (`privilege_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `RoleConstraint`
    FOREIGN KEY (`role_id`)
    REFERENCES `hydro`.`role_master` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`role_privilege_association_bckp` (
  `privilege_id` VARCHAR(100) NULL,
  `role_id` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_Role_Privilege_UPDATE
after update on `hydro`.`role_privilege_association`
for each row
insert into `hydro`.`role_privilege_association_bckp`(privilege_id, role_id, created_by, created_date, modified_by, modified_date)
values(NEW.privilege_id, NEW.role_id, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_Role_Privilege_DELETE
after delete on `hydro`.`role_privilege_association`
for each row
insert into `hydro`.`role_privilege_association_bckp`(privilege_id, role_id, created_by, created_date, modified_by, modified_date)
values(old.privilege_id, old.role_id, old.created_by, old.created_date, old.modified_by, old.modified_date);

INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES 
('1', '1'),('2', '1'),('3', '1'),('4', '1'),
('7', '1'),('8', '1'),('9', '1'),('10', '1'),
('11', '1'),('12', '1'),('14', '1'),('15', '1'),
('16', '1'),('17', '1'),('19', '1'),('20', '1'),
('21', '1'),('22', '1'),('23', '1'),('24', '1'),
('25', '1'),('26', '1'),('27', '1'),('28', '1'),('29', '1'),
('30', '1'),('31', '1'),('32', '1'),('33', '1'),('34', '1'),
('35', '1'),('36','1'),('37','1'),('38','1'),('39','1'),('40', '1'),('41','1'),('42','1'),
('43','1'),('44', '1'),('45', '1'),('46', '1'),('47', '1'),('48', '1'),('49', '1'),('50', '1')

('1', '2'),('2', '2'),('3','2'),('7', '2'),
('10', '2'),('11', '2'),('12', '2'),('15', '2'),('16', '2'),
('17', '2'),('19', '2'),('20', '2'),('21', '2'),
('25', '2'),('26', '2'),('27', '2'),('29', '2'),
('30', '2'),('31', '2'),('33', '2'),('34', '2'),
('35', '2'),('36','2'),('37','2'),('38','2'),
('39','2'),('40', '2'),('28', '2'),('32', '2'),
('41','2'),('43','2'),('44', '2'),('45', '2'),

('1', '3'), ('2', '3'), ('3', '3'), ('7', '3'), 
('10', '3'),('11', '3'),('12', '3'), ('16', '3'),
('17', '3'), ('19', '3'), ('20', '3'),('21', '3'),
('25','3'),('26','3'),('27','3'),('29', '3'), 
('30', '3'), ('31', '3'),('33', '3'), ('34', '3'),
('35', '3'), ('36', '3'), ('37', '3'), ('38', '3'),
('39', '3'),('28','3'),('32','3'),('43','3'),('44', '3'),

('1','4'),('2','4'),('7','4'),('10','4'),('11','4'),
('12', '4'),('16','4'),('17', '4'),('19','4'),
('20','4'),('21','4'),('25','4'),('26','4'),
('27','4'),('28','4'),('29','4'),('30','4'),
('31','4'),('32','4'),('33','4'),('34','4'),
('35','4'),('36','4'),('37','4'),('38','4'),
('39','4'),('43','4'),('44', '4'),

('1','5'),('2','5'),('3','5'),('7','5'),
('10','5'),('11','5'),('12','5'),('16','5'),
('17','5'),('19','5'),('20','5'),('25','5'),
('26','5'),('27','5'),('28','5'),('29','5'),('30','5'),
('31','5'),('32','5'),('33','5'),('34','5'),('35','5'),
('36','5'),('37','5'),('38','5'),('39','5'),('44', '5'),

('1','6'),('2','6'),('7','6'),('10','6'),
('11','6'),('12','6'),('16','6'),('17','6'),
('19','6'),('25','6'),('26','6'),('27','6'),('28','6'),
('29','6'),('30','6'),('31','6'),('32','6'),('33','6'),
('34','6'),('35','6'),('36','6'),
('37','6'),('38','6'),('39','6'),('44', '6'),

('1','7'),('2','7'),('3','7'),('7','7'),
('10','7'),('11','7'),('12','7'),('16','7'),
('17','7'),('19','7'),('25','7'),('26','7'),
('27','7'),('29','7'),('30','7'),('31','7'),
('36','7'),('37','7'),('39','7'),('44', '7'),

('1','8'),('2','8'),('7','8'),('10','8'),
('11','8'),('12','8'),('16','8'),('17','8'),
('25','8'),('26','8'),('27','8'),('29','8'),
('30','8'),('31','8'),('36','8'),('37','8'),('39','8'),('44', '8'),

('11', '9'),('7', '9'),('1', '9'),('16', '9'),
('39', '9'),('36', '9'),('29', '9'),('30', '9'),
('37', '9'),('31', '9'),('32', '9'),('33', '9'),('34', '9'),
('38', '9'),('35', '9'),('43', '9'),('21', '9'),
('10', '9'),('12', '9'),('17', '9'),('2', '9'),('40', '9'),('27','9'),('44','9'),

('11', '10'),('7', '10'),('1', '10'),('16', '10'),
('39', '10'),('36', '10'),('29', '10'),('30', '10'),
('37', '10'),('31', '10'),('32', '9'),('33', '10'),('34', '10'),
('38', '10'),('35', '10'),('43', '10'),('21', '10'),
('10', '10'),('12', '10'),('17', '10'),('2', '10'),('27','10'),('44','10'),;

INSERT INTO `hydro`.USER_MASTER(`user_id`, `first_name`, `middle_name`, `last_name`, `created_by`, `modified_by`,`org_type`, `user_role`, `email`,`role_id`,`user_name`) VALUES 
('8152678e-d928-477f-97fc-bc19fd12f2e2','Hydro','','Admin','HydroAdmin','HydroAdmin','HYDRO','ADMIN','hydroadmin@doverhydro.onmicrosoft.com','1','hydroadmin');

CREATE TABLE IF NOT EXISTS `hydro`.`CONTACT_MASTER` (
  `contact_id` VARCHAR(100) NOT NULL,
  `site_id` VARCHAR(100) DEFAULT NULL,
  `business_id` VARCHAR(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `name` VARCHAR(100) DEFAULT NULL,
  `number` VARCHAR(100) DEFAULT NULL,
  `title` VARCHAR(100) DEFAULT NULL,
  `created_by` VARCHAR(100) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) DEFAULT NULL,
  `modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`contact_id`)
) ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`CONTACT_MASTER_BCKP` (
   `contact_id` VARCHAR(100) NOT NULL,
  `site_id` VARCHAR(100) DEFAULT NULL,
  `business_id` VARCHAR(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `name` VARCHAR(100) DEFAULT NULL,
  `number` VARCHAR(100) DEFAULT NULL,
  `title` VARCHAR(100) DEFAULT NULL,
  `created_by` VARCHAR(100) DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) DEFAULT NULL,
  `modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_CONTACT_UPDATE
after update on `hydro`.CONTACT_MASTER
for each row
insert into `hydro`.CONTACT_MASTER_BCKP(contact_id, site_id, business_id, email, name, number, title, created_by, created_date, modified_by, modified_date)
values(NEW.contact_id, NEW.site_id, NEW.business_id, NEW.email, NEW.name, NEW.number, NEW.title, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_CONTACT_DELETE
after delete on `hydro`.CONTACT_MASTER
for each row
insert into `hydro`.CONTACT_MASTER_BCKP(contact_id, site_id, business_id, email, name, number, title, created_by, created_date, modified_by, modified_date)
values(old.contact_id, old.site_id, old.business_id, old.email, old.name, old.number, old.title, old.created_by, old.created_date, old.modified_by, old.modified_date);


CREATE TABLE IF NOT EXISTS `hydro`.`FILE_MASTER` (
  `file_id` VARCHAR(100) NOT NULL,
  `name` VARCHAR(200) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` VARCHAR(100) NULL,
  `site_id` VARCHAR(100) NULL,
  `description` VARCHAR(1000) NULL,
  `detailed_description` VARCHAR(1000) NULL,
  `version` INT NULL,
  `lm2_file` LONGBLOB NULL,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `file_type` INT NULL,
  `device_id` VARCHAR(100) NULL,
  `is_active` TINYINT NULL DEFAULT 0,
  `unit_id` VARCHAR(255) NULL,
  PRIMARY KEY (`file_id`),
  INDEX `SiteId_idx` (`site_id` ASC),
  CONSTRAINT `SiteId`
    FOREIGN KEY (`site_id`)
    REFERENCES `hydro`.`SITE_MASTER` (`site_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`FILE_MASTER_BCKP` (
  `file_id` VARCHAR(100) NOT NULL,
  `name` VARCHAR(200) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` VARCHAR(100) NULL,
  `site_id` VARCHAR(100) NULL,
  `description` VARCHAR(1000) NULL,
  `detailed_description` VARCHAR(1000) NULL,
  `version` INT NULL,
  `lm2_file` LONGBLOB NULL,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `file_type` INT NULL,
  `device_id` VARCHAR(100) NULL,
  `is_active` TINYINT NULL DEFAULT 0,
  `unit_id` VARCHAR(255) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_FILE_MASTER_UPDATE
after update on `hydro`.FILE_MASTER
for each row
insert into `hydro`.FILE_MASTER_BCKP(file_id, name, created_by, created_date, status, site_id, description, detailed_description,version,modified_by,modified_date, file_type,device_id,is_active, unit_id)
values(NEW.file_id, NEW.name, NEW.created_by, NEW.created_date, NEW.status, NEW.site_id, NEW.description, NEW.detailed_description, NEW.version, NEW.modified_by,NEW.modified_date, NEW.file_type, NEW.device_id, NEW.is_active, NEW.unit_id);

create trigger `hydro`.TRIG_FILE_MASTER_DELETE
after delete on `hydro`.FILE_MASTER
for each row
insert into `hydro`.FILE_MASTER_BCKP(file_id, name, created_by, created_date, status, site_id, description, detailed_description, version,modified_by,modified_date, file_type,device_id,is_active, unit_id)
values(old.file_id, old.name, old.created_by, old.created_date, old.status, old.site_id, old.description, old.detailed_description, old.version, old.modified_by,old.modified_date, old.file_type, old.device_id, old.is_active, old.unit_id);

ALTER TABLE `hydro`.`SITE_MASTER` 

ADD INDEX `Fileid_index` (`file_id` ASC);
ALTER TABLE `hydro`.`SITE_MASTER` 
ADD CONSTRAINT `FileId`
  FOREIGN KEY (`file_id`)
  REFERENCES `hydro`.`FILE_MASTER` (`file_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

CREATE TABLE IF NOT EXISTS `hydro`.`EQUIPMENT_MASTER` (
  `equipment_id` VARCHAR(100) NOT NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `site_id` VARCHAR(100) NULL,
  `alias` VARCHAR(100) NULL,
  `equipment_type` INT NULL,
  `slave` INT NULL,
  `ip_address` VARCHAR(100) NULL,
  `observations` VARCHAR(2000) NULL,
  `washer_count` INT NULL,
  `tunnel_count` INT NULL,
  `w_machine_chnl_count` INT NULL,
  `pump_count` INT NULL,
  `channel_count` INT NULL,
  `is_active` TINYINT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date`DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `version` VARCHAR(100) NULL,
  `file_id` VARCHAR(100) NULL,
  `device_id` VARCHAR(100) NULL,
  `unit_id` VARCHAR(255) NULL,
`warning_level` TINYINT(4) NULL,
`revision` INT(11) NULL,
`start_up_date` DATE NULL,
`date_power_on` DATETIME NULL,
`language` VARCHAR(2) NULL,
`units_system` INT(2) NULL,
`products_channel_1` VARCHAR(2) NULL,
`products_channel_2` VARCHAR(2) NULL,
`products_channel_3` VARCHAR(2) NULL,
`date_reset_statistics` DATETIME NULL,
`date_last_sync` DATETIME NULL,
`date_last_estadisticas_sync` DATETIME NULL,
`checksum` VARCHAR(255) NULL,
`first_conf_upload` TINYINT(4) NULL,
`first_formulas_upload` TINYINT(4) NULL,
`call_center` TINYINT(4) NULL,
`email` VARCHAR(255) NULL,
`report_period` INT(4) NULL,
`warning_cycles` TINYINT(4) NULL,
`warning_water` TINYINT(4) NULL,
`warning_product` TINYINT(4) NULL,
  PRIMARY KEY (`equipment_id`),
  INDEX `Site_idx` (`site_id` ASC),
  INDEX `File_idx` (`file_id` ASC),
  CONSTRAINT `SiteIDN`
    FOREIGN KEY (`site_id`)
    REFERENCES `hydro`.`SITE_MASTER` (`site_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FileIDN`
    FOREIGN KEY (`file_id`)
    REFERENCES `hydro`.`FILE_MASTER` (`file_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`EQUIPMENT_MASTER_BCKP` (
  `equipment_id` VARCHAR(100) NOT NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `site_id` VARCHAR(100) NULL,
  `alias` VARCHAR(100) NULL,
  `equipment_type` INT NULL,
  `slave` INT NULL,
  `ip_address` VARCHAR(100) NULL,
  `observations` VARCHAR(2000) NULL,
  `washer_count` INT NULL,
  `tunnel_count` INT NULL,
  `w_machine_chnl_count` INT NULL,
  `pump_count` INT NULL,
  `channel_count` INT NULL,
  `is_active` TINYINT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date`DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `version` VARCHAR(100) NULL,
  `file_id` VARCHAR(100) NULL,
  `device_id` VARCHAR(100) NULL,
   `unit_id` VARCHAR(255) NULL,
`warning_level` TINYINT(4) NULL,
`revision` INT(11) NULL,
`start_up_date` DATE NULL,
`date_power_on` DATETIME NULL,
`language` VARCHAR(2) NULL,
`units_system` INT(2) NULL,
`products_channel_1` VARCHAR(2) NULL,
`products_channel_2` VARCHAR(2) NULL,
`products_channel_3` VARCHAR(2) NULL,
`date_reset_statistics` DATETIME NULL,
`date_last_sync` DATETIME NULL,
`date_last_estadisticas_sync` DATETIME NULL,
`checksum` VARCHAR(255) NULL,
`first_conf_upload` TINYINT(4) NULL,
`first_formulas_upload` TINYINT(4) NULL,
`call_center` TINYINT(4) NULL,
`email` VARCHAR(255) NULL,
`report_period` INT(4) NULL,
`warning_cycles` TINYINT(4) NULL,
`warning_water` TINYINT(4) NULL,
`warning_product` TINYINT(4) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP )
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_EQUIPMENT_UPDATE
after update on `hydro`.EQUIPMENT_MASTER
for each row
insert into `hydro`.EQUIPMENT_MASTER_BCKP(equipment_id, lm2_seq, site_id, alias, equipment_type, slave, ip_address, observations, washer_count, tunnel_count, w_machine_chnl_count, pump_count, channel_count, is_active, created_by, created_date, modified_by, modified_date, version, file_id, device_id, unit_id, warning_level, revision, start_up_date, date_power_on, language, units_system, products_channel_1, products_channel_2, products_channel_3, date_reset_statistics, date_last_sync, date_last_estadisticas_sync, checksum, first_conf_upload, first_formulas_upload, call_center, email, report_period, warning_cycles, warning_water, warning_product)
values(NEW.equipment_id, NEW.lm2_seq, NEW.site_id, NEW.alias, NEW.equipment_type, NEW.slave, NEW.ip_address, NEW.observations, NEW.washer_count, NEW.tunnel_count, NEW.w_machine_chnl_count, NEW.pump_count, NEW.channel_count, NEW.is_active, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.version, NEW.file_id, NEW.device_id, NEW.unit_id, NEW.warning_level, NEW.revision, NEW.start_up_date, NEW.date_power_on, NEW.language, NEW.units_system, NEW.products_channel_1, NEW.products_channel_2, NEW.products_channel_3, NEW.date_reset_statistics, NEW.date_last_sync, NEW.date_last_estadisticas_sync, NEW.checksum, NEW.first_conf_upload, NEW.first_formulas_upload, NEW.call_center, NEW.email, NEW.report_period, NEW.warning_cycles, NEW.warning_water, NEW.warning_product);

create trigger `hydro`.TRIG_EQUIPMENT_DELETE
after delete on `hydro`.EQUIPMENT_MASTER
for each row
insert into `hydro`.EQUIPMENT_MASTER_BCKP(equipment_id, lm2_seq, site_id, alias, equipment_type, slave, ip_address, observations, washer_count, tunnel_count, w_machine_chnl_count, pump_count, channel_count, is_active, created_by, created_date, modified_by, modified_date, version, file_id, device_id, unit_id, warning_level, revision, start_up_date, date_power_on, language, units_system, products_channel_1, products_channel_2, products_channel_3, date_reset_statistics, date_last_sync, date_last_estadisticas_sync, checksum, first_conf_upload, first_formulas_upload, call_center, email, report_period, warning_cycles, warning_water, warning_product)
values(old.equipment_id, old.lm2_seq, old.site_id, old.alias, old.equipment_type, old.slave, old.ip_address, old.observations, old.washer_count, old.tunnel_count, old.w_machine_chnl_count, old.pump_count, old.channel_count, old.is_active, old.created_by, old.created_date, old.modified_by, old.modified_date, old.version, old.file_id, old.device_id, old.unit_id, old.warning_level, old.revision, old.start_up_date, old.date_power_on, old.language, old.units_system, old.products_channel_1, old.products_channel_2, old.products_channel_3, old.date_reset_statistics, old.date_last_sync, old.date_last_estadisticas_sync, old.checksum, old.first_conf_upload, old.first_formulas_upload, old.call_center, old.email, old.report_period, old.warning_cycles, old.warning_water, old.warning_product);

CREATE TABLE IF NOT EXISTS `hydro`.`EQUIPMENT_PUMP` (
  `pump_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NOT NULL,
  `pump_name` VARCHAR(100) NULL,
  `pump_value` INT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pump_id`),
  INDEX `Equipment_idx` (`equipment_id` ASC),
  CONSTRAINT `Equipment`
    FOREIGN KEY (`equipment_id`)
    REFERENCES `hydro`.`EQUIPMENT_MASTER` (`equipment_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`EQUIPMENT_PUMP_BCKP` (
  `pump_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NOT NULL,
  `pump_name` VARCHAR(100) NULL,
  `pump_value` INT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;


create trigger `hydro`.TRIG_EQUIPMENT_PUMP_UPDATE
after update on `hydro`.EQUIPMENT_PUMP
for each row
insert into `hydro`.EQUIPMENT_PUMP_BCKP(pump_id, equipment_id, pump_name, pump_value,created_by, created_date, modified_by, modified_date)
values(NEW.pump_id, NEW.equipment_id, NEW.pump_name, NEW.pump_value, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_EQUIPMENT_PUMP_DELETE
after delete on `hydro`.EQUIPMENT_PUMP
for each row
insert into `hydro`.EQUIPMENT_PUMP_BCKP(pump_id, equipment_id, pump_name, pump_value, created_by, created_date, modified_by, modified_date)
values(old.pump_id, old.equipment_id, old.pump_name, old.pump_value, old.created_by, old.created_date, old.modified_by, old.modified_date);


CREATE TABLE IF NOT EXISTS `hydro`.`FORMULA_MASTER` (
  `formula_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  `load` VARCHAR(100) NULL,
  `phases` VARCHAR(100) NULL,
  `color` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `percentage` INT(3) NULL,
  `date_last_change` DATETIME NULL,
  `used_phases` INT(4) NULL,
  `statistic_production` INT(10) NULL,
  `updated` INT(3) NULL,
  PRIMARY KEY (`formula_id`),
  INDEX `Equipment_idx` (`equipment_id` ASC),
  CONSTRAINT `EquipmentID`
    FOREIGN KEY (`equipment_id`)
    REFERENCES `hydro`.`EQUIPMENT_MASTER` (`equipment_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`FORMULA_MASTER_BCKP` (
  `formula_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  `load` VARCHAR(100) NULL,
  `phases` VARCHAR(100) NULL,
  `color` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `percentage` INT(3) NULL,
  `date_last_change` DATETIME NULL,
  `used_phases` INT(4) NULL,
  `statistic_production` INT(10) NULL,
  `updated` INT(3) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_FORMULA_MASTER_UPDATE
after update on `hydro`.FORMULA_MASTER
for each row
insert into `hydro`.FORMULA_MASTER_BCKP(formula_id, equipment_id, lm2_seq, name, `load`, phases, color, created_by, created_date, modified_by, modified_date, uid, percentage, date_last_change, used_phases, statistic_production, updated)
values(NEW.formula_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.load, NEW.phases, NEW.color, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid, NEW.percentage, NEW.date_last_change, NEW.used_phases, NEW.statistic_production, NEW.updated);

create trigger `hydro`.TRIG_FORMULA_MASTER_DELETE
after delete on `hydro`.FORMULA_MASTER
for each row
insert into `hydro`.FORMULA_MASTER_BCKP(formula_id, equipment_id, lm2_seq, name, `load`, phases, color, created_by, created_date, modified_by, modified_date, uid, percentage, date_last_change, used_phases, statistic_production, updated)
values(old.formula_id, old.equipment_id, old.lm2_seq, old.name, old.load, old.phases, old.color, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid, old.percentage, old.date_last_change, old.used_phases, old.statistic_production, old.updated);

CREATE TABLE IF NOT EXISTS `hydro`.`EQUIPMENT_FORMULA` (
  `formula_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NOT NULL,
  `formula_name` VARCHAR(100) NULL,
  `formula_value` INT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`formula_id`),
  INDEX `Equipment_idx` (`equipment_id` ASC),
  CONSTRAINT `Equipment0`
    FOREIGN KEY (`equipment_id`)
    REFERENCES `hydro`.`EQUIPMENT_MASTER` (`equipment_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`EQUIPMENT_FORMULA_BCKP` (
  `formula_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NOT NULL,
  `formula_name` VARCHAR(100) NULL,
  `formula_value` INT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)  
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_EQUIPMENT_FORMULA_UPDATE
after update on `hydro`.EQUIPMENT_FORMULA
for each row
insert into `hydro`.EQUIPMENT_FORMULA_BCKP(formula_id, equipment_id, formula_name, formula_value, created_by, created_date, modified_by, modified_date)
values(NEW.formula_id, NEW.equipment_id, NEW.formula_name, NEW.formula_value, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_EQUIPMENT_FORMULA_DELETE
after delete on `hydro`.EQUIPMENT_FORMULA
for each row
insert into `hydro`.EQUIPMENT_FORMULA_BCKP(formula_id, equipment_id, formula_name, formula_value, created_by, created_date, modified_by, modified_date)
values(old.formula_id, old.equipment_id, old.formula_name, old.formula_value, old.created_by, old.created_date, old.modified_by, old.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`EQUIPMENT_PUMP_MACHINERY` (
  `pump_machine_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NOT NULL,
  `pump_machine_name` VARCHAR(100) NULL,
  `pump_machine_value` INT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pump_machine_id`),
  INDEX `Equipment_idx` (`equipment_id` ASC),
  CONSTRAINT `Equipment1`
    FOREIGN KEY (`equipment_id`)
    REFERENCES `hydro`.`EQUIPMENT_MASTER` (`equipment_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`EQUIPMENT_PUMP_MACHINERY_BCKP` (
  `pump_machine_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NOT NULL,
  `pump_machine_name` VARCHAR(100) NULL,
  `pump_machine_value` INT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
   `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_EQUIPMENT_PUMP_MACHINERY_UPDATE
after update on `hydro`.EQUIPMENT_PUMP_MACHINERY
for each row
insert into `hydro`.EQUIPMENT_PUMP_MACHINERY_BCKP(pump_machine_id, equipment_id, pump_machine_name, pump_machine_value, created_by, created_date, modified_by, modified_date)
values(NEW.pump_machine_id, NEW.equipment_id, NEW.pump_machine_name, NEW.pump_machine_value, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_EQUIPMENT_PUMP_MACHINERY_DELETE
after delete on `hydro`.EQUIPMENT_PUMP_MACHINERY
for each row
insert into `hydro`.EQUIPMENT_PUMP_MACHINERY_BCKP(pump_machine_id, equipment_id, pump_machine_name, pump_machine_value, created_by, created_date, modified_by, modified_date)
values(old.pump_machine_id, old.equipment_id, old.pump_machine_name, old.pump_machine_value, old.created_by, old.created_date, old.modified_by, old.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`FORMULA_PDB` (
  `pdb_id` VARCHAR(100) NOT NULL,
  `formula_id` VARCHAR(100) NULL,
  `pdb_name` VARCHAR(100) NULL,
  `pdb_value` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pdb_id`),
  INDEX `Formula_idx` (`formula_id` ASC),
  CONSTRAINT `Formula`
    FOREIGN KEY (`formula_id`)
    REFERENCES `hydro`.`FORMULA_MASTER` (`formula_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`FORMULA_PDB_BCKP` (
  `pdb_id` VARCHAR(100) NULL,
  `formula_id` VARCHAR(100) NULL,
  `pdb_name` VARCHAR(100) NULL,
  `pdb_value` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_FORMULA_PDB_UPDATE
after update on `hydro`.FORMULA_PDB
for each row
insert into `hydro`.FORMULA_PDB_BCKP(pdb_id, formula_id, pdb_name, pdb_value, created_by, created_date, modified_by, modified_date)
values(NEW.pdb_id, NEW.formula_id, NEW.pdb_name, NEW.pdb_value, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_FORMULA_PDB_DELETE
after delete on `hydro`.FORMULA_PDB
for each row
insert into `hydro`.FORMULA_PDB_BCKP(pdb_id, formula_id, pdb_name, pdb_value, created_by, created_date, modified_by, modified_date)
values(old.pdb_id, old.formula_id, old.pdb_name, old.pdb_value, old.created_by, old.created_date, old.modified_by, old.modified_date);


CREATE TABLE IF NOT EXISTS `hydro`.`PRODUCT_MASTER` (
  `product_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  `density` INT NULL,
  `concentration` INT NULL,
  `kf` DOUBLE NULL,
  `flow` DOUBLE NULL,
  `frequency` INT NULL,
  `docification_mode` INT NULL,
  `priority` INT NULL,
  `contact` VARCHAR(100) NULL,
  `alarms_ignored` VARCHAR(100) NULL,
  `percentage` INT NULL,
  `drag_type` INT NULL,
  `pump_speed` INT NULL,
  `format` INT NULL,
  `price` INT NULL,
  `calibration` VARCHAR(100) NULL,
  `color1` VARCHAR(100) NULL,
  `color2` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` VARCHAR(100) NULL,
  `alarms_tolerance` INT(2) NULL,
  `date_last_change` DATETIME NULL,
  `dosing_mode` INT(1) NULL,
  `estate` INT(1) NULL,
  `pump_safe_stop` INT(1) NULL,
  `rotameter_sensor` INT(1) NULL,
  `statistic_production` INT(10) NULL,
  `statistic_warnings` INT(10) NULL,
  PRIMARY KEY (`product_id`),
  INDEX `Equipment_idx` (`equipment_id` ASC),
  CONSTRAINT `EquipmentID0`
    FOREIGN KEY (`equipment_id`)
    REFERENCES `hydro`.`EQUIPMENT_MASTER` (`equipment_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;


CREATE TABLE IF NOT EXISTS `hydro`.`PRODUCT_MASTER_BCKP` (
  `product_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  `density` INT NULL,
  `concentration` INT NULL,
  `kf` DOUBLE NULL,
  `flow` DOUBLE NULL,
  `frequency` INT NULL,
  `docification_mode` INT NULL,
  `priority` INT NULL,
  `contact` VARCHAR(100) NULL,
  `alarms_ignored` VARCHAR(100) NULL,
  `percentage` INT NULL,
  `drag_type` INT NULL,
  `pump_speed` INT NULL,
  `format` INT NULL,
  `price` INT NULL,
  `calibration` VARCHAR(100) NULL,
  `color1` VARCHAR(100) NULL,
  `color2` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` VARCHAR(100) NULL,
  `alarms_tolerance` INT(2) NULL,
  `date_last_change` DATETIME NULL,
  `dosing_mode` INT(1) NULL,
  `estate` INT(1) NULL,
  `pump_safe_stop` INT(1) NULL,
  `rotameter_sensor` INT(1) NULL,
  `statistic_production` INT(10) NULL,
  `statistic_warnings` INT(10) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_PRODUCT_MASTER_UPDATE
after update on `hydro`.PRODUCT_MASTER
for each row
insert into `hydro`.PRODUCT_MASTER_BCKP(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow, frequency, docification_mode, priority, contact, alarms_ignored, percentage, drag_type, pump_speed, format, price, calibration, color1, color2, created_by, created_date, modified_by, modified_date, uid, alarms_tolerance, date_last_change, dosing_mode, estate, pump_safe_stop, rotameter_sensor, statistic_production, statistic_warnings)
values(NEW.product_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.density, NEW.concentration, NEW.kf, NEW.flow, NEW.frequency, NEW.docification_mode, NEW.priority, NEW.contact, NEW.alarms_ignored, NEW.percentage, NEW.drag_type, NEW.pump_speed, NEW.format, NEW.price, NEW.calibration, NEW.color1, NEW.color2, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid, NEW.alarms_tolerance, NEW.date_last_change, NEW.dosing_mode, NEW.estate, NEW.pump_safe_stop, NEW.rotameter_sensor, NEW.statistic_production, NEW.statistic_warnings);

create trigger `hydro`.TRIG_PRODUCT_MASTER_DELETE
after delete on `hydro`.PRODUCT_MASTER
for each row
insert into `hydro`.PRODUCT_MASTER_BCKP(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow, frequency, docification_mode, priority, contact, alarms_ignored, percentage, drag_type, pump_speed, format, price, calibration, color1, color2, created_by, created_date, modified_by, modified_date, uid, alarms_tolerance, date_last_change, dosing_mode, estate, pump_safe_stop, rotameter_sensor, statistic_production, statistic_warnings)
values(old.product_id, old.equipment_id, old.lm2_seq, old.name, old.density, old.concentration, old.kf, old.flow, old.frequency, old.docification_mode, old.priority, old.contact, old.alarms_ignored, old.percentage, old.drag_type, old.pump_speed, old.format, old.price, old.calibration, old.color1, old.color2, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid, old.alarms_tolerance, old.date_last_change, old.dosing_mode, old.estate, old.pump_safe_stop, old.rotameter_sensor, old.statistic_production, old.statistic_warnings);

CREATE TABLE IF NOT EXISTS `hydro`.`EQUIPMENT_TUNNEL_CHANNEL` (
  `tunnel_channel_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NOT NULL,
  `tunnel_channel_name` VARCHAR(100) NULL,
  `tunnel_channel_value` INT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tunnel_channel_id`),
  INDEX `Equipment_idx` (`equipment_id` ASC),
  CONSTRAINT `Equipment2`
    FOREIGN KEY (`equipment_id`)
    REFERENCES `hydro`.`EQUIPMENT_MASTER` (`equipment_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`EQUIPMENT_TUNNEL_CHANNEL_BCKP` (
  `tunnel_channel_id` VARCHAR(100) NULL,
  `equipment_id` VARCHAR(100) NULL,
  `tunnel_channel_name` VARCHAR(100) NULL,
  `tunnel_channel_value` INT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_EQUIPMENT_TUNNEL_CHANNEL_UPDATE
after update on `hydro`.EQUIPMENT_TUNNEL_CHANNEL
for each row
insert into `hydro`.EQUIPMENT_TUNNEL_CHANNEL_BCKP(tunnel_channel_id, equipment_id, tunnel_channel_name, tunnel_channel_value, created_by, created_date, modified_by, modified_date)
values(NEW.tunnel_channel_id, NEW.equipment_id, NEW.tunnel_channel_name, NEW.tunnel_channel_value, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_EQUIPMENT_TUNNEL_CHANNEL_DELETE
after delete on `hydro`.EQUIPMENT_TUNNEL_CHANNEL
for each row
insert into `hydro`.EQUIPMENT_TUNNEL_CHANNEL_BCKP(tunnel_channel_id, equipment_id, tunnel_channel_name, tunnel_channel_value, created_by, created_date, modified_by, modified_date)
values(old.tunnel_channel_id, old.equipment_id, old.tunnel_channel_name, old.tunnel_channel_value, old.created_by, old.created_date, old.modified_by, old.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`WASHER_MASTER` (
  `washer_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  `load` INT NULL,
  `modifiable_load` INT NULL,
  `ltr_drag` INT NULL,
  `cellular_minutes` INT NULL,
  `id_formula` INT NULL,
  `work_mode` INT NULL,
  `reset_mode` INT NULL,
  `reset_signal` INT NULL,
  `reset_formula` INT NULL,
  `unused_machine` INT NULL,
  `unused_time_delay` INT NULL,
  `unused_timeout` INT NULL,
  `t_acceptation` INT NULL,
  `t_repetition` VARCHAR(100) NULL,
  `t_lock` INT NULL,
  `type_programmer` INT NULL,
  `signal_count` INT NULL,
  `signal_voltage` INT NULL,
  `signal_connection` INT NULL,
  `observation` VARCHAR(2000) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` VARCHAR(100) NULL,
  `date_last_change` DATETIME NULL,
  `end_formula` INT(3) NULL,
  `end_mode` INT(1) NULL,
  `end_signal_pump` INT(2) NULL,
  `flush_l` DECIMAL(4,2) NULL,
  `hold_delay` INT(3) NULL,
  `hold_mode` INT(1) NULL,
  `hold_timeout` INT(3) NULL
  `kg_sel` INT(1) NULL,
  `trigger_mode` INT(1) NULL,
  PRIMARY KEY (`washer_id`),
  INDEX `Equipment_idx` (`equipment_id` ASC),
  CONSTRAINT `EquipmentID2`
    FOREIGN KEY (`equipment_id`)
    REFERENCES `hydro`.`EQUIPMENT_MASTER` (`equipment_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`WASHER_MASTER_BCKP` (
  `washer_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  `load` INT NULL,
  `modifiable_load` INT NULL,
  `ltr_drag` INT NULL,
  `cellular_minutes` INT NULL,
  `id_formula` INT NULL,
  `work_mode` INT NULL,
  `reset_mode` INT NULL,
  `reset_signal` INT NULL,
  `reset_formula` INT NULL,
  `unused_machine` INT NULL,
  `unused_time_delay` INT NULL,
  `unused_timeout` INT NULL,
  `t_acceptation` INT NULL,
  `t_repetition` VARCHAR(100) NULL,
  `t_lock` INT NULL,
  `type_programmer` INT NULL,
  `signal_count` INT NULL,
  `signal_voltage` INT NULL,
  `signal_connection` INT NULL,
  `observation` VARCHAR(2000) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` VARCHAR(100) NULL,
  `date_last_change` DATETIME NULL,
  `end_formula` INT(3) NULL,
  `end_mode` INT(1) NULL,
  `end_signal_pump` INT(2) NULL,
  `flush_l` DECIMAL(4,2) NULL,
  `hold_delay` INT(3) NULL,
  `hold_mode` INT(1) NULL,
  `hold_timeout` INT(3) NULL
  `kg_sel` INT(1) NULL,
  `trigger_mode` INT(1) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_WASHER_MASTER_UPDATE
after update on `hydro`.WASHER_MASTER
for each row
insert into `hydro`.WASHER_MASTER_BCKP(washer_id, equipment_id, lm2_seq, name, `load`, modifiable_load, ltr_drag, cellular_minutes, id_formula, work_mode, reset_mode, reset_signal, reset_formula, unused_machine, unused_time_delay, unused_timeout, t_acceptation, t_repetition, t_lock, type_programmer, signal_count, signal_voltage, signal_connection, observation, created_by, created_date, modified_by, modified_date, uid, date_last_change, end_formula, end_mode, end_signal_pump, flush_l,  hold_delay, hold_mode, hold_timeout, kg_sel, trigger_mode)
values(NEW.washer_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.load, NEW.modifiable_load, NEW.ltr_drag, NEW.cellular_minutes, NEW.id_formula, NEW.work_mode, NEW.reset_mode, NEW.reset_signal, NEW.reset_formula, NEW.unused_machine, NEW.unused_time_delay, NEW.unused_timeout, NEW.t_acceptation, NEW.t_repetition, NEW.t_lock, NEW.type_programmer, NEW.signal_count, NEW.signal_voltage, NEW.signal_connection, NEW.observation, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid, NEW.date_last_change, NEW.end_formula, NEW.end_mode, NEW.end_signal_pump, NEW.flush_l, NEW.hold_delay, NEW.hold_mode, NEW.hold_timeout, NEW.kg_sel, NEW.trigger_mode);

create trigger `hydro`.TRIG_WASHER_MASTER_DELETE
after delete on `hydro`.WASHER_MASTER
for each row
insert into `hydro`.WASHER_MASTER_BCKP(washer_id, equipment_id, lm2_seq, name, `load`, modifiable_load, ltr_drag, cellular_minutes, id_formula, work_mode, reset_mode, reset_signal, reset_formula, unused_machine, unused_time_delay, unused_timeout, t_acceptation, t_repetition, t_lock, type_programmer, signal_count, signal_voltage, signal_connection, observation, created_by, created_date, modified_by, modified_date, uid, date_last_change, end_formula, end_mode, end_signal_pump, flush_l, hold_delay, hold_mode, hold_timeout, kg_sel, trigger_mode)
values(old.washer_id, old.equipment_id, old.lm2_seq, old.name, old.load, old.modifiable_load, old.ltr_drag, old.cellular_minutes, old.id_formula, old.work_mode, old.reset_mode, old.reset_signal, old.reset_formula, old.unused_machine, old.unused_time_delay, old.unused_timeout, old.t_acceptation, old.t_repetition, old.t_lock, old.type_programmer, old.signal_count, old.signal_voltage, old.signal_connection, old.observation, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid, old.date_last_change, old.end_formula, old.end_mode, old.end_signal_pump, old.flush_l, old.hold_delay, old.hold_mode, old.hold_timeout, old.kg_sel, old.trigger_mode);

CREATE TABLE IF NOT EXISTS `hydro`.`OBSERVATION_MASTER` (
  `observation_id` VARCHAR(100) NOT NULL,
  `site_id` VARCHAR(100) NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `observation` VARCHAR(5000) NULL,
  `recommendation` VARCHAR(5000) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `equipment_id` VARCHAR(100) NULL,
  `month` INT NULL,
  `year` INT NULL,
  `device_id` VARCHAR(100) NULL,
  PRIMARY KEY (`observation_id`),
  INDEX `site_idConstraint_idx` (`site_id` ASC),
  CONSTRAINT `site_idConstraint`
    FOREIGN KEY (`site_id`)
    REFERENCES `hydro`.`EQUIPMENT_MASTER` (`site_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`OBSERVATION_MASTER_BCKP` (
  `observation_id` VARCHAR(100) NOT NULL,
  `site_id` VARCHAR(100) NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `observation` VARCHAR(5000) NULL,
  `recommendation` VARCHAR(5000) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `equipment_id` VARCHAR(100) NULL,
  `month` INT NULL,
  `year` INT NULL,
  `device_id` VARCHAR(100) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_OBSERVATION_MASTER_UPDATE
after update on `hydro`.OBSERVATION_MASTER
for each row
insert into `hydro`.OBSERVATION_MASTER_BCKP(observation_id,site_id,lm2_seq, observation, recommendation, created_by, created_date, modified_by, modified_date, equipment_id, month, year, device_id)
values(NEW.observation_id,NEW.site_id,NEW.lm2_seq, NEW.observation, NEW.recommendation, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.equipment_id, NEW.month, NEW.year, NEW.device_id);

create trigger `hydro`.TRIG_OBSERVATION_MASTER_DELETE
after delete on `hydro`.OBSERVATION_MASTER
for each row
insert into `hydro`.OBSERVATION_MASTER_BCKP(observation_id,site_id,lm2_seq, observation, recommendation, created_by, created_date, modified_by, modified_date, equipment_id, month, year, device_id)
values(old.observation_id,old.site_id,old.lm2_seq, old.observation, old.recommendation, old.created_by, old.created_date, old.modified_by, old.modified_date, old.equipment_id, old.month, old.year, old.device_id);

CREATE TABLE IF NOT EXISTS `hydro`.`WATER_MASTER` (
  `water_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  `kf` INT NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `flow` VARCHAR(100) NULL,
  `water_time` INT NULL,
  `cellphone_minute` INT NULL,
  `docification_mode` INT NULL,
  `seperation_ml` INT NULL,
  `ignored_alarms` INT NULL,
  `percentage` INT NULL,
  `diameter` VARCHAR(100) NULL,
  `pump_type` INT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` VARCHAR(100) NULL,
  `channel` INT(2) NULL,
  `date_calibration` DATE NULL,
  `date_last_change` DATETIME NULL,
  PRIMARY KEY (`water_id`),
  INDEX `Equipment_idx` (`equipment_id` ASC),
  CONSTRAINT `Equipment78`
    FOREIGN KEY (`equipment_id`)
    REFERENCES `hydro`.`EQUIPMENT_MASTER` (`equipment_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`WATER_MASTER_BCKP` (
  `water_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  `kf` INT NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `flow` VARCHAR(100) NULL,
  `water_time` INT NULL,
  `cellphone_minute` INT NULL,
  `docification_mode` INT NULL,
  `seperation_ml` INT NULL,
  `ignored_alarms` INT NULL,
  `percentage` INT NULL,
  `diameter` VARCHAR(100) NULL,
  `pump_type` INT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` VARCHAR(100) NULL,
  `channel` INT(2) NULL,
  `date_calibration` DATE NULL,
  `date_last_change` DATETIME NULL,
 `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_WATER_MASTER_UPDATE
after update on `hydro`.WATER_MASTER
for each row
insert into `hydro`.WATER_MASTER_BCKP(water_id, equipment_id, name, kf, lm2_seq, flow, water_time, cellphone_minute, docification_mode, seperation_ml, ignored_alarms, percentage, diameter, pump_type, created_by, created_date, modified_by, modified_date, uid, channel, date_calibration, date_last_change)
values(NEW.water_id, NEW.equipment_id, NEW.name, NEW.kf, NEW.lm2_seq, NEW.flow, NEW.water_time, NEW.cellphone_minute, NEW.docification_mode, NEW.seperation_ml, NEW.ignored_alarms, NEW.percentage, NEW.diameter, NEW.pump_type, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid, NEW.channel, NEW.date_calibration, NEW.date_last_change);

create trigger `hydro`.TRIG_WATER_MASTER_DELETE
after delete on `hydro`.WATER_MASTER
for each row
insert into `hydro`.WATER_MASTER_BCKP(water_id, equipment_id, name, kf, lm2_seq, flow, water_time, cellphone_minute, docification_mode, seperation_ml, ignored_alarms, percentage, diameter, pump_type, created_by, created_date, modified_by, modified_date, uid, channel, date_calibration, date_last_change)
values(old.water_id, old.equipment_id, old.name, old.kf, old.lm2_seq, old.flow, old.water_time, old.cellphone_minute, old.docification_mode, old.seperation_ml, old.ignored_alarms, old.percentage, old.diameter, old.pump_type, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid, old.channel, old.date_calibration, old.date_last_change);

CREATE TABLE IF NOT EXISTS `hydro`.`TUNNEL_MASTER` (
  `tunnel_id` VARCHAR(100) NOT NULL,
  `equipment_id` VARCHAR(100) NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  `load` INT NULL,
  `modules_count` INT NULL,
  `module_count_dosif` INT NULL,
  `load_min` INT NULL,
  `load_max` INT NULL,
  `formula_id` INT NULL,
  `ltr` VARCHAR(100) NULL,
  `cellular_minutes` VARCHAR(100) NULL,
  `modules_per_channel` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` VARCHAR(100) NULL,
  PRIMARY KEY (`tunnel_id`),
  INDEX `Equipment_idx` (`equipment_id` ASC),
  CONSTRAINT `Equipment3`
    FOREIGN KEY (`equipment_id`)
    REFERENCES `hydro`.`EQUIPMENT_MASTER` (`equipment_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`TUNNEL_MASTER_BCKP` (
  `tunnel_id` VARCHAR(100) NULL,
  `equipment_id` VARCHAR(100) NULL,
  `lm2_seq` VARCHAR(100) NULL,
  `name` VARCHAR(100) NULL,
  `load` INT NULL,
  `modules_count` INT NULL,
  `module_count_dosif` INT NULL,
  `load_min` INT NULL,
  `load_max` INT NULL,
  `formula_id` INT NULL,
  `ltr` VARCHAR(100) NULL,
  `cellular_minutes` VARCHAR(100) NULL,
  `modules_per_channel` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `uid` VARCHAR(100) NULL,
  `log` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_TUNNEL_MASTER_UPDATE
after update on `hydro`.TUNNEL_MASTER
for each row
insert into `hydro`.TUNNEL_MASTER_BCKP(tunnel_id, equipment_id, lm2_seq, name, `load`, modules_count, module_count_dosif, load_min, load_max, formula_id, ltr, cellular_minutes, modules_per_channel, created_by, created_date, modified_by, modified_date, uid)
values(NEW.tunnel_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.load, NEW.modules_count, NEW.module_count_dosif, NEW.load_min, NEW.load_max, NEW.formula_id, NEW.ltr, NEW.cellular_minutes, NEW.modules_per_channel, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid);

create trigger `hydro`.TRIG_TUNNEL_MASTER_DELETE
after delete on `hydro`.TUNNEL_MASTER
for each row
insert into `hydro`.TUNNEL_MASTER_BCKP(tunnel_id, equipment_id, lm2_seq, name, `load`, modules_count, module_count_dosif, load_min, load_max, formula_id, ltr, cellular_minutes, modules_per_channel, created_by, created_date, modified_by, modified_date,uid)
values(old.tunnel_id, old.equipment_id, old.lm2_seq, old.name, old.load, old.modules_count, old.module_count_dosif, old.load_min, old.load_max, old.formula_id, old.ltr, old.cellular_minutes, old.modules_per_channel, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid);

CREATE TABLE IF NOT EXISTS `hydro`.`TUNNEL_PRODUCTS` (
  `tunnel_id` VARCHAR(100) NULL,
  `product_id` VARCHAR(100) NOT NULL,
  `product_name` VARCHAR(100) NULL,
  `product_value` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`product_id`),
  INDEX `tunnel_id_idx` (`tunnel_id` ASC),
  CONSTRAINT `tunnel_id`
    FOREIGN KEY (`tunnel_id`)
    REFERENCES `hydro`.`TUNNEL_MASTER` (`tunnel_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`TUNNEL_PRODUCTS_BCKP` (
  `tunnel_id` VARCHAR(100) NULL,
  `product_id` VARCHAR(100) NULL,
  `product_name` VARCHAR(100) NULL,
  `product_value` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_TUNNEL_PRODUCTS_DELETE
after delete on `hydro`.TUNNEL_PRODUCTS
for each row
insert into `hydro`.TUNNEL_PRODUCTS_BCKP(tunnel_id, product_id, product_name, product_value, created_by, created_date, modified_by, modified_date)
values(old.tunnel_id, old.product_id, old.product_name, old.product_value, old.created_by, old.created_date, old.modified_by, old.modified_date);

create trigger `hydro`.TRIG_TUNNEL_PRODUCTS_UPDATE
after update on `hydro`.TUNNEL_PRODUCTS
for each row
insert into `hydro`.TUNNEL_PRODUCTS_BCKP(tunnel_id, product_id, product_name, product_value, created_by, created_date, modified_by, modified_date)
values(NEW.tunnel_id, NEW.product_id, NEW.product_name, NEW.product_value, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`ES_ERROR_LOG` (
  `error_id` VARCHAR(50) NOT NULL,
  `site_id` VARCHAR(50) NULL,
  `file_id` VARCHAR(45) NULL,
  `description` VARCHAR(1000) NULL,
  `error_type` VARCHAR(100) NULL,
  `es_error` LONGTEXT NULL,
  `index_name` VARCHAR(100) NULL,
  `es_document` LONGTEXT NULL,
  `created_by` VARCHAR(45) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(45) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `es_type` VARCHAR(50) NULL,
  `month` INT NULL,
  `year` INT NULL,
  PRIMARY KEY (`error_id`),
  INDEX `Site_idx` (`site_id` ASC),
  INDEX `File_idx` (`file_id` ASC),
  CONSTRAINT `Site001`
    FOREIGN KEY (`site_id`)
    REFERENCES `hydro`.`SITE_MASTER` (`site_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `File001`
    FOREIGN KEY (`file_id`)
    REFERENCES `hydro`.`FILE_MASTER` (`file_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`ES_ERROR_LOG_BCKP` (
  `error_id` VARCHAR(50) NOT NULL,
  `site_id` VARCHAR(50) NULL,
  `file_id` VARCHAR(45) NULL,
  `description` VARCHAR(1000) NULL,
  `error_type` VARCHAR(100) NULL,
  `es_error` LONGTEXT NULL,
  `index_name` VARCHAR(100) NULL,
  `es_document` LONGTEXT NULL,
  `created_by` VARCHAR(45) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(45) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `es_type` VARCHAR(50) NULL,
  `month` INT NULL,
  `year` INT NULL,
  `log` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_ES_ERROR_LOG_DELETE
after delete on `hydro`.ES_ERROR_LOG
for each row
insert into `hydro`.ES_ERROR_LOG_BCKP(error_id, site_id, file_id, description, error_type, es_error, index_name, es_document, created_by, created_date, modified_by, modified_date, es_type, month, year)
values(old.error_id, old.site_id, old.file_id, old.description, old.error_type, old.es_error, old.index_name, old.es_document, old.created_by, old.created_date, old.modified_by, old.modified_date, old.es_type, old.month, old.year);

create trigger `hydro`.TRIG_ES_ERROR_LOG_UPDATE
after update on `hydro`.ES_ERROR_LOG
for each row
insert into `hydro`.ES_ERROR_LOG_BCKP(error_id, site_id, file_id, description, error_type, es_error, index_name, es_document, created_by, created_date, modified_by, modified_date, es_type, month, year)
values(NEW.error_id, NEW.site_id, NEW.file_id, NEW.description, NEW.error_type, NEW.es_error, NEW.index_name, NEW.es_document, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.es_type, NEW.month, NEW.year);

CREATE TABLE IF NOT EXISTS `hydro`.`USER_SITE_ASSOCIATION` (
  `user_id` VARCHAR(100) NOT NULL,
  `site_id` VARCHAR(100) NOT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `userConstraint_idx` (`user_id` ASC),
  INDEX `siteConstraint_idx` (`site_id` ASC),
  CONSTRAINT `UserConstraintForAssociation`
    FOREIGN KEY (`user_id`)
    REFERENCES `hydro`.`USER_MASTER` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `SiteConstraintForAssociation`
    FOREIGN KEY (`site_id`)
    REFERENCES `hydro`.`SITE_MASTER` (`site_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`USER_SITE_ASSOCIATION_BCKP` (
  `user_id` VARCHAR(100) NULL,
  `site_id` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_User_Site_Association_UPDATE
after update on `hydro`.USER_SITE_ASSOCIATION
for each row 
insert into `hydro`.USER_SITE_ASSOCIATION_BCKP(user_id, site_id, created_by, created_date, modified_by, modified_date)
values (NEW.user_id, NEW.site_id, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.TRIG_User_Site_Association_DELETE
after delete on `hydro`.USER_SITE_ASSOCIATION
for each row
insert into `hydro`.USER_SITE_ASSOCIATION_BCKP(user_id, site_id, created_by, created_date, modified_by, modified_date)
values (old.user_id, old.site_id, old.created_by, old.created_date, old.modified_by, old.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`SHIFT_MASTER` (
  `site_id` VARCHAR(50) NULL,
  `shift_id` VARCHAR(45) NULL,
  `shift_name` VARCHAR(45) NULL,
  `start_time` TIME NULL,
  `end_time` TIME NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `Site_idx` (`site_id` ASC),
  CONSTRAINT `Site1`
    FOREIGN KEY (`site_id`)
    REFERENCES `hydro`.`SITE_MASTER` (`site_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`SHIFT_MASTER_BCKP` (
  `site_id` VARCHAR(50) NULL,
  `shift_id` VARCHAR(45) NULL,
  `shift_name` VARCHAR(45) NULL,
  `start_time` TIME NULL,
  `end_time` TIME NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_Shift_Master_UPDATE
AFTER UPDATE ON `hydro`.SHIFT_MASTER
for each row
insert into `hydro`.SHIFT_MASTER_BCKP(site_id, shift_id, shift_name, start_time, end_time, created_by, created_date, modified_by, modified_date)
values(NEW.site_id, NEW.shift_id, NEW.shift_name, NEW.start_time, NEW.end_time, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE TRIGGER `hydro`.TRIG_Shift_Master_DELETE
after delete on `hydro`.SHIFT_MASTER
for each row
insert into `hydro`.SHIFT_MASTER_BCKP(site_id, shift_id, shift_name, start_time, end_time, created_by, created_date, modified_by, modified_date)
values(old.site_id, old.shift_id, old.shift_name, old.start_time, old.end_time, old.created_by, old.created_date, old.modified_by, old.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`ALARM_MASTER` (
  `alarm_id` VARCHAR(100) NOT NULL,
  `alarm_type` VARCHAR(100) NULL,
  `alarm_name` VARCHAR(100) NULL,
  `description` VARCHAR(1000) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`alarm_id`))
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`ALARM_MASTER_BCKP` (
  `alarm_id` VARCHAR(100) NOT NULL,
  `alarm_type` VARCHAR(100) NULL,
  `alarm_name` VARCHAR(100) NULL,
  `description` VARCHAR(1000) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.`TRIG_ALARM_MASTER_UPDATE`
after update on `hydro`.`ALARM_MASTER`
for each row 
insert into `hydro`.`ALARM_MASTER_BCKP`(alarm_id, alarm_type, alarm_name, description,created_by, created_date, modified_by, modified_date)
values (NEW.alarm_id, NEW.alarm_type, NEW.alarm_name, NEW.description, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_ALARM_MASTER_DELETE`
after delete on `hydro`.`ALARM_MASTER`
for each row
insert into `hydro`.`ALARM_MASTER_BCKP`(alarm_id, alarm_type, alarm_name, description,created_by, created_date, modified_by, modified_date)
values (old.alarm_id, old.alarm_type, old.alarm_name, old.description,old.created_by, old.created_date, old.modified_by, old.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`PREFERENCE_MASTER` (
  `id` VARCHAR(100) NOT NULL,
  `business_id` VARCHAR(100) NOT NULL,
  `site_id` VARCHAR(100) NULL,
  `unit_id` VARCHAR(100) NULL,
  `machine_id` VARCHAR(100) NULL,
  `role_id` VARCHAR(100) NULL,
  `alarm_id` VARCHAR(100) NULL,
  `sms` TINYINT NULL,
  `email` TINYINT NULL,
  `threshold` INT NOT NULL DEFAULT 0,
  `threshold_refresh_interval` VARCHAR(100) NULL DEFAULT NULL,
  `alarm_counter` INT NULL DEFAULT 0,
  `alarm_first_date_time` DATETIME NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `Ref_alarmIdColumn_idx` (`alarm_id` ASC),
  INDEX `Ref_businessId_idx` (`business_id` ASC),
  INDEX `Ref_roleIdref_idx` (`role_id` ASC),
  PRIMARY KEY (`id`),
  CONSTRAINT `Ref_alarmIdColumn`
    FOREIGN KEY (`alarm_id`)
    REFERENCES `hydro`.`ALARM_MASTER` (`alarm_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `Ref_roleIdref`
    FOREIGN KEY (`role_id`)
    REFERENCES `hydro`.`ROLE_MASTER` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `Ref_businessId`
    FOREIGN KEY (`business_id`)
    REFERENCES `hydro`.`BUSINESS_MASTER` (`business_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`PREFERENCE_MASTER_BCKP` (
  `id` VARCHAR(100) NULL,
  `business_id` VARCHAR(100) NOT NULL,
  `site_id` VARCHAR(100) NULL,
  `unit_id` VARCHAR(100) NULL,
  `machine_id` VARCHAR(100) NULL,
  `role_id` VARCHAR(100) NULL,
  `alarm_id` VARCHAR(100) NULL,
  `sms` TINYINT NULL,
  `email` TINYINT NULL,
  `threshold` INT NOT NULL DEFAULT 0,
  `threshold_refresh_interval` VARCHAR(100) NULL DEFAULT NULL,
  `alarm_counter` INT NULL DEFAULT 0,
  `alarm_first_date_time` DATETIME NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.`TRIG_PREFERENCE_MASTER_UPDATE`
after update on `hydro`.`PREFERENCE_MASTER`
for each row 
insert into `hydro`.`PREFERENCE_MASTER_BCKP`(id, business_id, site_id, unit_id, machine_id, role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, alarm_counter, alarm_first_date_time, created_by, created_date, modified_by, modified_date)
values (NEW.id, NEW.business_id, NEW.site_id, NEW.unit_id, NEW.machine_id, NEW.role_id, NEW.alarm_id, NEW.sms, NEW.email, NEW.threshold, NEW.threshold_refresh_interval, NEW.alarm_counter, NEW.alarm_first_date_time, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_PREFERENCE_MASTER_DELETE`
after delete on `hydro`.`PREFERENCE_MASTER`
for each row
insert into `hydro`.`PREFERENCE_MASTER_BCKP`(id, business_id, site_id, unit_id, machine_id, role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, alarm_counter, alarm_first_date_time, created_by, created_date, modified_by, modified_date)
values (old.id, old.business_id, old.site_id, old.unit_id, old.machine_id, old.role_id, old.alarm_id, old.sms, old.email, old.threshold, old.threshold_refresh_interval, old.alarm_counter, old.alarm_first_date_time, old.created_by, old.created_date, old.modified_by, old.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`USER_ALARM_PREFERENCE` (
`id` VARCHAR(45) NOT NULL,
  `user_id` VARCHAR(45) NULL,
  `alarm_id` VARCHAR(45) NULL,
  `active` TINYINT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX `Ref_alarmIdColumn_idx` (`alarm_id` ASC),
  INDEX `Ref_userIdColumn_idx` (`user_id` ASC),
	PRIMARY KEY (`id`),
  CONSTRAINT `Ref_alarmIdColumn0`
    FOREIGN KEY (`alarm_id`)
    REFERENCES `hydro`.`ALARM_MASTER` (`alarm_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `Ref_userIdColumn`
    FOREIGN KEY (`user_id`)
    REFERENCES `hydro`.`USER_MASTER` (`user_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`USER_ALARM_PREFERENCE_BCKP` (
  `id` VARCHAR(45) NOT NULL,
  `user_id` VARCHAR(45) NULL,
  `alarm_id` VARCHAR(45) NULL,
  `active` TINYINT NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.`TRIG_USER_ALARM_PREFERENCE_UPDATE`
after update on `hydro`.`USER_ALARM_PREFERENCE`
for each row 
insert into `hydro`.`USER_ALARM_PREFERENCE_BCKP`(id,user_id, alarm_id, active, created_by, created_date, modified_by, modified_date)
values (NEW.id,NEW.user_id, NEW.alarm_id, NEW.active, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_USER_ALARM_PREFERENCE_DELETE`
after delete on `hydro`.`USER_ALARM_PREFERENCE`
for each row
insert into `hydro`.`USER_ALARM_PREFERENCE_BCKP`(id,user_id, alarm_id, active, created_by, created_date, modified_by, modified_date)
values (old.id,old.user_id, old.alarm_id, old.active, old.created_by, old.created_date, old.modified_by, old.modified_date);

INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('45', '1'), ('45', '2'),('15', '2');

INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_type`, `alarm_name`, `description`) VALUES ('8', '0', 'Leak Test Alarm','The test performed prior to every product dose to see if there are flowmeter counts when the channel is pressurized with water.');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_type`, `alarm_name`, `description`) VALUES ('9', '0', 'Water Test Alarm','A water flow test performed after the leak test and prior to every product dose');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_type`, `alarm_name`, `description`) VALUES ('10', '0', 'Flow Meter/Dosing Alarm','The programmed dosage of product did not occur in the time allowed. The time allowed is based on a value determined by calibration plus an added % of that time');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_type`, `alarm_name`, `description`) VALUES ('33', '0', 'Air Pressure Failure Alarm','A drop in air pressure below the minimum requirement to operate the Air Assist');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_type`, `alarm_name`, `description`) VALUES ('32', '0', 'Emergency Stop/Unit Lock Alarm','EMERGENCY STOP button is depressed.');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_type`, `alarm_name`, `description`) VALUES ('16', '0', 'Minimum Level of Product/Drum Lance Alarm','Float switch in the drum lance is reading low levels or product');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_type`, `alarm_name`, `description`) VALUES ('2', '0', 'Cycles with Missed Phases','A load that has sent an end of load signal without completing all the programmed phases. A phase is a dose request within a formula.');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_type`, `alarm_name`, `description`) VALUES ('1', '0', 'Unfinished Cycles','The washer is started for a new load without the Dositec System receiving an end of load signal from the previous load');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_type`, `alarm_name`, `description`) VALUES ('11', '0', 'Flow Meter/Flush Alarm','The programmed amount of water for flushing did not occur in the time allowed. The time allowed is based on a value determined by calibration.');
INSERT INTO `hydro`.`alarm_master` (`alarm_id`, `alarm_type`, `alarm_name`, `description`) VALUES ('101', '1', 'Machine Idle Too long', 'The amount of time after a load is finished has exceeded a pre-set value that is set by the Chemical Company or Site Manager.');

CREATE TABLE IF NOT EXISTS `hydro`.`tunnel_module_product_association` (
  `id` VARCHAR(50) NOT NULL,
  `tunnel_id` VARCHAR(50) NULL,
  `module_id` VARCHAR(50) NULL,
  `product_id` VARCHAR(45) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  INDEX `tunnel_id_ref_idx` (`tunnel_id` ASC),
  CONSTRAINT `tunnel_id_ref`
    FOREIGN KEY (`tunnel_id`)
    REFERENCES `hydro`.`TUNNEL_MASTER` (`tunnel_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`tunnel_module_product_association_bckp` (
  `id` VARCHAR(50) NOT NULL,
  `tunnel_id` VARCHAR(50) NULL,
  `module_id` VARCHAR(50) NULL,
  `product_id` VARCHAR(45) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`))
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_Module_Product_UPDATE
AFTER UPDATE ON `hydro`.`tunnel_module_product_association`
for each row
insert into `hydro`.`tunnel_module_product_association_bckp`(id, tunnel_id, module_id, product_id, created_by, created_date, modified_by, modified_date)
values(NEW.id, NEW.tunnel_id, NEW.module_id, NEW.product_id,  NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE TRIGGER `hydro`.TRIG_Module_Product_DELETE
after delete on `hydro`.`tunnel_module_product_association`
for each row
insert into `hydro`.`tunnel_module_product_association_bckp`(id, tunnel_id, module_id, product_id, created_by, created_date, modified_by, modified_date)
values(old.id, old.tunnel_id, old.module_id, old.product_id, old.created_by, old.created_date, old.modified_by, old.modified_date);

CREATE TABLE IF NOT EXISTS `hydro`.`formula_phases` (
  `f_phase_id` VARCHAR(45) NOT NULL,
  `id` INT(11) NULL,
  `id_formula` INT(3) NULL,
  `num_phase` INT(2) NULL,
  `delay_1` INT(3) NULL,
  `delay_2` INT(3) NULL,
  `uid` VARCHAR(255) NULL,
  `equipment_id` VARCHAR(45) NULL,
  `formula_id` VARCHAR(45) NULL,
  PRIMARY KEY (`f_phase_id`),
  INDEX `formula_id_PhasesCons_idx` (`formula_id` ASC),
  INDEX `Equipment_id_phaseCons_idx` (`equipment_id` ASC),
  CONSTRAINT `formula_id_PhasesCons`
	  FOREIGN KEY (`formula_id`)
	  REFERENCES `hydro`.`formula_master` (`formula_id`)
	  ON DELETE NO ACTION
	  ON UPDATE NO ACTION,
  CONSTRAINT `Equipment_id_phaseCons`
	  FOREIGN KEY (`equipment_id`)
	  REFERENCES `hydro`.`equipment_master` (`equipment_id`)
	  ON DELETE NO ACTION
	  ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;
  
CREATE TABLE IF NOT EXISTS `hydro`.`formula_phases_bckp` (
  `f_phase_id` VARCHAR(45) NOT NULL,
  `id` INT(11) NULL,
  `id_formula` INT(3) NULL,
  `num_phase` INT(2) NULL,
  `delay_1` INT(3) NULL,
  `delay_2` INT(3) NULL,
  `uid` VARCHAR(255) NULL,
  `equipment_id` VARCHAR(45) NULL,
  `formula_id` VARCHAR(45) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;
  
create trigger `hydro`.TRIG_FORMULA_PHASES_UPDATE
after update on `hydro`.formula_phases
for each row
insert into `hydro`.formula_phases_bckp(f_phase_id, id, id_formula, num_phase, delay_1, delay_2, uid, equipment_id,formula_id)
values(NEW.f_phase_id, NEW.id, NEW.id_formula, NEW.num_phase, NEW.delay_1, NEW.delay_2, NEW.uid, NEW.equipment_id, NEW.formula_id);

create trigger `hydro`.TRIG_FORMULA_PHASES_DELETE
after delete on `hydro`.formula_phases
for each row
insert into `hydro`.formula_phases_bckp(f_phase_id, id, id_formula, num_phase, delay_1, delay_2, uid, equipment_id, formula_id)
values(old.f_phase_id, old.id, old.id_formula, old.num_phase, old.delay_1, old.delay_2, old.uid, old.equipment_id, old.formula_id);

CREATE TABLE IF NOT EXISTS `hydro`.`formula_dosages` (
  `f_dosage_id` VARCHAR(50) NOT NULL,
  `id` INT(11) NULL,
  `id_phase` INT(11) NULL,
  `dosage_order` INT(11) NULL,
  `id_product` INT(11) NULL,
  `dose` DECIMAL(5,2) NULL,
  `delay_bit` TINYINT(1) NULL,
  `uid` VARCHAR(255) NULL,
  `product_uid` VARCHAR(255) NULL,
  `f_phase_id` VARCHAR(255) NULL,
  PRIMARY KEY (`f_dosage_id`),
  INDEX `f_phase_idConst_idx` (`f_phase_id` ASC),
  CONSTRAINT `f_phase_idConst`
  FOREIGN KEY (`f_phase_id`)
  REFERENCES `hydro`.`formula_phases` (`f_phase_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`formula_dosages_bckp` (
  `f_dosage_id` VARCHAR(50) NOT NULL,
  `id` INT(11) NULL,
  `id_phase` INT(11) NULL,
  `dosage_order` INT(11) NULL,
  `id_product` INT(11) NULL,
  `dose` DECIMAL(5,2) NULL,
  `delay_bit` TINYINT(1) NULL,
  `uid` VARCHAR(255) NULL,
  `product_uid` VARCHAR(255) NULL,
  `f_phase_id` VARCHAR(255) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_FORMULA_DOSAGES_UPDATE
after update on `hydro`.formula_dosages
for each row
insert into `hydro`.formula_dosages_bckp(f_dosage_id, id, id_phase, dosage_order, id_product, dose, delay_bit, uid, product_uid,f_phase_id)
values(NEW.f_dosage_id, NEW.id, NEW.id_phase, NEW.dosage_order, NEW.id_product, NEW.dose, NEW.delay_bit, NEW.uid, NEW.product_uid, NEW.f_phase_id);

create trigger `hydro`.TRIG_FORMULA_DOSAGES_DELETE
after delete on `hydro`.formula_dosages
for each row
insert into `hydro`.formula_dosages_bckp(f_dosage_id, id, id_phase, dosage_order, id_product, dose, delay_bit, uid, product_uid, f_phase_id)
values(old.f_dosage_id, old.id, old.id_phase, old.dosage_order, old.id_product, old.dose, old.delay_bit, old.uid, old.product_uid, old.f_phase_id);

CREATE TABLE IF NOT EXISTS `hydro`.`channel_master` (
  `channel_id` VARCHAR(45) NOT NULL,
  `uid` VARCHAR(255) NULL,
  `alarms_skipped` INT(1) NULL,
  `alarms_tolerance` INT(2) NULL,
  `date_last_change` DATETIME NULL,
  `dosing_mode` INT(1) NULL,
  `flush_air_ml` INT(4) NULL,
  `flush_air_time` INT(3) NULL,
  `flush_type` INT(1) NULL,
  `name` VARCHAR(16) NULL,
  `pump_type` INT(1) NULL,
  `water_test` INT(4) NULL,
  `equipment_id` VARCHAR(100) NULL,
  PRIMARY KEY (`channel_id`),
  INDEX `equipment_master_const_idx` (`equipment_id` ASC),
  CONSTRAINT `equipment_master_const`
  FOREIGN KEY (`equipment_id`)
  REFERENCES `hydro`.`equipment_master` (`equipment_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`channel_master_bckp` (
  `channel_id` VARCHAR(45) NOT NULL,
  `uid` VARCHAR(255) NULL,
  `alarms_skipped` INT(1) NULL,
  `alarms_tolerance` INT(2) NULL,
  `date_last_change` DATETIME NULL,
  `dosing_mode` INT(1) NULL,
  `flush_air_ml` INT(4) NULL,
  `flush_air_time` INT(3) NULL,
  `flush_type` INT(1) NULL,
  `name` VARCHAR(16) NULL,
  `pump_type` INT(1) NULL,
  `water_test` INT(4) NULL,
  `equipment_id` VARCHAR(100) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_CHANNEL_MASTER_UPDATE
after update on `hydro`.channel_master
for each row
insert into `hydro`.channel_master_bckp(channel_id, uid, alarms_skipped, alarms_tolerance, date_last_change, dosing_mode, flush_air_ml, flush_air_time, flush_type, name, pump_type, water_test, equipment_id)
values(NEW.channel_id, NEW.uid, NEW.alarms_skipped, NEW.alarms_tolerance, NEW.date_last_change, NEW.dosing_mode, NEW.flush_air_ml, NEW.flush_air_time, NEW.flush_type, NEW.name, NEW.pump_type, NEW.water_test, NEW.equipment_id);

create trigger `hydro`.TRIG_CHANNEL_MASTER_DELETE
after delete on `hydro`.channel_master
for each row
insert into `hydro`.channel_master_bckp(channel_id, uid, alarms_skipped, alarms_tolerance, date_last_change, dosing_mode, flush_air_ml, flush_air_time, flush_type, name, pump_type, water_test, equipment_id)
values(old.channel_id, old.uid, old.alarms_skipped, old.alarms_tolerance, old.date_last_change, old.dosing_mode, old.flush_air_ml, old.flush_air_time, old.flush_type, old.name, old.pump_type, old.water_test, old.equipment_id);







