SET SQL_SAFE_UPDATES = 0;
update `hydro`.FILE_MASTER set is_active = 1 where file_id in (select file_id from `hydro`.site_master where file_id is not null);
SET SQL_SAFE_UPDATES = 1;
