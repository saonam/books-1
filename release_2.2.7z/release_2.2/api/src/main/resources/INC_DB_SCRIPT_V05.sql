INSERT INTO `hydro`.`privilege_master` (`privilege_id`,`privilege_name`) VALUES 
('41','CREATE-SAME-LEVEL-USER'),('42','SITE-FULL-EDIT');

INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES 
('41', '1'),('42','1'),('42','2');

DROP TRIGGER `hydro`.TRIG_Role_UPDATE;
DROP TRIGGER `hydro`.TRIG_Role_DELETE;

ALTER TABLE `hydro`.`role_master_bckp` 
ADD COLUMN `org_type` VARCHAR(100) NULL AFTER `clearance_level`;

UPDATE `hydro`.`role_master` SET `org_type`='DEFAULT' WHERE `role_id`='0';

create trigger `hydro`.TRIG_Role_UPDATE
after update on `hydro`.ROLE_MASTER
for each row
insert into `hydro`.ROLE_MASTER_BCKP(role_id, user_role, clearance_level, org_type, created_by, created_date, modified_by, modified_date)
values(NEW.role_id, NEW.user_role, NEW.clearance_level, NEW.org_type, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

create trigger `hydro`.TRIG_Role_DELETE
after delete on `hydro`.ROLE_MASTER
for each row
insert into `hydro`.ROLE_MASTER_BCKP(role_id, user_role, clearance_level, org_type, created_by, created_date, modified_by, modified_date)
values(old.role_id, old.user_role, old.clearance_level, old.org_type,old.created_by, old.created_date, old.modified_by, old.modified_date);

