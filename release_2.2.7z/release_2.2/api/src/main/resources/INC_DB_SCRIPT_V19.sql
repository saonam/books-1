INSERT INTO `hydro`.`privilege_master` (`privilege_id`, `privilege_name`) VALUES ('44', 'REAL-TIME-REPORT');

INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('44', '1');
INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('44', '2');
INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('44', '3');
INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('44', '4');
INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('44', '5');
INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('44', '6');
INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('44', '7');
INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES ('44', '8');

