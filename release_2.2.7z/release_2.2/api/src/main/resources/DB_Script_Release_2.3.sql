CREATE TABLE IF NOT EXISTS `hydro`.`cloud_failed_events` (
  `id` VARCHAR(100) NOT NULL,
  `site_id` VARCHAR(100) NULL,
  `unit_id` VARCHAR(100) NULL,
  `serial_number` VARCHAR(100) NULL,
  `event_id` VARCHAR(100) NULL,
  `event_time` VARCHAR(100) NULL,
  `event_blob` BLOB NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cause` VARCHAR(100) NULL,
  `error_code` INT(11) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`cloud_failed_events_bckp` (
  `id` VARCHAR(100) NOT NULL,
  `site_id` VARCHAR(100) NULL,
  `unit_id` VARCHAR(100) NULL,
  `serial_number` VARCHAR(100) NULL,
  `event_id` VARCHAR(100) NULL,
  `event_time` VARCHAR(100) NULL,
  `event_blob` BLOB NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cause` VARCHAR(100) NULL,
  `error_code` INT(11) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_CLOUD_FAILED_EVENTS_DELETE
after delete on `hydro`.cloud_failed_events
for each row
insert into `hydro`.cloud_failed_events_bckp(id, site_id, unit_id, serial_number, event_id, event_time,created_date,cause,error_code)
values(old.id, old.site_id, old.unit_id, old.serial_number, old.event_id, old.event_time,old.created_date,old.cause,old.error_code);
