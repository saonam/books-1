INSERT INTO `hydro`.`privilege_master` (`privilege_bit`, `privilege_name`) VALUES ('8388608', 'OBS&REC_VIEW');
INSERT INTO `hydro`.`privilege_master` (`privilege_bit`, `privilege_name`) VALUES ('16777216', 'OBS&REC_CREATE');
INSERT INTO `hydro`.`privilege_master` (`privilege_bit`, `privilege_name`) VALUES ('33554432', 'OBS&REC_DELETE');
INSERT INTO `hydro`.`privilege_master` (`privilege_bit`, `privilege_name`) VALUES ('67108864', 'OBS&REC_UPDATE');

UPDATE `hydro`.`role_master` SET `clearance_level`='134200815' WHERE `role_id`='1';
UPDATE `hydro`.`role_master` SET `clearance_level`='16223331' WHERE `role_id`='2';
