SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `hydro`.`file_master` 
DROP COLUMN `unit_id`;

ALTER TABLE `hydro`.`file_master_bckp` 
DROP COLUMN `unit_id`;

DROP trigger `hydro`.TRIG_FILE_MASTER_UPDATE;

DROP trigger `hydro`.TRIG_FILE_MASTER_DELETE;

create trigger `hydro`.TRIG_FILE_MASTER_UPDATE
after update on `hydro`.FILE_MASTER
for each row
insert into `hydro`.FILE_MASTER_BCKP(file_id, name, created_by, created_date, status, site_id, description, detailed_description,version,modified_by,modified_date, file_type,device_id,is_active)
values(NEW.file_id, NEW.name, NEW.created_by, NEW.created_date, NEW.status, NEW.site_id, NEW.description, NEW.detailed_description, NEW.version, NEW.modified_by,NEW.modified_date, NEW.file_type, NEW.device_id, NEW.is_active);

create trigger `hydro`.TRIG_FILE_MASTER_DELETE
after delete on `hydro`.FILE_MASTER
for each row
insert into `hydro`.FILE_MASTER_BCKP(file_id, name, created_by, created_date, status, site_id, description, detailed_description, version,modified_by,modified_date, file_type,device_id,is_active)
values(old.file_id, old.name, old.created_by, old.created_date, old.status, old.site_id, old.description, old.detailed_description, old.version, old.modified_by,old.modified_date, old.file_type, old.device_id, old.is_active);

ALTER TABLE `hydro`.`formula_master` 
DROP COLUMN `updated`,
DROP COLUMN `statistic_production`,
DROP COLUMN `used_phases`,
DROP COLUMN `date_last_change`,
DROP COLUMN `percentage`;

ALTER TABLE `hydro`.`formula_master_bckp` 
DROP COLUMN `updated`,
DROP COLUMN `statistic_production`,
DROP COLUMN `used_phases`,
DROP COLUMN `date_last_change`,
DROP COLUMN `percentage`;

DROP trigger `hydro`.TRIG_FORMULA_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_FORMULA_MASTER_DELETE;

create trigger `hydro`.TRIG_FORMULA_MASTER_UPDATE
after update on `hydro`.FORMULA_MASTER
for each row
insert into `hydro`.FORMULA_MASTER_BCKP(formula_id, equipment_id, lm2_seq, name, `load`, phases, color, created_by, created_date, modified_by, modified_date, uid)
values(NEW.formula_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.load, NEW.phases, NEW.color, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid);

create trigger `hydro`.TRIG_FORMULA_MASTER_DELETE
after delete on `hydro`.FORMULA_MASTER
for each row
insert into `hydro`.FORMULA_MASTER_BCKP(formula_id, equipment_id, lm2_seq, name, `load`, phases, color, created_by, created_date, modified_by, modified_date, uid)
values(old.formula_id, old.equipment_id, old.lm2_seq, old.name, old.load, old.phases, old.color, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid);

DROP TABLE `hydro`.`formula_phases`, `hydro`.`formula_phases_bckp`;

DROP TABLE `hydro`.`formula_dosages`, `hydro`.`formula_dosages_bckp`;

ALTER TABLE `hydro`.`equipment_master` 
DROP COLUMN `warning_product`,
DROP COLUMN `warning_water`,
DROP COLUMN `warning_cycles`,
DROP COLUMN `report_period`,
DROP COLUMN `email`,
DROP COLUMN `call_center`,
DROP COLUMN `first_formulas_upload`,
DROP COLUMN `first_conf_upload`,
DROP COLUMN `checksum`,
DROP COLUMN `date_last_estadisticas_sync`,
DROP COLUMN `date_last_sync`,
DROP COLUMN `date_reset_statistics`,
DROP COLUMN `products_channel_3`,
DROP COLUMN `products_channel_2`,
DROP COLUMN `products_channel_1`,
#DROP COLUMN `washer_extractors`,
DROP COLUMN `units_system`,
DROP COLUMN `language`,
DROP COLUMN `date_power_on`,
DROP COLUMN `start_up_date`,
DROP COLUMN `revision`,
DROP COLUMN `warning_level`,
DROP COLUMN `unit_id`;

ALTER TABLE `hydro`.`equipment_master_bckp` 
DROP COLUMN `warning_product`,
DROP COLUMN `warning_water`,
DROP COLUMN `warning_cycles`,
DROP COLUMN `report_period`,
DROP COLUMN `email`,
DROP COLUMN `call_center`,
DROP COLUMN `first_formulas_upload`,
DROP COLUMN `first_conf_upload`,
DROP COLUMN `checksum`,
DROP COLUMN `date_last_estadisticas_sync`,
DROP COLUMN `date_last_sync`,
DROP COLUMN `date_reset_statistics`,
DROP COLUMN `products_channel_3`,
DROP COLUMN `products_channel_2`,
DROP COLUMN `products_channel_1`,
#DROP COLUMN `washer_extractors`,
DROP COLUMN `units_system`,
DROP COLUMN `language`,
DROP COLUMN `date_power_on`,
DROP COLUMN `start_up_date`,
DROP COLUMN `revision`,
DROP COLUMN `warning_level`,
DROP COLUMN `unit_id`;

DROP trigger `hydro`.TRIG_EQUIPMENT_UPDATE;
DROP trigger `hydro`.TRIG_EQUIPMENT_DELETE;

create trigger `hydro`.TRIG_EQUIPMENT_UPDATE
after update on `hydro`.EQUIPMENT_MASTER
for each row
insert into `hydro`.EQUIPMENT_MASTER_BCKP(equipment_id, lm2_seq, site_id, alias, equipment_type, slave, ip_address, observations, washer_count, tunnel_count, w_machine_chnl_count, pump_count, channel_count, is_active, created_by, created_date, modified_by, modified_date, version, file_id, device_id)
values(NEW.equipment_id, NEW.lm2_seq, NEW.site_id, NEW.alias, NEW.equipment_type, NEW.slave, NEW.ip_address, NEW.observations, NEW.washer_count, NEW.tunnel_count, NEW.w_machine_chnl_count, NEW.pump_count, NEW.channel_count, NEW.is_active, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.version, NEW.file_id, NEW.device_id);

create trigger `hydro`.TRIG_EQUIPMENT_DELETE
after delete on `hydro`.EQUIPMENT_MASTER
for each row
insert into `hydro`.EQUIPMENT_MASTER_BCKP(equipment_id, lm2_seq, site_id, alias, equipment_type, slave, ip_address, observations, washer_count, tunnel_count, w_machine_chnl_count, pump_count, channel_count, is_active, created_by, created_date, modified_by, modified_date, version, file_id, device_id)
values(old.equipment_id, old.lm2_seq, old.site_id, old.alias, old.equipment_type, old.slave, old.ip_address, old.observations, old.washer_count, old.tunnel_count, old.w_machine_chnl_count, old.pump_count, old.channel_count, old.is_active, old.created_by, old.created_date, old.modified_by, old.modified_date, old.version, old.file_id, old.device_id);

DROP TABLE `hydro`.`channel_master`, `hydro`.`channel_master_bckp`;

ALTER TABLE `hydro`.`water_master` 
DROP COLUMN `date_last_change`,
DROP COLUMN `date_calibration`,
DROP COLUMN `channel`;

ALTER TABLE `hydro`.`water_master_bckp` 
DROP COLUMN `date_last_change`,
DROP COLUMN `date_calibration`,
DROP COLUMN `channel`;

DROP trigger `hydro`.TRIG_WATER_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_WATER_MASTER_DELETE;

create trigger `hydro`.TRIG_WATER_MASTER_UPDATE
after update on `hydro`.WATER_MASTER
for each row
insert into `hydro`.WATER_MASTER_BCKP(water_id, equipment_id, name, kf,lm2_seq, flow, water_time, cellphone_minute, docification_mode, seperation_ml, ignored_alarms, percentage, diameter, pump_type, created_by, created_date, modified_by, modified_date, uid)
values(NEW.water_id, NEW.equipment_id, NEW.name, NEW.kf,NEW.lm2_seq, NEW.flow, NEW.water_time, NEW.cellphone_minute, NEW.docification_mode, NEW.seperation_ml, NEW.ignored_alarms, NEW.percentage, NEW.diameter, NEW.pump_type, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid);

create trigger `hydro`.TRIG_WATER_MASTER_DELETE
after delete on `hydro`.WATER_MASTER
for each row
insert into `hydro`.WATER_MASTER_BCKP(water_id, equipment_id, name, kf,lm2_seq, flow, water_time, cellphone_minute, docification_mode, seperation_ml, ignored_alarms, percentage, diameter, pump_type, created_by, created_date, modified_by, modified_date, uid)
values(old.water_id, old.equipment_id, old.name, old.kf, old.lm2_seq,old.flow, old.water_time, old.cellphone_minute, old.docification_mode, old.seperation_ml, old.ignored_alarms, old.percentage, old.diameter, old.pump_type, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid);

ALTER TABLE `hydro`.`product_master` 
DROP COLUMN `statistic_warnings`,
DROP COLUMN `statistic_production`,
DROP COLUMN `rotameter_sensor`,
DROP COLUMN `pump_safe_stop`,
DROP COLUMN `estate`,
DROP COLUMN `dosing_mode`,
DROP COLUMN `date_last_change`,
DROP COLUMN `alarms_tolerance`;

ALTER TABLE `hydro`.`product_master_bckp` 
DROP COLUMN `statistic_warnings`,
DROP COLUMN `statistic_production`,
DROP COLUMN `rotameter_sensor`,
DROP COLUMN `pump_safe_stop`,
DROP COLUMN `estate`,
DROP COLUMN `dosing_mode`,
DROP COLUMN `date_last_change`,
DROP COLUMN `alarms_tolerance`;

DROP trigger `hydro`.TRIG_PRODUCT_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_PRODUCT_MASTER_DELETE;

create trigger `hydro`.TRIG_PRODUCT_MASTER_UPDATE
after update on `hydro`.PRODUCT_MASTER
for each row
insert into `hydro`.PRODUCT_MASTER_BCKP(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow, frequency, docification_mode, priority, contact, alarms_ignored, percentage, drag_type, pump_speed, format, price, calibration, color1, color2, created_by, created_date, modified_by, modified_date, uid)
values(NEW.product_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.density, NEW.concentration, NEW.kf, NEW.flow, NEW.frequency, NEW.docification_mode, NEW.priority, NEW.contact, NEW.alarms_ignored, NEW.percentage, NEW.drag_type, NEW.pump_speed, NEW.format, NEW.price, NEW.calibration, NEW.color1, NEW.color2, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid);

create trigger `hydro`.TRIG_PRODUCT_MASTER_DELETE
after delete on `hydro`.PRODUCT_MASTER
for each row
insert into `hydro`.PRODUCT_MASTER_BCKP(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow, frequency, docification_mode, priority, contact, alarms_ignored, percentage, drag_type, pump_speed, format, price, calibration, color1, color2, created_by, created_date, modified_by, modified_date, uid)
values(old.product_id, old.equipment_id, old.lm2_seq, old.name, old.density, old.concentration, old.kf, old.flow, old.frequency, old.docification_mode, old.priority, old.contact, old.alarms_ignored, old.percentage, old.drag_type, old.pump_speed, old.format, old.price, old.calibration, old.color1, old.color2, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid);

ALTER TABLE `hydro`.`washer_master` 
DROP COLUMN `trigger_mode`,
DROP COLUMN `kg_sel`,
DROP COLUMN `hold_timeout`,
DROP COLUMN `hold_mode`,
DROP COLUMN `hold_delay`,
#DROP COLUMN `formula_id`,
DROP COLUMN `flush_l`,
DROP COLUMN `end_signal_pump`,
DROP COLUMN `end_mode`,
DROP COLUMN `end_formula`,
DROP COLUMN `date_last_change`;

ALTER TABLE `hydro`.`washer_master_bckp` 
DROP COLUMN `trigger_mode`,
DROP COLUMN `kg_sel`,
DROP COLUMN `hold_timeout`,
DROP COLUMN `hold_mode`,
DROP COLUMN `hold_delay`,
#DROP COLUMN `formula_id`,
DROP COLUMN `flush_l`,
DROP COLUMN `end_signal_pump`,
DROP COLUMN `end_mode`,
DROP COLUMN `end_formula`,
DROP COLUMN `date_last_change`;

DROP trigger `hydro`.TRIG_WASHER_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_WASHER_MASTER_DELETE;

create trigger `hydro`.TRIG_WASHER_MASTER_UPDATE
after update on `hydro`.WASHER_MASTER
for each row
insert into `hydro`.WASHER_MASTER_BCKP(washer_id, equipment_id, lm2_seq, name, `load`, modifiable_load, ltr_drag, cellular_minutes, id_formula, work_mode, reset_mode, reset_signal, reset_formula, unused_machine, unused_time_delay, unused_timeout, t_acceptation, t_repetition, t_lock, type_programmer, signal_count, signal_voltage, signal_connection, observation, created_by, created_date, modified_by, modified_date, uid)
values(NEW.washer_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.load, NEW.modifiable_load, NEW.ltr_drag, NEW.cellular_minutes, NEW.id_formula, NEW.work_mode, NEW.reset_mode, NEW.reset_signal, NEW.reset_formula, NEW.unused_machine, NEW.unused_time_delay, NEW.unused_timeout, NEW.t_acceptation, NEW.t_repetition, NEW.t_lock, NEW.type_programmer, NEW.signal_count, NEW.signal_voltage, NEW.signal_connection, NEW.observation, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid);

create trigger `hydro`.TRIG_WASHER_MASTER_DELETE
after delete on `hydro`.WASHER_MASTER
for each row
insert into `hydro`.WASHER_MASTER_BCKP(washer_id, equipment_id, lm2_seq, name, `load`, modifiable_load, ltr_drag, cellular_minutes, id_formula, work_mode, reset_mode, reset_signal, reset_formula, unused_machine, unused_time_delay, unused_timeout, t_acceptation, t_repetition, t_lock, type_programmer, signal_count, signal_voltage, signal_connection, observation, created_by, created_date, modified_by, modified_date, uid)
values(old.washer_id, old.equipment_id, old.lm2_seq, old.name, old.load, old.modifiable_load, old.ltr_drag, old.cellular_minutes, old.id_formula, old.work_mode, old.reset_mode, old.reset_signal, old.reset_formula, old.unused_machine, old.unused_time_delay, old.unused_timeout, old.t_acceptation, old.t_repetition, old.t_lock, old.type_programmer, old.signal_count, old.signal_voltage, old.signal_connection, old.observation, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid);

SET FOREIGN_KEY_CHECKS=1;
