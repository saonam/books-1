DROP Trigger `hydro`.TRIG_OBSERVATION_MASTER_UPDATE;
DROP Trigger `hydro`.TRIG_OBSERVATION_MASTER_DELETE;

ALTER TABLE `hydro`.`observation_master` 
ADD COLUMN `site_id` VARCHAR(100) NULL AFTER `observation_id`,
ADD COLUMN `lm2_seq` VARCHAR(100) NULL AFTER `site_id`;

UPDATE `hydro`.`observation_master` OM 
set site_id = (select EM.site_id from `hydro`.equipment_master EM where EM.equipment_id=OM.equipment_id) , 
lm2_seq = (select EM.lm2_seq from `hydro`.equipment_master EM where EM.equipment_id=OM.equipment_id),
modified_date=modified_date;

ALTER TABLE `hydro`.`observation_master` 
DROP FOREIGN KEY `EquipmentID96`;
ALTER TABLE `hydro`.`observation_master` 
ADD INDEX `obseRecoSiteConstra_idx` (`site_id` ASC),
DROP INDEX `Equipment_idx` ;
ALTER TABLE `hydro`.`observation_master` 
ADD CONSTRAINT `obseRecoSiteConstra`
  FOREIGN KEY (`site_id`)
  REFERENCES `hydro`.`site_master` (`site_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;
  
ALTER TABLE `hydro`.`observation_master_bckp` 
ADD COLUMN `site_id` VARCHAR(100) NULL AFTER `observation_id`,
ADD COLUMN `lm2_seq` VARCHAR(100) NULL AFTER `site_id`;

create trigger `hydro`.TRIG_OBSERVATION_MASTER_UPDATE
after update on `hydro`.OBSERVATION_MASTER
for each row
insert into `hydro`.OBSERVATION_MASTER_BCKP(observation_id,site_id,lm2_seq, observation, recommendation, created_by, created_date, modified_by, modified_date, equipment_id, month, year)
values(NEW.observation_id,NEW.site_id,NEW.lm2_seq, NEW.observation, NEW.recommendation, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.equipment_id, NEW.month, NEW.year);

create trigger `hydro`.TRIG_OBSERVATION_MASTER_DELETE
after delete on `hydro`.OBSERVATION_MASTER
for each row
insert into `hydro`.OBSERVATION_MASTER_BCKP(observation_id,site_id,lm2_seq, observation, recommendation, created_by, created_date, modified_by, modified_date, equipment_id, month, year)
values(old.observation_id,old.site_id,old.lm2_seq, old.observation, old.recommendation, old.created_by, old.created_date, old.modified_by, old.modified_date, old.equipment_id, old.month, old.year);

