DELETE FROM `hydro`.`role_privilege_association` WHERE `role_id`='2' and `privilege_id`='42';
DELETE FROM `hydro`.`role_privilege_association` WHERE `role_id`='4' and `privilege_id`='19';

