DELETE FROM `hydro`.`role_privilege_association` WHERE `role_id`='1' and `privilege_id`='5';

DELETE FROM `hydro`.`role_privilege_association` WHERE `role_id`='1' and `privilege_id`='6';

DELETE FROM `hydro`.`role_privilege_association` WHERE `role_id`='1' and `privilege_id`='13';

DELETE FROM `hydro`.`role_privilege_association` WHERE `role_id`='1' and `privilege_id`='18';
