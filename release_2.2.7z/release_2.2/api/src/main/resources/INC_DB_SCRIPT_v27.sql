use hydro;

SET SQL_SAFE_UPDATES = 0;
update preference_master PM join washer_master WM on WM.washer_id=PM.machine_id set PM.machine_id=WM.lm2_seq;

SET SQL_SAFE_UPDATES = 0;
update preference_master PM join tunnel_master TM on TM.tunnel_id=PM.machine_id set PM.machine_id=TM.lm2_seq;
