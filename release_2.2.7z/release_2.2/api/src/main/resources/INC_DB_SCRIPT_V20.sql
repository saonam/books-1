CREATE TABLE `ALERT_SUBSCRIPTION` (
  `site_id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `user_role` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `created_by` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `modified_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`site_id`,`user_role`),
  CONSTRAINT `siteIdAlert` FOREIGN KEY (`site_id`) REFERENCES `site_master` (`site_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`ALERT_SUBSCRIPTION_BCKP` (
  `site_id` VARCHAR(100) NOT NULL,
  `user_role` VARCHAR(100) NULL,
  `created_by` VARCHAR(100) NULL,
  `created_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_by` VARCHAR(100) NULL,
  `modified_date` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_alert_UPDATE
AFTER UPDATE ON `hydro`.ALERT_SUBSCRIPTION
for each row
insert into `hydro`.ALERT_SUBSCRIPTION_BCKP(site_id, user_role, created_by, created_date, modified_by, modified_date )
values(NEW.site_id, NEW.user_role, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE TRIGGER `hydro`.TRIG_alert_DELETE
after delete on `hydro`.ALERT_SUBSCRIPTION
for each row
insert into `hydro`.ALERT_SUBSCRIPTION_BCKP(site_id, user_role, created_by, created_date, modified_by, modified_date)
values(old.site_id, old.user_role, old.created_by, old.created_date, old.modified_by, old.modified_date);
