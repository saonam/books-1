--TO UPDATE DEVICE_ID COLUMN IN FILE_MASTER
--update the device_id column to w.r.t siteId
update  file_master set device_id="897564b4a5ee491ca9fc8b7d683ac9e6" , is_active='1' 
 where file_id=(select file_id from site_master where site_id="f2ecd9ea23e742b894d0cf3b73ef372b");

--TO POPULATE DEVICE_ID COLUMN IN EQUIPMENT_MASTER
--Execute below query for the concerned site_id:
--STMT 1 :		Select file_id, device_id FROM hydro.file_master where site_id="f2ecd9ea23e742b894d0cf3b73ef372b" and is_active =1;
--Use the file_id from the previous query in the below query
--STMT 2 :		select equipment_id from hydro.equipment_master where file_id ="cad38d086149496785ffb914533a4a57652" and equipment_type=1;
--Use the device_id from STMT 1 and equipment_id from STMT 2 in the below update statement
--STMT 3 : 


--STMT 4		select equipment_id from hydro.equipment_master where file_id ="cad38d086149496785ffb914533a4a57651" and equipment_type=0;
--Use the device_id from STMT 1 and equipment_id from STMT 4 in the below update statement
--STMT 5 :
update hydro.equipment_master set device_id="897564b4a5ee491ca9fc8b7d683ac9e6" where equipment_id="2acd2b7778d04302a32da6f900a13df1";

--TO POPULATE DEVICE_ID COLUMN IN PREFERENCE_MASTER
--update the unit_id column to contain device_id, instead of lm2_seq in preference_master table using below statement.  use the site_id used in STMT 1 above

update hydro.preference_master set unit_id="897564b4a5ee491ca9fc8b7d683ac9e6" where site_id="f2ecd9ea23e742b894d0cf3b73ef372b" and unit_id=2;

update hydro.observation_master set device_id = "897564b4a5ee491ca9fc8b7d683ac9e6" where site_id ="f2ecd9ea23e742b894d0cf3b73ef372b" and lm2_seq = "2";

--INSERT FILE_MASTER, the version of the new file should be same as the updated file. 
insert into file_master (file_id, name, created_date,created_by, status,  site_id, description, detailed_description, version, file_type,device_id,is_active) 
VALUES (REPLACE( UUID( ) ,  '-',  '' ),"LA_CALANDRA_LOCAL.LM2",now(),"testuser",3,"f2ecd9ea23e742b894d0cf3b73ef372b","success","success",5,1,"ba1bec706ea6471585d7c782743fc9b4",1);

--- fm1.file_id is the newly created file entry and fm2.file_id is the existing file having Blob value
-- Update above created file with blob value(represented as lm2_file)
update file_master fm1 set fm1.lm2_file = (select fm2.lm2_file from (SELECT * FROM file_master) fm2 where fm2.file_id = "cad38d086149496785ffb914533a4a57651") where fm1.file_id ="d2dc02057dde11e99d728d7ed0998f00";
 
--UPDATE EQUIPMENT_MASTER
--- file_id will be value of UUID from above Query
update hydro.equipment_master set device_id="ba1bec706ea6471585d7c782743fc9b4" where equipment_id="e09fc46364b747b5aaa76fce58be3b4e";

update hydro.preference_master set unit_id="e436d4699b7f44e9a0c07600c3c7b9f9" where site_id="f2ecd9ea23e742b894d0cf3b73ef372b" and unit_id="ba1bec706ea6471585d7c782743fc9b4";

update hydro.observation_master set device_id = "e436d4699b7f44e9a0c07600c3c7b9f9" where site_id ="f2ecd9ea23e742b894d0cf3b73ef372b" and lm2_seq = "ba1bec706ea6471585d7c782743fc9b4";

--UPDATE status for site which support real time streaming

update hydro.site_master set streaming_enabled=true where site_id ="f2ecd9ea23e742b894d0cf3b73ef372b";