#Altering table to add new column unit id

ALTER TABLE `hydro`.`file_master` 
ADD COLUMN `unit_id` VARCHAR(255) NULL AFTER `is_active`;

ALTER TABLE `hydro`.`file_master_bckp` 
ADD COLUMN `unit_id` VARCHAR(255) NULL AFTER `is_active`;

DROP trigger `hydro`.TRIG_FILE_MASTER_UPDATE;

DROP trigger `hydro`.TRIG_FILE_MASTER_DELETE;

create trigger `hydro`.TRIG_FILE_MASTER_UPDATE
after update on `hydro`.FILE_MASTER
for each row
insert into `hydro`.FILE_MASTER_BCKP(file_id, name, created_by, created_date, status, site_id, description, detailed_description,version,modified_by,modified_date, file_type,device_id,is_active, unit_id)
values(NEW.file_id, NEW.name, NEW.created_by, NEW.created_date, NEW.status, NEW.site_id, NEW.description, NEW.detailed_description, NEW.version, NEW.modified_by,NEW.modified_date, NEW.file_type, NEW.device_id, NEW.is_active, NEW.unit_id);

create trigger `hydro`.TRIG_FILE_MASTER_DELETE
after delete on `hydro`.FILE_MASTER
for each row
insert into `hydro`.FILE_MASTER_BCKP(file_id, name, created_by, created_date, status, site_id, description, detailed_description, version,modified_by,modified_date, file_type,device_id,is_active, unit_id)
values(old.file_id, old.name, old.created_by, old.created_date, old.status, old.site_id, old.description, old.detailed_description, old.version, old.modified_by,old.modified_date, old.file_type, old.device_id, old.is_active, old.unit_id);

ALTER TABLE `hydro`.`formula_master` 
ADD COLUMN `percentage` INT(3) NULL AFTER `uid`,
ADD COLUMN `date_last_change` DATETIME NULL AFTER `percentage`,
ADD COLUMN `used_phases` INT(4) NULL AFTER `date_last_change`,
ADD COLUMN `statistic_production` INT(10) NULL AFTER `used_phases`,
ADD COLUMN `updated` INT(3) NULL AFTER `statistic_production`;

ALTER TABLE `hydro`.`formula_master_bckp` 
ADD COLUMN `percentage` INT(3) NULL AFTER `uid`,
ADD COLUMN `date_last_change` DATETIME NULL AFTER `percentage`,
ADD COLUMN `used_phases` INT(4) NULL AFTER `date_last_change`,
ADD COLUMN `statistic_production` INT(10) NULL AFTER `used_phases`,
ADD COLUMN `updated` INT(3) NULL AFTER `statistic_production`;

DROP trigger `hydro`.TRIG_FORMULA_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_FORMULA_MASTER_DELETE;

create trigger `hydro`.TRIG_FORMULA_MASTER_UPDATE
after update on `hydro`.FORMULA_MASTER
for each row
insert into `hydro`.FORMULA_MASTER_BCKP(formula_id, equipment_id, lm2_seq, name, `load`, phases, color, created_by, created_date, modified_by, modified_date, uid, percentage, date_last_change, used_phases, statistic_production, updated)
values(NEW.formula_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.load, NEW.phases, NEW.color, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid, NEW.percentage, NEW.date_last_change, NEW.used_phases, NEW.statistic_production, NEW.updated);

create trigger `hydro`.TRIG_FORMULA_MASTER_DELETE
after delete on `hydro`.FORMULA_MASTER
for each row
insert into `hydro`.FORMULA_MASTER_BCKP(formula_id, equipment_id, lm2_seq, name, `load`, phases, color, created_by, created_date, modified_by, modified_date, uid, percentage, date_last_change, used_phases, statistic_production, updated)
values(old.formula_id, old.equipment_id, old.lm2_seq, old.name, old.load, old.phases, old.color, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid, old.percentage, old.date_last_change, old.used_phases, old.statistic_production, old.updated);

CREATE TABLE IF NOT EXISTS `hydro`.`formula_phases` (
  `f_phase_id` VARCHAR(45) NOT NULL,
  `id` INT(11) NULL,
  `id_formula` INT(3) NULL,
  `num_phase` INT(2) NULL,
  `delay_1` INT(3) NULL,
  `delay_2` INT(3) NULL,
  `uid` VARCHAR(255) NULL,
  `equipment_id` VARCHAR(45) NULL,
  `formula_id` VARCHAR(45) NULL,
  PRIMARY KEY (`f_phase_id`),
  INDEX `formula_id_PhasesCons_idx` (`formula_id` ASC),
  INDEX `Equipment_id_phaseCons_idx` (`equipment_id` ASC),
  CONSTRAINT `formula_id_PhasesCons`
	  FOREIGN KEY (`formula_id`)
	  REFERENCES `hydro`.`formula_master` (`formula_id`)
	  ON DELETE NO ACTION
	  ON UPDATE NO ACTION,
  CONSTRAINT `Equipment_id_phaseCons`
	  FOREIGN KEY (`equipment_id`)
	  REFERENCES `hydro`.`equipment_master` (`equipment_id`)
	  ON DELETE NO ACTION
	  ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;
  
CREATE TABLE IF NOT EXISTS `hydro`.`formula_phases_bckp` (
  `f_phase_id` VARCHAR(45) NOT NULL,
  `id` INT(11) NULL,
  `id_formula` INT(3) NULL,
  `num_phase` INT(2) NULL,
  `delay_1` INT(3) NULL,
  `delay_2` INT(3) NULL,
  `uid` VARCHAR(255) NULL,
  `equipment_id` VARCHAR(45) NULL,
  `formula_id` VARCHAR(45) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;
  
create trigger `hydro`.TRIG_FORMULA_PHASES_UPDATE
after update on `hydro`.formula_phases
for each row
insert into `hydro`.formula_phases_bckp(f_phase_id, id, id_formula, num_phase, delay_1, delay_2, uid, equipment_id,formula_id)
values(NEW.f_phase_id, NEW.id, NEW.id_formula, NEW.num_phase, NEW.delay_1, NEW.delay_2, NEW.uid, NEW.equipment_id, NEW.formula_id);

create trigger `hydro`.TRIG_FORMULA_PHASES_DELETE
after delete on `hydro`.formula_phases
for each row
insert into `hydro`.formula_phases_bckp(f_phase_id, id, id_formula, num_phase, delay_1, delay_2, uid, equipment_id, formula_id)
values(old.f_phase_id, old.id, old.id_formula, old.num_phase, old.delay_1, old.delay_2, old.uid, old.equipment_id, old.formula_id);

CREATE TABLE IF NOT EXISTS `hydro`.`formula_dosages` (
  `f_dosage_id` VARCHAR(50) NOT NULL,
  `id` INT(11) NULL,
  `id_phase` INT(11) NULL,
  `dosage_order` INT(11) NULL,
  `id_product` INT(11) NULL,
  `dose` DECIMAL(5,2) NULL,
  `delay_bit` TINYINT(1) NULL,
  `uid` VARCHAR(255) NULL,
  `product_uid` VARCHAR(255) NULL,
  `f_phase_id` VARCHAR(255) NULL,
  PRIMARY KEY (`f_dosage_id`),
  INDEX `f_phase_idConst_idx` (`f_phase_id` ASC),
  CONSTRAINT `f_phase_idConst`
  FOREIGN KEY (`f_phase_id`)
  REFERENCES `hydro`.`formula_phases` (`f_phase_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`formula_dosages_bckp` (
  `f_dosage_id` VARCHAR(50) NOT NULL,
  `id` INT(11) NULL,
  `id_phase` INT(11) NULL,
  `dosage_order` INT(11) NULL,
  `id_product` INT(11) NULL,
  `dose` DECIMAL(5,2) NULL,
  `delay_bit` TINYINT(1) NULL,
  `uid` VARCHAR(255) NULL,
  `product_uid` VARCHAR(255) NULL,
  `f_phase_id` VARCHAR(255) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_FORMULA_DOSAGES_UPDATE
after update on `hydro`.formula_dosages
for each row
insert into `hydro`.formula_dosages_bckp(f_dosage_id, id, id_phase, dosage_order, id_product, dose, delay_bit, uid, product_uid,f_phase_id)
values(NEW.f_dosage_id, NEW.id, NEW.id_phase, NEW.dosage_order, NEW.id_product, NEW.dose, NEW.delay_bit, NEW.uid, NEW.product_uid, NEW.f_phase_id);

create trigger `hydro`.TRIG_FORMULA_DOSAGES_DELETE
after delete on `hydro`.formula_dosages
for each row
insert into `hydro`.formula_dosages_bckp(f_dosage_id, id, id_phase, dosage_order, id_product, dose, delay_bit, uid, product_uid, f_phase_id)
values(old.f_dosage_id, old.id, old.id_phase, old.dosage_order, old.id_product, old.dose, old.delay_bit, old.uid, old.product_uid, old.f_phase_id);

ALTER TABLE `hydro`.`equipment_master` 
ADD COLUMN `unit_id` VARCHAR(255) NULL AFTER `device_id`,
ADD COLUMN `warning_level` TINYINT(4) NULL AFTER `unit_id`,
ADD COLUMN `revision` INT(11) NULL AFTER `warning_level`,
ADD COLUMN `start_up_date` DATE NULL AFTER `revision`,
ADD COLUMN `date_power_on` DATETIME NULL AFTER `start_up_date`,
ADD COLUMN `language` VARCHAR(2) NULL AFTER `date_power_on`,
ADD COLUMN `units_system` INT(2) NULL AFTER `language`,
ADD COLUMN `products_channel_1` VARCHAR(2) NULL AFTER `units_system`,
ADD COLUMN `products_channel_2` VARCHAR(2) NULL AFTER `products_channel_1`,
ADD COLUMN `products_channel_3` VARCHAR(2) NULL AFTER `products_channel_2`,
ADD COLUMN `date_reset_statistics` DATETIME NULL AFTER `products_channel_3`,
ADD COLUMN `date_last_sync` DATETIME NULL AFTER `date_reset_statistics`,
ADD COLUMN `date_last_estadisticas_sync` DATETIME NULL AFTER `date_last_sync`,
ADD COLUMN `checksum` VARCHAR(255) NULL AFTER `date_last_estadisticas_sync`,
ADD COLUMN `first_conf_upload` TINYINT(4) NULL AFTER `checksum`,
ADD COLUMN `first_formulas_upload` TINYINT(4) NULL AFTER `first_conf_upload`,
ADD COLUMN `call_center` TINYINT(4) NULL AFTER `first_formulas_upload`,
ADD COLUMN `email` VARCHAR(255) NULL AFTER `call_center`,
ADD COLUMN `report_period` INT(4) NULL AFTER `email`,
ADD COLUMN `warning_cycles` TINYINT(4) NULL AFTER `report_period`,
ADD COLUMN `warning_water` TINYINT(4) NULL AFTER `warning_cycles`,
ADD COLUMN `warning_product` TINYINT(4) NULL AFTER `warning_water`;

ALTER TABLE `hydro`.`equipment_master_bckp` 
ADD COLUMN `unit_id` VARCHAR(255) NULL AFTER `device_id`,
ADD COLUMN `warning_level` TINYINT(4) NULL AFTER `unit_id`,
ADD COLUMN `revision` INT(11) NULL AFTER `warning_level`,
ADD COLUMN `start_up_date` DATE NULL AFTER `revision`,
ADD COLUMN `date_power_on` DATETIME NULL AFTER `start_up_date`,
ADD COLUMN `language` VARCHAR(2) NULL AFTER `date_power_on`,
ADD COLUMN `units_system` INT(2) NULL AFTER `language`,
ADD COLUMN `products_channel_1` VARCHAR(2) NULL AFTER `units_system`,
ADD COLUMN `products_channel_2` VARCHAR(2) NULL AFTER `products_channel_1`,
ADD COLUMN `products_channel_3` VARCHAR(2) NULL AFTER `products_channel_2`,
ADD COLUMN `date_reset_statistics` DATETIME NULL AFTER `products_channel_3`,
ADD COLUMN `date_last_sync` DATETIME NULL AFTER `date_reset_statistics`,
ADD COLUMN `date_last_estadisticas_sync` DATETIME NULL AFTER `date_last_sync`,
ADD COLUMN `checksum` VARCHAR(255) NULL AFTER `date_last_estadisticas_sync`,
ADD COLUMN `first_conf_upload` TINYINT(4) NULL AFTER `checksum`,
ADD COLUMN `first_formulas_upload` TINYINT(4) NULL AFTER `first_conf_upload`,
ADD COLUMN `call_center` TINYINT(4) NULL AFTER `first_formulas_upload`,
ADD COLUMN `email` VARCHAR(255) NULL AFTER `call_center`,
ADD COLUMN `report_period` INT(4) NULL AFTER `email`,
ADD COLUMN `warning_cycles` TINYINT(4) NULL AFTER `report_period`,
ADD COLUMN `warning_water` TINYINT(4) NULL AFTER `warning_cycles`,
ADD COLUMN `warning_product` TINYINT(4) NULL AFTER `warning_water`;

DROP trigger `hydro`.TRIG_EQUIPMENT_UPDATE;
DROP trigger `hydro`.TRIG_EQUIPMENT_DELETE;

create trigger `hydro`.TRIG_EQUIPMENT_UPDATE
after update on `hydro`.EQUIPMENT_MASTER
for each row
insert into `hydro`.EQUIPMENT_MASTER_BCKP(equipment_id, lm2_seq, site_id, alias, equipment_type, slave, ip_address, observations, washer_count, tunnel_count, w_machine_chnl_count, pump_count, channel_count, is_active, created_by, created_date, modified_by, modified_date, version, file_id, device_id, unit_id, warning_level, revision, start_up_date, date_power_on, language, units_system, products_channel_1, products_channel_2, products_channel_3, date_reset_statistics, date_last_sync, date_last_estadisticas_sync, checksum, first_conf_upload, first_formulas_upload, call_center, email, report_period, warning_cycles, warning_water, warning_product)
values(NEW.equipment_id, NEW.lm2_seq, NEW.site_id, NEW.alias, NEW.equipment_type, NEW.slave, NEW.ip_address, NEW.observations, NEW.washer_count, NEW.tunnel_count, NEW.w_machine_chnl_count, NEW.pump_count, NEW.channel_count, NEW.is_active, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.version, NEW.file_id, NEW.device_id, NEW.unit_id, NEW.warning_level, NEW.revision, NEW.start_up_date, NEW.date_power_on, NEW.language, NEW.units_system,  NEW.products_channel_1, NEW.products_channel_2, NEW.products_channel_3, NEW.date_reset_statistics, NEW.date_last_sync, NEW.date_last_estadisticas_sync, NEW.checksum, NEW.first_conf_upload, NEW.first_formulas_upload, NEW.call_center, NEW.email, NEW.report_period, NEW.warning_cycles, NEW.warning_water, NEW.warning_product);

create trigger `hydro`.TRIG_EQUIPMENT_DELETE
after delete on `hydro`.EQUIPMENT_MASTER
for each row
insert into `hydro`.EQUIPMENT_MASTER_BCKP(equipment_id, lm2_seq, site_id, alias, equipment_type, slave, ip_address, observations, washer_count, tunnel_count, w_machine_chnl_count, pump_count, channel_count, is_active, created_by, created_date, modified_by, modified_date, version, file_id, device_id, unit_id, warning_level, revision, start_up_date, date_power_on, language, units_system, products_channel_1, products_channel_2, products_channel_3, date_reset_statistics, date_last_sync, date_last_estadisticas_sync, checksum, first_conf_upload, first_formulas_upload, call_center, email, report_period, warning_cycles, warning_water, warning_product)
values(old.equipment_id, old.lm2_seq, old.site_id, old.alias, old.equipment_type, old.slave, old.ip_address, old.observations, old.washer_count, old.tunnel_count, old.w_machine_chnl_count, old.pump_count, old.channel_count, old.is_active, old.created_by, old.created_date, old.modified_by, old.modified_date, old.version, old.file_id, old.device_id, old.unit_id, old.warning_level, old.revision, old.start_up_date, old.date_power_on, old.language, old.units_system, old.products_channel_1, old.products_channel_2, old.products_channel_3, old.date_reset_statistics, old.date_last_sync, old.date_last_estadisticas_sync, old.checksum, old.first_conf_upload, old.first_formulas_upload, old.call_center, old.email, old.report_period, old.warning_cycles, old.warning_water, old.warning_product);

CREATE TABLE IF NOT EXISTS `hydro`.`channel_master` (
  `channel_id` VARCHAR(45) NOT NULL,
  `uid` VARCHAR(255) NULL,
  `alarms_skipped` INT(1) NULL,
  `alarms_tolerance` INT(2) NULL,
  `date_last_change` DATETIME NULL,
  `dosing_mode` INT(1) NULL,
  `flush_air_ml` INT(4) NULL,
  `flush_air_time` INT(3) NULL,
  `flush_type` INT(1) NULL,
  `name` VARCHAR(16) NULL,
  `pump_type` INT(1) NULL,
  `water_test` INT(4) NULL,
  `equipment_id` VARCHAR(100) NULL,
  PRIMARY KEY (`channel_id`),
  INDEX `equipment_master_const_idx` (`equipment_id` ASC),
  CONSTRAINT `equipment_master_const`
  FOREIGN KEY (`equipment_id`)
  REFERENCES `hydro`.`equipment_master` (`equipment_id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS `hydro`.`channel_master_bckp` (
  `channel_id` VARCHAR(45) NOT NULL,
  `uid` VARCHAR(255) NULL,
  `alarms_skipped` INT(1) NULL,
  `alarms_tolerance` INT(2) NULL,
  `date_last_change` DATETIME NULL,
  `dosing_mode` INT(1) NULL,
  `flush_air_ml` INT(4) NULL,
  `flush_air_time` INT(3) NULL,
  `flush_type` INT(1) NULL,
  `name` VARCHAR(16) NULL,
  `pump_type` INT(1) NULL,
  `water_test` INT(4) NULL,
  `equipment_id` VARCHAR(100) NULL,
  `log` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP)
ENGINE = InnoDB, CHARACTER SET = utf8, COLLATE = utf8_unicode_ci;

create trigger `hydro`.TRIG_CHANNEL_MASTER_UPDATE
after update on `hydro`.channel_master
for each row
insert into `hydro`.channel_master_bckp(channel_id, uid, alarms_skipped, alarms_tolerance, date_last_change, dosing_mode, flush_air_ml, flush_air_time, flush_type, name, pump_type, water_test, equipment_id)
values(NEW.channel_id, NEW.uid, NEW.alarms_skipped, NEW.alarms_tolerance, NEW.date_last_change, NEW.dosing_mode, NEW.flush_air_ml, NEW.flush_air_time, NEW.flush_type, NEW.name, NEW.pump_type, NEW.water_test, NEW.equipment_id);

create trigger `hydro`.TRIG_CHANNEL_MASTER_DELETE
after delete on `hydro`.channel_master
for each row
insert into `hydro`.channel_master_bckp(channel_id, uid, alarms_skipped, alarms_tolerance, date_last_change, dosing_mode, flush_air_ml, flush_air_time, flush_type, name, pump_type, water_test, equipment_id)
values(old.channel_id, old.uid, old.alarms_skipped, old.alarms_tolerance, old.date_last_change, old.dosing_mode, old.flush_air_ml, old.flush_air_time, old.flush_type, old.name, old.pump_type, old.water_test, old.equipment_id);

ALTER TABLE `hydro`.`water_master` 
ADD COLUMN `channel` INT(2) NULL AFTER `uid`,
ADD COLUMN `date_calibration` DATE NULL AFTER `channel`,
ADD COLUMN `date_last_change` DATETIME NULL AFTER `date_calibration`;

ALTER TABLE `hydro`.`water_master_bckp` 
ADD COLUMN `channel` INT(2) NULL AFTER `uid`,
ADD COLUMN `date_calibration` DATE NULL AFTER `channel`,
ADD COLUMN `date_last_change` DATETIME NULL AFTER `date_calibration`;

DROP trigger `hydro`.TRIG_WATER_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_WATER_MASTER_DELETE;

create trigger `hydro`.TRIG_WATER_MASTER_UPDATE
after update on `hydro`.WATER_MASTER
for each row
insert into `hydro`.WATER_MASTER_BCKP(water_id, equipment_id, name, kf, lm2_seq, flow, water_time, cellphone_minute, docification_mode, seperation_ml, ignored_alarms, percentage, diameter, pump_type, created_by, created_date, modified_by, modified_date, uid, channel, date_calibration, date_last_change)
values(NEW.water_id, NEW.equipment_id, NEW.name, NEW.kf, NEW.lm2_seq, NEW.flow, NEW.water_time, NEW.cellphone_minute, NEW.docification_mode, NEW.seperation_ml, NEW.ignored_alarms, NEW.percentage, NEW.diameter, NEW.pump_type, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid, NEW.channel, NEW.date_calibration, NEW.date_last_change);

create trigger `hydro`.TRIG_WATER_MASTER_DELETE
after delete on `hydro`.WATER_MASTER
for each row
insert into `hydro`.WATER_MASTER_BCKP(water_id, equipment_id, name, kf, lm2_seq, flow, water_time, cellphone_minute, docification_mode, seperation_ml, ignored_alarms, percentage, diameter, pump_type, created_by, created_date, modified_by, modified_date, uid, channel, date_calibration, date_last_change)
values(old.water_id, old.equipment_id, old.name, old.kf, old.lm2_seq, old.flow, old.water_time, old.cellphone_minute, old.docification_mode, old.seperation_ml, old.ignored_alarms, old.percentage, old.diameter, old.pump_type, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid, old.channel, old.date_calibration, old.date_last_change);

ALTER TABLE `hydro`.`product_master` 
ADD COLUMN `alarms_tolerance` INT(2) NULL AFTER `uid`,
ADD COLUMN `date_last_change` DATETIME NULL AFTER `alarms_tolerance`,
ADD COLUMN `dosing_mode` INT(1) NULL AFTER `date_last_change`,
ADD COLUMN `estate` INT(1) NULL AFTER `dosing_mode`,
ADD COLUMN `pump_safe_stop` INT(1) NULL AFTER `estate`,
ADD COLUMN `rotameter_sensor` INT(1) NULL AFTER `pump_safe_stop`,
ADD COLUMN `statistic_production` INT(10) NULL AFTER `rotameter_sensor`,
ADD COLUMN `statistic_warnings` INT(10) NULL AFTER `statistic_production`;

ALTER TABLE `hydro`.`product_master_bckp` 
ADD COLUMN `alarms_tolerance` INT(2) NULL AFTER `uid`,
ADD COLUMN `date_last_change` DATETIME NULL AFTER `alarms_tolerance`,
ADD COLUMN `dosing_mode` INT(1) NULL AFTER `date_last_change`,
ADD COLUMN `estate` INT(1) NULL AFTER `dosing_mode`,
ADD COLUMN `pump_safe_stop` INT(1) NULL AFTER `estate`,
ADD COLUMN `rotameter_sensor` INT(1) NULL AFTER `pump_safe_stop`,
ADD COLUMN `statistic_production` INT(10) NULL AFTER `rotameter_sensor`,
ADD COLUMN `statistic_warnings` INT(10) NULL AFTER `statistic_production`;

DROP trigger `hydro`.TRIG_PRODUCT_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_PRODUCT_MASTER_DELETE;

create trigger `hydro`.TRIG_PRODUCT_MASTER_UPDATE
after update on `hydro`.PRODUCT_MASTER
for each row
insert into `hydro`.PRODUCT_MASTER_BCKP(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow, frequency, docification_mode, priority, contact, alarms_ignored, percentage, drag_type, pump_speed, format, price, calibration, color1, color2, created_by, created_date, modified_by, modified_date, uid, alarms_tolerance, date_last_change, dosing_mode, estate, pump_safe_stop, rotameter_sensor, statistic_production, statistic_warnings)
values(NEW.product_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.density, NEW.concentration, NEW.kf, NEW.flow, NEW.frequency, NEW.docification_mode, NEW.priority, NEW.contact, NEW.alarms_ignored, NEW.percentage, NEW.drag_type, NEW.pump_speed, NEW.format, NEW.price, NEW.calibration, NEW.color1, NEW.color2, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid, NEW.alarms_tolerance, NEW.date_last_change, NEW.dosing_mode, NEW.estate, NEW.pump_safe_stop, NEW.rotameter_sensor, NEW.statistic_production, NEW.statistic_warnings);

create trigger `hydro`.TRIG_PRODUCT_MASTER_DELETE
after delete on `hydro`.PRODUCT_MASTER
for each row
insert into `hydro`.PRODUCT_MASTER_BCKP(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow, frequency, docification_mode, priority, contact, alarms_ignored, percentage, drag_type, pump_speed, format, price, calibration, color1, color2, created_by, created_date, modified_by, modified_date, uid, alarms_tolerance, date_last_change, dosing_mode, estate, pump_safe_stop, rotameter_sensor, statistic_production, statistic_warnings)
values(old.product_id, old.equipment_id, old.lm2_seq, old.name, old.density, old.concentration, old.kf, old.flow, old.frequency, old.docification_mode, old.priority, old.contact, old.alarms_ignored, old.percentage, old.drag_type, old.pump_speed, old.format, old.price, old.calibration, old.color1, old.color2, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid, old.alarms_tolerance, old.date_last_change, old.dosing_mode, old.estate, old.pump_safe_stop, old.rotameter_sensor, old.statistic_production, old.statistic_warnings);

ALTER TABLE `hydro`.`washer_master` 
ADD COLUMN `date_last_change` DATETIME NULL AFTER `uid`,
ADD COLUMN `end_formula` INT(3) NULL AFTER `date_last_change`,
ADD COLUMN `end_mode` INT(1) NULL AFTER `end_formula`,
ADD COLUMN `end_signal_pump` INT(2) NULL AFTER `end_mode`,
ADD COLUMN `flush_l` DECIMAL(4,2) NULL AFTER `end_signal_pump`,
ADD COLUMN `hold_delay` INT(3) NULL AFTER `flush_l`,
ADD COLUMN `hold_mode` INT(1) NULL AFTER `hold_delay`,
ADD COLUMN `hold_timeout` INT(3) NULL AFTER `hold_mode`,
ADD COLUMN `kg_sel` INT(1) NULL AFTER `hold_timeout`,
ADD COLUMN `trigger_mode` INT(1) NULL AFTER `kg_sel`;

ALTER TABLE `hydro`.`washer_master_bckp` 
ADD COLUMN `date_last_change`DATETIME NULL AFTER `uid`,
ADD COLUMN `end_formula` INT(3) NULL AFTER `date_last_change`,
ADD COLUMN `end_mode` INT(1) NULL AFTER `end_formula`,
ADD COLUMN `end_signal_pump` INT(2) NULL AFTER `end_mode`,
ADD COLUMN `flush_l` DECIMAL(4,2) NULL AFTER `end_signal_pump`,
ADD COLUMN `hold_delay` INT(3) NULL AFTER `flush_l`,
ADD COLUMN `hold_mode` INT(1) NULL AFTER `hold_delay`,
ADD COLUMN `hold_timeout` INT(3) NULL AFTER `hold_mode`,
ADD COLUMN `kg_sel` INT(1) NULL AFTER `hold_timeout`,
ADD COLUMN `trigger_mode` INT(1) NULL AFTER `kg_sel`;

DROP trigger `hydro`.TRIG_WASHER_MASTER_UPDATE;
DROP trigger `hydro`.TRIG_WASHER_MASTER_DELETE;

create trigger `hydro`.TRIG_WASHER_MASTER_UPDATE
after update on `hydro`.WASHER_MASTER
for each row
insert into `hydro`.WASHER_MASTER_BCKP(washer_id, equipment_id, lm2_seq, name, `load`, modifiable_load, ltr_drag, cellular_minutes, id_formula, work_mode, reset_mode, reset_signal, reset_formula, unused_machine, unused_time_delay, unused_timeout, t_acceptation, t_repetition, t_lock, type_programmer, signal_count, signal_voltage, signal_connection, observation, created_by, created_date, modified_by, modified_date, uid, date_last_change, end_formula, end_mode, end_signal_pump, flush_l, hold_delay, hold_mode, hold_timeout, kg_sel, trigger_mode)
values(NEW.washer_id, NEW.equipment_id, NEW.lm2_seq, NEW.name, NEW.load, NEW.modifiable_load, NEW.ltr_drag, NEW.cellular_minutes, NEW.id_formula, NEW.work_mode, NEW.reset_mode, NEW.reset_signal, NEW.reset_formula, NEW.unused_machine, NEW.unused_time_delay, NEW.unused_timeout, NEW.t_acceptation, NEW.t_repetition, NEW.t_lock, NEW.type_programmer, NEW.signal_count, NEW.signal_voltage, NEW.signal_connection, NEW.observation, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date, NEW.uid, NEW.date_last_change, NEW.end_formula, NEW.end_mode, NEW.end_signal_pump, NEW.flush_l, NEW.hold_delay, NEW.hold_mode, NEW.hold_timeout, NEW.kg_sel, NEW.trigger_mode);

create trigger `hydro`.TRIG_WASHER_MASTER_DELETE
after delete on `hydro`.WASHER_MASTER
for each row
insert into `hydro`.WASHER_MASTER_BCKP(washer_id, equipment_id, lm2_seq, name, `load`, modifiable_load, ltr_drag, cellular_minutes, id_formula, work_mode, reset_mode, reset_signal, reset_formula, unused_machine, unused_time_delay, unused_timeout, t_acceptation, t_repetition, t_lock, type_programmer, signal_count, signal_voltage, signal_connection, observation, created_by, created_date, modified_by, modified_date, uid, date_last_change, end_formula, end_mode, end_signal_pump, flush_l, hold_delay, hold_mode, hold_timeout, kg_sel, trigger_mode)
values(old.washer_id, old.equipment_id, old.lm2_seq, old.name, old.load, old.modifiable_load, old.ltr_drag, old.cellular_minutes, old.id_formula, old.work_mode, old.reset_mode, old.reset_signal, old.reset_formula, old.unused_machine, old.unused_time_delay, old.unused_timeout, old.t_acceptation, old.t_repetition, old.t_lock, old.type_programmer, old.signal_count, old.signal_voltage, old.signal_connection, old.observation, old.created_by, old.created_date, old.modified_by, old.modified_date, old.uid, old.date_last_change, old.end_formula, old.end_mode, old.end_signal_pump, old.flush_l, old.hold_delay, old.hold_mode, old.hold_timeout, old.kg_sel, old.trigger_mode);
