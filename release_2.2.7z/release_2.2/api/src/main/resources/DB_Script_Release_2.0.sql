## INSERT NEW ROLES
INSERT INTO `hydro`.`role_master` (`role_id`, `user_role`, `clearance_level`, `org_type`) VALUES ('9', 'HYDRO TECHNICIAN', '2', 'HYDRO');
INSERT INTO `hydro`.`role_master` (`role_id`, `user_role`, `clearance_level`, `org_type`) VALUES ('10', 'HYDRO USER', '3', 'HYDRO');

## UPDATE  Clearance Level 
UPDATE `hydro`.`role_master` SET `clearance_level` = '4' WHERE (`role_id` = '2');
UPDATE `hydro`.`role_master` SET `clearance_level` = '5' WHERE (`role_id` = '3');
UPDATE `hydro`.`role_master` SET `clearance_level` = '6' WHERE (`role_id` = '4');
UPDATE `hydro`.`role_master` SET `clearance_level` = '7' WHERE (`role_id` = '5');
UPDATE `hydro`.`role_master` SET `clearance_level` = '8' WHERE (`role_id` = '6');
UPDATE `hydro`.`role_master` SET `clearance_level` = '9' WHERE (`role_id` = '7');
UPDATE `hydro`.`role_master` SET `clearance_level` = '10' WHERE (`role_id` = '8');

##Update privilege_names

UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'SITE_LIST' WHERE (`privilege_id` = '1');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'ACCOUNT_VIEW' WHERE (`privilege_id` = '10');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'COMPANY_LIST' WHERE (`privilege_id` = '11');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'COMPANY_VIEW' WHERE (`privilege_id` = '12');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'COMPANY_DELETE' WHERE (`privilege_id` = '13');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'COMPANY_CREATE' WHERE (`privilege_id` = '14');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'COMPANY_UPDATE' WHERE (`privilege_id` = '15');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'USER_LIST' WHERE (`privilege_id` = '16');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'USER_VIEW' WHERE (`privilege_id` = '17');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'USER_DELETE' WHERE (`privilege_id` = '18');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'USER_CREATE' WHERE (`privilege_id` = '19');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'SITE_VIEW' WHERE (`privilege_id` = '2');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'USER_UPDATE' WHERE (`privilege_id` = '20');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'FILE_UPLOAD' WHERE (`privilege_id` = '25');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'FILE_HISTORY' WHERE (`privilege_id` = '26');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'GENERATE_REPORT' WHERE (`privilege_id` = '27');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'SITE_UPDATE' WHERE (`privilege_id` = '3');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'SITE_CREATE' WHERE (`privilege_id` = '4');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'FULL_PRIVILEGE' WHERE (`privilege_id` = '40');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'CREATE_SAME_LEVEL_USER' WHERE (`privilege_id` = '41');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'ACCOUNT_CREATE' WHERE (`privilege_id` = '9');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'ACCOUNT_UPDATE' WHERE (`privilege_id` = '8');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'ACCOUNT_LIST' WHERE (`privilege_id` = '7');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'ACCOUNT_DELETE' WHERE (`privilege_id` = '6');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'SITE_DELETE' WHERE (`privilege_id` = '5');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'ALERT_SETTING' WHERE (`privilege_id` = '45');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'ALARM_SUMMARY_REPORT' WHERE (`privilege_id` = '39');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'CHEMICAL_SUMMARY_ACTUAL_USAGE' WHERE (`privilege_id` = '31');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'CHEMICAL_SUMMARY_EST_USAGE' WHERE (`privilege_id` = '32');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'CHEMICAL_SUMMARY_REPORT' WHERE (`privilege_id` = '37');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'COST_SUMMARY_ABS_COST' WHERE (`privilege_id` = '33');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'COST_SUMMARY_COST_PER_CWT' WHERE (`privilege_id` = '34');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'COST_SUMMARY_ERROR' WHERE (`privilege_id` = '35');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'COST_SUMMARY_EST_COST' WHERE (`privilege_id` = '28');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'COST_SUMMARY_REPORT' WHERE (`privilege_id` = '38');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'OBSERVATION_RECOMMENDATION_CREATE' WHERE (`privilege_id` = '24');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'OBSERVATION_RECOMMENDATION_DELETE' WHERE (`privilege_id` = '23');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'OBS_REC_REPORT' WHERE (`privilege_id` = '43');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'OBSERVATION_RECOMMENDATION_UPDATE' WHERE (`privilege_id` = '22');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'OBSERVATION_RECOMMENDATION_VIEW' WHERE (`privilege_id` = '21');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'PRODUCTION_SUMMARY_LBS_WASHED' WHERE (`privilege_id` = '29');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'PRODUCTION_SUMMARY_LOADS_WASHED' WHERE (`privilege_id` = '30');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'REAL_TIME_REPORT' WHERE (`privilege_id` = '44');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'SITE_FULL_EDIT' WHERE (`privilege_id` = '42');
UPDATE `hydro`.`privilege_master` SET `privilege_name` = 'WASHER_PRODUCTION_SUMMARY_REPORT' WHERE (`privilege_id` = '36');


## ADD Privilege
INSERT INTO `hydro`.`privilege_master` (`privilege_id`, `privilege_name`) VALUES 
('46', 'DEVICE_MANAGEMENT_CREATE'),
('47', 'DEVICE_MANAGEMENT_DELETE'),
('48', 'DEVICE_MANAGEMENT_LIST'),
('49', 'DEVICE_MANAGEMENT_UPDATE'),
('50', 'DEVICE_MANAGEMENT_VIEW');


INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES 
('11', '9'),('7', '9'),('1', '9'),('16', '9'),
('39', '9'),('36', '9'),('29', '9'),('30', '9'),
('37', '9'),('31', '9'),('32', '9'),('33', '9'),('34', '9'),
('38', '9'),('35', '9'),('43', '9'),('21', '9'),
('10', '9'),('12', '9'),('17', '9'),('2', '9'),('40', '9'),('27','9'),('44','9');


INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES 
('11', '10'),('7', '10'),('1', '10'),('16', '10'),
('39', '10'),('36', '10'),('29', '10'),('30', '10'),
('37', '10'),('31', '10'),('32', '9'),('33', '10'),('34', '10'),
('38', '10'),('35', '10'),('43', '10'),('21', '10'),
('10', '10'),('12', '10'),('17', '10'),('2', '10'), ('27','10'),('44','10');


INSERT INTO `hydro`.`role_privilege_association` (`privilege_id`, `role_id`) VALUES 
('46', '1'),
('47', '1'),
('48', '1'),
('49', '1'),
('50', '1');

