

delete from hydro.role_privilege_association where role_id =7 and privilege_id =39

delete from hydro.role_privilege_association where role_id =8 and privilege_id =39