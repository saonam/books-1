ALTER TABLE `hydro`.`preference_master` 
CHANGE COLUMN `threshold_refresh_interval` `threshold_refresh_interval` VARCHAR(100) NULL DEFAULT NULL ;

ALTER TABLE `hydro`.`preference_master_bckp` 
CHANGE COLUMN `threshold_refresh_interval` `threshold_refresh_interval` VARCHAR(100) NULL DEFAULT NULL ;

ALTER TABLE `hydro`.`alarm_master` 
DROP COLUMN `threshold_refresh_interval`,
DROP COLUMN `threshold`;

ALTER TABLE `hydro`.`alarm_master_bckp` 
DROP COLUMN `threshold_refresh_interval`,
DROP COLUMN `threshold`;

DROP TRIGGER hydro.TRIG_ALARM_MASTER_UPDATE;
DROP TRIGGER hydro.TRIG_ALARM_MASTER_DELETE;

create trigger `hydro`.`TRIG_ALARM_MASTER_UPDATE`
after update on `hydro`.`ALARM_MASTER`
for each row 
insert into `hydro`.`ALARM_MASTER_BCKP`(alarm_id, alarm_name, description,created_by, created_date, modified_by, modified_date)
values (NEW.alarm_id, NEW.alarm_name, NEW.description, NEW.created_by, NEW.created_date, NEW.modified_by, NEW.modified_date);

CREATE trigger `hydro`.`TRIG_ALARM_MASTER_DELETE`
after delete on `hydro`.`ALARM_MASTER`
for each row
insert into `hydro`.`ALARM_MASTER_BCKP`(alarm_id, alarm_name, description,created_by, created_date, modified_by, modified_date)
values (old.alarm_id, old.alarm_name, old.description,old.created_by, old.created_date, old.modified_by, old.modified_date);

ALTER TABLE `hydro`.`preference_master` 
DROP COLUMN `threshold_refresh_interval`;

ALTER TABLE `hydro`.`preference_master` 
ADD COLUMN `threshold_refresh_interval` VARCHAR(100) NULL AFTER `threshold`;

ALTER TABLE `hydro`.`preference_master_bckp` 
DROP COLUMN `threshold_refresh_interval`;

ALTER TABLE `hydro`.`preference_master_bckp` 
ADD COLUMN `threshold_refresh_interval` VARCHAR(100) NULL AFTER `threshold`;

