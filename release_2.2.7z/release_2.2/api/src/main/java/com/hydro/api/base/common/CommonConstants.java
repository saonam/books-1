package com.hydro.api.base.common;

public class CommonConstants {
	
	public  static String STACK_TRACE ="Stack Trace : {}";
	public  static String ERROR ="Error : {}";
	public  static String QUERY ="query>>>> {}";
	public  static String TOTAL_TIME_TAKEN ="Total time taken>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> {}";
	public  static String RESPONSE_STRING ="Response String >>> {}";
	public  static String CONFIG = "config";

}
