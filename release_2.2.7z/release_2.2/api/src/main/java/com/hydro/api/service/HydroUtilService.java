package com.hydro.api.service;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.config.Config;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.event.business.HydroEventBL;
import com.hydro.api.exception.ExceptionHandler;
import com.hydro.api.exception.SystemException;
import com.hydro.api.service.helper.ServiceHelper;

/**
 * Base Service : Entry Point to the JSON APIs.
 * 
 * @author Khader
 *
 */
// No Base context root for the Services. Each services have their respective
// Endpoints.
@Path("/util")
@Produces({ MediaType.APPLICATION_JSON })
public class HydroUtilService extends HydroBaseService {

    private static final Logger LOG = LoggerFactory.getLogger(HydroUtilService.class);

    public HydroUtilService() throws Exception {
	super();
	BL = new HydroEventBL();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/test")
    public String test() {
	long start = System.currentTimeMillis();
	resStr = "{\"message\":\"Util APIs Works Fine!\"}";
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/configure")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String configure(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {

	    Config config = (Config) ServiceHelper.buildJsonString(body, Config.class);

	    ((HydroEventBL) BL).processJsonConfigPayload(config);

	    responseDTO.setResponseObject("Configuration processsing done");
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    /*
     * @POST
     * 
     * @Path("/notifyalarm")
     * 
     * @Consumes(MediaType.APPLICATION_JSON)
     * 
     * @Produces(MediaType.APPLICATION_JSON) public String notifyAlarm(String
     * body) { long start = System.currentTimeMillis(); boolean isProcessed =
     * false; try { EventDTO eventDTO = (EventDTO)
     * ServiceHelper.buildJsonString(body, EventDTO.class); isProcessed =
     * ((HydroEventBL) BL).processEvent(eventDTO);
     * responseDTO.setResponseObject(isProcessed);
     * responseDTO.setResponseStatus(true); resStr =
     * ServiceHelper.buildJsonString(responseDTO);
     * 
     * } catch (SystemException e) { LOG.error(e.getMessage()); resStr =
     * ServiceHelper.buildJsonString(ExceptionHandler.
     * getServiceResponseErrorMessage(e, errorMessages)); e.printStackTrace(); }
     * catch (Exception e) { LOG.error("Stack Trace : " +
     * ExceptionUtils.getFullStackTrace(e)); SystemException ex = new
     * SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
     * ErrorCodes.StatusCodes.FAILURE, null); resStr =
     * ServiceHelper.buildJsonString(ExceptionHandler.
     * getServiceResponseErrorMessage(ex, errorMessages)); } recordTime(start,
     * resStr); return resStr; }
     * 
     * 
     * 
     * @GET
     * 
     * @Path("deviceid/{serialid}")
     * 
     * @Consumes(MediaType.APPLICATION_JSON)
     * 
     * @Produces(MediaType.APPLICATION_JSON) public String
     * getDeviceid(@PathParam("serialid") String serialNumber) throws Exception
     * { long start = System.currentTimeMillis(); try { ConfigReader
     * configReader = ConfigReader.getObject(); String deviceId =
     * configReader.getDeviseIdUsingSerialNo(serialNumber); if
     * (StringUtils.isEmpty(deviceId)) {
     * responseDTO.setResponseObject(Constants.DEVICE_ID_NOT_PRESENT);
     * 
     * } else { responseDTO.setResponseObject(deviceId); }
     * responseDTO.setResponseObject(deviceId);
     * responseDTO.setResponseStatus(true); resStr =
     * ServiceHelper.buildJsonString(responseDTO);
     * 
     * } catch (SystemException e) { LOG.error(e.getMessage()); resStr =
     * ServiceHelper.buildJsonString(ExceptionHandler.
     * getServiceResponseErrorMessage(e, errorMessages)); e.printStackTrace(); }
     * catch (Exception e) { LOG.error("Stack Trace : " +
     * ExceptionUtils.getFullStackTrace(e)); SystemException ex = new
     * SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
     * ErrorCodes.StatusCodes.FAILURE, null); resStr =
     * ServiceHelper.buildJsonString(ExceptionHandler.
     * getServiceResponseErrorMessage(ex, errorMessages)); } recordTime(start,
     * resStr); return resStr; }
     * 
     * @GET
     * 
     * @Path("siteid/{serialid}")
     * 
     * @Consumes(MediaType.APPLICATION_JSON)
     * 
     * @Produces(MediaType.APPLICATION_JSON) public String
     * getSiteid(@PathParam("serialid") String serialNumber) throws Exception {
     * long start = System.currentTimeMillis(); try {
     * 
     * ConfigReader configReader = ConfigReader.getObject(); String siteId =
     * configReader.getSiteIdUsingSerialNo(serialNumber); if
     * (StringUtils.isEmpty(siteId)) {
     * responseDTO.setResponseObject(Constants.SITE_ID_NOT_PRESENT);
     * 
     * } else { responseDTO.setResponseObject(siteId); }
     * responseDTO.setResponseStatus(true); resStr =
     * ServiceHelper.buildJsonString(responseDTO);
     * 
     * } catch (SystemException e) { LOG.error(e.getMessage()); resStr =
     * ServiceHelper.buildJsonString(ExceptionHandler.
     * getServiceResponseErrorMessage(e, errorMessages)); e.printStackTrace(); }
     * catch (Exception e) { LOG.error("Stack Trace : " +
     * ExceptionUtils.getFullStackTrace(e)); SystemException ex = new
     * SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
     * ErrorCodes.StatusCodes.FAILURE, null); resStr =
     * ServiceHelper.buildJsonString(ExceptionHandler.
     * getServiceResponseErrorMessage(ex, errorMessages)); } recordTime(start,
     * resStr); return resStr; }
     */

    @POST
    @Path("/deviceEvent")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String saveEvent(String body) {
	long start = System.currentTimeMillis();
	try {
	    ((HydroEventBL) BL).saveEvent(body);

	    responseDTO.setResponseStatus(ErrorCodes.StatusCodes.SUCCESS);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }
}
