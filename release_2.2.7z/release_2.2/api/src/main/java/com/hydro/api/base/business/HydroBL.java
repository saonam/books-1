package com.hydro.api.base.business;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.base.dao.HydroDao;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.MetaDataDTO;
import com.hydro.api.dto.UserCreationRolesDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.user.dao.UserDao;

/**
 * Business layer for the Application.
 * 
 * @author Shreyas
 *
 */
public class HydroBL {
    private static final Logger LOG = LoggerFactory.getLogger(HydroBL.class);
    protected UserDTO user;
    protected Set<String> permissionList;
    protected List<UserCreationRolesDTO> userCreationList;
    // Data access object.
    protected HydroDao hydroDao;
    private boolean internalServerError = false;
    private boolean userDoesNotExistInDB = true;

    public HydroBL(String userId, String timeZone) {
	// Init of the DAO object.
	if (StringUtils.isEmpty(userId)) {
	    return;
	}
	user = new UserDTO();
	user.setUserId(userId);
	user.setTimeZone(timeZone);

	hydroDao = new HydroDao();
	try {
	    user = hydroDao.getUserDetails(user);
	    ConfigReader config = ConfigReader.getObject();
	    if (user != null) {
		user.setClearanceLevel(config.getRoleClearanceLevel(user.getOrgType(), user.getUserRole()));
		permissionList = config.getSpecificRolePermission(user.getOrgType(), user.getUserRole());
		user.setPermissions(CommonUtils.getPrivilegesName(permissionList));
		userCreationList = getCreationRoles();
	    } else {
		userDoesNotExistInDB = false;
	    }
	} catch (Exception e) {
	    internalServerError = true;
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error fetching User Data" + e.getMessage());
	    user = null;
	    return;
	}
    }

    protected boolean hasPermission(String permission, UserDTO userDTO) {
	try {
	    ConfigReader configReader = ConfigReader.getObject();
	    return configReader.hasPermission(userDTO.getOrgType(), userDTO.getUserRole(), permission);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return false;
    }

    protected boolean hasPermission(String permission) {
	return hasPermission(permission, user);
    }

    protected boolean hasCompanyVisibility(String companyId, UserDTO userDto) {
	if (!userDto.getOrgType().equals(Constants.HYDRO)) {
	    if (StringUtils.isEmpty(companyId) || !companyId.equalsIgnoreCase(userDto.getAssociationId())) {
		return false;
	    }
	}
	return true;
    }

    protected boolean hasCompanyVisibility(String companyId) {
	return hasCompanyVisibility(companyId, user);
    }

    protected boolean companyExists(String companyId, UserDTO userDto) {
	boolean hasVisibility = hasCompanyVisibility(companyId, userDto);
	if (!hasVisibility) {
	    return false;
	}
	if (!userDto.getOrgType().equals(Constants.HYDRO)) {
	    try {
		if (StringUtils.isEmpty(((UserDao) hydroDao).companyIdExists(companyId))) {
		    return false;
		}
	    } catch (Exception e) {
		return false;
	    }
	}
	return true;
    }

    protected boolean companyExists(String companyId) {
	return companyExists(companyId, user);
    }

    public HydroBL() throws SystemException, Exception {
	// Init of the DAO object.

    }

    public boolean testDbConnection() {
	return hydroDao.testDbConnection();
    }

    public void initRoutine() throws Exception {
	if (!userDoesNotExistInDB) {
	    throw new SystemException(ErrorCodes.USER_DOES_NOT_EXIST, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.UN_AUTHORIZED, null);
	}
	if (internalServerError) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
	if (user == null) {
	    throw new SystemException(ErrorCodes.INVALID_TOKEN, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.UN_AUTHORIZED, null);
	}
    }

    /**
     * 
     * @param accessToken
     * @return
     * @throws SystemException
     * @throws Exception
     */
    protected List<UserCreationRolesDTO> getCreationRoles() throws SystemException, Exception {
	try {
	    String userType = user.getOrgType();
	    String userRole = user.getUserRole();
	    List<UserCreationRolesDTO> userCreationList = new LinkedList<>();
	    ConfigReader config = ConfigReader.getObject();
	    // Throwing Invalid user access token in case the access token does
	    // not have user type and role.

	    if (StringUtils.isEmpty(userRole) || StringUtils.isEmpty(userType)
		    || !config.checkUserRoleAndType(userType, userRole)) {
		throw new SystemException(ErrorCodes.INVALID_USER_ROLE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.UN_AUTHORIZED, null);
	    }
	    if (Constants.DEFAULT.equalsIgnoreCase(userType)) {
		// No user creation permission for Default user.
	    } else {
		boolean createSameLevelPermission = hasPermission(Constants.PRIVILEGE_NAMES.CREATE_SAME_LEVEL_USER);
		userCreationList = config.getUserCreationRoleList(user.getClearanceLevel(), createSameLevelPermission);
	    }
	    return userCreationList;
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error getting info from Access token. Msg : " + e.getLocalizedMessage());
	    e.printStackTrace();
	    throw new SystemException(ErrorCodes.INVALID_TOKEN, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.UN_AUTHORIZED, null);

	}
    }

    public MetaDataDTO getMetaData() throws Exception {
	ConfigReader config = ConfigReader.getObject();
	MetaDataDTO metaData = new MetaDataDTO();
	metaData.setUser(user);
	metaData.setUserCreationRoles(userCreationList);
	metaData.setCompanyName(config.getAppConfig(Constants.AZURE_AD_COMPANY_NAME));
	metaData.setFileStatus(Constants.FileStatus.fileStatusConstants);
	metaData.setMetricList(CommonUtils.getMetricList());
	metaData.setPhaseStatus(ReportUtils.PHASE_STATUS.phaseStatusConstants);
	metaData.setThresholdReset(Constants.ThresholdResetConstants.resetValueList);
	return metaData;

    }

    protected void permissionDeniedCheck(String key) throws Exception {
	if (!permissionList.contains(key)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
    }
}
