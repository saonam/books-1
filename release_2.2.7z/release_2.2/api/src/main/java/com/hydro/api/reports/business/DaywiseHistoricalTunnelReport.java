package com.hydro.api.reports.business;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.DailyReportUtils;
import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.base.dao.ElasticSearchDAO;
import com.hydro.api.constants.Constants;
import com.hydro.api.dto.BatchDTO;
import com.hydro.api.dto.DailyReportEquipmentDTO;
import com.hydro.api.dto.DailyReportTunnelDTO;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.EventDTO;
import com.hydro.api.dto.ShiftDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.reports.DailyReportRequestDTO;
import com.hydro.api.dto.reports.DataRequestDTO;
import com.hydro.api.dto.reports.DaywiseReportRequestDTO;
import com.hydro.api.dto.reports.EventsDTO;
import com.hydro.api.dto.reports.ModuleDTO;
import com.hydro.api.dto.reports.TransferDTO;
import com.hydro.api.exception.SystemException;

public class DaywiseHistoricalTunnelReport implements DataRequestProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(DaywiseHistoricalTunnelReport.class);

    private static final Integer LAST_TRANSFER_KEY = new Integer(0);

//    private final ConfigReader config;
//    private SiteDao hydroDao;

    private DailyReportUtils dailyReportUtils;
    private Gson gson = new Gson();

    public DaywiseHistoricalTunnelReport() throws Exception {
//	hydroDao = new HydroSiteDao();
	dailyReportUtils = new DailyReportUtils();
//	config = ConfigReader.getObject();
    }

//    public ShiftDTO getData(DataRequestDTO dataRequest, Map<RequestContextEntity, Object> context) throws Exception {
    public DailyReportEquipmentDTO getData(DataRequestDTO dataRequest, Map<RequestContextEntity, Object> context) throws Exception {
	DaywiseReportRequestDTO requestDto = (DaywiseReportRequestDTO) dataRequest;

	SiteDTO site = (SiteDTO) context.get(DataRequestProcessor.RequestContextEntity.SITE);

	EquipmentDTO equipment = (EquipmentDTO) context.get(DataRequestProcessor.RequestContextEntity.EQUIPMENT);

	DailyReportTunnelDTO tunnel = dailyReportUtils.getTunnelInfo(equipment);

	JsonArray events = getEvents(site, equipment, requestDto);
	
	Map<Integer, TransferDTO> tempTransfers = new LinkedHashMap<>();

	buildTunnelState(tunnel, tempTransfers, requestDto, events, site, equipment);

	List<ShiftDTO> shifts = getShiftsView(tunnel, site, requestDto);

	calculateAggregrates(tunnel, tempTransfers, shifts, site, requestDto);

	cleanData(shifts);
	
	DailyReportEquipmentDTO response = prepareResponseEntity(requestDto, tunnel, site, equipment);

//	return shifts.get(0);
	return response;
    }

    private JsonArray getEvents(SiteDTO site, EquipmentDTO equipment, DaywiseReportRequestDTO requestDto)
	    throws SystemException, Exception {
	ConfigReader config = new ConfigReader();

	String fromDate = CommonUtils.convertZonedToUTC(
		DailyReportUtils.formDate(CommonUtils.getDateObject(requestDto.getDate()), requestDto.getStartShift()),
		site.getTimeZone());
	String toDate = CommonUtils.convertZonedToUTC(
		DailyReportUtils.formDate(CommonUtils.getDateObject(requestDto.getDate()), requestDto.getEndShift()),
		site.getTimeZone());

	ElasticSearchDAO esDao = new ElasticSearchDAO(false, config.getEsConfig());
	JsonArray events = esDao.getEvents(site, equipment, fromDate, toDate);

	return events;
    }

    private void buildTunnelState(DailyReportTunnelDTO tunnel, Map<Integer, TransferDTO> tempTransfers, DaywiseReportRequestDTO requestDto, JsonArray events,
	    SiteDTO site, EquipmentDTO equipment) throws Exception {

	tunnel.setTransferMap(new LinkedHashMap<Integer, TransferDTO>());
	tunnel.setBatchMap(new LinkedHashMap<Integer, BatchDTO>());
	tunnel.getTransferMap().put(new Integer(LAST_TRANSFER_KEY), null);

	Map<Integer, BatchDTO> batches = tunnel.getBatchMap();
	Map<Integer, TransferDTO> transfers = tunnel.getTransferMap();

//	Map<Integer, TransferDTO> tempTransfers = new LinkedHashMap<>();

	for (int i = 0; i < events.size(); i++) {

	    JsonObject eventJson = (JsonObject) events.get(i);
	    int eventType = eventJson.get(Constants.REPORTS.EVENT_TYPE).getAsInt();

	    if (eventType != Constants.EventType.LEVEL_ALARM.id()
		    && eventType != Constants.EventType.TRIGGER_ALARM.id()) {

		EventDTO event = gson.fromJson(eventJson, EventDTO.class);

		updateBatchState(batches, transfers, tempTransfers, eventJson, tunnel, requestDto, site, equipment);
		updateTransferState(transfers, tempTransfers, eventJson, requestDto, site, equipment);
	    }
	}
	transfers.remove(LAST_TRANSFER_KEY);

	batches.putAll(dailyReportUtils.getSortedBatchMap(batches));
    }

    private void updateBatchState(Map<Integer, BatchDTO> batches, Map<Integer, TransferDTO> transfers,
	    Map<Integer, TransferDTO> tempTransfers, JsonObject event, DailyReportTunnelDTO tunnel,
	    DaywiseReportRequestDTO requestDto, SiteDTO site, EquipmentDTO equipment) throws Exception {

	String fromDate = CommonUtils.convertZonedToUTC(
		DailyReportUtils.formDate(CommonUtils.getDateObject(requestDto.getDate()), requestDto.getStartShift()),
		site.getTimeZone());
	String toDate = CommonUtils.convertZonedToUTC(
		DailyReportUtils.formDate(CommonUtils.getDateObject(requestDto.getDate()), requestDto.getEndShift()),
		site.getTimeZone());

	int batchId = event.get(Constants.REPORTS.BATCH_ID).getAsInt();

	DailyReportRequestDTO requestDtoTemp = getRequestDto(requestDto, site, equipment);

	BatchDTO batch = dailyReportUtils.getBatchDTO(batches, transfers, event, site, requestDtoTemp, fromDate,
		tunnel.getModuleCount(), equipment, tempTransfers, toDate, site.getTimeZone());

	batches.put(batchId, batch);
    }

    private void updateTransferState(Map<Integer, TransferDTO> transfers, Map<Integer, TransferDTO> tempTransfers,
	    JsonObject event, DaywiseReportRequestDTO requestDto, SiteDTO site, EquipmentDTO equipment)
	    throws SystemException, Exception {

	int transferNum = event.get(Constants.REPORTS.TRANSFER_NUMBER).getAsInt();

	TransferDTO transfer = dailyReportUtils.getTransferDetails(transfers.containsKey(transferNum), event, transfers,
		equipment);
//	tempTransfers.put(transferNum, transfer);
//	transfers.put(transferNum, transfer);

	int eventType = event.get(Constants.REPORTS.EVENT_TYPE).getAsInt();
	String eventTime = CommonUtils
		.extractFechaDateInProcessableFormat(event.get(Constants.REPORTS.DATE_TIME).getAsString());
	if (eventType == Constants.EventType.BEGINNING_OF_NEW_CYCLE.id()) {
	    if (transfer.getStartTime() == null) {
		transfer.setStartTime(ReportUtils.convertStringToDate(eventTime));
	    }
	    tempTransfers.put(transferNum, transfer);
	    transfers.put(transferNum, transfer);
	}

	// create snapshot which can be used by next transfer in case if event is not
	// dispensing any data for module.
	int moduleId = event.get(Constants.REPORTS.MODULE).getAsInt();
	int formulaId = event.get(Constants.REPORTS.FORMULA).getAsInt();
	String formulaName = event.get(Constants.REPORTS.FORMULA_NAME).getAsString();
	Map<Integer, ModuleDTO> moduleMapSnapshot = transfer.getModuleMap();
	if (moduleMapSnapshot != null && !moduleMapSnapshot.isEmpty() && moduleMapSnapshot.containsKey(moduleId)
		&& (eventType != Constants.REPORTS.EVENT_TYPE_11)) {
	    ModuleDTO moduleDTO = moduleMapSnapshot.get(moduleId);
	    moduleDTO.setBatch(dailyReportUtils.createBatch(event, formulaId, formulaName));
	    moduleMapSnapshot.put(moduleId, moduleDTO);
	    transfers.put(transferNum, transfer);
	}

	// updating the transfer snapshots
	TransferDTO lastTransfer = transfers.get(LAST_TRANSFER_KEY);
	Integer lastTransferNumTemp = lastTransfer != null ? lastTransfer.getTransferNo() : LAST_TRANSFER_KEY;
	int lastTransferNum = dailyReportUtils.updateTransferModuleDetails(transferNum, lastTransferNumTemp, transfers,
		requestDto.isHistoricalReport(), transfer, eventTime);
	lastTransfer = transfers.get(lastTransferNum);
	transfers.put(LAST_TRANSFER_KEY, lastTransfer);

    }

    private BatchDTO createBatch(JsonObject event) {
	BatchDTO batchDTO = new BatchDTO();
	try {
	    Date eventDate = ReportUtils.convertStringToDate(event.get(Constants.REPORTS.DATE_TIME).getAsString());
	    List<EventsDTO> eventList = new LinkedList<>();
	    if (event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() != 10
		    && event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() != 11) {
		EventsDTO eventsDTO = DailyReportUtils.getTunnelEventsDetail(event);
		eventList.add(eventsDTO);
	    }
	    batchDTO.setEventList(eventList);
	    batchDTO.setFormulaId(event.get(Constants.REPORTS.FORMULA).getAsInt());
	    batchDTO.setFormulaName(event.get(Constants.REPORTS.FORMULA_NAME).getAsString());
	    batchDTO.setStartDate(eventDate);
	    batchDTO.setBatchStartTimeForEffCalc(eventDate);
	    batchDTO.setBatchEndTimeForEffCalc(eventDate);
	    batchDTO.setLbsWashed(event.get(Constants.REPORTS.KG_REALS).getAsInt());
	    batchDTO.setBatchId(event.get(Constants.REPORTS.BATCH_ID).getAsInt());
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return batchDTO;
    }

    public void updateBatch(BatchDTO batch, JsonObject event) {
	try {
	    Date eventDate = ReportUtils.convertStringToDate(event.get(Constants.REPORTS.DATE_TIME).getAsString());
	    List<EventsDTO> eventList = batch.getEventList();
	    if (event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() != Constants.EventType.BEGINNING_OF_NEW_CYCLE.id()) {
		EventsDTO eventsDTO = DailyReportUtils.getTunnelEventsDetail(event);
		eventList.add(eventsDTO);
	    }
//	    batch.setEventList(eventList);

	    if (event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() == Constants.EventType.END_OF_CYCLE.id()) {
		String eventTime = CommonUtils
			.extractFechaDateInProcessableFormat(event.get(Constants.REPORTS.DATE_TIME).getAsString());
		batch.setEndDate(ReportUtils.convertStringToDate(eventTime));
	    }
	    batch.setBatchEndTimeForEffCalc(eventDate);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
    }

    private List<ShiftDTO> getShiftsView(DailyReportTunnelDTO tunnel, SiteDTO site,
	    DaywiseReportRequestDTO requestDto) {
	
	List<ShiftDTO> shifts = requestDto.getSelectedShifts();
	ShiftDTO shift = shifts.get(0);
	shift.setTunnelDetails(tunnel);

	return shifts;
    }

    private void calculateAggregrates(DailyReportTunnelDTO tunnel, Map<Integer, TransferDTO> tempTransfers, List<ShiftDTO> shifts, SiteDTO site,
	    DaywiseReportRequestDTO requestDto) throws Exception {
	long currentTime = ReportUtils.convertStringToDate(ReportUtils.getCurrentDateTime(site.getTimeZone()))
		.getTime();
	String date = ReportUtils.getDate(requestDto.getDate());

	DailyReportTunnelDTO tempTunnelDTO = dailyReportUtils.getTunnelTurnRunTime(tunnel.getBatchMap());
	if (tempTunnelDTO.getBatchMap() != null) {

	}
	tunnel.setFormulaMap(dailyReportUtils.getFormulaProcessedInfo(tunnel.getBatchMap()));
	tunnel.setEfficiency(dailyReportUtils.getTunnelEfficiency(shifts, currentTime, tunnel.getBatchMap(), date,
		site.getTimeZone()));
	Map<Integer, BatchDTO> batchMap = dailyReportUtils.getBatchsWithEndTime(tunnel.getBatchMap(), shifts,
		requestDto.isHistoricalReport(), site.getTimeZone());
	tunnel.setTotalCycleProcessed(batchMap.size());
	tunnel.setTotalLbsProcessed(dailyReportUtils.getTotalLbsProcessed(batchMap));
//	DailyReportTunnelDTO tempData = dailyReportUtils.getActiveTimeDetails(shifts, currentTime,
//		dailyReportUtils.getTransfersEndTime(tunnel.getTransferMap()), date, requestDto.isHistoricalReport(),
//		site.getTimeZone());
	DailyReportTunnelDTO tempData = dailyReportUtils.getActiveTimeDetails(shifts, currentTime,
		dailyReportUtils.getTransfersEndTime(tempTransfers), date, requestDto.isHistoricalReport(),
		site.getTimeZone());
	tunnel.setAverageCycleTime(tempData.getAverageCycleTime());
	tunnel.setCurrentCycleTime(tempData.getCurrentCycleTime());
	tunnel.setEfficiency(
		dailyReportUtils.getTunnelEfficiency(tempData.getAverageCycleTime(), site.getTunnelTurnMinute()));
	dailyReportUtils.calculateChemicalDispensed(tunnel);
    }

    private DailyReportRequestDTO getRequestDto(DaywiseReportRequestDTO dataRequest, SiteDTO site,
	    EquipmentDTO equipment) throws Exception {
	DailyReportRequestDTO reportRequest = new DailyReportRequestDTO();
	reportRequest.setSiteId(site.getSiteId());
	reportRequest.setEquipmentId(equipment.getEquipmentId());

	reportRequest.setDate(dataRequest.getDate());
	reportRequest.setStartShift(dataRequest.getStartShift());
	reportRequest.setEndShift(dataRequest.getEndShift());
	reportRequest.setHistoricalReport(dataRequest.isHistoricalReport());

	reportRequest.setSelectedShifts(dataRequest.getSelectedShifts());
	return reportRequest;
    }
    
    private void cleanData(List<ShiftDTO> shifts) {
	for(ShiftDTO shift : shifts) {
	    shift.setStartTime(null);
	    shift.setEndTime(null);

	    DailyReportTunnelDTO tunnel = shift.getTunnelDetails();
	    tunnel.setModuleHashMap(null);
	    tunnel.setTransferMap(null);
	    tunnel.setModuleCapacity(null);
	    tunnel.setCurrentCycleTime(null);
	    for(Map.Entry<Integer, BatchDTO> entry : tunnel.getBatchMap().entrySet()) {
		BatchDTO batch = entry.getValue();
		batch.setBatchStartTimeForEffCalc(null);
		batch.setBatchEndTimeForEffCalc(null);
		for(EventsDTO event :  batch.getEventList()) {
		    event.setCurrentStatus(null);
		    event.setAlarmType(null);
		    event.setCost(null);
		}
	    }
	}
    }

    private DailyReportEquipmentDTO prepareResponseEntity(DaywiseReportRequestDTO requestDto,
	    DailyReportTunnelDTO tunnel, SiteDTO site, EquipmentDTO equipment) {

	DailyReportEquipmentDTO reportEquipment = new DailyReportEquipmentDTO();
	reportEquipment.setEquipmentId(equipment.getEquipmentId());
	reportEquipment.setEquipmentType(Constants.EquipmentType.TUNNEL.contentEquals(equipment.getEquipmentType()) ? Constants.TUNNEL : Constants.WASHER_EXTRACTOR);
	reportEquipment.setEquipmentName(StringUtils.trim(equipment.getEquipmentName()));
	reportEquipment.setTunnel(tunnel);

	return reportEquipment;
    }
}
