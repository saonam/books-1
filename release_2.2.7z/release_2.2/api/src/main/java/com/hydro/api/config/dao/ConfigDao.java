package com.hydro.api.config.dao;


import com.hydro.api.config.Config;
import com.hydro.api.config.FormulaMaster;
import com.hydro.api.config.MData;
import com.hydro.api.config.ProductMaster;
import com.hydro.api.config.UData;
import com.hydro.api.config.UnitMaster;
import com.hydro.api.config.MachineMaster;
import com.hydro.api.config.WaterMaster;
import com.hydro.api.exception.SystemException;

public interface ConfigDao {

	int createFileMaster(String siteId, Config config, String fileId, String deviceId) throws Exception;

	int createFormulaMaster(FormulaMaster formulaMaster, String equipId) throws Exception;

	int createProductMaster(ProductMaster productMaster, String equipId) throws Exception;

	int createWaterMaster(WaterMaster waterMaster, String equipId)throws Exception;

	int updateSiteMaster(String fileId, String siteId)throws Exception;

	int createEquipmentMaster(UnitMaster unitMaster, String equipId, String siteId, String fileId, String deviceId) throws Exception;

	int createWasherOrTunnelMaster(MachineMaster washerMaster, String equipId, int equipmentType) throws Exception;

	String getSiteId(String siteName) throws Exception;

	
	

}
