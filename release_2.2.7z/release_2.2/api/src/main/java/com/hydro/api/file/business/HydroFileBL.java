package com.hydro.api.file.business;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventHandler;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamReader;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.healthmarketscience.jackcess.Database;
import com.healthmarketscience.jackcess.DatabaseBuilder;
import com.healthmarketscience.jackcess.Row;
import com.healthmarketscience.jackcess.Table;
import com.hydro.api.base.business.HydroBL;
import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.base.dao.ESRestDAO;
import com.hydro.api.config.FormulaConfig;
import com.hydro.api.config.MasterConfigDTO;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.Constants.BULK_STATE;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.BulkResponseDTO;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.EquipmentListDTO;
import com.hydro.api.dto.FileDTO;
import com.hydro.api.dto.FileHistoryListResponseDTO;
import com.hydro.api.dto.FileMetaDataDTO;
import com.hydro.api.dto.FileStatusDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.lm2elements.NewDataSet;
import com.hydro.api.service.helper.ServiceHelper;
import com.hydro.api.site.business.HydroSiteBL;
import com.hydro.api.site.dao.SiteDao;
import com.hydro.api.site.dao.concrete.CompanySiteDao;
import com.hydro.api.site.dao.concrete.HydroSiteDao;
import com.hydro.api.site.dao.concrete.PartialCompanySiteDao;
import com.hydro.api.site.dao.concrete.PartialHydroSiteDao;
import com.hydro.api.site.dao.concrete.SiteComapnySiteDao;
import com.sun.jersey.core.header.FormDataContentDisposition;

/**
 * @author Srishti Tiwari, Shreyas K C
 *
 */
public class HydroFileBL extends HydroBL {
    private static final Logger LOG = LoggerFactory.getLogger(HydroFileBL.class);
    private static final Logger ESCONFLICTLOG = LoggerFactory.getLogger(Constants.ES_CONFLICTS);
    private static int THREAD_COUNT = 16;
    private static ExecutorService pool = Executors.newFixedThreadPool(Integer.valueOf(THREAD_COUNT));
    private HydroSiteBL siteBl;

    public HydroFileBL(String userId, String timeZone) throws SystemException, Exception {
	super(userId, timeZone);

	LOG.debug("In Hydro FILE BL.");
	String orgType = user.getOrgType();
	switch (orgType) {
	case Constants.HYDRO:
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new HydroSiteDao()
		    : new PartialHydroSiteDao();
	    break;
	case Constants.COMPANY:
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new CompanySiteDao()
		    : new PartialCompanySiteDao();
	    break;
	case Constants.SITE:
	    hydroDao = (permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE)) ? new CompanySiteDao()
		    : new SiteComapnySiteDao();
	    break;
	default:
	    LOG.debug("Unknown org type");
	}

	siteBl = new HydroSiteBL(userId, timeZone);
    }

    public boolean testAccountDbConnection() {
	return ((SiteDao) hydroDao).testSiteDbConnection();
    }

    /**
     * Method to upload to file(MDB, LM2)
     * 
     * @param inputStream
     * @param fileDetails
     * @param siteDTO
     * @param file
     * @return
     * @throws Exception
     */

    public boolean fileUpload(InputStream inputStream, FormDataContentDisposition fileDetails, SiteDTO siteDTO,
	    FileDTO file) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.FILE_UPLOAD);
	if (((fileDetails == null) || StringUtils.isEmpty(siteDTO.getSiteId()))
		|| StringUtils.isEmpty(fileDetails.getFileName())) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}

	String fileExtension = (file.getName()).substring((file.getName()).lastIndexOf(".") + 1).trim();

	LOG.info("Uploaded file::::" + fileDetails.getFileName());
	if (StringUtils.isEmpty(fileExtension)
		|| !Constants.SUPPORTED_EXTENSIONS.contains(fileExtension.toUpperCase())) {
	    throw new SystemException(ErrorCodes.FILE_FORMAT_NOT_SUPPORTED, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	ConfigReader config = ConfigReader.getObject();
	file.setFileId(UUID.randomUUID().toString());
	file.setSiteId(siteDTO.getSiteId());
	String saveFileLocation = config.getAppConfig(Constants.FILE_UPLOAD_PATH) + file.getFileId() + "."
		+ fileExtension;
	// Save file as blob in file_master
	((SiteDao) hydroDao).uploadFileTODB(siteDTO, file, user);

	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	byte[] buf = new byte[1024];
	int n = 0;
	while ((n = inputStream.read(buf)) >= 0)
	    baos.write(buf, 0, n);
	byte[] content = baos.toByteArray();

	// save the uploaded file
	boolean saveFile = saveFile(content, saveFileLocation);

	String extractedFile = null;
	// if zip file extract and get the mdb
	if (fileExtension.equalsIgnoreCase(Constants.ZIP)) {

	    try {
		extractedFile = extractFile(saveFileLocation, config.getAppConfig(Constants.FILE_UPLOAD_PATH));
		LOG.info("Extracted File :" + extractedFile);
		fileExtension = Constants.MDB;
	    } catch (Exception exp) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(exp));
		throw new SystemException(ErrorCodes.FILE_FORMAT_NOT_SUPPORTED,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }

	}
	String fileLocation = (extractedFile == null) ? saveFileLocation : extractedFile;
	LOG.info("Final File for processing :" + fileLocation);

	// LM2 file processing.
	if (fileExtension.equalsIgnoreCase(Constants.LM2)) {

	    pool.execute(new Runnable() {
		public void run() {
		    File dataFile = null;
		    try {

			// store file in blob and update file master and site
			// master
			((SiteDao) hydroDao).uploadLMFileTODB(content, siteDTO, file, user);

			dataFile = new File(fileLocation);
			file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.PROCESSING));
			file.setDescription(Constants.PROCESSING);
			file.setDetailedDescription(Constants.PROCESSING);
			((SiteDao) hydroDao).changeFileStatus(file);

			HashMap<String, HashMap<String, String>> eFileList = parsingLM2File(file, fileLocation);

			file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS));
			file.setDescription(Constants.SUCCESS);
			file.setDetailedDescription(Constants.SUCCESS);
			((SiteDao) hydroDao).changeConfigFileStatus(file);

			// update the equipment file records & Make other file
			// records inactive
			List<String> ipAddressList = new LinkedList<>();
			for (HashMap<String, String> eFileMap : eFileList.values()) {
			    FileDTO eFile = (FileDTO) file.clone();
			    eFile.setFileId(eFileMap.get(Constants.FILE_ID));
			    eFile.setDescription(eFileMap.get(Constants.DESCRIPTION));
			    eFile.setDevice_id(eFileMap.get(Constants.DEVICE_ID));
			    // Update record
			    ((SiteDao) hydroDao).updateEquipLM2File(eFile);
			    // Make other records inactive
//			    ((SiteDao) hydroDao).updateEquipLM2FileActive(eFile);
			    ipAddressList.add(config.getIpAddUsingDeviceId(eFileMap.get(Constants.DEVICE_ID)));
			}

			makeFileRecordsInactive(ipAddressList, file.getSiteId(), file.getFileId());

		    } catch (SystemException e) {

			LOG.error("Error : " + e.getMessage());

			try {
			    file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
			    file.setDescription(ErrorCodes.FAILED_IN_PROCESSING_FILE,
				    ConfigReader.getObject().getErrorConfig());
			    file.setDetailedDescription(e.getMessage());
			    ((SiteDao) hydroDao).changeFileStatus(file);
			} catch (Exception e2) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
			}

		    } catch (Exception e) {
			try {
			    file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
			    file.setDescription(ErrorCodes.FAILED_IN_PROCESSING_FILE,
				    ConfigReader.getObject().getErrorConfig());
			    file.setDetailedDescription(e.getMessage());
			    ((SiteDao) hydroDao).changeFileStatus(file);
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			} catch (Exception e1) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
			}

		    } finally {
			try {
			    if (inputStream != null) {
				inputStream.close();
			    }
			} catch (Exception e) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			}
			try {
			    if (baos != null) {
				baos.close();
			    }
			} catch (Exception e) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			}
			dataFile.delete();
		    }
		}
	    });
	}

	if (fileExtension.equalsIgnoreCase(Constants.JSON)) {
	    pool.execute(new Runnable() {
		public void run() {
		    File dataFile = null;
		    try {
			LOG.info("JSON File started processing :" + fileLocation);
			String dataType = null;
			String unitId = null;
			FormulaConfig formulaConfig = null;
			FileReader reader = new FileReader(fileLocation);
			Gson gson = new Gson();
			MasterConfigDTO masterConfigDTO = gson.fromJson(reader, MasterConfigDTO.class);
			if (masterConfigDTO != null && masterConfigDTO.getUnit() != null) {
			    unitId = masterConfigDTO.getUnit().getUnit_id();
			    dataType = masterConfigDTO.getData_type();
			} else {
			    reader = new FileReader(fileLocation);
			    formulaConfig = gson.fromJson(reader, FormulaConfig.class);
			    dataType = formulaConfig.getData_type();
			    unitId = formulaConfig.getUnit_id();
			}

			// fetching the data type from json file so as to find out what type of data is
			// being parsed.

			if (!dataType.equalsIgnoreCase(Constants.DATA_TYPE.CONFIG)
				&& !dataType.equalsIgnoreCase(Constants.DATA_TYPE.FORMULAS)) {
			    ((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
				    Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE),
				    ErrorCodes.INVALID_CONFIG_DATA_TYPE, ConfigReader.getObject().getErrorConfig(),
				    "Invalid config data type. Please upload either config/formulas json file"));
			}

			((SiteDao) hydroDao).uploadJsonFileTODB(content, siteDTO, file, user, dataType, unitId);
			dataFile = new File(fileLocation);
			((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
				Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.PROCESSING),
				Constants.PROCESSING, null, Constants.PROCESSING));
			HashMap<String, HashMap<String, String>> eFileList = null;
			if (dataType.equalsIgnoreCase(Constants.DATA_TYPE.CONFIG)) {
			    eFileList = ((SiteDao) hydroDao).parsingConfigFile(masterConfigDTO, file, user, unitId);
			    if (eFileList != null) {
				((SiteDao) hydroDao).changeConfigFileStatus(((SiteDao) hydroDao).getFileStatus(file,
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS),
					Constants.SUCCESS, null, Constants.SUCCESS));
				// update the equipment file records & Make other file
				// records inactive
				for (HashMap<String, String> eFileMap : eFileList.values()) {
				    FileDTO eFile = (FileDTO) file.clone();
				    eFile.setFileId(eFileMap.get(Constants.FILE_ID));
				    eFile.setDescription(eFileMap.get(Constants.DESCRIPTION));
				    eFile.setDevice_id(eFileMap.get(Constants.DEVICE_ID));
				    // Update record
				    ((SiteDao) hydroDao).updateEquipJsonFile(eFile);

//				    ((SiteDao) hydroDao).updateEquipLM2FileActive(eFile);
				}
				// Make other records inactive
				List<String> ipAddressList = new LinkedList<>();
				ipAddressList.add(masterConfigDTO.getUnit().getIp());
				makeFileRecordsInactive(ipAddressList, file.getSiteId(), file.getFileId());
				// whenever a new config for a unit is uploaded old formula details will be
				// marked as inactive
				((SiteDao) hydroDao).updateOldFileInActive(file, unitId);

			    } else {
				((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE),
					ErrorCodes.FAILED_IN_PROCESSING_FILE, ConfigReader.getObject().getErrorConfig(),
					"Failed during processing of file"));
			    }
			} else {
			    // upload formula config
			    // check if any config file is present for the unit if not then throw an
			    // exception
			    String equipmentId = ((SiteDao) hydroDao).getEquipmentForUnit(file.getSiteId(), unitId);
			    if (equipmentId == null) {
				((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE),
					ErrorCodes.CONFIG_FILE_MISSING, ConfigReader.getObject().getErrorConfig(),
					"Config file is missing for the unit. Please upload a config file and then try reuploading the formula file."));
			    } else if (formulaConfig != null) {
				((SiteDao) hydroDao).uploadJsonFileTODB(content, siteDTO, file, user, dataType, unitId);
				dataFile = new File(fileLocation);
				((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.PROCESSING),
					Constants.PROCESSING, null, Constants.PROCESSING));
				((SiteDao) hydroDao).parsingFormulaJSONFile(formulaConfig, file, user, equipmentId,
					unitId);
				((SiteDao) hydroDao).changeConfigFileStatus(((SiteDao) hydroDao).getFileStatus(file,
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS),
					Constants.SUCCESS, null, Constants.SUCCESS));
//				((SiteDao) hydroDao).updateEquipLM2FileActive(file);
				((SiteDao) hydroDao).updateOldFileInActive(file, unitId);
			    }

			}

		    } catch (SystemException e) {
			LOG.error("Error : " + e.getMessage());
			try {
			    ((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
				    Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE),
				    ErrorCodes.FAILED_IN_PROCESSING_FILE, ConfigReader.getObject().getErrorConfig(),
				    e.getMessage()));
			} catch (Exception e2) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
			}

		    } catch (Exception e) {
			try {
			    ((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
				    Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE),
				    ErrorCodes.FAILED_IN_PROCESSING_FILE, ConfigReader.getObject().getErrorConfig(),
				    e.getMessage()));
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			} catch (Exception e1) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
			}

		    } finally {

			dataFile.delete();

		    }
		}
	    });
	}

	// MDB file processing.
	if (fileExtension.equalsIgnoreCase(Constants.MDB)) {

	    ((SiteDao) hydroDao).uploadMDBFileStatusTODB(siteDTO, file, user);

	    pool.execute(new Runnable() {

		public void run() {
		    File dataFile = null;
		    try {

			file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.PROCESSING));
			file.setDescription(Constants.PROCESSING);
			file.setDetailedDescription(Constants.PROCESSING);
			((SiteDao) hydroDao).changeFileStatus(file);
			dataFile = new File(fileLocation);

			EquipmentListDTO eq = siteBl.getEquipmentSpecification(siteDTO);
			List<EquipmentDTO> equipmentList = eq.getEquipmentList();
			parsingMDBFile(dataFile, file.getFileId(), equipmentList, siteDTO.getSiteId(), user, file);

			// parsingFile.deleteOnExit();
			file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS));
			file.setDescription(Constants.SUCCESS);
			file.setDetailedDescription(Constants.SUCCESS);
			((SiteDao) hydroDao).changeFileStatus(file);

		    } catch (Exception e) {
			try {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			    throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
			} catch (SystemException e1) {

			    LOG.error("Error : " + e.getMessage());

			    try {
				file.setStatus(
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
				file.setDescription(e.getMessage());
				file.setDetailedDescription(e.getMessage());
				((SiteDao) hydroDao).changeFileStatus(file);
			    } catch (Exception e2) {
				LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
			    }

			} catch (Exception e1) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
			    try {
				file.setStatus(
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
				file.setDescription(ErrorCodes.FAILED_IN_PROCESSING_FILE,
					ConfigReader.getObject().getErrorConfig());
				file.setDetailedDescription(e.getMessage());
				((SiteDao) hydroDao).changeFileStatus(file);
			    } catch (Exception e2) {
				LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
			    }

			}

		    } finally {
			try {
			    if (inputStream != null) {
				inputStream.close();
			    }
			} catch (Exception e) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			}
			try {
			    if (baos != null) {
				baos.close();
			    }
			} catch (Exception e) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			}
			dataFile.delete();
		    }

		}

	    });

	}
	return true;

    }

    /**
     * Method to upload file(MDB, LM2) of Chunk size.
     * 
     * @param inputStream
     * @param fileDetails
     * @param siteDTO
     * @param file
     * @return
     * @throws Exception
     */

    public FileStatusDTO chunkFileUpload(InputStream inputStream, FormDataContentDisposition fileDetails,
	    SiteDTO siteDTO, FileDTO file, FileMetaDataDTO metaData) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.FILE_UPLOAD);
	FileStatusDTO statusDTO = new FileStatusDTO();
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	if (((fileDetails == null) || StringUtils.isEmpty(siteDTO.getSiteId()))
		|| StringUtils.isEmpty(fileDetails.getFileName())) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	String fileExtension = (file.getName()).substring((file.getName()).lastIndexOf(".") + 1).trim();
	LOG.info("Uploaded file::::" + metaData.getFileName());
	if (StringUtils.isEmpty(fileExtension)
		|| !Constants.SUPPORTED_EXTENSIONS.contains(fileExtension.toUpperCase())) {
	    throw new SystemException(ErrorCodes.FILE_FORMAT_NOT_SUPPORTED, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	try {
	    /*
	     * TODO: Once UI incorporated the UID, set randomId to fileId.
	     */
	    if (metaData != null && metaData.getChunkIndex() == 0) {
		// file.setFileId(UUID.randomUUID().toString());
		file.setFileId(metaData.getUploadUid());
		((SiteDao) hydroDao).uploadFileTODB(siteDTO, file, user);
	    } else {
		file.setFileId(metaData.getUploadUid());
		boolean isFileExists = ((SiteDao) hydroDao).fileExists(file.getFileId());
		if (!isFileExists) {
		    throw new SystemException(ErrorCodes.INVALID_UPLOAD_ID, ConfigReader.getObject().getErrorConfig(),
			    ErrorCodes.StatusCodes.BAD_REQUEST, null);
		}
	    }

	    ConfigReader config = ConfigReader.getObject();
	    file.setSiteId(siteDTO.getSiteId());
	    String saveFileLocation = config.getAppConfig(Constants.FILE_UPLOAD_PATH) + file.getFileId() + "."
		    + fileExtension;
	    byte[] buf = new byte[1024];
	    int n = 0;
	    while ((n = inputStream.read(buf)) >= 0)
		baos.write(buf, 0, n);
	    byte[] content = baos.toByteArray();

	    // save the uploaded file
	    boolean saveFile = saveChunkFile(content, saveFileLocation);
	    boolean uploaded = (metaData.getTotalChunks() - 1) <= metaData.getChunkIndex();

	    statusDTO.setUploaded(uploaded);
	    statusDTO.setUploadUid(file.getFileId());
	    if (uploaded) {
		LOG.info("Chunk file Uploaded successfully");
		statusDTO.setStatus(processFile(fileExtension, saveFileLocation, content, siteDTO, file, config));
	    }
	} finally {
	    if (baos != null) {
		baos.close();
	    }
	    if (inputStream != null) {
		inputStream.close();
	    }
	}
	return statusDTO;
    }

    public boolean processFile(String fileExtension, String saveFileLocation, byte[] content, SiteDTO siteDTO,
	    FileDTO file, ConfigReader config) throws Exception {

	String extractedFile = null;
	// if zip file extract and get the mdb
	if (fileExtension.equalsIgnoreCase(Constants.ZIP)) {

	    try {
		extractedFile = extractFile(saveFileLocation, config.getAppConfig(Constants.FILE_UPLOAD_PATH));
		LOG.info("Extracted File :" + extractedFile);
		String extension = FilenameUtils.getExtension(extractedFile);
		fileExtension = Constants.MDB;
	    } catch (SystemException exp) {
		LOG.error("Error : " + exp.getMessage());
		try {
		    file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
		    file.setDescription(exp.getMessage());
		    file.setDetailedDescription(exp.getMessage());
		    ((SiteDao) hydroDao).changeFileStatus(file);
		} catch (Exception e) {
		    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		}
	    } catch (Exception exp) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(exp));
		try {
		    file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
		    file.setDescription(ErrorCodes.INVALID_FILE_STRUCTURE, ConfigReader.getObject().getErrorConfig());
		    file.setDetailedDescription(file.getDescription());
		    ((SiteDao) hydroDao).changeFileStatus(file);
		} catch (Exception e) {
		    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		}
	    }
	}

	String fileLocation = (extractedFile == null) ? saveFileLocation : extractedFile;
	LOG.info("Final File for processing :" + fileLocation);

	// LM2 file processing.
	if (fileExtension.equalsIgnoreCase(Constants.LM2)) {

	    pool.execute(new Runnable() {
		public void run() {
		    File dataFile = null;
		    try {

			LOG.info("LM2 File started processing :" + fileLocation);
			// store file in blob and update file master and site
			// master
			((SiteDao) hydroDao).uploadLMFileTODB(content, siteDTO, file, user);

			dataFile = new File(fileLocation);
			file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.PROCESSING));
			file.setDescription(Constants.PROCESSING);
			file.setDetailedDescription(Constants.PROCESSING);
			((SiteDao) hydroDao).changeFileStatus(file);

			HashMap<String, HashMap<String, String>> eFileList = parsingLM2File(file, fileLocation);
			LOG.info("Lm2 File parsed successfully");

			file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS));
			file.setDescription(Constants.SUCCESS);
			file.setDetailedDescription(Constants.SUCCESS);
			((SiteDao) hydroDao).changeConfigFileStatus(file);

			// update the equipment file records & Make other file
			// records inactive
			List<String> ipAddressList = new LinkedList<>();
			for (HashMap<String, String> eFileMap : eFileList.values()) {
			    FileDTO eFile = (FileDTO) file.clone();
			    eFile.setFileId(eFileMap.get(Constants.FILE_ID));
			    eFile.setDescription(eFileMap.get(Constants.DESCRIPTION));
			    eFile.setDevice_id(eFileMap.get(Constants.DEVICE_ID));
			    // Update record
			    ((SiteDao) hydroDao).updateEquipLM2File(eFile);
			    ipAddressList.add(config.getIpAddUsingDeviceId(eFileMap.get(Constants.DEVICE_ID)));
			}
			// Make other records inactive

			makeFileRecordsInactive(ipAddressList, file.getSiteId(), file.getFileId());

		    } catch (SystemException e) {

			LOG.error("Error : " + e.getMessage());

			try {
			    file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
			    file.setDescription(ErrorCodes.FAILED_IN_PROCESSING_FILE,
				    ConfigReader.getObject().getErrorConfig());
			    file.setDetailedDescription(e.getMessage());
			    ((SiteDao) hydroDao).changeFileStatus(file);
			} catch (Exception e2) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
			}

		    } catch (Exception e) {
			try {
			    file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
			    file.setDescription(ErrorCodes.FAILED_IN_PROCESSING_FILE,
				    ConfigReader.getObject().getErrorConfig());
			    file.setDetailedDescription(e.getMessage());
			    ((SiteDao) hydroDao).changeFileStatus(file);
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			} catch (Exception e1) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
			}

		    } finally {

			dataFile.delete();

		    }
		}
	    });
	} else if (fileExtension.equalsIgnoreCase(Constants.MDB)) {
	    // MDB file processing.
	    // if (fileExtension.equalsIgnoreCase(Constants.MDB) ||
	    // fileExtension.equalsIgnoreCase(Constants.ACCDB)) {

	    ((SiteDao) hydroDao).uploadMDBFileStatusTODB(siteDTO, file, user);

	    pool.execute(new Runnable() {

		public void run() {
		    File dataFile = null;
		    try {
			LOG.info("MDB File started processing :" + fileLocation);
			file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.PROCESSING));
			file.setDescription(Constants.PROCESSING);
			file.setDetailedDescription(Constants.PROCESSING);
			((SiteDao) hydroDao).changeFileStatus(file);
			dataFile = new File(fileLocation);

			EquipmentListDTO eq = siteBl.getEquipmentSpecification(siteDTO);
			List<EquipmentDTO> equipmentList = eq.getEquipmentList();
			parsingMDBFile(dataFile, file.getFileId(), equipmentList, siteDTO.getSiteId(), user, file);
			LOG.info("MDB File parsed successfully");
			// parsingFile.deleteOnExit();
			file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS));
			file.setDescription(Constants.SUCCESS);
			file.setDetailedDescription(Constants.SUCCESS);
			((SiteDao) hydroDao).changeFileStatus(file);

		    } catch (Exception e) {
			try {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			    throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
			} catch (SystemException e1) {

			    LOG.error("Error : " + e.getMessage());

			    try {
				file.setStatus(
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
				file.setDescription(e.getMessage());
				file.setDetailedDescription(e.getMessage());
				((SiteDao) hydroDao).changeFileStatus(file);
			    } catch (Exception e2) {
				LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
			    }

			} catch (Exception e1) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
			    try {
				file.setStatus(
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
				file.setDescription(ErrorCodes.FAILED_IN_PROCESSING_FILE,
					ConfigReader.getObject().getErrorConfig());
				file.setDetailedDescription(e.getMessage());
				((SiteDao) hydroDao).changeFileStatus(file);
			    } catch (Exception e2) {
				LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
			    }

			}

		    } finally {
			dataFile.delete();
		    }

		}

	    });

	} else if (fileExtension.equalsIgnoreCase(Constants.JSON)) {
	    pool.execute(new Runnable() {
		public void run() {
		    File dataFile = null;
		    try {
			LOG.info("JSON File started processing :" + fileLocation);
			String dataType = null;
			String unitId = null;
			FormulaConfig formulaConfig = null;
			FileReader reader = new FileReader(fileLocation);
			Gson gson = new Gson();
			MasterConfigDTO masterConfigDTO = gson.fromJson(reader, MasterConfigDTO.class);
			if (masterConfigDTO != null && masterConfigDTO.getUnit() != null) {
			    unitId = masterConfigDTO.getUnit().getUnit_id();
			    dataType = masterConfigDTO.getData_type();
			} else {
			    reader = new FileReader(fileLocation);
			    formulaConfig = gson.fromJson(reader, FormulaConfig.class);
			    dataType = formulaConfig.getData_type();
			    unitId = formulaConfig.getUnit_id();
			}

			// fetching the data type from json file so as to find out what type of data is
			// being parsed.

			if (!dataType.equalsIgnoreCase(Constants.DATA_TYPE.CONFIG)
				&& !dataType.equalsIgnoreCase(Constants.DATA_TYPE.FORMULAS)) {
			    ((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
				    Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE),
				    ErrorCodes.INVALID_CONFIG_DATA_TYPE, ConfigReader.getObject().getErrorConfig(),
				    "Invalid config data type. Please upload either config/formulas json file"));
			}

			((SiteDao) hydroDao).uploadJsonFileTODB(content, siteDTO, file, user, dataType, unitId);
			dataFile = new File(fileLocation);
			((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
				Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.PROCESSING),
				Constants.PROCESSING, null, Constants.PROCESSING));
			HashMap<String, HashMap<String, String>> eFileList = null;
			if (dataType.equalsIgnoreCase(Constants.DATA_TYPE.CONFIG)) {
			    eFileList = ((SiteDao) hydroDao).parsingConfigFile(masterConfigDTO, file, user, unitId);
			    if (eFileList != null) {
				((SiteDao) hydroDao).changeConfigFileStatus(((SiteDao) hydroDao).getFileStatus(file,
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS),
					Constants.SUCCESS, null, Constants.SUCCESS));
				// update the equipment file records & Make other file
				// records inactive
				for (HashMap<String, String> eFileMap : eFileList.values()) {
				    FileDTO eFile = (FileDTO) file.clone();
				    eFile.setFileId(eFileMap.get(Constants.FILE_ID));
				    eFile.setDescription(eFileMap.get(Constants.DESCRIPTION));
				    eFile.setDevice_id(eFileMap.get(Constants.DEVICE_ID));
				    // Update record
				    ((SiteDao) hydroDao).updateEquipJsonFile(eFile);
				}
				List<String> ipAddressList = new LinkedList<>();
				ipAddressList.add(masterConfigDTO.getUnit().getIp());
				makeFileRecordsInactive(ipAddressList, file.getSiteId(), file.getFileId());
//				// whenever a new config for a unit is uploaded old formula details will be marked as inactive
				((SiteDao) hydroDao).updateOldFileInActive(file, unitId);
			    } else {
				((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE),
					ErrorCodes.FAILED_IN_PROCESSING_FILE, ConfigReader.getObject().getErrorConfig(),
					"Failed during processing of file"));
			    }
			} else {
			    // upload formula config
			    // check if any config file is present for the unit if not then throw an
			    // exception
			    String equipmentId = ((SiteDao) hydroDao).getEquipmentForUnit(file.getSiteId(), unitId);
			    if (equipmentId == null) {
				((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE),
					ErrorCodes.CONFIG_FILE_MISSING, ConfigReader.getObject().getErrorConfig(),
					"Config file is missing for this Unit. Please upload the config.json file before uploading the formula.json file."));
			    } else if (formulaConfig != null) {
				((SiteDao) hydroDao).uploadJsonFileTODB(content, siteDTO, file, user, dataType, unitId);
				dataFile = new File(fileLocation);
				((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.PROCESSING),
					Constants.PROCESSING, null, Constants.PROCESSING));
				((SiteDao) hydroDao).parsingFormulaJSONFile(formulaConfig, file, user, equipmentId,
					unitId);
				((SiteDao) hydroDao).changeConfigFileStatus(((SiteDao) hydroDao).getFileStatus(file,
					Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS),
					Constants.SUCCESS, null, Constants.SUCCESS));
				((SiteDao) hydroDao).updateOldFileInActive(file, unitId);
			    }

			}

		    } catch (SystemException e) {
			LOG.error("Error : " + e.getMessage());
			try {
			    ((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
				    Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE),
				    ErrorCodes.FAILED_IN_PROCESSING_FILE, ConfigReader.getObject().getErrorConfig(),
				    e.getMessage()));
			} catch (Exception e2) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
			}

		    } catch (Exception e) {
			try {
			    ((SiteDao) hydroDao).changeFileStatus(((SiteDao) hydroDao).getFileStatus(file,
				    Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE),
				    ErrorCodes.FAILED_IN_PROCESSING_FILE, ConfigReader.getObject().getErrorConfig(),
				    e.getMessage()));
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			} catch (Exception e1) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
			}

		    } finally {

			dataFile.delete();

		    }
		}
	    });
	}

	return true;
    }

    protected void parsingMDBFile(File parsingFile, String fileId, List<EquipmentDTO> equipmentList, String siteId,
	    UserDTO user, FileDTO file) throws Exception {
	// LinkedList<EsErrorLogDTO> conflictsList = new
	// LinkedList<EsErrorLogDTO>();
	SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.DATE_TIME_FORMAT_WITHOUT_SEC);
	boolean successFlag = false;
	boolean failureFlag = false;
	boolean partialSuccessFlag = false;
	long startTime = System.currentTimeMillis();
	long endTime;
	InputStream inputStream = null;
	Database db = null;
	Set<String> table;
	try {
	    try {
		db = DatabaseBuilder.open(parsingFile);
		table = db.getTableNames();
		if (table == null || (table != null
			&& (!table.contains(Constants.CONTROL) || !table.contains(Constants.EVENTOS1)))) {
		    throw new SystemException(ErrorCodes.INVALID_FILE_STRUCTURE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		throw new SystemException(ErrorCodes.INVALID_FILE_STRUCTURE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    /*
	     * Added data file pre check. Compare the equipment count from db and equipments
	     * from data file. Throwing exception, If the data file event exceeded the
	     * equipment count.
	     */
	    try {
		int tableEventSize = 0;
		for (String row : table) {
		    if (row.indexOf(Constants.EVENTOS) != -1) {
			if (db.getTable(row.toString()).getRowCount() > 0)
			    tableEventSize++;
		    }
		}
		if (equipmentList.size() < tableEventSize) {
		    throw new SystemException(ErrorCodes.DATA_ERROR_IN_MDB_FILE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		throw new SystemException(ErrorCodes.DATA_ERROR_IN_MDB_FILE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }

	    // TODO: Need to implement precheck for machine count.
	    try {

		if (table != null && table.contains(Constants.CONTROL)) {
		    table.remove(Constants.CONTROL);
		}
		int counter = 1;
		int batchCounterForLog = 1;
		for (String row : table) {

		    Table tableName = db.getTable(row.toString());

		    if (counter > equipmentList.size() || tableName.getRowCount() <= 0) {
			break;
			// throw new
			// SystemException(ErrorCodes.GENERIC_EXCEPTION,
			// ConfigReader.getObject().getErrorConfig(),
			// ErrorCodes.StatusCodes.FAILURE, null);
		    }
		    StringBuilder eventIdBuilder = null;
		    EquipmentDTO equipment = equipmentList.get(counter - 1);
		    ConfigReader configReader = ConfigReader.getObject();
		    ESRestDAO esDAO = new ESRestDAO();
		    int batchCounter = 1;
		    long start = System.currentTimeMillis();
		    long end = System.currentTimeMillis();
		    for (Row rows : tableName) {
			eventIdBuilder = new StringBuilder();
			Map<String, Object> dataMap = new LinkedHashMap<>();
			dataMap.put(Constants.LM2_SEQ, counter + "");
			eventIdBuilder.append(counter + "");
			dataMap.put(Constants.SITE_ID, siteId);
			eventIdBuilder.append(siteId + "");
			dataMap.put(Constants.LM2_FILE_ID, equipment.getFileId());
			dataMap.put(Constants.FILE_ID, fileId);
			dataMap.put(Constants.EQUIPMENT_TYPE, equipment.getEquipmentType());
			dataMap.put("device_id", equipment.getDeviceId());
			dataMap.put("source", "upload");

			Set<String> keys = rows.keySet();
			LocalDateTime dateTime = null;
			String pumpVal = "";
			String pumpKey = "";
			String prodVal = "";
			String prodKey = "";
			for (String key : keys) {
			    Object obj = rows.get(key);
			    // date time
			    // if
			    // (EventColumns.DATE_TIME.contains(key.toLowerCase()))
			    // {
			    // dateTime =
			    // CommonUtils.getEventDateTime(obj.toString());
			    // obj = dateTime;
			    // }
			    Date date = null;
			    if (obj instanceof Date) {
				date = (Date) obj;
				LocalDateTime dateTemp = LocalDateTime.ofInstant(date.toInstant(),
					ZoneId.systemDefault());
				obj = dateTemp;
				if (Constants.EventColumns.DATE_TIME.contains(key.toLowerCase())) {
				    dateTime = dateTemp;
				}
			    }
			    dataMap.put(key.toLowerCase(), obj);
			    if (Constants.EventColumns.EVENT_ID_GENERATOR.contains(key.toLowerCase())) {
				if (key.equalsIgnoreCase(Constants.REPORTS.DATE_TIME)) {
				    String strDate = formatter.format(date.getTime());
				    obj = strDate;
				}
				eventIdBuilder.append(obj + "");
			    }
			    key = key.trim();
			    if (Constants.EventColumns.PROD_NAME.contains(key.toLowerCase())) {
				prodKey = key.toLowerCase();
				Object prod = rows.get(key);
				if (prod != null)
				    prodVal = prod + "";
				if (StringUtils.isEmpty(prodVal)) {
				    prodVal = "";
				    dataMap.put(key.toLowerCase(), "");
				}
			    }
			    if (Constants.EventColumns.PUMPS.contains(key.toLowerCase())) {
				pumpKey = key.toLowerCase();
				Object pump = rows.get(key);
				if (pump != null)
				    pumpVal = pump + "";
				if (StringUtils.isEmpty(pumpVal)) {
				    pumpVal = "0";
				    dataMap.put(key.toLowerCase(), 0);
				}
			    }
			    // System.out.println("Key : " + key + ", Value : "
			    // +
			    // rows.get(key));
			}
			dataMap.put(prodKey + "_" + pumpKey, pumpVal + "_" + prodVal);
			eventIdBuilder.append(pumpVal + "_" + prodVal);

			String eventId = CommonUtils.getEventId(eventIdBuilder);
			dataMap.put(Constants.EVENT_ID, eventId);
			String jsonPayload = ServiceHelper.buildJsonString(dataMap);
			try {
			    String esType = configReader.getAppConfig(Constants.ES_TYPE);
			    String esIndex = ReportUtils.getIndexName(siteId, dateTime.getMonthValue(),
				    dateTime.getYear());
			    esDAO.prepareBulk(esIndex, esType, eventId, jsonPayload, false);
			    int batchSize = Integer.parseInt(configReader.getAppConfig(Constants.ES_BATCH_SIZE));
			    batchCounter++;
			    if (batchSize <= batchCounter) {
				end = System.currentTimeMillis();
				LOG.debug("Batch Size : " + (batchCounter - 1)
					+ ". Bulk creation time>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  "
					+ (end - start));
				long startBatch = System.currentTimeMillis();
				BulkResponseDTO bulkResponseDTO = esDAO.executeBulk(siteId, fileId, user);
				long endBatch = System.currentTimeMillis();
				LOG.debug("Batch Size : " + (batchCounter - 1)
					+ ". Bulk execution time>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  "
					+ (endBatch - startBatch) + "Batch Number:" + batchCounterForLog++);
				// if (bulkResponseDTO.getConflictsList() !=
				// null
				// &&
				// !bulkResponseDTO.getConflictsList().isEmpty())
				// {
				// conflictsList.addAll(bulkResponseDTO.getConflictsList());
				// }
				if (!StringUtils.isEmpty(bulkResponseDTO.getConflicts())) {
				    ESCONFLICTLOG.error(bulkResponseDTO.getConflicts());
				}
				BULK_STATE state = bulkResponseDTO.getBulkState();
				switch (state) {
				case FAILED:
				    failureFlag = true;
				    break;
				case SUCCESS:
				    successFlag = true;
				    break;
				case PARTIAL_SUCCESS:
				    partialSuccessFlag = true;
				    break;
				default:
				    break;
				}
				batchCounter = 1;
			    }
			} catch (Exception e) {
			    failureFlag = true;
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			}
			end = System.currentTimeMillis();
			LOG.debug("Batch Execution time >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>  " + (end - start));
			start = System.currentTimeMillis();
		    }
		    try {
			BulkResponseDTO bulkResponseDTO = esDAO.executeBulk(siteId, fileId, user);
			if (!StringUtils.isEmpty(bulkResponseDTO.getConflicts())) {
			    ESCONFLICTLOG.error(bulkResponseDTO.getConflicts());
			}
			// if (bulkResponseDTO.getConflictsList() != null
			// && !bulkResponseDTO.getConflictsList().isEmpty()) {
			// conflictsList.addAll(bulkResponseDTO.getConflictsList());
			// }
			BULK_STATE state = bulkResponseDTO.getBulkState();
			switch (state) {
			case FAILED:
			    failureFlag = true;
			    break;
			case SUCCESS:
			    successFlag = true;
			    break;
			case PARTIAL_SUCCESS:
			    partialSuccessFlag = true;
			    break;
			default:
			    break;
			}
			esDAO.closeRestClient();
		    } catch (Exception e) {
			// TODO: handle exception
			failureFlag = true;
			LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		    }
		    counter++;
		}

	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    } finally {
		try {
		    if (inputStream != null) {
			inputStream.close();
			inputStream = null;
		    }
		} catch (Exception e2) {
		    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
		}
	    }
	    if (partialSuccessFlag || (failureFlag && successFlag)) {
		file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.PARTIAL_SUCCESS));
		file.setDescription(ErrorCodes.FAILED_DURING_DATA_STORAGE, ConfigReader.getObject().getErrorConfig());
		file.setDetailedDescription(Constants.PARTIAL_SUCCESS);
		((SiteDao) hydroDao).changeFileStatus(file);
	    } else if (failureFlag) {
		file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
		file.setDescription(ErrorCodes.FAILED_DURING_DATA_STORAGE, ConfigReader.getObject().getErrorConfig());
		file.setDetailedDescription(Constants.FAILURE);
		((SiteDao) hydroDao).changeFileStatus(file);
	    } else if (successFlag) {
		file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS));
		file.setDescription(Constants.SUCCESS);
		file.setDetailedDescription(Constants.SUCCESS);
		((SiteDao) hydroDao).changeFileStatus(file);
	    } else {
		file.setStatus(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
		file.setDescription(ErrorCodes.FAILED_DURING_DATA_STORAGE, ConfigReader.getObject().getErrorConfig());
		file.setDetailedDescription(Constants.FAILURE);
		((SiteDao) hydroDao).changeFileStatus(file);
	    }
	    endTime = System.currentTimeMillis();
	    LOG.info("Processing (Data): " + fileId + " took : " + (endTime - startTime + " ms"));

	    // if (conflictsList != null && !conflictsList.isEmpty()) {
	    // for (EsErrorLogDTO errorLog : conflictsList) {
	    // ESCONFLICTLOG.error("Error inserting document. Error Message : "
	    // + errorLog.getEsError() + "\n"
	    // + "Error Type : " + errorLog.getErrorType() + "\n" + "Index Name
	    // : "
	    // + errorLog.getIndexName() + "\n" + "Type Name : " +
	    // errorLog.getEsType() + "\n"
	    // + "Document Failed : " + errorLog.getEsDocument());
	    // }
	    // }
	} finally {
	    try {
		if (db != null) {
		    db.close();
		    db = null;
		}
	    } catch (Exception e3) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e3));
	    }
	    try {
		if (parsingFile != null) {
		    parsingFile.delete();
		    parsingFile = null;
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public HashMap<String, HashMap<String, String>> parsingLM2File(FileDTO file, String filepath) throws Exception {
	long startTime = System.currentTimeMillis();
	long endTime;
	HashMap<String, HashMap<String, String>> eFileList = new HashMap<String, HashMap<String, String>>();
	// LM2 parsing part
	String xmlFile = null;
	try {
	    xmlFile = removeXSD(filepath);

	} catch (Exception e) {
	    File xml = new File(xmlFile);
	    xml.delete();
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVALID_FILE_STRUCTURE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}

	try {
	    eFileList = runLM2Unmarshaller(file, xmlFile);
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    File xml = new File(xmlFile);
	    xml.delete();
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    File xml = new File(xmlFile);
	    xml.delete();
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVALID_FILE_STRUCTURE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
	endTime = System.currentTimeMillis();
	LOG.info("Processing (LM2) : " + file.getFileId() + " took : " + (endTime - startTime + " ms"));

	return eFileList;
    }

    private boolean saveFile(byte[] content, String fileLocation) throws Exception {
	InputStream inputStream = null;
	File targetFile = null;
	try {
	    inputStream = new ByteArrayInputStream(content);
	    targetFile = new File(fileLocation);
	    FileUtils.copyInputStreamToFile(inputStream, targetFile);
	} finally {
	    try {
		if (inputStream != null) {
		    inputStream.close();
		}
		targetFile = null;
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
	return true;
    }

    private boolean saveChunkFile(byte[] content, String fileLocation) throws Exception {
	FileOutputStream fos = null;
	InputStream inputStream = null;
	File targetFile = null;
	try {
	    inputStream = new ByteArrayInputStream(content);
	    targetFile = new File(fileLocation);
	    fos = new FileOutputStream(targetFile, true);
	    IOUtils.copy(inputStream, fos);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (inputStream != null) {
		    inputStream.close();
		}
		if (fos != null) {
		    fos.close();
		}
		targetFile = null;
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
	return true;
    }

    private String extractFile(String fileZip, String destFolder) throws Exception {
	LOG.debug("In Extraction:  " + fileZip + " : " + destFolder);
	String extractedFilePath = null;
	File newFile = null;
	ZipInputStream zis = null;
	FileOutputStream fos = null;
	byte[] buffer = null;
	ZipEntry zipEntry = null;
	File zipFile = new File(fileZip);
	try {
	    buffer = new byte[1024];
	    zis = new ZipInputStream(new FileInputStream(zipFile));
	    zipEntry = zis.getNextEntry();
	    while (zipEntry != null) {
		String fileName = zipEntry.getName();
		newFile = new File(destFolder + "/" + fileName);
		extractedFilePath = newFile.getAbsolutePath();
		LOG.debug("Extracted File::" + extractedFilePath);
		fos = new FileOutputStream(newFile);
		int len;
		while ((len = zis.read(buffer)) > 0) {
		    fos.write(buffer, 0, len);
		}
		zipEntry = zis.getNextEntry();
		if (zipEntry != null) {
		    throw new SystemException(ErrorCodes.MULTIPLE_FILES_IN_ARCHIVE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }
	} finally {
	    newFile = null;
	    buffer = null;
	    zipEntry = null;
	    if (fos != null) {
		fos.flush();
		fos.close();
	    }
	    if (zis != null) {
		zis.closeEntry();
		zis.close();
	    }
	    zipFile.delete();
	}
	return extractedFilePath;
    }

    private String removeXSD(String lmsfileLocation) throws Exception {

	File xsdFile = new File(lmsfileLocation);
	String fileName = xsdFile.getAbsolutePath();
	BufferedReader br1 = null;
	File xmlFile = new File(fileName + "_temp");
	PrintWriter pw = null;
	StringBuilder sb = null;
	BufferedReader bufReader = null;
	InputStream in = null;
	InputStreamReader reader = null;
	try {
	    // PrintWriter object for output.txt
	    pw = new PrintWriter(xmlFile);
	    in = new FileInputStream(lmsfileLocation);
	    reader = new InputStreamReader(in, "UTF-8");
	    // BufferedReader object for input.txt
	    br1 = new BufferedReader(reader);

	    String line1 = br1.readLine();
	    line1 = CommonUtils.removeUTF8BOM(line1);
	    sb = new StringBuilder();
	    while (line1 != null) {
		sb.append(line1);
		line1 = br1.readLine();
		line1 = CommonUtils.removeUTF8BOM(line1);

	    }
	    line1 = sb.toString();
	    line1 = line1.replaceAll("<", "\n<");
	    bufReader = new BufferedReader(new StringReader(line1));

	    while ((line1 = bufReader.readLine()) != null) {
		if (!StringUtils.isEmpty(line1) && line1.indexOf("xs:") == -1)
		    pw.println(line1);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVALID_FILE_STRUCTURE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    sb = null;
	    try {
		if (xsdFile != null) {
		    xsdFile.delete();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	    try {
		if (xmlFile != null) {
		    xmlFile.delete();
		}
	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }
	    try {
		if (pw != null) {
		    pw.flush();
		    pw.close();
		}
	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }
	    try {
		if (br1 != null) {
		    br1.close();
		}
	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }
	    try {
		if (bufReader != null) {
		    bufReader.close();
		}
	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }
	    try {
		if (in != null) {
		    in.close();
		}
	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }
	    try {
		if (reader != null) {
		    reader.close();
		}
	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }

	}
	return xmlFile.getAbsolutePath();

    }

    private void makeFileRecordsInactive(List<String> ipAddList, String siteId, String siteFileId) {
	Map<Map<String, String>, String> activefileMap;
	try {
	    activefileMap = ((SiteDao) hydroDao).getListOfActiveDevices(siteId, siteFileId);
	    Map<String, String> filesToMakeAsInactive = new HashMap<>();
	    Set<String> fileList = new HashSet<>();
	    if (activefileMap.isEmpty()) {
		LOG.info("this site doesn't have any prev. config defined. Hence, no records will be updated");
	    } else if (!activefileMap.isEmpty()) {
		for (Map.Entry<Map<String, String>, String> activeMap : activefileMap.entrySet()) {
		    for (Map.Entry<String, String> fileDetails : activeMap.getKey().entrySet()) {
			for (String ipAdd : ipAddList) {
			    if ((fileDetails.getKey().trim()).equals(ipAdd.trim())) {
				filesToMakeAsInactive.put(fileDetails.getValue(), activeMap.getValue());
				break;
			    }
			}
		    }
		}
	    }
	    // now update the status of all the files which are present in map::
	    // filesToMakeAsInactive
	    // if file_type is lm2 then check if any other device is present for lm2 if yes
	    // then check it's status. If 2 devices details was present in lm2 file and both
	    // are in in-active state then only master file should marked as inactive.
	    // Otherwise the
	    // master file remains active, since for one of the device configuration is
	    // still read
	    // from lm2.
	    if (!filesToMakeAsInactive.isEmpty()) {
//	   		<file-id,file-type>
		for (Map.Entry<String, String> fileMapEntry : filesToMakeAsInactive.entrySet()) {
		    if (Constants.FILE_TYPE.CONFIG_JSON.equals(fileMapEntry.getValue())) {
			fileList.add(fileMapEntry.getKey());
			String fileId = fileMapEntry.getKey();
			String formatedString = fileId.substring(0, fileId.indexOf('_'));
			fileList.add(formatedString);
		    } else if (Constants.FILE_TYPE.LM2.equals(fileMapEntry.getValue())) {
			Set<String> lm2Files = ((SiteDao) hydroDao).getOtherDevicesForSite(fileMapEntry.getKey());
			if (!lm2Files.isEmpty()) {
			    for (String file : lm2Files) {
				if (filesToMakeAsInactive.containsKey(file)) {
				    fileList.add(fileMapEntry.getKey());
				    lm2Files.remove(file);
				}
			    }
			}
			if (lm2Files.isEmpty()) {
			    String fileId = fileMapEntry.getKey();
			    String formatedString = fileId.substring(0, fileId.indexOf('_'));
			    fileList.add(formatedString);
			}
			fileList.add(fileMapEntry.getKey());
		    }
		}

	    }
	    ((SiteDao) hydroDao).updateFileStatusToInactive(fileList);
	} catch (Exception e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

    }

    private HashMap<String, HashMap<String, String>> runLM2Unmarshaller(FileDTO file, String xmlFileStr)
	    throws Exception {
	LOG.info("LM2Unmarshaller start::::::::::::");
	File xsdFile = File.createTempFile("lm2", "xsd");
	File xmlFile = new File(xmlFileStr);
	InputStream in = null;
	FileOutputStream out = null;
	Schema schema = null;
	Unmarshaller unmarshaller = null;
	NewDataSet testData = null;
	XMLStreamReader xsr = null;
	XMLInputFactory xif = null;
	SchemaFactory sf = null;
	JAXBContext context = null;
	InputStream xmlStream = null;
	InputStreamReader reader = null;

	HashMap<String, HashMap<String, String>> eFileList = new HashMap<String, HashMap<String, String>>();
	try {
	    context = JAXBContext.newInstance(NewDataSet.class);
	    ClassLoader classLoader = getClass().getClassLoader();
	    in = (ConfigReader.class.getClassLoader().getResourceAsStream("LM2.xsd"));
	    // File xsdFile = new
	    // File(classLoader.getResource("LM2.XSD").getFile());
	    // File xsdFile = File.createTempFile("lm2", "xsd");
	    // xsdFile.deleteOnExit();

	    try {
		out = new FileOutputStream(xsdFile);
		IOUtils.copy(in, out);
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	    LOG.info("xsdFile::::::::::::" + xsdFile.getAbsolutePath());

	    // File xmlFile = new File(xmlFileStr);
	    // xmlFile.deleteOnExit();
	    LOG.info("xmlFile::::::::::::" + xmlFile.getAbsolutePath());

	    sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
	    schema = sf.newSchema(xsdFile);

	    // Code to prevent XXE attack:
	    xif = XMLInputFactory.newFactory();
	    xif.setProperty(XMLInputFactory.IS_SUPPORTING_EXTERNAL_ENTITIES, false);
	    xif.setProperty(XMLInputFactory.SUPPORT_DTD, false);

	    xmlStream = new FileInputStream(xmlFile);
	    reader = new InputStreamReader(xmlStream, Constants.UTF_8);
	    xsr = xif.createXMLStreamReader(reader);

	    unmarshaller = context.createUnmarshaller();
	    unmarshaller.setSchema(schema);
	    unmarshaller.setEventHandler(new DataValidationEventHandler());

	    LOG.info("unmarshalling start::::::::::::");
	    testData = (NewDataSet) unmarshaller.unmarshal(xsr);
	    LOG.info("unmarshalling end::::::::::::");

	    // ((SiteDao) hydroDao).pushLM2DataToDB1(user, file, testData);
	    // Add file record for each equipment & push LM2 data to DB
	    eFileList = ((SiteDao) hydroDao).pushLM2DataToDB(user, file, testData);
	    // Make other file records inactive
	    // ((SiteDao) hydroDao).updateEquipLM2FileActive(eFileList);

	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVALID_FILE_STRUCTURE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    schema = null;
	    unmarshaller = null;
	    testData = null;
	    xif = null;
	    sf = null;
	    context = null;
	    try {
		if (xsr != null) {
		    xsr.close();
		}
	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }
	    try {
		if (in != null) {
		    in.close();
		}

	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }
	    try {
		if (out != null) {
		    out.close();
		}

	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }

	    try {
		if (xmlStream != null) {
		    xmlStream.close();
		}

	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }

	    try {
		if (reader != null) {
		    reader.close();
		}

	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }

	    try {
		if (xsdFile != null) {
		    String xsdPath = xsdFile.getAbsolutePath();
		    if (xsdFile.delete() == false) {
			File xsd = new File(xsdPath);
			xsd.delete();
		    }
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	    try {
		if (xmlFile != null) {
		    String xmlPath = xmlFile.getAbsolutePath();
		    if (xmlFile.delete() == false) {
			File xml = new File(xmlPath);
			xml.delete();
		    }
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

	return eFileList;

    }

    public FileHistoryListResponseDTO getFileHistory() throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.FILE_HISTORY);
	FileHistoryListResponseDTO fileHistoryList = ((SiteDao) hydroDao).getFileHistoryList(user);
	return fileHistoryList;

    }
}

class DataValidationEventHandler implements ValidationEventHandler {
    @Override
    public boolean handleEvent(ValidationEvent event) {
	/*
	 * System.out.println("\nEVENT"); System.out.println("SEVERITY:  " +
	 * event.getSeverity()); System.out.println("MESSAGE:  " + event.getMessage());
	 * System.out.println("LINKED EXCEPTION:  " + event.getLinkedException());
	 * System.out.println("LOCATOR"); System.out.println("    LINE NUMBER:  " +
	 * event.getLocator().getLineNumber()); System.out.println(
	 * "    COLUMN NUMBER:  " + event.getLocator().getColumnNumber());
	 * System.out.println("    OFFSET:  " + event.getLocator().getOffset());
	 * System.out.println("    OBJECT:  " + event.getLocator().getObject());
	 * System.out.println("    NODE:  " + event.getLocator().getNode());
	 * System.out.println("    URL:  " + event.getLocator().getURL());
	 */
	return true;
    }

}
