package com.hydro.api.service;

import java.net.URI;
import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.SecurityContext;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.jose4j.jwk.HttpsJwks;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;
import org.jose4j.keys.resolvers.HttpsJwksVerificationKeyResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.TokenCache;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.exception.SystemException;
import com.sun.jersey.spi.container.ContainerRequest;
import com.sun.jersey.spi.container.ContainerRequestFilter;

/**
 * 
 * @author Shreyas
 *
 */
public class AuthFilter implements ContainerRequestFilter {
    private static final Logger AUDIT_LOG = LoggerFactory.getLogger(Constants.AUDIT_LOGS);

    private final static WebApplicationException emptyToken = new WebApplicationException(
	    Response.status(Status.UNAUTHORIZED).entity("Authorization token missing").build());
    private final static WebApplicationException Invalid = new WebApplicationException(
	    Response.status(Status.UNAUTHORIZED).entity("Invalid Token").build());
    private final static WebApplicationException emptyAudience = new WebApplicationException(
	    Response.status(Status.UNAUTHORIZED).entity("Audience header missing").build());
    private static final String AUTHENTICATION_SCHEME = "Bearer";
    private static final Logger LOG = LoggerFactory.getLogger(AuthFilter.class);

    private static final ArrayList<String> excludeUrls = new ArrayList<String>(
	    Arrays.asList("/api/util/", "/api/interface/"));

    @Override
    public ContainerRequest filter(ContainerRequest containerRequest) throws WebApplicationException {
	URI uri = containerRequest.getRequestUri();
	LOG.debug("uri.getPath():::" + uri.getPath() + ":"
		+ excludeUrls.parallelStream().anyMatch(uri.getPath()::contains));

	if (uri.getPath().contains("healthProbe")) {
	    return containerRequest;
	}

	String auth = containerRequest.getHeaderValue("authorization");
	String audience = containerRequest.getHeaderValue("aud");
	String authType = containerRequest.getHeaderValue("authType");
	if (StringUtils.isEmpty(auth)) {
	    throw emptyToken;
	}
	if (StringUtils.isEmpty(audience)) {
	    throw emptyAudience;
	}
	if (StringUtils.isEmpty(authType)) {
	    authType = "HEAD";
	}

	if (excludeUrls.parallelStream().anyMatch(uri.getPath()::contains)) {
	    authType = "HEADLESS";
	} else {
	    authType = "HEAD";
	}

	LOG.debug("AuthType:: " + authType);
	try {
	    ConfigReader configReader = ConfigReader.getObject();
	    TokenCache tokenCache = configReader.getTokenCache();
	    Map<String, Object> claims = decodeToken(auth, audience, authType);
	    LOG.debug("Claims:::" + claims);
	    Object uniqueName = claims.get("oid");
	    if (uniqueName == null) {
		throw Invalid;
	    }

	    if (!authType.equalsIgnoreCase("HEADLESS")
		    && !excludeUrls.parallelStream().anyMatch(uri.getPath()::contains)) {
		final SecurityContext currentSecurityContext = containerRequest.getSecurityContext();
		containerRequest.setSecurityContext(new SecurityContext() {

		    @Override
		    public Principal getUserPrincipal() {
			return () -> uniqueName.toString();
		    }

		    @Override
		    public boolean isUserInRole(String role) {
			return true;
		    }

		    @Override
		    public boolean isSecure() {
			return currentSecurityContext.isSecure();
		    }

		    @Override
		    public String getAuthenticationScheme() {
			return AUTHENTICATION_SCHEME;
		    }

		});
		String userId = uniqueName.toString();
		// If the token is invalid, then all the APIs return with
		// Invalid
		// token.
		if (!tokenCache.isValidToken(userId, auth)) {
		    throw Invalid;
		}
		if (containerRequest.getRequestUri().getPath().equalsIgnoreCase(Constants.LOGOUT_URI)) {
		    tokenCache.addTokenToCache(auth, userId, (long) claims.get(Constants.EXP));
		    AUDIT_LOG.info("User : " + uniqueName.toString() + " Logged out.");
		}
		if (containerRequest.getRequestUri().getPath().equalsIgnoreCase(Constants.LOGIN_URI)) {
		    AUDIT_LOG.info("User : " + uniqueName.toString() + " Logged in.");
		}
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw Invalid;
	}

	return containerRequest;

    }

    /* The exception thrown if a user is unauthorized. */

    private Map<String, Object> decodeToken(String jwt, String azureAudience, String authType) throws Exception {
	// TODO Auto-generated method stub
	ConfigReader configReader = ConfigReader.getObject();
	String azureCertificateUrl = configReader.getAppConfig(Constants.AZURE_AD_CERTIFICATE_URL);
	String azureTokenUrl = configReader.getAppConfig(Constants.AZURE_AD_TOKEN_URL);
	if (authType.equalsIgnoreCase("HEADLESS")) {
	    azureCertificateUrl = configReader.getAppConfig(Constants.AZURE_AD_HEADLESS_CERTIFICATE_URL);
	    azureTokenUrl = configReader.getAppConfig(Constants.AZURE_AD_HEADLESS_TOKEN_URL);
	}
	// String azureAudience =
	// configReader.getAppConfig(Constants.AZURE_AD_AUDIENCE);
	if (StringUtils.isEmpty(azureCertificateUrl) || StringUtils.isEmpty(azureTokenUrl)
		|| StringUtils.isEmpty(azureAudience)) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
	HttpsJwks httpsJkws = new HttpsJwks(azureTokenUrl);
	HttpsJwksVerificationKeyResolver httpsJwksKeyResolver = new HttpsJwksVerificationKeyResolver(httpsJkws);
	JwtConsumer jwtConsumer = new JwtConsumerBuilder().setRequireExpirationTime() // the
										      // JWT
										      // must
										      // have
										      // an
										      // expiration
										      // time
		.setAllowedClockSkewInSeconds(3600) // allow some leeway in
						    // validating time based
						    // claims to account for
						    // clock skew
		.setRequireSubject() // the JWT must have a subject claim
		.setExpectedIssuer(azureCertificateUrl) // whom
							// the
							// JWT
							// needs
							// to
							// have
							// been
							// issued
							// by
		.setExpectedAudience(azureAudience) // to
						    // whom
						    // the
						    // JWT
						    // is
						    // intended
						    // for
		.setVerificationKeyResolver(httpsJwksKeyResolver).build();

	try {
	    // Validate the JWT and process it to the Claims
	    JwtClaims jwtClaims = jwtConsumer.processToClaims(jwt);
	    return jwtClaims.getClaimsMap();
	} catch (InvalidJwtException e) {
	    // InvalidJwtException will be thrown, if the JWT failed processing
	    // or validation in anyway.
	    // Hopefully with meaningful explanations(s) about what went wrong.

	    LOG.error("Invalid JWT! " + e);
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
    }

}
