package com.hydro.api.service;

import java.security.Principal;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.EquipmentListDTO;
import com.hydro.api.dto.ShiftListResponseDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.SiteListResponseDTO;
import com.hydro.api.dto.StatusDTO;
import com.hydro.api.exception.ExceptionHandler;
import com.hydro.api.exception.SystemException;
import com.hydro.api.service.helper.ServiceHelper;
import com.hydro.api.site.business.HydroSiteBL;

/**
 * Base Service : Entry Point to the JSON APIs.
 * 
 * @author Shreyas
 *
 */
// No Base context root for the Services. Each services have their respective
// Endpoints.
@Path("/site")
@Produces({ MediaType.APPLICATION_JSON })
public class HydroSiteService extends HydroBaseService {
    private static final Logger LOG = LoggerFactory.getLogger(HydroSiteService.class);
    @Context
    SecurityContext securityContext;

    public HydroSiteService(@Context SecurityContext securityContext,
	    @HeaderParam(Constants.TIME_ZONE_HEADER) String timeZone) throws Exception {
	super();
	Principal principal = securityContext.getUserPrincipal();
	String username = principal.getName();
	BL = new HydroSiteBL(username, timeZone);
    }

    /**
     * Test API.
     * 
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/test")
    public String test() {
	long start = System.currentTimeMillis();
	resStr = "{\"messgae\":\"Site APIs Works Fine!\"}";
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * Testing the DB connection.
     * 
     * @return
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/testDbConnection")
    public String testDbConnection() {
	long start = System.currentTimeMillis();

	try {
	    BL.initRoutine();
	    // Check for the Database connection.
	    boolean flag = ((HydroSiteBL) BL).testSiteDbConnection();
	    if (flag) {
		resStr = "{ \"connected\":true}";
	    } else {
		resStr = "{ \"connected\":false}";
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * Get List of Sites.
     * 
     * @return site list
     * @throws Exception
     */
    @GET
    @Path("/getSiteList")
    @Produces(MediaType.APPLICATION_JSON)

    public String getSiteList(@QueryParam("createdStartDate") String createdStartDate,
	    @QueryParam("createdEndDate") String createdEndDate, @QueryParam("isHydroUser") boolean isHydroUser,
	    @QueryParam("sortByName") boolean sortByName) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    SiteDTO site = new SiteDTO(sortByName, isHydroUser, createdEndDate, createdStartDate);
	    SiteListResponseDTO aResponse = ((HydroSiteBL) BL).getSiteList(site);
	    responseDTO.setResponseObject(aResponse);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * Create new site, acquired by an account.
     * 
     * @param body
     * @return
     * @throws Exception
     */

    @POST
    @Path("/createSite")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String createSite(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    SiteDTO siteDTO = (SiteDTO) ServiceHelper.buildJsonString(body, SiteDTO.class);
	    siteDTO = ((HydroSiteBL) BL).createSite(siteDTO);
	    responseDTO.setResponseObject(siteDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * Update Site Details.
     * 
     * @param body
     * @return
     * @throws Exception
     */

    @PUT
    @Path("/updateSite")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String updateSite(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    SiteDTO siteDTO = (SiteDTO) ServiceHelper.buildJsonString(body, SiteDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroSiteBL) BL).updateSite(siteDTO));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * API to check if site exist.
     * 
     * @param body
     * @return
     * @throws Exception
     */

    @POST
    @Path("/siteNameExist")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String siteNameExist(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    SiteDTO siteDTO = (SiteDTO) ServiceHelper.buildJsonString(body, SiteDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroSiteBL) BL).siteNameExists(siteDTO));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/getSiteDetails")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getSiteDetails(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    SiteDTO site = (SiteDTO) ServiceHelper.buildJsonString(body, SiteDTO.class);
	    site = ((HydroSiteBL) BL).getSiteDetails(site);
	    responseDTO.setResponseObject(site);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/getEquipmentList")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getEquipmentList(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    SiteDTO site = (SiteDTO) ServiceHelper.buildJsonString(body, SiteDTO.class);
	    EquipmentListDTO response = (EquipmentListDTO) ((HydroSiteBL) BL).getEquipmentList(site);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(response);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/getSiteForCompany")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getSiteForCompany(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    SiteDTO site = (SiteDTO) ServiceHelper.buildJsonString(body, SiteDTO.class);
	    SiteListResponseDTO response = ((HydroSiteBL) BL).getSiteListForCompany(site);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(response);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/getShiftDetailsForSite")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getShiftDetailsForSite(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    SiteDTO site = (SiteDTO) ServiceHelper.buildJsonString(body, SiteDTO.class);
	    ShiftListResponseDTO response = ((HydroSiteBL) BL).getShiftDetailsForSite(site);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(response);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

}
