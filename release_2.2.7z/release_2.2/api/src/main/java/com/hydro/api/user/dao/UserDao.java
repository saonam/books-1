package com.hydro.api.user.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.base.dao.HydroDao;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.AlertDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.dto.UserListResponseDTO;
import com.hydro.api.dto.UserPreferenceResponseDTO;
import com.hydro.api.exception.SystemException;

/**
 *
 * @author Shreyas
 * 
 */
public abstract class UserDao extends HydroDao {
    protected static final Logger LOG = LoggerFactory.getLogger(UserDao.class);

    public boolean testUserDbConnection() {
	Database database = null;
	try {
	    database = new Database();

	    if (database.connection != null) {
		return true;
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    e.printStackTrace();
	    return false;
	} finally {
	    if (database != null) {
		try {
		    database.closeConnection();
		} catch (SQLException e) {
		    LOG.error("Error : " + e.getMessage());
		    e.printStackTrace();
		}
	    }
	}
	return false;
    }

    public abstract UserListResponseDTO getAllUserList(UserDTO userDTO, UserDTO targetUser) throws Exception;

    public abstract List<AlertDTO> getUserSpecificPreference(UserDTO user) throws Exception;

    public String companyIdExists(String companyId) throws Exception {

	Database database = null;
	try {
	    String query = SQLConstants.BUSINESS_ID_EXISTS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();

	    params.add(Constants.BusinessTypes.COMPANY);
	    params.add(companyId);
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.BUSINESS_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }

    public UserDTO createUser(UserDTO user, UserDTO userDTO, boolean fullPrivilege) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.CREATE_USER;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(userDTO.getUserId());
	    params.add(userDTO.getFirstName());
	    params.add(userDTO.getMiddleName());
	    params.add(userDTO.getLastName());
	    params.add(userDTO.getUserName());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(userDTO.getAddress1());
	    params.add(userDTO.getAddress2());
	    params.add(userDTO.getCity());
	    params.add(userDTO.getState());
	    params.add(userDTO.getCountry());
	    params.add(userDTO.getZipCode());
	    params.add(userDTO.getAssociationId());
	    params.add(userDTO.getOrgType().toUpperCase());
	    params.add(userDTO.getUserRole().toUpperCase());
	    params.add(userDTO.getPhoneNumber());
	    params.add(userDTO.getEmail());
	    params.add(userDTO.getRoleId());
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    if (count > 0) {
		UserDTO userResponse = new UserDTO();
		userResponse.setUserId(userDTO.getUserId());
		if (!fullPrivilege) {
		    query = SQLConstants.Company.partial.ASSOCIATE_SITE_TO_USER;
		    database.createBatch(query);
		    List<SiteDTO> siteList = userDTO.getSiteList();
		    if (siteList != null && siteList.size() > 0) {
			for (SiteDTO siteDTO : siteList) {
			    params = new LinkedList<>();
			    params.add(userDTO.getUserId());
			    params.add(siteDTO.getSiteId());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    database.addBatch(query, params);
			}
			int[] result = database.executeBatch();
			if (result != null && result.length > 0) {
			    for (int i = 0; i < result.length; i++) {
				if (result[i] != 1) {
				    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					    null);
				}
			    }
			}
		    }
		}
		database.commit();
		return userResponse;
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public boolean updateUser(UserDTO user, UserDTO userDTO, boolean fullPrivilege) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.UPDATE_USER;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(userDTO.getFirstName());
	    params.add(userDTO.getMiddleName());
	    params.add(userDTO.getLastName());
	    params.add(userDTO.getAddress1());
	    params.add(userDTO.getAddress2());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(userDTO.getState());
	    params.add(userDTO.getCountry());
	    params.add(userDTO.getCity());
	    params.add(userDTO.getZipCode());
	    params.add(userDTO.getAssociationId());
	    params.add(userDTO.getOrgType().toUpperCase());
	    params.add(userDTO.getUserRole().toUpperCase());
	    params.add(userDTO.getPhoneNumber());
	    params.add(userDTO.getRoleId());
	    params.add(userDTO.getUserId());
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    if (count > 0) {
		if (!fullPrivilege) {
		    query = SQLConstants.Company.partial.DELETE_SITE_ASSOCIATED_TO_USER;
		    params = new LinkedList<>();
		    params.add(userDTO.getUserId());
		    database.executeUpdate(query, params);
		    // Inserting the data to DB
		    query = SQLConstants.Company.partial.ASSOCIATE_SITE_TO_USER;
		    database.createBatch(query);
		    List<SiteDTO> siteList = userDTO.getSiteList();
		    if (siteList != null && siteList.size() > 0) {
			for (SiteDTO siteDTO : siteList) {
			    params = new LinkedList<>();
			    params.add(userDTO.getUserId());
			    params.add(siteDTO.getSiteId());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    database.addBatch(query, params);

			}
			int[] result = database.executeBatch();
			if (result != null && result.length > 0) {
			    for (int i = 0; i < result.length; i++) {
				if (result[i] != 1) {
				    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					    null);
				}
			    }
			}
		    }
		}
		database.commit();
		return true;
	    }
	    database.rollBack();
	    return false;
	} catch (Exception e) {
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public abstract boolean deActivateUser(UserDTO user, UserDTO usertDTO) throws Exception;

    public abstract boolean activateUser(UserDTO user, UserDTO usertDTO) throws Exception;

    public String emailExists(UserDTO userDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.EMAIL_EXISTS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(userDTO.getEmail().toLowerCase());
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.USER_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }

    public String userNameExists(UserDTO userDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.USER_NAME_EXISTS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(userDTO.getUserName().toLowerCase());
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.USER_NAME);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }

    public boolean checkSiteVisibility(UserDTO user, SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.full.GET_SITE_ASSOCIATED_TO_COMPANY;
	    // SELECT site_id from SITE_MASTER where site_id in (select site_id
	    // from SITE_BUSINESS_ASSOCIATION where business_id =? and site_id
	    // =?)
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(user.getAssociationId());
	    params.add(site.getSiteId());
	    ResultSet rSet = database.executeQuery(query, params);
	    if (rSet.next()) {
		return true;
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public List<SiteDTO> getSiteListForUser(UserDTO user) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.partial.GET_SITE_FOR_COMPANY;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(user.getAssociationId());
	    params.add(user.getUserId());
	    return getSiteDataForCompany(database.executeQuery(query, params));
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static List<AlertDTO> getUserSpecificPreferenceData(ResultSet rs, String companyId)
	    throws SystemException, Exception {
	try {
	    List<AlertDTO> alertList = new LinkedList<>();
	    while (rs.next()) {
		AlertDTO alert = new AlertDTO();
		alert.setAlarmId(rs.getInt(SQLColumns.ALARM_ID));
		alert.setAlarmName(rs.getString(SQLColumns.ALARM_NAME));
		alert.setAlarmType(rs.getString(SQLColumns.ALARM_TYPE));
		alert.setAlarmDescription(rs.getString(SQLColumns.DESCRIPTION));
		alert.setActive(rs.getBoolean(SQLColumns.ACTIVE));
		alertList.add(alert);
	    }
	    alertList.sort(Comparator.comparing(AlertDTO::getAlarmId));
	    return alertList;
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
    }

    public boolean checkUserPreferenceExist(UserDTO user) throws SystemException, Exception {
	Database database = null;
	try {
	    String query = SQLConstants.CHECK_USER_PREFERENCE_EXIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(user.getUserId());
	    ResultSet rSet = database.executeQuery(query, params);
	    if (rSet.next()) {
		return true;
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public boolean createUserPreferenceDetails(UserDTO user, UserPreferenceResponseDTO targetUser)
	    throws SystemException, Exception {
	Database database = null;
	// INSERT into user_alarm_preference(id, user_id, alarm_id, active,
	// created_by, created_date, modified_by, modified_date)
	// VALUES(?,?,?,?,?,utc_timestamp,?,utc_timestamp)
	try {
	    String query = SQLConstants.INSERT_INTO_USER_ALARM_PREFERENCE;
	    database = new Database();
	    database.createBatch(query);
	    LinkedList<Object> params = new LinkedList<>();
	    List<AlertDTO> alertList = targetUser.getAlertList();
	    if (user != null && alertList.size() > 0) {
		for (AlertDTO alert : alertList) {
		    params = new LinkedList<>();
		    String guid = CommonUtils.guidGenerator(null, null);
		    params.add(guid);
		    params.add(user.getUserId());
		    params.add(alert.getAlarmId());
		    params.add(alert.isActive());
		    params.add(user.getFirstName() + " " + user.getLastName());
		    params.add(user.getFirstName() + " " + user.getLastName());
		    database.addBatch(query, params);
		}
		int[] result = database.executeBatch();
		if (result != null && result.length > 0) {
		    for (int i = 0; i < result.length; i++) {
			if (result[i] != 1) {
			    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
			}
		    }
		}
	    }
	    database.commit();
	    return true;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public boolean updateUserPreferenceDetails(UserDTO user, UserPreferenceResponseDTO targetUser)
	    throws SystemException, Exception {
	Database database = null;
	try {
	    String query = SQLConstants.DELETE_USER_PREFERENCE;
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(targetUser.getUserId());
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    // INSERT into user_alarm_preference(id, user_id, alarm_id, active,
	    // created_by, created_date, modified_by, modified_date)
	    // VALUES(?,?,?,?,?,utc_timestamp,?,utc_timestamp)
	    List<AlertDTO> alertList = targetUser.getAlertList();
	    if (count >= 0 && alertList != null && alertList.size() >= 0) {
		query = SQLConstants.INSERT_INTO_USER_ALARM_PREFERENCE;

		database.createBatch(query);
		params = new LinkedList<>();
		if (user != null && alertList.size() > 0) {
		    for (AlertDTO alert : alertList) {
			params = new LinkedList<>();
			String guid = CommonUtils.guidGenerator(null, null);
			params.add(guid);
			params.add(user.getUserId());
			params.add(alert.getAlarmId());
			params.add(alert.isActive());
			params.add(user.getFirstName() + " " + user.getLastName());
			params.add(user.getFirstName() + " " + user.getLastName());
			database.addBatch(query, params);
		    }
		    int[] result = database.executeBatch();
		    if (result != null && result.length > 0) {
			for (int i = 0; i < result.length; i++) {
			    if (result[i] != 1) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }
			}
		    }
		}
	    }
	    database.commit();
	    return true;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

    }

    public LinkedList<Object> getUserListOnStartEndDate(UserDTO user) {
	String createdStartDate = user.getCreatedDateStart();
	String createdEndDate = user.getCreatedDateEnd();
	LinkedList<Object> params = new LinkedList<>();
	if (createdStartDate != null && createdEndDate != null) {
	    params.add(createdStartDate);
	    params.add(createdEndDate);
	}
	return params;
    }

}