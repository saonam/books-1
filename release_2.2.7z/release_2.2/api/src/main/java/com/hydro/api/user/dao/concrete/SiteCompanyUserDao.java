package com.hydro.api.user.dao.concrete;

import java.sql.SQLException;
import java.util.LinkedList;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.dto.UserListResponseDTO;
import com.hydro.api.exception.SystemException;

public class SiteCompanyUserDao extends CompanyUserDao {
    protected static final Logger LOG = LoggerFactory.getLogger(PartialCompanyUserDao.class);

    @Override
    public UserListResponseDTO getAllUserList(UserDTO userDTO, UserDTO targetUser) throws SystemException, Exception {

	Database database = null;
	try {
	    String query = SQLConstants.Company.partial.GET_USER_LIST;
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(userDTO.getUserId());
	    params.add(userDTO.getUserId());
	    params.add(userDTO.getAssociationId());
	    params.add(userDTO.getClearanceLevel());
	    if (targetUser.getCreatedDateStart() != null && targetUser.getCreatedDateEnd() != null) {
		query = SQLConstants.Company.partial.GET_USER_LIST_CREATED_DATE_FILTER;
		params.addAll(getUserListOnStartEndDate(targetUser));
	    }
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    return getUserListFromRs(database.executeQuery(query, params), userDTO.getTimeZone());
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    }

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean deActivateUser(UserDTO user, UserDTO userDTO) throws Exception {
	if (!user.getAssociationId().equals(userDTO.getAssociationId())) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.TOGGLE_ACTIVATE_USER;
	    LOG.debug("query>>>>" + query);
	    // UPDATE USER_MASTER SET is_active=?, modified_by=? WHERE user_id=?
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.ACTIVE_STATE.INACTIVE);
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(userDTO.getUserId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }
	    database.closeConnection();
	    return true;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean activateUser(UserDTO user, UserDTO userDTO) throws Exception {
	if (!user.getAssociationId().equals(userDTO.getAssociationId())) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}

	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.TOGGLE_ACTIVATE_USER;
	    LOG.debug("query>>>>" + query);
	    // UPDATE USER_MASTER SET is_active=?, modified_by=? WHERE user_id=?
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.ACTIVE_STATE.ACTIVE);
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(userDTO.getUserId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }
	    database.closeConnection();
	    return true;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }
}
