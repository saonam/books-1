package com.hydro.api.account.business;

import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.account.dao.AccountDao;
import com.hydro.api.account.dao.concrete.CompanyAccountDao;
import com.hydro.api.account.dao.concrete.HydroAccountDao;
import com.hydro.api.account.dao.concrete.PartialCompanyAccountDao;
import com.hydro.api.account.dao.concrete.PartialHydroAccountDao;
import com.hydro.api.account.dao.concrete.SiteCompanyAccountDao;
import com.hydro.api.base.business.HydroBL;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.AccountDTO;
import com.hydro.api.dto.AccountListResponseDTO;
import com.hydro.api.exception.SystemException;

/**
 * Business layer for the Application.
 * 
 * @author Shreyas
 *
 */
public class HydroAccountBL extends HydroBL {
    private static final Logger LOG = LoggerFactory.getLogger(HydroAccountBL.class);

    public HydroAccountBL(String userId, String timeZone) throws SystemException, Exception {
	super(userId, timeZone);
	LOG.debug("In Hydro Account BL.");
	String orgType = user.getOrgType();
	switch (orgType) {
	case Constants.HYDRO:
		// Giving full permission for Hydro technician but restricting create/update company,account,site using role_privilege_association
		 hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new HydroAccountDao()
				    : new PartialHydroAccountDao();
	    break;
	case Constants.COMPANY:
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new CompanyAccountDao()
		    : new PartialCompanyAccountDao();
	    break;
	case Constants.SITE:
	    hydroDao = (permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE)) ? new CompanyAccountDao()
		    : new SiteCompanyAccountDao();
	    break;
	default:
	    LOG.debug("Unknown Orgnization");
	}
    }

    public boolean testAccountDbConnection() {
	return ((AccountDao) hydroDao).testAccountDbConnection();
    }

    public AccountListResponseDTO getAccountList(AccountDTO account) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.ACCOUNT_LIST);
	AccountListResponseDTO accountList = ((AccountDao) hydroDao).getAccountList(user, account);
	return accountList;
    }

    /**
     * Get Account Details
     * 
     * @param accountDTO
     * @return
     * @throws Exception
     */
    public AccountDTO getAccountDetails(AccountDTO accountDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.ACCOUNT_VIEW);
	if (!((AccountDao) hydroDao).hasVisibility(user, accountDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	AccountDTO account = ((AccountDao) hydroDao).getAccountDetails(accountDTO);
	account.setSiteList(((AccountDao) hydroDao).getSiteListForAccount(user, accountDTO));
	account.setContactList(((AccountDao) hydroDao).getContactListForAccount(accountDTO));
	return account;
    }

    public AccountDTO createAccount(AccountDTO accountDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.ACCOUNT_CREATE);
	// Validation On Insufficient Information.
	List<Object> params = getInsufficientParamsListCreate(accountDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	if (accountNameExists(accountDTO)) {
	    throw new SystemException(ErrorCodes.NAME_EXISTS, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	return ((AccountDao) hydroDao).createAccount(user, accountDTO);
    }

    public boolean updateAccount(AccountDTO accountDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.ACCOUNT_UPDATE);
	// Validation
	List<Object> params = getInsufficientParamsListUpdate(accountDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	String acctExitingId = getExistingAccountNameId(accountDTO);
	if (StringUtils.isEmpty(acctExitingId) || accountDTO.getAccountId().equals(acctExitingId)) {
	    return ((AccountDao) hydroDao).updateAccount(user, accountDTO);
	} else {
	    throw new SystemException(ErrorCodes.NAME_EXISTS, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}

    }

    public String getExistingAccountNameId(AccountDTO accountDTO) throws Exception {
	if (StringUtils.isEmpty(accountDTO.getName())) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	return ((AccountDao) hydroDao).accountNameExists(accountDTO);
    }

    public boolean accountNameExists(AccountDTO accountDTO) throws Exception {
	if (StringUtils.isEmpty(getExistingAccountNameId(accountDTO))) {
	    return false;
	}
	return true;
    }

    protected List<Object> getInsufficientParamsListCreate(AccountDTO accountDTO) {
	List<Object> params = new LinkedList<>();
	if (accountDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.ACCOUNT_OBJECT);

	}
	if (StringUtils.isEmpty(accountDTO.getName())) {
	    params.add(ErrorCodes.InsufficientParams.ACCOUNT_NAME);
	}
	if (StringUtils.isEmpty(accountDTO.getAddress1())) {
	    params.add(ErrorCodes.InsufficientParams.ADDRESS1);
	}
	if (StringUtils.isEmpty(accountDTO.getState())) {
	    params.add(ErrorCodes.InsufficientParams.STATE);
	}
	if (StringUtils.isEmpty(accountDTO.getCountry())) {
	    params.add(ErrorCodes.InsufficientParams.COUNTRY);
	}
	if (StringUtils.isEmpty(accountDTO.getCity())) {
	    params.add(ErrorCodes.InsufficientParams.CITY);
	}
	if (StringUtils.isEmpty(accountDTO.getZipCode())) {
	    params.add(ErrorCodes.InsufficientParams.ZIPCODE);
	}
	return params;
    }

    protected List<Object> getInsufficientParamsListUpdate(AccountDTO accountDTO) {
	List<Object> params = new LinkedList<>();
	if (accountDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.ACCOUNT_OBJECT);

	}
	if (StringUtils.isEmpty(accountDTO.getAccountId())) {
	    params.add(ErrorCodes.InsufficientParams.ACCOUNT_ID);
	}
	if (StringUtils.isEmpty(accountDTO.getName())) {
	    params.add(ErrorCodes.InsufficientParams.ACCOUNT_NAME);
	}
	if (StringUtils.isEmpty(accountDTO.getAddress1())) {
	    params.add(ErrorCodes.InsufficientParams.ADDRESS1);
	}
	if (StringUtils.isEmpty(accountDTO.getState())) {
	    params.add(ErrorCodes.InsufficientParams.STATE);
	}
	if (StringUtils.isEmpty(accountDTO.getCountry())) {
	    params.add(ErrorCodes.InsufficientParams.COUNTRY);
	}
	if (StringUtils.isEmpty(accountDTO.getCity())) {
	    params.add(ErrorCodes.InsufficientParams.CITY);
	}
	if (StringUtils.isEmpty(accountDTO.getZipCode())) {
	    params.add(ErrorCodes.InsufficientParams.ZIPCODE);
	}
	return params;
    }

}
