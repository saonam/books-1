package com.hydro.api.site.dao;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.client.ResourceAccessException;

import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.EquipmentWrapperDTO;
import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.base.dao.Database;
import com.hydro.api.base.dao.HydroDao;
import com.hydro.api.company.dao.CompanyDao;
import com.hydro.api.config.ChannelDTO;
import com.hydro.api.config.FormulaConfig;
import com.hydro.api.config.FormulaDTO;
import com.hydro.api.config.FormulaPhaseDTO;
import com.hydro.api.config.FormulaProductDTO;
import com.hydro.api.config.MachineDTO;
import com.hydro.api.config.MasterConfigDTO;
import com.hydro.api.config.ProductConfigDTO;
import com.hydro.api.config.UnitDTO;
import com.hydro.api.config.WaterDTO;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.CompanyDTO;
import com.hydro.api.dto.ContactDTO;
import com.hydro.api.dto.ContactOperationsDTO;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.EsErrorLogDTO;
import com.hydro.api.dto.FileDTO;
import com.hydro.api.dto.FileHistoryDTO;
import com.hydro.api.dto.FileHistoryListResponseDTO;
import com.hydro.api.dto.FormulaMetaDataDTO;
import com.hydro.api.dto.ObservationDTO;
import com.hydro.api.dto.ObservationListResponseDTO;
import com.hydro.api.dto.ProductDTO;
import com.hydro.api.dto.ShiftDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.SiteListResponseDTO;
import com.hydro.api.dto.TunnelDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.dto.WasherMetaDataDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.lm2elements.NewDataSet;
import com.hydro.api.lm2elements.NewDataSet.TablaEquipos;
import com.hydro.api.lm2elements.NewDataSet.TablaFormulas;
import com.hydro.api.lm2elements.NewDataSet.TablaTuneles;

/**
 *
 * @author Shreyas, Srishti
 * 
 */
public abstract class SiteDao extends HydroDao {
    private static final Logger LOG = LoggerFactory.getLogger(SiteDao.class);

    public abstract SiteListResponseDTO getSiteList(UserDTO user, SiteDTO site) throws Exception;

    public abstract SiteDTO createSite(UserDTO user, SiteDTO siteDTO) throws Exception;

    public abstract boolean hasVisibility(UserDTO user, SiteDTO site) throws Exception;

    public abstract String siteNameExists(SiteDTO siteDTO) throws Exception;

    public abstract List<ContactDTO> getContactListForSite(UserDTO user, SiteDTO site) throws Exception;

    public abstract FileHistoryListResponseDTO getFileHistoryList(UserDTO user) throws Exception;

    public abstract boolean updateObservation(UserDTO user, ObservationDTO observationDTO) throws Exception;

    public abstract boolean deleteObservation(UserDTO user, ObservationDTO observationDTO) throws Exception;

    public abstract ObservationListResponseDTO getObservationList(UserDTO userDTO, ObservationDTO observationDTO)
	    throws Exception;

    public abstract SiteListResponseDTO getSiteListForCompany(SiteDTO site, UserDTO user) throws Exception;

    /**
     * Method to test DB connection for site.
     * 
     * @return
     */
    public boolean testSiteDbConnection() {
	Database database = null;
	try {
	    database = new Database();

	    if (database.connection != null) {
		return true;
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    e.printStackTrace();
	    return false;
	} finally {
	    if (database != null) {
		try {
		    database.closeConnection();
		} catch (SQLException e) {
		    LOG.error("Error : " + e.getMessage());
		    e.printStackTrace();
		}
	    }
	}
	return false;
    }

    /**
     * Method to fetch site list data, for executed SQL query.
     * 
     * @param ResultSet
     * @return
     * @throws Exception
     */

    protected List<SiteDTO> getSiteListData(ResultSet rs, String timeZone) throws Exception {
	List<SiteDTO> siteList = new LinkedList<>();
	while (rs.next()) {
	    SiteDTO site = new SiteDTO();
	    site.setSiteId(rs.getString(SQLColumns.SITE_ID));
	    site.setCreatedDate(CommonUtils.convertDate(rs.getString(SQLColumns.CREATED_DATE), timeZone));
	    site.setSiteName(rs.getString(SQLColumns.SITE_NAME));
	    site.setCountry(rs.getString(SQLColumns.COUNTRY));
	    site.setCity(rs.getString(SQLColumns.CITY));
	    site.setState(rs.getString(SQLColumns.STATE));
	    site.setZipCode(rs.getString(SQLColumns.ZIPCODE));
	    site.setCreatedBy(rs.getString(SQLColumns.CREATED_BY));
	    site.setAlertSetting(rs.getString(SQLColumns.ALERT_SETTING));
	    site.setAccountId(rs.getString(SQLColumns.BUSINESS_ID));
	    site.setAccountName(rs.getString(SQLColumns.ACCOUNT_NAME));
	    site.setCompanyName(rs.getString(SQLColumns.COMPANY_NAME));
	    site.setCompanyId(rs.getString(SQLColumns.COMPANY_ID));
	    site.setDescription(rs.getString(SQLColumns.DESCRIPTION));
	    site.setAddress1(rs.getString(SQLColumns.ADDRESS1));
	    site.setAddress2(rs.getString(SQLColumns.ADDRESS2));
	    site.setMetricUnit(rs.getString(SQLColumns.METRIC_UNIT));
	    site.setStreamingEnabled(rs.getBoolean(SQLColumns.STREAMING_ENABLED));
	    siteList.add(site);
	}
	return siteList;
    }

    /**
     * Method to check if account ID exist.
     * 
     * @param accountId
     * @return
     */
    public String accountIdExists(String accountId) throws Exception {

	Database database = null;
	try {
	    String query = SQLConstants.BUSINESS_ID_EXISTS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();

	    params.add(Constants.BusinessTypes.ACCOUNT);
	    params.add(accountId);
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.BUSINESS_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }

    public String equipmentIdExists(ObservationDTO observationDTO) throws Exception {

	Database database = null;
	try {
	    String query = SQLConstants.EQUIPMENT_ID_EXISTS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    // select equipment_id from EQUIPMENT_MASTER where equipment_id=?
	    // and site_id=?
	    params.add(observationDTO.getEquipmentId());
	    params.add(observationDTO.getSiteId());
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.EQUIPMENT_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }

    /**
     * Method to fetch site details
     * 
     * @param site
     * @return
     * @throws Exception
     */
    public SiteDTO getSiteDetails(SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_SITE_DETAILS;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(site.getSiteId());
	    // SELECT site_id, site_name, description, address1, address2, city,
	    // state, zipcode, country from SITE_MASTER where site_id = ?
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		SiteDTO siteDTO = new SiteDTO();
		siteDTO.setSiteId(rs.getString(SQLColumns.SITE_ID));
		siteDTO.setCompanyName(rs.getString(SQLColumns.NAME));
		siteDTO.setSiteName(rs.getString(SQLColumns.SITE_NAME));
		siteDTO.setDescription(rs.getString(SQLColumns.DESCRIPTION));
		siteDTO.setAddress1(rs.getString(SQLColumns.ADDRESS1));
		siteDTO.setAddress2(rs.getString(SQLColumns.ADDRESS2));
		siteDTO.setCity(rs.getString(SQLColumns.CITY));
		siteDTO.setState(rs.getString(SQLColumns.STATE));
		siteDTO.setZipCode(rs.getString(SQLColumns.ZIPCODE));
		siteDTO.setCountry(rs.getString(SQLColumns.COUNTRY));
		siteDTO.setAccountId(rs.getString(SQLColumns.SITE_OWNER));
		siteDTO.setMetricUnit(rs.getString(SQLColumns.METRIC_UNIT));
		siteDTO.setCompanyId(rs.getString(SQLColumns.BUSINESS_ID));
		siteDTO.setWasherTurnMinute(rs.getInt(SQLColumns.WASHER_TURN_MINUTE));
		siteDTO.setWasherIdleMinute(rs.getInt(SQLColumns.WASHER_IDLE_MINUTE));
		siteDTO.setWasherEffThreshold(rs.getDouble(SQLColumns.WASHER_EFFICIENCY_THRESHOLD));
		siteDTO.setTunnelTurnMinute(rs.getInt(SQLColumns.TUNNEL_TURN_MINUTE));
		siteDTO.setTunnelIdleMinute(rs.getInt(SQLColumns.TUNNEL_IDLE_MINUTE));
		siteDTO.setTunnelEffThreshold(rs.getDouble(SQLColumns.TUNNEL_EFFICIENCY_THRESHOLD));
		siteDTO.setTimeZone(rs.getString(SQLColumns.TIME_ZONE));
		siteDTO.setAlertSetting(rs.getString(SQLColumns.ALERT_SETTING));
		siteDTO.setStreamingEnabled(rs.getBoolean(SQLColumns.STREAMING_ENABLED));
		return siteDTO;
	    } else {
		throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {

	    }
	}
    }

    protected List<ContactDTO> getSiteContactData(ResultSet rs) throws SQLException {
	List<ContactDTO> contactList = new LinkedList<>();
	while (rs.next()) {
	    ContactDTO contact = new ContactDTO();
	    // SELECT contact_email, contact_name, contact_number, contact_title
	    // from CONTACT_MASTER where business_id = ?
	    contact.setContactId(rs.getString(SQLColumns.CONTACT_ID));
	    contact.setEmail(rs.getString(SQLColumns.CONTACT_EMAIL));
	    contact.setName(rs.getString(SQLColumns.CONTACT_NAME));
	    contact.setNumber(rs.getString(SQLColumns.CONTACT_NUMBER));
	    contact.setTitle(rs.getString(SQLColumns.CONTACT_TITLE));
	    contactList.add(contact);

	}
	return contactList;
    }

    public static HashSet<String> getContactAssociatedToSite(SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_CONTACT_ID_FOR_SITE;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(site.getSiteId());
	    HashSet<String> ContactIdSet = new HashSet<>();
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    while (rs.next()) {
		ContactIdSet.add(rs.getString(SQLColumns.CONTACT_ID));
	    }
	    return ContactIdSet;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public List<EquipmentDTO> getEquipmentList(SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_EQUIPMENT_LIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(site.getSiteId());
	    ResultSet rs = database.executeQuery(query, params);
	    List<EquipmentDTO> equipmentList = new LinkedList<>();

	    while (rs.next()) {
		EquipmentDTO equipment = new EquipmentDTO();
		equipment.setEquipmentId(rs.getString(SQLColumns.EQUIPMENT_ID));
		equipment.setEquipmentName(rs.getString(SQLColumns.ALIAS));
		equipment.setDeviceId(rs.getString(SQLColumns.DEVICE_ID));
		equipment.setEquipmentType(rs.getString(SQLColumns.EQUIPMENT_TYPE));
		equipment.setFileId(rs.getString(SQLColumns.FILE_ID));
		equipment.setLm2Seq(rs.getInt(SQLColumns.LM2_SEQ));
		equipmentList.add(equipment);
	    }

	    return equipmentList;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public List<EquipmentDTO> getEquipmentsForEquipmentType(SiteDTO site, int equipmentType) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_EQUIPMENT_LIST_FOR_TYPE;
	    String equipmentTypePredicate = "";
	    if (equipmentType > -1) {
		equipmentTypePredicate = String.format(" equipment_type = %s and ", String.valueOf(equipmentType));
	    }
	    query = String.format(query, equipmentTypePredicate);

	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(site.getSiteId());
	    ResultSet rs = database.executeQuery(query, params);
	    List<EquipmentDTO> equipmentList = new LinkedList<>();

	    while (rs.next()) {
		EquipmentDTO equipment = new EquipmentDTO();
		equipment.setEquipmentId(rs.getString(SQLColumns.EQUIPMENT_ID));
		equipment.setEquipmentName(rs.getString(SQLColumns.ALIAS));
		equipment.setDeviceId(rs.getString(SQLColumns.DEVICE_ID));
		equipment.setEquipmentType(rs.getString(SQLColumns.EQUIPMENT_TYPE));
		equipment.setFileId(rs.getString(SQLColumns.FILE_ID));
		equipment.setLm2Seq(rs.getInt(SQLColumns.LM2_SEQ));
		equipmentList.add(equipment);
	    }

	    return equipmentList;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public List<EquipmentDTO> getEquipmentsDetail(SiteDTO site, String equipmentId, Integer equipmentType)
	    throws Exception {
	Database database = null;
	try {

	    String query = null;
	    LinkedList<Object> params = new LinkedList<>();
	    String partMessage = null;
	    if (StringUtils.isNotBlank(equipmentId)) {
		query = SQLConstants.GET_EQUIPMENT;
		params.add(site.getSiteId());
		params.add(equipmentId);
		partMessage = String.format("equipment id : %s", equipmentId);
	    } else {
		query = SQLConstants.GET_EQUIPMENT_LIST_FOR_TYPE;

		String equipmentTypePredicate = "";
		if (equipmentType > -1) {
//		    equipmentTypePredicate = String.format(" equipment_type = ? and ", String.valueOf(equipmentType));
		    equipmentTypePredicate = " equipment_type = ? and ";
		    params.add(equipmentType);
		}
		params.add(site.getSiteId());

		query = String.format(query, equipmentTypePredicate);
		partMessage = String.format("equipment type : %s", String.valueOf(equipmentType));
	    }

	    LOG.debug("query>>>>" + query);

	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    List<EquipmentDTO> equipments = new LinkedList<>();

	    while (rs.next()) {
		EquipmentDTO equipment = new EquipmentDTO();
		equipment.setEquipmentId(rs.getString(SQLColumns.EQUIPMENT_ID));
		equipment.setEquipmentName(rs.getString(SQLColumns.ALIAS));
		equipment.setDeviceId(rs.getString(SQLColumns.DEVICE_ID));
		equipment.setEquipmentType(rs.getString(SQLColumns.EQUIPMENT_TYPE));
		equipment.setFileId(rs.getString(SQLColumns.FILE_ID));
		equipment.setLm2Seq(rs.getInt(SQLColumns.LM2_SEQ));
		equipments.add(equipment);
	    }

	    if (equipments == null || equipments.size() <= 0) {
		throw new SystemException(ErrorCodes.BAD_REQUEST, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST,
			String.format("No equipments found for site : %s and %s", site.getSiteName(), partMessage));
	    }

	    return equipments;
//	} catch (SystemException e) {
//	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
//	    throw e;
	} catch (SQLException e) {
	    throw new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    throw new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public List<WasherMetaDataDTO> getWasherList(EquipmentDTO equipment) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_WASHER_LIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(equipment.getEquipmentId());
	    ResultSet rs = database.executeQuery(query, params);
	    List<WasherMetaDataDTO> washerList = new LinkedList<>();

	    while (rs.next()) {
		WasherMetaDataDTO washer = new WasherMetaDataDTO();
		washer.setWasherId(rs.getString(SQLColumns.WASHER_ID));
		washer.setName(rs.getString(SQLColumns.NAME));
		washer.setLm2Seq(rs.getString(SQLColumns.LM2_SEQ));
		washer.setLoad(rs.getInt(SQLColumns.LOAD));
		washerList.add(washer);
	    }

	    return washerList;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public List<TunnelDTO> getTunnelList(EquipmentDTO equipment) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_TUNNEL_LIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(equipment.getEquipmentId());
	    ResultSet rs = database.executeQuery(query, params);
	    List<TunnelDTO> tunnelList = new LinkedList<>();
	    while (rs.next()) {
		TunnelDTO tunnel = new TunnelDTO();
		String tunnelId = rs.getString(SQLColumns.TUNNEL_ID);
		tunnel.setTunnelId(tunnelId);
		tunnel.setName(rs.getString(SQLColumns.NAME));
		tunnel.setLm2Seq(rs.getString(SQLColumns.LM2_SEQ));
		tunnel.setLoad(rs.getInt(SQLColumns.LOAD));
		tunnel.setModuleCount(rs.getInt(SQLColumns.MODULE_COUNT));
		tunnel.setModuleDetails(getTunnelDetails(equipment.getEquipmentId()));
		tunnelList.add(tunnel);
	    }
	    return tunnelList;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public Map<Integer, List<Integer>> getTunnelDetails(String equipmentId) throws Exception {
	Database database = null;
	List<Integer> productList = null;
	Map<Integer, List<Integer>> moduleDetails = new LinkedHashMap<>();
	try {
	    String query = SQLConstants.GET_MODULE_PRODUCT_DETAILS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(equipmentId);
	    ResultSet rs = database.executeQuery(query, params);
	    while (rs.next()) {
		int moduleId = rs.getInt(SQLColumns.MODULE_ID);
		int productId = rs.getInt(SQLColumns.PRODUCT_ID);
		if (moduleDetails.containsKey(moduleId)) {
		    productList = moduleDetails.get(moduleId);
		} else {
		    productList = new LinkedList<>();
		}
		if (productId != 0) {
		    productList.add(productId);
		    moduleDetails.put(moduleId, productList);
		}
	    }

	    return moduleDetails;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public List<FormulaMetaDataDTO> getFormulaList(EquipmentDTO equipment) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_FORMULA_LIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(equipment.getEquipmentId());
	    ResultSet rs = database.executeQuery(query, params);
	    List<FormulaMetaDataDTO> formulaList = new LinkedList<>();

	    while (rs.next()) {
		FormulaMetaDataDTO formula = new FormulaMetaDataDTO();
		formula.setFormulaId(rs.getString(SQLColumns.FORMULA_ID));
		formula.setName(rs.getString(SQLColumns.NAME));
		formula.setLm2Id(rs.getString(SQLColumns.LM2_SEQ));
		formulaList.add(formula);
	    }

	    return formulaList;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public List<ProductDTO> getProductList(EquipmentDTO equipment) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_PRODUCT_LIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(equipment.getEquipmentId());
	    ResultSet rs = database.executeQuery(query, params);
	    List<ProductDTO> productList = new LinkedList<>();

	    while (rs.next()) {
		ProductDTO product = new ProductDTO();
		product.setProductId(rs.getString(SQLColumns.PRODUCT_ID));
		product.setName(rs.getString(SQLColumns.NAME));
		product.setLm2Seq(rs.getString(SQLColumns.LM2_SEQ));
		product.setConcentration(rs.getInt(SQLColumns.CONCENTRATION));
		product.setFormat(rs.getInt(SQLColumns.FORMAT));

		productList.add(product);
	    }

	    return productList;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public boolean uploadLMFileTODB(byte[] content, SiteDTO site, FileDTO file, UserDTO userDTO) throws Exception {
	Database database = null;
	try {

	    String query = SQLConstants.UPDATE_LM2FILE;
	    // "INSERT INTO FILE_MASTER(file_id, name, created_by, status,
	    // site_id, description,version, lm2_file, modified_by, file_type)
	    // values(?,?,?,?,?,?,?,?,?)
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    InputStream inputStreamForDB = new ByteArrayInputStream(content);
	    params.add(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.UPLOADED));
	    params.add(Constants.LM2);
	    // find version no. of LM2 file.
	    int version = getFileUploadCount(site.getSiteId()) + 1;
	    params.add(version);
	    params.add(inputStreamForDB);
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    params.add(Constants.FILE_TYPE.LM2);
	    params.add(file.getFileId());
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    database.commit();
	    inputStreamForDB = null;

	    file.setVersion(version);

	    return true;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    // update the fileid into site master
    public boolean updateFileId(byte[] content, SiteDTO site, FileDTO file, UserDTO userDTO) throws Exception {
	Database database = null;
	try {

	    String query = SQLConstants.UPDATE_FILE_ID_IN_SITE_MASTER;
	    // "INSERT INTO FILE_MASTER(file_id, name, created_by, status,
	    // site_id, description,version, lm2_file, modified_by, file_type)
	    // values(?,?,?,?,?,?,?,?,?)
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    database.setAutoCommitFalse();
	    // update SITE_MASTER SET file_id=? where site_id=?"
	    params = new LinkedList<>();
	    params.add(file.getFileId());
	    params.add(site.getSiteId());
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }

	    database.commit();

	    return true;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public boolean uploadMDBFileStatusTODB(SiteDTO site, FileDTO file, UserDTO userDTO) throws Exception {
	Database database = null;
	try {

	    String query = SQLConstants.MDB_FILE_STATUS;
	    // INSERT INTO FILE_MASTER(file_id, name, created_by, status,
	    // site_id,
	    // description,version, modified_by, file_type)
	    // values(?,?,?,?,?,?,?,?,?)"
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.UPLOADED));
	    params.add(Constants.UPLOADED);
	    // find version no. of MDB file.
	    params.add((getFileUploadCount(site.getSiteId())) + 1);
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    params.add(Constants.FILE_TYPE.MDB);
	    params.add(file.getFileId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    return true;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));

	    }
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

    }

    public boolean updateEquipLM2File(FileDTO eFile) throws Exception {
	Database database = new Database();
	LinkedList<Object> params;
	try {

	    String query = SQLConstants.UPDATE_EQUIIP_LM2FILE;
	    // UPDATE_EQUIIP_LM2FILE = "UPDATE FILE_MASTER set status=?,
	    // description=?, detailed_description=?, version=?, file_type=?,
	    // modified_date=utc_timestamp where file_id=?"
	    LOG.debug("query>>>>" + query);
	    LOG.debug(
		    "Status:" + eFile.getStatus() + ":" + eFile.getDescription() + ":" + eFile.getDetailedDescription()
			    + ":" + eFile.getVersion() + ":" + eFile.getFileType() + ":" + eFile.getFileId());

	    params = new LinkedList<>();
	    params.add(eFile.getStatus());
	    params.add(eFile.getDescription());
	    params.add(eFile.getDetailedDescription());
	    params.add(eFile.getVersion());
	    params.add(Constants.FILE_TYPE.LM2);
	    params.add(eFile.getFileId());

	    int count = database.executeUpdate(query, params);
	    LOG.debug("count>>>>" + count);
	    if (count <= 0) {
		LOG.error("No rows impacted while updating equipment LM2 file record");
		// throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
		// ConfigReader.getObject().getErrorConfig(),
		// ErrorCodes.StatusCodes.FAILURE, null);
	    }

	    return true;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

    }

    public boolean updateEquipJsonFile(FileDTO eFile) throws Exception {
	Database database = new Database();
	LinkedList<Object> params;
	try {

	    String query = SQLConstants.UPDATE_EQUIIP_LM2FILE;
	    // UPDATE_EQUIIP_LM2FILE = "UPDATE FILE_MASTER set status=?,
	    // description=?, detailed_description=?, version=?, file_type=?,
	    // modified_date=utc_timestamp where file_id=?"
	    LOG.debug("query>>>>" + query);
	    LOG.debug(
		    "Status:" + eFile.getStatus() + ":" + eFile.getDescription() + ":" + eFile.getDetailedDescription()
			    + ":" + eFile.getVersion() + ":" + eFile.getFileType() + ":" + eFile.getFileId());

	    params = new LinkedList<>();
	    params.add(eFile.getStatus());
	    params.add(eFile.getDescription());
	    params.add(eFile.getDetailedDescription());
	    params.add(eFile.getVersion());
	    params.add(Constants.FILE_TYPE.CONFIG_JSON);
	    params.add(eFile.getFileId());

	    int count = database.executeUpdate(query, params);
	    LOG.debug("count>>>>" + count);
	    if (count <= 0) {
		LOG.error("No rows impacted while updating equipment LM2 file record");
		// throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
		// ConfigReader.getObject().getErrorConfig(),
		// ErrorCodes.StatusCodes.FAILURE, null);
	    }

	    return true;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

    }

    public boolean updateEquipLM2FileActive(FileDTO eFile) throws Exception {
	Database database = new Database();
	LinkedList<Object> params;
	try {

	    String query = SQLConstants.UPDATE_EQUIIP_LM2FILE_ACTIVE;
	    // UPDATE_EQUIIP_LM2FILE_ACTIVE = "UPDATE FILE_MASTER set
	    // is_active=0,
	    // modified_date=utc_timestamp where file_id!=? AND device_id=?"
	    LOG.debug("query>>>>" + query);
	    LOG.debug("deviceid:" + eFile.getDevice_id() + ":" + eFile.getFileId());

	    params = new LinkedList<>();
	    params.add(eFile.getFileId());
	    params.add(eFile.getDevice_id());

	    int count = database.executeUpdate(query, params);
	    LOG.debug("count>>>>" + count);
	    if (count <= 0) {
		LOG.debug("No rows impacted while updating equipment LM2 file record active");
		// throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
		// ConfigReader.getObject().getErrorConfig(),
		// ErrorCodes.StatusCodes.FAILURE, null);
	    }

	    return true;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

    }

    public void updateOldFileInActive(FileDTO eFile, String unitId) throws Exception {
	Database database = new Database();
	LinkedList<Object> params;
	try {
	    String query = SQLConstants.UPDATE_CONFIGFILE_INACTIVE;
	    LOG.debug("query>>>>" + query);
	    LOG.debug("deviceid:" + eFile.getDevice_id() + ":" + eFile.getFileId());
	    params = new LinkedList<>();
	    params.add(eFile.getFileId());
	    params.add(unitId);
	    params.add(eFile.getSiteId());
	    int count = database.executeUpdate(query, params);
	    LOG.debug("count>>>>" + count);
	    if (count <= 0) {
		LOG.debug("No rows impacted while updating equipment LM2 file record active");
	    }
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

    }

    public int getFileUploadCount(String siteId) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_LM2_UPLOAD_COUNT;
	    // "SELECT count(site_id) as lm2_upload_count FROM file_master where
	    // site_id =?"
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(siteId);
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    int count = 0;
	    if (rs.next()) {
		count = rs.getInt(SQLColumns.LM2_UPLOAD_COUNT);
	    }
	    return count;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public void changeFileStatus(FileDTO file) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.UPDATE_FILE_STATUS;
	    LOG.debug("query>>>>" + query);
	    // update FILE_MASTER set status=?, description=?,
	    // detailed_description=? where file_id=?
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(file.getStatus());
	    params.add(file.getDescription());
	    params.add(file.getDetailedDescription());
	    params.add(file.getFileId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public void changeConfigFileStatus(FileDTO file) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.UPDATE_JSON_LM2_FILE_STATUS;
	    LOG.debug("query>>>>" + query);
	    // update FILE_MASTER set status=?, description=?,
	    // detailed_description=? where file_id=?
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(file.getStatus());
	    params.add(file.getDescription());
	    params.add(file.getDetailedDescription());
	    params.add(file.getFileId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public boolean fileExists(String fileID) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.FILE_ID_EXIST;
	    // "select file_id from FILE_MASTER where file_id =?"
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(fileID);
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return true;
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }

    public boolean uploadFileTODB(SiteDTO site, FileDTO file, UserDTO userDTO) throws Exception {
	Database database = null;
	try {

	    String query = SQLConstants.CREATE_FILE;
	    // "INSERT INTO FILE_MASTER(file_id, name, created_by, status,
	    // description, site_id, modified_by, created_date, modified_date)
	    // values(?,?,?,?,?,?,?, utc_timestamp,utc_timestamp) "
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(file.getFileId());
	    params.add(file.getName());
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    params.add(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.UPLOADING));
	    params.add(Constants.UPLOADING);
	    params.add(site.getSiteId());
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count > 0) {
		return true;
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    protected FileHistoryListResponseDTO getFileListData(ResultSet rs, String timeZone) throws Exception {
	FileHistoryListResponseDTO response = new FileHistoryListResponseDTO();
	List<FileHistoryDTO> fileHistoryList = new LinkedList<>();

	while (rs.next()) {
	    // Select SITE_MASTER.site_name, FILE_MASTER.name,
	    // FILE_MASTER.file_id, FILE_MASTER.created_by,
	    // FILE_MASTER.created_date, status, FILE_MASTER.description from
	    // FILE_MASTER left join SITE_MASTER on
	    // FILE_MASTER.site_id=SITE_MASTER.site_id where FILE_MASTER.site_id
	    // in(SELECT site_id from SITE_MASTER where site_id in (select
	    // site_id from SITE_BUSINESS_ASSOCIATION where business_id =1))
	    // order by created_date desc limit 300
	    FileHistoryDTO fileHistoryDTO = new FileHistoryDTO();
	    fileHistoryDTO.setSiteName(rs.getString(SQLColumns.SITE_NAME));
	    String fileId = rs.getString(SQLColumns.FILE_ID);
	    fileHistoryDTO.setFileName(rs.getString(SQLColumns.NAME));
	    fileHistoryDTO.setFileId(fileId);
	    fileHistoryDTO.setCreatedBy(rs.getString(SQLColumns.CREATED_BY));
	    fileHistoryDTO.setCreatedDate(CommonUtils.convertDate(rs.getString(SQLColumns.CREATED_DATE), timeZone));
	    fileHistoryDTO.setStatus(rs.getString(SQLColumns.STATUS));
	    fileHistoryDTO.setDescription(rs.getString(SQLColumns.DESCRIPTION));
	    int isActive = rs.getInt(SQLColumns.IS_ACTIVE);
	    String fileType = rs.getString(SQLColumns.FILE_TYPE);
	    String lm2Status = null;
	    if (fileType != null) {
		switch (fileType) {
		case (Constants.FILE_TYPE.LM2):
		case (Constants.FILE_TYPE.CONFIG_JSON):
		case (Constants.FILE_TYPE.FORMULA_JSON):
		    lm2Status = Constants.LM2_STATUS.INACTIVE;
		    break;
		default:
		    break;
		}
	    }
	    if (isActive == 1) {
		lm2Status = Constants.LM2_STATUS.ACTIVE;
	    }
	    fileHistoryDTO.setLm2Status(lm2Status);
	    fileHistoryList.add(fileHistoryDTO);
	}
	response.setFileHistoryList(fileHistoryList);
	return response;
    }

    public ObservationDTO createObservation(UserDTO userDTO, ObservationDTO observation) throws Exception {
	Database database = null;
	try {

	    String query = SQLConstants.CREATE_OBSERVATION;
	    // "INSERT INTO hydro.OBSERVATION_MASTER(observation_id,
	    // observation,
	    // recommendation, created_by,modified_by,equipment_id, month, year)
	    // values(?,?,?,?,?,?,?,?)";

	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    String guid = CommonUtils.guidGenerator(null, null);
	    params.add(guid);
	    params.add(observation.getSiteId());
	    params.add(observation.getEquipmentId());
	    params.add(observation.getObservation());
	    params.add(observation.getRecommendation());
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    params.add(observation.getEquipmentId());
	    params.add(observation.getMonth());
	    params.add(observation.getYear());
	    params.add(observation.getEquipmentId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    ObservationDTO observationDTO = new ObservationDTO();
	    observationDTO.setObservationId(guid);
	    return observationDTO;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    protected ObservationListResponseDTO getObservationListData(ResultSet rs, String timeZone) throws Exception {
	ObservationListResponseDTO response = new ObservationListResponseDTO();
	List<ObservationDTO> observationList = new LinkedList<>();

	while (rs.next()) {

	    // "select observation_id, observation, recommendation, created_by,
	    // created_date, modified_by, modified_date from OBSERVATION_MASTER
	    // where month=? and year=? order by created_date desc"
	    ObservationDTO observationDTO = new ObservationDTO();
	    observationDTO.setObservationId(rs.getString(SQLColumns.OBSERVATION_ID));
	    observationDTO.setObservation(rs.getString(SQLColumns.OBSERVATION));
	    observationDTO.setRecommendation(rs.getString(SQLColumns.RECOMMENDATION));
	    observationDTO.setCreatedBy(rs.getString(SQLColumns.CREATED_BY));
	    observationDTO.setCreatedDate(CommonUtils.convertDate(rs.getString(SQLColumns.CREATED_DATE), timeZone));
	    observationDTO.setModifiedBy(rs.getString(SQLColumns.MODIFIED_BY));
	    observationDTO.setModifiedDate(CommonUtils.convertDate(rs.getString(SQLColumns.MODIFIED_DATE), timeZone));
	    observationList.add(observationDTO);
	}
	response.setObservationList(observationList);
	return response;
    }

    public HashMap<String, HashMap<String, String>> pushLM2DataToDB(UserDTO userDTO, FileDTO file, NewDataSet testData)
	    throws Exception {
	Database database = new Database();
	List<Object> tablesData = testData.getAllTableData();
	Iterator equipmentIterator = tablesData.iterator();
	NewDataSet.TablaEquipos equipment = null;
	ConfigReader configReader = ConfigReader.getObject();
	HashMap<String, HashMap<String, String>> equipFiles = new HashMap<String, HashMap<String, String>>();

	int lm2Sequence = 1;
	try {
	    LinkedList<Object> params = new LinkedList<>();
	    List<EquipmentWrapperDTO> equipmentList = new LinkedList<>();
	    while (equipmentIterator.hasNext()) {
		Object tableObj = (Object) equipmentIterator.next();
		if (tableObj instanceof NewDataSet.TablaEquipos) {
		    equipment = (NewDataSet.TablaEquipos) tableObj;
		    if ((equipment.getNUMLAVADORAS() != 0 || equipment.getNUMTUNELES() != 0)) {
			String guid = CommonUtils.guidGenerator(null, null);
			EquipmentWrapperDTO eqipmentWrapper = new EquipmentWrapperDTO();
			eqipmentWrapper.setEquipment(equipment);
			eqipmentWrapper.setId(guid);
			equipmentList.add(eqipmentWrapper);
		    }
		}
	    }

	    String query = SQLConstants.INSERT_FILE;
	    // INSERT_FILE = "INSERT INTO FILE_MASTER (file_id, name,
	    // created_by, status, site_id, description, detailed_description,
	    // version, modified_by, file_type, device_id, is_active,
	    // created_date,
	    // modified_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,
	    // utc_timestamp,utc_timestamp)"
	    LOG.debug("query>>>>" + query);

	    database.setAutoCommitFalse();
	    database.createBatch(query);
	    int ecount = 1;
	    for (EquipmentWrapperDTO equipmentWrapper : equipmentList) {

		TablaEquipos equip = equipmentWrapper.getEquipment();

		String deviceId = configReader.getDeviceIdUsingSiteIdIpAddress(file.getSiteId(),
			equip.getIPEQUIPO().trim());

		if (deviceId == null) {
		    LOG.debug("finding Device for SiteID::" + file.getSiteId() + ":IP:::" + equip.getIPEQUIPO().trim());
		    String uri = configReader.getAppConfig(Constants.SEARCH_SERVICE_URL).concat("/");
		    String tempId = CommonUtils.guidGenerator(null, null);
		    String reqBody = ReportUtils.getQuery("DeviceCreate.json");

		    SiteDTO sitedto = new SiteDTO();
		    sitedto.setSiteId(file.getSiteId());

		    String siteName = getSiteDetails(sitedto).getSiteName();
		    reqBody = reqBody.replace("SERIAL-NO", "NEEDS_UPDATE_" + tempId);
		    reqBody = reqBody.replace("SITE-ID", file.getSiteId());
		    reqBody = reqBody.replace("DEVICE-NAME", siteName + "_" + equip.getALIAS().trim());
		    reqBody = reqBody.replace("IP-ADDRESS", equip.getIPEQUIPO().trim());
		    reqBody = reqBody.replace("TEMP-ID", tempId);

		    LOG.debug("Device creation request body::" + reqBody);

		    CommonUtils.disableSslVerification();
		    try {
			String response = CommonUtils.doPost(uri, reqBody);
			deviceId = tempId;
		    } catch (Exception exp) {
			throw new SystemException(ErrorCodes.DEVICE_CREATION_FAILED,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }

		}
		LOG.debug("device Id ::" + deviceId);

		params = new LinkedList<>();
		params.add(file.getFileId() + "_" + ecount);
		params.add(file.getName());
		params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		params.add(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS));
		params.add(file.getSiteId());
		params.add(equip.getALIAS().trim());
		params.add("From LM2 Upload");
		params.add(file.getVersion());
		params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		params.add(Constants.FILE_TYPE.LM2);
		params.add(deviceId);
		params.add(1);

		database.setAutoCommitFalse();
		database.addBatch(query, params);

		HashMap<String, String> eFileMap = new HashMap<String, String>();
		eFileMap.put(Constants.FILE_ID, file.getFileId() + "_" + ecount);
		eFileMap.put(Constants.DESCRIPTION, equip.getALIAS().trim());
		eFileMap.put(Constants.DEVICE_ID, deviceId);

		equipFiles.put(equipmentWrapper.getId(), eFileMap);

		ecount++;
	    }
	    int[] result = database.executeBatch();
	    if (result == null || result.length <= 0) {
		throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (int i = 0; i < result.length; i++) {
		if (result[i] == 0) {
		    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }

	    query = SQLConstants.INSERT_INTO_EQUIPMENT_MASTER;
	    // Insert into EQUIPMENT_MASTER(equipment_id, lm2_seq,
	    // site_id,
	    // alias, equipment_type, slave, ip_address,
	    // observations,
	    // washer_count, tunnel_count, w_machine_chnl_count,
	    // pump_count,
	    // channel_count, is_active, created_by, modified_by,
	    // version,
	    // file_id) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);
	    LOG.debug("query>>>>" + query);

	    database.setAutoCommitFalse();
	    database.createBatch(query);
	    for (EquipmentWrapperDTO equipmentWrapper : equipmentList) {
		TablaEquipos equip = equipmentWrapper.getEquipment();
		if (equip.getNUMTUNELES() > equip.getNUMLAVADORAS())
		    equip.setTIPOPLC(Constants.EquipmentType.TUNNEL);
		else
		    equip.setTIPOPLC(Constants.EquipmentType.WASHER_EXTRACTOR);

		params = new LinkedList<>();
		params.add(equipmentWrapper.getId());
		params.add(lm2Sequence++);
		params.add(file.getSiteId());
		params.add(equip.getALIAS());
		params.add(equip.getTIPOPLC());
		params.add(equip.getESCLAVO());
		params.add(equip.getIPEQUIPO());
		params.add(equip.getOBSERVACIONES());
		params.add(equip.getNUMLAVADORAS());
		params.add(equip.getNUMTUNELES());
		params.add(equip.getNUMCANALESLAVADORAS());
		params.add(equip.getNUMBOMBAS());
		params.add(equip.getNUMCANALES());
		params.add(equip.getACTIVADO());
		params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		params.add(equip.getVERSION());
		params.add(equipFiles.get(equipmentWrapper.getId()).get(Constants.FILE_ID));// file.getFileId()
		params.add(equipFiles.get(equipmentWrapper.getId()).get(Constants.DEVICE_ID));

		database.setAutoCommitFalse();
		database.addBatch(query, params);

	    }
	    result = database.executeBatch();
	    if (result == null || result.length <= 0) {
		throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (int i = 0; i < result.length; i++) {
		if (result[i] == 0) {
		    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }
	    lm2Sequence = 1;
	    while (lm2Sequence <= equipmentList.size()) {

		for (EquipmentWrapperDTO equipmentWrapper : equipmentList) {

		    TablaEquipos tablaEquipos = equipmentWrapper.getEquipment();
		    query = SQLConstants.INSERT_INTO_EQUIPMENT_PUMP;
		    LOG.debug("query>>>>" + query);
		    database.createBatch(query);

		    params = new LinkedList<>();
		    String uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_NAME.BOMBAS1);
		    params.add(tablaEquipos.getBOMBAS1());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_NAME.BOMBAS2);
		    params.add(tablaEquipos.getBOMBAS2());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_NAME.BOMBAS3);
		    params.add(tablaEquipos.getBOMBAS3());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_NAME.BOMBAS4);
		    params.add(tablaEquipos.getBOMBAS4());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_NAME.BOMBAS5);
		    params.add(tablaEquipos.getBOMBAS5());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_NAME.BOMBAS6);
		    params.add(tablaEquipos.getBOMBAS6());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_NAME.BOMBAS7);
		    params.add(tablaEquipos.getBOMBAS7());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_NAME.BOMBAS8);
		    params.add(tablaEquipos.getBOMBAS8());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_NAME.BOMBAS9);
		    params.add(tablaEquipos.getBOMBAS9());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_NAME.BOMBAS10);
		    params.add(tablaEquipos.getBOMBAS10());
		    database.addBatch(query, params);
		    result = database.executeBatch();
		    if (result != null && result.length > 0) {
			for (int j = 0; j < result.length; j++) {
			    if (result[j] == 0) {
				throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }
			}
		    }

		    query = SQLConstants.INSERT_INTO_EQUIPMENT_FORMULA;
		    // "INSERT into
		    // equipment_formula(formula_id,
		    // equipment_id,
		    // formula_name, formula_value)
		    // VALUES(?,?,?,?)";
		    LOG.debug("query>>>>" + query);
		    database.createBatch(query);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.FORMULA_NAME.FORMULAS0);
		    params.add(tablaEquipos.getFORMULAS0());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.FORMULA_NAME.FORMULAS1);
		    params.add(tablaEquipos.getFORMULAS1());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.FORMULA_NAME.FORMULAS2);
		    params.add(tablaEquipos.getFORMULAS2());
		    database.addBatch(query, params);

		    result = database.executeBatch();
		    if (result != null && result.length > 0) {
			for (int j = 0; j < result.length; j++) {
			    if (result[j] == 0) {
				throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }
			}
		    }

		    query = SQLConstants.INSERT_INTO_EQUIPMENT_PUMP_MACHINERY;
		    // "INSERT INTO
		    // EQUIPMENT_PUMP_MACHINERY(pump_machine_id,
		    // equipment_id, pump_machine_name,
		    // pump_machine_value)
		    // value(?,?,?,?)"
		    LOG.debug("query>>>>" + query);
		    database.createBatch(query);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_MACHINE_NAME.BOMBAS_MAQUINARIA0);
		    params.add(tablaEquipos.getBOMBASMAQUINARIA0());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_MACHINE_NAME.BOMBAS_MAQUINARIA1);
		    params.add(tablaEquipos.getBOMBASMAQUINARIA1());
		    database.addBatch(query, params);

		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.PUMP_MACHINE_NAME.BOMBAS_MAQUINARIA2);
		    params.add(tablaEquipos.getBOMBASMAQUINARIA2());
		    database.addBatch(query, params);

		    result = database.executeBatch();
		    if (result != null && result.length > 0) {
			for (int j = 0; j < result.length; j++) {
			    if (result[j] == 0) {
				throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }
			}
		    }

		    query = SQLConstants.INSERT_INTO_EQUIPMENT_TUNEEL_CHANNEL;
		    params = new LinkedList<>();
		    uuid = CommonUtils.guidGenerator(null, null);
		    params.add(uuid);
		    params.add(equipmentWrapper.getId());
		    params.add(Constants.NUM_CANALES_TUNEL1);
		    params.add(tablaEquipos.getNUMCANALESTUNEL1());

		    int count = database.executeUpdate(query, params);
		    if (count <= 0) {
			throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }

		    // Storing product master data.
		    List<NewDataSet.TablaProductos> productList = new LinkedList<>();
		    // List<Object> tables = testData.getAllTableData();
		    Iterator productIterator = tablesData.iterator();
		    while (productIterator.hasNext()) {
			Object tableObj = (Object) productIterator.next();
			if (tableObj instanceof NewDataSet.TablaProductos) {
			    NewDataSet.TablaProductos product = (NewDataSet.TablaProductos) tableObj;
			    if (product.getEQUIPO() == lm2Sequence && !(product.getNOMBRE().contains("PRODUCT"))) {
				product = (NewDataSet.TablaProductos) tableObj;
				productList.add(product);
			    }
			}
		    }
		    query = SQLConstants.INSERT_INTO_PRODUCT_MASTER;
		    // "INSERT into PRODUCT_MASTER(product_id, equipment_id,
		    // lm2_seq, name, density, concentration, kf, flow,
		    // frequency,
		    // docification_mode, priority, contact, alarms_ignored,
		    // percentage, drag_type, pump_speed, format, price,
		    // calibration, color1, color2, created_by,modified_by)
		    // values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
		    LOG.debug("query>>>>" + query);
		    database.createBatch(query);
		    int lm2SequenceForProducts = 1;
		    for (NewDataSet.TablaProductos products : productList) {
			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(equipmentWrapper.getId());
			params.add(lm2SequenceForProducts++);
			params.add(products.getNOMBRE());
			params.add(products.getDENSIDAD());
			params.add(products.getCONCENTRACION());
			params.add(products.getKF());
			params.add(products.getCAUDAL());
			params.add(products.getFRECUENCIA());
			params.add(products.getMODODOSIFICACION());
			params.add(products.getPRIORIDAD());
			params.add(products.getCONTACTO());
			params.add(products.getALARMASIGNORADAS());
			params.add(products.getPORCENTAJE());
			params.add(products.getTIPOARRASTRE());
			params.add(products.getVELOCIDADBOMBA());
			params.add(products.getFORMATO());
			params.add(products.getPRECIO());
			params.add(products.getCALIBRACION());
			params.add(products.getCOLOR1());
			params.add(products.getCOLOR2());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
			database.setAutoCommitFalse();
			database.addBatch(query, params);
		    }
		    result = database.executeBatch();
		    if (result == null || result.length < 0) {
			throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		    for (int i = 0; i < result.length; i++) {
			if (result[i] < 0) {
			    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
			}
		    }

		    // Store data into WATER_MASTER
		    List<NewDataSet.TablaAgua> waterList = new LinkedList<>();
		    Iterator waterIterator = tablesData.iterator();
		    while (waterIterator.hasNext()) {
			Object tableObj = (Object) waterIterator.next();
			if (tableObj instanceof NewDataSet.TablaAgua) {
			    NewDataSet.TablaAgua water = (NewDataSet.TablaAgua) tableObj;
			    if (water.getEQUIPO() == lm2Sequence && !(water.getNOMBRE().contains("CHANNEL"))) {
				water = (NewDataSet.TablaAgua) tableObj;
				waterList.add(water);
			    }
			}
		    }
		    query = SQLConstants.INSERT_INTO_WATER_MASTER;
		    // "INSERT into WATER_MASTER(water_id, equipment_id,
		    // lm2_seq,name,
		    // kf, flow, water_time, cellphone_minute,
		    // docification_mode, seperation_ml, ignored_alarms,
		    // percentage, diameter, pump_type, created_by,modified_by)
		    // values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
		    LOG.debug("query>>>>" + query);
		    database.createBatch(query);
		    int lm2SequenceForWater = 1;
		    for (NewDataSet.TablaAgua water : waterList) {
			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(equipmentWrapper.getId());
			params.add(lm2SequenceForWater++);
			params.add(water.getNOMBRE());
			params.add(water.getKF());
			params.add(water.getCAUDAL());
			params.add(water.getTIEMPOAGUA());
			params.add(water.getTIEMPOAIRE());
			params.add(water.getMODODOSIFICACION());
			params.add(water.getMLSEPARACION());
			params.add(water.getALARMASIGNORADAS());
			params.add(water.getPORCENTAJE());
			params.add(water.getDIAMETRO());
			params.add(water.getTIPOBOMBA());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
			database.setAutoCommitFalse();
			database.addBatch(query, params);
		    }
		    result = database.executeBatch();
		    if (result == null || result.length < 0) {
			throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		    for (int i = 0; i < result.length; i++) {
			if (result[i] < 0) {
			    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
			}
		    }
		    // insert into washer master
		    List<NewDataSet.TablaLavadoras> washerList = new LinkedList<>();
		    Iterator washerIterator = tablesData.iterator();
		    int washerCount = tablaEquipos.getNUMLAVADORAS();
		    while (washerCount >= 1 && washerIterator.hasNext()) {
			Object tableObj = (Object) washerIterator.next();
			if (tableObj instanceof NewDataSet.TablaLavadoras) {
			    NewDataSet.TablaLavadoras washer = (NewDataSet.TablaLavadoras) tableObj;
			    if (washer.getEQUIPO() == lm2Sequence) {
				washer = (NewDataSet.TablaLavadoras) tableObj;
				washerList.add(washer);
				washerCount--;
			    }
			}
		    }
		    query = SQLConstants.INSERT_INTO_WASHER_MASTER;
		    // "INSERT into WASHER_MASTER(washer_id, equipment_id,
		    // lm2_seq, name, `load`, modifiable_load, ltr_drag,
		    // cellular_minutes, id_formula, work_mode, reset_mode,
		    // reset_signal, reset_formula, unused_machine,
		    // unused_time_delay, unused_timeout, t_acceptation,
		    // t_repetition, t_lock, type_programmer, signal_count,
		    // signal_voltage, signal_connection, observation,
		    // created_by,modified_by)
		    // values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
		    LOG.debug("query>>>>" + query);
		    database.createBatch(query);
		    int lm2SequenceForWasher = 1;
		    for (NewDataSet.TablaLavadoras washer : washerList) {
			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(equipmentWrapper.getId());
			params.add(lm2SequenceForWasher++);
			params.add(washer.getNOMBRE());
			params.add(washer.getKG());
			params.add(washer.getKGMODIFICABLE());
			params.add(washer.getLTRARRASTRE());
			params.add(washer.getTIEMPOAIRE());
			params.add(washer.getIDFORMULA());
			params.add(washer.getMODOTRABAJO());
			params.add(washer.getRESETMODO());
			params.add(washer.getRESETSENAL());
			params.add(washer.getRESETFORMULA());
			params.add(washer.getPAROMAQUINA());
			params.add(washer.getPARORETARDO());
			params.add(washer.getPAROTIMEOUT());
			params.add(washer.getTACEPTACION());
			params.add(washer.getTREPETICION());
			params.add(washer.getTBLOQUEO());
			params.add(washer.getTIPOPROGRAMADOR());
			params.add(washer.getNUMEROSENALES());
			params.add(washer.getVOLTAJESENALES());
			params.add(washer.getCONEXIONSENALES());
			params.add(washer.getOBSERVACIONES());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
			database.setAutoCommitFalse();
			database.addBatch(query, params);
		    }
		    result = database.executeBatch();
		    if (result == null || result.length < 0) {
			throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		    for (int i = 0; i < result.length; i++) {
			if (result[i] < 0) {
			    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
			}
		    }

		    // Insert into formula_master
		    List<EquipmentWrapperDTO> formulaList = new LinkedList<>();
		    Iterator formulaIterator = tablesData.iterator();
		    while (formulaIterator.hasNext()) {
			Object tableObj = (Object) formulaIterator.next();
			if (tableObj instanceof NewDataSet.TablaFormulas) {
			    NewDataSet.TablaFormulas formula = (NewDataSet.TablaFormulas) tableObj;
			    if ((formula.getEQUIPO() != null && formula.getEQUIPO() == lm2Sequence)
				    && (!StringUtils.isEmpty(formula.getNOMBRE()))) {
				String formula_id = CommonUtils.guidGenerator(null, null);
				EquipmentWrapperDTO eqipmentWrapper = new EquipmentWrapperDTO();
				eqipmentWrapper.setFormula(formula);
				eqipmentWrapper.setFormulaId(formula_id);
				formulaList.add(eqipmentWrapper);
			    }

			}
		    }
		    query = SQLConstants.INSERT_INTO_FORMULA_MASTER;
		    // INSERT into FORMULA_MASTER(formula_id, equipment_id,
		    // lm2_seq, name, `load`, phases, color, created_by,
		    // modified_by) value(?,?,?,?,?,?,?,?,?);
		    LOG.debug("query>>>>" + query);
		    database.setAutoCommitFalse();
		    database.createBatch(query);
		    int lm2SequenceForFormula = 1;
		    for (EquipmentWrapperDTO formula : formulaList) {
			TablaFormulas formulaTable = formula.getFormula();
			params = new LinkedList<>();
			params.add(formula.getFormulaId());
			params.add(equipmentWrapper.getId());
			params.add(lm2SequenceForFormula++);
			params.add(formulaTable.getNOMBRE());
			params.add(formulaTable.getKG());
			params.add(formulaTable.getFASES());
			params.add(formulaTable.getCOLOR());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
			database.setAutoCommitFalse();
			database.addBatch(query, params);
		    }
		    result = database.executeBatch();
		    if (result == null || result.length < 0) {
			throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		    for (int i = 0; i < result.length; i++) {
			if (result[i] < 0) {
			    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
			}
		    }

		    for (EquipmentWrapperDTO formulaPDB : formulaList) {

			TablaFormulas formulaDetails = formulaPDB.getFormula();
			// INSERT into FORMULA_PDB(pdb_id, formula_id, pdb_name,
			// pdb_value) value(?,?,?,?);

			query = SQLConstants.INSERT_INTO_FORMULA_PDB;
			LOG.debug("query>>>>" + query);
			database.createBatch(query);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(formulaPDB.getFormulaId());
			params.add(Constants.PDB_NAME.PDB1);
			params.add(formulaDetails.getPDB1());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(formulaPDB.getFormulaId());
			params.add(Constants.PDB_NAME.PDB2);
			params.add(formulaDetails.getPDB2());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(formulaPDB.getFormulaId());
			params.add(Constants.PDB_NAME.PDB3);
			params.add(formulaDetails.getPDB3());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(formulaPDB.getFormulaId());
			params.add(Constants.PDB_NAME.PDB4);
			params.add(formulaDetails.getPDB4());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(formulaPDB.getFormulaId());
			params.add(Constants.PDB_NAME.PDB5);
			params.add(formulaDetails.getPDB5());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(formulaPDB.getFormulaId());
			params.add(Constants.PDB_NAME.PDB6);
			params.add(formulaDetails.getPDB6());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(formulaPDB.getFormulaId());
			params.add(Constants.PDB_NAME.PDB7);
			params.add(formulaDetails.getPDB7());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(formulaPDB.getFormulaId());
			params.add(Constants.PDB_NAME.PDB8);
			params.add(formulaDetails.getPDB8());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(formulaPDB.getFormulaId());
			params.add(Constants.PDB_NAME.PDB9);
			params.add(formulaDetails.getPDB9());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(uuid);
			params.add(formulaPDB.getFormulaId());
			params.add(Constants.PDB_NAME.PDB10);
			params.add(formulaDetails.getPDB10());
			database.addBatch(query, params);

			result = database.executeBatch();
			if (result != null && result.length > 0) {
			    for (int j = 0; j < result.length; j++) {
				if (result[j] == 0) {
				    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
					    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					    null);
				}
			    }
			}

		    }
		    // Insert into Tunnel Master.
		    List<EquipmentWrapperDTO> tunnelList = new LinkedList<>();
		    Iterator tunnelIterator = tablesData.iterator();
		    while (tunnelIterator.hasNext()) {
			Object tableObj = (Object) tunnelIterator.next();
			if (tableObj instanceof NewDataSet.TablaTuneles) {
			    NewDataSet.TablaTuneles tunnel = (NewDataSet.TablaTuneles) tableObj;
			    if (tunnel.getEQUIPO() == lm2Sequence && (tunnel.getNUMMODULOS() > 0)) {// !(tunnel.getNOMBRE().contains("Insert
												    // name"))
				String tunnel_id = CommonUtils.guidGenerator(null, null);
				EquipmentWrapperDTO eqipmentWrapper = new EquipmentWrapperDTO();
				eqipmentWrapper.setTunnels(tunnel);
				eqipmentWrapper.setTunnelId(tunnel_id);
				tunnelList.add(eqipmentWrapper);
			    }
			}
		    }
		    query = SQLConstants.INSERT_INTO_TUNNEL_MASTER;
		    // INSERT into TUNNEL_MASTER(tunnel_id, equipment_id,
		    // lm2_seq, name, `load`, modules_count, module_count_dosif,
		    // load_min, load_max, formula_id, ltr, cellular_minutes,
		    // modules_by_channel, created_by, modified_by)
		    // value(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);
		    LOG.debug("query>>>>" + query);

		    List<String> tunnelModProd = new ArrayList<String>();

		    database.setAutoCommitFalse();
		    database.createBatch(query);
		    int lm2SequenceForTunnel = 1;
		    for (EquipmentWrapperDTO tunnel : tunnelList) {
			TablaTuneles tunnelTable = tunnel.getTunnels();
			params = new LinkedList<>();
			params.add(tunnel.getTunnelId());
			params.add(equipmentWrapper.getId());
			params.add(lm2SequenceForTunnel++);
			params.add(tunnelTable.getNOMBRE());
			params.add(tunnelTable.getKG());
			params.add(tunnelTable.getNUMMODULOS());
			params.add(tunnelTable.getNUMMODULOSDOSIF());
			params.add(tunnelTable.getKGMIN());
			params.add(tunnelTable.getKGMAX());
			params.add(tunnelTable.getIDFORMULA());
			params.add(tunnelTable.getLTR());
			params.add(tunnelTable.getTIEMPOAIRE());
			params.add(tunnelTable.getMODULOSPORCANAL());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());

			// Add PRODUCTOS_MODULOS# columns into
			// TUNNEL_MODULE_PRODUCT_ASSOCIATION
			Class<?> c = tunnelTable.getClass();
			List<String> items = Arrays.asList(tunnelTable.getMODULODOSIF().split(";"));
			int totalDosingModules = tunnelTable.getNUMMODULOSDOSIF();
			for (int i = 1; i <= totalDosingModules; i++) {
			    Method main = c.getDeclaredMethod("getPRODUCTOSMODULO" + i);
			    String prodModVal = (String) main.invoke(tunnelTable);
			    String[] products = prodModVal.split(";");

			    for (String productId : products) {
				tunnelModProd.add(tunnel.getTunnelId() + "_" + items.get(i - 1) + "_" + productId);
			    }

			}

			database.setAutoCommitFalse();
			database.addBatch(query, params);
		    }
		    result = database.executeBatch();
		    if (result == null || result.length < 0) {
			throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		    for (int i = 0; i < result.length; i++) {
			if (result[i] < 0) {
			    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
			}
		    }

		    query = SQLConstants.INSERT_INTO_TUNNEL_MODULE_PRODUCT_ASSOCIATION;
		    // INSERT_INTO_TUNNEL_MODULE_PRODUCT_ASSOCIATION = "INSERT
		    // into TUNNEL_MODULE_PRODUCT_ASSOCIATION(id, tunnel_id,
		    // module_id, product_id, created_by,
		    // modified_by,created_date,modified_date)
		    // value(?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
		    LOG.debug("query>>>>" + query);

		    database.setAutoCommitFalse();
		    database.createBatch(query);

		    for (String record : tunnelModProd) {
			String[] data = record.split("_");
			params = new LinkedList<>();
			params.add(CommonUtils.guidGenerator(null, null));
			params.add(data[0]);
			params.add(data[1]);
			params.add(data[2]);
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
			params.add(userDTO.getFirstName() + " " + userDTO.getLastName());

			database.setAutoCommitFalse();
			database.addBatch(query, params);
		    }
		    result = database.executeBatch();
		    if (result == null || result.length < 0) {
			throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		    for (int i = 0; i < result.length; i++) {
			if (result[i] < 0) {
			    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
			}
		    }

		    for (EquipmentWrapperDTO tunnelProducts : tunnelList) {

			TablaTuneles ProductDetails = tunnelProducts.getTunnels();
			// INSERT into TUNNEL_PRODUCTS_MASTER(tunnel_id,
			// product_id, product_name, product_value)
			// value(?,?,?,?)

			query = SQLConstants.INSERT_INTO_TUNNEL_PRODUCTS;
			LOG.debug("query>>>>" + query);
			database.createBatch(query);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(tunnelProducts.getTunnelId());
			params.add(uuid);
			params.add(Constants.PRODUCT_MODULO.PRODUCTOS_MODULO1);
			params.add(ProductDetails.getPRODUCTOSMODULO1());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(tunnelProducts.getTunnelId());
			params.add(uuid);
			params.add(Constants.PRODUCT_MODULO.PRODUCTOS_MODULO2);
			params.add(ProductDetails.getPRODUCTOSMODULO2());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(tunnelProducts.getTunnelId());
			params.add(uuid);
			params.add(Constants.PRODUCT_MODULO.PRODUCTOS_MODULO3);
			params.add(ProductDetails.getPRODUCTOSMODULO3());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(tunnelProducts.getTunnelId());
			params.add(uuid);
			params.add(Constants.PRODUCT_MODULO.PRODUCTOS_MODULO4);
			params.add(ProductDetails.getPRODUCTOSMODULO4());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(tunnelProducts.getTunnelId());
			params.add(uuid);
			params.add(Constants.PRODUCT_MODULO.PRODUCTOS_MODULO5);
			params.add(ProductDetails.getPRODUCTOSMODULO5());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(tunnelProducts.getTunnelId());
			params.add(uuid);
			params.add(Constants.PRODUCT_MODULO.PRODUCTOS_MODULO6);
			params.add(ProductDetails.getPRODUCTOSMODULO6());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(tunnelProducts.getTunnelId());
			params.add(uuid);
			params.add(Constants.PRODUCT_MODULO.PRODUCTOS_MODULO7);
			params.add(ProductDetails.getPRODUCTOSMODULO7());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(tunnelProducts.getTunnelId());
			params.add(uuid);
			params.add(Constants.PRODUCT_MODULO.PRODUCTOS_MODULO8);
			params.add(ProductDetails.getPRODUCTOSMODULO8());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(tunnelProducts.getTunnelId());
			params.add(uuid);
			params.add(Constants.PRODUCT_MODULO.PRODUCTOS_MODULO9);
			params.add(ProductDetails.getPRODUCTOSMODULO9());
			database.addBatch(query, params);

			params = new LinkedList<>();
			uuid = CommonUtils.guidGenerator(null, null);
			params.add(tunnelProducts.getTunnelId());
			params.add(uuid);
			params.add(Constants.PRODUCT_MODULO.PRODUCTOS_MODULO10);
			params.add(ProductDetails.getPRODUCTOSMODULO10());
			database.addBatch(query, params);

			result = database.executeBatch();
			if (result != null && result.length > 0) {
			    for (int j = 0; j < result.length; j++) {
				if (result[j] == 0) {
				    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
					    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					    null);
				}
			    }
			}

		    }

		    lm2Sequence++;
		}
	    }

	    database.commit();

	    return equipFiles;
	    // return true;
	} catch (

	SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

    }

    public static void insertEsErrorLog(EsErrorLogDTO errorLogDTO, UserDTO userDTO) throws Exception {

	Database database = null;
	try {

	    String query = SQLConstants.INSERT_ES_ERROR_LOG;
	    // "INSERT into ES_ERROR_LOG(error_id, site_id, file_id,
	    // description, error_type, es_error, index_name, es_document,
	    // created_by, created_date, modified_by, modified_date, version,
	    // es_type, month, year) values(?,?,?,?,?,?,?,?,?, utc_timestamp,?,
	    // utc_timestamp,?,?,?,?)"
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    String uuid = CommonUtils.guidGenerator(null, null);
	    params.add(uuid);
	    params.add(errorLogDTO.getSiteId());
	    params.add(errorLogDTO.getFileId());
	    params.add(errorLogDTO.getDescription());
	    params.add(errorLogDTO.getErrorType());
	    params.add(errorLogDTO.getEsError());
	    params.add(errorLogDTO.getIndexName());
	    params.add(errorLogDTO.getEsDocument());
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    params.add(errorLogDTO.getEsType());
	    params.add(errorLogDTO.getMonth());
	    params.add(errorLogDTO.getYear());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));

	    }
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

    }

    public String companyIdExists(String companyId) throws Exception {

	Database database = null;
	try {
	    String query = SQLConstants.BUSINESS_ID_EXISTS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.BusinessTypes.COMPANY);
	    params.add(companyId);
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.BUSINESS_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }

    public boolean updateSite(UserDTO user, SiteDTO siteDTO, boolean siteFullEditCheck) throws Exception {
	Database database = null;
	String query = SQLConstants.Company.partial.UPDATE_SITE;
	if (siteFullEditCheck)
	    query = SQLConstants.HydroAdmin.UPDATE_SITE;
	try {
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(siteDTO.getSiteName());
	    params.add(siteDTO.getAddress1());
	    params.add(siteDTO.getAddress2());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(siteDTO.getState());
	    params.add(siteDTO.getCountry());
	    params.add(siteDTO.getCity());
	    params.add(siteDTO.getZipCode());
	    params.add(siteDTO.getDescription());
	    params.add(siteDTO.getMetricUnit());
	    if (siteFullEditCheck) {
		params.add(siteDTO.getAccountId());
		params.add(siteDTO.getCompanyId());
	    }
	    params.add(siteDTO.getWasherTurnMinute());
	    params.add(siteDTO.getWasherIdleMinute());
	    params.add(siteDTO.getWasherEffThreshold());
	    params.add(siteDTO.getTunnelTurnMinute());
	    params.add(siteDTO.getTunnelIdleMinute());
	    params.add(siteDTO.getTunnelEffThreshold());
	    params.add(siteDTO.getTimeZone());
	    params.add(siteDTO.getAlertSetting());
	    params.add(siteDTO.isStreamingEnabled());
	    params.add(siteDTO.getSiteId());
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    if (count > 0) {
		siteDTO = updateContact(siteDTO, database, user);
		updateShift(siteDTO, database, user);
		query = SQLConstants.CHECK_SITE_PREFERENCE;
		LOG.debug("query>>>>" + query);
		params = new LinkedList<>();
		String siteId = siteDTO.getSiteId();
		params.add(siteId);
		ResultSet rSet = database.executeQuery(query, params);
		if (rSet.next()) {
		    if (siteDTO.getCompanyId() != null
			    && !rSet.getString(SQLColumns.BUSINESS_ID).equals(siteDTO.getCompanyId())) {
			// Delete site entry from user_site_association table.
			query = SQLConstants.DELETE_USER_SITE_ASSOCIATION;
			params = new LinkedList<>();
			params.add(siteId);
			int counter = database.executeUpdate(query, params);
			query = SQLConstants.DELETE_PREFERENCE_DETAILS;
			params = new LinkedList<>();
			params.add(siteId);
			counter = database.executeUpdate(query, params);
			if (counter > 0) {
			    CompanyDTO company = CompanyDao.getCompanyPreferenceDetails(user, siteDTO.getCompanyId());
			    CompanyDao.createPreference(company, database, user, siteId);

			}
		    }

		} else {
		    if (CompanyDao.checkCompanyPreferenceExist(siteDTO.getCompanyId())) {
			CompanyDTO company = CompanyDao.getCompanyPreferenceDetails(user, siteDTO.getCompanyId());
			CompanyDao.createPreference(company, database, user, siteId);
		    }
		}
	    }
	    database.commit();
	    return true;
	} catch (

	SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static HashSet<String> getShiftAssociatedToSite(SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_SHIFT_DETAILS_FOR_SITE;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(site.getSiteId());
	    HashSet<String> ContactIdSet = new HashSet<>();
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    while (rs.next()) {
		ContactIdSet.add(rs.getString(SQLColumns.SHIFT_ID));
	    }
	    return ContactIdSet;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static List<ShiftDTO> getShiftDetailsForSite(SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_SHIFT_DETAILS_FOR_SITE;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(site.getSiteId());
	    List<ShiftDTO> shiftList = new LinkedList<>();
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    int count = 0;
	    while (rs.next()) {
		count = count + 1;
		ShiftDTO shift = new ShiftDTO();
		shift.setShiftId(rs.getString(SQLColumns.SHIFT_ID));
		shift.setShiftName(rs.getString(SQLColumns.SHIFT_NAME));
		shift.setStartTime(rs.getString(SQLColumns.START_TIME));
		shift.setEndTime(rs.getString(SQLColumns.END_TIME));
		shiftList.add(shift);
	    }
	    if (site.getDefaultShift()) {
		ConfigReader config = new ConfigReader();
		ShiftDTO shift = new ShiftDTO();
		shift.setShiftId("");
		shift.setShiftName(config.getAppConfig(Constants.DEFAULT_SHIFT));
		shift.setStartTime(config.getAppConfig(Constants.DEFAULT_SHIFT_START_TIME));
		shift.setEndTime(config.getAppConfig(Constants.DEFAULT_SHIFT_END_TIME));
		shiftList.add(shift);
		if (count > 0) {
		    shift = new ShiftDTO();
		    shift.setShiftId("");
		    shift.setShiftName(Constants.OFF_SHIFT);
		    shiftList.add(shift);
		}
	    }
	    return shiftList;
	} catch (SystemException e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    try {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    protected void updateShift(SiteDTO siteDTO, Database database, UserDTO user) throws Exception {
	String query = SQLConstants.HydroAdmin.DELETE_SHIFT_FOR_SITE;
	LinkedList<Object> params = new LinkedList<>();
	params.add(siteDTO.getSiteId());
	int count = database.executeUpdate(query, params);
	List<ShiftDTO> shiftCreate = siteDTO.getShiftList();
	if (count >= 0 && shiftCreate != null && shiftCreate.size() >= 0) {
	    query = SQLConstants.HydroAdmin.CREATE_SHIFT;
	    LOG.debug("query>>>>" + query);
	    // INSERT INTO SHIFT_MASTER(site_id,shift_id,
	    // shift_name,start_time,end_time,created_by,
	    // modified_by,created_date,modified_date)
	    // values(?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)"
	    database.createBatch(query);
	    for (ShiftDTO shiftDTO : shiftCreate) {
		String uuid = CommonUtils.guidGenerator(null, null);
		params = new LinkedList<>();
		params.add(siteDTO.getSiteId());
		params.add(uuid);
		params.add(shiftDTO.getShiftName());
		params.add(shiftDTO.getStartTime());
		params.add(shiftDTO.getEndTime());
		params.add(user.getFirstName() + " " + user.getLastName());
		params.add(user.getFirstName() + " " + user.getLastName());
		database.addBatch(query, params);
	    }
	    int[] result = database.executeBatch();
	    if (result != null && result.length > 0) {
		for (int i = 0; i < result.length; i++) {
		    if (result[i] != 1) {
			throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		}
	    }
	}
    }

    protected SiteDTO updateContact(SiteDTO siteDTO, Database database, UserDTO user) throws Exception {
	ContactOperationsDTO contactOperations = siteDTO.getContactOperations();
	if (contactOperations != null) {
	    HashSet<String> contactIdList = null;
	    List<ContactDTO> contactUpdate = contactOperations.getUpdateContact();
	    if (contactUpdate != null && contactUpdate.size() > 0) {
		contactIdList = SiteDao.getContactAssociatedToSite(siteDTO);
		for (ContactDTO contact : contactUpdate) {
		    if (!contactIdList.contains(contact.getContactId())) {
			throw new SystemException(ErrorCodes.INVALID_CONTACT_ID,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST, null);
		    }
		    String query = SQLConstants.HydroAdmin.UPDATE_CONTACT_INFO;
		    LOG.debug("query>>>>" + query);
		    LinkedList<Object> params = new LinkedList<>();
		    database.createBatch(query);

		    for (ContactDTO contactDTO : contactUpdate) {
			// UPDATE CONTACT_MASTER SET contact_email =?,
			// contact_name=?, contact_number = ?,
			// contact_title =
			// ?, modified_by =? WHERE contact_id=?
			params = new LinkedList<>();
			params.add(contactDTO.getEmail());
			params.add(contactDTO.getName());
			params.add(contactDTO.getNumber());
			params.add(contactDTO.getTitle());
			params.add(user.getFirstName() + " " + user.getLastName());
			params.add(contactDTO.getContactId());
			database.addBatch(query, params);
		    }
		    int[] result = database.executeBatch();
		    if (result != null && result.length > 0) {
			for (int i = 0; i < result.length; i++) {
			    if (result[i] != 1) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }
			}
		    }
		}
	    }
	    // Check if contactId is associated to site.
	    List<ContactDTO> contactDelete = contactOperations.getDeleteContact();
	    if (contactDelete != null && contactDelete.size() > 0) {
		if (contactIdList == null) {
		    contactIdList = SiteDao.getContactAssociatedToSite(siteDTO);
		}
		for (ContactDTO contact : contactDelete) {
		    if (!contactIdList.contains(contact.getContactId())) {
			throw new SystemException(ErrorCodes.INVALID_CONTACT_ID,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST, null);
		    }
		    LinkedList<Object> params = new LinkedList<>();
		    String query = SQLConstants.HydroAdmin.DELETE_CONTACT_INFO + " ( "
			    + CommonUtils.generateQueryParams(contactDelete.size()) + " )";
		    LOG.debug("query>>>>" + query);
		    for (ContactDTO contactDTO : contactDelete) {
			params.add(contactDTO.getContactId());
		    }

		    int countDelete = database.executeUpdate(query, params);
		    if (countDelete < 0) {
			throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }

		}
	    }

	    // Inserting new Contact Details.
	    List<ContactDTO> contactCreate = contactOperations.getCreateContact();
	    if (contactCreate != null && contactCreate.size() > 0) {
		String query = SQLConstants.HydroAdmin.CREATE_CONTACT_INFO;
		LOG.debug("query>>>>" + query);

		// INSERT INTO
		// CONTACT_MASTER(contact_id,business_id,
		// site_id,email,name, number, title,created_by,
		// modified_by) values(?,?,?,?,?,?,?,?,?)
		LinkedList<Object> params = new LinkedList<>();
		database.createBatch(query);
		for (ContactDTO contactDTO : contactCreate) {
		    String uuid = CommonUtils.guidGenerator(null, null);
		    params = new LinkedList<>();
		    params.add(uuid);
		    params.add(null);
		    params.add(siteDTO.getSiteId());
		    params.add(contactDTO.getEmail());
		    params.add(contactDTO.getName());
		    params.add(contactDTO.getNumber());
		    params.add(contactDTO.getTitle());
		    params.add(user.getFirstName() + " " + user.getLastName());
		    params.add(user.getFirstName() + " " + user.getLastName());
		    database.addBatch(query, params);
		}
		int[] result = database.executeBatch();
		if (result != null && result.length > 0) {
		    for (int i = 0; i < result.length; i++) {
			if (result[i] != 1) {
			    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
			}
		    }
		}

	    }

	}
	return siteDTO;
    }

    public static boolean checkSitePreferenceExist(String siteId) throws SystemException, Exception {
	Database database = null;
	try {
	    String query = SQLConstants.CHECK_SITE_PREFERENCE;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(siteId);
	    ResultSet rSet = database.executeQuery(query, params);
	    if (rSet.next()) {
		return true;
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static String getDeviceIdForEquipment(String equipmentId) throws SystemException, Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_DEVICE_ID_FOR_EQUIPMENT;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(equipmentId);
	    ResultSet rSet = database.executeQuery(query, params);
	    if (rSet.next()) {
		return rSet.getString(SQLColumns.DEVICE_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public int getLm2Sequence(String deviceid) throws SystemException, Exception {
	Database database = null;
	int lm2seq = 0;
	try {
	    String query = SQLConstants.GET_TUNNEL_DETAIL_FOR_DEVICE;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> parameters = new LinkedList<>();
	    parameters.add(deviceid);
	    ResultSet tunnelResult = database.executeQuery(query, parameters);

	    if (tunnelResult.next()) {
		lm2seq = tunnelResult.getInt(SQLColumns.LM2_SEQ);
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Error while closing db connection : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
	return lm2seq;
    }

    public int getJSONConfigUploadCount(String siteId, String unitId) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.JsonParsing.GET_CONFIG_UPLOAD_COUNT;
	    // "SELECT count(site_id) as config_upload_count FROM hydro.FILE_MASTER where
	    // site_id =? and file_type = ?"
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(siteId);
	    params.add(Constants.FILE_TYPE.CONFIG_JSON);
	    params.add(unitId);
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    int count = 0;
	    if (rs.next()) {
		count = rs.getInt(SQLColumns.CONFIG_UPLOAD_COUNT);
	    }
	    return count;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public int getJSONFormulaConfigUploadCount(String siteId, String unitId) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.JsonParsing.GET_CONFIG_UPLOAD_COUNT;
	    // "SELECT count(site_id) as config_upload_count FROM hydro.FILE_MASTER where
	    // site_id =? and file_type = ?"
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(siteId);
	    params.add(Constants.FILE_TYPE.FORMULA_JSON);
	    params.add(unitId);
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    int count = 0;
	    if (rs.next()) {
		count = rs.getInt(SQLColumns.CONFIG_UPLOAD_COUNT);
	    }
	    return count;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public boolean uploadJsonFileTODB(byte[] content, SiteDTO site, FileDTO file, UserDTO userDTO, String dataType,
	    String unitId) throws Exception {
	Database database = null;
	try {
	    database = new Database();
	    String query = SQLConstants.JsonParsing.UPDATE_JSONFILE;
	    // UPDATE FILE_MASTER set status=?, description=?, file_type=?, version=?,
	    // lm2_file=?, modified_by=?, modified_date=utc_timestamp where file_id=?
	    LOG.debug("query>>>>" + query);
	    int version = 0;
	    LinkedList<Object> params = new LinkedList<>();
	    InputStream inputStreamForDB = new ByteArrayInputStream(content);
	    params.add(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.UPLOADED));
	    if (dataType.equalsIgnoreCase(Constants.DATA_TYPE.CONFIG)) {
		params.add(Constants.CONFIG_JSON);
		params.add(Constants.FILE_TYPE.CONFIG_JSON);
		version = getJSONConfigUploadCount(site.getSiteId(), unitId) + 1;
		params.add(version);
	    } else {
		params.add(Constants.FORMULA_JSON);
		params.add(Constants.FILE_TYPE.FORMULA_JSON);
		version = getJSONFormulaConfigUploadCount(site.getSiteId(), unitId) + 1;
		params.add(version);
	    }
	    // find version no. of LM2 file.
	    params.add(inputStreamForDB);
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    params.add(file.getFileId());
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    inputStreamForDB = null;
	    return true;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public HashMap<String, HashMap<String, String>> parsingConfigFile(MasterConfigDTO configJson, FileDTO file,
	    UserDTO userDTO, String unitId) throws Exception {
	Database database = null;
	HashMap<String, HashMap<String, String>> unitDetails = null;
	try {
	    database = new Database();
	    database.setAutoCommitFalse();
	    UnitDTO unitDTO = configJson.getUnit();
	    if (unitDTO != null && unitDTO.getIp() != null) {
		unitDetails = getDeviceDetails(file, unitDTO, userDTO, database);
		if (unitDetails != null && !unitDetails.isEmpty()) {
		    String equipmentId = CommonUtils.guidGenerator(null, null);
		    // insert into equipment master
		    int washerCount = createEquipmentEntries(unitDTO, database, equipmentId, userDTO, file,
			    unitDetails);
		    // insert into channel master
		    createChannelEntries(configJson.getChannels(), database, equipmentId);
		    // insert into water master
		    createWaterMEntries(configJson.getWater(), database, equipmentId, userDTO, unitId);
		    // insert into product master
		    createProductMEntries(configJson.getProducts(), database, equipmentId, userDTO);
		    // insert into washer master
		    createWasherMEntries(configJson.getMachines(), database, equipmentId, userDTO, washerCount, unitId);
		}
	    }
	    database.commit();
	    return unitDetails;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}

    }

    public void parsingFormulaJSONFile(FormulaConfig configJson, FileDTO file, UserDTO userDTO, String equipmentId,
	    String unitId) throws Exception {
	Database database = null;
	try {
	    database = new Database();
	    database.setAutoCommitFalse();
	    // delete if any existing formula entries are present in DB
	    if (setForeignKeyConstraint(database)) {
		deleteExistingFormulaForEquipment(equipmentId, database);
	    }
	    // get the equipment_id for the unit which is active , as against this equipment
	    // only entries should be created in formula master
	    // create formula master entries.
	    updateUnitId(file.getFileId(), unitId, database);
	    createFormulaMEntries(configJson.getFormulas(), database, equipmentId, userDTO);
	    database.commit();
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}

    }

    protected HashMap<String, HashMap<String, String>> getDeviceDetails(FileDTO file, UnitDTO unitDTO, UserDTO userDTO,
	    Database database) throws Exception {
	HashMap<String, HashMap<String, String>> equipFiles = null;
	try {
	    ConfigReader configReader = new ConfigReader();
	    String query = SQLConstants.JsonParsing.INSERT_INTO_FILE_MASTER;
	    equipFiles = new HashMap<String, HashMap<String, String>>();
	    String deviceId = configReader.getDeviceIdUsingSiteIdIpAddress(file.getSiteId(), unitDTO.getIp());

	    if (deviceId == null) {
		LOG.debug("finding Device for SiteID::" + file.getSiteId() + ":IP:::" + unitDTO.getIp());
		String uri = configReader.getAppConfig(Constants.SEARCH_SERVICE_URL).concat("/");
		String tempId = CommonUtils.guidGenerator(null, null);
		String reqBody = ReportUtils.getQuery("DeviceCreate.json");

		SiteDTO sitedto = new SiteDTO();
		sitedto.setSiteId(file.getSiteId());

		String siteName = getSiteDetails(sitedto).getSiteName();
		reqBody = reqBody.replace("SERIAL-NO", "NEEDS_UPDATE_" + tempId);
		reqBody = reqBody.replace("SITE-ID", file.getSiteId());
		reqBody = reqBody.replace("DEVICE-NAME", siteName + "_" + unitDTO.getName().trim());
		reqBody = reqBody.replace("IP-ADDRESS", unitDTO.getIp().trim());
		reqBody = reqBody.replace("TEMP-ID", tempId);

		LOG.debug("Device creation request body::" + reqBody);

		CommonUtils.disableSslVerification();
		try {
		    String response = CommonUtils.doPost(uri, reqBody);
		    deviceId = tempId;
		} catch (Exception exp) {
		    throw new SystemException(ErrorCodes.DEVICE_CREATION_FAILED,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}

	    }
	    LOG.debug("device Id ::" + deviceId);
	    LinkedList<Object> params = new LinkedList<>();
	    params = new LinkedList<>();
	    params.add(file.getFileId() + "_" + unitDTO.getId());
	    params.add(file.getName());
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    params.add(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.SUCCESS));
	    params.add(file.getSiteId());
	    params.add(unitDTO.getName().trim());
	    params.add("Config json upload");
	    params.add(file.getVersion());
	    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	    params.add(Constants.FILE_TYPE.CONFIG_JSON);
	    params.add(deviceId);
	    params.add(1);
	    params.add(unitDTO.getUnit_id());

	    HashMap<String, String> eFileMap = new HashMap<String, String>();
	    eFileMap.put(Constants.FILE_ID, file.getFileId() + "_" + unitDTO.getId());
	    eFileMap.put(Constants.DESCRIPTION, Constants.CONFIG_DEVICE);
	    eFileMap.put(Constants.DEVICE_ID, deviceId);
	    equipFiles.put(unitDTO.getId(), eFileMap);
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (ResourceAccessException e) {
	    throw new SystemException(ErrorCodes.DEVICE_MGMT_CONNECTION_TIMED_OUT,
		    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    e.printStackTrace();
	}
	return equipFiles;
    }

    public FileDTO getFileStatus(FileDTO file, String status, String errorCode, HashMap<String, String> errorConfig,
	    String detailedDescription) throws Exception {
	file.setStatus(status);
	file.setDescription(errorCode);
	if (errorConfig != null) {
	    file.setDescription(errorCode, errorConfig);
	}
	file.setDetailedDescription(detailedDescription);
	return file;
    }

    protected void createChannelEntries(List<ChannelDTO> channelList, Database database, String equipmentId)
	    throws Exception {
	String query = SQLConstants.JsonParsing.INSERT_INTO_CHANNEL_MASTER;
	LOG.info("Inserting into channel master, query used:: " + query);
	LinkedList<Object> params;
//	    INSERT into channel_master(channel_id, uid, alarms_skipped,   
//	    alarms_tolerance, date_last_change, dosing_mode, flush_air_ml, 
//	    flush_air_time, flush_type, `name`, pump_type, water_test, equipment_id)
	database.createBatch(query);
	if (channelList != null) {
	    for (ChannelDTO channelDTO : channelList) {
		params = new LinkedList<>();
		params.add(CommonUtils.guidGenerator(null, null));
		params.add(channelDTO.getUid());
		params.add(channelDTO.getAlarms_skipped());
		params.add(channelDTO.getAlarms_tolerance());
		params.add(channelDTO.getDate_last_change());
		params.add(channelDTO.getDosing_mode());
		params.add(channelDTO.getFlush_air_ml());
		params.add(channelDTO.getFlush_air_time());
		params.add(channelDTO.getFlush_type());
		params.add(channelDTO.getName());
		params.add(channelDTO.getPump_type());
		params.add(channelDTO.getWater_test());
		params.add(equipmentId);
		database.addBatch(query, params);
	    }
	    int[] result = database.executeBatch();
	    if (result == null || result.length < 0) {
		throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (int i = 0; i < result.length; i++) {
		if (result[i] < 0) {
		    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }
	}
    }

    protected void createWaterMEntries(List<WaterDTO> waterList, Database database, String equipmentId, UserDTO userDTO,
	    String unitId) throws Exception {
	String query = SQLConstants.JsonParsing.INSERT_INTO_WATER_MASTER;
	LOG.info("Inserting into water master, query used:: " + query);
	LinkedList<Object> params;
//	    water_id, equipment_id, kf, lm2_seq, flow,uid, channel, date_calibration, date_last_change, created_by, modified_by, created_date, modified_date
	database.createBatch(query);
	if (waterList != null) {
	    for (WaterDTO waterDTO : waterList) {
		params = new LinkedList<>();
		String uid = waterDTO.getUid();
		params.add(CommonUtils.guidGenerator(null, null));
		params.add(equipmentId);
		params.add(waterDTO.getKf());
		params.add(CommonUtils.generateLm2Seq(unitId, uid));
		params.add(waterDTO.getFlow_rate());
		params.add(uid);
		params.add(waterDTO.getChannel());
		params.add(waterDTO.getDate_calibration());
		params.add(waterDTO.getDate_last_change());
		params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		database.addBatch(query, params);
	    }
	    int[] result = database.executeBatch();
	    if (result == null || result.length < 0) {
		throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (int i = 0; i < result.length; i++) {
		if (result[i] < 0) {
		    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }
	}
    }

    protected int createEquipmentEntries(UnitDTO unitDTO, Database database, String equipmentId, UserDTO userDTO,
	    FileDTO file, HashMap<String, HashMap<String, String>> unitDetails) throws Exception {
	String query = SQLConstants.JsonParsing.INSERT_INTO_EQUIPMENT_MASTER;
//	    Insert into EQUIPMENT_MASTER(equipment_id, lm2_seq, site_id, alias, equipment_type,
//	    ip_address, washer_count, version, file_id, device_id, unit_id, 
//	    warning_level, revision, start_up_date, date_power_on, `language`, 
//	    units_system, products_channel_1, products_channel_2, products_channel_3,
//	    date_reset_statistics, date_last_sync, date_last_estadisticas_sync, 
//	    `checksum`, first_conf_upload, first_formulas_upload, call_center, 
//	    email, report_period, warning_cycles, warning_water, warning_product, 
//	    created_by, created_date, modified_by, modified_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp,?)"
	LOG.debug("query>>>>" + query);
	LinkedList<Object> params = new LinkedList<>();
	params.add(equipmentId);
	params.add(unitDTO.getId());
	params.add(file.getSiteId());
	params.add(unitDTO.getName());
	params.add(unitDTO.getUnit_type());
	params.add(unitDTO.getIp());
	params.add(unitDTO.getWasher_extractors());
	params.add(unitDTO.getVersion());
	params.add(unitDetails.get(unitDTO.getId()).get(Constants.FILE_ID));
	params.add(unitDetails.get(unitDTO.getId()).get(Constants.DEVICE_ID));
	params.add(unitDTO.getUnit_id());
	params.add(unitDTO.getWarning_level());
	params.add(unitDTO.getRevision());
	params.add(unitDTO.getStart_up_date());
	params.add(unitDTO.getDate_power_on());
	params.add(unitDTO.getLanguage());
	params.add(unitDTO.getUnits_system());
	params.add(unitDTO.getProducts_channel_1());
	params.add(unitDTO.getProducts_channel_2());
	params.add(unitDTO.getProducts_channel_3());
	params.add(unitDTO.getDate_reset_statistics());
	params.add(unitDTO.getDate_last_sync());
	params.add(unitDTO.getDate_last_estadisticas_sync());
	params.add(unitDTO.getChecksum());
	params.add(unitDTO.getFirst_conf_upload());
	params.add(unitDTO.getFirst_formulas_upload());
	params.add(unitDTO.getCall_center());
	params.add(unitDTO.getEmail());
	params.add(unitDTO.getReport_period());
	params.add(unitDTO.getWarning_cycles());
	params.add(unitDTO.getWarning_water());
	params.add(unitDTO.getWarning_product());
	params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
	int washerCount = Integer.parseInt(unitDTO.getWasher_extractors());
	int count = database.executeUpdate(query, params);
	if (count <= 0) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
	return washerCount;
    }

    protected void createProductMEntries(List<ProductConfigDTO> productList, Database database, String equipmentId,
	    UserDTO userDTO) throws Exception {
	String query = SQLConstants.JsonParsing.INSERT_INTO_PRODUCT_MASTER;
	LOG.info("Inserting into product master, query used:: " + query);
	LinkedList<Object> params;
//	   INSERT into product_master(product_id, equipment_id, lm2_seq, name,
//	density, concentration, kf, flow, priority, contact, alarms_ignored,
//	price, calibration, created_by,  modified_by,  uid, alarms_tolerance,
//	date_last_change, dosing_mode, estate, pump_safe_stop, rotameter_sensor, 
//	statistic_production, statistic_warnings,created_date,modified_date)

	database.createBatch(query);
	if (productList != null) {
	    for (ProductConfigDTO productDTO : productList) {
		params = new LinkedList<>();
		params.add(CommonUtils.guidGenerator(null, null));
		params.add(equipmentId);
		params.add(productDTO.getId());
		params.add(productDTO.getName());
		params.add(productDTO.getDensity());
		params.add(productDTO.getConcentration());
		params.add(productDTO.getKf());
		params.add(productDTO.getFlow_rate());
		params.add(productDTO.getPriority());
		params.add(productDTO.getAlarms_contact());
		params.add(productDTO.getAlarms_skipped());
		params.add(productDTO.getPrice());
		params.add(productDTO.getDate_calibration());
		params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		params.add(productDTO.getUid());
		params.add(productDTO.getAlarms_tolerance());
		params.add(productDTO.getDate_last_change());
		params.add(productDTO.getDosing_mode());
		params.add(productDTO.getEstate());
		params.add(productDTO.getPump_safe_stop());
		params.add(productDTO.getRotameter_sensor());
		params.add(productDTO.getStatistic_production());
		params.add(productDTO.getStatistic_warnings());
		database.addBatch(query, params);
	    }
	    int[] result = database.executeBatch();
	    if (result == null || result.length < 0) {
		throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (int i = 0; i < result.length; i++) {
		if (result[i] < 0) {
		    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }
	}
    }

    protected void createWasherMEntries(List<MachineDTO> machineList, Database database, String equipmentId,
	    UserDTO userDTO, int washerCount, String unitId) throws Exception {
	String query = SQLConstants.JsonParsing.INSERT_INTO_WASHER_MASTER;
	LOG.info("Inserting into washer master, query used:: " + query);
	LinkedList<Object> params;
//	   INSERT into washer_master(washer_id, equipment_id, lm2_seq, name, `load`, 
//	id_formula, t_acceptation, t_repetition, t_lock, created_by, modified_by, 
//	uid, date_last_change, end_formula, end_mode, end_signal_pump, flush_l, 
//	hold_delay, hold_mode, hold_timeout, kg_sel, trigger_mode,created_date,modified_date)

	database.createBatch(query);
	if (machineList != null) {
	    int count = 1;
	    for (MachineDTO machineDTO : machineList) {
		if (count <= washerCount) {
		    params = new LinkedList<>();
		    String uid = machineDTO.getUid();
		    params.add(CommonUtils.guidGenerator(null, null));
		    params.add(equipmentId);
		    params.add(CommonUtils.generateLm2Seq(unitId, uid));
		    params.add(machineDTO.getName());
		    params.add(machineDTO.getKg());
		    params.add(machineDTO.getFormula_id());
		    params.add(machineDTO.getTime_acceptance());
		    params.add(machineDTO.getTime_repetition());
		    params.add(machineDTO.getTime_lock());
		    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		    params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		    params.add(uid);
		    params.add(machineDTO.getDate_last_change());
		    params.add(machineDTO.getEnd_formula());
		    params.add(machineDTO.getEnd_mode());
		    params.add(machineDTO.getEnd_signal_pump());
		    params.add(machineDTO.getFlush_l());
		    params.add(machineDTO.getHold_delay());
		    params.add(machineDTO.getHold_mode());
		    params.add(machineDTO.getHold_timeout());
		    params.add(machineDTO.getKg_sel());
		    params.add(machineDTO.getTrigger_mode());
		    database.addBatch(query, params);
		    count++;
		}
	    }
	    int[] result = database.executeBatch();
	    if (result == null || result.length < 0) {
		throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (int i = 0; i < result.length; i++) {
		if (result[i] < 0) {
		    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }
	}
    }

    public String getEquipmentForUnit(String siteId, String unitId) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.JsonParsing.GET_EQUIPMENT_ASSOCIATED_TO_UNIT;
	    // select equipment_id from equipment_master where file_id = (SELECT file_id
	    // FROM FILE_MASTER where site_id =? and file_type = ? and unit_id = ? and
	    // is_active = ?)"
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(siteId);
	    params.add(Constants.FILE_TYPE.CONFIG_JSON);
	    params.add(unitId);
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.EQUIPMENT_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    protected void createFormulaMEntries(List<FormulaDTO> formulaList, Database database, String equipmentId,
	    UserDTO userDTO) throws Exception {
	String query = SQLConstants.JsonParsing.INSERT_INTO_FORMULA_MASTER;
	LOG.info("Inserting into formula master, query used:: " + query);
	LinkedList<Object> params;
	Map<String, String> formulaMap = new HashMap<>();
	database.createBatch(query);
//	    INSERT into formula_master(formula_id, equipment_id, lm2_seq, name, phases, created_by, 
//	modified_by,uid, percentage, date_last_change, used_phases, statistic_production, updated,modified_date,created_date) 
	if (formulaList != null) {
	    for (FormulaDTO formulaDTO : formulaList) {
		params = new LinkedList<>();
		String formulaId = CommonUtils.guidGenerator(null, null);
		params.add(formulaId);
		params.add(equipmentId);
		params.add(formulaDTO.getId());
		params.add(formulaDTO.getName());
		params.add(formulaDTO.getFormulas_phases().size());
		params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		params.add(userDTO.getFirstName() + " " + userDTO.getLastName());
		params.add(formulaDTO.getUid());
		params.add(formulaDTO.getPercentage());
		params.add(formulaDTO.getDate_last_change());
		params.add(formulaDTO.getUsed_phases());
		params.add(formulaDTO.getStatistic_production());
		params.add(formulaDTO.getUpdated());
		formulaMap.put(formulaDTO.getUid(), formulaId);
		database.addBatch(query, params);
	    }
	    int[] result = database.executeBatch();
	    if (result == null || result.length < 0) {
		throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (int i = 0; i < result.length; i++) {
		if (result[i] < 0) {
		    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }
	    createFormulaPhaseEntries(formulaList, database, equipmentId, formulaMap);
	}
    }

    protected void createFormulaPhaseEntries(List<FormulaDTO> formulaList, Database database, String equipmentId,
	    Map<String, String> formulaMap) throws Exception {
	String query = SQLConstants.JsonParsing.INSERT_INTO_FORMULA_PHASE;
	LOG.info("Inserting into formula master, query used:: " + query);
	Map<String, String> fPhaseMap = new HashMap<>();
	LinkedList<Object> params;
//	    INSERT into formula_phases(f_phase_id, id, id_formula, num_phase, delay_1, delay_2, uid, equipment_id, formula_id) values(?,?,?,?,?,?,?,?,?)"
	database.createBatch(query);
	if (formulaList != null) {
	    for (FormulaDTO formulaMDTO : formulaList) {
		for (FormulaPhaseDTO formulaDTO : formulaMDTO.getFormulas_phases()) {
		    params = new LinkedList<>();
		    String phaseId = CommonUtils.guidGenerator(null, null);
		    params.add(phaseId);
		    params.add(formulaDTO.getId());
		    params.add(formulaDTO.getId_formula());
		    params.add(formulaDTO.getNum_phase());
		    params.add(formulaDTO.getDelay_1());
		    params.add(formulaDTO.getDelay_2());
		    params.add(formulaDTO.getUid());
		    params.add(equipmentId);
		    params.add(formulaMap.get(formulaMDTO.getUid()));
		    fPhaseMap.put(formulaDTO.getUid(), phaseId);
		    database.addBatch(query, params);
		}
	    }
	    int[] result = database.executeBatch();
	    if (result == null || result.length < 0) {
		throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (int i = 0; i < result.length; i++) {
		if (result[i] < 0) {
		    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }
	    createFormulaDosageEntries(formulaList, database, equipmentId, fPhaseMap);
	}
    }

    protected void createFormulaDosageEntries(List<FormulaDTO> formulaList, Database database, String equipmentId,
	    Map<String, String> fPhaseMap) throws Exception {
	String query = SQLConstants.JsonParsing.INSERT_INTO_FORMULA_DOSAGES;
	LOG.info("Inserting into formula dosage, query used:: " + query);
	LinkedList<Object> params;
//	    INSERT into formula_dosages(f_dosage_id, id, id_phase, dosage_order, id_product, dose, delay_bit, uid, product_uid, equipment_id, formula_id,f_phase_id
	database.createBatch(query);
	if (formulaList != null) {
	    for (FormulaDTO formulaMDTO : formulaList) {
		for (FormulaPhaseDTO formulaPDTO : formulaMDTO.getFormulas_phases()) {
		    for (FormulaProductDTO formulaDTO : formulaPDTO.getProducts()) {
			params = new LinkedList<>();
			params.add(CommonUtils.guidGenerator(null, null));
			params.add(formulaDTO.getId());
			params.add(formulaDTO.getId_phase());
			params.add(formulaDTO.getDosage_order());
			params.add(formulaDTO.getId_product());
			params.add(formulaDTO.getDose());
			params.add(formulaDTO.getDelay_bit());
			params.add(formulaDTO.getUid());
			params.add(formulaDTO.getProduct_uid());
			params.add(fPhaseMap.get(formulaPDTO.getUid()));
			database.addBatch(query, params);
		    }
		}
	    }
	    int[] result = database.executeBatch();
	    if (result == null || result.length < 0) {
		throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (int i = 0; i < result.length; i++) {
		if (result[i] < 0) {
		    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }
	}
    }

    public EquipmentDTO getEequipment(String equipmentId, String siteId) throws SystemException, Exception {
	Database database = null;
	EquipmentDTO equipment = null;
	try {
	    String query = SQLConstants.GET_EQUIPMENT;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(siteId);
	    params.add(equipmentId);
	    ResultSet rs = database.executeQuery(query, params);

	    if (rs.next()) {
		equipment = new EquipmentDTO();
		equipment.setEquipmentId(rs.getString(SQLColumns.EQUIPMENT_ID));
		equipment.setEquipmentName(rs.getString(SQLColumns.ALIAS));
		equipment.setDeviceId(rs.getString(SQLColumns.DEVICE_ID));
		equipment.setEquipmentType(rs.getString(SQLColumns.EQUIPMENT_TYPE));
		equipment.setFileId(rs.getString(SQLColumns.FILE_ID));
		equipment.setLm2Seq(rs.getInt(SQLColumns.LM2_SEQ));

	    }

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
	return equipment;

    }

    public boolean updateUnitId(String fileId, String unitId, Database database) throws Exception {
	try {
	    String query = SQLConstants.JsonParsing.UPDATE_UNITID;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(unitId);
	    params.add(fileId);
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	}
	return true;
    }

    public boolean deleteExistingFormulaForEquipment(String equipmentId, Database database) throws Exception {
	try {
	    String query = SQLConstants.JsonParsing.DELETE_EXISTING_FORMULA_ENTRIES;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(equipmentId);
	    int count = database.executeUpdate(query, params);
	    if (count < 0) {
		LOG.error("Error : failed to delete existing formula entries.");
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	}
	return true;
    }

    public boolean setForeignKeyConstraint(Database database) throws Exception {
	try {
	    String query = SQLConstants.JsonParsing.SET_FOREIGN_KEY_CHECKS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(0);
	    int count = database.executeUpdate(query, params);
	    if (count < 0) {
		return false;
	    }
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	}
	return true;
    }

    public Map<Map<String, String>, String> getListOfActiveDevices(String siteId, String fileId)
	    throws SystemException, Exception {
	Database database = null;
	Map<Map<String, String>, String> configMap = new HashMap<>();
	try {
	    String query = SQLConstants.JsonParsing.GET_ACTIVE_CONFIG_DETAILS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(siteId);
	    params.add(fileId + "%");
	    ResultSet rs = database.executeQuery(query, params);
	    while (rs.next()) {
		Map<String, String> details = new HashMap<>();
		details.put(rs.getString(SQLColumns.IP_ADDRESS), rs.getString(SQLColumns.FILE_ID));
		configMap.put(details, rs.getString(SQLColumns.FILE_TYPE));
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
	return configMap;
    }

    public Set<String> getOtherDevicesForSite(String fileId) throws SystemException, Exception {
	Database database = null;
	try {
	    Set<String> fileIdList = new HashSet<>();
	    String query = SQLConstants.JsonParsing.GET_OTHER_DEVICE_FILE_ID;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    String formatedString = fileId.substring(0, fileId.indexOf('_') + 1);
	    params.add(formatedString + "_");
	    params.add(fileId);
	    ResultSet rs = database.executeQuery(query, params);
	    while (rs.next()) {
		fileIdList.add(rs.getString(SQLColumns.FILE_ID));
		return fileIdList;
	    }
	    return fileIdList;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public void updateFileStatusToInactive(Set<String> fileList) throws Exception {
	Database database = null;
	try {
	    database = new Database();
	    String query = SQLConstants.JsonParsing.UPDATE_FILE_STATUS_TO_INACTIVE;
	    LOG.debug("query>>>>" + query);
	    database.setAutoCommitFalse();
	    database.createBatch(query);
	    LinkedList<Object> params = new LinkedList<>();
	    for (String fileId : fileList) {
		params = new LinkedList<>();
		params.add(fileId);
		database.addBatch(query, params);
	    }
	    int[] result = database.executeBatch();
	    if (result == null || result.length <= 0) {
		throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (int i = 0; i < result.length; i++) {
		if (result[i] == 0) {
		    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		}
	    }
	    database.commit();
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public LinkedList<Object> getSiteListOnStartEndDate(SiteDTO site) {
	String createdStartDate = site.getCreatedDateStart();
	String createdEndDate = site.getCreatedDateEnd();
	LinkedList<Object> params = new LinkedList<>();
	if (createdStartDate != null && createdEndDate != null) {
	    params.add(createdStartDate);
	    params.add(createdEndDate);
	}
	return params;
    }
}
