package com.hydro.api.base.common;

import static java.time.DayOfWeek.MONDAY;
import static java.time.DayOfWeek.SUNDAY;
import static java.time.temporal.TemporalAdjusters.nextOrSame;
import static java.time.temporal.TemporalAdjusters.previousOrSame;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.net.URI;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;
import java.util.UnknownFormatConversionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.joda.time.Interval;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.CalculationDTO;
import com.hydro.api.dto.CompanyDTO;
import com.hydro.api.dto.CompanyListResponseDTO;
import com.hydro.api.dto.MetricDTO;
import com.hydro.api.dto.PermissionDTO;
import com.hydro.api.dto.RoleDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;
import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

/**
 * @author Shreyas, Srishti
 *
 */
public class CommonUtils {
    private static final Logger LOG = LoggerFactory.getLogger(CommonUtils.class);

    public static String generateJWTToken(Map<String, Object> claim, Date expiry, String subject) throws Exception {
	ConfigReader config = ConfigReader.getObject();

	String jwt = Jwts.builder().setSubject(subject).setExpiration(expiry).setClaims(claim)
		.signWith(SignatureAlgorithm.HS256, config.getAppConfig(Constants.JWT_TOKEN).getBytes("UTF-8"))
		.compact();

	return jwt;
    }

    public static Jws<Claims> getClaims(String jwt) throws Exception {
	ConfigReader config = ConfigReader.getObject();
	Jws<Claims> claims = Jwts.parser().setSigningKey(config.getAppConfig(Constants.JWT_TOKEN).getBytes("UTF-8"))
		.parseClaimsJws(jwt);

	// final Claims claims =
	// Jwts.parser().setSigningKey("secretkey").parseClaimsJws(jwt).getBody();
	return claims;
    }

    public static Jws<Claims> getAzzureClaims(String jwt) throws Exception {
	ConfigReader config = ConfigReader.getObject();
	String keyVal = null;
	try {
	    CloseableHttpClient httpClient = HttpClients.createDefault();
	    HttpGet getRequest = new HttpGet(config.getAppConfig(Constants.AZURE_TOKEN_URL));
	    CloseableHttpResponse httpResponse = httpClient.execute(getRequest);

	    BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

	    String inputLine;
	    StringBuffer response = new StringBuffer();

	    while ((inputLine = reader.readLine()) != null) {
		response.append(inputLine);
	    }
	    reader.close();
	    httpClient.close();
	    String responseString = response.toString();
	    if (StringUtils.isEmpty(responseString)) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, config.getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    JsonObject responseObject = new Gson().fromJson(responseString, JsonObject.class);
	    JsonArray keys = responseObject.getAsJsonArray(Constants.KEYS);

	    JsonElement key = keys.get(0).getAsJsonObject().get(Constants.KID);
	    keyVal = key.getAsString();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}

	Jws<Claims> claims = Jwts.parser().setSigningKey(keyVal).parseClaimsJws(jwt);
	return claims;
    }

    public static String guidGenerator(String prefix, String postFix) {
	// VMID guid = new VMID();

	final String uuid = UUID.randomUUID().toString().replace("-", "");
	// System.out.println("uuid = " + uuid);
	prefix = prefix == null ? "" : prefix;
	postFix = postFix == null ? "" : postFix;
	String id = prefix + uuid + postFix;
	// LOG.info(id);
	return id;
    }

    public static String generateQueryParams(int length) {
	if (length <= 0) {
	    return "";
	}
	StringBuffer sBuffer = new StringBuffer();
	for (int i = 0; i < length; i++) {
	    if (i != 0 && i != length) {
		sBuffer.append(",");
	    }
	    sBuffer.append("?");
	}
	return sBuffer.toString();
    }

    public static PermissionDTO getPrivilegesName(Set<String> permissionList) throws Exception {
	PermissionDTO permissionDTO = new PermissionDTO();
	if (permissionList == null || permissionList.size() <= 0) {
	    return permissionDTO;
	}

	Class<?> clazz = permissionDTO.getClass();
	for (String permission : permissionList) {
	    try {
		Field field = clazz.getDeclaredField(permission);
		field.setAccessible(true);
		field.set(permissionDTO, Boolean.TRUE);
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	}
	return permissionDTO;

    }

    public static String getGraphApiToken() throws Exception {
	AuthenticationContext context = null;
	AuthenticationResult result = null;
	ExecutorService service = null;
	ConfigReader config = ConfigReader.getObject();
	try {

	    service = Executors.newFixedThreadPool(4);
	    context = new AuthenticationContext(config.getAppConfig(Constants.AZURE_AD_AUTHORITY_URL), false, service);
	    ClientCredential credential = new ClientCredential(config.getAppConfig(Constants.AZURE_AD_CLIENT_ID),
		    config.getAppConfig(Constants.AZURE_AD_CLIENT_SECRET));
	    Future<AuthenticationResult> future = context
		    .acquireToken(config.getAppConfig(Constants.AZURE_AD_GRAPH_RESOURCE), credential, null);
	    result = future.get();
	} finally {
	    service.shutdown();
	}
	String accessToken = null;
	if (result == null) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} else {
	    accessToken = result.getAccessToken();
	}
	return accessToken;
    }

    // public static void main(String[] args) throws Exception {
    // // userSignInNameExists("test", "test");
    // createUser("achandrahas@dovercorp.com", "dummydisplay", "mailNickname",
    // "TempPassword@123", "testusername");
    // }

    public static boolean userSignInNameExists(String userName) throws Exception {
	HttpClient httpclient = HttpClients.createDefault();
	ConfigReader config = ConfigReader.getObject();
	if (StringUtils.isEmpty(userName)) {
	    return false;
	}
	// userName = userName + "@" +
	// config.getAppConfig(Constants.AZURE_AD_COMPANY_NAME);
	try {
	    // OAuth2 is required to access this API. For more information
	    // visit:
	    // https://msdn.microsoft.com/en-us/office/office365/howto/common-app-authentication-tasks

	    // Specify values for path parameters (shown as {...})
	    URIBuilder builder = new URIBuilder(config.getAppConfig(Constants.AZURE_AD_CREATE_USER_URL));
	    // Specify values for the following required parameters
	    // builder.setParameter("api-version", "1.6");
	    // Specify values for optional parameters, as needed
	    // builder.setParameter("$filter", "startswith(userPrincipalName ,'"
	    // + userName + "')");
	    builder.setParameter("$filter", "signInNames/any(x:x/value eq '" + userName + "')");
	    URI uri = builder.build();
	    HttpGet request = new HttpGet(uri);
	    request.addHeader(Constants.AUTHORIZATION, getGraphApiToken());
	    request.addHeader(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
	    HttpResponse response = httpclient.execute(request);
	    HttpEntity entity = response.getEntity();
	    if (entity == null) {
		return false;
	    }
	    String responseString = EntityUtils.toString(entity);
	    JsonObject responseObject = new Gson().fromJson(responseString, JsonObject.class);
	    JsonArray valueArray = responseObject.getAsJsonArray(Constants.VALUE);
	    if (valueArray == null || valueArray.size() <= 0) {
		return false;
	    } else
		return true;
	    // For UPN
	    /*
	     * for (int i = 0; i < valueArray.size(); i++) { JsonObject value =
	     * valueArray.get(i).getAsJsonObject();
	     * 
	     * String upn = value.get(Constants.USER_PRINCIPAL_NAME).getAsString(); if
	     * (userName.equalsIgnoreCase(upn)) { return true; } }
	     */

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error Fetching the user information. Error : " + e.getMessage());
	}
	return false;
    }

    public static JsonObject createUser(String email, String displayName, String mailNickname, String password,
	    String userName) throws Exception {
	ConfigReader config = ConfigReader.getObject();
	CloseableHttpClient httpClient = HttpClients.createDefault();
	HttpPost httpPost = new HttpPost(config.getAppConfig(Constants.AZURE_AD_CREATE_USER_URL));
	httpPost.addHeader(Constants.AUTHORIZATION, getGraphApiToken());
	httpPost.addHeader(Constants.CONTENT_TYPE, Constants.APPLICATION_JSON);
	JsonObject jObject = new JsonObject();
	jObject.addProperty(Constants.ACCOUNT_ENABLED, true);

	// UPN
	// jObject.addProperty(Constants.USER_PRINCIPAL_NAME, userName);
	// use either UPN or signinnames
	// Signinnames
	JsonArray signInNames = new JsonArray();
	JsonObject signInName = new JsonObject();
	signInName.addProperty(Constants.TYPE, Constants.USER_NAME);
	signInName.addProperty(Constants.VALUE, userName);
	signInNames.add(signInName);
	jObject.add(Constants.SIGN_IN_NAMES, signInNames);
	jObject.addProperty(Constants.CREATION_TYPE, Constants.LOCAL_ACCOUNT);

	jObject.addProperty(Constants.DISPLAY_NAME, displayName);
	jObject.addProperty(Constants.MAIL_NICK_NAME, mailNickname);
	JsonObject passwordProfile = new JsonObject();
	passwordProfile.addProperty(Constants.PASSWORD, password);
	passwordProfile.addProperty(Constants.FORCE_CHANGE_PASSWORD_NEXT_LOGIN, true);
	jObject.add(Constants.PASSWORD_PROFILE, passwordProfile);
	jObject.addProperty(Constants.PASSWORD_POLICIES, Constants.DISABLE_PASSWORD_EXPIRATION);
	JsonArray otherMails = new JsonArray();
	otherMails.add(email);
	jObject.add(Constants.OTHER_MAILS, otherMails);
	String jsonString = jObject.toString();
	HttpEntity entity = new ByteArrayEntity(jsonString.getBytes("UTF-8"));
	httpPost.setEntity(entity);
	CloseableHttpResponse httpResponse = httpClient.execute(httpPost);
	BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

	String inputLine;
	StringBuffer response = new StringBuffer();

	while ((inputLine = reader.readLine()) != null) {
	    response.append(inputLine);
	}
	reader.close();

	// print result
	String resp = response.toString();
	JsonObject jsonObject = new JsonParser().parse(resp).getAsJsonObject();

	// System.out.println(response.toString());
	try {
	    httpClient.close();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error while closing HTTP connection Error : " + e.getMessage());
	}
	return jsonObject;
    }

    public static void sendEmail(List<String> toEmailList, String subject, String body) {
	try {
	    ConfigReader config = ConfigReader.getObject();
	    final String username = config.getAppConfig(Constants.MAIL_USER);
	    final String password = config.getAppConfig(Constants.MAIL_PASSWORD);
	    final String fromMail = config.getAppConfig(Constants.MAIL_ADDRESS);

	    Properties props = new Properties();
	    props.put("mail.smtp.auth", "true");
	    props.put("mail.transport.protocol", "smtp");
	    props.put("mail.smtp.starttls.enable", "true");
	    props.put("mail.smtp.host", config.getAppConfig(Constants.MAIL_SMTP));
	    props.put("mail.smtp.port", config.getAppConfig(Constants.MAIL_PORT));

	    Session session = Session.getInstance(props, new javax.mail.Authenticator() {
		protected PasswordAuthentication getPasswordAuthentication() {
		    return new PasswordAuthentication(username, password);
		}
	    });

	    Message message = new MimeMessage(session);
	    message.setFrom(new InternetAddress(fromMail));
	    String emailList = StringUtils.join(toEmailList, ',');
	    InternetAddress[] sendTo = InternetAddress.parse(emailList, true);

	    /*
	     * if (isValidMail(toEmail)) { message.setRecipient(Message.RecipientType.TO,
	     * new InternetAddress(toEmail)); } else { throw new
	     * SystemException(ErrorCodes.INVALID_MAIL_FORMAT, config.getErrorConfig(),
	     * ErrorCodes.StatusCodes.FAILURE, null); }
	     */

	    message.setRecipients(Message.RecipientType.TO, sendTo);
	    message.setSubject(subject);
	    // message.setText(body);
	    message.setContent(body, "text/html");
	    if (toEmailList.size() > 0)
		Transport.send(message);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error : " + e.getMessage());

	}

    }

    public static void sendEmail(String toEmail, String subject, String body) {
	List<String> toList = new ArrayList<String>();
	toList.add(toEmail);

	sendEmail(toList, subject, body);
    }

    public static String getEventId(StringBuilder uniqueIdentifier) {
	MessageDigest md = null;
	try {
	    md = MessageDigest.getInstance("SHA-256");
	    uniqueIdentifier = (uniqueIdentifier == null) ? new StringBuilder() : uniqueIdentifier;
	    md.update(uniqueIdentifier.toString().getBytes("utf8"));
	    StringBuilder hexString = new StringBuilder();
	    byte[] messageDigest = md.digest();
	    for (int i = 0; i < messageDigest.length; i++) {
		hexString.append(Integer.toHexString(0xFF & messageDigest[i]));
	    }
	    return hexString.toString();
	} catch (Exception ex) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    LOG.info("Error generaing Event Id" + ex.getMessage());
	}
	return null;
    }

    public static LocalDateTime getEventDateTime(String time) {
	if (StringUtils.isEmpty(time)) {
	    return null;
	}
	try {
	    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy  HH:mm:ss");
	    LocalDateTime dateTime = LocalDateTime.parse(time, formatter);
	    return dateTime;

	} catch (DateTimeParseException e) {
	    LOG.error("ParseException while parsing the date time: " + time + " Error thrown: "
		    + e.getLocalizedMessage());
	    e.printStackTrace();
	    return null;
	} catch (Exception e) {
	    LOG.error("Exception while parsing the date time: " + time + " Error thrown: " + e.getLocalizedMessage());
	    e.printStackTrace();
	    return null;
	}
    }

    // public static long convertKgToLbs(long weight) {
    // return (long) (weight * 2.20462262185);
    // }

    public static double realTimeConvertMlToGal(double ml, String unit, int concentrationPercent) {
	// For an invalid concentration, use the full.
	if (concentrationPercent < 0 || concentrationPercent > 100) {
	    concentrationPercent = 100;
	}
	double result = ml;
	switch (unit) {
	case Constants.Units.UsUnit.ID:
	    result = ml / 128;
	    break;
	case Constants.Units.MetricUnit.ID:
	    result = ml / 100;
	    result = (result * concentrationPercent) / 100;
	    break;
	default:
	    result = ml / 128;
	    break;
	}

	return result;
    }

    public static double mdbConvertMlToGal(double ml, String unit, int concentrationPercent) {
	// For an invalid concentration, use the full.
	if (concentrationPercent < 0 || concentrationPercent > 100) {
	    concentrationPercent = 100;
	}
	double result = ml;
	switch (unit) {
	case Constants.Units.UsUnit.ID:
	    result = ml / 1280;
	    break;
	case Constants.Units.MetricUnit.ID:
	    result = ml / 1000;
	    result = (result * concentrationPercent) / 100;
	    break;
	default:
	    result = ml / 1280;
	    break;
	}

	return result;
    }

    public static double getPerCw(double numerator, double denomenator, String unit) {
	switch (unit) {
	case Constants.Units.UsUnit.ID:
	    return (numerator / denomenator) * 100;
	case Constants.Units.MetricUnit.ID:
	    return (numerator / denomenator);
	default:
	    return (numerator / denomenator) * 100;
	}

    }

    public static String removeUTF8BOM(String s) {
	String UTF8_BOM = "\uFEFF";
	if (!StringUtils.isEmpty(s) && s.startsWith(UTF8_BOM)) {
	    s = s.substring(1);
	}
	return s;
    }

    public static boolean isValidTimeZone(String timeZone) {
	Set<String> timeZoneList = new HashSet<String>(Arrays.asList(TimeZone.getAvailableIDs()));
	if (timeZoneList.contains(timeZone)) {
	    return true;
	}
	return false;
    }

    public static String convertDate(String date, String timeZone) {
	if (StringUtils.isEmpty(timeZone) || !(isValidTimeZone(timeZone))) {
	    return date;
	}
	ZoneId zone = ZoneId.of(timeZone);
	ZoneOffset offset = ((LocalDateTime.parse(date,
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.DATE_FORMAT))).atZone(zone)).getOffset();
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.DATE_FORMAT);
	return ((LocalDateTime.parse(date, DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.DATE_FORMAT)))
		.plus(offset.getTotalSeconds(), ChronoUnit.SECONDS)).format(formatter);
    }

    public static ZonedDateTime parseAsUtcZoneTime(String utcTime) {
	return convertUTCtoZonedTime(utcTime, null);
    }

    public static ZonedDateTime convertUTCtoZonedTime(String utcTime, String timeZone) {
	LocalDateTime local = LocalDateTime.parse(utcTime,
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
	ZonedDateTime utc = ZonedDateTime.of(local, ZoneOffset.UTC);
	if (StringUtils.isBlank(timeZone) || !(isValidTimeZone(timeZone))) {
	    return utc;
	}
	ZoneId zone = ZoneId.of(timeZone);
	return utc.withZoneSameInstant(zone);
    }

    public static ZonedDateTime getCurrentTimeForZone(String timeZone) {
	if (timeZone == null || timeZone.isEmpty()) {
	    return ZonedDateTime.now(ZoneOffset.UTC);
	}
	return ZonedDateTime.now(ZoneId.of(timeZone));
    }

    public static Duration getTimeDifferenceWrtCurrentTime(ZonedDateTime time) {
	ZoneId zone = time.getZone();
	ZonedDateTime currentTime = ZonedDateTime.now(zone);
	return Duration.between(currentTime, time);
    }

    public static boolean userNamePattern(String userName) {
	if (StringUtils.isEmpty(userName)) {
	    return false;
	}
	if (userName.matches("[a-z]+[a-z0-9_]*")) {
	    return true;
	}
	return false;
    }

    public static String getBasicAuthentication(String username, String password) {
	return new Base64().encodeAsString(new String(username + ":" + password).getBytes());
    }

    /**
     * Method to check if the entered metric for site is valid or not.
     * 
     * @param metricId : The key to be stored in the DB against the site master.
     * @return
     */
    public static boolean isValidMetric(String metricId) {
	if (StringUtils.isEmpty(metricId)) {
	    return false;
	}
	for (MetricDTO metric : Constants.Units.METRIC_LIST) {
	    if (metricId.equalsIgnoreCase(metric.getId())) {
		return true;
	    }
	}
	return false;
    }

    /**
     * Method to calculate the weight from one unit to another.
     * 
     * @param unit1
     * @param unit2
     * @return
     */
    public static CalculationDTO convertWeightCalculation(String unit1, String unit2) {
	if (StringUtils.isEmpty(unit1) || StringUtils.isEmpty(unit2) || unit1.equalsIgnoreCase(unit2)) {
	    return null;
	}
	CalculationDTO calculationDTO = new CalculationDTO();
	switch (unit1) {
	case Constants.Units.KG:
	    // Matching for KGs
	    switch (unit2) {
	    case Constants.Units.LBS:
		calculationDTO.setOperation(Constants.Units.Operations.MULTIPLY);
		calculationDTO.setFormula(Constants.Units.KG_LBS);
		break;
	    default:
		calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
		break;
	    }
	    break;
	case Constants.Units.LBS:
	    switch (unit2) {
	    case Constants.Units.KG:
		calculationDTO.setOperation(Constants.Units.Operations.DIVIDE);
		calculationDTO.setFormula(Constants.Units.KG_LBS);
		break;
	    default:
		calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
		break;
	    }
	    break;

	default:
	    calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
	    break;
	}
	return calculationDTO;
    }

    /**
     * Method to calculate the weight from one unit to another.
     * 
     * @param unit1
     * @param unit2
     * @return
     */
    public static CalculationDTO convertVolumeCalculation(String unit1, String unit2) {
	if (StringUtils.isEmpty(unit1) || StringUtils.isEmpty(unit2) || unit1.equalsIgnoreCase(unit2)) {
	    return null;
	}
	CalculationDTO calculationDTO = new CalculationDTO();
	switch (unit1) {
	case Constants.Units.KG:
	    // Matching for KGs
	    switch (unit2) {
	    case Constants.Units.GAL:
		calculationDTO.setOperation(Constants.Units.Operations.DIVIDE);
		calculationDTO.setFormula(Constants.Units.GALLON_KG);
		break;
	    case Constants.Units.ML:
		calculationDTO.setOperation(Constants.Units.Operations.MULTIPLY);
		calculationDTO.setFormula(Constants.Units.ML_KG);
		break;
	    case Constants.Units.OZ:
		calculationDTO.setOperation(Constants.Units.Operations.MULTIPLY);
		calculationDTO.setFormula(Constants.Units.OZ_KG);
		break;
	    default:
		calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
		break;
	    }
	    break;
	case Constants.Units.GAL:
	    switch (unit2) {
	    case Constants.Units.KG:
		calculationDTO.setOperation(Constants.Units.Operations.MULTIPLY);
		calculationDTO.setFormula(Constants.Units.GALLON_KG);
		break;
	    case Constants.Units.ML:
		calculationDTO.setOperation(Constants.Units.Operations.MULTIPLY);
		calculationDTO.setFormula(Constants.Units.ML_GALLON);
		break;
	    case Constants.Units.OZ:
		calculationDTO.setOperation(Constants.Units.Operations.MULTIPLY);
		calculationDTO.setFormula(Constants.Units.OZ_GALLON);
		break;
	    default:
		calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
		break;
	    }
	    break;
	case Constants.Units.ML:
	    switch (unit2) {
	    case Constants.Units.OZ:
		calculationDTO.setOperation(Constants.Units.Operations.DIVIDE);
		calculationDTO.setFormula(Constants.Units.OZ_ML);
		break;
	    case Constants.Units.KG:
		calculationDTO.setOperation(Constants.Units.Operations.DIVIDE);
		calculationDTO.setFormula(Constants.Units.ML_KG);
		break;
	    case Constants.Units.GAL:
		calculationDTO.setOperation(Constants.Units.Operations.DIVIDE);
		calculationDTO.setFormula(Constants.Units.ML_GALLON);
		break;
	    default:
		calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
		break;
	    }
	    break;
	case Constants.Units.OZ:
	    switch (unit2) {
	    case Constants.Units.KG:
		calculationDTO.setOperation(Constants.Units.Operations.DIVIDE);
		calculationDTO.setFormula(Constants.Units.OZ_KG);
		break;
	    case Constants.Units.GAL:
		calculationDTO.setOperation(Constants.Units.Operations.DIVIDE);
		calculationDTO.setFormula(Constants.Units.OZ_GALLON);
		break;
	    case Constants.Units.ML:
		calculationDTO.setOperation(Constants.Units.Operations.MULTIPLY);
		calculationDTO.setFormula(Constants.Units.OZ_ML);
		break;
	    default:
		calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
		break;
	    }
	    break;

	default:
	    calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
	    break;
	}
	return calculationDTO;
    }

    public static CalculationDTO convertChemicalPerCwCalculation(String unit1, String unit2) {
	if (StringUtils.isEmpty(unit1) || StringUtils.isEmpty(unit2) || unit1.equalsIgnoreCase(unit2)) {
	    return null;
	}
	CalculationDTO calculationDTO = new CalculationDTO();
	switch (unit1) {
	case Constants.Units.UsUnit.ID:
	    // Matching for KGs
	    switch (unit2) {
	    case Constants.Units.MetricUnit.ID:
		calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
		break;
	    default:
		calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
		break;
	    }
	    break;
	case Constants.Units.MetricUnit.ID:
	    switch (unit2) {
	    case Constants.Units.UsUnit.ID:
		calculationDTO.setOperation(Constants.Units.Operations.MULTIPLY);
		calculationDTO.setFormula(Constants.Units.PER_CW);
		break;
	    default:
		calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
		break;
	    }
	    break;

	default:
	    calculationDTO.setOperation(Constants.Units.Operations.NO_OPERATION);
	    break;
	}
	return calculationDTO;
    }

    public static LinkedList<MetricDTO> getMetricList() {
	LinkedList<MetricDTO> metricList = Constants.Units.METRIC_LIST;
	metricList.forEach((value) -> {
	    String key = value.getId();
	    Constants.Units.weightList.forEach((weight) -> {
		CalculationDTO calculationDTO = convertWeightCalculation(value.getWeightUnit(), weight);
		if (calculationDTO != null) {
		    value.getWeightCalculation().put(weight, calculationDTO);
		}
	    });

	    Constants.Units.volumeList.forEach((volume) -> {
		value.getVolumeCalculation().put(volume, convertVolumeCalculation(value.getVolumeUnit(), volume));
	    });
	    Constants.Units.volumeList.forEach((volume) -> {
		value.getAlarmVolumeCalculation().put(volume,
			convertVolumeCalculation(value.getAlarmVolumeUnit(), volume));
	    });

	    Constants.Units.METRIC_LIST.forEach((unit) -> {
		value.getChemicalPerCwCalculation().put(unit.getId(),
			convertChemicalPerCwCalculation(value.getId(), unit.getId()));
	    });
	});
	return metricList;
    }

    public static String removeAfterLastOccurence(String original, String delimiter) {
	if (StringUtils.isEmpty(original) || StringUtils.isEmpty(delimiter)) {
	    return original;
	}
	int firstIndex = original.indexOf(delimiter);
	String result = original;
	if (firstIndex != -1) {

	    result = original.substring(firstIndex + 1, original.length());
	}
	return result;
    }

    public static boolean isValidMail(String mail) {
	if (StringUtils.isEmpty(mail)) {
	    return false;
	}
	EmailValidator validator = EmailValidator.getInstance();
	if (validator.isValid(mail)) {
	    return true;
	}
	return false;
    }

    public static boolean userCreationCheck(UserDTO loggedInUser, UserDTO userDTO, Boolean sameLevelUserFlag) {
	if (sameLevelUserFlag)
	    return (loggedInUser.getClearanceLevel() <= userDTO.getClearanceLevel());
	return (loggedInUser.getClearanceLevel() < userDTO.getClearanceLevel());

    }

    public static boolean checkCompanyVisibility(CompanyListResponseDTO companyListResonse, String companyId) {
	for (CompanyDTO company : companyListResonse.getCompanyList()) {
	    if (company.getCompanyId().equals(companyId)) {
		return true;
	    }
	}
	return false;
    }

    public static boolean roleExists(List<RoleDTO> roleList, String userRole) {
	return (roleList == null || StringUtils.isEmpty(userRole)) ? (false)
		: (roleList.stream().anyMatch((role) -> userRole.equals(role.getUserRole())));
    }

    public static String convertFromUtcEpochToZoneDate(long epochTime, String timeZoneId) {
	ZonedDateTime utcDateTime = ZonedDateTime.ofInstant(Instant.ofEpochMilli(epochTime), ZoneOffset.UTC);
	return utcDateTime.withZoneSameInstant(ZoneId.of(timeZoneId))
		.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT));
    }

    public static Long convertStringToLongTime(String stringTime) throws Exception {
	if (StringUtils.isEmpty(stringTime)) {
	    return null;
	}
	try {
	    SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);
	    return dateFormat.parse(stringTime).getTime();
	} catch (ParseException e) {
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	} catch (Exception e) {
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
    }

    public static Long convertStringToLongDateTime(String stringTime) throws Exception {
	if (StringUtils.isEmpty(stringTime)) {
	    return null;
	}
	try {
	    SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	    return dateFormat.parse(stringTime).getTime();
	} catch (ParseException e) {
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	} catch (Exception e) {
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
    }

    public static Long convertStringToLongDate(String stringTime) throws Exception {
	if (StringUtils.isEmpty(stringTime)) {
	    return null;
	}
	try {
	    SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	    dateFormat.setTimeZone(TimeZone.getTimeZone(Constants.UTC));
	    return dateFormat.parse(stringTime).getTime();
	} catch (ParseException e) {
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	} catch (Exception e) {
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
    }

    public static Interval createInterval(long startTime, long endTime) throws Exception {
	try {
	    Interval interval = new Interval(startTime, endTime);
	    return interval;
	} catch (Exception e) {
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
    }

    public static boolean validateTimeStamp(String time) throws Exception {
	if (StringUtils.isEmpty(time))
	    return false;
	try {
	    Pattern pattern = Pattern.compile(Constants.TIME24HOURS_PATTERN);
	    Matcher matcher = pattern.matcher(time);
	    return matcher.matches();
	} catch (Exception e) {
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
    }

    public static String convertLongToStringDate(Long Time) {
	DateFormat formatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
	String dateFormatted = formatter.format(Time);
	return dateFormatted;
    }

    public static String convertLongToStringTime(Long Time) {
	DateFormat formatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);
	formatter.setTimeZone(TimeZone.getTimeZone("UTC"));
	String dateFormatted = formatter.format(Time);
	return dateFormatted;
    }

    public static boolean thresholdValidation(int threshold) {
	if (threshold < 0 || threshold > 100) {
	    return false;
	}
	return true;
    }

    public static boolean isDateInShift(String dateInQuestion, String startDateStr, String endDateStr, String zone) {
	boolean isValid = false;
	try {
	    ZoneId zoneId = ZoneId.of(zone);
	    SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	    Date eventDate = formatter.parse(dateInQuestion);
	    LocalDateTime eventldt = LocalDateTime.ofInstant(eventDate.toInstant(), zoneId);

	    Date startDate = formatter.parse(startDateStr);
	    LocalDateTime startldt = LocalDateTime.ofInstant(startDate.toInstant(), ZoneId.systemDefault());

	    Date endDate = formatter.parse(endDateStr);
	    LocalDateTime endldt = LocalDateTime.ofInstant(endDate.toInstant(), ZoneId.systemDefault());

	    isValid = (eventldt.isAfter(startldt) && eventldt.isBefore(endldt));

	} catch (Exception exp) {
	    LOG.error("Error in isDateBetween:" + exp.getMessage());
	}

	return isValid;
    }

    public static boolean isDateBetween(String dateInQuestion, String startDateStr, String endDateStr) {
	boolean isValid = false;
	try {
	    ZoneId zoneId = ZoneId.systemDefault();// ZoneId.of(zone);
	    SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	    Date eventDate = formatter.parse(dateInQuestion);
	    LocalDateTime eventldt = LocalDateTime.ofInstant(eventDate.toInstant(), zoneId);

	    Date startDate = formatter.parse(startDateStr);
	    LocalDateTime startldt = LocalDateTime.ofInstant(startDate.toInstant(), zoneId);

	    Date endDate = formatter.parse(endDateStr);
	    LocalDateTime endldt = LocalDateTime.ofInstant(endDate.toInstant(), zoneId);

	    isValid = (eventldt.isAfter(startldt) && eventldt.isBefore(endldt));

	} catch (Exception exp) {
	    LOG.error("Error in isDateBetween:" + exp.getMessage());
	}

	return isValid;
    }

    public static boolean isDateInSameDay(String dateInQuestion, String dateToCompare) {
	boolean isValid = false;
	try {
	    LocalDate eventldt = LocalDateTime
		    .parse(dateInQuestion,
			    DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))
		    .toLocalDate();
	    LocalDate compareldt = LocalDateTime
		    .parse(dateToCompare,
			    DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))
		    .toLocalDate();

	    isValid = eventldt.equals(compareldt);// (eventldt.isAfter(dayStart)
	    // &&
	    // eventldt.isBefore(dayEnd));
	    LOG.debug("isDateinSameDay: isValid:" + isValid + " eventldt: " + eventldt + "compareldt: " + compareldt);
	} catch (Exception exp) {
	    LOG.error("Error in isDateInSameDay:" + exp.getMessage());
	}

	return isValid;
    }

    public static boolean isDateInSameWeek(String dateInQuestion, String dateToCompare) {
	boolean isValid = false;
	try {
	    LocalDateTime eventldt = LocalDateTime.parse(dateInQuestion,
		    DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
	    LocalDateTime compareldt = LocalDateTime.parse(dateToCompare,
		    DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));

	    LocalDateTime weekStart = compareldt.with(previousOrSame(MONDAY)).with(LocalTime.MIN);
	    LocalDateTime weekEnd = compareldt.with(nextOrSame(SUNDAY)).with(LocalTime.MAX);

	    isValid = (eventldt.isAfter(weekStart) && eventldt.isBefore(weekEnd));
	    LOG.debug("isDateinSameWeek- isValid:" + isValid + " eventldt: " + eventldt + " compareldt: " + compareldt
		    + ": weekStart: " + weekStart + ":weekEnd: " + weekEnd);
	} catch (Exception exp) {
	    LOG.error("Error in isDateInSameWeek:" + exp.getMessage());
	}

	return isValid;
    }

    public static boolean isDateInSameMonth(String dateInQuestion, String dateToCompare) {
	boolean isValid = false;
	try {
	    LocalDateTime eventldt = LocalDateTime.parse(dateInQuestion,
		    DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
	    LocalDateTime compareldt = LocalDateTime.parse(dateToCompare,
		    DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));

	    LocalDateTime monthStart = compareldt.with(TemporalAdjusters.firstDayOfMonth()).with(LocalTime.MIN);
	    LocalDateTime monthEnd = compareldt.with(TemporalAdjusters.lastDayOfMonth()).with(LocalTime.MAX);

	    isValid = (eventldt.isAfter(monthStart) && eventldt.isBefore(monthEnd));
	    LOG.debug("isDateinSameMonth: isValid:" + isValid + " eventldt: " + eventldt + " compareldt: " + compareldt
		    + ": monthStart: " + monthStart + ":monthEnd: " + monthEnd);
	} catch (Exception exp) {
	    LOG.error("Error in isDateInSameMonth:" + exp.getMessage());
	}

	return isValid;
    }

    /**
     * create monthly index list as per the list of sites provided as input.
     * 
     * @param year
     * @param month
     * @return list of indices
     */

    public static List<String> createMonthlyIndexList(List<String> siteList) {
	// hydro-siteId-month-year
	String index = "";
	List<String> indexList = new LinkedList<>();
	try {
	    for (String siteId : siteList) {
		LocalDateTime now = LocalDateTime.now(Clock.systemUTC());
		ConfigReader config = ConfigReader.getObject();
		index = config.getAppConfig(Constants.ES_INDEX) + siteId + Constants.HYPHEN + now.getMonthValue()
			+ Constants.HYPHEN + now.getYear();
		indexList.add(index);
		// check if the month is first of month and if the earlier time
		// goes to prev. date
		if (now.getDayOfMonth() == 1) {
		    LocalDateTime earlier = now.minusMinutes(
			    Integer.parseInt(config.getAppConfig(Constants.MACHINE_IDLE_QUERY_TIME_RANGE_IN_HRS)) * 60);
		    if (earlier.getDayOfMonth() != 1) {
			index = config.getAppConfig(Constants.ES_INDEX) + siteId + Constants.HYPHEN
				+ earlier.getMonthValue() + Constants.HYPHEN + earlier.getYear();
			indexList.add(index);
		    }
		}
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return indexList;
    }

    public static boolean isFirstDayofMonth() {
	LocalDate date = LocalDate.now(Clock.systemUTC());
	if (date.getDayOfMonth() == 1) {
	    return true;
	}
	return false;
    }

    public static void esError(JsonObject responseObject) throws Exception {
	if (responseObject == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonObject esError = (JsonObject) responseObject.get(Constants.REPORTS.ERROR);
	if (esError != null) {
	    LOG.error("ES Error" + responseObject);
	    JsonArray jArray = esError.getAsJsonArray(Constants.REPORTS.ROOT_CAUSE);
	    esError = jArray.get(0).getAsJsonObject();
	    String esErrorType = esError.get(Constants.REPORTS.TYPE).getAsString();
	    switch (esErrorType) {
	    case Constants.ES_EXCEPTION_TYPE.INDEX_NOT_FOUND_EXCEPTION:
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    default:
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	}
    }

    public static void disableSslVerification() {
	try {
	    // Create a trust manager that does not validate certificate chains
	    TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
		public java.security.cert.X509Certificate[] getAcceptedIssuers() {
		    return null;
		}

		public void checkClientTrusted(X509Certificate[] certs, String authType) {
		}

		public void checkServerTrusted(X509Certificate[] certs, String authType) {
		}
	    } };

	    // Install the all-trusting trust manager
	    SSLContext sc = SSLContext.getInstance("SSL");
	    sc.init(null, trustAllCerts, new java.security.SecureRandom());
	    HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	    // Create all-trusting host name verifier
	    HostnameVerifier allHostsValid = new HostnameVerifier() {
		public boolean verify(String hostname, SSLSession session) {
		    return true;
		}
	    };

	    // Install the all-trusting host verifier
	    HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	} catch (NoSuchAlgorithmException e) {
	    e.printStackTrace();
	} catch (KeyManagementException e) {
	    e.printStackTrace();
	}
    }

    public static String doPost(String uri, String jsonQuery) throws Exception {
	String responseStr = null;
	URL obj = new URL(uri);
	HttpsURLConnection postConnection = (HttpsURLConnection) obj.openConnection();
	postConnection.setRequestMethod("POST");
	postConnection.setRequestProperty("Content-Type", "application/json");
	postConnection.setDoOutput(true);
	OutputStream os = postConnection.getOutputStream();
	os.write(jsonQuery.getBytes());
	os.flush();
	os.close();
	int responseCode = postConnection.getResponseCode();
	System.out.println("POST Response Code :  " + responseCode);
	System.out.println("POST Response Message : " + postConnection.getResponseMessage());

	if (responseCode == HttpsURLConnection.HTTP_OK) {

	    BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
	    String inputLine;
	    StringBuffer response = new StringBuffer();
	    while ((inputLine = in.readLine()) != null) {
		response.append(inputLine);
	    }
	    in.close();

	    responseStr = response.toString();
	    // print result
	    System.out.println("responseStr::" + responseStr);
	} else {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}

	return responseStr;
    }

    private static SecureRandom random = new SecureRandom();

    /** different dictionaries used */
    private static final String ALPHA_CAPS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String ALPHA = "abcdefghijklmnopqrstuvwxyz";
    private static final String NUMERIC = "0123456789";
    private static final String SPECIAL_CHARS = "!@#$%^&*_=+-/"; // Allowed by
    // Azure "@ # $
    // % ^ & * - _
    // ! + = [ ] {
    // } | \ : ‘ ,
    // . ? / ` ~ "
    // ( ) ;";

    /**
     * Method will generate random string based on the parameters
     * 
     * @param len the length of the random string
     * @param dic the dictionary used to generate the password
     * @return the random password
     */
    public static String generatePassword(int len) {
	String dic = ALPHA_CAPS + ALPHA + SPECIAL_CHARS + NUMERIC;
	String result = "";
	for (int i = 0; i < len; i++) {
	    int index = random.nextInt(dic.length());
	    result += dic.charAt(index);
	}
	return result;
    }

    public static String convertZonedDateToUTCDate(String date, String timeZone, boolean startOfDay,
	    boolean isDateTime) {
	if (StringUtils.isEmpty(timeZone) || !(isValidTimeZone(timeZone))) {
	    return date;
	}

	LocalDate localDate = LocalDate.parse(date,
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT));
	ZonedDateTime zonedDateTime = null;
	if (startOfDay) {
	    zonedDateTime = localDate.atStartOfDay(ZoneId.of(timeZone));
	} else {
	    zonedDateTime = localDate.atTime(23, 59, 59).atZone(ZoneId.of(timeZone));
	}
	ZonedDateTime utcZonedt = zonedDateTime.withZoneSameInstant(ZoneOffset.UTC);
	if (isDateTime) {
	    return utcZonedt.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
	}
	return utcZonedt.format(DateTimeFormatter.ISO_LOCAL_DATE);
    }

    public static ZonedDateTime convertZonedDateToUTCDate(String date, String timeZone, boolean startOfDay) {

	LocalDate localDate = LocalDate.parse(date,
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT));
	ZonedDateTime zonedDateTime = null;
	if (startOfDay) {
	    zonedDateTime = localDate.atStartOfDay(ZoneId.of(timeZone));
	} else {
	    zonedDateTime = localDate.atTime(23, 59, 59).atZone(ZoneId.of(timeZone));
	}
	ZonedDateTime utcZonedt = zonedDateTime.withZoneSameInstant(ZoneOffset.UTC);
	return utcZonedt;

    }

    public static String convertUTCToZonedDate(String date, String timeZone, boolean isStartOfDay) {
	if (StringUtils.isEmpty(timeZone) || !(isValidTimeZone(timeZone))) {
	    return date;
	}

	LocalDate localDate = LocalDate.parse(date,
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT));
	LocalDateTime localDateTime = null;
	if (isStartOfDay) {
	    localDateTime = localDate.atStartOfDay();
	} else {
	    localDateTime = localDate.atTime(23, 59, 59);
	}

	ZonedDateTime utc = ZonedDateTime.of(localDateTime, ZoneOffset.UTC);

	ZonedDateTime localZonedt = utc.withZoneSameInstant(ZoneId.of(timeZone));

	return localZonedt.format(DateTimeFormatter.ISO_LOCAL_DATE);

    }

    public static String convertUTCtoZonedReportDate(String date, String timeZone) {
	ZonedDateTime zonedDateTime = convertUTCtoZonedTime(date, timeZone);
	return zonedDateTime.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
    }

    public static Date convertUtilZonedDateToUTC(Date date, String siteTimeZone, boolean startOfDay) {
	if (StringUtils.isEmpty(siteTimeZone) || !(isValidTimeZone(siteTimeZone))) {
	    return date;
	}

	SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
	String rdate = formatter.format(date);

	LocalDate localDate = LocalDate.parse(rdate,
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT));
	ZonedDateTime zonedDateTime = null;
	if (startOfDay) {
	    zonedDateTime = localDate.atStartOfDay(ZoneId.of(siteTimeZone));
	} else {
	    zonedDateTime = localDate.atTime(23, 59, 59).atZone(ZoneId.of(siteTimeZone));
	}
	ZonedDateTime utcZonedt = zonedDateTime.withZoneSameInstant(ZoneOffset.UTC);
	return Date.from(utcZonedt.toInstant());

    }

    public static String getShiftTimeUTC(String shiftTime, String siteTimeZone) {

	LocalDate localZonedDate = LocalDate.now(TimeZone.getTimeZone(siteTimeZone).toZoneId());

	String date = localZonedDate.format(DateTimeFormatter.ISO_LOCAL_DATE);
	String DT = date + "T" + shiftTime;

	SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	Date shiftDt = null;
	try {
	    shiftDt = dateFormat.parse(DT);
	} catch (ParseException e) {
	    LOG.error("Error in getShiftTimeUTC:" + e.getMessage());
	}

	SimpleDateFormat timeformat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);
	timeformat.setTimeZone(TimeZone.getTimeZone(Constants.UTC));

	return timeformat.format(shiftDt);

    }

    public static String convertStringUTCToZonedTime(String date, String timeZone) {
	if (StringUtils.isEmpty(timeZone) || !(isValidTimeZone(timeZone))) {
	    return date;
	}

	ZonedDateTime localDateTime = LocalDateTime
		.parse(date, DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))
		.atZone(ZoneId.of(Constants.UTC));

	ZonedDateTime utc = localDateTime.withZoneSameInstant(ZoneId.of(timeZone));
	return utc.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.TIME_FORMAT));

    }

    public static String convertDateUTCToZonedTime(Date date, String timeZone) {
	DateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	String validDate = dateFormat.format(date);

	if (StringUtils.isEmpty(timeZone) || !(isValidTimeZone(timeZone))) {
	    return validDate;
	}

	ZonedDateTime localDateTime = LocalDateTime
		.parse(validDate, DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))
		.atZone(ZoneId.of(Constants.UTC));

	ZonedDateTime utc = localDateTime.withZoneSameInstant(ZoneId.of(timeZone));
	return utc.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.DATE_FORMAT));

    }

    public static String convertZonedToUTC(String date, String timeZone) {
	if (StringUtils.isEmpty(timeZone) || !(isValidTimeZone(timeZone))) {
	    return date;
	}

	LocalDateTime localDateTime = LocalDateTime.parse(date,
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
	ZonedDateTime siteDateTime = ZonedDateTime.of(localDateTime, ZoneId.of(timeZone));

	ZonedDateTime utc = siteDateTime.withZoneSameInstant(ZoneId.of(Constants.UTC));
	return utc.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));

    }

    public static String convertUTCToZoned(String date, String timeZone) {
	if (StringUtils.isEmpty(timeZone) || !(isValidTimeZone(timeZone))) {
	    return date;
	}

	ZonedDateTime localDateTime = LocalDateTime
		.parse(date, DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))
		.atZone(ZoneId.of(Constants.UTC));

	ZonedDateTime utc = localDateTime.withZoneSameInstant(ZoneId.of(timeZone));
	return utc.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));

    }

    public static String convertZonedToUTCDate(String date, String timeZone) {
	if (StringUtils.isEmpty(timeZone) || !(isValidTimeZone(timeZone))) {
	    return date;
	}

	ZonedDateTime localDateTime = LocalDateTime
		.parse(date, DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))
		.atZone(ZoneId.of(timeZone));

	ZonedDateTime utc = localDateTime.withZoneSameInstant(ZoneId.of(Constants.UTC));
	return utc.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT));

    }

    public static String getShiftDateTimeUTC(Date date, String shiftTime, String siteTimeZone) {
	LocalDateTime localZoneDt = ZonedDateTime.ofInstant(date.toInstant(), ZoneId.of(siteTimeZone))
		.toLocalDateTime();
	String zoneDtStr = localZoneDt
		.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT));
	String zoneDateTimeStr = zoneDtStr + "T" + shiftTime;
	localZoneDt = LocalDateTime.parse(zoneDateTimeStr);
	ZonedDateTime utcDateTime = ZonedDateTime.of(localZoneDt, ZoneId.of(siteTimeZone))
		.withZoneSameInstant(ZoneOffset.UTC);
	return utcDateTime.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
    }

    public static Date convertStringToDate(String stringDate) throws Exception {
	if (StringUtils.isEmpty(stringDate)) {
	    return null;
	}
	try {
	    return new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT).parse(stringDate);
	} catch (Exception e) {
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
    }

    public static String getTimeFromDateObject(String dateStr) {
	Date date;
	try {
	    if (dateStr != null) {
		date = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME).parse(dateStr);
		String time = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT).format(date);
		return time;
	    }
	} catch (ParseException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return dateStr;
    }

    public static String getDateFromDateObject(String dateStr) {
	Date date;
	try {
	    if (dateStr != null) {
		date = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME).parse(dateStr);
		String time = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT).format(date);
		return time;
	    }
	} catch (ParseException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return dateStr;
    }

    public static String extractFechaDateInProcessableFormat(String inputDate) throws SystemException, Exception {
	try {
	    Pattern dtPtrn = Pattern.compile(Constants.DATE_TIME_FORMAT.PROCESSABLE_EVENT_DATETIME_FORMAT);
	    Matcher matcher = dtPtrn.matcher(inputDate);
	    if (!matcher.matches()) {
		throw new UnknownFormatConversionException(inputDate);
	    }
	    return matcher.group(1);
	} catch (Exception e) {
	    throw new SystemException(ErrorCodes.UNKNOWN_FORMAT_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, e.getMessage());
	}
    }

    public static String getDateObject(Date date) throws SystemException, Exception {
	String validDate;
	try {
	    DateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT);
	    validDate = dateFormat.format(date);
	    return validDate;
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, date);
	}

    }

    public static int generateLm2Seq(String unitId, String uid) {
	int lm2Seq = 0;
	if (unitId != null) {
	    uid = uid.replace(unitId, "");
	    lm2Seq = (Integer.parseInt(uid));
	}
	return lm2Seq;
    }

    public static Integer convertStringToInteger(String str) {
	if (str != null) {
	    return Integer.parseInt(str);
	}
	return null;
    }

    public static Double convertStringToDecimal(String str) {
	if (str != null) {
	    return Double.parseDouble(str);
	}
	return null;
    }
}
