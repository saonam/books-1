package com.hydro.api.reports.business;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.DailyReportEquipmentDTO;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.FormulaMetaDataDTO;
import com.hydro.api.dto.ProductDTO;
import com.hydro.api.dto.ShiftDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.TunnelDTO;
import com.hydro.api.dto.WasherMetaDataDTO;
import com.hydro.api.dto.reports.DailyReportResponseDTO;
import com.hydro.api.dto.reports.DataRequestDTO;
import com.hydro.api.dto.reports.DaywiseReportRequestDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.reports.business.DataRequestProcessorFactory.RequestProcessor;
import com.hydro.api.site.dao.SiteDao;
import com.hydro.api.site.dao.concrete.HydroSiteDao;

public class DaywiseHistoricalReport implements DataRequestProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(DaywiseHistoricalReport.class);

    private final ConfigReader config;
    private SiteDao hydroDao;
    private final ArrayList<String> supportedEquipmentTypes;

    public DaywiseHistoricalReport() throws Exception {
	hydroDao = new HydroSiteDao();
	config = ConfigReader.getObject();
	DataRequestDTO.EquipmentType[] equipmentTypes = DataRequestDTO.EquipmentType.values();
	supportedEquipmentTypes = new ArrayList<>();
	for (DataRequestDTO.EquipmentType type : equipmentTypes) {
	    supportedEquipmentTypes.add(type.name());
	}
    }

    @Override
    public Object getData(DataRequestDTO dataRequest, Map<RequestContextEntity, Object> context) throws Exception {
	
	validateRequest(dataRequest);
	
//	DataRequestDTO.EquipmentType equipmentType = null;
	Integer equipmentType = null;
	
	if(StringUtils.isBlank(dataRequest.getEquipmentId())) {
	    equipmentType = getEquipmentType(dataRequest).id();
	}

	SiteDTO site = getSiteDetails(dataRequest.getSiteId());

	List<EquipmentDTO> equipments = getEquipments(site, dataRequest.getEquipmentId(), equipmentType);

	if (context == null) {
	    context = new HashMap<RequestContextEntity, Object>();
	    context.put(DataRequestProcessor.RequestContextEntity.SITE, site);
	}
	
	ShiftDTO shift = getShiftDetails(dataRequest);

	DailyReportResponseDTO response = new DailyReportResponseDTO();

	DataRequestProcessor requestProcessor = null;
	for (EquipmentDTO equipment : equipments) {
	    context.put(DataRequestProcessor.RequestContextEntity.EQUIPMENT, equipment);

	    DataRequestDTO requestDto = getRequestDto(dataRequest, site, equipment);
	    if (equipment.getEquipmentType().equals(String.valueOf(DataRequestDTO.EquipmentType.WASHER.id()))) {
		requestProcessor = DataRequestProcessorFactory
			.getRequestProcessor(RequestProcessor.DAYWISE_WASHER);
//		response.setShift((ShiftDTO) requestProcessor.getData(requestDto, context));
	    } else if (equipment.getEquipmentType().equals(String.valueOf(DataRequestDTO.EquipmentType.TUNNEL.id()))) {
		requestProcessor = DataRequestProcessorFactory
			.getRequestProcessor(RequestProcessor.DAYWISE_TUNNEL);
//		response.setShift((ShiftDTO) requestProcessor.getData(requestDto, context));
	    }
	    shift.addEquipment((DailyReportEquipmentDTO) requestProcessor.getData(requestDto, context));
	}
	shift.setStartTime(null);
	shift.setEndTime(null);
	response.setShift(shift);
	
	return shift;
    }

    private SiteDTO getSiteDetails(String siteId) throws Exception {
	SiteDTO siteDTO = new SiteDTO();
	siteDTO.setSiteId(siteId);
	return ((SiteDao) hydroDao).getSiteDetails(siteDTO);
    }

    private List<EquipmentDTO> getEquipments(SiteDTO site, String equipmentId, Integer equipmentType) throws SystemException, Exception {
	List<EquipmentDTO> equipments = ((SiteDao) hydroDao).getEquipmentsDetail(site, equipmentId, equipmentType);
	
	for (EquipmentDTO equipment : equipments) {
	    if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.TUNNEL)) {
		List<TunnelDTO> tunnelList = ((SiteDao) hydroDao).getTunnelList(equipment);
		equipment.setTunnelList(tunnelList);
	    } else {
		List<WasherMetaDataDTO> washerList = ((SiteDao) hydroDao).getWasherList(equipment);
		equipment.setWasherList(washerList);
	    }
	    List<FormulaMetaDataDTO> formulaList = ((SiteDao) hydroDao).getFormulaList(equipment);
	    equipment.setFormulaList(formulaList);
	    List<ProductDTO> productList = ((SiteDao) hydroDao).getProductList(equipment);
	    Map<String, String> productMap = new HashMap<>();
	    for (ProductDTO productDTO : productList) {
		if (!StringUtils.isEmpty(productDTO.getLm2Seq())) {
		    productMap.put(productDTO.getLm2Seq(), productDTO.getName());
		}
	    }
	    equipment.setProductMap(productMap);
	    equipment.setProductList(productList);

	}
	if (CollectionUtils.isEmpty(equipments)) {
	    throw new SystemException(ErrorCodes.INVALID_EQUIPMENT_ID, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	return equipments;
    }

    private DaywiseReportRequestDTO getRequestDto(DataRequestDTO dataRequest, SiteDTO site, EquipmentDTO equipment)
	    throws Exception {
	ConfigReader config = new ConfigReader();
	DaywiseReportRequestDTO reportRequest = new DaywiseReportRequestDTO();
	reportRequest.setHistoricalReport(true);
	reportRequest.setSiteId(dataRequest.getSiteId());
	reportRequest.setEquipmentId(equipment.getEquipmentId());

	LocalDateTime fromDate = LocalDateTime.parse(dataRequest.getFromDate(),
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.DATE_FORMAT));
	LocalDateTime toDate = LocalDateTime.parse(dataRequest.getToDate(),
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.DATE_FORMAT));

	String date = fromDate.toLocalDate()
		.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT));

	SimpleDateFormat localDateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT);
	Date convertedDate;
	try {
	    convertedDate = localDateFormat.parse(date);
	} catch (ParseException e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, date);
	}

	reportRequest.setDate(convertedDate);
	reportRequest.setStartShift(
		fromDate.toLocalTime().format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.TIME_FORMAT)));
	reportRequest.setEndShift(
		toDate.toLocalTime().format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.TIME_FORMAT)));

	ShiftDTO fullDayShift = new ShiftDTO();
	fullDayShift.setShiftName("Full Day");
	fullDayShift.setStartTime(reportRequest.getStartShift());
	fullDayShift.setEndTime(reportRequest.getEndShift());
	List<ShiftDTO> selectedShifts = new ArrayList<>();
	selectedShifts.add(fullDayShift);
	reportRequest.setSelectedShifts(selectedShifts);
	return reportRequest;
    }
    
    private void validateRequest(DataRequestDTO reportRequest) throws Exception {
	
	List<Object> params = getInsufficientParamsDaywiseHistoricalReport(reportRequest);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	
	LocalDateTime fromDate = null;
	LocalDateTime toDate = null;

	try {
	    fromDate = LocalDateTime.parse(reportRequest.getFromDate(),
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.DATE_FORMAT));
	} catch (DateTimeParseException e) {
	    throw new SystemException(ErrorCodes.BAD_REQUEST, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST,
		    String.format("fromDate %s not in expected format yyyy-MM-dd HH:mm:ss", reportRequest.getFromDate()));
	}
	
	try {
	    toDate = LocalDateTime.parse(reportRequest.getToDate(),
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.DATE_FORMAT));
	} catch(DateTimeParseException e) {
	    throw new SystemException(ErrorCodes.BAD_REQUEST, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST,
		    String.format("toDate %s not in expected format yyyy-MM-dd HH:mm:ss", reportRequest.getToDate()));
	}

	if (!fromDate.toLocalDate().equals(toDate.toLocalDate())) {
	    throw new SystemException(ErrorCodes.DATE_RANGE_NOT_VALID, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST,
		    String.format("fromDate : %s and toDate : %s must be on same day.", reportRequest.getFromDate(), reportRequest.getToDate()));
	}
	
	if(fromDate.isAfter(toDate)) {
	    throw new SystemException(ErrorCodes.DATE_RANGE_NOT_VALID, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST,
		    String.format("fromDate : %s must be smaller than toDate : %s.", reportRequest.getFromDate(), reportRequest.getToDate()));
	}

	if (StringUtils.isBlank(config.getAppConfig(Constants.PG_MAX_DAYS_THRESHOLD))) {
	    throw new SystemException(ErrorCodes.MISSING_CONFIG_PROPERTY, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE,
		    String.format("Configuration property %s is missing.", Constants.PG_MAX_DAYS_THRESHOLD));
	}
	long pgMaxDaysThreshold = Long.valueOf(config.getAppConfig(Constants.PG_MAX_DAYS_THRESHOLD));

	if (Duration.between(toDate, fromDate).toDays() > pgMaxDaysThreshold) {
	    throw new SystemException(ErrorCodes.BAD_REQUEST, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST,
		    String.format(
			    "Difference between fromDate : %s and toDate : %s is greater than allowed limit of %d days",
			    fromDate.toString(), toDate.toString(), pgMaxDaysThreshold));
	}
    }

    private List<Object> getInsufficientParamsDaywiseHistoricalReport(DataRequestDTO reportRequest) {
	List<Object> params = new LinkedList<>();
	if (reportRequest == null) {
	    params.add(ErrorCodes.InsufficientParams.REPORT_REQUEST_OBJECT);
	    return params;
	}
	if (reportRequest.getSiteId()==null || StringUtils.isEmpty(reportRequest.getSiteId())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_ID);
	}
	if (reportRequest.getFromDate()==null || StringUtils.isEmpty(reportRequest.getFromDate().toString())) {
	    params.add(ErrorCodes.InsufficientParams.FROM_DATE);
	}
	if (reportRequest.getToDate()==null || StringUtils.isEmpty(reportRequest.getToDate().toString())) {
	    params.add(ErrorCodes.InsufficientParams.TO_DATE);
	}
	return params;
    }
    
    private DataRequestDTO.EquipmentType getEquipmentType(DataRequestDTO dataRequest) throws SystemException {
	
	String equipmentTypeStr = dataRequest.getEquipmentType();

	if (StringUtils.isBlank(equipmentTypeStr)) {
	    equipmentTypeStr = DataRequestDTO.EquipmentType.BOTH.name();
	}

	if (!supportedEquipmentTypes.contains(equipmentTypeStr.toUpperCase())) {
	    throw new SystemException(ErrorCodes.BAD_REQUEST, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST,
		    String.format("equipmentType %s not supported.", equipmentTypeStr));
	}

	return DataRequestDTO.EquipmentType.valueOf(equipmentTypeStr.toUpperCase());
    }

    private ShiftDTO getShiftDetails(DataRequestDTO dataRequest) {

	LocalDateTime fromDate = LocalDateTime.parse(dataRequest.getFromDate(),
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.DATE_FORMAT));
	LocalDateTime toDate = LocalDateTime.parse(dataRequest.getToDate(),
		DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.DATE_FORMAT));
	
	String startShift = fromDate.toLocalTime().format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.TIME_FORMAT));
	String endShift = toDate.toLocalTime().format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.TIME_FORMAT));

	ShiftDTO shift = new ShiftDTO();
	shift.setShiftName("Full Day");
	shift.setStartTime(startShift);
	shift.setEndTime(endShift);
	shift.setEquipments(new ArrayList<DailyReportEquipmentDTO>());
	
	return shift;
    }
}
