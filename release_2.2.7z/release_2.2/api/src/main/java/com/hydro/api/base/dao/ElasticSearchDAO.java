package com.hydro.api.base.dao;

import java.io.IOException;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import javax.ws.rs.core.HttpHeaders;

import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.ESConfig;
import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.exception.SystemException;

import io.searchbox.client.JestClient;
import io.searchbox.client.JestClientFactory;
import io.searchbox.client.JestResult;
import io.searchbox.client.config.HttpClientConfig;
import io.searchbox.core.Bulk;
import io.searchbox.core.Bulk.Builder;
import io.searchbox.core.DocumentResult;
import io.searchbox.core.Get;
import io.searchbox.core.Index;
import io.searchbox.core.MultiSearch;
import io.searchbox.core.MultiSearchResult;
import io.searchbox.core.Search;
import io.searchbox.core.SearchResult;
import io.searchbox.params.Parameters;

/**
 * Data Access Layer for Elastic Search
 * 
 * @author Shreyas K C
 *
 * 
 */
public class ElasticSearchDAO {
    private static Logger LOG = LoggerFactory.getLogger(ElasticSearchDAO.class);

    private JestClient jestClient;
    private static int retryCount;
    private static boolean isTest;
    private static int retryTime = 30000;
    private Builder bulkBuilder;

    /**
     * private Constructor.
     */
    private ElasticSearchDAO() {
	LOG.info("Creating new ES DAO Object");
    }

    /**
     * Method returning the Singleton Instance.
     * 
     * @param isTest
     * @return
     */
    public ElasticSearchDAO(boolean isTest, ESConfig config) {
	init(isTest, config);
    }

    /**
     * Init Method
     * 
     * @param isTest
     */
    private void init(boolean test, ESConfig config) {
	isTest = test;
	// For Test Cases, there is no need to initialize the ES related
	// details.
	retryCount = config.getRetryCount();
	if (isTest) {
	    return;
	}
	JestClientFactory factory = new JestClientFactory();
	ConfigReader configReader = new ConfigReader();
	String username = configReader.getAppConfig(Constants.ES_USERNAME);
	String password = configReader.getAppConfig(Constants.ES_PASSWORD);
	factory.setHttpClientConfig(new HttpClientConfig.Builder(config.getEsClusterJestUrl()).multiThreaded(true)
		.connTimeout(config.getMaxEsConnTimeout()).readTimeout(config.getMaxEsReadTimeout())
		.maxTotalConnection(config.getMaxEsConnections()).defaultCredentials(username, password).build());
	jestClient = factory.getObject();
    }

    public void closeJestClient() {
	try {
	    jestClient.close();
	} catch (IOException e) {
	    LOG.error("Error closing jest client : " + e.getMessage());
	    e.printStackTrace();
	}
    }

    /**
     * Common method to Retry
     * 
     * @param count
     * @return
     */
    public boolean retry(int count) {
	if (count >= retryCount) {
	    LOG.error("Exceeded the number of retries..." + retryCount + " hence aborting connection to ES.");
	    return false;
	}
	// Increments 30 Second for every retry.
	int delayTime = count * retryTime;
	LOG.info("Max ES Retry Count :" + retryCount);
	LOG.info("Sleeping for " + delayTime + "seconds before connecting to elastic search");
	LOG.info("Retrying for the " + count + " time. Delay time: " + delayTime);
	try {
	    Thread.sleep(delayTime);
	} catch (InterruptedException e) {
	    e.printStackTrace();
	    LOG.error("Exception : " + e.getLocalizedMessage());
	    return false;
	}
	return true;
    }

    /**
     * Queries Elasticsearch as specified by a search action and returns the results
     * as a JsonObject.
     * 
     * @param search - search action
     * 
     * @return resultJsonObject - JsonObject containing the results of query
     *         execution
     */
    public JsonObject executeQuery(String query, List<String> indexList, String type) throws Exception {
	Search search = new Search.Builder(query).addIndices(indexList).addType(type).ignoreUnavailable(true).build();
	int count = 0;
	SearchResult searchResult = null;
	if (indexList != null && !indexList.isEmpty()) {
	    while (true) {
		try {
		    searchResult = jestClient.execute(search);
		    break;
		} catch (IOException e) {
		    LOG.error("IOException while executing query from elastic search " + search);
		    LOG.error("Error :  " + e.getMessage());
		    e.printStackTrace();
		    if (!retry(++count)) {
			// If the Retry completed then stop retrying. Else
			// continue.
			break;
		    }
		} finally {
		    try {
			jestClient.close();
		    } catch (IOException e) {
			LOG.error("Error closing jest client : " + e.getMessage());
			e.printStackTrace();
		    }
		}
	    }
	}
	if (indexList.isEmpty()) {
	    LOG.debug("no index found");
	    return null;
	}
	if (searchResult == null) {
	    return null;
	}
	JsonObject jsonObject = searchResult.getJsonObject();

	LOG.debug("Search result - getJsonObject: " + jsonObject);
	return jsonObject;
    }

    public List<JsonObject> executeMultiSearch(List<String> queriesStr, List<String> indices, String type)
	    throws Exception {
	List<Search> queries = new ArrayList<>();
	for (String queryStr : queriesStr) {
	    queries.add(new Search.Builder(queryStr).addIndices(indices).addType(type).ignoreUnavailable(true).build());
	}
	long start = System.currentTimeMillis();
	JsonObject multiSearchResponse = executeMultipleQuery(queries);
	long end = System.currentTimeMillis();
	LOG.info("Total time taken for ES query>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> " + queriesStr + "  {}",
		(end - start));
	handleEsError(multiSearchResponse);

	JsonArray responses = multiSearchResponse.getAsJsonArray(Constants.REPORTS.RESPONSES);
	if (responses.size() != queriesStr.size()) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
	List<JsonObject> results = new ArrayList<>();
	for (int i = 0; i < responses.size(); i++) {
	    results.add(responses.get(i).getAsJsonObject());
	}

	return results;
    }

    public List<JsonObject> executeMultipleQueries(List<String> queriesStr, List<String> indices, String type)
	    throws Exception {
	List<JsonObject> results = new ArrayList<>();
	for (String queryStr : queriesStr) {
	    results.add(executeQuery(queryStr, indices, type));
	}
	return results;
    }

    /**
     * Queries Elasticsearch as specified by a search action using multi search
     * query and returns the results as a JsonObject.
     * 
     * @param search - search action
     * 
     * @return resultJsonObject - JsonObject containing the results of query
     *         execution
     */
    public JsonObject executeMultipleQuery(List<Search> searchQueries) throws Exception {
	MultiSearch multiSearch = new MultiSearch.Builder(searchQueries).build();
	int count = 0;
	MultiSearchResult searchResult = null;
	while (true) {
	    try {
		searchResult = jestClient.execute(multiSearch);
		break;
	    } catch (IOException e) {
		LOG.error("IOException while executing query from elastic search " + multiSearch);
		LOG.error("Error :  " + e.getMessage());
		e.printStackTrace();
		if (!retry(++count)) {
		    // If the Retry completed then stop retrying. Else
		    // continue.
		    break;
		}
	    } finally {
		try {
		    jestClient.close();
		} catch (IOException e) {
		    LOG.error("Error closing jest client : " + e.getMessage());
		    e.printStackTrace();
		}
	    }
	}
	if (searchResult == null) {
	    return null;
	}
	JsonObject jsonObject = searchResult.getJsonObject();

	LOG.debug("Search result - getJsonObject: " + jsonObject);
	return jsonObject;
    }

    /**
     * Prepares the bulk body to be inserted into Elasticsearch
     * 
     * @param esIndex
     * @param esType
     * @param id
     * @param toJson
     */

    public void prepareBulk(String esIndex, String esType, String id, String toJson) {

	if (bulkBuilder == null) {
	    bulkBuilder = new Bulk.Builder();
	    bulkBuilder.defaultIndex(esIndex).defaultType(esType).toggleApiParameter(Parameters.OP_TYPE + "=create",
		    true);
	    bulkBuilder.setHeader(HttpHeaders.CONTENT_TYPE, "application/json");
	}
	try {
	    bulkBuilder.addAction(new Index.Builder(toJson).id(id).build());
	} catch (Exception e) {
	    LOG.error("Failed to build bulk object for id : " + id);
	    e.printStackTrace();
	}

    }

    /**
     * Checks if a particular ID exists or not in Elasticsearch
     * 
     * @param esIndex
     * @param esType
     * @param id
     * @return boolean
     * @throws IOException
     * @throws SystemException
     */

    public boolean checkIfIdExists(String esIndex, String esType, String id) throws IOException {

	Get get = new Get.Builder(esIndex, id).type(esType).build();
	JestResult jestResult = jestClient.execute(get);
	if (jestResult != null) {
	    if ((jestResult.getResponseCode() / 2) == 2) {
		return true;
	    }
	}
	return false;

    }

    public static void main(String args[]) throws Exception {
	ConfigReader configReader = ConfigReader.getObject();
	ElasticSearchDAO esDAO = new ElasticSearchDAO(false, configReader.getEsConfig());
	// String payload = "{\"key\":1,\"val\":\"hello\"}";
	// esDAO.prepareBulk("test", "test", "1", payload);
	// // payload = "{\"key\":2,\"val\":\"hello2\"}";
	// // esDAO.prepareBulk("test", "test", "2", payload);
	// // payload = "{\"key\":3,\"val\":\"hello3\"}";
	// // esDAO.prepareBulk("test", "test", "3", payload);
	// // payload = "{\"key\":1,\"val\":\"hello4\"}";
	// // esDAO.prepareBulk("test", "test", "1", payload);
	// Object res = esDAO.jestClient.execute(esDAO.bulkBuilder.build());
	String query;
	query = ReportUtils.getQuery("MatchAll.json");
	List<String> indexName = new LinkedList<>();
	indexName.add("hydro-d3f9f980c28143c3a2f56ccce0daa7d3-3-2017");
	indexName.add("hydro-d3f9f980c28143c3a2f56ccce0daa7d3-6-2017");
	LOG.info(esDAO.executeQuery(query, indexName, "hydro-events").toString());
	System.out.println("Done");
    }

    public void indexDocument(String doc, String index, String esType, String id) throws Exception {
	try {
	    Index indexAction = new Index.Builder(doc).index(index).type(esType).id(id).build();
	    DocumentResult actionResult = jestClient.execute(indexAction);
	    if (!actionResult.isSucceeded()) {
		LOG.error("Failed to index document to index : " + index + " for the reason : "
			+ actionResult.getErrorMessage());
	    } else {
		LOG.info("Document successfully indexed to : " + index);
	    }
	} catch (IOException ioe) {
	    throw new SystemException(ioe, ErrorCodes.ES_COMMUNICATION_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
    }

    public static void handleEsError(JsonObject responseObject) throws Exception {
	if (responseObject == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	Set<String> errors = new HashSet<>();
	if (responseObject.has(Constants.REPORTS.RESPONSES)
		&& responseObject.get(Constants.REPORTS.RESPONSES).isJsonArray()) {
	    JsonArray responses = responseObject.get(Constants.REPORTS.RESPONSES).getAsJsonArray();
	    responses.forEach(element -> {
		if (element != null && element.isJsonObject()
			&& element.getAsJsonObject().has(Constants.REPORTS.ERROR)) {
		    addErrorDetail(errors, element.getAsJsonObject().get(Constants.REPORTS.ERROR).getAsJsonObject());
		}
	    });
	} else {
//	    JsonObject esError = (JsonObject) responseObject.get(Constants.REPORTS.ERROR);
	    if (responseObject.getAsJsonObject().has(Constants.REPORTS.ERROR)) {
		addErrorDetail(errors, responseObject.get(Constants.REPORTS.ERROR).getAsJsonObject());
//		LOG.error("ES Error" + responseObject);
//		JsonArray jArray = esError.getAsJsonArray(Constants.REPORTS.ROOT_CAUSE);
//		esError = jArray.get(0).getAsJsonObject();
//		String esErrorType = esError.get(Constants.REPORTS.TYPE).getAsString();
//		switch (esErrorType) {
//		case Constants.ES_EXCEPTION_TYPE.INDEX_NOT_FOUND_EXCEPTION:
//		    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
//			    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
//		default:
//		    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
//			    ErrorCodes.StatusCodes.FAILURE, null);
//		}
	    }
	}
	if (errors.size() > 0) {
	    if (errors.size() == 1 && errors.contains(Constants.ES_EXCEPTION_TYPE.INDEX_NOT_FOUND_EXCEPTION)) {
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    } else if (errors.size() == 1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    } else {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, errors.toArray(new String[0]));
	    }
	}
    }

    private static void addErrorDetail(Set<String> errors, JsonObject error) {
	LOG.error("ES Error" + error);
	JsonObject errorDetail = error.getAsJsonArray(Constants.REPORTS.ROOT_CAUSE).get(0).getAsJsonObject();
	String errorType = errorDetail.get(Constants.REPORTS.TYPE).getAsString();
	errors.add(errorType);
    }
    
    public JsonArray getEvents(SiteDTO siteDto, EquipmentDTO equipment, String fromDateTime, String toDateTime)
	    throws SystemException, Exception {

	String fromDate = java.time.LocalDateTime
		.parse(fromDateTime, DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))
		.toLocalDate().format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT));
	String toDate = java.time.LocalDateTime
		.parse(toDateTime, DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))
		.toLocalDate().format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT));

	List<String> indices = ReportUtils.getExistingIndices(fromDate, toDate, siteDto);
	String query = ReportUtils.prepareQuery(Constants.REPORTS.REAL_TIME_REPORT,
		new String[][] { { Constants.START_TIME, fromDateTime }, { Constants.END_TIME, toDateTime },
			{ Constants.DEVICE_ID_VAL, equipment.getDeviceId() } });
	ConfigReader config = new ConfigReader();
	JsonObject responseObject = executeQuery(query, indices, config.getAppConfig(Constants.ES_TYPE));
	handleEsError(responseObject);
	JsonObject firstHitsObject = (JsonObject) responseObject.get(Constants.REPORTS.HITS);
	if (firstHitsObject != null) {
	    return ReportUtils.fieldsQuery(firstHitsObject);
	} else {
	    return null;
	}
    }
}
