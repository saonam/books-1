package com.hydro.api.account.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.base.dao.HydroDao;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.AccountDTO;
import com.hydro.api.dto.AccountListResponseDTO;
import com.hydro.api.dto.ContactDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;

/**
 *
 * @author Shreyas
 * 
 */
public abstract class AccountDao extends HydroDao {
    private static final Logger LOG = LoggerFactory.getLogger(AccountDao.class);

    public abstract AccountListResponseDTO getAccountList(UserDTO user, AccountDTO account) throws Exception;

    public abstract List<SiteDTO> getSiteListForAccount(UserDTO user, AccountDTO accountDTO) throws Exception;

    public abstract List<ContactDTO> getContactListForAccount(AccountDTO account) throws Exception;

    public abstract boolean hasVisibility(UserDTO user, AccountDTO accountDTO) throws Exception;

    public abstract boolean updateAccount(UserDTO user, AccountDTO accountDTO) throws Exception;

    public abstract AccountDTO createAccount(UserDTO user, AccountDTO accountDTO) throws Exception;

    public abstract String accountNameExists(AccountDTO accountDTO) throws Exception;

    public boolean testAccountDbConnection() {
	Database database = null;
	try {
	    database = new Database();

	    if (database.connection != null) {
		return true;
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    return false;
	} finally {
	    if (database != null) {
		try {
		    database.closeConnection();
		} catch (SQLException e) {
		    e.printStackTrace();
		}
	    }
	}
	return false;
    }

    protected AccountListResponseDTO getAccountListData(ResultSet rs, String timeZone) throws SQLException {
	AccountListResponseDTO response = new AccountListResponseDTO();
	List<AccountDTO> accountList = new LinkedList<>();
	while (rs.next()) {
	    // SELECT business_id,name,state,zipcode,city,created_by FROM
	    // BUSINESS_MASTER where business_type = ?
	    AccountDTO account = new AccountDTO();
	    account.setAccountId(rs.getString(SQLColumns.BUSINESS_ID));
	    account.setName(rs.getString(SQLColumns.NAME));
	    account.setState(rs.getString(SQLColumns.STATE));
	    account.setZipCode(rs.getString(SQLColumns.ZIPCODE));
	    account.setCity(rs.getString(SQLColumns.CITY));
	    account.setCreatedBy(rs.getString(SQLColumns.CREATED_BY));
	    account.setCountry(rs.getString(SQLColumns.COUNTRY));
	    account.setCreatedDate(CommonUtils.convertDate(rs.getString(SQLColumns.CREATED_DATE), timeZone));

	    accountList.add(account);
	}
	response.setAccountList(accountList);
	return response;
    }

    protected List<SiteDTO> getAccountSiteData(ResultSet rs) throws SQLException {
	List<SiteDTO> siteList = new LinkedList<>();
	while (rs.next()) {
	    SiteDTO siteDTO = new SiteDTO();
	    siteDTO.setSiteId(rs.getString(SQLColumns.SITE_ID));
	    siteDTO.setSiteName(rs.getString(SQLColumns.SITE_NAME));
	    siteList.add(siteDTO);
	}
	return siteList;
    }

    protected List<ContactDTO> getAccountContactData(ResultSet rs) throws SQLException {
	List<ContactDTO> contactList = new LinkedList<>();
	while (rs.next()) {
	    ContactDTO contact = new ContactDTO();
	    // siteDTO.setSiteId(rs.getString(SQLColumns.));
	    // siteDTO.setSiteName(rs.getString(SQLColumns.SITE_NAME));
	    // SELECT contact_email, contact_name, contact_number, contact_title
	    // from CONTACT_MASTER where business_id = ?
	    contact.setContactId(rs.getString(SQLColumns.CONTACT_ID));
	    contact.setEmail(rs.getString(SQLColumns.CONTACT_EMAIL));
	    contact.setName(rs.getString(SQLColumns.CONTACT_NAME));
	    contact.setNumber(rs.getString(SQLColumns.CONTACT_NUMBER));
	    contact.setTitle(rs.getString(SQLColumns.CONTACT_TITLE));
	    contactList.add(contact);

	}
	return contactList;
    }

    /**
     * Method to fetch account details.
     * 
     * @param accountDTO
     * @return
     * @throws Exception
     */
    public AccountDTO getAccountDetails(AccountDTO accountDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_ACCOUNT_DETAILS;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.BusinessTypes.ACCOUNT);
	    params.add(accountDTO.getAccountId());

	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		AccountDTO account = new AccountDTO();
		account.setAccountId(rs.getString(SQLColumns.BUSINESS_ID));
		account.setName(rs.getString(SQLColumns.NAME));
		account.setAddress1(rs.getString(SQLColumns.ADDRESS1));
		account.setAddress2(rs.getString(SQLColumns.ADDRESS2));
		account.setState(rs.getString(SQLColumns.STATE));
		account.setCountry(rs.getString(SQLColumns.COUNTRY));
		account.setCity(rs.getString(SQLColumns.CITY));
		account.setZipCode(rs.getString(SQLColumns.ZIPCODE));
		account.setDescription(rs.getString(SQLColumns.DESCRIPTION));
		return account;
	    } else {
		throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static HashSet<String> getContactAssociatedToAccount(AccountDTO account) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_CONTACT_ID_FOR_BUSINESS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(account.getAccountId());
	    HashSet<String> ContactIdSet = new HashSet<>();
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    while (rs.next()) {
		ContactIdSet.add(rs.getString(SQLColumns.CONTACT_ID));
	    }
	    return ContactIdSet;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public LinkedList<Object> getAccountListOnStartEndDate(AccountDTO account) {
	String createdStartDate = account.getCreatedDateStart();
	String createdEndDate = account.getCreatedDateEnd();
	LinkedList<Object> params = new LinkedList<>();
	if (createdStartDate != null && createdEndDate != null) {
	    params.add(createdStartDate);
	    params.add(createdEndDate);
	}
	return params;
    }
}
