/**
 * 
 */
package com.hydro.api.base.common;

import com.hydro.api.lm2elements.NewDataSet.TablaEquipos;
import com.hydro.api.lm2elements.NewDataSet.TablaFormulas;
import com.hydro.api.lm2elements.NewDataSet.TablaTuneles;

public class EquipmentWrapperDTO {

    private TablaEquipos equipment;
    private TablaFormulas formula;
    private TablaTuneles tunnels;
    private String id;
    private String formulaId;
    private String tunnelId;
    private int lm2Seq;

    public TablaEquipos getEquipment() {
	return equipment;
    }

    public void setEquipment(TablaEquipos equipment) {
	this.equipment = equipment;
    }

    public TablaFormulas getFormula() {
	return formula;
    }

    public void setFormula(TablaFormulas formula) {
	this.formula = formula;
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getFormulaId() {
	return formulaId;
    }

    public void setFormulaId(String formulaId) {
	this.formulaId = formulaId;
    }

    public String getTunnelId() {
	return tunnelId;
    }

    public void setTunnelId(String tunnelId) {
	this.tunnelId = tunnelId;
    }

    public TablaTuneles getTunnels() {
	return tunnels;
    }

    public void setTunnels(TablaTuneles tunnels) {
	this.tunnels = tunnels;
    }
    
    public int getLm2Seq() {
        return lm2Seq;
    }

    public void setLm2Seq(int lm2Seq) {
        this.lm2Seq = lm2Seq;
    }
}
