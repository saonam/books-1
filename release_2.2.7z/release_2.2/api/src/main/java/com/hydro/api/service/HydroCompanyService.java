package com.hydro.api.service;

import java.security.Principal;
import java.util.LinkedList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.company.business.HydroCompanyBL;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.CompanyDTO;
import com.hydro.api.dto.CompanyListResponseDTO;
import com.hydro.api.dto.CreateSiteAssociationDTO;
import com.hydro.api.dto.SiteAssociationDTO;
import com.hydro.api.dto.SiteAssociationListResponseDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.SiteListResponseDTO;
import com.hydro.api.dto.StatusDTO;
import com.hydro.api.exception.ExceptionHandler;
import com.hydro.api.exception.SystemException;
import com.hydro.api.service.helper.ServiceHelper;

/**
 * Base Service : Entry Point to the JSON APIs.
 * 
 * @author Shreyas
 *
 */
// No Base context root for the Services. Each services have their respective
// Endpoints.
@Path(Constants.COMPANY_MODULES.CONTEXT)
@Produces({ MediaType.APPLICATION_JSON })
public class HydroCompanyService extends HydroBaseService {
    private static final Logger LOG = LoggerFactory.getLogger(HydroCompanyService.class);

    public HydroCompanyService(@Context SecurityContext securityContext,
	    @HeaderParam(Constants.TIME_ZONE_HEADER) String timeZone) throws Exception {
	super();
	Principal principal = securityContext.getUserPrincipal();
	String username = principal.getName();
	BL = new HydroCompanyBL(username, timeZone);
    }

    /**
     * Test API.
     * 
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/test")
    public String test() {
	long start = System.currentTimeMillis();
	resStr = "{\"messgae\":\"Company APIs Works Fine!\"}";
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * Testing the DB connection.
     * 
     * @return
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/testDbConnection")
    public String testDbConnection() {
	long start = System.currentTimeMillis();

	try {
	    BL.initRoutine();
	    // Check for the Database connection.
	    boolean flag = ((HydroCompanyBL) BL).testCompanyDbConnection();
	    if (flag) {
		resStr = "{ \"connected\":true}";
	    } else {
		resStr = "{ \"connected\":false}";
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @GET
    @Path(Constants.COMPANY_MODULES.GET_ALL_LIST)
    @Produces(MediaType.APPLICATION_JSON)

    public String getCompanyList(@QueryParam("createdStartDate") String createdStartDate,
	    @QueryParam("createdEndDate") String createdEndDate, @QueryParam("sortByName") boolean sortByName)
	    throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    CompanyDTO company = new CompanyDTO(sortByName, createdEndDate, createdStartDate);
	    CompanyListResponseDTO cResponse = ((HydroCompanyBL) BL).getCompanyList(company);
	    responseDTO.setResponseObject(cResponse);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;

    }

    @POST
    @Path("/getCompanyDetails")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)

    public String getCompanyDetails(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    CompanyDTO companyDTO = (CompanyDTO) ServiceHelper.buildJsonString(body, CompanyDTO.class);
	    companyDTO = ((HydroCompanyBL) BL).getCompanyDetails(companyDTO);
	    responseDTO.setResponseObject(companyDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;

    }

    @GET
    @Path("/getSiteList")
    @Produces(MediaType.APPLICATION_JSON)

    public String getSiteList() throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    SiteListResponseDTO siteResponse = new SiteListResponseDTO();
	    List<SiteDTO> siteList = new LinkedList<>();
	    siteList = ((HydroCompanyBL) BL).getSiteList();
	    siteResponse.setSiteList(siteList);
	    responseDTO.setResponseObject(siteResponse);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;

    }

    @POST
    @Path("/createCompany")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String createCompany(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    CompanyDTO companyDTO = (CompanyDTO) ServiceHelper.buildJsonString(body, CompanyDTO.class);
	    companyDTO = ((HydroCompanyBL) BL).createCompany(companyDTO);
	    responseDTO.setResponseObject(companyDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @PUT
    @Path("/updateCompany")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String updateCompany(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    CompanyDTO companyDTO = (CompanyDTO) ServiceHelper.buildJsonString(body, CompanyDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroCompanyBL) BL).updateCompany(companyDTO));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/companyNameExists")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String companyNameExists(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    CompanyDTO comapnyDTO = (CompanyDTO) ServiceHelper.buildJsonString(body, CompanyDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroCompanyBL) BL).companyNameExists(comapnyDTO));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/deleteCompany")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String deleteCompany(String body) throws Exception {
	StatusDTO status = new StatusDTO();
	status.setStatus(true);
	responseDTO.setResponseObject(status);
	responseDTO.setResponseStatus(true);
	resStr = ServiceHelper.buildJsonString(status);
	return resStr;
    }

    @POST
    @Path("/getSiteAssociationList")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)

    public String getSiteAssociationList(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();

	    SiteAssociationListResponseDTO siteAssociationDTO = new SiteAssociationListResponseDTO();
	    List<SiteAssociationDTO> siteList = new LinkedList<>();
	    SiteAssociationDTO site = new SiteAssociationDTO();
	    site.setCompanyId("asso id");
	    site.setSiteId("Id val");
	    site.setSiteName("NAME");

	    site.setState("state");
	    site.setZipCode("123");

	    site.setServiceName("service name");
	    site.setServiceImage("url");
	    siteList.add(site);
	    siteAssociationDTO.setSiteAssociationList(siteList);
	    responseDTO.setResponseObject(siteAssociationDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(siteAssociationDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;

    }

    @POST
    @Path("/createSiteAssociation")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String createSiteAssociation(String body) throws Exception {
	CreateSiteAssociationDTO siteAssociation = new CreateSiteAssociationDTO();
	siteAssociation.setAssociationId("AssoId");
	responseDTO.setResponseObject(siteAssociation);
	responseDTO.setResponseStatus(true);
	resStr = ServiceHelper.buildJsonString(siteAssociation);
	return resStr;
    }

    @POST
    @Path("/updateSiteAssociation")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String updateSiteAssociation(String body) throws Exception {
	StatusDTO status = new StatusDTO();
	status.setStatus(true);
	responseDTO.setResponseObject(status);
	responseDTO.setResponseStatus(true);
	resStr = ServiceHelper.buildJsonString(status);
	return resStr;
    }

    @POST
    @Path("/deleteSiteAssociation")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String deleteSiteAssociation(String body) throws Exception {
	StatusDTO status = new StatusDTO();
	status.setStatus(true);
	responseDTO.setResponseObject(status);
	responseDTO.setResponseStatus(true);
	resStr = ServiceHelper.buildJsonString(status);
	return resStr;
    }

    @GET
    @Path("/getAlertSetting")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getAlertSetting() throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    CompanyDTO company = ((HydroCompanyBL) BL).getAlertSetting();
	    responseDTO.setResponseObject(company);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }
}
