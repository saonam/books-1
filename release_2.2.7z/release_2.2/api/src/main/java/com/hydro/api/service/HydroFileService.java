package com.hydro.api.service;

import java.io.InputStream;
import java.security.Principal;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.FileDTO;
import com.hydro.api.dto.FileHistoryListResponseDTO;
import com.hydro.api.dto.FileMetaDataDTO;
import com.hydro.api.dto.FileStatusDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.StatusDTO;
import com.hydro.api.exception.ExceptionHandler;
import com.hydro.api.exception.SystemException;
import com.hydro.api.file.business.HydroFileBL;
import com.hydro.api.service.helper.ServiceHelper;
import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

/**
 * File Service : Entry Point to the File Bases APIs
 * 
 * @author Shreyas
 *
 */
// No Base context root for the Services. Each services have their respective
// Endpoints.
@Path("/file")
@Produces({ MediaType.APPLICATION_JSON })
public class HydroFileService extends HydroBaseService {
    private static final Logger LOG = LoggerFactory.getLogger(HydroFileService.class);
    @Context
    SecurityContext securityContext;

    public HydroFileService(@Context SecurityContext securityContext,
	    @HeaderParam(Constants.TIME_ZONE_HEADER) String timeZone) throws Exception {
	super();
	Principal principal = securityContext.getUserPrincipal();
	String username = principal.getName();
	BL = new HydroFileBL(username, timeZone);
    }

    /**
     * Test API.
     * 
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/test")
    public String test() {
	long start = System.currentTimeMillis();
	resStr = "{\"messgae\":\"Summary APIs Works Fine!\"}";
	recordTime(start, resStr);
	return resStr;
    }

    /*
     * @GET
     * 
     * @Produces(MediaType.APPLICATION_JSON)
     * 
     * @Path("/testXmlParsing") public String testXmlParsing() {
     * 
     * FileDTO file = new FileDTO(); file.setName("LA_CALANDRA_LOCAL.LM2");
     * file.setFileId("testfileid2");
     * file.setSiteId("f2ecd9ea23e742b894d0cf3b73ef372b"); file.setVersion(1);
     * 
     * try {
     * 
     * ((HydroFileBL) BL).parsingLM2File(file,
     * "C:\\Temp\\Hydro\\LA-Calandra\\LA_CALANDRA_LOCAL.LM2"); } catch
     * (Exception e) { // TODO Auto-generated catch block e.printStackTrace(); }
     * return "success"; }
     */
    @POST
    @Path("/fileUpload")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    public String fileUpload(@FormDataParam("file") InputStream uploadedInputStream,
	    @FormDataParam("file") FormDataContentDisposition fileDetail, @FormDataParam("siteId") String siteId)
	    throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    StatusDTO statusDTO = new StatusDTO();
	    SiteDTO site = new SiteDTO();
	    site.setSiteId(siteId);
	    FileDTO file = new FileDTO();
	    file.setName(fileDetail.getFileName());
	    statusDTO.setStatus(((HydroFileBL) BL).fileUpload(uploadedInputStream, fileDetail, site, file));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/chunkFileUpload")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces(MediaType.APPLICATION_JSON)
    public String chunkFileUpload(@FormDataParam("file") InputStream uploadedInputStream,
	    @FormDataParam("file") FormDataContentDisposition fileDetail, @FormDataParam("siteId") String siteId,
	    @FormDataParam("metadata") String metadata) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    FileMetaDataDTO metaData = (FileMetaDataDTO) ServiceHelper.buildJsonString(metadata, FileMetaDataDTO.class);
	    FileStatusDTO statusDTO = new FileStatusDTO();
	    SiteDTO site = new SiteDTO();
	    site.setSiteId(siteId);
	    FileDTO file = new FileDTO();
	    file.setName(metaData.getFileName());
	    statusDTO = ((HydroFileBL) BL).chunkFileUpload(uploadedInputStream, fileDetail, site, file, metaData);
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @GET
    @Path("/getFileHistory")
    @Produces(MediaType.APPLICATION_JSON)
    public String getFileHistory() throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();

	    FileHistoryListResponseDTO fileHistoryList = ((HydroFileBL) BL).getFileHistory();
	    responseDTO.setResponseObject(fileHistoryList);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }
}
