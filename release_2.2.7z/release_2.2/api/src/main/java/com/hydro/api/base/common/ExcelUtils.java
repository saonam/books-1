package com.hydro.api.base.common;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.ss.util.RegionUtil;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.constants.Constants;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.reports.ReportRequestDTO;
import com.hydro.api.dto.reports.WarningDTO;

/**
 * @author Srishti Tiwari
 *
 */

public class ExcelUtils {
    private static final Logger LOG = LoggerFactory.getLogger(ReportUtils.class);

    public static CellStyle cellStyle(XSSFSheet sheet) {
	XSSFCellStyle cellStyle = sheet.getWorkbook().createCellStyle();
	XSSFFont font = sheet.getWorkbook().createFont();
	font.setBold(true);
	font.setFontHeightInPoints((short) 10);
	font.setFontName("Arial");
	cellStyle.setFont((Font) font);
	cellStyle.setWrapText(true);
	cellStyle.setAlignment(HorizontalAlignment.CENTER);
	cellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	return cellStyle;
    }

    public static CellStyle cellStyleForTopHeading(XSSFSheet sheet) {
	XSSFCellStyle cellStyle = sheet.getWorkbook().createCellStyle();
	XSSFFont font = sheet.getWorkbook().createFont();
	font.setBold(true);
	font.setFontHeightInPoints((short) 12);
	font.setFontName("Arial");
	cellStyle.setFont((Font) font);
	cellStyle.setWrapText(true);
	cellStyle.setAlignment(HorizontalAlignment.LEFT);
	cellStyle.setFillForegroundColor(IndexedColors.SKY_BLUE.getIndex());
	cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	return cellStyle;
    }

    public static CellStyle cellStyleSideHeading(XSSFSheet sheet) {
	XSSFCellStyle cellStyle = sheet.getWorkbook().createCellStyle();
	XSSFFont font = sheet.getWorkbook().createFont();
	font.setBold(true);
	font.setFontHeightInPoints((short) 10);
	font.setFontName("Arial");
	font.setColor(IndexedColors.BLUE_GREY.getIndex());
	cellStyle.setFont((Font) font);
	cellStyle.setWrapText(true);
	cellStyle.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
	return cellStyle;
    }

    public static CellStyle cellStyleSubHeading(XSSFSheet sheet) {
	XSSFCellStyle cellStyle = sheet.getWorkbook().createCellStyle();
	XSSFFont font = sheet.getWorkbook().createFont();
	font.setBold(true);
	font.setFontHeightInPoints((short) 8);
	font.setFontName("Arial");
	font.setColor(IndexedColors.BLUE_GREY.getIndex());
	cellStyle.setFont((Font) font);
	cellStyle.setWrapText(true);
	cellStyle.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
	return cellStyle;
    }

    public static CellStyle cellStyleError(XSSFSheet sheet) {
	XSSFCellStyle cellStyle = sheet.getWorkbook().createCellStyle();
	XSSFFont font = sheet.getWorkbook().createFont();
	font.setBold(true);
	font.setFontHeightInPoints((short) 10);
	font.setFontName("Arial");
	cellStyle.setFont((Font) font);
	return cellStyle;
    }

    public static Cell createCell(Row row, int cellCount, String cellValue) {
	Cell cell = null;
	if (row != null) {
	    cell = row.createCell(cellCount);
	    cell.setCellValue(cellValue);
	    return cell;
	}
	return cell;
    }

    public static int getColumnIndex(XSSFSheet sheet, String cellString) {
	if (sheet != null && !StringUtils.isEmpty((CharSequence) cellString)) {
	    DataFormatter dataFormatter = new DataFormatter();
	    for (Row rowiterator : sheet) {
		for (Cell cellIterator : rowiterator) {
		    if (dataFormatter.formatCellValue(cellIterator).equalsIgnoreCase(cellString))
			return cellIterator.getColumnIndex();
		}
	    }
	}
	return 0;
    }

    public static XSSFSheet createTopHeadings(XSSFWorkbook workbook, XSSFSheet sheet, int rowCount, int cellCount,
	    SiteDTO site, String reportTag, String maxDate, String minDate, ReportRequestDTO reportRequest) {
	String equipmentName = reportRequest.getEquipmentName().trim();
	int rowIndex = rowCount;
	if (sheet != null && site != null) {
	    Row row = sheet.createRow(rowCount++);
	    int firstColumn = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;
	    int lastColumn = 6;
	    Cell cell = ExcelUtils.createCell(row, cellCount,
		    Constants.REPORT_EXPORT_CONSTANTS.SITE + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + Constants.REPORT_EXPORT_CONSTANTS.COLON + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + site.getSiteName());

	    sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, firstColumn, lastColumn));
	    cell.setCellStyle(ExcelUtils.cellStyleForTopHeading(sheet));

	    rowIndex = rowCount;
	    row = sheet.createRow(rowCount++);
	    cell = ExcelUtils.createCell(row, cellCount,
		    Constants.REPORT_EXPORT_CONSTANTS.COMPANY + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + Constants.REPORT_EXPORT_CONSTANTS.COLON + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + Constants.REPORT_EXPORT_CONSTANTS.NO_COMPANY_ASSOCIATED);

	    if (!StringUtils.isEmpty(site.getCompanyName()))
		cell = ExcelUtils.createCell(row, cellCount,
			Constants.REPORT_EXPORT_CONSTANTS.COMPANY + Constants.REPORT_EXPORT_CONSTANTS.SPACE
				+ Constants.REPORT_EXPORT_CONSTANTS.COLON + Constants.REPORT_EXPORT_CONSTANTS.SPACE
				+ site.getCompanyName());
	    sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, firstColumn, lastColumn));
	    cell.setCellStyle(ExcelUtils.cellStyleForTopHeading(sheet));

	    rowIndex = rowCount;
	    row = sheet.createRow(rowCount++);
	    cell = ExcelUtils.createCell(row, cellCount,
		    Constants.REPORT_EXPORT_CONSTANTS.UNIT_NAME + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + Constants.REPORT_EXPORT_CONSTANTS.COLON + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + equipmentName);
	    sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, firstColumn, lastColumn));
	    cell.setCellStyle(ExcelUtils.cellStyleForTopHeading(sheet));

	    rowIndex = rowCount;
	    row = sheet.createRow(rowCount++);
	    cell = ExcelUtils.createCell(row, cellCount,
		    reportTag + Constants.REPORT_EXPORT_CONSTANTS.SPACE + minDate
			    + Constants.REPORT_EXPORT_CONSTANTS.SPACE + Constants.REPORT_EXPORT_CONSTANTS.TO
			    + Constants.REPORT_EXPORT_CONSTANTS.SPACE + maxDate);
	    sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, firstColumn, lastColumn));
	    cell.setCellStyle(ExcelUtils.cellStyleForTopHeading(sheet));
	}
	return sheet;
    }

    public static Double lbsKgConversion(String measurmentUnit, Long actualValue, String actualMeasurementUnit) {
	if (!measurmentUnit.equalsIgnoreCase(actualMeasurementUnit)) {
	    if (Constants.Units.LBS.equalsIgnoreCase(actualMeasurementUnit) && actualValue != null && actualValue != 0)
		return (actualValue / Constants.Units.lbsKgConversion);
	    if (Constants.Units.KG.equalsIgnoreCase(actualMeasurementUnit) && actualValue != null && actualValue != 0)
		return (actualValue * Constants.Units.lbsKgConversion);
	}
	return actualValue.doubleValue();
    }

    public static Double galKgConversion(String measurmentUnit, Double actualValue, String actualMeasurementUnit) {
	if (!measurmentUnit.equalsIgnoreCase(actualMeasurementUnit)) {
	    if (Constants.Units.KG.equalsIgnoreCase(actualMeasurementUnit) && actualValue != null)
		return (actualValue / Constants.Units.galToKgConversion);
	    if (Constants.Units.GAL.equalsIgnoreCase(actualMeasurementUnit) && actualValue != null)
		return (actualValue * Constants.Units.galToKgConversion);
	}
	return actualValue;
    }

    public static Double ozToMlConversion(String measurmentUnit, Double actualValue, String actualMeasurementUnit) {
	if (measurmentUnit == null || !measurmentUnit.equalsIgnoreCase(actualMeasurementUnit)) {
	    if (Constants.Units.OZ.equalsIgnoreCase(actualMeasurementUnit) && actualValue != null)
		return (actualValue * Constants.Units.ozToMlConversion);
	    if (Constants.Units.ML.equalsIgnoreCase(actualMeasurementUnit) && actualValue != null)
		return (actualValue / Constants.Units.ozToMlConversion);
	}
	return actualValue;
    }

    public static Double realCwtCalculation(Double realCost, Long washedWeight, String measurmentUnit,
	    String actualMeasurementUnit, Double realCw) {
	if (!measurmentUnit.equalsIgnoreCase(actualMeasurementUnit)) {
	    if (Constants.Units.LBS.equalsIgnoreCase(actualMeasurementUnit) && realCost != null && washedWeight != null
		    && realCost != 0 && washedWeight != 0)
		return (realCost / (washedWeight / Constants.Units.lbsKgConversion));
	    if (Constants.Units.KG.equalsIgnoreCase(actualMeasurementUnit) && realCost != null && washedWeight != null
		    && realCost != 0 && washedWeight != 0)
		return (realCost / (washedWeight * Constants.Units.lbsKgConversion)) * 100;
	}
	return realCw;
    }

    public static boolean sheetNameExist(XSSFWorkbook workBook, String sheetName) {
	int numberOfSheets = workBook.getNumberOfSheets();
	if (numberOfSheets != 0) {
	    for (int i = 0; i < numberOfSheets; i++) {
		if (workBook.getSheetName(i).equals(sheetName)) {
		    return true;
		}
	    }
	}
	return false;
    }

    public static void pushingMachineDataToExcel(XSSFSheet equipmentSheet, Row row, int equipmentRowCount,
	    Integer alarmId, WarningDTO warning, String measurmentUnit, String actualMeasurementUnit,
	    HashMap<String, Integer> machineHeader) {
	if (warning != null) {
	    row = equipmentSheet.createRow(equipmentRowCount++);
	    Cell cell;
	    cell = ExcelUtils.createCell(row,
		    machineHeader.get(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME)),
		    warning.getDateTime().get(Constants.VALUE));
	    equipmentSheet.setColumnWidth(cell.getColumnIndex(),
		    Constants.REPORT_EXPORT_CONSTANTS.ALARM_SUB_SCREEN_HEADING);
	    if (alarmId.equals(1) || alarmId.equals(2) || alarmId.equals(8) || alarmId.equals(9) || alarmId.equals(10) || alarmId.equals(11)) {
		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS)));
		String value = warning.getProcess().get(Constants.VALUE);
		if (value != null && !value.trim().isEmpty() && StringUtils.isNumeric(value)) {
		    cell.setCellValue(Integer.parseInt(value));
		}
		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA)));
		value = warning.getFormulaId().get(Constants.VALUE);
		if (value != null && !value.trim().isEmpty() && StringUtils.isNumeric(value)) {
		    cell.setCellValue(Integer.parseInt(value));
		}
		cell = ExcelUtils.createCell(row, machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME)),
			warning.getFormulaName().get(Constants.VALUE));
		equipmentSheet.setColumnWidth(cell.getColumnIndex(),
			Constants.REPORT_EXPORT_CONSTANTS.ALARM_SUB_SCREEN_HEADING);
	    }
	    if (alarmId.equals(10)) {
		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_ID_DISPLAY.get(Constants.REPORTS.PRODUCT_ID)));
		String value = warning.getProductId().get(Constants.VALUE);
		if (value != null && !value.trim().isEmpty() && StringUtils.isNumeric(value)) {
		    cell.setCellValue(Integer.parseInt(value));
		}
		cell = ExcelUtils.createCell(row,
			machineHeader.get(
				Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT)),
			warning.getProductName().get(Constants.VALUE));
		equipmentSheet.setColumnWidth(cell.getColumnIndex(),
			Constants.REPORT_EXPORT_CONSTANTS.ALARM_SUB_SCREEN_HEADING);

		cell = row.createCell(machineHeader.get(
			Constants.REPORTS.DISPLAY_FIELDS.ESTIMATED_USAGE_DISPLAY.get(Constants.REPORTS.ESTIMATED_ML)));
		cell.setCellValue((ExcelUtils.ozToMlConversion(measurmentUnit,
			Double.parseDouble(warning.getEstimatedChemical().get(Constants.VALUE)),
			actualMeasurementUnit)));

		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.ACTUAL_USAGE_DISPLAY.get(Constants.REPORTS.ACTUAL_ML)));
		cell.setCellValue((ExcelUtils.ozToMlConversion(measurmentUnit,
			Double.parseDouble(warning.getActualChemical().get(Constants.VALUE)), actualMeasurementUnit)));

	    }
	    if (alarmId.equals(2)) {
		cell = row.createCell(
			machineHeader.get(Constants.REPORTS.DISPLAY_FIELDS.PHASE_DISPLAY.get(Constants.REPORTS.PHASE)));
		String value = warning.getPhase().get(Constants.VALUE);
		if (value != null && !value.trim().isEmpty() && StringUtils.isNumeric(value)) {
		    cell.setCellValue(Integer.parseInt(value));
		}
	    }
	    if (alarmId.equals(16)) {
		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS)));
		String value = warning.getProcess().get(Constants.VALUE);
		if (value != null && !value.trim().isEmpty() && StringUtils.isNumeric(value)) {
		    cell.setCellValue(Integer.parseInt(value));
		}
		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_ID_DISPLAY.get(Constants.REPORTS.PRODUCT_ID)));
		value = warning.getProductId().get(Constants.VALUE);
		if (value != null && !value.trim().isEmpty() && StringUtils.isNumeric(value)) {
		    cell.setCellValue(Integer.parseInt(value));
		}
		cell = ExcelUtils.createCell(row,
			machineHeader.get(
				Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT)),
			warning.getProductName().get(Constants.VALUE));
		equipmentSheet.setColumnWidth(cell.getColumnIndex(),
			Constants.REPORT_EXPORT_CONSTANTS.ALARM_SUB_SCREEN_HEADING);
	    }
	}
    }

    public static HashMap<String, Integer> createMachineHeader(XSSFSheet equipmentSheet, int equipmentRowCount,
	    List<String> headerList) {
	Row row = equipmentSheet.createRow(equipmentRowCount);
	Cell cell;
	HashMap<String, Integer> machineHeaderMap = new LinkedHashMap<>();
	if (headerList != null) {
	    int columnCount = 0;
	    for (String header : headerList) {
		row = equipmentSheet.getRow(equipmentRowCount);
		machineHeaderMap.put(header, columnCount);
		cell = ExcelUtils.createCell(row, columnCount++, header);
		cell.setCellStyle(ExcelUtils.cellStyleFormulaHeading(equipmentSheet));
	    }
	}
	return machineHeaderMap;
    }

    public static LocalDate convertStringToLocalDate(String date) {
	DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT);
	LocalDate localDate = LocalDate.parse(date, dateformatter);
	return localDate;
    }

    public static String realCwtLabel(String measurmentUnit, String actualMeasurementUnit,
	    String cwtLabelForActualMetric) {
	if (!measurmentUnit.equalsIgnoreCase(actualMeasurementUnit)) {
	    if (Constants.Units.LBS.equalsIgnoreCase(actualMeasurementUnit))
		return Constants.Units.KILO;
	    if (Constants.Units.KG.equalsIgnoreCase(actualMeasurementUnit))
		return Constants.Units.CW_LABEL;
	}
	return cwtLabelForActualMetric;
    }

    public static Integer monthBetweenDate(String fromDate, String toDate) {
	long month = (ChronoUnit.MONTHS.between(LocalDate.parse(fromDate).withDayOfMonth(1),
		LocalDate.parse(toDate).withDayOfMonth(1)));
	return (int) month;
    }

    public static void setBordersToMergedCellsInRow(XSSFSheet sheet) {
	int numMerged = sheet.getNumMergedRegions();
	for (int i = 0; i < numMerged; i++) {
	    CellRangeAddress mergedRegions = sheet.getMergedRegion(i);
	    RegionUtil.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM, mergedRegions, sheet, sheet.getWorkbook());
	    RegionUtil.setBorderRight(XSSFCellStyle.BORDER_MEDIUM, mergedRegions, sheet, sheet.getWorkbook());
	    RegionUtil.setBorderTop(XSSFCellStyle.BORDER_MEDIUM, mergedRegions, sheet, sheet.getWorkbook());
	    RegionUtil.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM, mergedRegions, sheet, sheet.getWorkbook());

	}
    }

    public static void bordersAcrossCellRange(XSSFSheet sheet, int firstRow, int lastRow, int firstColumn,
	    int lastColumn) {
	CellRangeAddress region = new CellRangeAddress(firstRow, lastRow, firstColumn, lastColumn);
	RegionUtil.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM, region, sheet, sheet.getWorkbook());
	RegionUtil.setBorderRight(XSSFCellStyle.BORDER_MEDIUM, region, sheet, sheet.getWorkbook());
	RegionUtil.setBorderTop(XSSFCellStyle.BORDER_MEDIUM, region, sheet, sheet.getWorkbook());
	RegionUtil.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM, region, sheet, sheet.getWorkbook());

    }

    public static XSSFCellStyle setCellMediumBorder(XSSFWorkbook workbook) {
	XSSFCellStyle cellStyle = workbook.createCellStyle();
	cellStyle.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
	return cellStyle;
    }

    public static CellStyle cellStyleFormulaHeading(XSSFSheet sheet) {
	XSSFCellStyle cellStyle = sheet.getWorkbook().createCellStyle();
	XSSFFont font = sheet.getWorkbook().createFont();
	font.setBold(true);
	font.setFontHeightInPoints((short) 10);
	font.setFontName("Arial");
	cellStyle.setFont((Font) font);
	cellStyle.setWrapText(true);
	cellStyle.setAlignment(HorizontalAlignment.LEFT);
	cellStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	cellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
	cellStyle.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
	return cellStyle;
    }

    public static CellStyle cellStyleForCellValue(XSSFSheet sheet) {
	XSSFCellStyle cellStyle = sheet.getWorkbook().createCellStyle();
	XSSFFont font = sheet.getWorkbook().createFont();
	font.setFontHeightInPoints((short) 10);
	font.setFontName("Arial");
	cellStyle.setFont((Font) font);
	cellStyle.setWrapText(true);
	cellStyle.setAlignment(HorizontalAlignment.LEFT);
	cellStyle.setBorderBottom(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderTop(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderLeft(XSSFCellStyle.BORDER_MEDIUM);
	cellStyle.setBorderRight(XSSFCellStyle.BORDER_MEDIUM);
	return cellStyle;
    }

    public static XSSFCellStyle setCellThinBorder(XSSFWorkbook workbook) {
	XSSFCellStyle cellStyle = workbook.createCellStyle();
	cellStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
	cellStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
	cellStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);
	cellStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
	return cellStyle;
    }

    public static XSSFSheet createTopHeadingsForAlarmSubScreen(XSSFWorkbook workbook, XSSFSheet sheet, int rowCount,
	    int cellCount, SiteDTO site, String reportTag, String maxDate, String minDate, String alarmName,
	    ReportRequestDTO reportRequest) {
	String equipmentName = reportRequest.getEquipmentName().trim();
	int firstRow = rowCount;
	int rowIndex = rowCount;
	if (sheet != null && site != null) {
	    Row row = sheet.createRow(rowCount++);
	    int firstColumn = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;
	    int lastColumn = 6;
	    Cell cell = ExcelUtils.createCell(row, cellCount,
		    Constants.REPORT_EXPORT_CONSTANTS.SITE + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + Constants.REPORT_EXPORT_CONSTANTS.COLON + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + site.getSiteName());

	    sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, firstColumn, lastColumn));
	    cell.setCellStyle(ExcelUtils.cellStyleForTopHeading(sheet));

	    rowIndex = rowCount;
	    row = sheet.createRow(rowCount++);
	    cell = ExcelUtils.createCell(row, cellCount,
		    Constants.REPORT_EXPORT_CONSTANTS.COMPANY + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + Constants.REPORT_EXPORT_CONSTANTS.COLON + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + Constants.REPORT_EXPORT_CONSTANTS.NO_COMPANY_ASSOCIATED);

	    if (!StringUtils.isEmpty(site.getCompanyName()))
		cell = ExcelUtils.createCell(row, cellCount,
			Constants.REPORT_EXPORT_CONSTANTS.COMPANY + Constants.REPORT_EXPORT_CONSTANTS.SPACE
				+ Constants.REPORT_EXPORT_CONSTANTS.COLON + Constants.REPORT_EXPORT_CONSTANTS.SPACE
				+ site.getCompanyName());
	    sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, firstColumn, lastColumn));
	    cell.setCellStyle(ExcelUtils.cellStyleForTopHeading(sheet));

	    rowIndex = rowCount;
	    int lastRow = rowCount;
	    row = sheet.createRow(rowCount++);
	    cell = ExcelUtils.createCell(row, cellCount,
		    reportTag + Constants.REPORT_EXPORT_CONSTANTS.SPACE + minDate
			    + Constants.REPORT_EXPORT_CONSTANTS.SPACE + Constants.REPORT_EXPORT_CONSTANTS.TO
			    + Constants.REPORT_EXPORT_CONSTANTS.SPACE + maxDate);
	    sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, firstColumn, lastColumn));
	    cell.setCellStyle(ExcelUtils.cellStyleForTopHeading(sheet));

	    rowIndex = rowCount;
	    row = sheet.createRow(rowCount++);
	    cell = ExcelUtils.createCell(row, cellCount,
		    Constants.REPORT_EXPORT_CONSTANTS.UNIT_NAME + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + Constants.REPORT_EXPORT_CONSTANTS.COLON + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + equipmentName);
	    sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, firstColumn, lastColumn));
	    cell.setCellStyle(ExcelUtils.cellStyleForTopHeading(sheet));

	    rowIndex = rowCount;
	    lastRow = rowCount;
	    row = sheet.createRow(rowCount++);
	    cell = ExcelUtils.createCell(row, cellCount,
		    Constants.REPORT_EXPORT_CONSTANTS.ALARM_NAME_TAG + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + Constants.REPORT_EXPORT_CONSTANTS.COLON + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			    + alarmName);
	    sheet.addMergedRegion(new CellRangeAddress(rowIndex, rowIndex, firstColumn, lastColumn));
	    cell.setCellStyle(ExcelUtils.cellStyleForTopHeading(sheet));
	}
	return sheet;
    }

    public static void pushingMDBMachineDataToExcel(XSSFSheet equipmentSheet, Row row, int equipmentRowCount,
	    Integer alarmId, WarningDTO warning, String measurmentUnit, String actualMeasurementUnit,
	    HashMap<String, Integer> machineHeader) {
	if (warning != null) {
	    row = equipmentSheet.createRow(equipmentRowCount++);
	    Cell cell;
	    cell = ExcelUtils.createCell(row,
		    machineHeader.get(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME)),
		    warning.getDateTime().get(Constants.VALUE));
	    equipmentSheet.setColumnWidth(cell.getColumnIndex(),
		    Constants.REPORT_EXPORT_CONSTANTS.ALARM_SUB_SCREEN_HEADING);
	    
	    if (alarmId.equals(2) || alarmId.equals(3) || alarmId.equals(5) || alarmId.equals(4) || alarmId.equals(101)
		    || alarmId.equals(111)) {
		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS)));
		String value = warning.getProcess().get(Constants.VALUE);
		if (value != null && !value.trim().isEmpty() && StringUtils.isNumeric(value)) {
		    cell.setCellValue(Integer.parseInt(value));
		}
		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA)));
		value = warning.getFormulaId().get(Constants.VALUE);
		if (value != null && !value.trim().isEmpty() && StringUtils.isNumeric(value)) {
		    cell.setCellValue(Integer.parseInt(value));
		}
		cell = ExcelUtils.createCell(row, machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME)),
			warning.getFormulaName().get(Constants.VALUE));
		equipmentSheet.setColumnWidth(cell.getColumnIndex(),
			Constants.REPORT_EXPORT_CONSTANTS.ALARM_SUB_SCREEN_HEADING);
	    }
	    
	    if (alarmId.equals(2) || alarmId.equals(3) || alarmId.equals(5) || alarmId.equals(4) || alarmId.equals(900)) {
		cell = ExcelUtils.createCell(row,
			machineHeader.get(
				Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT)),
			warning.getProductName().get(Constants.VALUE));
		equipmentSheet.setColumnWidth(cell.getColumnIndex(),
			Constants.REPORT_EXPORT_CONSTANTS.ALARM_SUB_SCREEN_HEADING);
	    }
	    
	    if (alarmId.equals(4)) {
		cell = row.createCell(machineHeader.get(
			Constants.REPORTS.DISPLAY_FIELDS.ESTIMATED_USAGE_DISPLAY.get(Constants.REPORTS.ESTIMATED_ML)));
		cell.setCellValue((ExcelUtils.ozToMlConversion(measurmentUnit,
			Double.parseDouble(warning.getEstimatedChemical().get(Constants.VALUE)),
			actualMeasurementUnit)));

		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.ACTUAL_USAGE_DISPLAY.get(Constants.REPORTS.ACTUAL_ML)));
		cell.setCellValue((ExcelUtils.ozToMlConversion(measurmentUnit,
			Double.parseDouble(warning.getActualChemical().get(Constants.VALUE)), actualMeasurementUnit)));

		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.ESTIMATED_TIME_DISPLAY.get(Constants.REPORTS.ESTIMATED_TIME)));
		cell.setCellValue(warning.getEstimatedTime().get(Constants.VALUE));

		cell = row.createCell(machineHeader
			.get(Constants.REPORTS.DISPLAY_FIELDS.ACTUAL_TIME_DISPLAY.get(Constants.REPORTS.ACTUAL_TIME)));
		cell.setCellValue(warning.getActualTime().get(Constants.VALUE));
	    }
	    
	    if (alarmId.equals(111)) {
		cell = row.createCell(
			machineHeader.get(Constants.REPORTS.DISPLAY_FIELDS.PHASE_DISPLAY.get(Constants.REPORTS.PHASE)));
		String value = warning.getPhase().get(Constants.VALUE);
		if (value != null && !value.trim().isEmpty() && StringUtils.isNumeric(value)) {
		    cell.setCellValue(Integer.parseInt(value));
		}
	    }
	}
    }

}
