package com.hydro.api.site.business;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.joda.time.Interval;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.business.HydroBL;
import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.EquipmentListDTO;
import com.hydro.api.dto.FormulaMetaDataDTO;
import com.hydro.api.dto.ProductDTO;
import com.hydro.api.dto.ShiftDTO;
import com.hydro.api.dto.ShiftListResponseDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.SiteListResponseDTO;
import com.hydro.api.dto.TunnelDTO;
import com.hydro.api.dto.WasherMetaDataDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.site.dao.SiteDao;
import com.hydro.api.site.dao.concrete.CompanySiteDao;
import com.hydro.api.site.dao.concrete.HydroSiteDao;
import com.hydro.api.site.dao.concrete.PartialCompanySiteDao;
import com.hydro.api.site.dao.concrete.PartialHydroSiteDao;
import com.hydro.api.site.dao.concrete.SiteComapnySiteDao;

/**
 * Business layer for the Application.
 * 
 * @author Shreyas, Srishti
 *
 */
public class HydroSiteBL extends HydroBL {
    private static final Logger LOG = LoggerFactory.getLogger(HydroSiteBL.class);

    public HydroSiteBL(String userId, String timeZone) throws SystemException, Exception {
	super(userId, timeZone);

	LOG.debug("In Hydro Site B BL.");
	String orgType = user.getOrgType();
	switch (orgType) {
	case Constants.HYDRO:
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new HydroSiteDao()
		    : new PartialHydroSiteDao();
	    break;
	case Constants.COMPANY:
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new CompanySiteDao()
		    : new PartialCompanySiteDao();
	    break;
	case Constants.SITE:
	    hydroDao = (permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE)) ? new CompanySiteDao()
		    : new SiteComapnySiteDao();
	    break;
	default:
	    LOG.debug("Unknown org type");
	}

    }

    /**
     * Test Site DataBase Connection
     * 
     * @return
     */

    public boolean testSiteDbConnection() {
	return ((SiteDao) hydroDao).testSiteDbConnection();
    }

    public SiteListResponseDTO getSiteList(SiteDTO site) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.SITE_LIST);
	SiteListResponseDTO siteList = ((SiteDao) hydroDao).getSiteList(user, site);
	return siteList;
    }

    public SiteListResponseDTO getSiteListForCompany(SiteDTO site) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.SITE_LIST);
	if (!user.getOrgType().equals(Constants.HYDRO)) {
	    if (StringUtils.isEmpty(site.getCompanyId())) {
		throw new SystemException(ErrorCodes.INVALID_COMPANY_ID, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, user.getAssociationId());
	    }
	    if (!site.getCompanyId().equalsIgnoreCase(user.getAssociationId())) {
		throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FORBIDDEN, user.getAssociationId());
	    }
	}
	SiteListResponseDTO response = ((SiteDao) hydroDao).getSiteListForCompany(site, user);
	return response;
    }

    /**
     * Method for creating site.
     * 
     * @param siteDTO
     * @return
     * @throws Exception
     */
    public SiteDTO createSite(SiteDTO siteDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.SITE_CREATE);
	// Validation

	List<Object> params = getInsufficientParamsListCreate(siteDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	if (!CommonUtils.isValidMetric(siteDTO.getMetricUnit())) {
	    throw new SystemException(ErrorCodes.INVALID_METRIC_UNIT, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	if (!accountIdExists(siteDTO.getAccountId())) {
	    throw new SystemException(ErrorCodes.INVALID_ACCOUNT_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, siteDTO.getAccountId());
	}
	if (StringUtils.isEmpty(siteDTO.getCompanyId())) {
	    siteDTO.setCompanyId(null);
	} else if (!companyExists(siteDTO.getCompanyId())) {
	    throw new SystemException(ErrorCodes.INVALID_COMPANY_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, siteDTO.getCompanyId());
	}
	if (siteDTO.getShiftList() != null && !checkValidShift(siteDTO)) {
	    throw new SystemException(ErrorCodes.INVALID_SHIFT, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	if (!siteNameExists(siteDTO)) {
	    return ((SiteDao) hydroDao).createSite(user, siteDTO);
	} else {
	    throw new SystemException(ErrorCodes.DUPLICATE_SITE_NAME, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
    }

    protected boolean checkValidShift(SiteDTO siteDTO) throws Exception {
	Interval interval = null;
	List<ShiftDTO> shift = siteDTO.getShiftList();
	HashSet<Interval> intervalSet = new HashSet<>();
	for (ShiftDTO shiftDTO : shift) {
	    String startTime = shiftDTO.getStartTime();
	    String endTime = shiftDTO.getEndTime();
	    if (!CommonUtils.validateTimeStamp(startTime) || !CommonUtils.validateTimeStamp(endTime))
		throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    Long startTimeLong = CommonUtils.convertStringToLongTime(startTime);
	    Long endTimeLong = CommonUtils.convertStringToLongTime(endTime);
	    if (startTimeLong == null || endTimeLong == null)
		throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    interval = CommonUtils.createInterval(startTimeLong, endTimeLong);
	    if (interval == null)
		return false;
	    if (!intervalSet.isEmpty()) {
		if (intervalSet.contains(interval)) {
		    return false;
		}
		Iterator<Interval> itr = intervalSet.iterator();
		while (itr.hasNext()) {
		    Interval key = itr.next();
		    if (key.overlaps(interval))
			return false;
		}
	    }
	    intervalSet.add(interval);
	}
	return true;
    }

    /**
     * Method to check if mandatory fields are present,specified accountID exist and
     * then update site details.
     * 
     * @param siteDTO
     * @return
     * @throws Exception
     */
    public boolean updateSite(SiteDTO siteDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.SITE_UPDATE);
	boolean siteFullEdit = hasPermission(Constants.PRIVILEGE_NAMES.SITE_FULL_EDIT);
	List<Object> params = getInsufficientParamsListUpdate(siteDTO, siteFullEdit);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	if (!CommonUtils.isValidMetric(siteDTO.getMetricUnit())) {
	    throw new SystemException(ErrorCodes.INVALID_METRIC_UNIT, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	if (siteFullEdit) {
	    if (StringUtils.isEmpty(siteDTO.getCompanyId())) {
		siteDTO.setCompanyId(null);
	    } else if (!companyExists(siteDTO.getCompanyId())) {
		throw new SystemException(ErrorCodes.INVALID_COMPANY_ID, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, siteDTO.getCompanyId());
	    }
	    if (!accountIdExists(siteDTO.getAccountId())) {
		throw new SystemException(ErrorCodes.INVALID_ACCOUNT_ID, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }
	}

	if (siteDTO.getShiftList() != null && !checkValidShift(siteDTO)) {
	    throw new SystemException(ErrorCodes.INVALID_SHIFT, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}

	String siteExistingId = getSiteExistingName(siteDTO);
	if (StringUtils.isEmpty(siteExistingId) || siteDTO.getSiteId().equals(siteExistingId)) {
	    return ((SiteDao) hydroDao).updateSite(user, siteDTO, siteFullEdit);
	} else {
	    throw new SystemException(ErrorCodes.DUPLICATE_SITE_NAME, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}

    }

    /**
     * Method to check if the given account ID exist.
     * 
     * @param accountId
     * @return
     * @throws Exception
     */
    public boolean accountIdExists(String accountId) throws Exception {
	if (StringUtils.isEmpty(accountId)) {
	    List<Object> paramsList = new LinkedList<>();
	    paramsList.add(ErrorCodes.InsufficientParams.ACCOUNT_ID);
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, paramsList);
	}
	if (StringUtils.isEmpty(((SiteDao) hydroDao).accountIdExists(accountId))) {
	    return false;
	}
	return true;
    }

    public String getSiteExistingName(SiteDTO site) throws Exception {
	List<Object> params = getInsufficientParamsSiteExist(site);
	if (StringUtils.isEmpty(site.getSiteName())) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	return ((SiteDao) hydroDao).siteNameExists(site);

    }

    public boolean siteNameExists(SiteDTO site) throws Exception {
	if (StringUtils.isEmpty(getSiteExistingName(site))) {
	    return false;
	}
	return true;
    }

    public SiteDTO getSiteDetails(SiteDTO siteDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.SITE_VIEW);

	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	SiteDTO site = ((SiteDao) hydroDao).getSiteDetails(siteDTO);
	if (site == null) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	site.setContactList(((SiteDao) hydroDao).getContactListForSite(user, siteDTO));
	ShiftListResponseDTO shift = getShiftDetailsForSite(siteDTO);
	site.setShiftList(shift.getShiftList());
	return site;
    }

    public EquipmentListDTO getEquipmentList(SiteDTO siteDTO) throws Exception {
	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	EquipmentListDTO equipmentList = new EquipmentListDTO();
	equipmentList.setEquipmentList(((SiteDao) hydroDao).getEquipmentList(siteDTO));
	return equipmentList;
    }

    public EquipmentListDTO getEquipmentSpecification(SiteDTO siteDTO) throws Exception {
	EquipmentListDTO response = new EquipmentListDTO();
	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	List<EquipmentDTO> equipmentList = ((SiteDao) hydroDao).getEquipmentList(siteDTO);
	if (equipmentList == null || equipmentList.size() <= 0) {
	    throw new SystemException(ErrorCodes.INVALID_SITE_META_DATA, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	for (EquipmentDTO equipment : equipmentList) {
	    if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.TUNNEL)) {
		List<TunnelDTO> tunnelList = ((SiteDao) hydroDao).getTunnelList(equipment);
		equipment.setTunnelList(tunnelList);
	    } else {
		List<WasherMetaDataDTO> washerList = ((SiteDao) hydroDao).getWasherList(equipment);
		equipment.setWasherList(washerList);
	    }
	    List<FormulaMetaDataDTO> formulaList = ((SiteDao) hydroDao).getFormulaList(equipment);
	    equipment.setFormulaList(formulaList);
	    List<ProductDTO> productList = ((SiteDao) hydroDao).getProductList(equipment);
	    Map<String, String> productMap = new HashMap<>();
	    for (ProductDTO productDTO : productList) {
		if (!StringUtils.isEmpty(productDTO.getLm2Seq())) {
		    productMap.put(productDTO.getLm2Seq(), productDTO.getName());
		}
	    }
	    equipment.setProductMap(productMap);
	    equipment.setProductList(productList);

	}
	response.setEquipmentList(equipmentList);
	return response;
    }

    public ShiftListResponseDTO getShiftDetailsForSite(SiteDTO siteDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.SITE_VIEW);
	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	List<ShiftDTO> shiftList = ((SiteDao) hydroDao).getShiftDetailsForSite(siteDTO);
	ShiftListResponseDTO response = new ShiftListResponseDTO();
	response.setShiftList(shiftList);
	return response;
    }

    protected List<Object> getInsufficientParamsListCreate(SiteDTO site) {
	List<Object> params = new LinkedList<>();
	if (site == null) {
	    params.add(ErrorCodes.InsufficientParams.SITE_OBJECT);
	}
	if (StringUtils.isEmpty(site.getSiteName())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_NAME);
	}
	if (StringUtils.isEmpty(site.getAccountId())) {
	    params.add(ErrorCodes.InsufficientParams.ACCOUNT_ID);
	}
	if (StringUtils.isEmpty(site.getAddress1())) {
	    params.add(ErrorCodes.InsufficientParams.ADDRESS1);
	}
	if (StringUtils.isEmpty(site.getState())) {
	    params.add(ErrorCodes.InsufficientParams.STATE);
	}
	if (StringUtils.isEmpty(site.getCountry())) {
	    params.add(ErrorCodes.InsufficientParams.COUNTRY);
	}
	if (StringUtils.isEmpty(site.getCity())) {
	    params.add(ErrorCodes.InsufficientParams.CITY);
	}
	if (StringUtils.isEmpty(site.getZipCode())) {
	    params.add(ErrorCodes.InsufficientParams.ZIPCODE);
	}
	if (StringUtils.isEmpty(site.getMetricUnit())) {
	    params.add(ErrorCodes.InsufficientParams.METRIC_UNIT);
	}
	if (StringUtils.isEmpty(site.getTimeZone())) {
	    params.add(ErrorCodes.InsufficientParams.TIME_ZONE);
	}
	if (StringUtils.isEmpty(site.getCompanyId())) {
	    params.add(ErrorCodes.InsufficientParams.COMPANY_ID);
	}
	return params;
    }

    protected List<Object> getInsufficientParamsListUpdate(SiteDTO site, boolean siteFullEdit) {
	List<Object> params = new LinkedList<>();
	if (site == null) {
	    params.add(ErrorCodes.InsufficientParams.SITE_OBJECT);
	}
	if (StringUtils.isEmpty(site.getSiteId())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_ID);
	}
	if (StringUtils.isEmpty(site.getSiteName())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_NAME);
	}
	if (siteFullEdit && StringUtils.isEmpty(site.getAccountId())) {
	    params.add(ErrorCodes.InsufficientParams.ACCOUNT_ID);
	}
	if (StringUtils.isEmpty(site.getAddress1())) {
	    params.add(ErrorCodes.InsufficientParams.ADDRESS1);
	}
	if (StringUtils.isEmpty(site.getState())) {
	    params.add(ErrorCodes.InsufficientParams.STATE);
	}
	if (StringUtils.isEmpty(site.getCountry())) {
	    params.add(ErrorCodes.InsufficientParams.COUNTRY);
	}
	if (StringUtils.isEmpty(site.getCity())) {
	    params.add(ErrorCodes.InsufficientParams.CITY);
	}
	if (StringUtils.isEmpty(site.getZipCode())) {
	    params.add(ErrorCodes.InsufficientParams.ZIPCODE);
	}
	if (StringUtils.isEmpty(site.getMetricUnit())) {
	    params.add(ErrorCodes.InsufficientParams.METRIC_UNIT);
	}
	if (StringUtils.isEmpty(site.getTimeZone())) {
	    params.add(ErrorCodes.InsufficientParams.TIME_ZONE);
	}
	if (siteFullEdit && StringUtils.isEmpty(site.getCompanyId())) {
	    params.add(ErrorCodes.InsufficientParams.COMPANY_ID);
	}
	return params;
    }

    protected List<Object> getInsufficientParamsSiteExist(SiteDTO site) {
	List<Object> params = new LinkedList<>();
	if (StringUtils.isEmpty(site.getSiteName())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_NAME);
	}
	return params;
    }

    public EquipmentDTO getEquipmentDatail(String equipmentId, SiteDTO siteDTO) throws SystemException, Exception {
	EquipmentDTO equipment = null;

	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}

	equipment = ((SiteDao) hydroDao).getEequipment(equipmentId, siteDTO.getSiteId());

	if (equipment == null) {
	    throw new SystemException(ErrorCodes.INVALID_EQUIPMENT_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	} else {

	    if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.TUNNEL)) {
		List<TunnelDTO> tunnelList = ((SiteDao) hydroDao).getTunnelList(equipment);
		equipment.setTunnelList(tunnelList);
	    } else {
		List<WasherMetaDataDTO> washerList = ((SiteDao) hydroDao).getWasherList(equipment);
		equipment.setWasherList(washerList);
	    }
	    List<FormulaMetaDataDTO> formulaList = ((SiteDao) hydroDao).getFormulaList(equipment);
	    equipment.setFormulaList(formulaList);
	    List<ProductDTO> productList = ((SiteDao) hydroDao).getProductList(equipment);
	    Map<String, String> productMap = new HashMap<>();
	    for (ProductDTO productDTO : productList) {
		if (!StringUtils.isEmpty(productDTO.getLm2Seq())) {
		    productMap.put(productDTO.getLm2Seq(), productDTO.getName());
		}
	    }
	    equipment.setProductMap(productMap);
	    equipment.setProductList(productList);
	}
	return equipment;
    }

}