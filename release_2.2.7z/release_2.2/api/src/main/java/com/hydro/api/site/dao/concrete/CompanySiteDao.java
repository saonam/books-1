/**
 * 
 */
package com.hydro.api.site.dao.concrete;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.ContactDTO;
import com.hydro.api.dto.FileHistoryListResponseDTO;
import com.hydro.api.dto.ObservationDTO;
import com.hydro.api.dto.ObservationListResponseDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.SiteListResponseDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.site.dao.SiteDao;

/**
 * @author Shreyas
 *
 */
public class CompanySiteDao extends SiteDao {

    private static final Logger LOG = LoggerFactory.getLogger(CompanySiteDao.class);

    @Override
    public SiteListResponseDTO getSiteList(UserDTO user, SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.full.GET_SITE_LIST;
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(user.getAssociationId());
	    if (site.getCreatedDateStart() != null && site.getCreatedDateEnd() != null) {
		query = SQLConstants.Company.full.GET_SITE_LIST_CREATED_DATE_FILTER;
		LOG.debug("query>>>>" + query);
		params.addAll(getSiteListOnStartEndDate(site));
	    } else if (site.isSortByName()) {
		query = SQLConstants.Company.full.GET_SITE_LIST_SORTED_ON_NAME;
	    }
	    SiteListResponseDTO response = new SiteListResponseDTO();
	    List<SiteDTO> siteList = getSiteListData(database.executeQuery(query, params), user.getTimeZone());
	    response.setSiteList(siteList);
	    return response;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public SiteDTO createSite(UserDTO usser, SiteDTO siteDTO) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    @Override
    public boolean hasVisibility(UserDTO user, SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.full.GET_SITE_ASSOCIATED_TO_COMPANY;
	    // SELECT site_id from SITE_MASTER where site_id in (select site_id
	    // from SITE_BUSINESS_ASSOCIATION where business_id =? and site_id
	    // =?)
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(user.getAssociationId());
	    params.add(site.getSiteId());
	    ResultSet rSet = database.executeQuery(query, params);
	    if (rSet.next()) {
		return true;
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public List<ContactDTO> getContactListForSite(UserDTO userDTO, SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.GET_CONTACT_LIST_FOR_SITE;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(site.getSiteId());
	    params.add(userDTO.getAssociationId());
	    database = new Database();
	    return getSiteContactData(database.executeQuery(query, params));
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public FileHistoryListResponseDTO getFileHistoryList(UserDTO user) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.full.GET_FILE_HISTORY;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(user.getAssociationId());
	    return getFileListData(database.executeQuery(query, params), user.getTimeZone());
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean updateObservation(UserDTO user, ObservationDTO observationDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.full.UPDATE_OBSERVATION;
	    LOG.debug("query>>>>" + query);
	    // "update OBSERVATION_MASTER set observation=?,
	    // recommendation=?,modified_by=?, modified_date = utc_timestamp
	    // where observation_id=? and equipment_id in(select equipment_id
	    // from EQUIPMENT_MASTER where site_id in(select site_id from
	    // SITE_BUSINESS_ASSOCIATION where business_id = ?))"
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(observationDTO.getObservation());
	    params.add(observationDTO.getRecommendation());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(observationDTO.getObservationId());
	    params.add(user.getAssociationId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    return true;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean deleteObservation(UserDTO user, ObservationDTO observationDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.full.DELETE_OBSERVATION;
	    LOG.debug("query>>>>" + query);
	    // "delete from OBSERVATION_MASTER where observation_id =? and
	    // equipment_id in(select equipment_id from EQUIPMENT_MASTER where
	    // site_id in(select site_id from SITE_BUSINESS_ASSOCIATION where
	    // business_id = ?))"
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(observationDTO.getObservationId());
	    params.add(user.getAssociationId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    return true;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public ObservationListResponseDTO getObservationList(UserDTO userDTO, ObservationDTO observationDTO)
	    throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.full.GET_OBSERVATION_LIST;
	    // select observation_id, observation, recommendation, created_by,
	    // created_date,modified_by, modified_date from OBSERVATION_MASTER
	    // where equipment_id = (select
	    // equipment_id from EQUIPMENT_MASTER where equipment_id=? and
	    // site_id =(select site_id from SITE_BUSINESS_ASSOCIATION where
	    // business_id =? and site_id =?))and month=? and year=?
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(observationDTO.getEquipmentId());
	    params.add(userDTO.getAssociationId());
	    params.add(observationDTO.getSiteId());
	    params.add(observationDTO.getMonth());
	    params.add(observationDTO.getYear());
	    params.add(observationDTO.getSiteId());
	    database = new Database();
	    return getObservationListData(database.executeQuery(query, params), userDTO.getTimeZone());
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public SiteListResponseDTO getSiteListForCompany(SiteDTO site, UserDTO user) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_SITE_LIST;
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(site.getCompanyId());
	    if (site.isSortByName()) {
		query = SQLConstants.GET_SITE_LIST_SORTED_BY_NAME;
	    }
	    LOG.debug("query>>>>" + query);
	    SiteListResponseDTO response = new SiteListResponseDTO();
	    response.setSiteList(getSiteListData(database.executeQuery(query, params), user.getTimeZone()));
	    return response;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public String siteNameExists(SiteDTO siteDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.SITE_NAME_EXIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(siteDTO.getSiteName().toLowerCase());
	    params.add(siteDTO.getSiteId());
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.SITE_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }
}
