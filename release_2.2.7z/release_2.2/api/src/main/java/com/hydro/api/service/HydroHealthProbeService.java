package com.hydro.api.service;

import java.util.HashMap;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.dao.Database;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.ResponseDTO;
import com.hydro.api.exception.ExceptionHandler;
import com.hydro.api.exception.SystemException;
import com.hydro.api.service.helper.ServiceHelper;

@Produces({ MediaType.APPLICATION_JSON })
@Path("/healthProbe")
public class HydroHealthProbeService {

    private static final Logger LOG = LoggerFactory.getLogger(HydroBaseService.class);
    protected String resStr = null;
    protected HashMap<String, String> errorMessages;

    @GET
    @Path("/checkStatus")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String healthProbe() throws Exception {
	try {
	    LOG.info("Inside health probe service.");
	    ResponseDTO response = new ResponseDTO();
	    Database db = new Database();
	    if (db.getConnection()) {
		response.setResponseObject("Connected to DB successfully!!");
		response.setResponseStatus(true);
	    } else {
		response.setResponseObject(false);
		response.setResponseStatus(false);
	    }
	    resStr = ServiceHelper.buildJsonString(response);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    e.printStackTrace();
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	return resStr;
    }

}
