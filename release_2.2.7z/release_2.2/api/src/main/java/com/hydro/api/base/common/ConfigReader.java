package com.hydro.api.base.common;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.Set;

import javax.net.ssl.SSLContext;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.BasicHttpClientConnectionManager;
import org.apache.http.ssl.SSLContexts;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hydro.api.base.dao.HydroDao;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.device.AdvanceSearchDeviceRequest;
import com.hydro.api.device.Association;
import com.hydro.api.device.DeviceProperties;
import com.hydro.api.device.SearchProperties;
import com.hydro.api.dto.DeviceDTO;
import com.hydro.api.dto.RoleDTO;
import com.hydro.api.dto.UserCreationRolesDTO;
import com.hydro.api.exception.SystemException;

/**
 * Class to load the properties from the database during the first call.
 * 
 * @author Shreyas
 *
 */
public class ConfigReader {
    private static Logger LOG = LoggerFactory.getLogger(ConfigReader.class);

    private static boolean hasObject = false;

    private static ConfigReader configReaderObject = null;
    private static HashMap<String, String> errorConfig = null;
    private static HashMap<String, String> appConfig = null;
    private static ESConfig esConfig = null;
    private static HashMap<String, List<RoleDTO>> roleConfig = null;
    private static Set<String> deviceConfig = null;
    private static TokenCache tokenCache = null;

    private ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Singleton class that instantiates once during the server starts.
     * 
     * @return The config object created once and stored in the server cache.
     * @throws FileParsingException
     * @throws DALException
     * @throws SQLException
     * @throws SystemException
     * @throws IOException
     * @throws NumberFormatException
     */
    public synchronized static ConfigReader getObject() throws Exception {
	if (hasObject) {
	    return configReaderObject;
	} else {
	    configReaderObject = new ConfigReader();

	    configReaderObject.objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
	    configReaderObject.objectMapper.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

	    errorConfig = configReaderObject.getErrorMessages();
	    appConfig = new HashMap<>();
	    Properties props = new Properties();
	    InputStream is = (ConfigReader.class.getClassLoader().getResourceAsStream("application.properties"));
	    try {
		props.load(is);
		String jwt = props.getProperty(Constants.JWT_TOKEN);
		appConfig.put(Constants.JWT_TOKEN, jwt);
		String azureUrl = props.getProperty(Constants.AZURE_TOKEN_URL);
		appConfig.put(Constants.AZURE_TOKEN_URL, azureUrl);

		String azureCertificateUrl = props.getProperty(Constants.AZURE_AD_CERTIFICATE_URL);
		appConfig.put(Constants.AZURE_AD_CERTIFICATE_URL, azureCertificateUrl);
		String azureTokenUrl = props.getProperty(Constants.AZURE_AD_TOKEN_URL);
		appConfig.put(Constants.AZURE_AD_TOKEN_URL, azureTokenUrl);
		String azureHeadlessCertificateUrl = props.getProperty(Constants.AZURE_AD_HEADLESS_CERTIFICATE_URL);
		appConfig.put(Constants.AZURE_AD_HEADLESS_CERTIFICATE_URL, azureHeadlessCertificateUrl);
		String azureHeadlessTokenUrl = props.getProperty(Constants.AZURE_AD_HEADLESS_TOKEN_URL);
		appConfig.put(Constants.AZURE_AD_HEADLESS_TOKEN_URL, azureHeadlessTokenUrl);
		String azureAudience = props.getProperty(Constants.AZURE_AD_AUDIENCE);
		appConfig.put(Constants.AZURE_AD_AUDIENCE, azureAudience);
		String createUserUrl = props.getProperty(Constants.AZURE_AD_CREATE_USER_URL);
		appConfig.put(Constants.AZURE_AD_CREATE_USER_URL, createUserUrl);
		String authorityUrl = props.getProperty(Constants.AZURE_AD_AUTHORITY_URL);
		appConfig.put(Constants.AZURE_AD_AUTHORITY_URL, authorityUrl);
		String clientId = props.getProperty(Constants.AZURE_AD_CLIENT_ID);
		appConfig.put(Constants.AZURE_AD_CLIENT_ID, clientId);
		String clientSecret = props.getProperty(Constants.AZURE_AD_CLIENT_SECRET);
		appConfig.put(Constants.AZURE_AD_CLIENT_SECRET, clientSecret);
		String graphResource = props.getProperty(Constants.AZURE_AD_GRAPH_RESOURCE);
		appConfig.put(Constants.AZURE_AD_GRAPH_RESOURCE, graphResource);
		String defaultPassword = props.getProperty(Constants.AZURE_AD_DEFAULT_PASSWORD);
		appConfig.put(Constants.AZURE_AD_DEFAULT_PASSWORD, defaultPassword);
		String prop = props.getProperty(Constants.AZURE_AD_COMPANY_NAME);
		appConfig.put(Constants.AZURE_AD_COMPANY_NAME, prop);
		prop = props.getProperty(Constants.MAIL_SMTP);
		appConfig.put(Constants.MAIL_SMTP, prop);
		prop = props.getProperty(Constants.MAIL_HEADER);
		appConfig.put(Constants.MAIL_HEADER, prop);
		prop = props.getProperty(Constants.MAIL_ADDRESS);
		appConfig.put(Constants.MAIL_ADDRESS, prop);
		prop = props.getProperty(Constants.APP_URL);
		appConfig.put(Constants.APP_URL, prop);
		prop = props.getProperty(Constants.MAIL_PORT);
		appConfig.put(Constants.MAIL_PORT, prop);
		prop = props.getProperty(Constants.MAIL_USER);
		appConfig.put(Constants.MAIL_USER, prop);
		prop = props.getProperty(Constants.MAIL_PASSWORD);
		appConfig.put(Constants.MAIL_PASSWORD, prop);
		prop = props.getProperty(Constants.ES_TYPE);
		appConfig.put(Constants.ES_TYPE, prop);
		prop = props.getProperty(Constants.ES_INDEX);
		appConfig.put(Constants.ES_INDEX, prop);
		prop = props.getProperty(Constants.ES_DAILY_INDEX_THRESHOLD);
		appConfig.put(Constants.ES_DAILY_INDEX_THRESHOLD, prop);
		prop = props.getProperty(Constants.FILE_UPLOAD_PATH);
		appConfig.put(Constants.FILE_UPLOAD_PATH, prop);
		prop = props.getProperty(Constants.CANAL_FOR_TUNNEL_REPORT);
		appConfig.put(Constants.CANAL_FOR_TUNNEL_REPORT, prop);
		prop = props.getProperty(Constants.ES_BATCH_SIZE);
		appConfig.put(Constants.ES_BATCH_SIZE, prop);
		prop = props.getProperty(Constants.ES_USERNAME);
		appConfig.put(Constants.ES_USERNAME, prop);
		prop = props.getProperty(Constants.ES_PASSWORD);
		appConfig.put(Constants.ES_PASSWORD, prop);
		prop = props.getProperty(Constants.TOKEN_CACHE_BUFFER_TIME);
		appConfig.put(Constants.TOKEN_CACHE_BUFFER_TIME, prop);
		prop = props.getProperty(Constants.SOLID_PRODUCT_FORMAT);
		appConfig.put(Constants.SOLID_PRODUCT_FORMAT, prop);
		prop = props.getProperty(Constants.WELCOME_SUBJECT);
		appConfig.put(Constants.WELCOME_SUBJECT, prop);
		prop = props.getProperty(Constants.DEFAULT_SHIFT_START_TIME);
		appConfig.put(Constants.DEFAULT_SHIFT_START_TIME, prop);
		prop = props.getProperty(Constants.DEFAULT_SHIFT_END_TIME);
		appConfig.put(Constants.DEFAULT_SHIFT_END_TIME, prop);
		prop = props.getProperty(Constants.DEFAULT_SHIFT);
		appConfig.put(Constants.DEFAULT_SHIFT, prop);
		prop = props.getProperty(Constants.ES_DAILY_INDEX);
		appConfig.put(Constants.ES_DAILY_INDEX, prop);
		prop = props.getProperty(Constants.REPORTS.EVENT_TYPE_START_OF_CYCLE);
		appConfig.put(Constants.REPORTS.EVENT_TYPE_START_OF_CYCLE, prop);
		prop = props.getProperty(Constants.REPORTS.EVENT_TYPE_END_OF_CYCLE);
		appConfig.put(Constants.REPORTS.EVENT_TYPE_END_OF_CYCLE, prop);
		prop = props.getProperty(Constants.REPORTS.ZERO_PHASE);
		appConfig.put(Constants.REPORTS.ZERO_PHASE, prop);
		prop = props.getProperty(Constants.REPORTS.MISSED_PHASE);
		appConfig.put(Constants.REPORTS.MISSED_PHASE, prop);
		prop = props.getProperty(Constants.REPORTS.DEFAULT_INDEX);
		appConfig.put(Constants.REPORTS.DEFAULT_INDEX, prop);
		prop = props.getProperty(Constants.REPORTS.PHASE_CONSTANT);
		appConfig.put(Constants.REPORTS.PHASE_CONSTANT, prop);
		prop = props.getProperty(Constants.REPORTS.OFF_SHIFT);
		appConfig.put(Constants.REPORTS.OFF_SHIFT, prop);
		prop = props.getProperty(Constants.MACHINE_IDLE_QUERY_TIME_RANGE_IN_HRS);
		appConfig.put(Constants.MACHINE_IDLE_QUERY_TIME_RANGE_IN_HRS, prop);
		prop = props.getProperty(Constants.ES_HOST_NAMES);
		if (StringUtils.isEmpty(prop)) {
		    LOG.error("********ES_HOST_NAMES property is not set.");
		    throw new IllegalArgumentException("ES_HOST_NAMES property is not set");
		}
		appConfig.put(Constants.ES_HOST_NAMES, prop);
		prop = props.getProperty(Constants.ES_PORTS);
		if (StringUtils.isEmpty(prop)) {
		    LOG.error("********ES_PORTS property is not set.");
		    throw new IllegalArgumentException("ES_HOSTS property is not set");
		}
		appConfig.put(Constants.ES_PORTS, prop);
		prop = props.getProperty(Constants.ES_SCHEME);
		if (StringUtils.isEmpty(prop)) {
		    LOG.error("********ES_SCHEME property is not set.");
		    throw new IllegalArgumentException("ES_SCHEME property is not set");
		}
		appConfig.put(Constants.ES_SCHEME, prop);
		String esHosts = props.getProperty(Constants.ES_HOST_NAMES);
		String esPort = props.getProperty(Constants.ES_PORTS);
		String esProtocol = props.getProperty(Constants.ES_SCHEME);
		int maxEsConnTimeout;
		int maxEsReadTimeout;
		int maxEsConnections;
		if (StringUtils.isEmpty(esHosts)) {
		    LOG.error("********ES_HOSTS property is not set, cannot instantiate ESConfig");
		    throw new IllegalArgumentException("ES_HOSTS property is not set");
		}

		try {
		    maxEsConnTimeout = Integer.parseInt((props.getProperty(Constants.MAX_ES_CONN_TIMEOUT)));

		} catch (NumberFormatException e) {
		    LOG.info("********MAX_ES_CONN_TIMEOUT property is not set. Setting to Default 10000");
		    maxEsConnTimeout = 10000;
		}

		try {
		    maxEsReadTimeout = Integer.parseInt((props.getProperty(Constants.MAX_ES_READ_TIMEOUT)));

		} catch (NumberFormatException e) {
		    LOG.info("********MAX_ES_READ_TIMEOUT property is not  set. Setting to Default 20000");
		    maxEsReadTimeout = 20000;
		}

		try {
		    maxEsConnections = Integer.parseInt((props.getProperty(Constants.MAX_ES_CONNECTIONS)));

		} catch (NumberFormatException e) {
		    LOG.info("********MAX_ES_READ_TIMEOUT property is not  set. Setting to Default 100");
		    maxEsConnections = 100;
		}

		// Twilio
		prop = props.getProperty(Constants.SMS_ACCOUNT_SID);
		appConfig.put(Constants.SMS_ACCOUNT_SID, prop);
		prop = props.getProperty(Constants.SMS_AUTH_TOKEN);
		appConfig.put(Constants.SMS_AUTH_TOKEN, prop);
		prop = props.getProperty(Constants.SMS_HYDRO_PHONE_NUMBER);
		appConfig.put(Constants.SMS_HYDRO_PHONE_NUMBER, prop);

		prop = props.getProperty(Constants.ADVANCE_SEARCH_DEVICE);
		appConfig.put(Constants.ADVANCE_SEARCH_DEVICE, prop);
		prop = props.getProperty(Constants.SEARCH_SERVICE_URL);
		appConfig.put(Constants.SEARCH_SERVICE_URL, prop);
		appConfig.put(Constants.SEARCH_DEVICE_ID_PROP_NAME, Constants.SEARCH_DEVICE_ID);
		appConfig.put(Constants.SEARCH_DEVICE_ALL_PROP_NAME, Constants.SEARCH_DEVICE_ALL);
		prop = props.getProperty(Constants.PG_MAX_DAYS_THRESHOLD);
		appConfig.put(Constants.PG_MAX_DAYS_THRESHOLD, prop);

		esConfig = new ESConfig(esHosts, esPort, maxEsConnTimeout, maxEsReadTimeout, maxEsConnections,
			esProtocol);
		tokenCache = new TokenCache();
		HydroDao dao = new HydroDao();
		roleConfig = dao.getRoles();

		dao.updateFileStatus();
		initRoutine();
		hasObject = true;
		return configReaderObject;
	    } finally {
		is.close();
	    }
	}

    }

    // methods handling device cache
    public static void loadDeviceConfig() {
	// format for device config siteId-deviceId-Ip_address-serial#
	deviceConfig = new HashSet<>();
	deviceConfig.add("891e13e9b6644873adc7a0dbf5edc4f1550_device1_192.168.1.91_serial1");
	deviceConfig.add("891e13e9b6644873adc7a0dbf5edc4f1550_device2_192.168.1.92_serial2");
	deviceConfig.add("f2ecd9ea23e742b894d0cf3b73ef372b-ba1bec706ea6471585d7c782743fc9b4-192.168.1.89-serial1");

    }

    /**
     * @param deviceId
     */
    public void updateDeviceCache(String deviceId, boolean isUpdate) {

	StringBuilder serviceUrl = new StringBuilder();
	HttpComponentsClientHttpRequestFactory requestFactory = getRequestFactory();
	RestTemplate restTemplate = new RestTemplate(requestFactory);
	boolean isCleanUpdate = false;
	try {
	    ConfigReader configReader = ConfigReader.getObject();
	    if (deviceId != null) {
		// prepare the query for search api for a specific device
		serviceUrl.append(configReader.getAppConfig(Constants.SEARCH_SERVICE_URL))
			.append(configReader.getAppConfig(Constants.SEARCH_DEVICE_ID_PROP_NAME)).append("/")
			.append(deviceId);
	    } else {
		// prepare the query for search api to fetch all the devices
		serviceUrl.append(configReader.getAppConfig(Constants.SEARCH_SERVICE_URL))
			.append(configReader.getAppConfig(Constants.SEARCH_DEVICE_ALL_PROP_NAME));
		isCleanUpdate = true; // This flag signals to clear the whole
				      // cache, before loading all the devices
	    }

	    // query the search api to get the device detail(s)
	    RequestEntity request = new RequestEntity(HttpMethod.GET, new URI(serviceUrl.toString()));
	    ResponseEntity<String> response = restTemplate.exchange(request, String.class);

	    if (response.getStatusCode() == HttpStatus.OK) {
		if (response.getBody().isEmpty()) {
		    LOG.error("Request to Search Service successful, but device not found.");
		    throw new WebApplicationException(Status.NOT_FOUND);
		}

		// update/add the device details in cache depending on the flag
		// isUpdate = true/false respectively
		if (isUpdate) {
		    configReader.updateDeviceConfig(convertJsonToEntityList(response.getBody()), isCleanUpdate);
		} else {
		    configReader.addDeviceToCache(convertJsonToEntityList(response.getBody()));
		}
	    } else if (response.getStatusCode() == HttpStatus.NOT_FOUND) {
		LOG.error("Search Service did not find the device(s)");
		throw new WebApplicationException(Status.NOT_FOUND);
	    } else {
		LOG.error("Search Service request failed with status code other than NOT_FOUND.");
		throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);
	    }

	} catch (RestClientException rce) {
	    LOG.error(ExceptionUtils.getFullStackTrace(rce));
	    throw new WebApplicationException(rce, Status.INTERNAL_SERVER_ERROR);
	} catch (Exception e) {
	    LOG.error(ExceptionUtils.getFullStackTrace(e));
	    throw new WebApplicationException(e, Status.INTERNAL_SERVER_ERROR);
	}
    }

    private List<DeviceDTO> convertJsonToEntityList(String response) {
	List<DeviceDTO> entities;
	try {
	    JsonNode jn = objectMapper.readTree(response);
	    entities = new ArrayList<>();

	    if (jn.isObject()) {
		entities.add(objectMapper.readValue(response, DeviceDTO.class));
	    } else if (jn.isArray()) {
		TypeReference<ArrayList<DeviceDTO>> ref = new TypeReference<ArrayList<DeviceDTO>>() {
		};
		entities = objectMapper.readValue(response, ref);
	    }
	    return entities;

	} catch (IOException e) {
	    LOG.error(ExceptionUtils.getFullStackTrace(e));
	    throw new WebApplicationException(e, Status.INTERNAL_SERVER_ERROR);
	}
    }

    public void deleteDeviceFromCache(String deviceId) {
	if (deviceId == null) {
	    LOG.error("deviceId missing for a DELETE request");
	    throw new WebApplicationException(Status.BAD_REQUEST);
	}

	try {
	    String queryStr = ".*" + deviceId + ".*";
	    String[] deviceDetails = getDeviceDetails(queryStr);
	    if (deviceDetails != null) {
		deviceConfig.remove(convertToCacheFormat(deviceDetails));
	    }
	} catch (Exception e) {
	    LOG.error(ExceptionUtils.getFullStackTrace(e));
	    throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);
	}

    }

    public void updateDeviceConfig(List<DeviceDTO> devices, boolean isCleanUpdate) {
	if (isCleanUpdate) {
	    deviceConfig.clear();
	} else {
	    for (DeviceDTO device : devices) {
		deleteDeviceFromCache(device.getId());
	    }
	}
	addDeviceToCache(devices);
    }

    public void addDeviceToCache(List<DeviceDTO> devices) {
	for (DeviceDTO device : devices) {
	    deviceConfig.add(convertToCacheFormat(device));
	}
    }

    private String convertToCacheFormat(DeviceDTO device) {
	return convertToCacheFormat(device.getSiteId(), device.getId(), device.getIp(), device.getSerialNumber());
    }

    private String convertToCacheFormat(String... elements) {
	return String.join("-", elements);
    }

    public String getDeviceIdUsingSiteIdIpAddress(String siteId, String ipAddress) throws Exception {
	String deviceID = null;
	// format for device config siteId-deviceId-Ip_address-serial#
	String queryStr = siteId + ".*" + ipAddress + ".*";
	String[] deviceDetails = getDeviceDetails(queryStr);
	LOG.debug("deviceDetails::" + deviceDetails);
	if (deviceDetails != null) {
	    deviceID = deviceDetails[1];
	} else {
	    // call advanced searchAPI to get device details of provided siteid
	    // and ipaddress.update cache and return deviceID
	    LOG.info("getDeviceIdUsingSiteIdIpAddress: Not found in cache - going for search: " + ipAddress + ":"
		    + siteId);
	    AdvanceSearchDeviceRequest searchRequest = createDeviceSearchRequest(Constants.SITE_ID_SEARCH, siteId, null,
		    null, Constants.IP_ADDRESS, ipAddress);
	    deviceID = updateCacheAndRetunDeviceId(searchRequest);

	}
	return deviceID;

    }

    public String getDeviceIdUsingSiteIdSerialNo(String serialNo, String siteId) throws Exception {
	String deviceID = null;
	// format for device config siteId-deviceId-Ip_address-serial#
	// data.serial
	String queryStr = siteId + ".*" + serialNo;
	String[] deviceDetails = getDeviceDetails(queryStr);
	if (deviceDetails != null) {
	    deviceID = deviceDetails[1];
	} else {
	    // TODO - call advanced searchAPI to get device details of provided
	    // siteid and serialnumber.update cache and return deviceID
	    LOG.info("getDeviceIdUsingSiteIdSerialNo: Not found in cache - going for search: " + serialNo + ":"
		    + siteId);
	    AdvanceSearchDeviceRequest searchRequest = createDeviceSearchRequest(Constants.SITE_ID_SEARCH, siteId,
		    Constants.SERIAL_NUMBER, serialNo, null, null);
	    deviceID = updateCacheAndRetunDeviceId(searchRequest);
	}
	return deviceID;
    }

    public String getSiteIdUsingDeviceId(String deviceId) {
	String siteID = null;
	// format for device config siteId-deviceId-Ip_address-serial#
	String queryStr = ".*" + deviceId + ".*";
	String[] deviceDetails = getDeviceDetails(queryStr);
	if (deviceDetails != null) {
	    siteID = deviceDetails[0];
	} else {
	    // Call Search API to get device details of provided deviceID.
	    // update cache and return siteID
	    LOG.info("getSiteIdUsingDeviceId: Not found in cache - going for search: " + deviceId);
	    updateDeviceCache(deviceId, false);
	    deviceDetails = getDeviceDetails(queryStr);
	    if (deviceDetails != null) {
		siteID = deviceDetails[0];
	    }
	}
	return siteID;
    }

    public String getIpAddUsingDeviceId(String deviceId) {
	String ipAdd = null;
	// format for device config siteId-deviceId-Ip_address-serial#
	String queryStr = ".*" + deviceId + ".*";
	String[] deviceDetails = getDeviceDetails(queryStr);
	if (deviceDetails != null) {
	    ipAdd = deviceDetails[2];
	} else {
	    // Call Search API to get device details of provided deviceID.
	    // update cache and return ipAdd
	    LOG.info("getIpAddUsingDeviceId: Not found in cache - going for search: " + deviceId);
	    updateDeviceCache(deviceId, false);
	    deviceDetails = getDeviceDetails(queryStr);
	    if (deviceDetails != null) {
		ipAdd = deviceDetails[2];
	    }
	}
	return ipAdd;
    }

    public String getDeviseIdUsingSerialNo(String serialNo) throws Exception {
	String deviceID = null;
	// format for device config siteId-deviceId-Ip_address-serial#
	String queryStr = ".*" + serialNo;
	String[] deviceDetails = getDeviceDetails(queryStr);
	if (deviceDetails != null) {
	    deviceID = deviceDetails[1];
	} else {
	    // call advanced searchAPI to get device details of provided
	    // serialnumber.update cache and return deviceID
	    LOG.info("getDeviseIdUsingSerialNo: Not found in cache - going for search: " + serialNo);
	    AdvanceSearchDeviceRequest searchRequest = createDeviceSearchRequest(null, null, Constants.SERIAL_NUMBER,
		    serialNo, null, null);

	    deviceID = updateCacheAndRetunDeviceId(searchRequest);
	}
	return deviceID;
    }

    public String getSiteIdUsingSerialNo(String serialNo) throws Exception {
	String siteID = null;
	// format for device config siteId-deviceId-Ip_address-serial#
	String queryStr = ".*" + serialNo;
	String[] deviceDetails = getDeviceDetails(queryStr);
	if (deviceDetails != null) {
	    siteID = deviceDetails[0];
	} else {
	    LOG.info("getSiteIdUsingSerialNo: Not found in cache - going for search: " + serialNo);
	    AdvanceSearchDeviceRequest searchRequest = createDeviceSearchRequest(null, null, Constants.SERIAL_NUMBER,
		    serialNo, null, null);
	    String deviceSearchResponse = getDeviceSearchDetails(searchRequest);
	    updateCache(processDeviceJson(deviceSearchResponse));
	    siteID = getSiteId(deviceSearchResponse);
	}
	return siteID;
    }

    private String updateCacheAndRetunDeviceId(AdvanceSearchDeviceRequest searchRequest) throws Exception {

	String deviceSearchResponse = getDeviceSearchDetails(searchRequest);
	updateCache(processDeviceJson(deviceSearchResponse));
	LOG.debug("deviceSearchResponse:::" + deviceSearchResponse);
	return getDeviceId(deviceSearchResponse);
    }

    private String getDeviceId(String deviceSearchResponse) {
	String deviceId = null;
	JSONObject obj = new JSONObject(deviceSearchResponse);
	JSONArray arr = obj.getJSONArray(Constants.DATA);
	if (arr != null && arr.length() > 0) {
	    deviceId = arr.getJSONObject(0).getString(Constants.ID);
	}
	return deviceId;
    }

    private String getSiteId(String deviceSearchResponse) throws Exception {

	JSONObject obj = new JSONObject(deviceSearchResponse);
	JSONArray arr = obj.getJSONArray(Constants.DATA);
	String siteId = null;
	if (arr != null && arr.length() > 0) {
	    siteId = arr.getJSONObject(0).getString(Constants.SITE_NAME);
	}
	return siteId;

    }

    private static void updateCache(String cacheString) {
	if (!StringUtils.isEmpty(cacheString)) {
	    if (deviceConfig != null) {
		deviceConfig.add(cacheString);
	    } else {
		deviceConfig = new HashSet<>();
		deviceConfig.add(cacheString);
	    }
	}
    }

    private String[] getDeviceDetails(String queryStr) {
	if (!deviceConfig.isEmpty()) {
	    Optional<String> deviceDetails = deviceConfig.stream().filter(device -> device.matches(queryStr))
		    .findFirst();
	    if (deviceDetails.isPresent()) {
		LOG.debug("getDeviceDetails-deviceDetails:::" + deviceDetails);
		return deviceDetails.get().split("-");
	    }
	}
	return null;
    }

    private AdvanceSearchDeviceRequest createDeviceSearchRequest(String assoctionkey, String assoctionValue,
	    String searchProKey, String searchProValue, String devicePropertyKey, String devicePropertyValue) {

	AdvanceSearchDeviceRequest searchRequest = new AdvanceSearchDeviceRequest();
	searchRequest.setPageNumber(1);
	searchRequest.setPageSize(10);
	if (StringUtils.isNotEmpty(assoctionkey)) {
	    Association association = new Association();
	    association.setAssociationKey(assoctionkey);
	    association.setAssociationValue(Arrays.asList(assoctionValue));
	    searchRequest.setAssociation(Arrays.asList(association));
	} else {
	    searchRequest.setAssociation(Collections.EMPTY_LIST);
	}
	if (StringUtils.isNotEmpty(searchProKey)) {
	    SearchProperties searchProperties = new SearchProperties();
	    searchProperties.setPropertyKey(searchProKey);
	    searchProperties.setPropertyValue(Arrays.asList(searchProValue));
	    searchRequest.setProperties(Arrays.asList(searchProperties));
	} else {

	    searchRequest.setProperties(Collections.EMPTY_LIST);
	}
	if (StringUtils.isNotEmpty(devicePropertyKey)) {
	    DeviceProperties deviceProperties = new DeviceProperties();
	    deviceProperties.setPropertyKey(devicePropertyKey);
	    deviceProperties.setPropertyValue(Arrays.asList(devicePropertyValue));
	    searchRequest.setDeviceProperties(Arrays.asList(deviceProperties));
	} else {
	    searchRequest.setDeviceProperties(Collections.emptyList());
	}
	return searchRequest;
    }

    // process json from searchAPI and return device cache string
    // format for device config siteId-deviceId-Ip_address-serial#
    private String processDeviceJson(String deviceSearchResponse) throws Exception {

	String cacheString = null;
	JSONObject obj = new JSONObject(deviceSearchResponse);
	JSONArray arr = obj.getJSONArray(Constants.DATA);
	if (arr != null) {
	    if (arr.length() == 1) {

		String siteId = arr.getJSONObject(0).getString(Constants.SITE_NAME);
		// String siteId = configdao.getSiteId(siteName);
		String serialNumber = arr.getJSONObject(0).getString(Constants.SERIAL_NUMBER);
		String deviceId = arr.getJSONObject(0).getString(Constants.ID);

		String ipAddress = getIpAddress(arr);

		cacheString = String.join("-", siteId, deviceId, ipAddress, serialNumber);
		LOG.info("cache value {} ", cacheString);
	    } else if (arr.length() > 1) {
		throw new SystemException(ErrorCodes.MULTIPLE_DEVICES_EXIST, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	}
	return cacheString;
    }

    private String getIpAddress(JSONArray arr) {
	String ipAddress = null;
	JSONArray propertiesArray = arr.getJSONObject(0).getJSONArray("properties");
	for (int i = 0; i < propertiesArray.length(); i++) {
	    String variableName = propertiesArray.getJSONObject(i).getString("variableName");
	    if (Constants.IP_ADDRESS.equalsIgnoreCase(variableName)) {
		ipAddress = propertiesArray.getJSONObject(i).getString("variableValue");
		break;
	    }
	}
	return ipAddress;
    }

    public String getDeviceSearchDetails(AdvanceSearchDeviceRequest searchDeviceRequest) {
	String deviceResponse = null;
	String uri = getAppConfig(Constants.SEARCH_SERVICE_URL).concat(getAppConfig(Constants.ADVANCE_SEARCH_DEVICE));

	HttpComponentsClientHttpRequestFactory requestFactory = getRequestFactory();
	requestFactory.setReadTimeout(60000);
	requestFactory.setConnectTimeout(60000);
	requestFactory.setConnectionRequestTimeout(60000);
	RestTemplate restTemplate = new RestTemplate(requestFactory);
	try {
	    deviceResponse = restTemplate.postForObject(uri, searchDeviceRequest, String.class);
	} catch (Exception e) {
	    LOG.error("Exception while Device Management AdvanceSearch: " + e.getMessage());
	    throw e;
	}
	return deviceResponse;
    }

    public static void main(String args[]) throws Exception {
	String uri = "https://hydrodev.centralus.cloudapp.azure.com/api/devicemgmt/";

	String query = ReportUtils.getQuery("DeviceCreate.json");
	query = query.replace("SERIAL-NO", "MYTestSerial");
	query = query.replace("SITE-ID", "TestSerialID");
	query = query.replace("DEVICE-NAME", "MyTEstDeviceName");
	query = query.replace("IP-ADDRESS", "121.0.0.2");
	query = query.replace("TEMP-ID", "66d1b5f0d2f04179af89b1f83115e5ad");

	System.out.println(query);
	try {
	    CommonUtils.disableSslVerification();
	    String response = CommonUtils.doPost(uri, query);
	    System.out.println(response);
	} catch (Exception e) {
	    e.printStackTrace();
	}

    }

    private HttpComponentsClientHttpRequestFactory getRequestFactory() {
	TrustStrategy acceptingTrustStrategy = (cert, authType) -> true;
	SSLContext sslContext = null;
	try {
	    sslContext = SSLContexts.custom().loadTrustMaterial(null, acceptingTrustStrategy).build();
	} catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
	    LOG.error(CommonConstants.STACK_TRACE, ExceptionUtils.getFullStackTrace(e));
	}
	SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext, NoopHostnameVerifier.INSTANCE);

	Registry<ConnectionSocketFactory> socketFactoryRegistry = RegistryBuilder.<ConnectionSocketFactory>create()
		.register("https", sslsf).register("http", new PlainConnectionSocketFactory()).build();

	BasicHttpClientConnectionManager connectionManager = new BasicHttpClientConnectionManager(
		socketFactoryRegistry);
	CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(sslsf)
		.setConnectionManager(connectionManager).build();

	HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
	return requestFactory;
    }

    private static void initRoutine() throws Exception {
	// initiate device config cache
	loadDeviceConfig();
    }

    /**
     * Method to set the error config values.
     * 
     * @param errorConfig
     */
    public void setErrorConfig(HashMap<String, String> errorConfig) {
	ConfigReader.errorConfig = errorConfig;
    }

    // public static String getRoleId(String userRole) {
    // String roleId = roleConfig.get(userRole);
    // if (StringUtils.isEmpty(roleId)) {
    // roleId = Constants.DEFAULT_ROLE_ID;
    // }
    // return roleId;
    // }

    public String getRoleId(String orgType, String userRole) {
	List<RoleDTO> roleList = roleConfig.get(orgType);
	for (RoleDTO roles : roleList) {
	    if (roles.getUserRole().equals(userRole)) {
		return roles.getRoleId();
	    }
	}
	return Constants.DEFAULT_ROLE_ID;
    }

    public int getRoleClearanceLevel(String orgType, String userRole) {
	LOG.debug(orgType + ":" + userRole);
	List<RoleDTO> roleList = roleConfig.get(orgType);
	if (roleList != null) {
	    for (RoleDTO roles : roleList) {
		if (roles.getUserRole().equals(userRole)) {
		    LOG.debug(roles.getUserRole() + ":" + userRole + ":" + roles.getClearanceLevel());
		    return roles.getClearanceLevel();
		}
	    }
	}
	return Constants.DEFAULT_CLEARANCE_LEVEL;
    }

    public Set<String> getSpecificRolePermission(String orgType, String userRole) {
	List<RoleDTO> roleList = roleConfig.get(orgType);
	for (RoleDTO roles : roleList) {
	    if (roles.getUserRole().equals(userRole))
		return roles.getPermissions();
	}
	return null;
    }

    public Set<String> getSpecificRolePermissionRoleId(String orgType, String roleId) {
	List<RoleDTO> roleList = roleConfig.get(orgType);
	for (RoleDTO roles : roleList) {
	    if (roles.getRoleId().equals(roleId))
		return roles.getPermissions();
	}
	return null;
    }

    public List<UserCreationRolesDTO> getUserCreationRoleList(int clearanceLevel, boolean includeSameClearance) {
	List<UserCreationRolesDTO> userCreationList = new LinkedList<>();
	roleConfig.forEach((key, value) -> {
	    UserCreationRolesDTO creationRole = new UserCreationRolesDTO();
	    String uri = Constants.roleUrl.get(key);
	    creationRole.setUri(uri);
	    creationRole.setOrgType(key);
	    List<HashMap<String, Object>> roleList = new LinkedList<>();
	    value.forEach((role) -> {
		if (role.getClearanceLevel() > clearanceLevel) {
		    HashMap<String, Object> hashMap = new HashMap<>();
		    hashMap.put(Constants.NAME, role.getUserRole());
		    String privielge = Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE;
		    hashMap.put(Constants.PRIVILEGE_NAMES.USER_CREATION_FULL_PRIVILEGE,
			    hasPermission(key, role.getUserRole(), privielge));
		    roleList.add(hashMap);
		} else if (role.getClearanceLevel() == clearanceLevel && includeSameClearance) {
		    HashMap<String, Object> hashMap = new HashMap<>();
		    hashMap.put(Constants.NAME, role.getUserRole());
		    String privielge = Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE;
		    hashMap.put(Constants.PRIVILEGE_NAMES.USER_CREATION_FULL_PRIVILEGE,
			    hasPermission(key, role.getUserRole(), privielge));
		    roleList.add(hashMap);
		}
	    });
	    if (roleList != null && roleList.size() > 0) {
		creationRole.setUserRole(roleList);
		userCreationList.add(creationRole);
	    }

	});
	return userCreationList;
    }

    public boolean checkUserRoleAndType(String orgType, String userRole) {
	List<RoleDTO> roleList = roleConfig.get(orgType);
	if (!StringUtils.isEmpty(userRole) && !StringUtils.isEmpty(orgType) && roleList != null) {
	    return CommonUtils.roleExists(roleList, userRole);
	}
	return false;
    }

    public boolean hasPermission(String orgType, String userRole, String permission) {
	try {
	    return (getSpecificRolePermission(orgType, userRole).contains(permission));
	} catch (Exception e) {
	    return false;
	}
    }

    /**
     * Method to get the error config values.
     * 
     * @return the error config hash map.
     */
    public static HashMap<String, String> getErrorConfig() {
	return errorConfig;
    }

    public String getAppConfig(String key) {
	return appConfig.get(key);
    }

    public ESConfig getEsConfig() {
	return esConfig;
    }

    public static void setJWTKey(String key) {
	if (hasObject) {
	    appConfig.put(Constants.JWT_TOKEN, key);
	}
    }

    public TokenCache getTokenCache() {
	return tokenCache;
    }

    private static HashMap<String, String> getErrorMessages() {
	HashMap<String, String> errorConfig = new HashMap<String, String>();
	errorConfig.put("10001",
		"A System Error Occured. Please retry the operation. If the problem persists, contact the system administrator");
	errorConfig.put("10002", "Invalid Token");
	errorConfig.put("10003", "Invalid User Type");
	errorConfig.put("10004", "Invalid User Role");
	errorConfig.put("10005", "Invalid request format.");
	errorConfig.put("10006", "The resource requested is not accessible for the user.");
	errorConfig.put("10007", "The resource requested is not available.");
	errorConfig.put("10008", "Insufficient information to complete the request.");
	errorConfig.put("10009", "Cannot complete request due to insufficient privileges.");
	errorConfig.put("10010", "Given name already exists.");
	errorConfig.put("10011", "Given site id does not exist.");
	errorConfig.put("10012", "Given Account id does not exist.");
	errorConfig.put("10013", "Given Company id does not exist.");
	errorConfig.put("10014", "Site Name already exist.");
	errorConfig.put("10015", "Given email already exists.");
	errorConfig.put("10016", "Given Contact id does not exist.");
	errorConfig.put("10017", "Error occurred while creating a user in AD.");
	errorConfig.put("10018", "The Database file is empty.");
	errorConfig.put("10019", "The uploaded file format is not supported.");
	errorConfig.put("10020", "Missing LM2 information. Please upload LM2 file.");
	errorConfig.put("10021", "Given Equipment ID does not exist.");
	errorConfig.put("10022", "Invalid Month/Year.");
	errorConfig.put("10023",
		"Incorrect File Format/Content. Please verify the file format and file content, and re-upload. If the problem persists, contact the system administrator.");
	errorConfig.put("10024", "Invalid File Structure");
	errorConfig.put("10025",
		"Failed due to an unexpected system error. Please retry uploading the file. If the problem persists, please contact administrator for further details.");
	errorConfig.put("10026", "No data found.");
	errorConfig.put("10027", "The user already exists.");
	errorConfig.put("10028", "The uploaded id is not valid.");
	errorConfig.put("10029", "Error occured while updating the file status.");
	errorConfig.put("10030", "Invalid : Multiple Files in archive");
	errorConfig.put("10031",
		"Invalid data file : The units configured in LM2 does not match the units in the data file.");
	errorConfig.put("10032", "Invalid User name.");
	errorConfig.put("10033", "Invalid Metric Unit.");
	errorConfig.put("10034", "Invalid Mail Format.");
	errorConfig.put("10035", "The specified file export format is not supported.");
	errorConfig.put("10036", "The date range exceeded 12 months limit. Please select range within 12 months.");
	errorConfig.put("10037", "Given Shift id does not exist.");
	errorConfig.put("10038", "Invalid shift selection.Please select a valid shift interval.");
	errorConfig.put("10039", "Invalid time stamp. Please enter a valid timestamp.");
	errorConfig.put("10040", "Invalid thresold value. Please enter a valid threshold between 0-100.");
	errorConfig.put("10041", "Invalid site. Please associate a company to the site.");
	errorConfig.put("10042", "User does not exist in database.");
	errorConfig.put("10045",
		"Device is not associated to the equipment config. Please contact administrator for further details.");
	errorConfig.put("10046", "More then one Device exists with same Ip Address & Site.");
	errorConfig.put("10047", "Device creation failed.");
	errorConfig.put("10048", "Error while communicating with ElasticSearch");
	errorConfig.put("10049", "Invalid config data type. Please upload either config/formulas json file");
	errorConfig.put("10050",
		"Config file is missing for this Unit. Please upload the config.json file before uploading the formula.json file");
	errorConfig.put("10051", "Unknown format encountered.");
	errorConfig.put("10053", "Machines not found.");
	errorConfig.put("10054", "Bad request.");
	errorConfig.put("10055", "Internal error.");
	errorConfig.put("10056", "Configuration property missing.");
	errorConfig.put("10057", "Invalid date range.");
	errorConfig.put("10058", "Failed to access device management API.");
	errorConfig.put("10059", "Invalid device Id");
	return errorConfig;
    }

}
