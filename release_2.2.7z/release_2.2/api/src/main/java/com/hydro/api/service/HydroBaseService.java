package com.hydro.api.service;

import java.security.Principal;
import java.util.HashMap;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.business.HydroBL;
import com.hydro.api.base.common.CommonConstants;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.MetaDataDTO;
import com.hydro.api.dto.ResponseDTO;
import com.hydro.api.exception.ExceptionHandler;
import com.hydro.api.exception.SystemException;
import com.hydro.api.service.helper.ServiceHelper;

/**
 * Base Service : Entry Point to the JSON APIs.
 * 
 * @author Shreyas
 *
 */
// No Base context root for the Services. Each services have their respective
// Endpoints.
@Path("/")
@Produces({ MediaType.APPLICATION_JSON })
public class HydroBaseService {
    private static final Logger LOG = LoggerFactory.getLogger(HydroBaseService.class);
    protected HashMap<String, String> errorMessages;
    protected HydroBL BL;
    protected String resStr = null;
    protected Object obj = null;
    protected ResponseDTO responseDTO;

    public HydroBaseService() throws Exception {
	errorMessages = ConfigReader.getObject().getErrorConfig();
	responseDTO = new ResponseDTO();
    }

    public HydroBaseService(@Context SecurityContext securityContext,
	    @HeaderParam(Constants.TIME_ZONE_HEADER) String timeZone) throws Exception {
	Principal principal = securityContext.getUserPrincipal();
	String username = principal.getName();
	errorMessages = ConfigReader.getObject().getErrorConfig();
	responseDTO = new ResponseDTO();
	BL = new HydroBL(username, timeZone);
    }

    /**
     * Build JSON String from ServiceResponseDTO.
     * 
     * @param responseDTO
     *            - reference of ServiceResponseDTO
     * @return JSON String
     */

    /**
     * Method to fetch the config objects on start up.
     * 
     * @throws Exception
     */

    /**
     * Test API.
     * 
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/test")
    public String test() {
	long start = System.currentTimeMillis();
	resStr = "{\"messgae\":\"Base APIs Works Fine!\"}";
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * Testing the DB connection.
     * 
     * @return
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/testDbConnection")
    public String testDbConnection() {
	long start = System.currentTimeMillis();

	try {
	    BL.initRoutine();
	    // Check for the Database connection.
	    boolean flag = BL.testDbConnection();
	    if (flag) {
		resStr = "{ \"connected\":true}";
	    } else {
		resStr = "{ \"connected\":false}";
	    }
	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @GET
    @Path("/getMetaData")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getMetaData() throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    MetaDataDTO permissions = (BL).getMetaData();
	    responseDTO.setResponseObject(permissions);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	}catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @GET
    @Path("/getCompomentHealth")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getCompomentHealth() throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    HashMap<String, Object> health = ReportUtils.getCompomentHealth();
	    responseDTO.setResponseObject(health);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @GET
    @Path("/logout")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String logout() throws Exception {
	try {
	    BL.initRoutine();
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);
	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	return resStr;
    }

    @GET
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String login() throws Exception {
	try {
	    BL.initRoutine();
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);
	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	return resStr;
    }
    
    
    @GET
    @Path("/loadDeviceInfo")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
	public String loadDeviceInfo() throws Exception {
		long start = System.currentTimeMillis();
		try {
			BL.initRoutine();
			
			responseDTO.setResponseStatus(true);
			responseDTO.setResponseObject("deviceConfig");
			responseDTO.setResponseStatus(true);
			resStr = ServiceHelper.buildJsonString(responseDTO);
		} catch (SystemException e) {
			LOG.error(e.getMessage());
			resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
			e.printStackTrace();
		} catch (Exception e) {
			LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
					ErrorCodes.StatusCodes.FAILURE, null);
			resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
		}

		recordTime(start, resStr);

		return resStr;
	}
    
  

    
    public String handleException(Exception e)  {
		String resultJson = null;
		if (e instanceof SystemException) {
			LOG.error(CommonConstants.ERROR, e.getMessage());
			resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage((SystemException) e, errorMessages));
			e.printStackTrace();
		} else {
			LOG.error(CommonConstants.STACK_TRACE, ExceptionUtils.getFullStackTrace(e));
			e.printStackTrace();
			SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,ErrorCodes.StatusCodes.FAILURE, null);
			resultJson = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
		}
		return resultJson;

	}
	
	public void recordTime(long start,String resStr) {
			long end = System.currentTimeMillis();
			LOG.info(CommonConstants.TOTAL_TIME_TAKEN, (end - start));
			LOG.debug(CommonConstants.RESPONSE_STRING, resStr);
		}
}
