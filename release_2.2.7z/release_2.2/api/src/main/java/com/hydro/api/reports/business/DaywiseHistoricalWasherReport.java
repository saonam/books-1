package com.hydro.api.reports.business;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.DailyReportUtils;
import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.base.dao.ElasticSearchDAO;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.DailyReportEquipmentDTO;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.EventDTO;
import com.hydro.api.dto.ShiftDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.reports.CycleDTO;
import com.hydro.api.dto.reports.DailyReportFormulaDTO;
import com.hydro.api.dto.reports.DailyReportRequestDTO;
import com.hydro.api.dto.reports.DailyReportWasherDTO;
import com.hydro.api.dto.reports.DataRequestDTO;
import com.hydro.api.dto.reports.DaywiseReportRequestDTO;
import com.hydro.api.dto.reports.EventsDTO;
import com.hydro.api.dto.reports.PhaseDTO;
import com.hydro.api.exception.SystemException;
import io.jsonwebtoken.lang.Collections;

public class DaywiseHistoricalWasherReport implements DataRequestProcessor {
    private static final Logger LOG = LoggerFactory.getLogger(DaywiseHistoricalWasherReport.class);

    private final ConfigReader config;

    private DailyReportUtils dailyReportUtils;
    private Gson gson = new Gson();

    public DaywiseHistoricalWasherReport() throws Exception {
	dailyReportUtils = new DailyReportUtils();
	config = ConfigReader.getObject();
    }
	
    public DailyReportEquipmentDTO getData(DataRequestDTO dataRequest, Map<RequestContextEntity, Object> context) throws Exception {

	DaywiseReportRequestDTO requestDto = (DaywiseReportRequestDTO) dataRequest;

	SiteDTO site = (SiteDTO) context.get(DataRequestProcessor.RequestContextEntity.SITE);

	EquipmentDTO equipment = (EquipmentDTO) context.get(DataRequestProcessor.RequestContextEntity.EQUIPMENT);

	Map<Integer, DailyReportWasherDTO> washers = dailyReportUtils.createWasherMap(equipment);

	if (Collections.isEmpty(washers)) {
	    throw new SystemException(ErrorCodes.MACHINES_NOT_FOUND, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	JsonArray events = getEvents(site, equipment, requestDto);

	buildWashersState(washers, events, site, equipment, requestDto);

	List<ShiftDTO> shifts = getShiftsView(washers, site, requestDto);

	calculateAggregrates(washers, shifts, site, requestDto);

	cleanData(washers);

	DailyReportEquipmentDTO response = prepareResponseEntity(requestDto, washers, site, equipment);

	return response;
    }

    private DailyReportRequestDTO getRequestDto(DaywiseReportRequestDTO dataRequest, SiteDTO site,
	    EquipmentDTO equipment) throws Exception {
	DailyReportRequestDTO reportRequest = new DailyReportRequestDTO();
	reportRequest.setSiteId(site.getSiteId());
	reportRequest.setEquipmentId(equipment.getEquipmentId());

	reportRequest.setDate(dataRequest.getDate());
	reportRequest.setStartShift(dataRequest.getStartShift());
	reportRequest.setEndShift(dataRequest.getEndShift());
	reportRequest.setHistoricalReport(dataRequest.isHistoricalReport());

	reportRequest.setSelectedShifts(dataRequest.getSelectedShifts());
	return reportRequest;
    }

    private void buildWashersState(Map<Integer, DailyReportWasherDTO> washers, JsonArray events, SiteDTO site,
	    EquipmentDTO equipment, DaywiseReportRequestDTO requestDto) throws Exception {

	for (int i = 0; i < events.size(); i++) {
	    JsonObject eventJson = (JsonObject) events.get(i);
	    EventDTO event = gson.fromJson(eventJson, EventDTO.class);

	    Integer machineId = eventJson.get(Constants.REPORTS.MACHINE_WASHER).getAsInt();
	    if (machineId <= 0) {
		LOG.error("Data not proper for the washer event : " + eventJson);
		continue;
	    }

	    DailyReportWasherDTO washer = washers.get(machineId);
	    
	    if(washer == null) {
		continue;
	    }

	    updateWasherState(washer, eventJson, site, equipment, requestDto);
	}
    }

    private void updateIncompleteCycleData(SiteDTO site, EquipmentDTO equipment, DailyReportWasherDTO washer,
	    DaywiseReportRequestDTO requestDto, JsonObject event, CycleDTO cycle) throws Exception {
//	Integer cycleVal = event.getProceso();
	Integer cycleVal = event.get(Constants.REPORTS.PROCESS).getAsInt();
	String startShift = CommonUtils.getShiftDateTimeUTC(requestDto.getDate(), requestDto.getStartShift(),
		site.getTimeZone());

	DailyReportRequestDTO tempRequestDto = getRequestDto(requestDto, site, equipment);
//	dailyReportUtils.incompleteCycleData(site, tempRequestDto, cycleVal, equipment.getEquipmentId(),
//		gson.toJsonTree(event).getAsJsonObject(), washer.getCycleHashMap(), startShift, cycle,
//		site.getTimeZone());
	
	dailyReportUtils.incompleteCycleData(site, tempRequestDto, cycleVal, equipment.getEquipmentId(),
		event, washer.getCycleHashMap(), startShift, cycle,
		site.getTimeZone());
    }

    private boolean updateWasherState(DailyReportWasherDTO washer, JsonObject event, SiteDTO site, EquipmentDTO equipment,
	    DaywiseReportRequestDTO requestDto) throws Exception {

	Map<Integer, DailyReportFormulaDTO> formulaMap = washer.getFormulaHashMap();
	if (MapUtils.isEmpty(formulaMap)) {
	    washer.setFormulaHashMap(new LinkedHashMap<>());
	}

	washer.setLbs(event.get(Constants.REPORTS.KG_REALS).getAsInt());

	Map<Integer, CycleDTO> cycles = washer.getCycleHashMap();

	if (!updateCycleState(cycles, event, washer, site, equipment, requestDto)) {
	    return false;
	}

	updateFormulaDetails(washer, event);

	return true;
    }

    private boolean updateCycleState(Map<Integer, CycleDTO> cycles, JsonObject event, DailyReportWasherDTO washer,
	    SiteDTO site, EquipmentDTO equipment, DaywiseReportRequestDTO requestDto) throws Exception {

	Integer cycleId = event.get(Constants.REPORTS.PROCESS).getAsInt();
	if (cycleId <= 0) {
	    LOG.error("Data not proper for the washer event : " + event);
	    return false;
	}
	
	String eventType = event.get(Constants.REPORTS.EVENT_TYPE).getAsString();

	CycleDTO cycle = cycles.get(cycleId);
	if (cycle == null) {
	    cycle = dailyReportUtils.createCycle(event);
	    cycles.put(cycleId, cycle);

	    
	    if (!eventType.equals(config.getAppConfig(Constants.REPORTS.EVENT_TYPE_START_OF_CYCLE))) {
		updateIncompleteCycleData(site, equipment, washer, requestDto, event, cycle);
	    }
	}

	DailyReportFormulaDTO formula = cycle.getFormula();
	Map<Integer, PhaseDTO> phaseMap = formula.getPhaseMap();

	int previousActivePhaseId = cycle.getCyclePreviousActivePhase();
	PhaseDTO previousActivePhase = phaseMap.get(previousActivePhaseId);

	String phaseString = event.get(Constants.REPORTS.PHASE).getAsString();
//	PhaseDTO currentPhase = phaseMap.get(event.getFase());
	PhaseDTO currentPhase = phaseMap.get(Integer.valueOf(phaseString));

	// set the cycle start time
	if (eventType.equals(config.getAppConfig(Constants.REPORTS.EVENT_TYPE_START_OF_CYCLE))
		&& cycle.getEndCycleTime() == null) {
	    cycle.setStartCycleTime(
		    ReportUtils.convertStringToDate(CommonUtils.extractFechaDateInProcessableFormat(event.get(Constants.REPORTS.DATE_TIME).getAsString())));
	}

	// set the cycle end time and set the previous phase as complete
	if (eventType.equals(config.getAppConfig(Constants.REPORTS.EVENT_TYPE_END_OF_CYCLE))
		&& String.valueOf(phaseString).equals(config.getAppConfig(Constants.REPORTS.ZERO_PHASE))) {
	    cycle.setCycleCompleted(true);
	    cycle.setEndCycleTime(
		    ReportUtils.convertStringToDate(CommonUtils.extractFechaDateInProcessableFormat(event.get(Constants.REPORTS.DATE_TIME).getAsString())));
	}

	updatePhaseDetails(currentPhase, event, previousActivePhase);

	// update previous active phase
	if (!eventType.equals(config.getAppConfig(Constants.REPORTS.MISSED_PHASE))
		&& !phaseString.equals(config.getAppConfig(Constants.REPORTS.ZERO_PHASE))) {
	    cycle.setCyclePreviousActivePhase(Integer.valueOf(phaseString));
	}

	currentPhase = phaseMap.get(Integer.valueOf(phaseString));
	if (currentPhase != null && currentPhase.isValidPhase()) {
	    dailyReportUtils.createEvent(event, currentPhase);
	}

	return true;

    }

    private void updatePhaseDetails(PhaseDTO currentPhase, JsonObject event, PhaseDTO previousActivePhase) {
	String eventType = event.get(Constants.REPORTS.EVENT_TYPE).getAsString();
	String phaseString = event.get(Constants.REPORTS.PHASE).getAsString();
	if (previousActivePhase != null) {
	    if (eventType.equals(config.getAppConfig(Constants.REPORTS.EVENT_TYPE_END_OF_CYCLE))
		    || (!eventType.equals(config.getAppConfig(Constants.REPORTS.MISSED_PHASE)) && !String
			    .valueOf(phaseString).equals(config.getAppConfig(Constants.REPORTS.ZERO_PHASE)))) {
		previousActivePhase.setPhaseStatus(ReportUtils.PHASE_STATUS.SUCCESSFUL);
		previousActivePhase.setActivePhase(false);
	    }
	}

	if (!eventType.equals(config.getAppConfig(Constants.REPORTS.MISSED_PHASE))) {
	    if (!String.valueOf(phaseString).equals(config.getAppConfig(Constants.REPORTS.ZERO_PHASE))) {
		currentPhase.setPhaseStatus(ReportUtils.PHASE_STATUS.IN_PROGRESS);
		currentPhase.setActivePhase(true);

	    }

	} else {
	    if (!String.valueOf(phaseString).equals(config.getAppConfig(Constants.REPORTS.ZERO_PHASE))) {
		currentPhase.setPhaseStatus(ReportUtils.PHASE_STATUS.MISSED_PHASE);
		currentPhase.setActivePhase(false);
	    }
	}
    }

    private void updateFormulaDetails(DailyReportWasherDTO washer, JsonObject event) {
	dailyReportUtils.createFormulaMap(washer, event);
    }

    private void calculateAggregrates(Map<Integer, DailyReportWasherDTO> washers, List<ShiftDTO> shifts, SiteDTO site,
	    DaywiseReportRequestDTO requestDto) throws SystemException, Exception {
	String fromDate = CommonUtils.convertZonedToUTC(
		DailyReportUtils.formDate(CommonUtils.getDateObject(requestDto.getDate()), requestDto.getStartShift()),
		site.getTimeZone());
	String toDate = CommonUtils.convertZonedToUTC(
		DailyReportUtils.formDate(CommonUtils.getDateObject(requestDto.getDate()), requestDto.getEndShift()),
		site.getTimeZone());
	long currentTime = ReportUtils.convertStringToDate(
		CommonUtils.convertZonedToUTC(ReportUtils.getCurrentDateTime(site.getTimeZone()), site.getTimeZone()))
		.getTime();

	dailyReportUtils.updateIdleTime(washers, site, fromDate, currentTime);
	dailyReportUtils.setWasherTurnTime(washers, fromDate, toDate, site, currentTime);
	dailyReportUtils.setMachineEfficiency(washers, fromDate, toDate, currentTime);
	dailyReportUtils.totalLbs(washers);
	dailyReportUtils.formulaCostCalculation(washers);
	dailyReportUtils.setCycleTurnRunTime(washers,
		dailyReportUtils.getShiftWithLeastStartTime(requestDto.getSelectedShifts()));

	dailyReportUtils.setEfficiencyAndTurnTime(shifts, shifts.get(0));
	dailyReportUtils.calculateChemicalDispensed(washers);
    }

    private List<ShiftDTO> getShiftsView(Map<Integer, DailyReportWasherDTO> washers, SiteDTO site,
	    DaywiseReportRequestDTO requestDto) {

	List<ShiftDTO> shifts = requestDto.getSelectedShifts();
	ShiftDTO shift = shifts.get(0);
	shift.setWasherHashMap(washers);

	return shifts;
    }

//    private ShiftDTO prepareResponseEntity(DaywiseReportRequestDTO requestDto,
//	    Map<Integer, DailyReportWasherDTO> washers, SiteDTO site) {
//
//	List<ShiftDTO> shifts = requestDto.getSelectedShifts();
//	ShiftDTO shift = shifts.get(0);
//	shift.setStartTime(null);
//	shift.setEndTime(null);
//
//	return shift;
//    }

    private DailyReportEquipmentDTO prepareResponseEntity(DaywiseReportRequestDTO requestDto,
	    Map<Integer, DailyReportWasherDTO> washers, SiteDTO site, EquipmentDTO equipment) {

	DailyReportEquipmentDTO reportEquipment = new DailyReportEquipmentDTO();
	reportEquipment.setEquipmentId(equipment.getEquipmentId());
	reportEquipment.setEquipmentType(Constants.EquipmentType.TUNNEL.contentEquals(equipment.getEquipmentType()) ? Constants.TUNNEL : Constants.WASHER_EXTRACTOR);
	reportEquipment.setEquipmentName(StringUtils.trim(equipment.getEquipmentName()));
	reportEquipment.setWasherHashMap(washers);

	return reportEquipment;
    }

    private CycleDTO createCycle(JsonObject event) throws Exception {
//	return dailyReportUtils.createCycle(gson.toJsonTree(event).getAsJsonObject());
	return dailyReportUtils.createCycle(event);
    }

    private JsonArray getEvents(SiteDTO site, EquipmentDTO equipment, DaywiseReportRequestDTO requestDto)
	    throws SystemException, Exception {
	ConfigReader config = new ConfigReader();

	String fromDate = CommonUtils.convertZonedToUTC(
		DailyReportUtils.formDate(CommonUtils.getDateObject(requestDto.getDate()), requestDto.getStartShift()),
		site.getTimeZone());
	String toDate = CommonUtils.convertZonedToUTC(
		DailyReportUtils.formDate(CommonUtils.getDateObject(requestDto.getDate()), requestDto.getEndShift()),
		site.getTimeZone());

	ElasticSearchDAO esDao = new ElasticSearchDAO(false, config.getEsConfig());
	JsonArray events = esDao.getEvents(site, equipment, fromDate, toDate);

	return events;
    }

    private void cleanData(Map<Integer, DailyReportWasherDTO> washers) {
	washers.forEach((washerId, washer) -> {
	    washer.setIdleTime(null);
	    washer.setFirstCycleKey(null);
	    washer.setLastCycleKey(null);
	    washer.setTimeElapsedInShift(null);
	    washer.setTotalCycleActiveTime(null);
	    washer.setTotalTurnTimeCount(null);
	    washer.setTotalTurnTime(null);
	    washer.setWasherTurnTimeAverage(null);
	    washer.setWasherTurnTimeTotal(null);
	    washer.setWasherRunTimeAverage(null);
	    washer.setWasherRunTimeTotal(null);
	    washer.setAverageTurnTime(null);
	    for(Map.Entry<Integer, CycleDTO> entry : washer.getCycleHashMap().entrySet()) {
		CycleDTO cycle = entry.getValue();
		cycle.setCyclePreviousActivePhase(null);
		cycle.setTurnTime(null);
		if(cycle.getFormula() != null && MapUtils.isNotEmpty(cycle.getFormula().getPhaseMap())) {
		    Map<Integer, PhaseDTO> phases = cycle.getFormula().getPhaseMap();
		    for(Map.Entry<Integer, PhaseDTO> phase : phases.entrySet()) {
			if(phase.getValue()!=null && CollectionUtils.isNotEmpty(phase.getValue().getEventList())) {
			    for(EventsDTO event : phase.getValue().getEventList()) {
				event.setCurrentStatus(null);
				event.setAlarmType(null);
			    }
			}
		    }
		}
	    }
	});
    }
}
