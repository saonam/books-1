package com.hydro.api.company.business;

import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.business.HydroBL;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.company.dao.CompanyDao;
import com.hydro.api.company.dao.concrete.CompanyCompanyDao;
import com.hydro.api.company.dao.concrete.HydroCompanyDao;
import com.hydro.api.company.dao.concrete.PartialCompanyCompanyDao;
import com.hydro.api.company.dao.concrete.PartialHydroCompanyDao;
import com.hydro.api.company.dao.concrete.SiteCompanyCompanyDao;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.CompanyDTO;
import com.hydro.api.dto.CompanyListResponseDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.site.dao.concrete.CompanySiteDao;
import com.hydro.api.site.dao.concrete.HydroSiteDao;
import com.hydro.api.site.dao.concrete.PartialCompanySiteDao;
import com.hydro.api.site.dao.concrete.SiteComapnySiteDao;

/**
 * Business layer for the Application.
 * 
 * @author Shreyas
 *
 */
public class HydroCompanyBL extends HydroBL {
    private static final Logger LOG = LoggerFactory.getLogger(HydroCompanyBL.class);

    public HydroCompanyBL(String userId, String timeZone) throws SystemException, Exception {
	super(userId, timeZone);

	LOG.debug("In Hydro Company BL.");
	
	String orgType = user.getOrgType();
	switch (orgType) {
	case Constants.HYDRO:
	    hydroDao =  new HydroCompanyDao();
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new HydroCompanyDao()
			    :   new PartialHydroCompanyDao();
	    break;
	case Constants.COMPANY:
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new CompanyCompanyDao()
		    :   new PartialCompanyCompanyDao();
	    break;
	case Constants.SITE:
	    hydroDao = (permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE)) ? new CompanyCompanyDao()
		    : new SiteCompanyCompanyDao();
	    break;
	default:
	    LOG.debug("Unknown org type");
	}
	
	
    }

    public boolean testCompanyDbConnection() {

	return ((CompanyDao) hydroDao).testCompanyDbConnection();

    }

    public CompanyListResponseDTO getCompanyList(CompanyDTO company) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.COMPANY_LIST);
	CompanyListResponseDTO companyList = ((CompanyDao) hydroDao).getCompanyList(user, company);
	return companyList;
    }

    public CompanyDTO getCompanyDetails(CompanyDTO companyDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.COMPANY_VIEW);
	if (!((CompanyDao) hydroDao).hasVisibility(user, companyDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	CompanyDTO company = ((CompanyDao) hydroDao).getCompanyDetails(companyDTO);
	if (company == null) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	company.setSiteList(((CompanyDao) hydroDao).getSiteListForCompany(companyDTO));
	company.setContactList(((CompanyDao) hydroDao).getContactListForCompany(user, companyDTO));
	CompanyDTO companyDTO2 = CompanyDao.getCompanyPreferenceDetails(user, companyDTO.getCompanyId());
	CompanyDTO companyDetails = null;

	if (companyDTO2.getSystemAlarmMap() == null || companyDTO2.getSystemAlarmMap().isEmpty()) {
	    companyDetails = getAlertSetting();
	    company.setSystemAlarmMap(companyDetails.getSystemAlarmMap());
	} else {
	    company.setSystemAlarmMap(companyDTO2.getSystemAlarmMap());
	}
	if (companyDTO2.getPreDefinedAlarmMap() == null || companyDTO2.getPreDefinedAlarmMap().isEmpty()) {
	    if (companyDetails == null) {
		companyDetails = getAlertSetting();
	    }
	    company.setPreDefinedAlarmMap(companyDetails.getPreDefinedAlarmMap());
	} else {
	    company.setPreDefinedAlarmMap(companyDTO2.getPreDefinedAlarmMap());
	}

	return company;
    }

    public String getExistingCompanyNameId(CompanyDTO companyDTO) throws Exception {
	if (StringUtils.isEmpty(companyDTO.getName())) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	return ((CompanyDao) hydroDao).companyNameExists(user, companyDTO);
    }

    public boolean companyNameExists(CompanyDTO companyDTO) throws Exception {
	if (StringUtils.isEmpty(getExistingCompanyNameId(companyDTO))) {
	    return false;
	}
	return true;
    }

    public List<SiteDTO> getSiteList() throws Exception {
	return ((CompanyDao) hydroDao).getSiteList(user);
    }

    public CompanyDTO createCompany(CompanyDTO companyDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.COMPANY_CREATE);

	List<Object> params = getInsufficientParamsListCreate(companyDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	if (companyNameExists(companyDTO)) {
	    throw new SystemException(ErrorCodes.NAME_EXISTS, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	return ((CompanyDao) hydroDao).createCompany(user, companyDTO);
    }

    public CompanyDTO getAlertSetting() throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.ALERT_SETTING);
	return ((CompanyDao) hydroDao).getAlarmDetails();
    }

    public boolean updateCompany(CompanyDTO companyDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.COMPANY_UPDATE);
	if (user.getOrgType().equals(Constants.HYDRO)) {
	    // Validation
	    List<Object> params = getInsufficientParamsListUpdate(companyDTO);
	    if (params.size() > 0) {
		throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST, params);
	    }
	    String compExitingId = getExistingCompanyNameId(companyDTO);
	    if (!(StringUtils.isEmpty(compExitingId) || companyDTO.getCompanyId().equals(compExitingId))) {
		throw new SystemException(ErrorCodes.NAME_EXISTS, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }
	}
	if (user.getUserRole().equals(Constants.CHEMICAL_COMPANY_ADMIN)) {
	    List<Object> params = new LinkedList<>();
	    if (StringUtils.isEmpty(companyDTO.getCompanyId())) {
		params.add(ErrorCodes.InsufficientParams.COMPANY_ID);
		throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION,
			ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST, params);
	    }
	}
	return ((CompanyDao) hydroDao).updateCompany(user, companyDTO);
    }

    protected List<Object> getInsufficientParamsListCreate(CompanyDTO companyDTO) {
	List<Object> params = new LinkedList<>();
	if (companyDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.COMPANY_OBJECT);

	}
	if (StringUtils.isEmpty(companyDTO.getName())) {
	    params.add(ErrorCodes.InsufficientParams.COMPANY_NAME);
	}
	if (StringUtils.isEmpty(companyDTO.getAddress1())) {
	    params.add(ErrorCodes.InsufficientParams.ADDRESS1);
	}
	if (StringUtils.isEmpty(companyDTO.getState())) {
	    params.add(ErrorCodes.InsufficientParams.STATE);
	}
	if (StringUtils.isEmpty(companyDTO.getCountry())) {
	    params.add(ErrorCodes.InsufficientParams.COUNTRY);
	}
	if (StringUtils.isEmpty(companyDTO.getCity())) {
	    params.add(ErrorCodes.InsufficientParams.CITY);
	}
	if (StringUtils.isEmpty(companyDTO.getZipCode())) {
	    params.add(ErrorCodes.InsufficientParams.ZIPCODE);
	}
	return params;

    }

    protected List<Object> getInsufficientParamsListUpdate(CompanyDTO companyDTO) {
	List<Object> params = new LinkedList<>();
	if (companyDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.COMPANY_OBJECT);

	}
	if (StringUtils.isEmpty(companyDTO.getCompanyId())) {
	    params.add(ErrorCodes.InsufficientParams.COMPANY_ID);
	}
	if (StringUtils.isEmpty(companyDTO.getName())) {
	    params.add(ErrorCodes.InsufficientParams.COMPANY_NAME);
	}
	if (StringUtils.isEmpty(companyDTO.getAddress1())) {
	    params.add(ErrorCodes.InsufficientParams.ADDRESS1);
	}
	if (StringUtils.isEmpty(companyDTO.getState())) {
	    params.add(ErrorCodes.InsufficientParams.STATE);
	}
	if (StringUtils.isEmpty(companyDTO.getCountry())) {
	    params.add(ErrorCodes.InsufficientParams.COUNTRY);
	}
	if (StringUtils.isEmpty(companyDTO.getCity())) {
	    params.add(ErrorCodes.InsufficientParams.CITY);
	}
	if (StringUtils.isEmpty(companyDTO.getZipCode())) {
	    params.add(ErrorCodes.InsufficientParams.ZIPCODE);
	}
	return params;
    }
}
