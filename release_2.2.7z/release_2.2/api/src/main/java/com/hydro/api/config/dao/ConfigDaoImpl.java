package com.hydro.api.config.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;


import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.CommonConstants;
import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.base.dao.HydroDao;
import com.hydro.api.config.Config;
import com.hydro.api.config.FormulaMaster;
import com.hydro.api.config.MData;
import com.hydro.api.config.ProductMaster;
import com.hydro.api.config.UData;
import com.hydro.api.config.UnitMaster;
import com.hydro.api.config.MachineMaster;
import com.hydro.api.config.WaterMaster;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.exception.SystemException;

public class ConfigDaoImpl extends HydroDao implements ConfigDao {
	
	private static final Logger log = LoggerFactory.getLogger(ConfigDaoImpl.class);

	@Override
	public int createFileMaster(String siteId, Config config, String fileId, String deviceId) throws Exception {

		String query = SQLConstants.CONFIG_INSERT_FILE_MASTER;
		LinkedList<Object> params = new LinkedList<>();
		params.add(fileId);
		params.add(fileId);
		params.add("Backend System");
		params.add(Constants.FILE_THREE);
		params.add("Streamed from Device:" + deviceId);
		params.add(siteId);
		params.add(config.toString());
		params.add(Constants.FILE_FOUR);
		params.add(deviceId);
		params.add(Constants.FILE_NEWLY_CREATED_STATUS);
		return executeDBQuery(query, params);
	}

	@Override
	public int createFormulaMaster(FormulaMaster formulaMaster, String equipId) throws Exception {

		String query = SQLConstants.CONFIG_INSERT_FORMULA_MASTER;
	
		LinkedList<Object> params = new LinkedList<>();
		String guid = CommonUtils.guidGenerator(null, null);
		String formulaId = formulaMaster.getUid() + "_" + guid + "";
		params.add(formulaId);
		params.add(equipId);
		params.add(formulaMaster.getLm2_seq());
		params.add(formulaMaster.getName());
		params.add(formulaMaster.getPhases());
		params.add(formulaMaster.getUid());

		return executeDBQuery(query, params);

	}

	

	@Override
	public int createProductMaster(ProductMaster productMaster, String equipId) throws Exception {

		String query = SQLConstants.CONFIG_INSERT_PRODUCT_MASTER;
		
		LinkedList<Object> params = new LinkedList<>();
		String guid = CommonUtils.guidGenerator(null, null);
		String productId = productMaster.getUid() + "_" + guid + "";
		params.add(productId);
		params.add(equipId);
		params.add(productMaster.getLm2_seq());
		params.add(productMaster.getName());
		params.add(productMaster.getDensity());
		params.add(productMaster.getConcentration());
		params.add(productMaster.getKf());
		params.add(productMaster.getFlow());
		params.add(productMaster.getDocification_mode());
		params.add(productMaster.getPriority());
		params.add(productMaster.getAlarms_ignored());
		params.add(productMaster.getPrice());
		params.add(productMaster.getUid());
		return executeDBQuery(query, params);
	}

	@Override
	public int createWasherOrTunnelMaster(MachineMaster machineMaster, String equipId, int equipmentType) throws Exception {
		String query = null;
		if (equipmentType == 0) {
			query = SQLConstants.CONFIG_INSERT_TUNNEL_MASTER;
		} else {
			query = SQLConstants.CONFIG_INSERT_WASHER_MASTER;
		}
		LinkedList<Object> params = new LinkedList<>();
		String guid = CommonUtils.guidGenerator(null, null);
		String washerId = machineMaster.getUid() + "_" + guid + "";
		params.add(washerId);
		params.add(equipId);
		params.add(machineMaster.getLm2_seq());
		params.add(machineMaster.getName());
		params.add(machineMaster.getLoad());
		params.add(machineMaster.getId_formula());
		params.add(machineMaster.getUid());
		return executeDBQuery(query, params);
	}

	@Override
	public int createWaterMaster(WaterMaster waterMaster, String equipId) throws Exception {
		String query = SQLConstants.CONFIG_INSERT_WATER_MASTER;
		
		LinkedList<Object> params = new LinkedList<>();
		String guid = CommonUtils.guidGenerator(null, null);
		String waterId = waterMaster.getUid() + "_" + guid + "";
		params.add(waterId);
		params.add(equipId);
		params.add(waterMaster.getLm2_seq());
		params.add(waterMaster.getKf());
		params.add(waterMaster.getFlow());
		params.add(waterMaster.getUid());
		return executeDBQuery(query, params);
	}

	@Override
	public int updateSiteMaster(String fileId, String siteId) throws Exception {

		String query = SQLConstants.CONFIG_UPDATE_SITE_MASTER;

		LinkedList<Object> params = new LinkedList<>();
		params.add(fileId);
		params.add(siteId);

		return executeDBQuery(query, params);
	}

	@Override
	public int createEquipmentMaster(UnitMaster unitMaster, String equipId, String siteId, String fileId,String deviceId) throws Exception {

		String query = SQLConstants.CONFIG_INSERT_EQUIPMENT_MASTER;

		LinkedList<Object> params = new LinkedList<>();

		params.add(equipId);
		params.add(siteId);
		params.add(fileId);
		params.add(unitMaster.getEquipment_type());
		params.add(unitMaster.getAlias());
		params.add(unitMaster.getVersion());
		params.add(unitMaster.getIp_address());
		params.add(unitMaster.getWasher_count());
		params.add(unitMaster.getW_machine_chnl_count());
		params.add(unitMaster.getLm2_seq());
		params.add(deviceId);
		return executeDBQuery(query, params);

	}
	
	private int executeDBQuery(String query, LinkedList<Object> params) throws Exception, SystemException {
		int count = 0;
		Database database = null;
		log.debug(CommonConstants.QUERY, query);
		try {
			database = new Database();

			count = database.executeUpdate(query, params);
			if (count <= 0) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
						ErrorCodes.StatusCodes.FAILURE, null);
			}

		} catch (SystemException e) {
			log.error(CommonConstants.ERROR, e.getMessage());
			throw e;
		} catch (SQLException e) {
			log.error(CommonConstants.ERROR, e.getMessage());
			try {
				log.error(e.getMessage());
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
						ErrorCodes.StatusCodes.FAILURE, null);

			} catch (SQLException e1) {
				log.error(CommonConstants.ERROR, e1.getMessage());
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
						ErrorCodes.StatusCodes.FAILURE, null);
			}
		} catch (Exception e) {
			log.error(CommonConstants.STACK_TRACE, ExceptionUtils.getFullStackTrace(e));
			throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
					ErrorCodes.StatusCodes.FAILURE, null);
		} finally {
			try {
				if (database != null) {
					database.closeConnection();
				}
			} catch (Exception e) {
				log.error(CommonConstants.STACK_TRACE, ExceptionUtils.getFullStackTrace(e));
			}
		}

		return count;

	}

	@Override
	public String getSiteId(String siteName) throws Exception {
		String query = SQLConstants.CONFIG_GET_SITE_ID;
		Database database = null;
		LinkedList<Object> params = new LinkedList<>();
		params.add(siteName);
		String siteId = null;
		try {
			database = new Database();
			ResultSet rs = database.executeQuery(query, params);
			if (rs.next()) {
				siteId = rs.getString("site_id");
			}
		} catch (Exception e) {
			handleException(e);
		} finally {
			closeDbConnection(database);
		}
		return siteId;
	}
	
}