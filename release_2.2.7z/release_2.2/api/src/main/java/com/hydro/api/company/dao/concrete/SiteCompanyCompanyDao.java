package com.hydro.api.company.dao.concrete;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.CompanyDTO;
import com.hydro.api.dto.CompanyListResponseDTO;
import com.hydro.api.dto.ContactDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;

public class SiteCompanyCompanyDao extends CompanyCompanyDao {
    private static final Logger LOG = LoggerFactory.getLogger(PartialCompanyCompanyDao.class);

    @Override
    public CompanyListResponseDTO getCompanyList(UserDTO user, CompanyDTO company) throws Exception {
	Database database = null;
	try {
	    database = new Database();
	    String query = SQLConstants.Company.GET_COMPANY_LIST;
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.BusinessTypes.COMPANY);
	    params.add(user.getAssociationId());
	    if (company.getCreatedDateStart() != null && company.getCreatedDateEnd() != null) {
		query = SQLConstants.Company.GET_COMPANY_LIST_CREATED_DATE_FILTER;
		LOG.debug("query>>>>" + query);
		params.addAll(getCompanyListOnStartEndDate(company));
	    } else if (company.isSortByName()) {
		query = SQLConstants.Company.GET_COMPANY_LIST_SORTED_ON_NAME;
	    }
	    return getCompanyListData(database.executeQuery(query, params), user.getTimeZone());
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean hasVisibility(UserDTO user, CompanyDTO company) throws Exception {
	if (user.getAssociationId().equals(company.getCompanyId())) {
	    return true;
	}
	return false;
    }

    @Override
    public CompanyDTO createCompany(UserDTO user, CompanyDTO company) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    @Override
    public boolean updateCompany(UserDTO user, CompanyDTO company) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    @Override
    public List<SiteDTO> getSiteList(UserDTO user) throws Exception {
	CompanyDTO company = new CompanyDTO();
	company.setCompanyId(user.getAssociationId());
	return super.getSiteListForCompany(company);
    }

    @Override
    public List<ContactDTO> getContactListForCompany(UserDTO user, CompanyDTO company) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

}
