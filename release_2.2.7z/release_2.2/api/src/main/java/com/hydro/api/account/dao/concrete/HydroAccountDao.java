package com.hydro.api.account.dao.concrete;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.account.dao.AccountDao;
import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.AccountDTO;
import com.hydro.api.dto.AccountListResponseDTO;
import com.hydro.api.dto.ContactDTO;
import com.hydro.api.dto.ContactOperationsDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;

/**
 *
 * @author Shreyas
 * 
 */
public class HydroAccountDao extends AccountDao {
    private static final Logger LOG = LoggerFactory.getLogger(HydroAccountDao.class);

    @Override
    public AccountListResponseDTO getAccountList(UserDTO user, AccountDTO account) throws SystemException, Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_ACCOUNT_LIST;
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.BusinessTypes.ACCOUNT);
	    if (account.getCreatedDateStart() != null && account.getCreatedDateEnd() != null) {
		query = SQLConstants.HydroAdmin.GET_ACCOUNT_LIST_CREATED_DATE_FILTER;
		params.addAll(getAccountListOnStartEndDate(account));
	    } else if (account.isSortByName()) {
		query = SQLConstants.HydroAdmin.GET_ACCOUNT_LIST_SORTED_ON_NAME;
	    }
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    return getAccountListData(database.executeQuery(query, params), user.getTimeZone());
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error("DB Error : " + e.getMessage());
		LOG.error(e.getMessage());
		throw new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));

	    }
	}
    }

    //
    // @Override
    // public AccountDTO getAccountDetails(String accountId) throws Exception {
    // // TODO Auto-generated method stub
    // return null;
    // }
    /**
     * Returning True As the Hydro Admin has visibility to all the resources.
     */
    @Override
    public boolean hasVisibility(UserDTO user, AccountDTO accountDTO) throws Exception {
	return true;
    }

    @Override
    public List<SiteDTO> getSiteListForAccount(UserDTO user, AccountDTO accountDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_SITES_FOR_ACCOUNT;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(accountDTO.getAccountId());
	    database = new Database();
	    return getAccountSiteData(database.executeQuery(query, params));
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public AccountDTO createAccount(UserDTO user, AccountDTO accountDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.CREATE_ACCOUNT;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    String guid = CommonUtils.guidGenerator(null, null);
	    // INSERT INTO BUSINESS_MASTER (`business_id`, `name`,
	    // `business_type`,
	    // `address1`, `address2`, `created_by`, `modified_by`,
	    // `state`,country,`city`, `zipcode`, `description`) VALUES (?, ?,
	    // ?, ?, ?, ?, ?, ?, ?, ?, ?,?)
	    params.add(guid);
	    params.add(accountDTO.getName());
	    params.add(Constants.BusinessTypes.ACCOUNT);
	    params.add(accountDTO.getAddress1());
	    params.add(accountDTO.getAddress2());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(accountDTO.getState());
	    params.add(accountDTO.getCountry());
	    params.add(accountDTO.getCity());
	    params.add(accountDTO.getZipCode());
	    params.add(accountDTO.getDescription());
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    if (count > 0) {
		AccountDTO account = new AccountDTO();
		account.setAccountId(guid);
		ContactOperationsDTO contactOperations = accountDTO.getContactOperations();
		if (contactOperations != null && contactOperations.getCreateContact() != null
			&& contactOperations.getCreateContact().size() > 0) {
		    List<ContactDTO> contactCreate = contactOperations.getCreateContact();

		    query = SQLConstants.HydroAdmin.CREATE_CONTACT_INFO;
		    LOG.debug("query>>>>" + query);

		    // INSERT INTO
		    // CONTACT_MASTER(contact_id,business_id,
		    // site_id,email,name, number, title,created_by,
		    // modified_by) values(?,?,?,?,?,?,?,?,?)
		    params = new LinkedList<>();
		    database.createBatch(query);
		    for (ContactDTO contactDTO : contactCreate) {
			String uuid = CommonUtils.guidGenerator(null, null);
			params = new LinkedList<>();
			params.add(uuid);
			params.add(guid);
			params.add(null);
			params.add(contactDTO.getEmail());
			params.add(contactDTO.getName());
			params.add(contactDTO.getNumber());
			params.add(contactDTO.getTitle());
			params.add(user.getFirstName() + " " + user.getLastName());
			params.add(user.getFirstName() + " " + user.getLastName());
			database.addBatch(query, params);
		    }
		    int[] result = database.executeBatch();
		    if (result != null && result.length > 0) {
			for (int i = 0; i < result.length; i++) {
			    if (result[i] != 1) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }
			}

		    }
		}
		database.commit();
		return account;
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (SystemException e) {
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean updateAccount(UserDTO user, AccountDTO accountDTO) throws Exception {
	Database database = null;
	try {
	    // UPDATE BUSINESS_MASTER set name=?, address1=?,address2=?,
	    // modified_by=? ,
	    // state=?,country=?,city=? , zipcode=?,
	    // description=?, contact_title=?,contact_name=?, contact_number=?,
	    // contact_email=? where business_id=?

	    String query = SQLConstants.HydroAdmin.UPDATE_BUSINESS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(accountDTO.getName());
	    params.add(accountDTO.getAddress1());
	    params.add(accountDTO.getAddress2());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(accountDTO.getState());
	    params.add(accountDTO.getCountry());
	    params.add(accountDTO.getCity());
	    params.add(accountDTO.getZipCode());
	    params.add(accountDTO.getDescription());
	    params.add(accountDTO.getAccountId());
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    if (count > 0) {
		ContactOperationsDTO contactOperations = accountDTO.getContactOperations();
		if (contactOperations != null) {
		    HashSet<String> contactIdList = null;
		    List<ContactDTO> contactUpdate = contactOperations.getUpdateContact();
		    if (contactUpdate != null && contactUpdate.size() > 0) {
			contactIdList = AccountDao.getContactAssociatedToAccount(accountDTO);
			for (ContactDTO contact : contactUpdate) {
			    if (!contactIdList.contains(contact.getContactId())) {
				throw new SystemException(ErrorCodes.INVALID_CONTACT_ID,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
					null);
			    }
			    query = SQLConstants.HydroAdmin.UPDATE_CONTACT_INFO;
			    LOG.debug("query>>>>" + query);
			    params = new LinkedList<>();
			    database.createBatch(query);

			    for (ContactDTO contactDTO : contactUpdate) {
				// UPDATE CONTACT_MASTER SET contact_email =?,
				// contact_name=?, contact_number = ?,
				// contact_title =
				// ?, modified_by =? WHERE contact_id=?
				params = new LinkedList<>();
				params.add(contactDTO.getEmail());
				params.add(contactDTO.getName());
				params.add(contactDTO.getNumber());
				params.add(contactDTO.getTitle());
				params.add(user.getFirstName() + " " + user.getLastName());
				params.add(contactDTO.getContactId());
				database.addBatch(query, params);
			    }
			    int[] result = database.executeBatch();
			    if (result != null && result.length > 0) {
				for (int i = 0; i < result.length; i++) {
				    if (result[i] != 1) {
					throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
						ConfigReader.getObject().getErrorConfig(),
						ErrorCodes.StatusCodes.FAILURE, null);
				    }
				}
			    }
			}
		    }
		    // Check if contactId is associated to site.
		    List<ContactDTO> contactDelete = contactOperations.getDeleteContact();
		    if (contactDelete != null && contactDelete.size() > 0) {

			if (contactIdList == null) {
			    contactIdList = AccountDao.getContactAssociatedToAccount(accountDTO);
			}
			for (ContactDTO contact : contactDelete) {
			    if (!contactIdList.contains(contact.getContactId())) {
				throw new SystemException(ErrorCodes.INVALID_CONTACT_ID,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
					null);
			    }
			    params = new LinkedList<>();
			    query = SQLConstants.HydroAdmin.DELETE_CONTACT_INFO + " ( "
				    + CommonUtils.generateQueryParams(contactDelete.size()) + " )";
			    LOG.debug("query>>>>" + query);
			    for (ContactDTO contactDTO : contactDelete) {
				params.add(contactDTO.getContactId());
			    }

			    int countDelete = database.executeUpdate(query, params);
			    if (countDelete < 0) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }

			}
		    }

		    // Inserting new Contact Details.

		    if (contactOperations.getCreateContact() != null
			    && contactOperations.getCreateContact().size() > 0) {
			List<ContactDTO> contactCreate = contactOperations.getCreateContact();
			query = SQLConstants.HydroAdmin.CREATE_CONTACT_INFO;
			LOG.debug("query>>>>" + query);

			// INSERT INTO
			// CONTACT_MASTER(contact_id,business_id,
			// site_id,email,name, number, title,created_by,
			// modified_by) values(?,?,?,?,?,?,?,?,?)
			params = new LinkedList<>();
			database.createBatch(query);
			for (ContactDTO contactDTO : contactCreate) {
			    String uuid = CommonUtils.guidGenerator(null, null);
			    params = new LinkedList<>();
			    params.add(uuid);
			    params.add(accountDTO.getAccountId());
			    params.add(null);
			    params.add(contactDTO.getEmail());
			    params.add(contactDTO.getName());
			    params.add(contactDTO.getNumber());
			    params.add(contactDTO.getTitle());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    database.addBatch(query, params);
			}
			int[] result = database.executeBatch();
			if (result != null && result.length > 0) {
			    for (int i = 0; i < result.length; i++) {
				if (result[i] != 1) {
				    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					    null);
				}
			    }
			}
		    }
		}
	    }
	    database.commit();
	    return true;

	} catch (SystemException e) {
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public String accountNameExists(AccountDTO accountDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.BUSINESS_NAME_EXISTS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();

	    params.add(Constants.BusinessTypes.ACCOUNT);
	    params.add(accountDTO.getName().toLowerCase());
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.BUSINESS_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }

    @Override
    public List<ContactDTO> getContactListForAccount(AccountDTO account) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_CONTACT_LIST_FOR_BUSINESS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(account.getAccountId());
	    database = new Database();
	    return getAccountContactData(database.executeQuery(query, params));
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }
}
