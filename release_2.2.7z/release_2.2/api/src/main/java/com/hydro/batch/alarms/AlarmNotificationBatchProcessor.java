package com.hydro.batch.alarms;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.event.business.HydroEventBL;
import com.hydro.api.exception.SystemException;

@DisallowConcurrentExecution
public class AlarmNotificationBatchProcessor implements Job {
    // Logger log = Logger.getLogger(MailSenderJob.class);
    private static final Logger LOG = LoggerFactory.getLogger(AlarmNotificationBatchProcessor.class);

    @Override
    public void execute(JobExecutionContext pArg0) throws JobExecutionException {
	try {

	    HydroEventBL eventBl = new HydroEventBL();
	    eventBl.getMachineIdleNotification();

	} catch (SystemException e1) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
	} catch (InterruptedException e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	} catch (Exception e1) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
	}
    }
}
