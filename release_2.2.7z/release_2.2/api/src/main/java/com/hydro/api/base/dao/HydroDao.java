package com.hydro.api.base.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.CommonConstants;
import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.RoleDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.dto.UserListResponseDTO;
import com.hydro.api.exception.SystemException;

/**
 *
 * @author Shreyas
 * 
 */
public class HydroDao {
    private static final Logger LOG = LoggerFactory.getLogger(HydroDao.class);

    public boolean testDbConnection() {
	Database database = null;
	try {
	    database = new Database();

	    if (database.connection != null) {
		return true;
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    return false;
	} finally {
	    if (database != null) {
		try {
		    database.closeConnection();
		} catch (SQLException e) {
		    LOG.error("Error : " + e.getMessage());
		    e.printStackTrace();
		}
	    }
	}
	return false;
    }

    public UserDTO getUserDetails(UserDTO user) throws SystemException, Exception {

	Database database = null;
	try {
	    String query = SQLConstants.GET_USER_DETAILS;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    LOG.debug("query>>>>" + query);
	    params.add(user.getUserId());
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return getUserListData(rs, user.getTimeZone());
	    }
	    LOG.info("User with User ID" + user.getUserId() + " Doesn't exist in Database.");
	    return null;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    }

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public HashMap<String, Set<String>> getPermissionList() {
	Database database = null;
	HashMap<String, Set<String>> rolePermissionMap = new HashMap<>();
	try {
	    String query = SQLConstants.Company.partial.GET_PERMISSION_LIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    while (rs.next()) {
		String privilegeName = rs.getString(SQLColumns.PRIVILEGE_NAME);
		String roleId = rs.getString(SQLColumns.ROLE_ID);
		if (!rolePermissionMap.containsKey(roleId)) {
		    Set<String> permission = new HashSet<>();
		    permission.add(privilegeName);
		    rolePermissionMap.put(roleId, permission);
		}
		rolePermissionMap.get(roleId).add(privilegeName);
	    }
	    return rolePermissionMap;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());

	} catch (SQLException e) {

	    LOG.error(e.getMessage());

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));

	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
	return rolePermissionMap;
    }

    protected UserListResponseDTO getUserListFromRs(ResultSet rs, String timeZone) throws SQLException {
	UserListResponseDTO response = new UserListResponseDTO();
	List<UserDTO> userList = new LinkedList<>();
	while (rs.next()) {
	    UserDTO user = getUserListData(rs, timeZone);
	    userList.add(user);
	}
	response.setUserList(userList);
	return response;
    }

    protected UserDTO getUserListData(ResultSet rs, String timeZone) throws SQLException {
	UserDTO user = new UserDTO();
	user.setUserId(rs.getString(SQLColumns.USER_ID));
	user.setFirstName(rs.getString(SQLColumns.FIRST_NAME));
	user.setMiddleName(rs.getString(SQLColumns.MIDDLE_NAME));
	user.setLastName(rs.getString(SQLColumns.LAST_NAME));
	user.setUserName(rs.getString(SQLColumns.USER_NAME));
	user.setEmail(rs.getString(SQLColumns.EMAIL));
	user.setPhoneNumber(rs.getString(SQLColumns.PHONE_NUMBER));
	user.setUserRole(rs.getString(SQLColumns.USER_ROLE));
	user.setTimeZone(timeZone);
	String businessId = rs.getString(SQLColumns.BUSINESS_ID);
	String siteId = rs.getString(SQLColumns.SITE_ID);
	String associationId = (StringUtils.isEmpty(businessId)) ? siteId : businessId;
	user.setAssociationId(associationId);
	String isActive = rs.getString(SQLColumns.IS_ACTIVE);
	user.setActive("1".equalsIgnoreCase(isActive) ? true : false);
	user.setAssociationName(rs.getString(SQLColumns.NAME));
	user.setCreatedDate(CommonUtils.convertDate(rs.getString(SQLColumns.CREATED_DATE), timeZone));
	user.setCreatedBy(rs.getString(SQLColumns.CREATED_BY));
	user.setOrgType(rs.getString(SQLColumns.ORG_TYPE));
	user.setAddress1(rs.getString(SQLColumns.ADDRESS1));
	user.setAddress2(rs.getString(SQLColumns.ADDRESS2));
	user.setState(rs.getString(SQLColumns.STATE));
	user.setCountry(rs.getString(SQLColumns.COUNTRY));
	user.setCity(rs.getString(SQLColumns.CITY));
	user.setZipCode(rs.getString(SQLColumns.ZIPCODE));
	user.setClearanceLevel(rs.getInt(SQLColumns.CLEARENCE_LEVEL));
	return user;
    }

    public HashMap<String, List<RoleDTO>> getRoles() {
	Database database = null;
	// HashMap<String, String> roleMap = new LinkedHashMap<>();
	HashMap<String, List<RoleDTO>> roleMap = new HashMap<>();
	try {
	    HashMap<String, Set<String>> rolePermission = getPermissionList();
	    String query = SQLConstants.GET_ROLES;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);

	    while (rs.next()) {
		RoleDTO role = new RoleDTO();
		role.setUserRole(rs.getString(SQLColumns.USER_ROLE));
		String roleId = rs.getString(SQLColumns.ROLE_ID);
		role.setRoleId(roleId);
		role.setClearanceLevel(rs.getInt(SQLColumns.CLEARENCE_LEVEL));
		String orgType = rs.getString(SQLColumns.ORG_TYPE);
		role.setOrgType(orgType);
		role.setPermissions(rolePermission.get(roleId));
		List<RoleDTO> roleList;
		if (!roleMap.containsKey(orgType)) {
		    roleList = new LinkedList<>();
		    roleMap.put(orgType, roleList);
		}
		roleList = roleMap.get(orgType);
		roleList.add(role);
		roleMap.put(orgType, roleList);
	    }

	} catch (SystemException e) {
	    LOG.error(e.getMessage());

	} catch (SQLException e) {
	    LOG.error(e.getMessage());

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
	return roleMap;
    }

    public void updateFileStatus() {

	Database database = null;
	try {
	    String query = SQLConstants.UPDATE_FILE_STATUS_FAILURE;
	    // update FILE_MASTER set status=?, description=?,
	    // detailed_description=?, modified_date = utc_timestamp where
	    // status in (?,?,?)
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.FAILURE));
	    String errorMessage = Constants.SERVER_STARTUP_FAILURE;
	    params.add(errorMessage);
	    params.add(errorMessage);
	    params.add(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.UPLOADING));
	    params.add(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.UPLOADED));
	    params.add(Constants.FileStatus.fileStatusConstants.get(Constants.FileStatus.PROCESSING));
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    LOG.info(count + " Number of pending processes updated to failed");
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    protected List<SiteDTO> getSiteDataForCompany(ResultSet rs) throws SQLException {
	List<SiteDTO> siteList = new LinkedList<>();
	while (rs.next()) {
	    SiteDTO siteDTO = new SiteDTO();
	    siteDTO.setSiteId(rs.getString(SQLColumns.SITE_ID));
	    siteDTO.setSiteName(rs.getString(SQLColumns.SITE_NAME));
	    siteList.add(siteDTO);
	}
	return siteList;
    }

	public void handleException(Exception e) throws Exception {
		if (e instanceof SystemException) {
			LOG.error(e.getMessage());
			throw e;
		} else if (e instanceof SQLException) {
			try {
				LOG.error(CommonConstants.ERROR, e.getMessage());
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
						ErrorCodes.StatusCodes.FAILURE, null);

			} catch (SQLException e1) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
						ErrorCodes.StatusCodes.FAILURE, null);

			}
		} else {
			LOG.error(CommonConstants.STACK_TRACE, ExceptionUtils.getFullStackTrace(e));
			throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
					ErrorCodes.StatusCodes.FAILURE, null);
		}

	}

	public void handleSQLException(Exception e) throws Exception {

		if (e instanceof SQLException) {
			try {
				LOG.error(CommonConstants.ERROR, e.getMessage());
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
						ErrorCodes.StatusCodes.FAILURE, null);

			} catch (SQLException e1) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
						ErrorCodes.StatusCodes.FAILURE, null);

			}
		} else if (e instanceof SystemException) {
			LOG.error(CommonConstants.ERROR, e.getMessage());
			throw e;

		}
	}

	public void closeDbConnection(Database database) {
		try {
			if (database != null) {
				database.closeConnection();
			}
		} catch (Exception e) {
			LOG.error(CommonConstants.STACK_TRACE, ExceptionUtils.getFullStackTrace(e));
		}
	}
    
}
