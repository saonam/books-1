package com.hydro.api.base.common;

import java.util.HashSet;
import java.util.Set;

/**
 * Object responsible for holding Elastic search connection details
 * 
 * @author Shreyas K C
 * 
 */
public class ESConfig {
    private int retryCount;
    private int maxEsConnTimeout;
    private int maxEsReadTimeout;
    private int maxEsConnections;
    private Set<String> esClusterJestUrl = new HashSet<String>();

    public ESConfig(String esClusterJestURL, String port, int maxEsConnTimeOut, int maxESReadTimeout,
	    int maxEsConnections, String esProtocol) {
	this.esClusterJestUrl.add(esProtocol + "://" + esClusterJestURL + ":" + port);
	this.retryCount = esClusterJestUrl.size();
	this.maxEsConnTimeout = maxEsConnTimeOut;
	this.maxEsReadTimeout = maxESReadTimeout;
	this.maxEsConnections = maxEsConnections;
    }

    /**
     * @return the retryCount
     */
    public int getRetryCount() {
	return retryCount;
    }

    /**
     * @return the maxEsConnTimeout
     */
    public int getMaxEsConnTimeout() {
	return maxEsConnTimeout;
    }

    /**
     * @return the maxEsReadTimeout
     */
    public int getMaxEsReadTimeout() {
	return maxEsReadTimeout;
    }


    /**
     * @return the maxEsConnections
     */
    public int getMaxEsConnections() {
        return maxEsConnections;
    }

    public void setMaxEsConnections(int maxEsConnections) {
        this.maxEsConnections = maxEsConnections;
    }

    /**
     * @return the esClusterJestUrl
     */
    public Set<String> getEsClusterJestUrl() {
	return esClusterJestUrl;
    }

}
