package com.hydro.api.base.common;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.math3.util.Precision;
import org.joda.time.Interval;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.hydro.api.base.dao.ElasticSearchDAO;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.BatchDTO;
import com.hydro.api.dto.DailyReportProductDTO;
import com.hydro.api.dto.DailyReportTunnelDTO;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.ShiftDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.TunnelDTO;
import com.hydro.api.dto.WasherMetaDataDTO;
import com.hydro.api.dto.reports.CycleDTO;
import com.hydro.api.dto.reports.DailyReportFormulaDTO;
import com.hydro.api.dto.reports.DailyReportRequestDTO;
import com.hydro.api.dto.reports.DailyReportResponseDTO;
import com.hydro.api.dto.reports.DailyReportWasherDTO;
import com.hydro.api.dto.reports.EventsDTO;
import com.hydro.api.dto.reports.ModuleDTO;
import com.hydro.api.dto.reports.PhaseDTO;
import com.hydro.api.dto.reports.RealTimeAlarmDTO;
import com.hydro.api.dto.reports.TransferDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.site.dao.SiteDao;

public class DailyReportUtils {

    private static final Logger LOG = LoggerFactory.getLogger(ReportUtils.class);
    static ConfigReader config = new ConfigReader();

    public void setMachineEfficiency(Map<Integer, DailyReportWasherDTO> washerHashMap, String startShift,
	    String endShift, long currentTime) {
	washerHashMap.forEach((washerKey, washer) -> {
	    if (washer != null) {
		long activeCycleTime = 0;
		for (Integer key : washer.getCycleHashMap().keySet()) {
		    CycleDTO cycle = washer.getCycleHashMap().get(key);
		    if (cycle != null)
			activeCycleTime = activeCycleTime + ReportUtils.getCycleActiveTimeInShift(
				cycle.getStartCycleTime(), cycle.getEndCycleTime(), startShift, endShift, currentTime);
		}
		Double timeElapsedInShift = null;
		try {
		    timeElapsedInShift = getTimeElapsedInShift(currentTime, startShift, endShift);
		    if (timeElapsedInShift != null && timeElapsedInShift != 0) {
			Double efficiency = ((activeCycleTime / timeElapsedInShift) * 100);
			washer.setTotalCycleActiveTime(activeCycleTime);
			washer.setTimeElapsedInShift(timeElapsedInShift);
			washer.setEfficiency(Precision.round(efficiency, 2));
		    }
		} catch (Exception e) {
		    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		}

	    }
	});
    }

    public void setEfficiencyAndTurnTime(List<ShiftDTO> shiftList, ShiftDTO masterShift) {

	masterShift.getWasherHashMap().forEach((washerKey, washer) -> {
	    // set total no. of loads for each washer.
	    Map<Integer, CycleDTO> cycleHashMap = washer.getCycleHashMap();
	    if (cycleHashMap != null && !cycleHashMap.isEmpty())
		washer.setLoads(washer.getCycleHashMap().size());
	    // calculation for efficiency and turn time.
	    long totalTurnTime = 0;
	    long totalTurnTimeCount = 0;
	    double totalTimeElaspsed = 0;
	    long totalCycleActiveTime = 0;
	    for (ShiftDTO shift : shiftList) {
		DailyReportWasherDTO washerDTO = shift.getWasherHashMap().get(washerKey);
		if (washerDTO.getTimeElapsedInShift() != null) {
		    totalTimeElaspsed = totalTimeElaspsed + washerDTO.getTimeElapsedInShift();
		    totalCycleActiveTime = totalCycleActiveTime + washerDTO.getTotalCycleActiveTime();
		}
		totalTurnTime = totalTurnTime + washerDTO.getTotalTurnTime();
		totalTurnTimeCount = totalTurnTimeCount + washerDTO.getTotalTurnTimeCount();
	    }

	    if (totalTimeElaspsed != 0) {
		Double efficiency = ((totalCycleActiveTime / totalTimeElaspsed) * 100);
		washer.setEfficiency(Precision.round(efficiency, 2));
	    }

	    if (totalTurnTimeCount != 0) {
		washer.setAverageTurnTime(CommonUtils.convertLongToStringTime(totalTurnTime / totalTurnTimeCount));
	    }
	});

    }

    public void setWasherTurnTime(Map<Integer, DailyReportWasherDTO> washerHashMap, String startShift, String endShift,
	    SiteDTO site, long currentTime) {
	washerHashMap.forEach((washerKey, washer) -> {
	    if (washer != null) {
		long turnTime = 0;
		long turnCount = 0;
		int startCycleCount = 0;
		int lastCycleCount = 0;
		Integer previous = null;
		Map<Integer, CycleDTO> cycleHashMap = washer.getCycleHashMap();
		if (cycleHashMap != null && !cycleHashMap.isEmpty()) {
		    Set<Integer> cycleIterator = cycleHashMap.keySet();
		    Iterator<Integer> keySetIterator = cycleIterator.iterator();
		    CycleDTO firstCycle = cycleHashMap.get(washer.getFirstCycleKey());
		    CycleDTO lastCycle = cycleHashMap.get(washer.getLastCycleKey());
		    while (keySetIterator.hasNext()) {
			CycleDTO prevCycle;
			CycleDTO nextCycle = null;
			if (previous != null)
			    prevCycle = cycleHashMap.get(previous);
			else
			    prevCycle = cycleHashMap.get(keySetIterator.next());
			if (keySetIterator.hasNext())
			    previous = keySetIterator.next();
			if (previous != null)
			    nextCycle = cycleHashMap.get(previous);

			try {
			    // check if first cycle startTime is less than shift
			    // time
			    if (firstCycle != null && CommonUtils.convertStringToLongDateTime(startShift) < firstCycle
				    .getStartCycleTime().getTime() && startCycleCount == 0) {
				turnTime = turnTime + (firstCycle.getStartCycleTime().getTime()
					- CommonUtils.convertStringToLongDateTime(startShift));

				startCycleCount++;
				turnCount++;
			    }

			    // check if last cycle endTime is less than shift
			    // time
			    if (lastCycle != null
				    && lastCycle.getEndCycleTime() != null && lastCycle.getEndCycleTime()
					    .getTime() < CommonUtils.convertStringToLongDateTime(endShift)
				    && lastCycleCount == 0) {
				if (currentTime < CommonUtils.convertStringToLongDateTime(endShift)) {
				    long lastCycleLong = lastCycle.getEndCycleTime().getTime();
				    // Since, there was slight time difference
				    // in
				    // system time and server time
				    // cycleActiveTime
				    // was coming -ve.
				    // Hence to avoid that check if
				    // lastCycleLong <
				    // currentTime
				    if (lastCycleLong < currentTime)
					turnTime = turnTime + (currentTime - lastCycleLong);
				} else {
				    turnTime = turnTime + (CommonUtils.convertStringToLongDateTime(endShift)
					    - lastCycle.getEndCycleTime().getTime());
				}

				lastCycleCount++;
				turnCount++;
			    }

			    // calculating turn time for cycle present within
			    // shift
			    if (prevCycle != null && nextCycle != null && nextCycle.getStartCycleTime() != null
				    && prevCycle.getEndCycleTime() != null) {
				turnTime = turnTime + (nextCycle.getStartCycleTime().getTime()
					- prevCycle.getEndCycleTime().getTime());
				turnCount++;
			    }

			} catch (Exception e) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			}
		    }
		} else {
		    try {
			turnTime = CommonUtils.convertStringToLongDateTime(endShift)
				- CommonUtils.convertStringToLongDateTime(startShift);
			washer.setTotalTurnTime(turnTime);
		    } catch (Exception e) {
			LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		    }

		}
		if (turnCount != 0) {
		    washer.setTotalTurnTimeCount(turnCount);
		    washer.setTotalTurnTime(turnTime);
		    washer.setAverageTurnTime(CommonUtils.convertLongToStringTime(turnTime / turnCount));
		}
	    }
	});

    }

    public void updateIdleTime(Map<Integer, DailyReportWasherDTO> washerMap, SiteDTO siteDTO, String shiftStart,
	    long currentTime) {
	washerMap.forEach((k, v) -> {
	    if (v != null) {
		LinkedHashMap<Integer, CycleDTO> sortedMap = new LinkedHashMap<Integer, CycleDTO>();
		v.getCycleHashMap().entrySet().stream()
			.sorted((entry1, entry2) -> entry1.getValue().getStartCycleTime()
				.compareTo(entry2.getValue().getStartCycleTime()))
			.forEachOrdered(x -> sortedMap.put(x.getKey(), x.getValue()));

		v.setCycleHashMap(sortedMap);
		if (v.getCycleHashMap() != null && !v.getCycleHashMap().isEmpty()) {
		    for (Integer cyclekey : v.getCycleHashMap().keySet()) {
			v.setLastCycleKey(cyclekey);
		    }
		    for (Integer cyclekey : v.getCycleHashMap().keySet()) {
			v.setFirstCycleKey(cyclekey);
			break;
		    }
		    v.setLoads(v.getCycleHashMap().size());
		    CycleDTO cycle = v.getCycleHashMap().get(v.getLastCycleKey());
		    try {
			Long lastCycleEndTimeString;
			if (cycle != null && cycle.getEndCycleTime() != null && cycle.isCycleCompleted()) {
			    lastCycleEndTimeString = cycle.getEndCycleTime().getTime();
			    // Since, there was slight time difference in system
			    // time and server time cycleActiveTime was coming
			    // -ve.
			    // Hence to avoid that check if
			    // lastCycleEndTimeString < currentTime
			    if (lastCycleEndTimeString < currentTime) {
				long idleTime = (currentTime - lastCycleEndTimeString);
				v.setIdleTime(CommonUtils.convertLongToStringTime(idleTime));
			    }
			}
		    } catch (Exception e) {
			LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		    }
		}
		if (v.getCycleHashMap() == null || v.getCycleHashMap().isEmpty()) {
		    try {
			long shiftStartLong = CommonUtils.convertStringToLongDateTime(shiftStart);
			// Since, there was slight time difference in system
			// time and server time cycleActiveTime was coming -ve.
			// Hence to avoid that check if shiftStartLong <
			// currentTime
			if (shiftStartLong < currentTime) {
			    v.setIdleTime(CommonUtils.convertLongToStringTime(currentTime - shiftStartLong));
			}
		    } catch (Exception e) {
			LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		    }
		}

	    }
	});
    }

    public void calculateChemicalDispensed(Map<Integer, DailyReportWasherDTO> washers) {
	if (MapUtils.isEmpty(washers)) {
	    return;
	}
	for (Map.Entry<Integer, DailyReportWasherDTO> washerEntry : washers.entrySet()) {
	    DailyReportWasherDTO washer = washerEntry.getValue();
	    if (washer == null || MapUtils.isEmpty(washer.getCycleHashMap())) {
		continue;
	    }
	    for (Map.Entry<Integer, CycleDTO> cycleEntry : washer.getCycleHashMap().entrySet()) {
		CycleDTO cycle = cycleEntry.getValue();
		if (cycle == null || cycle.getFormula() == null || MapUtils.isEmpty(cycle.getFormula().getPhaseMap())) {
		    continue;
		}
		cycle.setTotalMlActual(0d); // to avoid NullPointerException, since the default initialization would be
					    // null
		cycle.setTotalMlEstimated(0d); // to avoid NullPointerException, since the default initialization would
					       // be
					       // null
		for (Map.Entry<Integer, PhaseDTO> phaseEntry : cycle.getFormula().getPhaseMap().entrySet()) {
		    PhaseDTO phase = phaseEntry.getValue();
		    if (CollectionUtils.isEmpty(phase.getEventList())) {
			continue;
		    }
		    for (EventsDTO event : phase.getEventList()) {
			cycle.setTotalMlActual(cycle.getTotalMlActual() + event.getMl());
			cycle.setTotalMlEstimated(cycle.getTotalMlEstimated() + event.getMlEstimated());
		    }
		}
	    }
	}
    }

    public void calculateChemicalDispensed(DailyReportTunnelDTO tunnel) {
	if (tunnel == null) {
	    return;
	}
	for (Map.Entry<Integer, BatchDTO> batchEntry : tunnel.getBatchMap().entrySet()) {
	    BatchDTO batch = batchEntry.getValue();
	    if (batch == null || CollectionUtils.isEmpty(batch.getEventList())) {
		continue;
	    }
	    batch.setTotalMlActual(0d); // to avoid NullPointerException, since the default initialization would be null
	    batch.setTotalMlEstimated(0d); // to avoid NullPointerException, since the default initialization would be
					   // null
	    for (EventsDTO event : batch.getEventList()) {
		batch.setTotalMlActual(batch.getTotalMlActual() + event.getMl());
		batch.setTotalMlEstimated(batch.getTotalMlEstimated() + event.getMlEstimated());
	    }
	}
    }

    public CycleDTO createCycle(JsonObject event) throws Exception {
	List<Integer> validPhasesList;
	ConfigReader config = new ConfigReader();
	int totalPhases = 1;
	int cycleId = 0;
	int constantPhases = Integer.parseInt(config.getAppConfig(Constants.REPORTS.PHASE_CONSTANT));
	// Map<Integer, CycleDTO> cycleHashMap = new LinkedHashMap<>();
	Map<Integer, PhaseDTO> phHashMap = new HashMap<>();
	CycleDTO cycle = new CycleDTO();
	// cycleHashMap = washerDetails.getCycleHashMap();
	String cycleStartTime = event.get(Constants.REPORTS.DATE_TIME).getAsString();
	cycleId = event.get(Constants.REPORTS.PROCESS).getAsInt();
	cycle.setCycleId(cycleId);
	cycle.setLbs(event.get(Constants.REPORTS.KG_REALS).getAsInt());
	cycle.setFormulaCost(event.get(Constants.REPORTS.FORMULA_COST).getAsDouble());
	cycle.setStartCycleTime(ReportUtils.convertStringToDate(cycleStartTime));
	validPhasesList = ReportUtils.bitPositions(event.get(Constants.REPORTS.TOTAL_PHASES).getAsInt());
	DailyReportFormulaDTO formula = new DailyReportFormulaDTO();
	formula.setFormulaId(event.get(Constants.REPORTS.FORMULA).getAsInt());
	formula.setTotalPhases(constantPhases);
	formula.setFormulaName(event.get(Constants.REPORTS.FORMULA_NAME).getAsString());
	while (totalPhases <= constantPhases) {
	    PhaseDTO phase = new PhaseDTO();
	    phase.setActivePhase(false);
	    phase.setValidPhase(false);
	    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.YET_TO_START);
	    if (validPhasesList.contains(totalPhases))
		phase.setValidPhase(true);
	    phHashMap.put(totalPhases, phase);
	    totalPhases++;
	}
	formula.setPhaseMap(phHashMap);
	cycle.setFormula(formula);
	return cycle;
    }

    public CycleDTO incompleteCycleData(SiteDTO siteDTO, DailyReportRequestDTO requestDTO, int cycleVal,
	    String equipmentId, JsonObject event, Map<Integer, CycleDTO> cycleMapDetails, String startShift,
	    CycleDTO cycle, String timeZone) throws Exception {
	List<String> indexList = null;
	String query = ReportUtils.getQuery(Constants.REPORTS.CYCLE_DETAILS);
	if (StringUtils.isEmpty(query)) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}

	// Index and shift selection for real time report.
	JsonObject responseObjectForCycle = null;

	String fromDateTime = getShiftStartTime(startShift);
	String toDateTime = startShift;

	if (!requestDTO.isHistoricalReport()) {
	    List<String> dateList = new ArrayList<>(Arrays.asList(CommonUtils.getDateFromDateObject(fromDateTime),
		    CommonUtils.getDateFromDateObject(toDateTime)));
	    indexList = ReportUtils.getExistingDailyIndices(dateList, siteDTO);
	} else {
	    indexList = ReportUtils.getExistingIndices(CommonUtils.getDateFromDateObject(fromDateTime),
		    CommonUtils.getDateFromDateObject(toDateTime), siteDTO);
	}

	if (!fromDateTime.equals(toDateTime)) {
	    responseObjectForCycle = getCycleDetails(query, fromDateTime, toDateTime, equipmentId, event, indexList);
	    JsonObject firstHitsObjectForCycle = (JsonObject) responseObjectForCycle.get(Constants.REPORTS.HITS);
	    if (firstHitsObjectForCycle != null) {
		JsonArray jsonArrayCycle = ReportUtils.fieldsQuery(firstHitsObjectForCycle);
		// check if jsonArrayCycle contains
		// event_type 10

		if (jsonArrayCycle != null && jsonArrayCycle.size() != 0) {

		    for (int j = 0; j < jsonArrayCycle.size(); j++)
			try {
			    {
				LOG.debug("Processing event:: " + j);
				JsonObject cycleEvent = (JsonObject) jsonArrayCycle.get(j);
				cycle = createPhaseDetails(cycleVal, cycleMapDetails,
					cycleMapDetails.get(cycleVal).getCyclePreviousActivePhase(), cycleEvent,
					startShift);

			    }
			} catch (Exception e) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			}
		}
	    }
	}

	return cycle;

    }

    protected static JsonObject getCycleDetails(String query, String startTime, String endTime, String equipmentId,
	    JsonObject event, List<String> indexList) {
	ElasticSearchDAO esDAO = null;
	JsonObject responseObjectForCycle = null;
	try {
	    ConfigReader config = new ConfigReader();

	    query = query.replace(Constants.START_TIME, startTime);
	    query = query.replace(Constants.END_TIME, endTime);
	    String deviceId = SiteDao.getDeviceIdForEquipment(equipmentId);
	    if (deviceId == null) {
		throw new SystemException(ErrorCodes.DEVICE_DOES_NOT_EXIST, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    query = query.replace(Constants.DEVICE_ID_VAL, deviceId);
	    query = query.replace(Constants.CYCLE_ID, event.get(Constants.REPORTS.PROCESS).getAsString());
	    query = query.replace(Constants.MACHINE_ID, event.get(Constants.REPORTS.MACHINE_WASHER).getAsString());
	    esDAO = new ElasticSearchDAO(false, config.getEsConfig());
	    responseObjectForCycle = esDAO.executeQuery(query, indexList, config.getAppConfig(Constants.ES_TYPE));
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	if (esDAO != null)
	    esDAO.closeJestClient();
	return responseObjectForCycle;
    }

    public static CycleDTO createPhaseDetails(int cycleVal, Map<Integer, CycleDTO> cycleMapDetails,
	    int previousActivePhase, JsonObject cycleEvent, String startShift) throws Exception {
	ConfigReader config = new ConfigReader();
	CycleDTO cycle = cycleMapDetails.get(cycleVal);
	PhaseDTO phase = new PhaseDTO();
	DailyReportFormulaDTO formula = cycle.getFormula();
	Map<Integer, PhaseDTO> phaseMap = formula.getPhaseMap();
	// System.out.println("Formulae
	// phaseMap"+phaseMap);

	if (cycle.getCyclePreviousActivePhase() != null)
	    previousActivePhase = cycle.getCyclePreviousActivePhase();
	if (cycle != null) {
	    if (cycle.getCycleId() == cycleVal
		    && cycleEvent.get(Constants.REPORTS.EVENT_TYPE).toString()
			    .equals(config.getAppConfig(Constants.REPORTS.EVENT_TYPE_START_OF_CYCLE))
		    && cycle.getEndCycleTime() == null) {
		cycle.setStartCycleTime(
			ReportUtils.convertStringToDate(cycleEvent.get(Constants.REPORTS.DATE_TIME).getAsString()));
	    }
	    if (cycle.getCycleId() == cycleVal
		    && cycleEvent.get(Constants.REPORTS.EVENT_TYPE).toString()
			    .equals(config.getAppConfig(Constants.REPORTS.EVENT_TYPE_END_OF_CYCLE))
		    && cycleEvent.get(Constants.REPORTS.PHASE).toString()
			    .equals(config.getAppConfig(Constants.REPORTS.ZERO_PHASE))) {
		// alarmMap = new HashMap<>();
		Date cycleEndTime = ReportUtils
			.convertStringToDate(cycleEvent.get(Constants.REPORTS.DATE_TIME).getAsString());
		cycle.setEndCycleTime(cycleEndTime);
		phase = phaseMap.get(previousActivePhase);
		if (phase == null) {
		    phase = new PhaseDTO();
		    phaseMap.put(previousActivePhase, phase);
		    // System.out.println("phase is
		    // null");
		}
		phase.setPhaseStatus(ReportUtils.PHASE_STATUS.SUCCESSFUL);
		phase.setActivePhase(false);

	    }
	    // setting cycle active time, when end
	    // of
	    // cycle is not
	    // present

	    if (cycle.getEndCycleTime() == null) {
		if (!cycleEvent.get(Constants.REPORTS.PHASE)
			.equals(config.getAppConfig(Constants.REPORTS.ZERO_PHASE))) {
		    if (previousActivePhase != cycleEvent.get(Constants.REPORTS.PHASE).getAsInt()
			    && !cycleEvent.get(Constants.REPORTS.EVENT_TYPE).getAsString()
				    .equals(config.getAppConfig(Constants.REPORTS.MISSED_PHASE))) {
			if (previousActivePhase != 0) {
			    phase = phaseMap.get(previousActivePhase);
			    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.SUCCESSFUL);
			    phase.setActivePhase(false);
			}
			phase = phaseMap.get(cycleEvent.get(Constants.REPORTS.PHASE).getAsInt());
			if (phase != null) {
			    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.IN_PROGRESS);
			    phase.setActivePhase(true);
			}
		    }
		    if (previousActivePhase == cycleEvent.get(Constants.REPORTS.PHASE).getAsInt()
			    && !cycleEvent.get(Constants.REPORTS.EVENT_TYPE).getAsString()
				    .equals(config.getAppConfig(Constants.REPORTS.MISSED_PHASE))
			    && previousActivePhase != 0) {
			phase = phaseMap.get(previousActivePhase);
			if (phase != null) {
			    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.IN_PROGRESS);
			    phase.setActivePhase(true);
			}
		    }
		    if (cycleEvent.get(Constants.REPORTS.EVENT_TYPE).getAsString()
			    .equals(config.getAppConfig(Constants.REPORTS.MISSED_PHASE))) {
			phase = phaseMap.get(cycleEvent.get(Constants.REPORTS.PHASE).getAsInt());
			if (phase != null) {
			    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.MISSED_PHASE);
			    phase.setActivePhase(false);
			}
		    }
		    if (cycleEvent.get(Constants.REPORTS.EVENT_TYPE).toString()
			    .equals(config.getAppConfig(Constants.REPORTS.EVENT_TYPE_END_OF_CYCLE))
			    && previousActivePhase != 0) {
			phase = phaseMap.get(previousActivePhase);
			if (phase != null) {
			    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.SUCCESSFUL);
			    phase.setActivePhase(false);
			}
		    }
		}
	    }
	    if (ReportUtils.setPrevPhase(cycleEvent)) {
		cycle.setCyclePreviousActivePhase(cycleEvent.get(Constants.REPORTS.PHASE).getAsInt());
	    }
	    phase = phaseMap.get(cycleEvent.get(Constants.REPORTS.PHASE).getAsInt());
	    DailyReportUtils utils = new DailyReportUtils();
	    if (phase != null && phase.isValidPhase() != false)
		utils.createEvent(cycleEvent, phase);
	}
	return cycle;
    }

    public void createEvent(JsonObject event, PhaseDTO phase) throws Exception {
	List<EventsDTO> eventList = phase.getEventList();
	if (eventList == null)
	    eventList = new LinkedList<>();
	EventsDTO phaseEvent = new EventsDTO();
	phaseEvent.setProductId(event.get(Constants.REPORTS.PRODUCT_ID).getAsInt());
	phaseEvent.setEventStartTime(
		ReportUtils.convertStringToDate(event.get(Constants.REPORTS.DATE_TIME).getAsString()));
	phaseEvent.setProductName(event.get(Constants.REPORTS.PRODUCT).getAsString());
	phaseEvent.setPhase(event.get(Constants.REPORTS.PHASE).getAsInt());
	phaseEvent.setMl(event.get(Constants.REPORTS.ACTUAL_ML).getAsDouble());
	phaseEvent.setMlEstimated(event.get(Constants.REPORTS.ESTIMATED_ML).getAsDouble());
	phaseEvent.setTimeActual(event.get(Constants.REPORTS.ACTUAL_TIME).getAsString());
	phaseEvent.setTimeEstimated(event.get(Constants.REPORTS.ESTIMATED_TIME).getAsString());
	phaseEvent.setCost(event.get(Constants.REPORTS.COST_REAL).getAsDouble());
	phaseEvent.setAlarmType(event.get(Constants.REPORTS.ALARM_CODE).getAsInt());
	phaseEvent.setEventType(event.get(Constants.REPORTS.EVENT_TYPE).getAsInt());
	eventList.add(phaseEvent);
	phase.setEventList(eventList);
    }

    public void formulaCostCalculation(Map<Integer, DailyReportWasherDTO> washerMapDetails) {
	washerMapDetails.forEach((washerKey, washerValue) -> {
	    if (washerValue != null) {
		Map<Integer, CycleDTO> cycleHashMap = washerValue.getCycleHashMap();
		Map<Integer, DailyReportFormulaDTO> formulaHashMap = washerValue.getFormulaHashMap();
		if (formulaHashMap != null && !formulaHashMap.isEmpty()) {
		    formulaHashMap.forEach((formulaKey, formulaValue) -> {
			Double totalFormulaCost = 0.0;
			if (formulaValue != null && formulaValue.getCycleHashMap() != null) {
			    for (Integer key : formulaValue.getCycleHashMap().keySet()) {
				if (cycleHashMap.containsKey(key)) {
				    Double cycleformulaCost = 0.0;
				    CycleDTO cycle = cycleHashMap.get(key);
				    if (cycle != null && cycle.getFormula() != null) {
					Map<Integer, PhaseDTO> phaseMap = cycle.getFormula().getPhaseMap();
					if (phaseMap != null && !phaseMap.isEmpty()) {
					    for (Integer phaseKey : phaseMap.keySet()) {
						List<EventsDTO> eventList = phaseMap.get(phaseKey).getEventList();
						if (eventList != null) {
						    for (EventsDTO event : eventList) {
							cycleformulaCost = cycleformulaCost + event.getCost();
						    }

						}

					    }
					}
				    }
				    cycle.setFormulaCost(cycleformulaCost);
				    totalFormulaCost = totalFormulaCost + cycleformulaCost;
				}
				formulaValue.setTotalCost(totalFormulaCost);
			    }
			}
		    });
		}
	    }
	});
    }

    public Map<Integer, RealTimeAlarmDTO> createAlarmMap(CycleDTO cycle, Map<Integer, RealTimeAlarmDTO> alarmMap) {

	if (cycle != null && cycle.getFormula() != null) {
	    Map<Integer, PhaseDTO> phaseMap = cycle.getFormula().getPhaseMap();
	    phaseMap.forEach((phaseKey, phaseValue) -> {
		if (phaseValue.getEventList() != null) {
		    for (EventsDTO eventDetails : phaseValue.getEventList()) {
			int alarmType = eventDetails.getAlarmType();
			RealTimeAlarmDTO alarm = ReportUtils.getAlarmDetails(alarmType, eventDetails.getEventType(),
				eventDetails.getProductName());
			if (!Constants.REPORTS.SYSTEM_ALARMS.containsKey(alarmType))
			    alarmMap.put(alarmType, alarm);
		    }
		    phaseValue.setEventList(null);
		}
	    });
	}
	return alarmMap;
    }

    public void totalLbs(Map<Integer, DailyReportWasherDTO> washerMapDetails) {
	washerMapDetails.forEach((washerKey, washer) -> {
	    if (washer != null) {
		int capacity = 0;
		for (Integer key : washer.getCycleHashMap().keySet()) {
		    CycleDTO cycle = washer.getCycleHashMap().get(key);
		    if (cycle != null && cycle.getLbs() != null)
			capacity = capacity + cycle.getLbs();
		}
		washer.setTotalCapacity(capacity);
	    }
	});
    }

    public void createFormulaMap(DailyReportWasherDTO washer, JsonObject event) {
	// creating master formula list for each shift
	Map<Integer, DailyReportFormulaDTO> formulaMap = washer.getFormulaHashMap();
	if (formulaMap == null || formulaMap.isEmpty())
	    formulaMap = new LinkedHashMap<>();

	if (formulaMap.containsKey(event.get(Constants.REPORTS.FORMULA).getAsInt())) {
	    DailyReportFormulaDTO formulaDTO = formulaMap.get(event.get(Constants.REPORTS.FORMULA).getAsInt());
	    Map<Integer, CycleDTO> cycleMap = formulaDTO.getCycleHashMap();
	    if (!cycleMap.containsKey(event.get(Constants.REPORTS.PROCESS).getAsInt())) {
		CycleDTO cycleDetails = new CycleDTO();
		cycleDetails.setCycleId(event.get(Constants.REPORTS.PROCESS).getAsInt());
		cycleMap.put(event.get(Constants.REPORTS.PROCESS).getAsInt(), cycleDetails);
		formulaDTO.setTotalCost(
			formulaDTO.getTotalCost() + event.get(Constants.REPORTS.FORMULA_COST).getAsDouble());
		formulaDTO.setCycleHashMap(cycleMap);
		formulaDTO.setFormulaId(event.get(Constants.REPORTS.FORMULA).getAsInt());
		formulaDTO.setFormulaName(event.get(Constants.REPORTS.FORMULA_NAME).getAsString());
		formulaDTO.setNoOfOccurences(formulaDTO.getCycleHashMap().size());
		formulaMap.put(event.get(Constants.REPORTS.FORMULA).getAsInt(), formulaDTO);
	    }
	}

	if (!formulaMap.containsKey(event.get(Constants.REPORTS.FORMULA).getAsInt())) {
	    DailyReportFormulaDTO formulaDTO = new DailyReportFormulaDTO();
	    Map<Integer, CycleDTO> cycleMap = new LinkedHashMap<>();
	    CycleDTO cycleDetails = new CycleDTO();
	    cycleDetails.setCycleId(event.get(Constants.REPORTS.PROCESS).getAsInt());
	    cycleMap.put(event.get(Constants.REPORTS.PROCESS).getAsInt(), cycleDetails);
	    formulaDTO.setTotalCost(event.get(Constants.REPORTS.FORMULA_COST).getAsDouble());
	    formulaDTO.setNoOfOccurences(1);
	    formulaDTO.setCycleHashMap(cycleMap);
	    formulaDTO.setFormulaId(event.get(Constants.REPORTS.FORMULA).getAsInt());
	    formulaDTO.setFormulaName(event.get(Constants.REPORTS.FORMULA_NAME).getAsString());
	    formulaMap.put(event.get(Constants.REPORTS.FORMULA).getAsInt(), formulaDTO);
	}
	washer.setFormulaHashMap(formulaMap);
    }

    public ShiftDTO checkEventShift(List<ShiftDTO> shiftList, String eventTime) throws Exception {
	for (ShiftDTO shift : shiftList) {
	    Interval interval = CommonUtils.createInterval(CommonUtils.convertStringToLongTime(shift.getStartTime()),
		    CommonUtils.convertStringToLongTime(shift.getEndTime()));
	    if (interval.contains(CommonUtils.convertStringToLongTime(eventTime))
		    || interval.getEnd().isEqual(CommonUtils.convertStringToLongTime(eventTime))) {
		return shift;
	    }
	}
	return null;
    }

    public void setCycleTurnRunTime(Map<Integer, DailyReportWasherDTO> washerMapDetails, String shiftStartTime) {
	SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);
	washerMapDetails.forEach((washerKey, washerValue) -> {
	    long turnTimeCount = 0;
	    long runTimeCount = 0;
	    long washerTotalTurnTime = 0;
	    long washerTotalRunTime = 0;
	    Map<Integer, CycleDTO> cycleHashMap = washerValue.getCycleHashMap();
	    if (!cycleHashMap.isEmpty()) {
		Map<Integer, CycleDTO> sortedMap = getSortedCycleHashMap(cycleHashMap);
		// get the no. of entries present in hash map and then iterate
		// over it.
		Integer firstCycleId = sortedMap.keySet().iterator().next();
		Set<Integer> keySet = sortedMap.keySet();
		// Create iterator for parsing the elements present in hash map
		Iterator<Integer> iterator = keySet.iterator();
		Integer cycle1Id = null;
		CycleDTO cycle1 = null;
		CycleDTO cycle2 = null;
		// consider two cycle at a time for calculating turn time b/w
		// cycles
		while (iterator.hasNext()) {
		    if (cycle1Id != null)
			cycle1 = sortedMap.get(cycle1Id);
		    cycle2 = sortedMap.get(iterator.next());

		    if (cycle2 != null && cycle2.getStartCycleTime() != null) {
			// calculate turn time for first cycle
			if (cycle2.getCycleId() == firstCycleId) {
			    try {
				// calculate turn time for 1st cycle
				long millisec = sdf.parse(sdf.format(cycle2.getStartCycleTime())).getTime()
					- sdf.parse(shiftStartTime).getTime();
				cycle2.setTurnTime(ReportUtils.convertMillsecToHHMMSS(millisec));
				washerTotalTurnTime = washerTotalTurnTime + millisec;
				turnTimeCount++;
			    } catch (Exception e) {
				LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			    }
			}

			// calculate run time for each cycle.
			if (cycle2.getEndCycleTime() != null) {
			    long millisec = cycle2.getEndCycleTime().getTime() - cycle2.getStartCycleTime().getTime();
			    cycle2.setRunTime(ReportUtils.convertMillsecToHHMMSS(millisec));
			    washerTotalRunTime = washerTotalRunTime + millisec;
			    runTimeCount++;
			}

			// calculate turn time
			if (cycle1 != null && cycle1.getEndCycleTime() != null) {
			    long millisec = cycle2.getStartCycleTime().getTime() - cycle1.getEndCycleTime().getTime();
			    cycle2.setTurnTime(ReportUtils.convertMillsecToHHMMSS(millisec));
			    washerTotalTurnTime = washerTotalTurnTime + millisec;
			    turnTimeCount++;
			}
		    }

		    cycle1Id = cycle2.getCycleId();
		}
	    }

	    washerValue.setWasherTurnTimeTotal(ReportUtils.convertMillsecToHHMMSS(washerTotalTurnTime));
	    washerValue.setWasherRunTimeTotal(ReportUtils.convertMillsecToHHMMSS(washerTotalRunTime));
	    if (turnTimeCount != 0)
		washerValue.setWasherTurnTimeAverage(
			ReportUtils.convertMillsecToHHMMSS(washerTotalTurnTime / turnTimeCount));
	    if (runTimeCount != 0)
		washerValue
			.setWasherRunTimeAverage(ReportUtils.convertMillsecToHHMMSS(washerTotalRunTime / runTimeCount));
	});
    }

    public List<Interval> sortShiftListOnStartTime(List<ShiftDTO> shiftList) {
	List<Interval> configuredShiftIntervals = new ArrayList<Interval>();
	SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);
	try {
	    for (ShiftDTO siteShift : shiftList) {
		configuredShiftIntervals.add(new Interval(dateFormat.parse(siteShift.getStartTime()).getTime(),
			dateFormat.parse(siteShift.getEndTime()).getTime()));
		// sort configured shift intervals & use the sorted list to
		// find out
		// the off shifts present in a day.
		Collections.sort(configuredShiftIntervals, new Comparator<Interval>() {
		    @Override
		    public int compare(Interval i1, Interval i2) {
			return Long.compare(i1.getStart().getMillis(), i2.getStart().getMillis());
		    }
		});
	    }
	} catch (ParseException e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return configuredShiftIntervals;
    }

    public Map<Integer, RealTimeAlarmDTO> getSystemAlarm(Map<Integer, RealTimeAlarmDTO> systemAlarmMap,
	    JsonObject event, SiteDTO siteDTO, DailyReportResponseDTO response, String equipmentType) {
	try {
	    int alarmType = event.get(Constants.REPORTS.ALARM_CODE).getAsInt();
	    // System.out.println("AlarmType::"+alarmType);
	    // clear the alarms if there is a event
	    if (alarmType != 32 || alarmType != 33)
		response.setClearAlarm(true);
	    // create alarm

	    if (equipmentType.equalsIgnoreCase(Constants.EquipmentType.WASHER_EXTRACTOR)) {
		if (event.get(Constants.REPORTS.MACHINE_WASHER) == null) {
		    LOG.error("Data not proper for washer event : " + event);
		} else if (event.get(Constants.REPORTS.MACHINE_WASHER).getAsInt() == 0
			&& event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() >= 100) {
		    RealTimeAlarmDTO alarm = ReportUtils.createSystemAlarm(alarmType, event, response,
			    systemAlarmMap.get(Constants.REPORTS.OUT_OF_PRODUCT));
		    systemAlarmMap.put(alarmType, alarm);
		}
	    } else if (equipmentType.equalsIgnoreCase(Constants.EquipmentType.TUNNEL)) {
		if (event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() >= 100) {
		    RealTimeAlarmDTO alarm = ReportUtils.createSystemAlarm(alarmType, event, response,
			    systemAlarmMap.get(Constants.REPORTS.OUT_OF_PRODUCT));
		    systemAlarmMap.put(alarmType, alarm);
		}
	    } else {
		throw new SystemException(ErrorCodes.INVALID_EQUIPMENT_ID, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    }
	    // System.out.println("After size::"+systemAlarmMap.size());
	    // if any event occurs after alarm code: 32 & 33, clear the
	    // alarm 32 & 33
	    if (response.isClearAlarm()) {
		if (systemAlarmMap.containsKey(Constants.REPORTS.UNIT_LOCKED_ALARM)) {
		    systemAlarmMap.remove(Constants.REPORTS.UNIT_LOCKED_ALARM);
		}
		if (systemAlarmMap.containsKey(Constants.REPORTS.AIR_PRESSURE_ALARM)) {
		    systemAlarmMap.remove(Constants.REPORTS.AIR_PRESSURE_ALARM);
		}
	    }
	    // checking if out of product exceeds 15 min, if so clear
	    // alarm.
	    if (systemAlarmMap != null && systemAlarmMap.containsKey(Constants.REPORTS.OUT_OF_PRODUCT)) {
		RealTimeAlarmDTO alarm = systemAlarmMap.get(Constants.REPORTS.OUT_OF_PRODUCT);
		if (alarm != null) {
		    long milliseconds = 15 * 60000;
		    Map<Integer, DailyReportProductDTO> alarmParameters = alarm.getProductMap();
		    if (alarmParameters != null) {
			Set<Integer> keySet = alarmParameters.keySet();
			Iterator<Integer> keySetIterator = keySet.iterator();
			while (keySetIterator.hasNext()) {
			    int productId = keySetIterator.next();
			    DailyReportProductDTO product = alarmParameters.get(productId);
			    if (product != null) {
				long time;
				try {
				    time = CommonUtils
					    .convertStringToLongTime(ReportUtils.getCurrentTime(siteDTO.getTimeZone()))
					    - CommonUtils.convertStringToLongTime(
						    ReportUtils.getTimeFromDate(product.getTime()));
				    if (time >= milliseconds)
					alarmParameters.remove(productId);
				} catch (Exception e) {
				    LOG.debug("Stack trace::" + e.getStackTrace());
				}
			    }

			}
			if (alarmParameters == null || alarmParameters.isEmpty())
			    systemAlarmMap.remove(Constants.REPORTS.OUT_OF_PRODUCT);
		    }
		}
	    }
	} catch (Exception e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return systemAlarmMap;
    }

    public ShiftDTO getDefaultShift() {

	String shiftStartTime = config.getAppConfig(Constants.DEFAULT_SHIFT_START_TIME);
	String shiftEndTime = config.getAppConfig(Constants.DEFAULT_SHIFT_END_TIME);
	ShiftDTO defaultShift = new ShiftDTO();
	defaultShift.setStartTime(shiftStartTime);
	defaultShift.setEndTime(shiftEndTime);
	defaultShift.setShiftName(config.getAppConfig(Constants.DEFAULT_SHIFT));
	return defaultShift;
    }

    public Map<Integer, DailyReportWasherDTO> createWasherMap(EquipmentDTO equipment) {
	Map<Integer, DailyReportWasherDTO> washerMap = new HashMap<Integer, DailyReportWasherDTO>();
	for (WasherMetaDataDTO washer : equipment.getWasherList()) {
	    DailyReportWasherDTO machine = new DailyReportWasherDTO();
	    machine.setLm2Seq(washer.getLm2Seq());
	    machine.setWasherName(washer.getName());
	    Map<Integer, CycleDTO> cycleHashMap = new LinkedHashMap<>();
	    machine.setCycleHashMap(cycleHashMap);
	    washerMap.put(Integer.parseInt(washer.getLm2Seq()), machine);
	}
	return washerMap;
    }

    public List<ShiftDTO> getOffShiftList(List<Interval> configuredShiftIntervals) {
	List<ShiftDTO> offShiftList = new LinkedList<>();
	try {
	    SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);

	    // get the list of off shifts using actual shifts as
	    // reference.
	    Interval baseInterval = new Interval(
		    dateFormat.parse(config.getAppConfig(Constants.DEFAULT_SHIFT_START_TIME)).getTime(),
		    dateFormat.parse(config.getAppConfig(Constants.DEFAULT_SHIFT_END_TIME)).getTime());
	    ListIterator intervalIterator = configuredShiftIntervals.listIterator();
	    int offShiftCounter = 0;
	    ShiftDTO offShift = new ShiftDTO();
	    while (intervalIterator.hasNext()) {
		Interval interval = (Interval) intervalIterator.next();

		if (!interval.getStart().equals(baseInterval.getStart())) {
		    intervalIterator.previous();
		    if (!intervalIterator.hasPrevious()) {
			offShift = new ShiftDTO();
			offShiftCounter = offShiftCounter + 1;
			offShift.setShiftName(Constants.OFF_SHIFT + " " + offShiftCounter);
			offShift.setStartTime(dateFormat.format(baseInterval.getStart().toDate()));
			offShift.setEndTime(dateFormat.format(interval.getStart().minusSeconds(1).toDate()));
			offShiftList.add(offShift);
			intervalIterator.next();
		    } else {
			intervalIterator.next();
		    }
		}
		if (intervalIterator.hasNext()) {
		    Interval nextInterval = (Interval) intervalIterator.next();
		    if (!interval.getEnd().plusSeconds(1).equals(nextInterval.getStart())) {
			offShift = new ShiftDTO();
			offShiftCounter = offShiftCounter + 1;
			offShift.setShiftName(Constants.OFF_SHIFT + " " + offShiftCounter);
			offShift.setStartTime(dateFormat.format(interval.getEnd().plusSeconds(1).toDate()));
			offShift.setEndTime(dateFormat.format(nextInterval.getStart().minusSeconds(1).toDate()));
			offShiftList.add(offShift);
		    }
		    intervalIterator.previous();
		}

		if (!interval.getEnd().equals(baseInterval.getEnd()) && !intervalIterator.hasNext()) {
		    offShift = new ShiftDTO();
		    offShiftCounter = offShiftCounter + 1;
		    offShift.setShiftName(Constants.OFF_SHIFT + " " + offShiftCounter);
		    offShift.setStartTime(dateFormat.format(interval.getEnd().plusSeconds(1).toDate()));
		    offShift.setEndTime(dateFormat.format(baseInterval.getEnd().toDate()));
		    offShiftList.add(offShift);
		}
	    }
	} catch (Exception e) {
	    // TODO: handle exception
	}
	return offShiftList;
    }

    public ShiftDTO getShiftForRealTime(List<ShiftDTO> userConfiguredShifts, SiteDTO siteDTO) {
	// In case of real time report, find the current time falls in which
	// shift and for that shift create data
	ShiftDTO shift = new ShiftDTO();
	try {

	    if (userConfiguredShifts != null && !userConfiguredShifts.isEmpty()) {
		// check if the current time falls in any shift
		shift = checkEventShift(userConfiguredShifts,
			ReportUtils.getTimeZonedCurrentTime(siteDTO.getTimeZone()));
	    }
	    if ((shift == null || StringUtils.isEmpty(shift.getShiftId()))) {
		shift = getDefaultShift();
		shift.setEndTime(ReportUtils.getCurrentTime(siteDTO.getTimeZone()));
		shift.setShiftName(config.getAppConfig(Constants.REPORTS.OFF_SHIFT));
	    }
	} catch (Exception e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return shift;
    }

    public StringBuilder appendShiftName(List<ShiftDTO> selectedShift) {
	StringBuilder shiftName = null;
	if (selectedShift != null) {
	    shiftName = new StringBuilder();
	    for (ShiftDTO shiftDTO : selectedShift) {
		shiftName.append(shiftDTO.getShiftName());
		shiftName.append(",");
	    }
	}
	return shiftName;
    }

    public List<ShiftDTO> getShiftsForHistoricalReport(List<ShiftDTO> selectedShift,
	    List<ShiftDTO> userConfiguredShifts) {
	List<ShiftDTO> finalShiftsForProcessing = new LinkedList<>();
	List<Interval> configuredShiftIntervals = new ArrayList<Interval>();
	for (ShiftDTO shiftDTO : selectedShift) {
	    // check if selectedShift contains OFF SHIFT
	    if (!shiftDTO.getShiftName().equalsIgnoreCase(Constants.OFF_SHIFT)) {
		finalShiftsForProcessing.add(shiftDTO);
	    }
	    if (shiftDTO.getShiftName().equalsIgnoreCase(Constants.OFF_SHIFT) && userConfiguredShifts != null) {
		configuredShiftIntervals = sortShiftListOnStartTime(userConfiguredShifts);
		// get the list of off shifts using actual shifts as
		// reference.
		finalShiftsForProcessing.addAll(getOffShiftList(configuredShiftIntervals));
	    }

	}
	return finalShiftsForProcessing;
    }

    // tunnel related methods
    public DailyReportTunnelDTO getTunnelInfo(EquipmentDTO equipmentDTO) {
	Map<Integer, ModuleDTO> moduleMap = new HashMap<>();
	DailyReportTunnelDTO tunnelDetails = new DailyReportTunnelDTO();
	List<TunnelDTO> tunnelList = equipmentDTO.getTunnelList();
	if (tunnelList != null) {
	    tunnelList.forEach(tunnel -> {
		tunnelDetails.setName(tunnel.getName());
		int moduleCount = tunnel.getModuleCount();
		tunnelDetails.setModuleCount(moduleCount);
		while (moduleCount != 0) {
		    ModuleDTO moduleDTO = new ModuleDTO();
		    moduleDTO.setProductMap(getModulesProductMap(tunnel.getModuleDetails(), moduleCount));
		    moduleMap.put(moduleCount, moduleDTO);
		    moduleCount--;
		}
		tunnelDetails.setModuleHashMap(moduleMap);
	    });
	}
	return tunnelDetails;
    }

    public Map<Integer, Boolean> getModulesProductMap(Map<Integer, List<Integer>> moduleDetails, int moduleId) {
	if (moduleDetails.containsKey(moduleId)) {
	    List<Integer> productList = moduleDetails.get(moduleId);
	    Map<Integer, Boolean> productMap = new HashMap<>();
	    if (productList != null) {
		productList.forEach(product -> productMap.put(product, false));
	    }
	    return productMap;
	}
	return null;
    }

    public DailyReportTunnelDTO getIncompleteBatchData(SiteDTO siteDTO, DailyReportRequestDTO requestDTO,
	    JsonObject event, String startShift, int maxModule, EquipmentDTO equipmentDTO,
	    Map<Integer, TransferDTO> tempTransferMap, String endShift, String siteTimeZone) throws Exception {
	List<String> indexList = null;
	BatchDTO batchDTO = null;
	TransferDTO transferDTO = null;
	DailyReportTunnelDTO tunnelDTO = new DailyReportTunnelDTO();
	String query = ReportUtils.getQuery(Constants.REPORTS.BATCH_DATA_QUERY);
	if (StringUtils.isEmpty(query)) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}

	// Index and shift selection for real time report.
	JsonObject responseObject = null;

	String fromDateTime = getShiftStartTime(startShift);
	String toDateTime = startShift;

	if (!requestDTO.isHistoricalReport()) {
	    List<String> dateList = new ArrayList<>(Arrays.asList(CommonUtils.getDateFromDateObject(fromDateTime),
		    CommonUtils.getDateFromDateObject(toDateTime)));
	    indexList = ReportUtils.getExistingDailyIndices(dateList, siteDTO);
	} else {
	    indexList = ReportUtils.getExistingIndices(CommonUtils.getDateFromDateObject(fromDateTime),
		    CommonUtils.getDateFromDateObject(toDateTime), siteDTO);
	}

	if (!fromDateTime.equals(toDateTime)) {
	    responseObject = getBatchData(query, fromDateTime, toDateTime, equipmentDTO, event, indexList);
	    JsonObject firstHitsObject = null;
	    if (responseObject != null)
		firstHitsObject = (JsonObject) responseObject.get(Constants.REPORTS.HITS);
	    if (firstHitsObject != null) {
		JsonArray jsonArray = ReportUtils.fieldsQuery(firstHitsObject);
		// check if jsonArrayCycle contains
		// event_type 10

		if (jsonArray != null && jsonArray.size() != 0) {
		    for (int j = 0; j < jsonArray.size(); j++) {

			try {
			    LOG.debug("Processing event:: " + j);
			    JsonObject jsonObject = (JsonObject) jsonArray.get(j);
			    if (jsonObject.get(Constants.REPORTS.EVENT_TYPE).getAsInt() == 10) {
				transferDTO = createTransferDTO(jsonObject, equipmentDTO);
				TransferDTO tempTransferDTO = new TransferDTO();
				tempTransferDTO.setStartTime(ReportUtils.convertStringToDate(
					jsonObject.get(Constants.REPORTS.DATE_TIME).getAsString()));
				tempTransferMap.put(jsonObject.get(Constants.REPORTS.TRANSFER_NUMBER).getAsInt(),
					tempTransferDTO);
			    }
			    if (batchDTO == null) {
				batchDTO = createBatch(jsonObject, jsonObject.get(Constants.REPORTS.FORMULA).getAsInt(),
					jsonObject.get(Constants.REPORTS.FORMULA_NAME).getAsString());
			    } else {
				batchDTO = updateExistingBatch(jsonObject, batchDTO, maxModule);
			    }
			} catch (Exception e) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			}
		    }
		    tunnelDTO.setBatchDetails(batchDTO);
		    tunnelDTO.setTransferDetails(transferDTO);
		}
	    }
	}

	return tunnelDTO;

    }

    protected static JsonObject getBatchData(String query, String startTime, String endTime, EquipmentDTO equipment,
	    JsonObject event, List<String> indexList) {
	JsonObject responseObject = null;
	ElasticSearchDAO esDAO = null;
	try {
	    query = query.replace(Constants.START_TIME, startTime);
	    query = query.replace(Constants.END_TIME, endTime);
	    String deviceId = equipment.getDeviceId();
	    if (deviceId == null) {
		throw new SystemException(ErrorCodes.DEVICE_DOES_NOT_EXIST, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    query = query.replace(Constants.DEVICE_ID_VAL, deviceId);
	    query = query.replace(Constants.BATCH_ID_VAL, event.get(Constants.REPORTS.BATCH_ID).getAsString());
	    System.out.println("Query::" + query);
	    esDAO = new ElasticSearchDAO(false, config.getEsConfig());
	    responseObject = esDAO.executeQuery(query, indexList, config.getAppConfig(Constants.ES_TYPE));
	    System.out.println(responseObject);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	if (esDAO != null)
	    esDAO.closeJestClient();
	return responseObject;
    }

    public static EventsDTO getTunnelEventsDetail(JsonObject jsonObject) {
	EventsDTO event = new EventsDTO();
	try {
	    event.setProductId(jsonObject.get(Constants.REPORTS.PRODUCT_ID).getAsInt());
	    event.setEventStartTime(
		    ReportUtils.convertStringToDate(jsonObject.get(Constants.REPORTS.DATE_TIME).getAsString()));
	    event.setProductName(jsonObject.get(Constants.REPORTS.PRODUCT).getAsString());
	    event.setModule(jsonObject.get(Constants.REPORTS.MODULE).getAsInt());
	    event.setMl(jsonObject.get(Constants.REPORTS.ACTUAL_ML).getAsDouble());
	    event.setMlEstimated(jsonObject.get(Constants.REPORTS.ESTIMATED_ML).getAsDouble());
	    event.setTimeActual(jsonObject.get(Constants.REPORTS.ACTUAL_TIME).getAsString());
	    event.setTimeEstimated(jsonObject.get(Constants.REPORTS.ESTIMATED_TIME).getAsString());
	    event.setCost(jsonObject.get(Constants.REPORTS.COST_REAL).getAsDouble());
	    event.setAlarmType(jsonObject.get(Constants.REPORTS.ALARM_CODE).getAsInt());
	    event.setEventType(jsonObject.get(Constants.REPORTS.EVENT_TYPE).getAsInt());
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return event;
    }

    public static TransferDTO getTunnelTransferDetails(JsonObject jsonObject) {
	TransferDTO transferDTO = new TransferDTO();
	try {
	    transferDTO.setTransferNo(jsonObject.get(Constants.REPORTS.TRANSFER_NUMBER).getAsInt());
	    transferDTO.setStartTime(
		    ReportUtils.convertStringToDate(jsonObject.get(Constants.REPORTS.DATE_TIME).getAsString()));
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    e.printStackTrace();
	}
	return transferDTO;
    }

    public Date getBatchStartTimeWRTShift(String shiftStartTime, String eventFecha) {
	Date shiftStartDateTime = null;
	Date eventDateTime;
	try {
	    shiftStartDateTime = ReportUtils.convertStringToDate(shiftStartTime);
	    eventDateTime = ReportUtils.convertStringToDate(eventFecha);
	    if (eventDateTime.getTime() >= shiftStartDateTime.getTime()) {
		return eventDateTime;
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return shiftStartDateTime;

    }

    public Date getBatchEndTimeWRTShift(String shiftEndTime, String eventFecha) {
	Date shiftDateTime;
	Date eventDateTime = null;
	try {
	    if (shiftEndTime != null && eventFecha != null) {
		shiftDateTime = ReportUtils.convertStringToDate(shiftEndTime);
		eventDateTime = ReportUtils.convertStringToDate(eventFecha);
		if (eventDateTime.getTime() >= shiftDateTime.getTime()) {
		    return eventDateTime;
		}
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return eventDateTime;
    }

    public BatchDTO createBatch(JsonObject event, int formulaId, String formulaName) {
	BatchDTO batchDTO = new BatchDTO();
	try {
	    Date eventDate = ReportUtils.convertStringToDate(event.get(Constants.REPORTS.DATE_TIME).getAsString());
	    List<EventsDTO> eventList = new LinkedList<>();
	    if (event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() != 10
		    && (event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() != 11)) {
		EventsDTO eventsDTO = DailyReportUtils.getTunnelEventsDetail(event);
		eventList.add(eventsDTO);
	    }
	    batchDTO.setEventList(eventList);
	    batchDTO.setFormulaId(formulaId);
	    batchDTO.setFormulaName(formulaName);
	    batchDTO.setStartDate(eventDate);
	    batchDTO.setBatchStartTimeForEffCalc(eventDate);
	    batchDTO.setBatchEndTimeForEffCalc(eventDate);
	    batchDTO.setLbsWashed(event.get(Constants.REPORTS.KG_REALS).getAsInt());
	    batchDTO.setBatchId(event.get(Constants.REPORTS.BATCH_ID).getAsInt());
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return batchDTO;
    }

    public BatchDTO updateExistingBatch(JsonObject event, BatchDTO batchDTO, int maxModule) {
	try {
	    Date eventDate = ReportUtils.convertStringToDate(event.get(Constants.REPORTS.DATE_TIME).getAsString());
	    List<EventsDTO> eventList = batchDTO.getEventList();
	    if (event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() != 10
		    && (event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() != 11)) {
		EventsDTO eventsDTO = DailyReportUtils.getTunnelEventsDetail(event);
		eventList.add(eventsDTO);
	    }
	    batchDTO.setEventList(eventList);
	    if (event.get(Constants.REPORTS.EVENT_TYPE).getAsInt() == 11) {
		String eventTime = CommonUtils
			.extractFechaDateInProcessableFormat(event.get(Constants.REPORTS.DATE_TIME).getAsString());
		batchDTO.setEndDate(ReportUtils.convertStringToDate(eventTime));
		batchDTO.setBatchEndTimeForEffCalc(eventDate);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return batchDTO;
    }

    public BatchDTO getMasterBatchDTO(Map<Integer, BatchDTO> masterBatchMap, boolean flag, JsonObject event,
	    BatchDTO shiftBatch, int maxModule) {
	BatchDTO tempBatchDTO = null;
	int batchId = event.get(Constants.REPORTS.BATCH_ID).getAsInt();
	try {
	    tempBatchDTO = flag ? updateExistingBatch(event, masterBatchMap.get(batchId), maxModule)
		    : (BatchDTO) shiftBatch.clone();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return tempBatchDTO;
    }

    public TransferDTO getTransferDetails(boolean flag, JsonObject event, Map<Integer, TransferDTO> transferMap,
	    EquipmentDTO equipmentDTO) {
	TransferDTO transferDTO = null;
	int transferId = event.get(Constants.REPORTS.TRANSFER_NUMBER).getAsInt();
	try {
	    transferDTO = flag ? updateExistingTransfer(event, transferMap.get(transferId))
		    : createTransferDTO(event, equipmentDTO);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return transferDTO;
    }

    public TransferDTO createTransferDTO(JsonObject event, EquipmentDTO equipmentDTO) {
	TransferDTO transferDTO = new TransferDTO();
	try {
	    transferDTO.setTransferNo(event.get(Constants.REPORTS.TRANSFER_NUMBER).getAsInt());
	    List<EventsDTO> eventList = new LinkedList<>();
	    EventsDTO eventsDTO = DailyReportUtils.getTunnelEventsDetail(event);
	    eventList.add(eventsDTO);
	    transferDTO.setStartTime(
		    ReportUtils.convertStringToDate(event.get(Constants.REPORTS.DATE_TIME).getAsString()));
	    transferDTO.setModuleMap(getTunnelInfo(equipmentDTO).getModuleHashMap());
	    transferDTO.setEventList(eventList);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return transferDTO;

    }

    public Map<Integer, DailyReportFormulaDTO> getFormulaProcessedInfo(Map<Integer, BatchDTO> batchMap) {
	Map<Integer, DailyReportFormulaDTO> formulaMap = new LinkedHashMap<>();
	if (batchMap != null) {
	    batchMap.forEach((batchKey, batchValue) -> {
		if (batchValue.getStartDate() != null && batchValue.getEndDate() != null) {
		    DailyReportFormulaDTO formulaDTO;
		    int formulaId = batchValue.getFormulaId();
		    if (formulaMap.containsKey(formulaId)) {
			formulaDTO = formulaMap.get(formulaId);
			formulaDTO.setNoOfOccurences(formulaDTO.getNoOfOccurences() + 1);
			formulaDTO.setPoundsRun(formulaDTO.getPoundsRun() + batchValue.getLbsWashed());
		    } else {
			formulaDTO = new DailyReportFormulaDTO();
			formulaDTO.setFormulaId(formulaId);
			formulaDTO.setFormulaName(batchValue.getFormulaName());
			formulaDTO.setNoOfOccurences(1);
			formulaDTO.setPoundsRun(batchValue.getLbsWashed());
		    }
		    formulaMap.put(formulaId, formulaDTO);
		}
	    });
	}
	return formulaMap;
    }

    public Double getTunnelEfficiency(List<ShiftDTO> shiftList, long currentTime, Map<Integer, BatchDTO> batchMap,
	    String date, String siteTimeZone) throws Exception {
	Double efficiency = 0.0;
	if (shiftList != null) {
	    Double totalTimeElapsedInShift = 0.0;
	    long totalBatchActiveTime = 0;
	    for (ShiftDTO shift : shiftList) {
		if (shift != null) {
		    // String startShift = date + Constants.T + shift.getStartTime();
		    // String endShift = date + Constants.T + shift.getEndTime();
		    String startShift = CommonUtils
			    .convertZonedToUTC(DailyReportUtils.formDate(date, shift.getStartTime()), siteTimeZone);
		    String endShift = CommonUtils.convertZonedToUTC(DailyReportUtils.formDate(date, shift.getEndTime()),
			    siteTimeZone);
		    totalTimeElapsedInShift = totalTimeElapsedInShift
			    + getTimeElapsedInShift(currentTime, startShift, endShift);
		    if (batchMap != null) {
			List<Interval> intervals = new LinkedList<>();
			for (Integer key : batchMap.keySet()) {
			    BatchDTO batch = batchMap.get(key);
			    if (batch != null) {
				intervals.add(ReportUtils.getBatchActiveTime(batch.getBatchStartTimeForEffCalc(),
					batch.getBatchEndTimeForEffCalc(), startShift, endShift, currentTime));
			    }
			}
			List<Interval> mergedIntervals = merge(intervals);
			if (mergedIntervals != null) {
			    for (Interval i : mergedIntervals) {
				totalBatchActiveTime = totalBatchActiveTime + (i.getEndMillis() - i.getStartMillis());
			    }
			}
		    }
		}
	    }
	    if (totalTimeElapsedInShift != null && totalTimeElapsedInShift != 0) {
		efficiency = ((totalBatchActiveTime / totalTimeElapsedInShift) * 100);
		return Precision.round(efficiency, 2);
	    }
	}
	return efficiency;
    }

    public Double getTimeElapsedInShift(long currentTime, String startShift, String endShift) {
	Double timeElapsedInShift = 0.0;
	try {
	    if (currentTime < CommonUtils.convertStringToLongDateTime(endShift)) {
		long startShiftLong = CommonUtils.convertStringToLongDateTime(startShift);
		// Since, there was slight time difference in system
		// time and server time cycleActiveTime was coming -ve.
		// Hence to avoid that check if startShiftLong <
		// currentTime
		if (startShiftLong < currentTime) {
		    timeElapsedInShift = (double) (currentTime - startShiftLong);
		}
	    } else {
		timeElapsedInShift = (double) (CommonUtils.convertStringToLongDateTime(endShift)
			- CommonUtils.convertStringToLongDateTime(startShift));
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return timeElapsedInShift;
    }

    public int getTotalLbsProcessed(Map<Integer, BatchDTO> batchMap) {
	int totalCapacity = 0;
	for (Integer key : batchMap.keySet()) {
	    BatchDTO batchDTO = batchMap.get(key);
	    totalCapacity = totalCapacity + batchDTO.getLbsWashed();
	}
	return totalCapacity;
    }

    public Map<Integer, BatchDTO> getSortedBatchMap(Map<Integer, BatchDTO> batchMap) {
	Map<Integer, BatchDTO> sortedMap = new LinkedHashMap<Integer, BatchDTO>();
	batchMap.entrySet().stream().sorted(
		(entry1, entry2) -> entry1.getValue().getStartDate().compareTo(entry2.getValue().getStartDate()))
		.forEachOrdered(x -> sortedMap.put(x.getKey(), x.getValue()));
	return sortedMap;
    }

    public Map<Integer, TransferDTO> getSortedTransferMap(Map<Integer, TransferDTO> batchMap) {
	Map<Integer, TransferDTO> sortedMap = new LinkedHashMap<Integer, TransferDTO>();
	batchMap.entrySet().stream().sorted(
		(entry1, entry2) -> entry1.getValue().getStartTime().compareTo(entry2.getValue().getStartTime()))
		.forEachOrdered(x -> sortedMap.put(x.getKey(), x.getValue()));
	return sortedMap;
    }

    public Map<Integer, RealTimeAlarmDTO> getAlarmDetailsForBatchEvents(List<EventsDTO> eventList) {
	Map<Integer, RealTimeAlarmDTO> alarmMap = new LinkedHashMap<>();
	if (eventList != null) {
	    for (EventsDTO eventDetails : eventList) {
		int alarmType = eventDetails.getAlarmType();
		RealTimeAlarmDTO alarm = ReportUtils.getAlarmDetails(alarmType, eventDetails.getEventType(),
			eventDetails.getProductName());
		if (!Constants.REPORTS.SYSTEM_ALARMS.containsKey(alarmType))
		    alarmMap.put(alarmType, alarm);
	    }
	}
	return alarmMap;
    }

    public Map<Integer, RealTimeAlarmDTO> getAlarmList(Map<Integer, RealTimeAlarmDTO> systemAlarmMap,
	    Map<Integer, RealTimeAlarmDTO> alarmMap) {
	Map<Integer, RealTimeAlarmDTO> alarmMapList;
	if ((alarmMapList = alarmMap) == null)
	    alarmMapList = new HashMap<>();
	List<String> products = new ArrayList<String>();
	System.out.println("System Alarm Map::" + systemAlarmMap);
	Iterator<Integer> keySetIterator = systemAlarmMap.keySet().iterator();
	while (keySetIterator.hasNext()) {
	    int productId = keySetIterator.next();
	    RealTimeAlarmDTO product = systemAlarmMap.get(productId);
	    Map<Integer, DailyReportProductDTO> productMap = product.getProductMap();
	    if (productMap != null && !productMap.isEmpty()) {
		productMap.forEach((k, v) -> products.add(v.getProductName()));
	    }
	    RealTimeAlarmDTO ad = new RealTimeAlarmDTO();
	    ad.setAlarmName(product.getAlarmName());
	    if (productId == Constants.REPORTS.OUT_OF_PRODUCT) {
		ad.setAlarmParameters(products);
	    }
	    alarmMapList.put(productId, ad);
	}
	return alarmMapList;
    }

    public BatchDTO getLastBatch(Map<Integer, BatchDTO> masterBatchMap) {
	List<Entry<Integer, BatchDTO>> entryList;
	if (!masterBatchMap.isEmpty()) {
	    entryList = new ArrayList<Map.Entry<Integer, BatchDTO>>(masterBatchMap.entrySet());
	    return (BatchDTO) entryList.get(entryList.size() - 1).getValue();
	}
	return null;
    }

    public BatchDTO getBatchDTO(Map<Integer, BatchDTO> masterBatchMap, Map<Integer, TransferDTO> transferMap,
	    JsonObject event, SiteDTO siteDTO, DailyReportRequestDTO requestDTO, String startShift, int maxModule,
	    EquipmentDTO equipmentDTO, Map<Integer, TransferDTO> tempTransferMap, String endShift,
	    String siteTimeZone) {
	int batchId = event.get(Constants.REPORTS.BATCH_ID).getAsInt();
	int transferNo = event.get(Constants.REPORTS.TRANSFER_NUMBER).getAsInt();
	int formulaId = event.get(Constants.REPORTS.FORMULA).getAsInt();
	String formulaName = event.get(Constants.REPORTS.FORMULA_NAME).getAsString();
	int eventType = event.get(Constants.REPORTS.EVENT_TYPE).getAsInt();
	int startEvent = Integer.parseInt(config.getAppConfig(Constants.REPORTS.EVENT_TYPE_START_OF_CYCLE));
	BatchDTO batchDTO = new BatchDTO();
	try {
	    if (!masterBatchMap.containsKey(batchId) && eventType != startEvent) {
		// batch is incomplete and we need to get the previous events data
		// get complete batch data and process it first.
		DailyReportTunnelDTO tunnelDTO;
		tunnelDTO = getIncompleteBatchData(siteDTO, requestDTO, event, startShift, maxModule, equipmentDTO,
			tempTransferMap, endShift, siteTimeZone);
		if (tunnelDTO.getTransferDetails() != null) {
		    transferMap.put(transferNo, tunnelDTO.getTransferDetails());
		}
		if (tunnelDTO.getBatchDetails() != null) {
		    batchDTO = tunnelDTO.getBatchDetails();
		    batchDTO = updateExistingBatch(event, batchDTO, maxModule);
		} else {
		    batchDTO = createBatch(event, formulaId, formulaName);
		}
	    } else if (masterBatchMap.containsKey(batchId)) {
		batchDTO = updateExistingBatch(event, masterBatchMap.get(batchId), maxModule);
	    } else {
		batchDTO = createBatch(event, formulaId, formulaName);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return batchDTO;

    }

    public Map<Integer, CycleDTO> getSortedCycleHashMap(Map<Integer, CycleDTO> cycleHashMap) {
	Map<Integer, CycleDTO> sortedMap = new LinkedHashMap<Integer, CycleDTO>();
	cycleHashMap.entrySet().stream()
		.sorted((entry1, entry2) -> entry1.getValue().getStartCycleTime()
			.compareTo(entry2.getValue().getStartCycleTime()))
		.forEachOrdered(x -> sortedMap.put(x.getKey(), x.getValue()));
	return sortedMap;
    }

    public DailyReportTunnelDTO getTunnelTurnRunTime(Map<Integer, BatchDTO> batchMap) {
	DailyReportTunnelDTO tunnelDTO = new DailyReportTunnelDTO();
	if (!batchMap.isEmpty()) {
	    Set<Integer> keySet = batchMap.keySet();
	    Iterator<Integer> iterator = keySet.iterator();
	    BatchDTO cycle2 = null;
	    while (iterator.hasNext()) {
		cycle2 = batchMap.get(iterator.next());
		if (cycle2 != null && cycle2.getStartDate() != null && cycle2.getEndDate() != null) {
		    long millisec = cycle2.getEndDate().getTime() - cycle2.getStartDate().getTime();
		    cycle2.setRunTime(ReportUtils.convertMillsecToHHMMSS(millisec));
		}
	    }
	}
	tunnelDTO.setBatchMap(batchMap);
	return tunnelDTO;
    }

    public String getShiftWithLeastStartTime(List<ShiftDTO> shiftList) {
	SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);
	// sort final shift list to get the lowest shift start time, which will
	// be used for calculating first cycle turn time.
	List<Interval> tempShiftIntervals = new ArrayList<Interval>();
	tempShiftIntervals = sortShiftListOnStartTime(shiftList);
	ListIterator iterator = tempShiftIntervals.listIterator();
	String shiftTimeForTurnTimeCalc = null;
	if (iterator.hasNext()) {
	    Interval interval = (Interval) iterator.next();
	    shiftTimeForTurnTimeCalc = dateFormat.format(interval.getStart().toDate());
	}
	return shiftTimeForTurnTimeCalc;
    }

    public String getShiftName(List<ShiftDTO> selectedShift) {
	StringBuilder shiftName = appendShiftName(selectedShift);
	return shiftName.deleteCharAt(shiftName.length() - 1).toString();
    }

    public List<Interval> merge(List<Interval> intervals) {
	if (intervals == null || intervals.size() <= 1) {
	    return intervals;
	}

	Collections.sort(intervals, new Comparator<Interval>() {
	    @Override
	    public int compare(Interval i1, Interval i2) {
		return Long.compare(i1.getStart().getMillis(), i2.getStart().getMillis());
	    }
	});

	List<Interval> result = new ArrayList<>();
	Interval first = intervals.get(0);
	long start = first.getStartMillis();
	long end = first.getEndMillis();

	for (int i = 1; i < intervals.size(); i++) {
	    Interval current = intervals.get(i);
	    if (current.getStartMillis() <= end) {
		end = Math.max(current.getEndMillis(), end);
	    } else {
		result.add(new Interval(start, end));
		start = current.getStartMillis();
		end = current.getEndMillis();
	    }
	}

	result.add(new Interval(start, end));

	return result;
    }

    public long getLastShiftEndTime(List<ShiftDTO> shiftList, String date, String siteTimeZone) {
	// get last shift end time
	List<Interval> tempShiftIntervals = new ArrayList<Interval>();
	tempShiftIntervals = sortShiftListOnStartTime(shiftList);
	ListIterator iterator = tempShiftIntervals.listIterator();
	long shiftEndTimeLong = 0;
	String shiftEndTime = null;
	while (iterator.hasNext()) {
	    Interval interval = (Interval) iterator.next();
	    Date endIntervalDate = interval.getEnd().toDate();
	    shiftEndTime = getTimeFromDate(endIntervalDate);
	}
	String dateString = CommonUtils.convertZonedToUTC(DailyReportUtils.formDate(date, shiftEndTime), siteTimeZone);
	try {
	    shiftEndTimeLong = CommonUtils.convertStringToLongDateTime(dateString);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return shiftEndTimeLong;
    }

    public static String getTimeFromDate(Date date) {
	SimpleDateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);
	return dateFormat.format(date);
    }

    public TransferDTO getLastTransfer(Map<Integer, TransferDTO> transferMap) {
	List<Entry<Integer, TransferDTO>> entryList;
	if (!transferMap.isEmpty()) {
	    entryList = new ArrayList<Map.Entry<Integer, TransferDTO>>(transferMap.entrySet());
	    return (TransferDTO) entryList.get(entryList.size() - 1).getValue();
	}
	return null;
    }

    public TransferDTO getSecondLastTransfer(Map<Integer, TransferDTO> transferMap) {
	List<Entry<Integer, TransferDTO>> entryList;
	if (!transferMap.isEmpty()) {
	    entryList = new ArrayList<Map.Entry<Integer, TransferDTO>>(transferMap.entrySet());
	    int entryListSize = entryList.size();
	    int entry = entryListSize - 2;
	    if (entry >= 0 && entry <= entryListSize)
		return (TransferDTO) entryList.get(entryList.size() - 2).getValue();
	}
	return null;
    }

    public boolean checkEventShift(ShiftDTO shift, String eventTime) throws Exception {
	Interval interval = CommonUtils.createInterval(CommonUtils.convertStringToLongTime(shift.getStartTime()),
		CommonUtils.convertStringToLongTime(shift.getEndTime()));
	if (interval.contains(CommonUtils.convertStringToLongTime(eventTime))
		|| interval.getEnd().isEqual(CommonUtils.convertStringToLongTime(eventTime))) {
	    return true;
	}
	return false;
    }

    public Map<Integer, BatchDTO> getBatchMap(List<ShiftDTO> shiftList, boolean isHistoricalReport,
	    Map<Integer, BatchDTO> batchMap) {
	ReportUtils reportUtils = new ReportUtils();
	DailyReportTunnelDTO tunnelDTO = new DailyReportTunnelDTO();
	ShiftDTO shift = new ShiftDTO();
	shift = shiftList.get(0);
	Map<Integer, BatchDTO> finalBatchMap = new LinkedHashMap<>();
	if (!isHistoricalReport && batchMap != null && !batchMap.isEmpty()) {
	    for (Integer key : batchMap.keySet()) {
		BatchDTO batchDTO = batchMap.get(key);
		try {
		    if (checkEventShift(shift, reportUtils.getTimeFromDate(batchDTO.getStartDate()))) {
			finalBatchMap.put(batchDTO.getBatchId(), batchDTO);
		    }
		} catch (Exception e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		}
	    }
	} else {
	    finalBatchMap = batchMap;
	}
	return finalBatchMap;
    }

    public Map<Integer, TransferDTO> getTransferMap(List<ShiftDTO> shiftList, boolean isHistoricalReport,
	    Map<Integer, TransferDTO> transferMap) {
	ReportUtils reportUtils = new ReportUtils();
	ShiftDTO shift = shiftList.get(0);
	Map<Integer, TransferDTO> finalTransferMap = new LinkedHashMap<>();
	if (!isHistoricalReport && transferMap != null && !transferMap.isEmpty()) {
	    for (Integer key : transferMap.keySet()) {
		TransferDTO transferDTO = transferMap.get(key);
		try {
		    if (checkEventShift(shift, reportUtils.getTimeFromDate(transferDTO.getStartTime()))) {
			finalTransferMap.put(transferDTO.getTransferNo(), transferDTO);
		    }
		} catch (Exception e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		}
	    }
	} else {
	    finalTransferMap = transferMap;
	}
	return finalTransferMap;
    }

    public TransferDTO updateExistingTransfer(JsonObject event, TransferDTO transferDTO) {
	try {
	    List<EventsDTO> eventList = transferDTO.getEventList();
	    EventsDTO eventsDTO = DailyReportUtils.getTunnelEventsDetail(event);
	    eventList.add(eventsDTO);
	    transferDTO.setEventList(eventList);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return transferDTO;
    }

    public int updateTransferModuleDetails(int transferNo, int lastTransferNo, Map<Integer, TransferDTO> transferMap,
	    boolean isHistoricalReport, TransferDTO transferDTO, String eventTime) {
	try {
	    // set end time for a transfer
	    if (transferNo != lastTransferNo) {
		if (lastTransferNo != 0 && transferMap.containsKey(lastTransferNo)) {
		    if (!isHistoricalReport) {
			Map<Integer, ModuleDTO> prevModuleMap = transferMap.get(lastTransferNo).getModuleMap();
			// check if any of the module is empty, if yes then use prev. transfer snapshot
			// to update module value with batch and then update the current transfer with
			// newly updated module map
			Map<Integer, ModuleDTO> moduleDetails = transferDTO.getModuleMap();
			Iterator<Entry<Integer, ModuleDTO>> iterator = moduleDetails.entrySet().iterator();
			while (iterator.hasNext()) {
			    Map.Entry<Integer, ModuleDTO> moduleEntry = iterator.next();
			    ModuleDTO moduleDTO = moduleEntry.getValue();
			    if (moduleDTO.getBatch() == null && prevModuleMap != null
				    && prevModuleMap.containsKey(moduleEntry.getKey() - 1)) {
				BatchDTO batchDTO = prevModuleMap.get(moduleEntry.getKey() - 1).getBatch();
				moduleDTO.setBatch(batchDTO);
				moduleDetails.put(moduleEntry.getKey(), moduleDTO);
			    }
			}
			transferDTO.setModuleMap(moduleDetails);
			transferMap.put(transferNo, transferDTO);
		    }
		    transferDTO = transferMap.get(lastTransferNo);
//		    transferDTO.setEndTime(ReportUtils.convertStringToDate(eventTime));
		    transferMap.put(lastTransferNo, transferDTO);
		}
		lastTransferNo = transferNo;
	    }
	} catch (Exception e) {
	    // TODO: handle exception
	}
	return lastTransferNo;

    }

    public Map<Integer, BatchDTO> getBatchsWithEndTime(Map<Integer, BatchDTO> batchMap, List<ShiftDTO> shiftList,
	    boolean isHistorical, String siteTimeZone) throws Exception {
	Map<Integer, BatchDTO> finalBatchMap = new HashMap<>();
	if (!isHistorical) {
	    ShiftDTO shift = shiftList.get(0);
	    Iterator<Entry<Integer, BatchDTO>> it = batchMap.entrySet().iterator();
	    while (it.hasNext()) {
		Map.Entry<Integer, BatchDTO> pair = it.next();
		BatchDTO batchDTO = pair.getValue();
		if (batchDTO.getEndDate() != null && it.hasNext()
			&& checkEventShift(shift,
				CommonUtils.convertStringUTCToZonedTime(
					CommonUtils.extractFechaDateInProcessableFormat(
						ReportUtils.convertDateToString(batchDTO.getEndDate())),
					siteTimeZone))) {

		    finalBatchMap.put(pair.getKey(), pair.getValue());
		}
	    }
	} else {
	    Iterator<Entry<Integer, BatchDTO>> it = batchMap.entrySet().iterator();
	    while (it.hasNext()) {
		Map.Entry<Integer, BatchDTO> pair = it.next();
		BatchDTO batchDTO = pair.getValue();
		if (batchDTO.getEndDate() != null && it.hasNext()) {
		    finalBatchMap.put(pair.getKey(), pair.getValue());
		}
	    }
	}
	return finalBatchMap;
    }

    public Map<Integer, TransferDTO> getTransfersEndTime(Map<Integer, TransferDTO> transferMap) {
	Map<Integer, TransferDTO> tempMap = getSortedTransferMap(transferMap);
	Iterator<Entry<Integer, TransferDTO>> iterator = tempMap.entrySet().iterator();
	Map.Entry<Integer, TransferDTO> t1 = null;
	while (iterator.hasNext()) {
	    if (t1 == null) {
		t1 = iterator.next();
	    }
	    if (iterator.hasNext() && t1.getValue().getEndTime() == null) {
		Map.Entry<Integer, TransferDTO> t2 = iterator.next();
		TransferDTO transferDTO = t1.getValue();
		transferDTO.setEndTime(t2.getValue().getStartTime());
		tempMap.put(t1.getKey(), transferDTO);
		t1 = t2;
	    } else if (iterator.hasNext()) {
		t1 = iterator.next();
	    }
	}
	return tempMap;
    }

    public DailyReportTunnelDTO getActiveTimeDetails(List<ShiftDTO> shiftList, long currentTime,
	    Map<Integer, TransferDTO> transferMap, String date, boolean isHistoricalReport, String siteTimeZone)
	    throws Exception {
	DailyReportTunnelDTO tunnelDTO = new DailyReportTunnelDTO();
	long shiftEndTime = getLastShiftEndTime(shiftList, date, siteTimeZone);
	long totalBatchActiveTime = 0;
	Set<Integer> transferSet = new HashSet<Integer>();
	TransferDTO transferDTO = null;
	if (shiftList != null) {
	    Double totalTimeElapsedInShift = 0.0;
	    for (ShiftDTO shift : shiftList) {
		if (shift != null) {
		    String startShift = CommonUtils
			    .convertZonedToUTC(DailyReportUtils.formDate(date, shift.getStartTime()), siteTimeZone);
		    String endShift = CommonUtils.convertZonedToUTC(DailyReportUtils.formDate(date, shift.getEndTime()),
			    siteTimeZone);
		    totalTimeElapsedInShift = totalTimeElapsedInShift
			    + getTimeElapsedInShift(currentTime, startShift, endShift);
		    if (transferMap != null && !transferMap.isEmpty()) {
			if (isHistoricalReport) {
			    for (Integer key : transferMap.keySet()) {
				transferDTO = transferMap.get(key);

				if (transferDTO != null) {
				    totalBatchActiveTime = addTransferTime(currentTime, totalBatchActiveTime,
					    transferSet, transferDTO, startShift, endShift, key);
				}

			    }
			} else {

			    for (Integer key : transferMap.keySet()) {
				if (transferMap.get(key) != null && checkEventShift(shift,
					CommonUtils.convertStringUTCToZonedTime(
						CommonUtils.extractFechaDateInProcessableFormat(ReportUtils
							.convertDateToString(transferMap.get(key).getStartTime())),
						siteTimeZone))) {
				    transferDTO = transferMap.get(key);
				    if (transferDTO != null) {
					totalBatchActiveTime = addTransferTime(currentTime, totalBatchActiveTime,
						transferSet, transferDTO, startShift, endShift, key);
				    }

				}
			    }
			}
		    }
		    if (!transferSet.isEmpty()) {

			double totalTranfers = transferSet.size();
			tunnelDTO.setAverageCycleTime(
				Math.round(TimeUnit.MILLISECONDS.toSeconds(totalBatchActiveTime) / totalTranfers));

		    }

		}
	    }
	}
	if (transferDTO != null && transferDTO.getStartTime() != null) {
	    if (shiftEndTime < currentTime) {
		tunnelDTO.setCurrentCycleTime(
			TimeUnit.MILLISECONDS.toSeconds(shiftEndTime - transferDTO.getStartTime().getTime()));
	    } else {
		tunnelDTO.setCurrentCycleTime(
			TimeUnit.MILLISECONDS.toSeconds(currentTime - transferDTO.getStartTime().getTime()));
	    }
	}
	return tunnelDTO;
    }

    private long addTransferTime(long currentTime, long totalBatchActiveTime, Set<Integer> transferSet,
	    TransferDTO transferDTO, String startShift, String endShift, Integer key) {
	long activeTime = ReportUtils.getCycleActiveTimeInShift(transferDTO.getStartTime(), transferDTO.getEndTime(),
		startShift, endShift, currentTime);
	totalBatchActiveTime = totalBatchActiveTime + activeTime;
	if (activeTime != 0) {
	    transferSet.add(key);
	}
	return totalBatchActiveTime;
    }

    // new logic for tunnel efficiency.
    public Double getTunnelEfficiency(long avgTranferTime, double siteDefaultTrasferTime) {
//	Efficiency = Actual pounds processed / theoretical max poundage
//		actual poundage = (elapsed time in shift * capacity)/(avg. transfer time)
//	theoretical max poundage = (elapsed time in shift * capacity)/(transfer time in site pref.)
//	Hence effi = transfer time in site pref / avg. transfer time
	Double efficiency = 0.0;
	if (avgTranferTime != 0) {
	    double avgTransferTimeInMin = (avgTranferTime / 60.0);
	    efficiency = ((siteDefaultTrasferTime / avgTransferTimeInMin) * 100);
	    return Precision.round(efficiency, 2);
	}
	return efficiency;
    }

    public static void convertTunnelRealTimeEventTimetoSiteZone(ShiftDTO masterShiftDTO, String siteTimeZone)
	    throws ParseException {
	if (siteTimeZone != null) {
	    DailyReportTunnelDTO dt = masterShiftDTO.getTunnelDetails();
	    Map<Integer, ModuleDTO> moduleMap = dt.getModuleHashMap();
	    moduleMap.forEach((k, v) -> {
		BatchDTO batch = v.getBatch();
		if (batch != null) {
		    try {
			if (batch.getStartDate() != null) {
			    batch.setStartDate(convertStringToDate(
				    CommonUtils.convertDateUTCToZonedTime(batch.getStartDate(), siteTimeZone)));
			}
			if (batch.getEndDate() != null) {
			    batch.setEndDate(convertStringToDate(
				    CommonUtils.convertDateUTCToZonedTime(batch.getEndDate(), siteTimeZone)));
			}
			if (batch.getBatchStartTimeForEffCalc() != null) {
			    batch.setBatchStartTimeForEffCalc(convertStringToDate(CommonUtils
				    .convertDateUTCToZonedTime(batch.getBatchStartTimeForEffCalc(), siteTimeZone)));
			}
			if (batch.getBatchEndTimeForEffCalc() != null) {
			    batch.setBatchEndTimeForEffCalc(convertStringToDate(CommonUtils
				    .convertDateUTCToZonedTime(batch.getBatchEndTimeForEffCalc(), siteTimeZone)));
			}
		    } catch (Exception e) {
			LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		    }
		}
	    });
	}
    }

    public static void convertWasherRealTimeEventTimetoSiteZone(ShiftDTO masterShiftDTO, String siteTimeZone) {
	if (siteTimeZone != null) {
	    Map<Integer, DailyReportWasherDTO> washerMap = masterShiftDTO.getWasherHashMap();
	    washerMap.forEach((washerKey, washerValue) -> {
		CycleDTO cycle = washerValue.getCurrentCycle();
		if (cycle != null) {
		    try {
			if (cycle.getStartCycleTime() != null) {
			    cycle.setStartCycleTime(convertStringToDate(
				    CommonUtils.convertDateUTCToZonedTime(cycle.getStartCycleTime(), siteTimeZone)));
			}
			if (cycle.getEndCycleTime() != null) {
			    cycle.setEndCycleTime(convertStringToDate(
				    CommonUtils.convertDateUTCToZonedTime(cycle.getEndCycleTime(), siteTimeZone)));
			}
		    } catch (Exception e) {
			LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		    }
		}
	    });
	}
    }

    public static void convertWasherDayWiseTimeEventTimetoSiteZone(ShiftDTO masterShiftDTO, String siteTimeZone) {
	if (siteTimeZone != null) {
	    Map<Integer, DailyReportWasherDTO> washerMap = masterShiftDTO.getWasherHashMap();
	    washerMap.forEach((washerKey, washerValue) -> {
		Map<Integer, CycleDTO> cycleMap = washerValue.getCycleHashMap();
		cycleMap.forEach((cycleKey, cycleValue) -> {
		    CycleDTO cycle = cycleValue;
		    if (cycle != null) {
			try {
			    if (cycle.getStartCycleTime() != null) {
				cycle.setStartCycleTime(convertStringToDate(CommonUtils
					.convertDateUTCToZonedTime(cycle.getStartCycleTime(), siteTimeZone)));
			    }
			    if (cycle.getEndCycleTime() != null) {
				cycle.setEndCycleTime(convertStringToDate(
					CommonUtils.convertDateUTCToZonedTime(cycle.getEndCycleTime(), siteTimeZone)));
			    }
			    DailyReportFormulaDTO formula = cycle.getFormula();
			    Map<Integer, PhaseDTO> phaseMap = formula.getPhaseMap();
			    if (!phaseMap.isEmpty()) {
				phaseMap.forEach((phaseKey, phaseValue) -> {
				    if (phaseValue != null && phaseValue.getEventList() != null
					    && !phaseValue.getEventList().isEmpty()) {
					List<EventsDTO> eventList = phaseValue.getEventList();
					for (EventsDTO event : eventList) {
					    if (event.getEventStartTime() != null) {
						try {
						    event.setEventStartTime(
							    convertStringToDate(CommonUtils.convertDateUTCToZonedTime(
								    event.getEventStartTime(), siteTimeZone)));
						} catch (Exception e) {
						    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
						}
					    }
					}
				    }
				});
			    }
			} catch (Exception e) {
			    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			}
		    }
		});

	    });
	}
    }

    public static void convertTunnelEventTimetoSiteZone(ShiftDTO masterShiftDTO, String siteTimeZone) throws Exception {
	if (siteTimeZone != null) {
	    DailyReportTunnelDTO dt = masterShiftDTO.getTunnelDetails();
	    Map<Integer, BatchDTO> batchMap = dt.getBatchMap();
	    for (Map.Entry<Integer, BatchDTO> entry : batchMap.entrySet()) {
		BatchDTO batch = entry.getValue();
		if (batch != null) {
		    if (batch.getStartDate() != null) {
			batch.setStartDate(convertStringToDate(
				CommonUtils.convertDateUTCToZonedTime(batch.getStartDate(), siteTimeZone)));

		    }
		    if (batch.getEndDate() != null) {
			batch.setEndDate(convertStringToDate(
				CommonUtils.convertDateUTCToZonedTime(batch.getEndDate(), siteTimeZone)));
		    }
		    if (batch.getBatchStartTimeForEffCalc() != null) {
			batch.setBatchStartTimeForEffCalc(convertStringToDate(CommonUtils
				.convertDateUTCToZonedTime(batch.getBatchStartTimeForEffCalc(), siteTimeZone)));
		    }
		    if (batch.getBatchEndTimeForEffCalc() != null) {
			batch.setBatchEndTimeForEffCalc(convertStringToDate(CommonUtils
				.convertDateUTCToZonedTime(batch.getBatchEndTimeForEffCalc(), siteTimeZone)));
		    }
		    List<EventsDTO> eventList = batch.getEventList();
		    if (eventList != null && !eventList.isEmpty()) {
			for (EventsDTO event : eventList) {
			    if (event.getEventStartTime() != null) {
				event.setEventStartTime(convertStringToDate(CommonUtils
					.convertDateUTCToZonedTime(event.getEventStartTime(), siteTimeZone)));
			    }
			}
		    }
		}
	    }
	}
    }

    public static String formDate(String date, String time) {
	return (date + Constants.T + time);
    }

    public static Date convertStringToDate(String date) throws Exception {
	SimpleDateFormat localDateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.DATE_FORMAT);
	Date convertedDate;
	try {
	    convertedDate = localDateFormat.parse(date);
	} catch (ParseException e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, date);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, date);
	}
	return convertedDate;
    }

    public static String getShiftStartTime(String startShift) {
	DateTimeFormatter formatter = DateTimeFormatter
		.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	LocalDateTime ldt = LocalDateTime.parse(startShift).minusDays(1);
	return ldt.format(formatter);
    }

    public JsonObject executeDailyReportQuery(String query, List<String> indexList) {
	// fetching machine data from ES
	ElasticSearchDAO esDAO = new ElasticSearchDAO(false, config.getEsConfig());
	JsonObject responseObject = null;
	try {
	    responseObject = esDAO.executeQuery(query, indexList, config.getAppConfig(Constants.ES_TYPE));
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	if (esDAO != null)
	    esDAO.closeJestClient();
	return responseObject;

    }
}
