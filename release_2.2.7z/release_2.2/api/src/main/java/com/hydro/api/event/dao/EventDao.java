package com.hydro.api.event.dao;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.base.dao.HydroDao;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.EventDTO;
import com.hydro.api.dto.FormulaMetaDataDTO;
import com.hydro.api.dto.ProductDTO;
import com.hydro.api.exception.SystemException;

/**
 *
 * @author Srishti Tiwari
 * 
 */
public class EventDao extends HydroDao {
    private static final Logger LOG = LoggerFactory.getLogger(EventDao.class);

    public EventDTO getSiteDetails(String siteId) throws SystemException, Exception {
	Database database = null;
	EventDTO eventDTO = null;
	try {
	    String query = SQLConstants.GET_SITE_DETAILS;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(siteId);
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		eventDTO = new EventDTO();
		eventDTO.setSiteName(rs.getString(SQLColumns.SITE_NAME));
		eventDTO.setAssociationId(rs.getString(SQLColumns.BUSINESS_ID));
		eventDTO.setTimeZone(rs.getString(SQLColumns.TIME_ZONE));
		eventDTO.setAlertSetting(rs.getInt(SQLColumns.ALERT_SETTING));
		eventDTO.setWasherIdleTime(rs.getInt(SQLColumns.WASHER_IDLE_MINUTE));
		eventDTO.setTunnelIdleTime(rs.getInt(SQLColumns.TUNNEL_IDLE_MINUTE));
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Error while closing db connection : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
	return eventDTO;
    }

    /*
     * public Map<String, List<String>> getSmsEmailMap1(String siteId, List<String>
     * roleList, int alarmId) throws Exception { Database database = null;
     * Map<String, List<String>> smsEmailMap = new HashMap<>(); try { database = new
     * Database(); database.setAutoCommitFalse(); String placeHolders =
     * String.join(",", Collections.nCopies(roleList.size(), "?")); String query =
     * "select t1.email from (select * from user_master UM where business_id=(select business_id from site_master where site_id=?) and role_id in(select role_id from preference_master where role_id in ("
     * + placeHolders +
     * ") and alarm_id=? and business_id=UM.business_id and email is true)) t1 left join (select * from user_alarm_preference where alarm_id=? and active=0) t2 on t1.user_id= t2.user_id where t2.user_id is null"
     * ; LOG.debug("query>>>>" + query);
     * 
     * LinkedList<Object> params = new LinkedList<>(); params.add(siteId); for
     * (String role : roleList) { params.add(role); } params.add(alarmId);
     * params.add(alarmId); List<String> emailList = new LinkedList<>();
     * 
     * ResultSet rs = database.executeQuery(query, params); while (rs.next()) {
     * emailList.add(rs.getString(SQLColumns.EMAIL)); }
     * smsEmailMap.put(SQLColumns.EMAIL, emailList); query =
     * "select t1.phone_number from (select * from user_master UM where business_id=(select business_id from site_master where site_id=?) and role_id in(select role_id from preference_master where role_id in ("
     * + placeHolders +
     * ") and alarm_id=? and business_id=UM.business_id and sms is true)) t1 left join (select * from user_alarm_preference where alarm_id=? and active=0) t2 on t1.user_id= t2.user_id where t2.user_id is null"
     * ; LOG.debug("query>>>>" + query);
     * 
     * List<String> contactList = new LinkedList<>();
     * 
     * rs = database.executeQuery(query, params); while (rs.next()) {
     * contactList.add(rs.getString(SQLColumns.PHONE_NUMBER)); }
     * smsEmailMap.put(SQLColumns.SMS, contactList); database.commit(); return
     * smsEmailMap; } catch (SystemException e) { LOG.error(e.getMessage()); throw
     * e; } catch (SQLException e) {
     * 
     * try { LOG.error(e.getMessage()); throw new
     * SystemException(ErrorCodes.GENERIC_EXCEPTION,
     * ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
     * null);
     * 
     * } catch (SQLException e1) { throw new
     * SystemException(ErrorCodes.GENERIC_EXCEPTION,
     * ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
     * null); } } catch (Exception e) { LOG.error("Stack Trace : " +
     * ExceptionUtils.getFullStackTrace(e)); throw new
     * SystemException(ErrorCodes.GENERIC_EXCEPTION,
     * ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
     * null); } finally { try { if (database != null) { database.closeConnection();
     * } } catch (Exception e) { LOG.error( "Stack Trace : " +
     * ExceptionUtils.getFullStackTrace(e)); } } }
     */

    public long calTimeDifference(LocalDateTime fecha, LocalDateTime convertedCurrentDateTime) {
	long min = Duration.between(fecha, convertedCurrentDateTime).toMinutes();
	return min;
    }

    public void populateTunnelDetail(EventDTO eventDto) throws SystemException, Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_TUNNEL_DETAIL_FOR_DEVICE;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> parameters = new LinkedList<>();
	    parameters.add(eventDto.getDevice_id());
	    ResultSet tunnelResult = database.executeQuery(query, parameters);
	    String tunnelName;
	    if (tunnelResult.next()) {
		tunnelName = tunnelResult.getString(SQLColumns.TUNNEL_NAME);
		if (tunnelName == null || tunnelName.trim().isEmpty()) {
		    LOG.error("Tunnel name missing in tunnel details table.");
		} else {
		    eventDto.setWasherextractor_name(tunnelName);
		}

		eventDto.setDestino(tunnelResult.getInt(SQLColumns.LM2_SEQ));
	    } else {
		LOG.error("Tunnel details not found.");
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Error while closing db connection : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public EquipmentDTO getEquipmentDetail(String deviceId) throws SystemException, Exception {
	Database database = null;
	EquipmentDTO equipment = null;
	try {
	    String query = SQLConstants.GET_EQUIPMENT_DETAIL_FOR_DEVICE;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> parameters = new LinkedList<>();
	    parameters.add(deviceId);
	    ResultSet result = database.executeQuery(query, parameters);

	    if (result.next()) {
		equipment = new EquipmentDTO();
		equipment.setEquipmentId(result.getString(SQLColumns.EQUIPMENT_ID));
		equipment.setSiteId(result.getString(SQLColumns.SITE_ID));
		equipment.setLm2Seq(result.getInt(SQLColumns.LM2_SEQ));
		equipment.setAlias(result.getString(SQLColumns.ALIAS));
		equipment.setEquipmentType(result.getString(SQLColumns.EQUIPMENT_TYPE));
		equipment.setFileId(result.getString(SQLColumns.FILE_ID));
		equipment.setDeviceId(deviceId);
	    }
	    return equipment;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Error while closing db connection : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public FormulaMetaDataDTO getFormulaDetail(String equipmentId, Integer lm2Seq) throws SystemException, Exception {
	Database database = null;
	FormulaMetaDataDTO formula = null;
	try {
	    String query = SQLConstants.GET_FORMULA_FOR_LM2;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> parameters = new LinkedList<>();
	    parameters.add(equipmentId);
	    parameters.add(String.valueOf(lm2Seq));
	    ResultSet result = database.executeQuery(query, parameters);

	    if (result.next()) {
		formula = new FormulaMetaDataDTO();
		formula.setFormulaId(result.getString(SQLColumns.FORMULA_ID));
		formula.setLm2Id(result.getString(SQLColumns.LM2_SEQ));
		formula.setName(result.getString(SQLColumns.NAME));
	    }
	    return formula;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Error while closing db connection : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public List<ProductDTO> getProductList(EquipmentDTO equipment) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_PRODUCT_LIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(equipment.getEquipmentId());
	    ResultSet rs = database.executeQuery(query, params);
	    List<ProductDTO> productList = new LinkedList<>();

	    while (rs.next()) {
		ProductDTO product = new ProductDTO();
		product.setProductId(rs.getString(SQLColumns.PRODUCT_ID));
		product.setName(rs.getString(SQLColumns.NAME));
		product.setLm2Seq(rs.getString(SQLColumns.LM2_SEQ));
		product.setConcentration(rs.getInt(SQLColumns.CONCENTRATION));
		product.setFormat(rs.getInt(SQLColumns.FORMAT));
		product.setPrecio(new BigDecimal(rs.getInt(SQLColumns.PRICE) / Constants.Units.PRICE));
		productList.add(product);
	    }

	    return productList;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }
}
