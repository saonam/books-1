package com.hydro.api.reports.business;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.exception.SystemException;

public class DataRequestProcessorFactory {

    private static DataRequestProcessorFactory factory;
    private static final Logger LOG = LoggerFactory.getLogger(DataRequestProcessorFactory.class);

    private Map<String, Object> processors = new HashMap<>();

    private DataRequestProcessorFactory() {
    }

    public static DataRequestProcessor getRequestProcessor(RequestProcessor requestProcessor)
	    throws SystemException, Exception {

	if (factory == null) {
	    factory = new DataRequestProcessorFactory();
	}

	String klsStr = requestProcessor.klass.getName();
	DataRequestProcessor processor = (DataRequestProcessor) factory.processors.get(klsStr);
	if (processor == null) {
	    try {
		processor = (DataRequestProcessor) requestProcessor.klass().newInstance();
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		throw new SystemException(ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE,
			String.format("Error loading report generator : %s", requestProcessor.klass().getName()));
	    }
	    factory.processors.put(klsStr, processor);
	}
	return processor;
    }

    public enum RequestProcessor {
	DAYWISE(DaywiseHistoricalReport.class),
	DAYWISE_WASHER(DaywiseHistoricalWasherReport.class),
	DAYWISE_TUNNEL(DaywiseHistoricalTunnelReport.class);

	private final Class klass;

	private RequestProcessor(Class klass) {
	    this.klass = klass;
	}

	public Class klass() {
	    return klass;
	}
    }
}
