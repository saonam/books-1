package com.hydro.api.user.business;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.hydro.api.base.business.HydroBL;
import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.dto.UserListResponseDTO;
import com.hydro.api.dto.UserPreferenceResponseDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.site.business.HydroSiteBL;
import com.hydro.api.user.dao.UserDao;
import com.hydro.api.user.dao.concrete.CompanyUserDao;
import com.hydro.api.user.dao.concrete.HydroUserDao;
import com.hydro.api.user.dao.concrete.PartialCompanyUserDao;
import com.hydro.api.user.dao.concrete.PartialHydroUserDao;
import com.hydro.api.user.dao.concrete.SiteCompanyUserDao;

/**
 * Business layer for the Application.
 * 
 * @author Shreyas
 *
 */
public class HydroUserBL extends HydroBL {
    private static final Logger LOG = LoggerFactory.getLogger(HydroUserBL.class);
    private HydroSiteBL siteBL;

    public HydroUserBL(String userId, String timeZone) throws SystemException, Exception {
	super(userId, timeZone);
	LOG.debug("In Hydro User BL.");
	
	String orgType = user.getOrgType();
	switch (orgType) {
	case Constants.HYDRO:
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new HydroUserDao()
			    :   new PartialHydroUserDao();
	    break;
	case Constants.COMPANY:
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new CompanyUserDao()
		    :   new PartialCompanyUserDao();
	    break;
	case Constants.SITE:
	    hydroDao = (permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE)) ? new CompanyUserDao()
		    : new SiteCompanyUserDao();
	    break;
	default:
	    LOG.debug("Unknown Orgnization");
	}
	siteBL = new HydroSiteBL(userId, timeZone);
    }

    public boolean testUserDbConnection() {
	return ((UserDao) hydroDao).testUserDbConnection();
    }

    public UserListResponseDTO getUserList(UserDTO targetUser) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.USER_LIST);
	UserListResponseDTO response = ((UserDao) hydroDao).getAllUserList(user, targetUser);
	List<UserDTO> userList = response.getUserList();
	for (UserDTO user : userList) {
	    user.setFullPrivilege(hasPermission(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE, user));
	}
	return response;
    }

    public UserDTO getUserDetails(UserDTO targetUser) throws Exception {
	ConfigReader configReader = new ConfigReader();
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.USER_VIEW);
	UserDTO userDTO = hydroDao.getUserDetails(targetUser);
	boolean sameLevelUserFlag = hasPermission(Constants.PRIVILEGE_NAMES.CREATE_SAME_LEVEL_USER);
	if (!CommonUtils.userCreationCheck(user, userDTO, sameLevelUserFlag)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	if (!hasCompanyVisibility(userDTO.getAssociationId(), user)) {
	    throw new SystemException(ErrorCodes.INVALID_COMPANY_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, userDTO.getAssociationId());
	}
	if (!configReader.hasPermission(userDTO.getOrgType(), userDTO.getUserRole(),
		Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE))
	    userDTO.setSiteList(((UserDao) hydroDao).getSiteListForUser(userDTO));
	return userDTO;
    }

    public boolean userSignInNameExists(UserDTO userDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.USER_CREATE);

	if (!user.getPermissions().isUSER_CREATE()) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	if (userDTO == null || !CommonUtils.userNamePattern(userDTO.getUserName())) {
	    throw new SystemException(ErrorCodes.INVALID_USER_NAME, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);

	}
	if (userDTO.getUserName().equalsIgnoreCase(((UserDao) hydroDao).userNameExists(userDTO))) {
	    return true;
	}
	return CommonUtils.userSignInNameExists(userDTO.getUserName());
    }

    public UserDTO createUser(UserDTO userDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.USER_CREATE);
	ConfigReader config = ConfigReader.getObject();
	boolean sameLevelUserFlag = hasPermission(Constants.PRIVILEGE_NAMES.CREATE_SAME_LEVEL_USER);

	userDTO.setClearanceLevel(config.getRoleClearanceLevel(userDTO.getOrgType(), userDTO.getUserRole()));
	if (!CommonUtils.userCreationCheck(user, userDTO, sameLevelUserFlag)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	if (!CommonUtils.userNamePattern(userDTO.getUserName())) {
	    throw new SystemException(ErrorCodes.INVALID_USER_NAME, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	// Validation On Insufficient Information.

	List<Object> params = getInsufficientParamsListCreate(userDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	if (!config.checkUserRoleAndType(userDTO.getOrgType().toUpperCase(), userDTO.getUserRole().toUpperCase())) {
	    throw new SystemException(ErrorCodes.INVALID_USER_ROLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, userDTO.getAssociationId());
	}

	if (CommonUtils.userSignInNameExists(userDTO.getUserName())) {
	    throw new SystemException(ErrorCodes.USER_EXISTS, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, userDTO.getAssociationId());
	}
	// Adding check for empty association Id.
	if (StringUtils.isEmpty(userDTO.getAssociationId())) {
	    // Empty string for association id leads to foreign key conflict
	    // between user master and business master.
	    userDTO.setAssociationId(null);
	}
	// For Company user check the company association

	if (!companyExists(userDTO.getAssociationId())) {
	    throw new SystemException(ErrorCodes.INVALID_COMPANY_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, userDTO.getAssociationId());
	}

	// if (emailExists(userDTO)) {
	// throw new SystemException(ErrorCodes.EMAIL_EXISTS,
	// ConfigReader.getObject().getErrorConfig(),
	// ErrorCodes.StatusCodes.BAD_REQUEST, null);
	// }
	// String email, String displayName, String mailNickname, String
	// password
	String tempPassword = CommonUtils.generatePassword(10);// Constants.AZURE_AD_DEFAULT_PASSWORD//
							       // CommonUtils.guidGenerator(null,
							       // null);
	String userName = userDTO.getUserName().trim().toLowerCase();
	JsonObject jsonObject = CommonUtils.createUser(userDTO.getEmail(),
		userDTO.getFirstName().trim() + " " + userDTO.getLastName().trim(), userDTO.getFirstName().trim(),
		tempPassword, userName);// + "@" +
					// config.getAppConfig(Constants.AZURE_AD_COMPANY_NAME)

	JsonElement je = jsonObject.get(Constants.OBJECT_ID);
	if (je == null || StringUtils.isEmpty(je.getAsString())) {
	    throw new SystemException(ErrorCodes.ERROR_CREATING_USER_IN_AD, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
	String id = je.getAsString();
	/*
	 * String mailBody =
	 * "Please login to the application using the below credentials.\n" +
	 * "User Id : " + userName + "\n" + "Temporary Password : " + tempPassword +
	 * "\nApplication URL : " + config.getAppConfig(Constants.APP_URL);// + "@" + //
	 * config.getAppConfig(Constants.AZURE_AD_COMPANY_NAME)
	 */

	String mailBody = "Hi " + userDTO.getLastName().trim() + ",<br />";
	mailBody += "Welcome to HydroConnect, Please find below your login credentials. <br /><br />";
	mailBody += "User Id : " + userName + "<br />" + "Temporary Password : " + tempPassword + "<br />";
	mailBody += "Application URL : " + config.getAppConfig(Constants.APP_URL) + "<br /><br />";
	mailBody += "Thank you,<br /> Hydro Systems Admin";

	userDTO.setUserId(id);
	userDTO.setRoleId(config.getRoleId(userDTO.getOrgType(), userDTO.getUserRole()));

	boolean hasFullPermission = hasPermission(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE, userDTO);

	if (!hasFullPermission && !hasSiteAccess(userDTO)) {
	    throw new SystemException(ErrorCodes.INVALID_SITE_IN_LIST, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, userDTO.getAssociationId());
	}

	UserDTO createdUser = ((UserDao) hydroDao).createUser(user, userDTO, hasFullPermission);
	String welcomeSub = config.getAppConfig(Constants.WELCOME_SUBJECT);
	if (StringUtils.isEmpty(welcomeSub)) {
	    welcomeSub = Constants.WELCOME_HEADER;
	}
	CommonUtils.sendEmail(userDTO.getEmail(), welcomeSub, mailBody);
	return createdUser;
    }

    public boolean updateUser(UserDTO userDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.USER_UPDATE);
	if (!CommonUtils.userNamePattern(userDTO.getUserName())) {
	    throw new SystemException(ErrorCodes.INVALID_USER_NAME, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	boolean sameLevelUserFlag = hasPermission(Constants.PRIVILEGE_NAMES.CREATE_SAME_LEVEL_USER);
	// Validation
	ConfigReader config = ConfigReader.getObject();
	List<Object> params = getInsufficientParamsListUpdate(userDTO);
	userDTO.setClearanceLevel(config.getRoleClearanceLevel(userDTO.getOrgType(), userDTO.getUserRole()));
	if (!CommonUtils.userCreationCheck(user, userDTO, sameLevelUserFlag)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	if (!config.checkUserRoleAndType(userDTO.getOrgType().toUpperCase(), userDTO.getUserRole().toUpperCase())) {
	    throw new SystemException(ErrorCodes.INVALID_USER_ROLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, userDTO.getAssociationId());
	}
	if (!companyExists(userDTO.getAssociationId())) {
	    throw new SystemException(ErrorCodes.INVALID_COMPANY_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, userDTO.getAssociationId());
	}
	if (StringUtils.isEmpty(userDTO.getAssociationId())) {
	    userDTO.setAssociationId(null);
	}
	userDTO.setRoleId(config.getRoleId(userDTO.getOrgType(), userDTO.getUserRole()));

	boolean hasFullPermission = hasPermission(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE, userDTO);

	if (!hasFullPermission && !hasSiteAccess(userDTO)) {
	    throw new SystemException(ErrorCodes.INVALID_SITE_IN_LIST, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, userDTO.getAssociationId());
	}

	return ((UserDao) hydroDao).updateUser(user, userDTO, hasFullPermission);
    }

    private boolean hasSiteAccess(UserDTO userDTO) {
	List<SiteDTO> siteList = userDTO.getSiteList();
	if (siteList != null && siteList.size() > 0) {
	    try {
		SiteDTO siteDTO = new SiteDTO();
		siteDTO.setCompanyId(userDTO.getAssociationId());
		List<SiteDTO> userSiteList = siteBL.getSiteListForCompany(siteDTO).getSiteList();
		Set<String> siteIdList = new HashSet<>();
		// Building a set of site Ids visible to the user
		for (SiteDTO userSite : userSiteList) {
		    siteIdList.add(userSite.getSiteId());
		}
		// checking if the to be updated sites are visible to the
		// user.
		for (SiteDTO site : siteList) {
		    if (StringUtils.isEmpty(site.getSiteId()) || !siteIdList.contains(site.getSiteId())) {
			return false;
		    }
		}
	    } catch (Exception e) {
		return false;
	    }
	}
	return true;
    }

    public boolean deActivateUser(UserDTO usertDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.USER_UPDATE);
	// Validation
	ConfigReader config = ConfigReader.getObject();
	List<Object> params = getInsufficientParamsListToggle(usertDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}

	return ((UserDao) hydroDao).deActivateUser(user, usertDTO);
    }

    public boolean activateUser(UserDTO usertDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.USER_UPDATE);
	ConfigReader config = ConfigReader.getObject();
	// Validation
	List<Object> params = getInsufficientParamsListToggle(usertDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, config.getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	return ((UserDao) hydroDao).activateUser(user, usertDTO);
    }

    public boolean companyIdExists(String companyId) throws Exception {
	if (StringUtils.isEmpty(((UserDao) hydroDao).companyIdExists(companyId))) {
	    return false;
	}
	return true;
    }

    protected List<Object> getInsufficientParamsListCreate(UserDTO userDTO) {
	List<Object> params = new LinkedList<>();
	if (userDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.USER_OBJECT);

	}
	if (StringUtils.isEmpty(userDTO.getFirstName())) {
	    params.add(ErrorCodes.InsufficientParams.FIRST_NAME);
	}
	if (StringUtils.isEmpty(userDTO.getLastName())) {
	    params.add(ErrorCodes.InsufficientParams.LAST_NAME);
	}
	if (StringUtils.isEmpty(userDTO.getAddress1())) {
	    params.add(ErrorCodes.InsufficientParams.ADDRESS1);
	}
	if (StringUtils.isEmpty(userDTO.getState())) {
	    params.add(ErrorCodes.InsufficientParams.STATE);
	}
	if (StringUtils.isEmpty(userDTO.getCountry())) {
	    params.add(ErrorCodes.InsufficientParams.COUNTRY);
	}
	if (StringUtils.isEmpty(userDTO.getCity())) {
	    params.add(ErrorCodes.InsufficientParams.CITY);
	}
	if (StringUtils.isEmpty(userDTO.getZipCode())) {
	    params.add(ErrorCodes.InsufficientParams.ZIPCODE);
	}
	if (StringUtils.isEmpty(userDTO.getUserRole())) {
	    params.add(ErrorCodes.InsufficientParams.USER_ROLE);
	}
	if (StringUtils.isEmpty(userDTO.getEmail())) {
	    params.add(ErrorCodes.InsufficientParams.EMAIL);
	}
	if (!userDTO.getOrgType().equals(Constants.HYDRO)) {
	    if (userDTO.getOrgType().equals(Constants.COMPANY) && StringUtils.isEmpty(userDTO.getAssociationId())) {
		params.add(ErrorCodes.InsufficientParams.COMPANY_ID);
	    } else if (userDTO.getOrgType().equals(Constants.SITE) && StringUtils.isEmpty(userDTO.getAssociationId())) {
		params.add(ErrorCodes.InsufficientParams.SITE_ID);
	    } else if (userDTO.getOrgType().equals(Constants.ACCOUNT)
		    && StringUtils.isEmpty(userDTO.getAssociationId())) {
		params.add(ErrorCodes.InsufficientParams.ACCOUNT_ID);
	    }
	}

	return params;
    }

    protected List<Object> getInsufficientParamsListUpdate(UserDTO userDTO) {
	List<Object> params = new LinkedList<>();
	if (userDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.USER_OBJECT);

	}
	if (StringUtils.isEmpty(userDTO.getUserId())) {
	    params.add(ErrorCodes.InsufficientParams.USER_ID);
	}
	if (StringUtils.isEmpty(userDTO.getFirstName())) {
	    params.add(ErrorCodes.InsufficientParams.FIRST_NAME);
	}
	if (StringUtils.isEmpty(userDTO.getLastName())) {
	    params.add(ErrorCodes.InsufficientParams.LAST_NAME);
	}
	if (StringUtils.isEmpty(userDTO.getAddress1())) {
	    params.add(ErrorCodes.InsufficientParams.ADDRESS1);
	}
	if (StringUtils.isEmpty(userDTO.getState())) {
	    params.add(ErrorCodes.InsufficientParams.STATE);
	}
	if (StringUtils.isEmpty(userDTO.getCountry())) {
	    params.add(ErrorCodes.InsufficientParams.COUNTRY);
	}
	if (StringUtils.isEmpty(userDTO.getCity())) {
	    params.add(ErrorCodes.InsufficientParams.CITY);
	}
	if (StringUtils.isEmpty(userDTO.getZipCode())) {
	    params.add(ErrorCodes.InsufficientParams.ZIPCODE);
	}
	if (StringUtils.isEmpty(userDTO.getUserRole())) {
	    params.add(ErrorCodes.InsufficientParams.USER_ROLE);
	}
	if (!userDTO.getOrgType().equals(Constants.HYDRO)) {
	    if (userDTO.getOrgType().equals(Constants.COMPANY) && StringUtils.isEmpty(userDTO.getAssociationId())) {
		params.add(ErrorCodes.InsufficientParams.COMPANY_ID);
	    } else if (userDTO.getOrgType().equals(Constants.SITE) && StringUtils.isEmpty(userDTO.getAssociationId())) {
		params.add(ErrorCodes.InsufficientParams.SITE_ID);
	    } else if (userDTO.getOrgType().equals(Constants.ACCOUNT)
		    && StringUtils.isEmpty(userDTO.getAssociationId())) {
		params.add(ErrorCodes.InsufficientParams.ACCOUNT_ID);
	    }
	}
	return params;
    }

    protected List<Object> getInsufficientParamsListToggle(UserDTO userDTO) {
	List<Object> params = new LinkedList<>();
	if (userDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.USER_OBJECT);

	}
	if (StringUtils.isEmpty(userDTO.getUserId())) {
	    params.add(ErrorCodes.InsufficientParams.USER_ID);
	}

	return params;
    }

    public String getExistingEmailId(UserDTO userDTO) throws Exception {
	if (StringUtils.isEmpty(userDTO.getEmail())) {
	    List<Object> params = new LinkedList<>();
	    params.add(ErrorCodes.InsufficientParams.EMAIL);
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	return ((UserDao) hydroDao).emailExists(userDTO);
    }

    public boolean emailExists(UserDTO userDTO) throws Exception {
	if (StringUtils.isEmpty(getExistingEmailId(userDTO))) {
	    return false;
	}
	return true;
    }

    public UserPreferenceResponseDTO getUserPreferenceDetails() throws Exception {
	UserPreferenceResponseDTO userPreference = new UserPreferenceResponseDTO();
	userPreference.setAlertList(((UserDao) hydroDao).getUserSpecificPreference(user));
	userPreference.setUserId(user.getUserId());
	return userPreference;
    }

    public boolean updateUserPreference(UserPreferenceResponseDTO targetUser) throws SystemException, Exception {
	if (!user.getUserId().equals(targetUser.getUserId())) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	boolean response;
	if (!((UserDao) hydroDao).checkUserPreferenceExist(user))
	    response = ((UserDao) hydroDao).createUserPreferenceDetails(user, targetUser);
	else
	    response = ((UserDao) hydroDao).updateUserPreferenceDetails(user, targetUser);
	return response;
    }

}
