/**
 * 
 */
package com.hydro.api.site.dao.concrete;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.company.dao.CompanyDao;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.CompanyDTO;
import com.hydro.api.dto.ContactDTO;
import com.hydro.api.dto.ContactOperationsDTO;
import com.hydro.api.dto.FileHistoryListResponseDTO;
import com.hydro.api.dto.ObservationDTO;
import com.hydro.api.dto.ObservationListResponseDTO;
import com.hydro.api.dto.ShiftDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.SiteListResponseDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.site.dao.SiteDao;

/**
 * @author Shreyas, Srishti
 *
 */
public class HydroSiteDao extends SiteDao {

    private static final Logger LOG = LoggerFactory.getLogger(HydroSiteDao.class);

    @Override
    public SiteListResponseDTO getSiteList(UserDTO user, SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_SITE_LIST;
	    LinkedList<Object> params = new LinkedList<>();
	    if (site.getCreatedDateStart() != null && site.getCreatedDateEnd() != null) {
		query = SQLConstants.HydroAdmin.GET_SITE_LIST_CREATED_DATE_FILTER;
		params = getSiteListOnStartEndDate(site);
	    } else if (site.isSortByName()) {
		query = SQLConstants.HydroAdmin.GET_SITE_LIST_SORTED_ON_NAME;
	    }
	    database = new Database();
	    SiteListResponseDTO response = new SiteListResponseDTO();
	    List<SiteDTO> siteList = getSiteListData(database.executeQuery(query, params), user.getTimeZone());
	    response.setSiteList(siteList);
	    return response;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public SiteDTO createSite(UserDTO user, SiteDTO siteDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.CREATE_SITE;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();

	    String guid = CommonUtils.guidGenerator(null, null);
	    // INSERT INTO SITE_MASTER(`site_id`, `site_name`, `description`,
	    // `created_by`,
	    // `modified_by`,`address1`, `address2`, `country`, `city`, `state`,
	    // `zipcode`,site_owner) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
	    params.add(guid);
	    params.add(siteDTO.getSiteName());
	    params.add(siteDTO.getDescription());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(siteDTO.getAddress1());
	    params.add(siteDTO.getAddress2());
	    params.add(siteDTO.getCountry());
	    params.add(siteDTO.getCity());
	    params.add(siteDTO.getState());
	    params.add(siteDTO.getZipCode());
	    params.add(siteDTO.getAccountId());
	    params.add(siteDTO.getMetricUnit());
	    params.add(siteDTO.getCompanyId());
	    params.add(siteDTO.getWasherTurnMinute());
	    params.add(siteDTO.getWasherIdleMinute());
	    params.add(siteDTO.getWasherEffThreshold());
	    params.add(siteDTO.getTunnelTurnMinute());
	    params.add(siteDTO.getTunnelIdleMinute());
	    params.add(siteDTO.getTunnelEffThreshold());
	    params.add(siteDTO.getTimeZone());
	    params.add(siteDTO.getAlertSetting());
	    params.add(siteDTO.isStreamingEnabled());
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    if (count > 0) {
		// create contact using contactDetailsDTO.
		siteDTO = createContact(siteDTO, database, guid, user);
		siteDTO = createShift(siteDTO, database, user, guid);
		siteDTO.setSiteId(guid);
		SiteDTO site = new SiteDTO();
		site.setSiteId(guid);
		if (CompanyDao.checkCompanyPreferenceExist(siteDTO.getCompanyId())) {
		    CompanyDTO company = CompanyDao.getCompanyPreferenceDetails(user, siteDTO.getCompanyId());
		    CompanyDao.createPreference(company, database, user, guid);
		}
		database.commit();
		return site;
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean hasVisibility(UserDTO user, SiteDTO site) throws Exception {
	return true;
    }

    @Override
    public List<ContactDTO> getContactListForSite(UserDTO userDTO, SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_CONTACT_LIST_FOR_SITE;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(site.getSiteId());
	    database = new Database();
	    return getSiteContactData(database.executeQuery(query, params));
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public FileHistoryListResponseDTO getFileHistoryList(UserDTO user) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_FILE_HISTORY;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    return getFileListData(database.executeQuery(query, params), user.getTimeZone());
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean updateObservation(UserDTO user, ObservationDTO observationDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.UPDATE_OBSERVATION;
	    LOG.debug("query>>>>" + query);
	    // "update OBSERVATION_MASTER set observation=?, recommendation=?,
	    // modified_by=?
	    // where observation_id=?"
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(observationDTO.getObservation());
	    params.add(observationDTO.getRecommendation());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(observationDTO.getObservationId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    return true;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean deleteObservation(UserDTO user, ObservationDTO observationDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.DELETE_OBSERVATION;
	    LOG.debug("query>>>>" + query);
	    // delete from OBSERVATION_MASTER where observation_id =?
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(observationDTO.getObservationId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    return true;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public ObservationListResponseDTO getObservationList(UserDTO userDTO, ObservationDTO observationDTO)
	    throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_OBSERVATION_LIST;
	    // "select observation_id, observation, recommendation, created_by,
	    // created_date, modified_by, modified_date from OBSERVATION_MASTER
	    // where month=? and year=? order by created_date desc"
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(observationDTO.getSiteId());
	    params.add(observationDTO.getMonth());
	    params.add(observationDTO.getYear());
	    params.add(observationDTO.getEquipmentId());
	    database = new Database();
	    return getObservationListData(database.executeQuery(query, params), userDTO.getTimeZone());
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} finally {

	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public SiteListResponseDTO getSiteListForCompany(SiteDTO site, UserDTO user) throws Exception {
	Database database = null;
	try {

	    String query = SQLConstants.GET_SITE_LIST_PARTIAL;
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    List<String> companyIds = site.getCompanyIds();
	    if (null == companyIds) {
		query = query + "\"" + site.getCompanyId() + "\"";
	    } else {
		// adding company ids in inclause
		query = query + companyIds.stream().map(s -> "\"" + s + "\"").collect(Collectors.joining(", "));
	    }
	    if (site.isSortByName()) {
		query = query + SQLConstants.SITE_LIST_BY_SITENAME;
	    } else {
		query = query + SQLConstants.SITE_LIST_BY_CT_DATE;
	    }
	    LOG.debug("query>>>>" + query);
	    SiteListResponseDTO response = new SiteListResponseDTO();
	    response.setSiteList(getSiteListData(database.executeQuery(query, params), user.getTimeZone()));
	    return response;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public String siteNameExists(SiteDTO siteDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.SITE_NAME_EXIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(siteDTO.getSiteName().toLowerCase());
	    params.add(siteDTO.getAccountId());
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.SITE_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }

    protected SiteDTO createShift(SiteDTO siteDTO, Database database, UserDTO user, String guid) throws Exception {
	if (siteDTO.getShiftList() != null && siteDTO.getShiftList().size() > 0) {
	    List<ShiftDTO> shiftCreate = siteDTO.getShiftList();
	    String query = SQLConstants.HydroAdmin.CREATE_SHIFT;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database.createBatch(query);
	    for (ShiftDTO shiftDTO : shiftCreate) {
		String uuid = CommonUtils.guidGenerator(null, null);
		params = new LinkedList<>();
		params.add(guid);
		params.add(uuid);
		params.add(shiftDTO.getShiftName());
		params.add(shiftDTO.getStartTime());
		params.add(shiftDTO.getEndTime());
		params.add(user.getFirstName() + " " + user.getLastName());
		params.add(user.getFirstName() + " " + user.getLastName());
		database.addBatch(query, params);
	    }

	    int[] result = database.executeBatch();
	    if (result != null && result.length > 0) {
		for (int i = 0; i < result.length; i++) {
		    if (result[i] != 1) {
			throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		}
	    }

	}
	return siteDTO;
    }

    public SiteDTO createContact(SiteDTO siteDTO, Database database, String guid, UserDTO user) throws Exception {
	ContactOperationsDTO contactOperations = siteDTO.getContactOperations();
	if (contactOperations != null && contactOperations.getCreateContact() != null
		&& contactOperations.getCreateContact().size() > 0) {
	    List<ContactDTO> contactCreate = contactOperations.getCreateContact();
	    String query = SQLConstants.HydroAdmin.CREATE_CONTACT_INFO;
	    LOG.debug("query>>>>" + query);

	    // INSERT INTO CONTACT_MASTER(contact_id,business_id,
	    // site_id,email,name, number, title,created_by,
	    // modified_by) values(?,?,?,?,?,?,?,?,?)
	    LinkedList<Object> params = new LinkedList<>();
	    database.createBatch(query);
	    for (ContactDTO contactDTO : contactCreate) {
		String uuid = CommonUtils.guidGenerator(null, null);
		params = new LinkedList<>();
		params.add(uuid);
		params.add(null);
		params.add(guid);
		params.add(contactDTO.getEmail());
		params.add(contactDTO.getName());
		params.add(contactDTO.getNumber());
		params.add(contactDTO.getTitle());
		params.add(user.getFirstName() + " " + user.getLastName());
		params.add(user.getFirstName() + " " + user.getLastName());
		database.addBatch(query, params);
	    }

	    int[] result = database.executeBatch();
	    if (result != null && result.length > 0) {
		for (int i = 0; i < result.length; i++) {
		    if (result[i] != 1) {
			throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		}
	    }

	}
	return siteDTO;
    }
}
