package com.hydro.api.site.dao.concrete;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.ObservationDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.SiteListResponseDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;

public class PartialHydroSiteDao extends HydroSiteDao {

    private static final Logger LOG = LoggerFactory.getLogger(PartialHydroSiteDao.class);

    public SiteDTO createSite(UserDTO user, SiteDTO siteDTO) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    public boolean deleteObservation(UserDTO user, ObservationDTO observationDTO) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    public boolean updateObservation(UserDTO user, ObservationDTO observationDTO) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    public ObservationDTO createObservation(UserDTO userDTO, ObservationDTO observation) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    public boolean updateSite(UserDTO user, SiteDTO siteDTO, boolean siteFullEditCheck) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    @Override
    public boolean hasVisibility(UserDTO user, SiteDTO site) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.partial.GET_SITE_ASSOCIATED_TO_COMPANY;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(site.getSiteId());
	    params.add(user.getUserId());
	    ResultSet rSet = database.executeQuery(query, params);
	    if (rSet.next()) {
		return true;
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public SiteListResponseDTO getSiteList(UserDTO user, SiteDTO site) throws Exception {
	Database database = null;
	List<SiteDTO> siteList = null;
	SiteListResponseDTO response = new SiteListResponseDTO();
	database = new Database();
	try {
	    if (site.isHydroUser()) {
		String query = SQLConstants.Company.partial.GET_SITES_FOR_USER;
		LOG.debug("query>>>>" + query);
		LinkedList<Object> params = new LinkedList<>();
		params.add(user.getUserId());
		siteList = getSiteListData(database.executeQuery(query, params), user.getTimeZone());
	    } else {
		String query = SQLConstants.HydroAdmin.GET_SITE_LIST;
		LinkedList<Object> params = new LinkedList<>();
		if (site.getCreatedDateStart() != null && site.getCreatedDateEnd() != null) {
		    query = SQLConstants.HydroAdmin.GET_SITE_LIST_CREATED_DATE_FILTER;
		    params = getSiteListOnStartEndDate(site);
		} else if (site.isSortByName()) {
		    query = SQLConstants.Company.partial.GET_SITE_LIST_SORTED_ON_NAME;
		}
		siteList = getSiteListData(database.executeQuery(query, params), user.getTimeZone());
	    }
	    response.setSiteList(siteList);
	    return response;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    protected List<SiteDTO> getSiteData(ResultSet rs) throws SQLException {
	List<SiteDTO> siteList = new LinkedList<>();
	while (rs.next()) {
	    SiteDTO siteDTO = new SiteDTO();
	    siteDTO.setSiteId(rs.getString(SQLColumns.SITE_ID));
	    siteDTO.setSiteName(rs.getString(SQLColumns.SITE_NAME));
	    siteList.add(siteDTO);
	}
	return siteList;
    }

}
