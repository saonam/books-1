package com.hydro.api.reports.business;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.hydro.api.dto.reports.CycleDTO;

public class CycleDTOJsonSerializer implements JsonSerializer<CycleDTO> {

    @Override
    public JsonElement serialize(CycleDTO cycle, Type typeOfSrc, JsonSerializationContext context) {
	JsonObject jsonObj = new JsonObject();
	jsonObj.add("cycleId", context.serialize(cycle.getCycleId()));
	jsonObj.add("runTime", context.serialize(cycle.getRunTime()));
	jsonObj.add("startCycleTime", context.serialize(cycle.getStartCycleTime()));
	jsonObj.add("endCycleTime", context.serialize(cycle.getEndCycleTime()));
	jsonObj.add("formulaCost", context.serialize(cycle.getFormulaCost()));
	jsonObj.add("lbs", context.serialize(cycle.getLbs()));
	jsonObj.add("cycleCompleted", context.serialize(cycle.isCycleCompleted()));
	jsonObj.add("totalMlEstimated", context.serialize(cycle.getTotalMlEstimated()));
	jsonObj.add("totalMlReal", context.serialize(cycle.getTotalMlActual()));
	jsonObj.add("formula", context.serialize(cycle.getFormula()));
	return jsonObj;
    }

}
