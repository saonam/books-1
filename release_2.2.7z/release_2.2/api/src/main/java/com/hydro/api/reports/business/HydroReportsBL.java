package com.hydro.api.reports.business;

import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.StreamingOutput;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.math3.util.Precision;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.hydro.api.base.business.HydroBL;
import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.DailyReportUtils;
import com.hydro.api.base.common.ExcelUtils;
import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.base.dao.ElasticSearchDAO;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.Constants.REPORTS;
import com.hydro.api.constants.Constants.Units.MetricUnit;
import com.hydro.api.constants.Constants.Units.UsUnit;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.BatchDTO;
import com.hydro.api.dto.DailyReportTunnelDTO;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.EquipmentListDTO;
import com.hydro.api.dto.FormulaMetaDataDTO;
import com.hydro.api.dto.ObservationDTO;
import com.hydro.api.dto.ObservationListResponseDTO;
import com.hydro.api.dto.ProductDTO;
import com.hydro.api.dto.ShiftDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.TunnelDTO;
import com.hydro.api.dto.WasherMetaDataDTO;
import com.hydro.api.dto.reports.AlarmDTO;
import com.hydro.api.dto.reports.AlarmSummaryDTO;
import com.hydro.api.dto.reports.ChemicalDTO;
import com.hydro.api.dto.reports.ChemicalSummaryDTO;
import com.hydro.api.dto.reports.CostSummaryDTO;
import com.hydro.api.dto.reports.CycleDTO;
import com.hydro.api.dto.reports.DailyReportFormulaDTO;
import com.hydro.api.dto.reports.DailyReportRequestDTO;
import com.hydro.api.dto.reports.DailyReportResponseDTO;
import com.hydro.api.dto.reports.DailyReportWasherDTO;
import com.hydro.api.dto.reports.EquipmentReportDTO;
import com.hydro.api.dto.reports.FormulaDTO;
import com.hydro.api.dto.reports.MachineDTO;
import com.hydro.api.dto.reports.ModuleDTO;
import com.hydro.api.dto.reports.PhaseDTO;
import com.hydro.api.dto.reports.RealTimeAlarmDTO;
import com.hydro.api.dto.reports.ReportRequestDTO;
import com.hydro.api.dto.reports.TransferDTO;
import com.hydro.api.dto.reports.WarningDTO;
import com.hydro.api.dto.reports.WasherProductionDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.site.business.HydroSiteBL;
import com.hydro.api.site.dao.SiteDao;
import com.hydro.api.site.dao.concrete.CompanySiteDao;
import com.hydro.api.site.dao.concrete.HydroSiteDao;
import com.hydro.api.site.dao.concrete.PartialCompanySiteDao;
import com.hydro.api.site.dao.concrete.PartialHydroSiteDao;
import com.hydro.api.site.dao.concrete.SiteComapnySiteDao;

/**
 * Business layer for the Application.
 * 
 * @author Shreyas,Srishti
 *
 */
public class HydroReportsBL extends HydroBL {
    private static final Logger LOG = LoggerFactory.getLogger(HydroReportsBL.class);
    private HydroSiteBL siteBl;
    DateTimeFormatter dateformatter = DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT);

    public HydroReportsBL(String userId, String timeZone) throws SystemException, Exception {
	super(userId, timeZone);
	LOG.debug("In Hydro Reports BL.");

	String orgType = user.getOrgType();
	switch (orgType) {
	case Constants.HYDRO:
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new HydroSiteDao()
		    : new PartialHydroSiteDao();
	    break;
	case Constants.COMPANY:
	    hydroDao = permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE) ? new CompanySiteDao()
		    : new PartialCompanySiteDao();
	    break;
	case Constants.SITE:
	    hydroDao = (permissionList.contains(Constants.PRIVILEGE_NAMES.FULL_PRIVILEGE)) ? new CompanySiteDao()
		    : new SiteComapnySiteDao();
	    break;
	default:
	    LOG.debug("Unknown org type");
	}

	siteBl = new HydroSiteBL(userId, timeZone);
    }

    private Integer getLoadsWashed(Integer loads) {
	if (permissionList.contains(Constants.PRIVILEGE_NAMES.PRODUCTION_SUMMARY_LOADS_WASHED)) {
	    return loads;
	}
	return null;
    }

    private Long getWeightWashed(Long weight) {
	if (permissionList.contains(Constants.PRIVILEGE_NAMES.PRODUCTION_SUMMARY_LBS_WASHED)) {
	    return weight;
	}
	return null;
    }

    public WasherProductionDTO washerProductionSummary(ReportRequestDTO requestDTO) throws Exception {
	WasherProductionDTO response = washerProductionSummaryUtility(requestDTO);
	response.setSiteDTO(null);
	return response;
    }

    public WasherProductionDTO washerProductionSummaryUtility(ReportRequestDTO requestDTO) throws Exception {

	requestParameterValidation(requestDTO, Constants.PRIVILEGE_NAMES.WASHER_PRODUCTION_SUMMARY_REPORT);
	SiteDTO siteDTO = getSiteDetails(requestDTO);

	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}

	EquipmentDTO equipment = getEquipment(requestDTO, siteDTO);

	WasherProductionDTO response = null;
	if (siteDTO.isStreamingEnabled()
		&& (Constants.EquipmentType.TUNNEL).equalsIgnoreCase(equipment.getEquipmentType())) {
	    response = TunnelEdgeReportProcessing(requestDTO, siteDTO, equipment);
	} else {
	    response = mdbReportProcessing(requestDTO, siteDTO, equipment);
	}
	return response;
    }

    private EquipmentDTO getEquipment(ReportRequestDTO requestDTO, SiteDTO siteDTO) throws Exception, SystemException {

	EquipmentDTO equipment = siteBl.getEquipmentDatail(requestDTO.getEquipmentId(), siteDTO);
	/*
	 * EquipmentListDTO eq = siteBl.getEquipmentSpecification(siteDTO);
	 * List<EquipmentDTO> eqList = eq.getEquipmentList();
	 * 
	 * for (EquipmentDTO obj : eqList) { if
	 * (obj.getEquipmentId().equalsIgnoreCase(requestDTO.getEquipmentId())) {
	 * equipment = obj; break; } }
	 */
	if (equipment == null) {
	    throw new SystemException(ErrorCodes.INVALID_EQUIPMENT_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	return equipment;

    }

    private SiteDTO getSiteDetails(ReportRequestDTO requestDTO) throws Exception {
	SiteDTO siteDTO = new SiteDTO();
	siteDTO.setSiteId(requestDTO.getSiteId());
	siteDTO = ((SiteDao) hydroDao).getSiteDetails(siteDTO);
	return siteDTO;
    }

    private void requestParameterValidation(ReportRequestDTO requestDTO, String reportName) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.GENERATE_REPORT);
	permissionDeniedCheck(reportName);
	List<Object> params = getInsufficientParamsReport(requestDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}

	if (ExcelUtils.monthBetweenDate(requestDTO.getFromDate(), requestDTO.getToDate()) > 12) {
	    throw new SystemException(ErrorCodes.INVALID_DATE_RANGE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
    }

    private WasherProductionDTO mdbReportProcessing(ReportRequestDTO requestDTO, SiteDTO siteDTO,
	    EquipmentDTO equipment) throws SystemException, Exception {

	WasherProductionDTO response;
	String siteTimeZone = siteDTO.getTimeZone();
	String equipmentType = equipment.getEquipmentType();
	String reportQueryName = null;

	if (Constants.EquipmentType.TUNNEL.equalsIgnoreCase(equipmentType)) {
	    reportQueryName = Constants.REPORTS.TUNNEL_PROD_SUMMARY_QUERY;
	} else if (Constants.EquipmentType.WASHER_EXTRACTOR.equalsIgnoreCase(equipmentType)) {
	    reportQueryName = Constants.REPORTS.WE_PROD_SUMMARY_QUERY;
	}

	String query = createESQuery(requestDTO, reportQueryName, equipment.getDeviceId(), siteTimeZone);
	JsonObject responseObject = executeESQuery(requestDTO, siteDTO, query, siteTimeZone);

	JsonObject agg = handleError(responseObject);

	JsonObject machineAgg = (JsonObject) (agg).get(Constants.REPORTS.MACHINE_AGGREGATION);
	if (machineAgg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonArray unitBuckets = machineAgg.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (unitBuckets == null || unitBuckets.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	String maxDateForReport = getMaxDate(requestDTO, siteDTO, equipment);

	List<EquipmentReportDTO> equipmentList = new LinkedList<>();
	int totalProductionLoads = 0;
	int totalProductionWeight = 0;
	List<FormulaDTO> formulaReportList = new LinkedList<>();
	if (unitBuckets != null && unitBuckets.size() > 0) {
	    List<FormulaMetaDataDTO> formulaMetaList = equipment.getFormulaList();
	    Map<String, String> formulaMap = new LinkedHashMap<>();
	    for (FormulaMetaDataDTO formulaMetaDataDTO : formulaMetaList) {
		formulaMap.put(formulaMetaDataDTO.getName().trim(), formulaMetaDataDTO.getFormulaId());
		FormulaDTO formula = new FormulaDTO();
		formula.setFormulaName(formulaMetaDataDTO.getName().trim());
		formula.setFormulaId(formulaMetaDataDTO.getFormulaId());
		formula.setLoads(0);
		formula.setWashedWeight((long) 0);
		formulaReportList.add(formula);
	    }

	    for (int i = 0; i < unitBuckets.size(); i++) {
		EquipmentReportDTO unit = new EquipmentReportDTO();
		JsonObject machine = unitBuckets.get(i).getAsJsonObject();
		Integer machineSeq = machine.get(Constants.REPORTS.KEY).getAsInt();
		unit.setId(machineSeq);
		JsonObject formulaAggregation = (JsonObject) machine.get(Constants.REPORTS.FORMULA_AGGREGATION);
		JsonArray formulaJArray = formulaAggregation.getAsJsonArray(Constants.REPORTS.BUCKETS);
		List<FormulaDTO> formulaList = null;
		int totalLoads = 0;
		long totalWeight = 0;
		if (formulaJArray != null && formulaJArray.size() > 0) {
		    formulaList = new LinkedList<>();
		    for (int j = 0; j < formulaJArray.size(); j++) {
			JsonObject formulaJson = formulaJArray.get(j).getAsJsonObject();
			JsonObject canal = null;
			String formulaName = formulaJson.get(Constants.REPORTS.KEY).getAsString();
			if (!StringUtils.isEmpty(formulaName)) {
			    formulaName = formulaName.trim();
			    FormulaDTO formula = new FormulaDTO();
			    formula.setFormulaName(formulaName.toUpperCase());
			    if (StringUtils.isEmpty(formulaMap.get(formulaName))) {
				formulaMap.put(formulaName, formulaName);
				FormulaDTO tempFormula = new FormulaDTO();
				tempFormula.setFormulaId(formulaName);
				tempFormula.setFormulaName(formulaName);
				tempFormula.setLoads(0);
				tempFormula.setWashedWeight((long) 0);
				formulaReportList.add(tempFormula);
			    }
			    formula.setFormulaId(formulaMap.get(formulaName));
			    long weight = 0;
			    int load = 0;
			    try {
				/**
				 * {weight} should be initialized based upon {EquipmentType}, because a new
				 * {canal_aggregator} has been introduced for TUNNEL. Earlier, the {SUM_REAL}
				 * was in the same tree. Now, then, if it is {WASHER_EXTRACTOR}, then get it
				 * from the {formulaJson}
				 */

				if (Constants.EquipmentType.WASHER_EXTRACTOR.equalsIgnoreCase(equipmentType)) {
				    weight = ((JsonObject) formulaJson.get(Constants.REPORTS.SUM_REAL))
					    .get(Constants.REPORTS.VALUE).getAsLong();
				    load = ((JsonArray) ((JsonObject) formulaJson
					    .get(Constants.REPORTS.CYCLE_AGGREGATION)).get(Constants.REPORTS.BUCKETS))
						    .size();
				} else {
				    canal = ((JsonArray) ((JsonObject) formulaJson
					    .get(Constants.REPORTS.CANAL_AGGREGATION)).get(Constants.REPORTS.BUCKETS))
						    .get(0).getAsJsonObject();
				    // If it is {TUNNEL}, then get it from the
				    // {canal}.
				    weight = ((JsonObject) canal.get(Constants.REPORTS.SUM_REAL))
					    .get(Constants.REPORTS.VALUE).getAsLong();

				    load = ((JsonArray) ((JsonObject) canal.get(Constants.REPORTS.PUMP_AGGREGATION))
					    .get(Constants.REPORTS.BUCKETS)).get(0).getAsJsonObject()
						    .get(Constants.REPORTS.DOC_COUNT).getAsInt();
				}
				// weight = CommonUtils.convertKgToLbs(weight);
				formula.setWashedWeight(weight);
				totalWeight += weight;

			    } catch (Exception e) {
				LOG.error("Error Fetching load count for FOrmula : " + formulaName + " Error: "
					+ e.getMessage());
				LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			    }
			    for (FormulaDTO rootFormula : formulaReportList) {
				if (!StringUtils.isEmpty(rootFormula.getFormulaName())
					&& rootFormula.getFormulaName().equalsIgnoreCase(formulaName)) {
				    rootFormula.setLoads(getLoadsWashed(rootFormula.getLoads() + load));
				    rootFormula
					    .setWashedWeight(getWeightWashed(rootFormula.getWashedWeight() + weight));
				}

			    }
			    formula.setLoads(load);
			    totalLoads += load;
			    if (!StringUtils.isEmpty(formulaName)) {
				formulaList.add(formula);
			    }
			}
		    }
		}

		int equipmentSeq;
		if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.WASHER_EXTRACTOR)) {
		    List<WasherMetaDataDTO> washerList = equipment.getWasherList();
		    for (WasherMetaDataDTO washer : washerList) {
			equipmentSeq = 0;
			try {
			    equipmentSeq = Integer.parseInt(washer.getLm2Seq());
			} catch (Exception e) {
			    LOG.error("Invalid lm2 sequence : " + e.getMessage());
			}
			if (equipmentSeq == unit.getId()) {
			    unit.setName(washer.getName().toUpperCase());
			    unit.setCapacity(washer.getLoad());
			    unit.setLm2Seq(washer.getLm2Seq());
			    break;
			}
		    }
		} else {
		    List<TunnelDTO> tunnelList = equipment.getTunnelList();
		    for (TunnelDTO tunnel : tunnelList) {
			equipmentSeq = 0;
			try {
			    equipmentSeq = Integer.parseInt(tunnel.getLm2Seq());
			} catch (Exception e) {
			    LOG.error("Invalid lm2 sequence : " + e.getMessage());
			}
			if (equipmentSeq == unit.getId()) {
			    unit.setName(tunnel.getName());
			    unit.setCapacity(tunnel.getLoad());
			    unit.setLm2Seq(tunnel.getLm2Seq());
			    break;
			}
		    }
		}

		totalProductionWeight += totalWeight;
		totalProductionLoads += totalLoads;
		unit.setTotalProduction(totalWeight);
		unit.setTotalLoads(totalLoads);
		if (CollectionUtils.isNotEmpty(formulaList)) {
		    formulaList.sort(Comparator.comparing(FormulaDTO::getFormulaName));
		}
		unit.setFormulaList(formulaList);
		unit.setName(unit.getLm2Seq() + "." + unit.getName());
		equipmentList.add(unit);
	    }
	}

	populateEquipmentDTO(equipmentList, totalProductionLoads, totalProductionWeight);

	response = populateWasherProductionDTO(requestDTO, siteDTO, maxDateForReport, equipmentList,
		totalProductionLoads, totalProductionWeight, formulaReportList, null, siteTimeZone);
	return response;
    }

    private WasherProductionDTO populateWasherProductionDTO(ReportRequestDTO requestDTO, SiteDTO siteDTO,
	    String maxDateForReport, List<EquipmentReportDTO> equipmentList, int totalProductionLoads,
	    int totalProductionWeight, List<FormulaDTO> formulaReportList, List<String> avgCalculatedForMonths,
	    String siteTimeZone) {

	formulaReportList.sort(Comparator.comparing(FormulaDTO::getWashedWeight).reversed());
	equipmentList.sort(Comparator.comparing(EquipmentReportDTO::getId));

	WasherProductionDTO response = new WasherProductionDTO();
	response.setMonth(requestDTO.getMonth());
	response.setYear(requestDTO.getYear());
	response.setSiteId(requestDTO.getSiteId());
	response.setUnitId(requestDTO.getEquipmentId());
	response.setTotalProduction(totalProductionWeight);
	response.setTotalLoads(totalProductionLoads);
	response.setEquipmentList(equipmentList);
	response.setFormulaList(formulaReportList);
	response.setMaxDate(maxDateForReport);
	response.setMinDate(requestDTO.getFromDate());
	response.setSiteDTO(siteDTO);
	response.setAvgCalculatedForMonths(avgCalculatedForMonths);
	return response;
    }

    private WasherProductionDTO TunnelEdgeReportProcessing(ReportRequestDTO requestDTO, SiteDTO siteDTO,
	    EquipmentDTO equipment) throws SystemException, Exception {

	WasherProductionDTO response;
	String siteTimeZone = siteDTO.getTimeZone();
	String query = createESQuery(requestDTO, Constants.REPORTS.TUNNEL_EDGE_PROD_SUMMARY_QUERY,
		equipment.getDeviceId(), siteTimeZone);

	StringBuilder sb = getBatchIds(requestDTO, siteDTO, equipment, siteTimeZone);

	query = query.replace(Constants.BATCH_IDS_VAL, sb);

	JsonObject responseObject = executeESQuery(requestDTO, siteDTO, query, siteTimeZone);

	JsonObject agg = handleError(responseObject);

	Map<String, String> formulaMap = getFormulaMap(equipment);
	List<FormulaDTO> formulaReportList = createFormulaReportList(equipment.getFormulaList());

	JsonObject formulaAggregation = (JsonObject) (agg).get(Constants.REPORTS.FORMULA_AGGREGATION);
	if (formulaAggregation == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonArray formulaJArray = formulaAggregation.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (formulaJArray == null || formulaJArray.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	String maxDateForReport = getMaxDate(requestDTO, siteDTO, equipment);

	EquipmentReportDTO unit = new EquipmentReportDTO();
	unit.setId(equipment.getLm2Seq());
	List<FormulaDTO> formulaList = null;
	List<EquipmentReportDTO> equipmentList = new LinkedList<>();
	int totalProductionLoads = 0;
	int totalProductionWeight = 0;
	int totalLoads = 0;
	long totalWeight = 0;
	formulaList = new LinkedList<>();
	for (int j = 0; j < formulaJArray.size(); j++) {
	    JsonObject formulaJson = formulaJArray.get(j).getAsJsonObject();
	    JsonObject canal = null;
	    String formulaName = formulaJson.get(Constants.REPORTS.KEY).getAsString();
	    if (!StringUtils.isEmpty(formulaName)) {
		formulaName = formulaName.trim();
		FormulaDTO formula = new FormulaDTO();
		formula.setFormulaName(formulaName.toUpperCase());
		if (StringUtils.isEmpty(formulaMap.get(formulaName))) {
		    formulaMap.put(formulaName, formulaName);
		    FormulaDTO tempFormula = new FormulaDTO();
		    tempFormula.setFormulaId(formulaName);
		    tempFormula.setFormulaName(formulaName);
		    tempFormula.setLoads(0);
		    tempFormula.setWashedWeight((long) 0);
		    formulaReportList.add(tempFormula);
		}
		formula.setFormulaId(formulaMap.get(formulaName));
		long weight = 0;
		int load = 0;
		try {// avg_real_kg

		    weight = ((JsonObject) formulaJson.get(Constants.REPORTS.SUM_REAL)).get(Constants.REPORTS.VALUE)
			    .getAsLong();

		    formula.setWashedWeight(weight);
		    totalWeight += weight;

		    load = ((JsonArray) ((JsonObject) formulaJson.get(Constants.REPORTS.BATCH_AGGREGATION))
			    .get(Constants.REPORTS.BUCKETS)).size();

		} catch (Exception e) {
		    LOG.error("Error Fetching load count for FOrmula : " + formulaName + " Error: " + e.getMessage());
		    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		}
		for (FormulaDTO rootFormula : formulaReportList) {
		    if (!StringUtils.isEmpty(rootFormula.getFormulaName())
			    && rootFormula.getFormulaName().equalsIgnoreCase(formulaName)) {
			rootFormula.setLoads(getLoadsWashed(rootFormula.getLoads() + load));
			rootFormula.setWashedWeight(getWeightWashed(rootFormula.getWashedWeight() + weight));
		    }

		}
		formula.setLoads(load);
		totalLoads += load;
		if (!StringUtils.isEmpty(formulaName)) {
		    formulaList.add(formula);
		}

	    }
	}

	List<TunnelDTO> tunnelList = equipment.getTunnelList();
	for (TunnelDTO tunnel : tunnelList) {

	    unit.setName(tunnel.getName());
	    unit.setCapacity(tunnel.getLoad());
	    unit.setLm2Seq(tunnel.getLm2Seq());
	}

	totalProductionWeight += totalWeight;
	totalProductionLoads += totalLoads;
	unit.setTotalProduction(totalWeight);
	unit.setTotalLoads(totalLoads);
	formulaList.sort(Comparator.comparing(FormulaDTO::getFormulaName));
	unit.setFormulaList(formulaList);
	unit.setName(unit.getLm2Seq() + "." + unit.getName());
	equipmentList.add(unit);

	// JsonArray jArray = ReportUtils.aggregationsQuery(aggregationsObject);

	populateEquipmentDTO(equipmentList, totalProductionLoads, totalProductionWeight);

	response = populateWasherProductionDTO(requestDTO, siteDTO, maxDateForReport, equipmentList,
		totalProductionLoads, totalProductionWeight, formulaReportList, null, siteTimeZone);

	return response;

    }

    private StringBuilder getBatchIds(ReportRequestDTO requestDTO, SiteDTO siteDTO, EquipmentDTO equipment,
	    String siteTimeZone) throws SystemException, Exception {
	String processedLoadsQuery = createESQuery(requestDTO, Constants.REPORTS.GET_PROCESSED_LOADS_FOR_TUNNEL,
		equipment.getDeviceId(), siteTimeZone);

	JsonObject responseObjectForProcessedLoads = executeESQuery(requestDTO, siteDTO, processedLoadsQuery,
		siteTimeZone);
	JsonObject agg = handleError(responseObjectForProcessedLoads);

	JsonObject batcgAgg = (JsonObject) (agg).get(Constants.REPORTS.BATCH_AGGREGATION);
	if (batcgAgg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	JsonArray batchBuckets = batcgAgg.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (batchBuckets == null || batchBuckets.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	StringBuilder sb = new StringBuilder();
	if (batchBuckets != null && batchBuckets.size() > 0) {
	    for (int i = 0; i < batchBuckets.size(); i++) {
		JsonObject formulaJson = batchBuckets.get(i).getAsJsonObject();
		sb.append(formulaJson.get(Constants.REPORTS.KEY).getAsString()).append("\",\"");
	    }
	}
	return sb;
    }

    private StringBuilder getThreemothsBatchIds(ReportRequestDTO requestDTO, SiteDTO siteDTO, EquipmentDTO equipment,
	    String siteTimeZone) throws SystemException, Exception {
	String processedLoadsQuery = createAvgMonthESQuery(requestDTO, Constants.REPORTS.GET_PROCESSED_LOADS_FOR_TUNNEL,
		equipment, 3, siteTimeZone);
	int avgReferenceMonth = 3;

	ConfigReader configReader = ConfigReader.getObject();

	JsonObject responseObjectForProcessedLoads = executeAvgMonthESQuery(requestDTO, avgReferenceMonth,
		processedLoadsQuery, configReader, siteTimeZone);
	JsonObject agg = handleError(responseObjectForProcessedLoads);

	JsonObject batcgAgg = (JsonObject) (agg).get(Constants.REPORTS.BATCH_AGGREGATION);
	if (batcgAgg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	JsonArray batchBuckets = batcgAgg.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (batchBuckets == null || batchBuckets.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	StringBuilder sb = new StringBuilder();
	if (batchBuckets != null && batchBuckets.size() > 0) {
	    for (int i = 0; i < batchBuckets.size(); i++) {
		JsonObject formulaJson = batchBuckets.get(i).getAsJsonObject();
		sb.append(formulaJson.get(Constants.REPORTS.KEY).getAsString()).append("\",\"");
	    }
	}
	return sb;
    }

    private JsonObject executeESQuery(ReportRequestDTO requestDTO, SiteDTO siteDTO, String query, String siteTimeZone)
	    throws Exception {
	ConfigReader configReader = ConfigReader.getObject();
	ElasticSearchDAO esDAO = new ElasticSearchDAO(false, configReader.getEsConfig());
	JsonObject responseObject = esDAO.executeQuery(query,
		ReportUtils.getExistingIndices(
			CommonUtils.convertZonedDateToUTCDate(requestDTO.getFromDate(), siteTimeZone, true, false),
			CommonUtils.convertZonedDateToUTCDate(requestDTO.getToDate(), siteTimeZone, false, false),
			siteDTO),
		configReader.getAppConfig(Constants.ES_TYPE));
	if (esDAO != null)
	    esDAO.closeJestClient();
	return responseObject;
    }

    private List<FormulaDTO> createFormulaReportList(List<FormulaMetaDataDTO> formulaMetaList) {
	List<FormulaDTO> formulaReportList = new LinkedList<>();
	for (FormulaMetaDataDTO formulaMetaDataDTO : formulaMetaList) {
	    FormulaDTO formula = new FormulaDTO();
	    formula.setFormulaName(formulaMetaDataDTO.getName().trim());
	    formula.setFormulaId(formulaMetaDataDTO.getFormulaId());
	    formula.setLoads(0);
	    formula.setWashedWeight((long) 0);
	    formulaReportList.add(formula);
	}
	return formulaReportList;
    }

    private String createESQuery(ReportRequestDTO requestDTO, String reportQueryName, String deviceId,
	    String siteTimeZone) throws SystemException, Exception {
	String query = null;
	query = ReportUtils.getQuery(reportQueryName);
	if (StringUtils.isEmpty(query)) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}

	query = query.replace(Constants.FROM_DATE_VAL,
		CommonUtils.convertZonedDateToUTCDate(requestDTO.getFromDate(), siteTimeZone, true, true));

	query = query.replace(Constants.TO_DATE_VAL,
		CommonUtils.convertZonedDateToUTCDate(requestDTO.getToDate(), siteTimeZone, false, true));
	query = query.replace(Constants.DEVICE_ID_VAL, deviceId);

	LOG.info("QueryTOExecute" + query);
	return query;

    }

    private JsonObject handleError(JsonObject responseObject) throws Exception {
	handleEsError(responseObject);
	JsonObject agg = (JsonObject) responseObject.get(Constants.REPORTS.AGGREGATIONS);
	if (agg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	return agg;
    }

    private String getMaxDate(ReportRequestDTO requestDTO, SiteDTO siteDTO, EquipmentDTO equipment)
	    throws SystemException, Exception {
	String maxDateForReport = null;

	String query = createESQuery(requestDTO, Constants.REPORTS.MAX_EVENT_DATE_QUERY, equipment.getDeviceId(),
		siteDTO.getTimeZone());

	ConfigReader configReader = ConfigReader.getObject();
	JsonObject responseObject = executeESQuery(requestDTO, siteDTO, query, siteDTO.getTimeZone());

	handleEsError(responseObject);

	JsonObject maxDate = (JsonObject) ((JsonObject) responseObject.get(Constants.REPORTS.AGGREGATIONS))
		.get(Constants.REPORTS.MAX_DATE);

	if (maxDate != null) {
	    maxDateForReport = CommonUtils.convertFromUtcEpochToZoneDate(maxDate.get(Constants.VALUE).getAsLong(),
		    siteDTO.getTimeZone());
	}
	return maxDateForReport;
    }

    private void populateEquipmentDTO(List<EquipmentReportDTO> equipmentList, int totalProductionLoads,
	    int totalProductionWeight) {
	for (EquipmentReportDTO e : equipmentList) {
	    int loads = e.getTotalLoads();
	    long weight = e.getTotalProduction();
	    double loadContribution = (((double) loads / (double) totalProductionLoads) * 100);
	    double weightContribution = (((double) weight / (double) totalProductionWeight) * 100);
	    e.setTotalLoadsContribution(Precision.round(loadContribution, 2));
	    e.setTotalProductionContribution(Precision.round(weightContribution, 2));
	}
    }

    public ChemicalSummaryDTO chemicalSummary(ReportRequestDTO requestDTO) throws Exception {
	ChemicalSummaryDTO response = chemicalSummaryUtility(requestDTO);
	response.setSiteDTO(null);
	return response;
    }

    public ChemicalSummaryDTO chemicalSummaryUtility(ReportRequestDTO requestDTO) throws Exception {

	requestParameterValidation(requestDTO, Constants.PRIVILEGE_NAMES.CHEMICAL_SUMMARY_REPORT);
	SiteDTO siteDTO = getSiteDetails(requestDTO);
	EquipmentDTO equipment = getEquipment(requestDTO, siteDTO);
	HashMap<String, ProductDTO> prodMap = new HashMap<>();
	List<ProductDTO> prodList = equipment.getProductList();
	if (prodList != null) {
	    for (ProductDTO productDTO : prodList) {
		if (productDTO != null && !StringUtils.isEmpty(productDTO.getName())) {
		    prodMap.put(productDTO.getName().trim(), productDTO);
		}
	    }
	}
	String siteTimeZone = siteDTO.getTimeZone();
	String query = createESQuery(requestDTO, Constants.REPORTS.CHEMICAL_SUMMARY_QUERY, equipment.getDeviceId(),
		siteTimeZone);
	JsonObject responseObject = executeESQuery(requestDTO, siteDTO, query, siteTimeZone);

	handleEsError(responseObject);
	ConfigReader configReader = ConfigReader.getObject();
	JsonObject agg = (JsonObject) responseObject.get(Constants.REPORTS.AGGREGATIONS);
	if (agg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonObject productAgg = (JsonObject) (agg).get(Constants.REPORTS.PRODUCT_AGGREGATION);
	if (productAgg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonArray productBuckets = productAgg.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (productBuckets == null || productBuckets.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	String maxDateForReport = getMaxDate(requestDTO, siteDTO, equipment);

	List<ChemicalDTO> chemicalList = new LinkedList<>();
	List<FormulaDTO> formulaReportList = new LinkedList<>();
	if (productBuckets != null && productBuckets.size() > 0) {
	    List<FormulaMetaDataDTO> formulaMetaList = equipment.getFormulaList();
	    Map<String, String> formulaMap = new LinkedHashMap<>();
	    for (FormulaMetaDataDTO formulaMetaDataDTO : formulaMetaList) {
		formulaMap.put(formulaMetaDataDTO.getName().trim(), formulaMetaDataDTO.getFormulaId());
		FormulaDTO formula = new FormulaDTO();
		formula.setFormulaName(formulaMetaDataDTO.getName().toUpperCase());
		formula.setFormulaId(formulaMetaDataDTO.getFormulaId());
		formulaReportList.add(formula);
	    }
	    for (int i = 0; i < productBuckets.size(); i++) {
		ChemicalDTO chem = new ChemicalDTO();
		JsonObject prod = productBuckets.get(i).getAsJsonObject();
		String prodName = prod.get(Constants.REPORTS.KEY).getAsString();
		prodName = ReportUtils.getformulaName(prodName);
		chem.setName(prodName.toUpperCase());
		String productName = CommonUtils.removeAfterLastOccurence(prodName, Constants.UNDERSCORE);
		if (!StringUtils.isEmpty(productName)) {
		    productName = productName.trim();
		}
		ProductDTO product = prodMap.get(productName);
		if (null != product) {
		    chem.setLm2Seq(product.getLm2Seq());
		} else {
		    chem.setLm2Seq(Constants.DEFAULT_LM2SEQ);
		}
		Double totalErrorUsage = 0.0;
		double totalEstimatedUsage = 0.0;
		double totalActualUsage = 0.0;

		JsonObject formulaAggregation = (JsonObject) prod.get(Constants.REPORTS.FORMULA_AGGREGATION);
		JsonArray formulaJArray = formulaAggregation.getAsJsonArray(Constants.REPORTS.BUCKETS);
		List<FormulaDTO> formulaList = null;

		if (formulaJArray != null && formulaJArray.size() > 0) {
		    formulaList = new LinkedList<>();
		    for (int j = 0; j < formulaJArray.size(); j++) {
			JsonObject formulaJson = formulaJArray.get(j).getAsJsonObject();
			String formulaName = formulaJson.get(Constants.REPORTS.KEY).getAsString();
			if (!StringUtils.isEmpty(formulaName)) {
			    formulaName = formulaName.trim();
			    FormulaDTO formula = new FormulaDTO();
			    formula.setFormulaName(formulaName);
			    if (StringUtils.isEmpty(formulaMap.get(formulaName))) {
				formulaMap.put(formulaName, formulaName);
				FormulaDTO tempFormula = new FormulaDTO();
				tempFormula.setFormulaId(formulaName);
				tempFormula.setFormulaName(formulaName);
				formulaReportList.add(tempFormula);
			    }
			    formula.setFormulaId(formulaMap.get(formulaName));
			    Double errorUsage = 0.0;

			    double sumEstimated = ((JsonObject) formulaJson.get(Constants.REPORTS.SUM_ESTIMATED_ML))
				    .get(Constants.REPORTS.VALUE).getAsDouble();
			    double sumReal = ((JsonObject) formulaJson.get(Constants.REPORTS.SUM_ML))
				    .get(Constants.REPORTS.VALUE).getAsDouble();
			    int concentrationPercent = 100;
			    int format = 0;
			    if (product != null) {
				concentrationPercent = product.getConcentration();
			    }
			    if (product != null) {
				format = product.getFormat();
			    }
			    int defaultFormatSolid = 0;
			    try {
				defaultFormatSolid = Integer
					.parseInt(configReader.getAppConfig(Constants.SOLID_PRODUCT_FORMAT));
			    } catch (Exception e) {
				LOG.error(
					"Error extracting SOLID_PRODUCT_FORMAT from config. Please set a valid value. "
						+ e.getMessage());
			    }
			    // If the given product is not solid then use the
			    // full concentration. Else use the specified
			    // concentration.
			    if (format != defaultFormatSolid) {
				concentrationPercent = 100;
			    }
			    if (siteDTO.isStreamingEnabled()) {
				sumEstimated = CommonUtils.realTimeConvertMlToGal(sumEstimated, siteDTO.getMetricUnit(),
					concentrationPercent);
				sumReal = CommonUtils.realTimeConvertMlToGal(sumReal, siteDTO.getMetricUnit(),
					concentrationPercent);
			    } else {
				sumEstimated = CommonUtils.mdbConvertMlToGal(sumEstimated, siteDTO.getMetricUnit(),
					concentrationPercent);
				sumReal = CommonUtils.mdbConvertMlToGal(sumReal, siteDTO.getMetricUnit(),
					concentrationPercent);
			    }
			    sumEstimated = Precision.round(sumEstimated, 3);
			    sumReal = Precision.round(sumReal, 3);
			    // Tweaking the data to show actual value is lesser
			    // or equal to the estimated value.
			    if (sumReal > sumEstimated) {
				sumReal = sumEstimated;
			    }
			    // To fetch the error percent.
			    if (sumEstimated != 0.0) {
				errorUsage = ((sumReal - sumEstimated) / sumEstimated) * 100;
			    }
			    totalEstimatedUsage += sumEstimated;
			    totalActualUsage += sumReal;
			    formula.setEstimatedUsage(Precision.round(sumEstimated, 3));
			    formula.setActualUsage(Precision.round(sumReal, 3));
			    formula.setErrorUsage(Precision.round(errorUsage, 3));
			    if (!StringUtils.isEmpty(formulaName)) {
				formulaList.add(formula);
			    }

			}
		    }
		}
		totalEstimatedUsage = Precision.round(totalEstimatedUsage, 3);
		totalActualUsage = Precision.round(totalActualUsage, 3);
		// Tweaking the data to show actual value is lesser or equal to
		// the estimated value.
		if (totalActualUsage > totalEstimatedUsage) {
		    totalActualUsage = totalEstimatedUsage;
		}
		if (totalEstimatedUsage != 0.0) {
		    totalErrorUsage = ((totalActualUsage - totalEstimatedUsage) / totalEstimatedUsage) * 100;
		}
		chem.setTotalEstimatedUsage(totalEstimatedUsage);
		chem.setTotalActualUsage(totalActualUsage);
		chem.setTotalErrorUsage(Precision.round(totalErrorUsage, 3));
		if (CollectionUtils.isNotEmpty(formulaList)) {
		    formulaList.sort(Comparator.comparing(FormulaDTO::getFormulaName));
		}
		chem.setFormulaList(formulaList);
		chemicalList.add(chem);
	    }
	}
	formulaReportList.sort(Comparator.comparing(FormulaDTO::getFormulaName));
	ChemicalSummaryDTO response = new ChemicalSummaryDTO();
	response.setMonth(requestDTO.getMonth());
	response.setYear(requestDTO.getYear());
	response.setSiteId(requestDTO.getSiteId());
	response.setUnitId(requestDTO.getEquipmentId());
	// chemicalList.sort(Comparator.comparing(ChemicalDTO::getName));
	chemicalList.sort(Comparator.comparing(ChemicalDTO::getLm2Seq).thenComparing(ChemicalDTO::getName));
	response.setChemicalList(chemicalList);
	response.setFormulaList(formulaReportList);
	chemicalEstimatedFilter(response);
	chemicalActualUsageFilter(response);
	response.setMaxDate(maxDateForReport);
	response.setMinDate(requestDTO.getFromDate());

	response.setSiteDTO(siteDTO);
	return response;
    }

    public ChemicalSummaryDTO chemicalSummaryAvgForPrevMonth(ReportRequestDTO requestDTO) throws Exception {
	int avgReferenceMonth = requestDTO.getAvgReference();
	requestParameterValidationForAvgperMonth(requestDTO, Constants.PRIVILEGE_NAMES.CHEMICAL_SUMMARY_REPORT);
	if (avgReferenceMonth == 0) {
	    avgReferenceMonth = 3;
	}

	SiteDTO siteDTO = getSiteDetails(requestDTO);
	String siteTimeZone = siteDTO.getTimeZone();
	EquipmentDTO equipment = getEquipment(requestDTO, siteDTO);
	HashMap<String, ProductDTO> prodMap = new HashMap<>();
	List<ProductDTO> prodList = equipment.getProductList();
	if (prodList != null) {
	    for (ProductDTO productDTO : prodList) {
		if (productDTO != null && !StringUtils.isEmpty(productDTO.getName())) {
		    prodMap.put(productDTO.getName().trim(), productDTO);
		}
	    }
	}

	String query = null;

	query = createAvgMonthESQuery(requestDTO, Constants.REPORTS.CHEMICAL_SUMMARY_QUERY, equipment,
		avgReferenceMonth, siteTimeZone);

	ConfigReader configReader = ConfigReader.getObject();

	JsonObject responseObject = executeAvgMonthESQuery(requestDTO, avgReferenceMonth, query, configReader,
		siteTimeZone);

	handleEsError(responseObject);
	JsonObject agg = (JsonObject) responseObject.get(Constants.REPORTS.AGGREGATIONS);
	if (agg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	// check if any of the index present in indexList contributed in
	// creating response, if not then not further calculations are required.
	JsonObject contributedIndicesForResponse = (JsonObject) (agg).get(Constants.INDEX_AGGREGATION);
	JsonArray contributedIndicesForResponseArray = contributedIndicesForResponse
		.getAsJsonArray(Constants.REPORTS.BUCKETS);
	int contributedIndicesSize = contributedIndicesForResponseArray.size();
	List<String> avgCalculatedForMonths = new LinkedList<>();

	if (contributedIndicesSize > 0) {
	    for (int i = 0; i < contributedIndicesForResponseArray.size(); i++) {
		JsonObject indexJson = contributedIndicesForResponseArray.get(i).getAsJsonObject();
		String key = indexJson.get(Constants.REPORTS.KEY).getAsString();
		String[] keyValue = key.split("-");
		String monthYearValue = Month.of(Integer.parseInt(keyValue[2])).name() + "-" + keyValue[3];
		avgCalculatedForMonths.add(monthYearValue);
	    }
	}

	JsonObject productAgg = (JsonObject) (agg).get(Constants.REPORTS.PRODUCT_AGGREGATION);
	if (productAgg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonArray productBuckets = productAgg.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (productBuckets == null || productBuckets.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	List<ChemicalDTO> chemicalList = new LinkedList<>();
	List<FormulaDTO> formulaReportList = new LinkedList<>();
	if (productBuckets != null && productBuckets.size() > 0) {
	    List<FormulaMetaDataDTO> formulaMetaList = equipment.getFormulaList();
	    Map<String, String> formulaMap = new LinkedHashMap<>();
	    for (FormulaMetaDataDTO formulaMetaDataDTO : formulaMetaList) {
		formulaMap.put(formulaMetaDataDTO.getName().trim(), formulaMetaDataDTO.getFormulaId());
		FormulaDTO formula = new FormulaDTO();
		formula.setFormulaName(formulaMetaDataDTO.getName().toUpperCase());
		formula.setFormulaId(formulaMetaDataDTO.getFormulaId());
		formulaReportList.add(formula);
	    }
	    for (int i = 0; i < productBuckets.size(); i++) {
		ChemicalDTO chem = new ChemicalDTO();
		JsonObject prod = productBuckets.get(i).getAsJsonObject();
		String prodName = prod.get(Constants.REPORTS.KEY).getAsString();
		prodName = ReportUtils.getformulaName(prodName);
		chem.setName(prodName.toUpperCase());
		String productName = CommonUtils.removeAfterLastOccurence(prodName, Constants.UNDERSCORE);
		if (!StringUtils.isEmpty(productName)) {
		    productName = productName.trim();
		}
		ProductDTO product = prodMap.get(productName);
		Double totalErrorUsage = 0.0;
		double totalEstimatedUsage = 0.0;
		double totalActualUsage = 0.0;

		JsonObject formulaAggregation = (JsonObject) prod.get(Constants.REPORTS.FORMULA_AGGREGATION);
		JsonArray formulaJArray = formulaAggregation.getAsJsonArray(Constants.REPORTS.BUCKETS);
		List<FormulaDTO> formulaList = null;

		if (formulaJArray != null && formulaJArray.size() > 0) {
		    formulaList = new LinkedList<>();
		    for (int j = 0; j < formulaJArray.size(); j++) {
			JsonObject formulaJson = formulaJArray.get(j).getAsJsonObject();
			String formulaName = formulaJson.get(Constants.REPORTS.KEY).getAsString();
			if (!StringUtils.isEmpty(formulaName)) {
			    formulaName = formulaName.trim();
			    FormulaDTO formula = new FormulaDTO();
			    formula.setFormulaName(formulaName);
			    if (StringUtils.isEmpty(formulaMap.get(formulaName))) {
				formulaMap.put(formulaName, formulaName);
				FormulaDTO tempFormula = new FormulaDTO();
				tempFormula.setFormulaId(formulaName);
				tempFormula.setFormulaName(formulaName);
				formulaReportList.add(tempFormula);
			    }
			    formula.setFormulaId(formulaMap.get(formulaName));
			    Double errorUsage = 0.0;

			    double sumEstimated = ((JsonObject) formulaJson.get(Constants.REPORTS.SUM_ESTIMATED_ML))
				    .get(Constants.REPORTS.VALUE).getAsDouble();
			    double sumReal = ((JsonObject) formulaJson.get(Constants.REPORTS.SUM_ML))
				    .get(Constants.REPORTS.VALUE).getAsDouble();
			    int concentrationPercent = 100;
			    int format = 0;
			    if (product != null) {
				concentrationPercent = product.getConcentration();
			    }
			    if (product != null) {
				format = product.getFormat();
			    }
			    int defaultFormatSolid = 0;
			    try {
				defaultFormatSolid = Integer
					.parseInt(configReader.getAppConfig(Constants.SOLID_PRODUCT_FORMAT));
			    } catch (Exception e) {
				LOG.error(
					"Error extracting SOLID_PRODUCT_FORMAT from config. Please set a valid value. "
						+ e.getMessage());
			    }
			    // If the given product is not solid then use the
			    // full concentration. Else use the specified
			    // concentration.
			    if (format != defaultFormatSolid) {
				concentrationPercent = 100;
			    }
			    if (siteDTO.isStreamingEnabled()) {
				sumEstimated = CommonUtils.realTimeConvertMlToGal(sumEstimated, siteDTO.getMetricUnit(),
					concentrationPercent);
				sumReal = CommonUtils.realTimeConvertMlToGal(sumReal, siteDTO.getMetricUnit(),
					concentrationPercent);
			    } else {
				sumEstimated = CommonUtils.mdbConvertMlToGal(sumEstimated, siteDTO.getMetricUnit(),
					concentrationPercent);
				sumReal = CommonUtils.mdbConvertMlToGal(sumReal, siteDTO.getMetricUnit(),
					concentrationPercent);
			    }
			    sumEstimated = Precision.round(sumEstimated, 3);
			    sumReal = Precision.round(sumReal, 3);
			    // Tweaking the data to show actual value is lesser
			    // or equal to the estimated value.
			    if (sumReal > sumEstimated) {
				sumReal = sumEstimated;
			    }

			    sumEstimated = Math.round(((double) sumEstimated / contributedIndicesSize));
			    sumReal = Math.round(((double) sumReal / contributedIndicesSize));
			    // To fetch the error percent.
			    if (sumEstimated != 0.0) {
				errorUsage = ((sumReal - sumEstimated) / sumEstimated) * 100;
			    }
			    totalEstimatedUsage += sumEstimated;
			    totalActualUsage += sumReal;
			    formula.setEstimatedUsage(Precision.round(sumEstimated, 3));
			    formula.setActualUsage(Precision.round(sumReal, 3));
			    formula.setErrorUsage(Precision.round(errorUsage, 3));
			    if (!StringUtils.isEmpty(formulaName)) {
				formulaList.add(formula);
			    }

			}
		    }
		}
		totalEstimatedUsage = Precision.round(totalEstimatedUsage, 3);
		totalActualUsage = Precision.round(totalActualUsage, 3);
		// Tweaking the data to show actual value is lesser or equal to
		// the estimated value.
		if (totalActualUsage > totalEstimatedUsage) {
		    totalActualUsage = totalEstimatedUsage;
		}
		if (totalEstimatedUsage != 0.0) {
		    totalErrorUsage = ((totalActualUsage - totalEstimatedUsage) / totalEstimatedUsage) * 100;
		}
		chem.setTotalEstimatedUsage(totalEstimatedUsage);
		chem.setTotalActualUsage(totalActualUsage);
		chem.setTotalErrorUsage(Precision.round(totalErrorUsage, 3));
		formulaList.sort(Comparator.comparing(FormulaDTO::getFormulaName));
		chem.setFormulaList(formulaList);
		chemicalList.add(chem);
	    }
	}
	formulaReportList.sort(Comparator.comparing(FormulaDTO::getFormulaName));
	ChemicalSummaryDTO response = new ChemicalSummaryDTO();
	response.setSiteId(requestDTO.getSiteId());
	response.setUnitId(requestDTO.getEquipmentId());
	chemicalList.sort(Comparator.comparing(ChemicalDTO::getName));
	response.setChemicalList(chemicalList);
	response.setFormulaList(formulaReportList);
	return response;
    }

    private void requestParameterValidationForAvgperMonth(ReportRequestDTO requestDTO, String reportName)
	    throws Exception, SystemException {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.GENERATE_REPORT);
	permissionDeniedCheck(reportName);
	List<Object> params = getInsufficientParamsReport(requestDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
    }

    private String createAvgMonthESQuery(ReportRequestDTO requestDTO, String reportQueryName, EquipmentDTO equipment,
	    int avgReferenceMonth, String siteTimeZone) throws SystemException, Exception {
	String query;
	query = ReportUtils.getQuery(reportQueryName);
	if (StringUtils.isEmpty(query)) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}

	query = query.replace(Constants.FROM_DATE_VAL,
		CommonUtils.convertZonedToUTC(
			ReportUtils.getFromDateForMonthAvgCalculation(requestDTO.getFromDate(), avgReferenceMonth),
			siteTimeZone));

	query = query.replace(Constants.TO_DATE_VAL, CommonUtils
		.convertZonedToUTC(ReportUtils.getToDateForMonthAvgCalculation(requestDTO.getToDate()), siteTimeZone));

	query = query.replace(Constants.DEVICE_ID_VAL, equipment.getDeviceId());
	LOG.info("Query::" + query);
	return query;
    }

    private JsonObject executeAvgMonthESQuery(ReportRequestDTO requestDTO, int avgReferenceMonth, String query,
	    ConfigReader configReader, String siteTimeZone) throws Exception {
	ElasticSearchDAO esDAO = new ElasticSearchDAO(false, configReader.getEsConfig());

	String fromDate = CommonUtils.convertZonedToUTCDate(
		ReportUtils.getFromDateForMonthAvgCalculation(requestDTO.getFromDate(), avgReferenceMonth),
		siteTimeZone);

	String toDate = CommonUtils.convertZonedToUTCDate(
		ReportUtils.getToDateForMonthAvgCalculation(requestDTO.getFromDate()), siteTimeZone);

	SiteDTO siteDTO = new SiteDTO();
	siteDTO.setSiteId(requestDTO.getSiteId());

	JsonObject responseObject = esDAO.executeQuery(query, ReportUtils.getExistingIndices(fromDate, toDate, siteDTO),
		configReader.getAppConfig(Constants.ES_TYPE));
	if (esDAO != null)
	    esDAO.closeJestClient();
	return responseObject;
    }

    private void chemicalEstimatedFilter(ChemicalSummaryDTO response) {
	if (!permissionList.contains(Constants.PRIVILEGE_NAMES.CHEMICAL_SUMMARY_EST_USAGE)) {
	    ReportUtils.unsetFormulaEstimatedValue(response.getFormulaList());
	    for (ChemicalDTO chemical : response.getChemicalList()) {
		chemical.setTotalEstimatedUsage(null);
		chemical.setTotalErrorUsage(null);
		ReportUtils.unsetFormulaEstimatedValue(chemical.getFormulaList());
	    }
	}
    }

    private void chemicalActualUsageFilter(ChemicalSummaryDTO response) {
	if (!permissionList.contains(Constants.PRIVILEGE_NAMES.CHEMICAL_SUMMARY_ACTUAL_USAGE)) {
	    ReportUtils.unsetFormulaActualValue(response.getFormulaList());
	    for (ChemicalDTO chemical : response.getChemicalList()) {
		chemical.setTotalActualUsage(null);
		chemical.setTotalErrorUsage(null);
		ReportUtils.unsetFormulaActualValue(chemical.getFormulaList());
	    }
	}
    }

    public CostSummaryDTO costSummary(ReportRequestDTO requestDTO) throws Exception {
	CostSummaryDTO response = costSummaryUtility(requestDTO);
	response.setSiteDTO(null);
	return response;
    }

    public CostSummaryDTO costSummaryUtility(ReportRequestDTO requestDTO) throws Exception {
	requestParameterValidation(requestDTO, Constants.PRIVILEGE_NAMES.COST_SUMMARY_REPORT);
	SiteDTO siteDTO = getSiteDetails(requestDTO);
	EquipmentDTO equipment = getEquipment(requestDTO, siteDTO);

	CostSummaryDTO response = null;

	if (siteDTO.isStreamingEnabled()
		&& (Constants.EquipmentType.TUNNEL).equalsIgnoreCase(equipment.getEquipmentType())) {
	    response = tunnelEdgeCostReportProcessing(requestDTO, siteDTO, equipment);
	} else {
	    response = mdbCostReportProcessing(requestDTO, siteDTO, equipment);
	}

	return response;

    }

    private CostSummaryDTO tunnelEdgeCostReportProcessing(ReportRequestDTO requestDTO, SiteDTO siteDTO,
	    EquipmentDTO equipment) throws SystemException, Exception {
	String siteTimeZone = siteDTO.getTimeZone();
	JsonObject agg;
	StringBuilder sb = getBatchIds(requestDTO, siteDTO, equipment, siteTimeZone);

	String query = createESQuery(requestDTO, Constants.REPORTS.TUNNEL_EDGE_COST_SUMMARY_QUERY,
		equipment.getDeviceId(), siteTimeZone);

	query = query.replace(Constants.BATCH_IDS_VAL, sb);

	int tunnelModule = equipment.getTunnelList().get(0).getModuleCount();
	query = query.replace(Constants.MODULE_VAL, tunnelModule + "");

	JsonObject responseObject = executeESQuery(requestDTO, siteDTO, query, siteTimeZone);

	agg = handleError(responseObject);

	JsonObject formulaAgg = (JsonObject) (agg).get(Constants.REPORTS.FORMULA_AGGREGATION);
	if (formulaAgg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonArray formulaBuckets = formulaAgg.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (formulaBuckets == null || formulaBuckets.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	String maxDateForReport = getMaxDate(requestDTO, siteDTO, equipment);

	double totalEstimatedCost = 0.0;
	double totalRealCost = 0.0;
	long totalWeight = 0;
	List<FormulaDTO> formulaList = new LinkedList<>();
	if (formulaBuckets != null && formulaBuckets.size() > 0) {
	    Map<String, String> formulaMap = getFormulaMap(equipment);
	    for (int i = 0; i < formulaBuckets.size(); i++) {
		FormulaDTO formula = new FormulaDTO();
		JsonObject formulaJson = formulaBuckets.get(i).getAsJsonObject();
		String formulaName = formulaJson.get(Constants.REPORTS.KEY).getAsString();
		formula.setFormulaName(formulaName.toUpperCase());
		if (StringUtils.isEmpty(formulaName)) {
		    continue;
		}
		if (StringUtils.isEmpty(formulaMap.get(formulaName))) {
		    formulaMap.put(formulaName, formulaName);
		}
		formula.setFormulaId(formulaMap.get(formulaName));
		double error = 0.0;
		double realCost = ((JsonObject) formulaJson.get(Constants.REPORTS.TOTAL_SUM_REAL_COST))
			.get(Constants.REPORTS.VALUE).getAsDouble();
		double estimatedCost = ((JsonObject) formulaJson.get(Constants.REPORTS.TOTAL_SUM_COST_ESTIMATED))
			.get(Constants.REPORTS.VALUE).getAsDouble();
		long weight = ((JsonObject) formulaJson.get(Constants.REPORTS.TOTAL_SUM_REAL))
			.get(Constants.REPORTS.VALUE).getAsLong();

		// weight = CommonUtils.convertKgToLbs(weight);
		estimatedCost = Precision.round(estimatedCost, 3);
		realCost = Precision.round(realCost, 3);
		// Tweaking the data to show actual value is lesser or equal to
		// the estimated value.
		if (realCost > estimatedCost) {
		    realCost = estimatedCost;
		}

		formula.setWashedWeight(weight);
		double estimatedPerCw = 0.0;
		double realPerCw = 0.0;
		if (weight != 0) {
		    estimatedPerCw = CommonUtils.getPerCw(estimatedCost, (double) weight, siteDTO.getMetricUnit());
		    realPerCw = CommonUtils.getPerCw(realCost, (double) weight, siteDTO.getMetricUnit());
		}
		estimatedPerCw = Precision.round(estimatedPerCw, 3);
		realPerCw = Precision.round(realPerCw, 3);

		if (estimatedPerCw != 0.0) {
		    error = CommonUtils.getPerCw((realPerCw - estimatedPerCw), estimatedPerCw, siteDTO.getMetricUnit());
		    error = Precision.round(error, 3);
		}
		formula.setEstimatedCost(estimatedCost);
		formula.setRealCost(realCost);
		formula.setEstimatedCw(estimatedPerCw);
		formula.setRealCw(realPerCw);
		formula.setErrorCost(error);
		totalWeight += weight;
		totalEstimatedCost += estimatedCost;
		totalRealCost += realCost;
		formulaList.add(formula);
	    }
	}

	totalEstimatedCost = Precision.round(totalEstimatedCost, 3);
	totalRealCost = Precision.round(totalRealCost, 3);
	if (totalRealCost > totalEstimatedCost) {
	    totalRealCost = totalEstimatedCost;
	}
	double totalEstimatedPerCw = 0.0;
	double totalRealPerCw = 0.0;
	if (totalWeight != 0) {
	    totalEstimatedPerCw = CommonUtils.getPerCw(totalEstimatedCost, (double) totalWeight,
		    siteDTO.getMetricUnit());
	    totalRealPerCw = CommonUtils.getPerCw(totalRealCost, (double) totalWeight, siteDTO.getMetricUnit());
	}
	CostSummaryDTO response = populateCostSummeryDTO(requestDTO, siteDTO, maxDateForReport, totalEstimatedCost,
		totalRealCost, totalWeight, formulaList, totalEstimatedPerCw, totalRealPerCw, siteTimeZone);
	return response;

    }

    private Map<String, String> getFormulaMap(EquipmentDTO equipment) {
	List<FormulaMetaDataDTO> formulaMetaList = equipment.getFormulaList();
	Map<String, String> formulaMap = new LinkedHashMap<>();
	for (FormulaMetaDataDTO formulaMetaDataDTO : formulaMetaList) {
	    formulaMap.put(formulaMetaDataDTO.getName().trim(), formulaMetaDataDTO.getFormulaId());
	}
	return formulaMap;
    }

    private CostSummaryDTO mdbCostReportProcessing(ReportRequestDTO requestDTO, SiteDTO siteDTO, EquipmentDTO equipment)
	    throws SystemException, Exception {
	CostSummaryDTO response;
	String reportQueryName = null;
	String siteTimeZone = siteDTO.getTimeZone();
	String equipmentType = equipment.getEquipmentType();
	Map<String, Long> formulaWeightMap = null;
	if (Constants.EquipmentType.TUNNEL.equalsIgnoreCase(equipmentType)) {
	    reportQueryName = Constants.REPORTS.TUNNEL_COST_SUMMARY_QUERY;
	} else if (Constants.EquipmentType.WASHER_EXTRACTOR.equalsIgnoreCase(equipmentType)) {
	    reportQueryName = Constants.REPORTS.WE_COST_SUMMARY_QUERY;
	    formulaWeightMap = getLoadProcessedMap(requestDTO, siteDTO, equipment, siteTimeZone);
	}

	String query = createESQuery(requestDTO, reportQueryName, equipment.getDeviceId(), siteTimeZone);

	JsonObject responseObject = executeESQuery(requestDTO, siteDTO, query, siteTimeZone);
	handleEsError(responseObject);
	JsonArray formulaBuckets = getFormulaBuckets(responseObject);
	String maxDateForReport = getMaxDate(requestDTO, siteDTO, equipment);

	double totalEstimatedCost = 0.0;
	double totalRealCost = 0.0;
	long totalWeight = 0;
	List<FormulaDTO> formulaList = new LinkedList<>();
	if (formulaBuckets != null && formulaBuckets.size() > 0) {
	    Map<String, String> formulaMap = getFormulaMap(equipment);
	    for (int i = 0; i < formulaBuckets.size(); i++) {
		FormulaDTO formula = new FormulaDTO();
		JsonObject formulaJson = formulaBuckets.get(i).getAsJsonObject();
		String formulaName = formulaJson.get(Constants.REPORTS.KEY).getAsString();
		formula.setFormulaName(formulaName.toUpperCase());
		if (StringUtils.isEmpty(formulaName)) {
		    continue;
		}
		if (StringUtils.isEmpty(formulaMap.get(formulaName))) {
		    formulaMap.put(formulaName, formulaName);
		}
		formula.setFormulaId(formulaMap.get(formulaName));
		double error = 0.0;
		double realCost = ((JsonObject) formulaJson.get(Constants.REPORTS.TOTAL_SUM_REAL_COST))
			.get(Constants.REPORTS.VALUE).getAsDouble();
		double estimatedCost = ((JsonObject) formulaJson.get(Constants.REPORTS.TOTAL_SUM_COST_ESTIMATED))
			.get(Constants.REPORTS.VALUE).getAsDouble();
		long weight = 0;
		if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.TUNNEL)) {
		    try {
			// Getting the buckets for the machines.
			JsonArray machineBuckets = formulaJson.get(Constants.REPORTS.MACHINE_AGGREGATION)
				.getAsJsonObject().getAsJsonArray(Constants.REPORTS.BUCKETS);
			for (int j = 0; j < machineBuckets.size(); j++) {
			    JsonArray pumpBuckets = machineBuckets.get(j).getAsJsonObject()
				    .get(Constants.REPORTS.PUMP_AGGREGATION).getAsJsonObject()
				    .getAsJsonArray(Constants.REPORTS.BUCKETS);
			    for (int k = 0; k < pumpBuckets.size(); k++) {
				long pumpSum = pumpBuckets.get(k).getAsJsonObject().get(Constants.REPORTS.SUM_PUMP_AGG)
					.getAsJsonObject().getAsJsonArray(Constants.REPORTS.BUCKETS).get(0)
					.getAsJsonObject().get(Constants.REPORTS.SUM_PUMP_REAL_KG).getAsJsonObject()
					.get(Constants.REPORTS.VALUE).getAsLong();
				weight += pumpSum;
			    }
			}
		    } catch (Exception e) {
			LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			LOG.error("Error extracting the sum of loads for the tunnel extractor. : " + e.getMessage());
		    }
		} else {
		    // weight = ((JsonObject) formulaJson.get(Constants.REPORTS.TOTAL_SUM_REAL))
		    // .get(Constants.REPORTS.VALUE).getAsLong();
		    weight = formulaWeightMap.get(formulaName.toUpperCase());
		}

		// weight = CommonUtils.convertKgToLbs(weight);
		estimatedCost = Precision.round(estimatedCost, 3);
		realCost = Precision.round(realCost, 3);
		// Tweaking the data to show actual value is lesser or equal to
		// the estimated value.
		if (realCost > estimatedCost) {
		    realCost = estimatedCost;
		}

		formula.setWashedWeight(weight);
		double estimatedPerCw = 0.0;
		double realPerCw = 0.0;
		if (weight != 0) {
		    estimatedPerCw = CommonUtils.getPerCw(estimatedCost, (double) weight, siteDTO.getMetricUnit());
		    realPerCw = CommonUtils.getPerCw(realCost, (double) weight, siteDTO.getMetricUnit());
		}
		estimatedPerCw = Precision.round(estimatedPerCw, 3);
		realPerCw = Precision.round(realPerCw, 3);

		if (estimatedPerCw != 0.0) {
		    error = CommonUtils.getPerCw((realPerCw - estimatedPerCw), estimatedPerCw, siteDTO.getMetricUnit());
		    error = Precision.round(error, 3);
		}
		formula.setEstimatedCost(estimatedCost);
		formula.setRealCost(realCost);
		formula.setEstimatedCw(estimatedPerCw);
		formula.setRealCw(realPerCw);
		formula.setErrorCost(error);
		totalWeight += weight;
		totalEstimatedCost += estimatedCost;
		totalRealCost += realCost;
		formulaList.add(formula);
	    }
	}

	totalEstimatedCost = Precision.round(totalEstimatedCost, 3);
	totalRealCost = Precision.round(totalRealCost, 3);
	if (totalRealCost > totalEstimatedCost) {
	    totalRealCost = totalEstimatedCost;
	}
	double totalEstimatedPerCw = 0.0;
	double totalRealPerCw = 0.0;
	if (totalWeight != 0) {
	    totalEstimatedPerCw = CommonUtils.getPerCw(totalEstimatedCost, (double) totalWeight,
		    siteDTO.getMetricUnit());
	    totalRealPerCw = CommonUtils.getPerCw(totalRealCost, (double) totalWeight, siteDTO.getMetricUnit());
	}

	response = populateCostSummeryDTO(requestDTO, siteDTO, maxDateForReport, totalEstimatedCost, totalRealCost,
		totalWeight, formulaList, totalEstimatedPerCw, totalRealPerCw, siteTimeZone);
	return response;
    }

    private Map<String, Long> getLoadProcessedMap(ReportRequestDTO requestDTO, SiteDTO siteDTO, EquipmentDTO equipment,
	    String siteTimeZone) throws SystemException, Exception {
	String loadprocesedQuery = Constants.REPORTS.WE_LOAD_PROCESSED_QUERY;
	String query = createESQuery(requestDTO, loadprocesedQuery, equipment.getDeviceId(), siteTimeZone);
	JsonObject responseObject = executeESQuery(requestDTO, siteDTO, query, siteTimeZone);
	handleEsError(responseObject);
	JsonArray formulaBuckets = getFormulaBuckets(responseObject);
	Map<String, Long> formulaWeightMap = new HashMap<String, Long>();
	for (int i = 0; i < formulaBuckets.size(); i++) {
	    JsonObject formulaJson = formulaBuckets.get(i).getAsJsonObject();
	    String formulaName = formulaJson.get(Constants.REPORTS.KEY).getAsString();
	    formulaWeightMap.put(formulaName.toUpperCase(),
		    ((JsonObject) formulaJson.get(Constants.REPORTS.TOTAL_SUM_REAL)).get(Constants.REPORTS.VALUE)
			    .getAsLong());
	}
	return formulaWeightMap;
    }

    private JsonArray getFormulaBuckets(JsonObject responseObject) throws SystemException, Exception {
	JsonObject agg = (JsonObject) responseObject.get(Constants.REPORTS.AGGREGATIONS);
	if (agg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonObject formulaAgg = (JsonObject) (agg).get(Constants.REPORTS.FORMULA_AGGREGATION);
	if (formulaAgg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonArray formulaBuckets = formulaAgg.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (formulaBuckets == null || formulaBuckets.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	return formulaBuckets;
    }

    private CostSummaryDTO populateCostSummeryDTO(ReportRequestDTO requestDTO, SiteDTO siteDTO, String maxDateForReport,
	    double totalEstimatedCost, double totalRealCost, long totalWeight, List<FormulaDTO> formulaList,
	    double totalEstimatedPerCw, double totalRealPerCw, String siteTimeZone) {

	CostSummaryDTO response = new CostSummaryDTO();
	response.setMonth(requestDTO.getMonth());
	response.setYear(requestDTO.getYear());
	response.setSiteId(requestDTO.getSiteId());
	response.setUnitId(requestDTO.getEquipmentId());
	formulaList.sort(Comparator.comparing(FormulaDTO::getWashedWeight).reversed());
	response.setFormulaList(formulaList);
	response.setTotalWeight(totalWeight);
	response.setTotalEstimatedCost(totalEstimatedCost);
	response.setTotalEstimatedCw(Precision.round(totalEstimatedPerCw, 3));
	response.setTotalRealCost(totalRealCost);
	response.setTotalRealCw(Precision.round(totalRealPerCw, 3));
	costEstimatedCostFilter(response);
	realCostFilter(response);
	costPerCwtFilter(response);
	costErrorFilter(response);
	response.setMaxDate(maxDateForReport);
	response.setMinDate(requestDTO.getFromDate());
	response.setSiteDTO(siteDTO);
	return response;
    }

    public CostSummaryDTO costSummaryAvgForPrevMonth(ReportRequestDTO requestDTO) throws Exception {
	int avgReferenceMonth = requestDTO.getAvgReference();
	requestParameterValidationForAvgperMonth(requestDTO, Constants.PRIVILEGE_NAMES.COST_SUMMARY_REPORT);

	if (avgReferenceMonth == 0) {
	    avgReferenceMonth = 3;
	}

	SiteDTO siteDTO = getSiteDetails(requestDTO);
	EquipmentDTO equipment = getEquipment(requestDTO, siteDTO);
	String equipmentType = equipment.getEquipmentType();
	String siteTimeZone = siteDTO.getTimeZone();

	String reportQueryName = null;
	if (Constants.EquipmentType.TUNNEL.equalsIgnoreCase(equipmentType)) {
	    reportQueryName = Constants.REPORTS.TUNNEL_COST_SUMMARY_QUERY;
	} else if (Constants.EquipmentType.WASHER_EXTRACTOR.equalsIgnoreCase(equipmentType)) {
	    reportQueryName = Constants.REPORTS.WE_COST_SUMMARY_QUERY;
	}

	String query = createAvgMonthESQuery(requestDTO, reportQueryName, equipment, avgReferenceMonth, siteTimeZone);

	LOG.info("Query::" + query);

	ConfigReader configReader = ConfigReader.getObject();

	String prod = configReader.getAppConfig(Constants.CANAL_FOR_TUNNEL_REPORT);
	int channelCount = equipment.getChannelCount();
	prod = channelCount + "";
	query = query.replace(Constants.CANAL_FOR_TUNNEL_REPORT, prod);

	JsonObject responseObject = executeAvgMonthESQuery(requestDTO, avgReferenceMonth, query, configReader,
		siteTimeZone);

	handleEsError(responseObject);
	JsonObject agg = (JsonObject) responseObject.get(Constants.REPORTS.AGGREGATIONS);
	if (agg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	// check if any of the index present in indexList contributed in
	// creating response, if not then not further calculations are required.
	JsonObject contributedIndicesForResponse = (JsonObject) (agg).get(Constants.INDEX_AGGREGATION);
	JsonArray contributedIndicesForResponseArray = contributedIndicesForResponse
		.getAsJsonArray(Constants.REPORTS.BUCKETS);
	int contributedIndicesSize = contributedIndicesForResponseArray.size();
	List<String> avgCalculatedForMonths = new LinkedList<>();

	if (contributedIndicesSize > 0) {
	    for (int i = 0; i < contributedIndicesForResponseArray.size(); i++) {
		JsonObject indexJson = contributedIndicesForResponseArray.get(i).getAsJsonObject();
		String key = indexJson.get(Constants.REPORTS.KEY).getAsString();
		String[] keyValue = key.split("-");
		String monthYearValue = Month.of(Integer.parseInt(keyValue[2])).name() + "-" + keyValue[3];
		avgCalculatedForMonths.add(monthYearValue);
	    }
	}

	JsonObject formulaAgg = (JsonObject) (agg).get(Constants.REPORTS.FORMULA_AGGREGATION);
	if (formulaAgg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonArray formulaBuckets = formulaAgg.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (formulaBuckets == null || formulaBuckets.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	double totalEstimatedCost = 0.0;
	double totalRealCost = 0.0;
	long totalWeight = 0;
	List<FormulaDTO> formulaList = new LinkedList<>();
	if (formulaBuckets != null && formulaBuckets.size() > 0) {
	    List<FormulaMetaDataDTO> formulaMetaList = equipment.getFormulaList();
	    Map<String, String> formulaMap = new LinkedHashMap<>();
	    for (FormulaMetaDataDTO formulaMetaDataDTO : formulaMetaList) {
		formulaMap.put(formulaMetaDataDTO.getName().trim(), formulaMetaDataDTO.getFormulaId());
	    }
	    for (int i = 0; i < formulaBuckets.size(); i++) {
		FormulaDTO formula = new FormulaDTO();
		JsonObject formulaJson = formulaBuckets.get(i).getAsJsonObject();
		String formulaName = formulaJson.get(Constants.REPORTS.KEY).getAsString();
		formula.setFormulaName(formulaName.toUpperCase());
		if (StringUtils.isEmpty(formulaName)) {
		    continue;
		}
		if (StringUtils.isEmpty(formulaMap.get(formulaName))) {
		    formulaMap.put(formulaName, formulaName);
		}
		formula.setFormulaId(formulaMap.get(formulaName));
		double error = 0.0;
		double realCost = ((JsonObject) formulaJson.get(Constants.REPORTS.TOTAL_SUM_REAL_COST))
			.get(Constants.REPORTS.VALUE).getAsDouble();
		double estimatedCost = ((JsonObject) formulaJson.get(Constants.REPORTS.TOTAL_SUM_COST_ESTIMATED))
			.get(Constants.REPORTS.VALUE).getAsDouble();
		long weight = 0;
		if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.TUNNEL)) {
		    try {
			// Getting the buckets for the machines.
			JsonArray machineBuckets = formulaJson.get(Constants.REPORTS.MACHINE_AGGREGATION)
				.getAsJsonObject().getAsJsonArray(Constants.REPORTS.BUCKETS);
			for (int j = 0; j < machineBuckets.size(); j++) {
			    JsonArray pumpBuckets = machineBuckets.get(j).getAsJsonObject()
				    .get(Constants.REPORTS.PUMP_AGGREGATION).getAsJsonObject()
				    .getAsJsonArray(Constants.REPORTS.BUCKETS);
			    for (int k = 0; k < pumpBuckets.size(); k++) {
				long pumpSum = pumpBuckets.get(k).getAsJsonObject().get(Constants.REPORTS.SUM_PUMP_AGG)
					.getAsJsonObject().getAsJsonArray(Constants.REPORTS.BUCKETS).get(0)
					.getAsJsonObject().get(Constants.REPORTS.SUM_PUMP_REAL_KG).getAsJsonObject()
					.get(Constants.REPORTS.VALUE).getAsLong();
				weight += pumpSum;
			    }
			}
		    } catch (Exception e) {
			LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			LOG.error("Error extracting the sum of loads for the tunnel extractor. : " + e.getMessage());
		    }
		} else {
		    weight = ((JsonObject) formulaJson.get(Constants.REPORTS.TOTAL_SUM_REAL))
			    .get(Constants.REPORTS.VALUE).getAsLong();
		}

		// Tweaking the data to show actual value is lesser or equal to
		// the estimated value.
		if (realCost > estimatedCost) {
		    realCost = estimatedCost;
		}

		// dividing weight, estimatedCost & realCost with
		// contributedIndicesSize to find avg. values
		weight = (long) Math.round(((double) weight / contributedIndicesSize));
		estimatedCost = Precision.round((estimatedCost / contributedIndicesSize), 3);
		realCost = Precision.round((realCost / contributedIndicesSize), 3);

		formula.setWashedWeight(weight);
		double estimatedPerCw = 0.0;
		double realPerCw = 0.0;
		if (weight != 0) {
		    estimatedPerCw = CommonUtils.getPerCw(estimatedCost, (double) weight, siteDTO.getMetricUnit());
		    realPerCw = CommonUtils.getPerCw(realCost, (double) weight, siteDTO.getMetricUnit());
		}
		estimatedPerCw = Precision.round(estimatedPerCw, 3);
		realPerCw = Precision.round(realPerCw, 3);

		if (estimatedPerCw != 0.0) {
		    error = CommonUtils.getPerCw((realPerCw - estimatedPerCw), estimatedPerCw, siteDTO.getMetricUnit());
		    error = Precision.round(error, 3);
		}
		formula.setRealCost(realCost);
		formula.setRealCw(realPerCw);
		totalWeight += weight;
		totalEstimatedCost += estimatedCost;
		totalRealCost += realCost;
		formulaList.add(formula);
	    }
	}
	totalEstimatedCost = Precision.round(totalEstimatedCost, 3);
	totalRealCost = Precision.round(totalRealCost, 3);
	if (totalRealCost > totalEstimatedCost) {
	    totalRealCost = totalEstimatedCost;
	}
	double totalEstimatedPerCw = 0.0;
	double totalRealPerCw = 0.0;
	if (totalWeight != 0) {
	    totalEstimatedPerCw = CommonUtils.getPerCw(totalEstimatedCost, (double) totalWeight,
		    siteDTO.getMetricUnit());
	    totalRealPerCw = CommonUtils.getPerCw(totalRealCost, (double) totalWeight, siteDTO.getMetricUnit());
	}
	CostSummaryDTO response = new CostSummaryDTO();
	response.setSiteId(requestDTO.getSiteId());
	response.setUnitId(requestDTO.getEquipmentId());
	formulaList.sort(Comparator.comparing(FormulaDTO::getWashedWeight).reversed());
	response.setFormulaList(formulaList);
	response.setTotalRealCost(totalRealCost);
	response.setTotalRealCw(Precision.round(totalRealPerCw, 3));
	response.setAvgCalculatedForMonths(avgCalculatedForMonths);
	return response;
    }

    private void costEstimatedCostFilter(CostSummaryDTO response) {
	if (!permissionList.contains(Constants.PRIVILEGE_NAMES.COST_SUMMARY_EST_COST)) {
	    response.setTotalEstimatedCost(null);
	    response.setTotalEstimatedCw(null);
	    ReportUtils.unsetFormulaEstimatedValue(response.getFormulaList());
	}
    }

    private void costPerCwtFilter(CostSummaryDTO response) {
	if (!permissionList.contains(Constants.PRIVILEGE_NAMES.COST_SUMMARY_COST_PER_CWT)) {
	    response.setTotalEstimatedCw(null);
	    for (FormulaDTO formula : response.getFormulaList()) {
		formula.setEstimatedCw(null);
		formula.setRealCw(null);
		formula.setErrorCost(null);
	    }
	}
    }

    private void realCostFilter(CostSummaryDTO response) {
	if (!permissionList.contains(Constants.PRIVILEGE_NAMES.COST_SUMMARY_ABS_COST)) {
	    response.setTotalRealCost(null);
	    response.setTotalRealCw(null);
	    ReportUtils.unsetFormulaActualValue(response.getFormulaList());
	}
    }

    private void costErrorFilter(CostSummaryDTO response) {
	if (!permissionList.contains(Constants.PRIVILEGE_NAMES.COST_SUMMARY_ERROR)) {
	    for (FormulaDTO formula : response.getFormulaList()) {
		formula.setErrorCost(null);
	    }
	}
    }

    public AlarmSummaryDTO alarmSummary(ReportRequestDTO requestDTO) throws Exception {
	AlarmSummaryDTO response = null;
	SiteDTO siteDTO = new SiteDTO();
	siteDTO.setSiteId(requestDTO.getSiteId());
	siteDTO = ((SiteDao) hydroDao).getSiteDetails(siteDTO);
	if (siteDTO.isStreamingEnabled()) {
	    response = realTimeAlarmSummary(requestDTO);
	} else {
	    response = mdbAlarmSummary(requestDTO);
	}
	return response;
    }

    public AlarmSummaryDTO mdbAlarmSummary(ReportRequestDTO requestDTO) throws Exception {

	requestParameterValidation(requestDTO, Constants.PRIVILEGE_NAMES.ALARM_SUMMARY_REPORT);
	SiteDTO siteDTO = getSiteDetails(requestDTO);
	String siteTimeZone = siteDTO.getTimeZone();
	EquipmentDTO equipment = getEquipment(requestDTO, siteDTO);
	String maxDateForReport = null;
	String query = createESQuery(requestDTO, Constants.REPORTS.ALARM_SUMMARY_QUERY, equipment.getDeviceId(),
		siteTimeZone);

	JsonObject responseObject = executeESQuery(requestDTO, siteDTO, query, siteTimeZone);
	handleEsError(responseObject);
	List<AlarmDTO> alarmList = new LinkedList<>();

	Map<String, Map<String, Object>> machineNameMap = new LinkedHashMap<>();
	if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.WASHER_EXTRACTOR)) {
	    List<WasherMetaDataDTO> washerList = equipment.getWasherList();
	    for (WasherMetaDataDTO washer : washerList) {
		Map<String, Object> mMap = new LinkedHashMap<>();
		mMap.put(Constants.REPORTS.NAME, washer.getLm2Seq() + "." + washer.getName());
		mMap.put(Constants.REPORTS.CAPACITY, washer.getLoad());
		mMap.put(Constants.REPORTS.LM2_SEQ, washer.getLm2Seq());
		machineNameMap.put(washer.getLm2Seq(), mMap);
	    }
	} else {
	    List<TunnelDTO> tunnelList = equipment.getTunnelList();
	    for (TunnelDTO tunnel : tunnelList) {
		Map<String, Object> mMap = new LinkedHashMap<>();
		mMap.put(Constants.REPORTS.NAME, tunnel.getLm2Seq() + "." + tunnel.getName());
		mMap.put(Constants.REPORTS.CAPACITY, tunnel.getLoad());
		mMap.put(Constants.REPORTS.LM2_SEQ, tunnel.getLm2Seq());
		machineNameMap.put(tunnel.getLm2Seq(), mMap);
	    }
	}

	if (Constants.EquipmentType.TUNNEL.equals(equipment.getEquipmentType())) {
	    REPORTS.MDB_TUNNEL_ALARMS.forEach((alarmId, alarmName) -> {
		AlarmDTO alarmDetails = new AlarmDTO();
		alarmDetails.setAlarmId(alarmId);
		alarmDetails.setAlarmName(alarmName);
		alarmDetails.setHeaderList(ReportUtils.mdbHeaderList(alarmId));
		if (!ReportUtils.isSystemAlarm(ReportUtils.getEquivalentAlarmCode(alarmId))) {
		    alarmDetails.setMachineList(ReportUtils.creatingMachineList(machineNameMap));
		}
		alarmList.add(alarmDetails);
	    });
	} else {
	    REPORTS.MDB_ALARMS.forEach((alarmId, alarmName) -> {
		AlarmDTO alarmDetails = new AlarmDTO();
		alarmDetails.setAlarmId(alarmId);
		alarmDetails.setAlarmName(alarmName);
		alarmDetails.setHeaderList(ReportUtils.mdbHeaderList(alarmId));
		if (!ReportUtils.isSystemAlarm(ReportUtils.getEquivalentAlarmCode(alarmId))) {
		    alarmDetails.setMachineList(ReportUtils.creatingMachineList(machineNameMap));
		}
		alarmList.add(alarmDetails);
	    });
	}
	AlarmSummaryDTO alarmSummary = new AlarmSummaryDTO();
	alarmSummary.setAlarmList(alarmList);

	JsonObject firstHitsObject = (JsonObject) responseObject.get(Constants.REPORTS.HITS);
	if (firstHitsObject != null) {
	    JsonArray jsonArray = ReportUtils.fieldsQuery(firstHitsObject);
	    if (jsonArray == null || jsonArray.size() <= 0) {
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    }

	    maxDateForReport = getMaxDate(requestDTO, siteDTO, equipment);

	    for (int i = 0; i < jsonArray.size(); i++) {
		JsonObject event = (JsonObject) jsonArray.get(i);
		JsonElement alarmJsonElement = event.get(Constants.REPORTS.ALARM_CODE);
		if (alarmJsonElement == null) {
		    continue;
		}
		int alarmCode = alarmJsonElement.getAsInt();
		int equivalentAlarm = ReportUtils.getEquivalentAlarmCode(alarmCode);
		String machineId = event.get(Constants.REPORTS.MACHINE_WASHER).getAsString();
		if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.TUNNEL)) {
		    machineId = event.get(Constants.REPORTS.MACHINE_TUNNEL).getAsString();
		}
		WarningDTO warningDTO = ReportUtils.mdbWarning(event, siteDTO.getMetricUnit(), equivalentAlarm,
			siteTimeZone);

		for (AlarmDTO alarmDTO : alarmList) {
		    if (alarmDTO.getAlarmId() == equivalentAlarm) {
			if (alarmDTO.getTotalWarnings() == null || alarmDTO.getTotalMachines() == null) {
			    alarmDTO.setTotalWarnings(0);
			    alarmDTO.setTotalMachines(0);
			}
//			alarmDTO.setTotalWarnings(alarmDTO.getTotalWarnings() + 1);
			if (warningDTO == null) {
			    List<WarningDTO> systemWarningList = ReportUtils.getSystemWarningList(equivalentAlarm,
				    alarmDTO.getSystemWarningList(), event, alarmCode, equipment.getProductMap(),
				    siteTimeZone, siteDTO.isStreamingEnabled(), equipment.getEquipmentType());
			    if (systemWarningList != null) {
				alarmDTO.setSystemWarningList(systemWarningList);
				alarmDTO.setTotalMachines(0);
				alarmDTO.setTotalWarnings(systemWarningList.size());
			    }
			} else {
			    List<MachineDTO> machineList = alarmDTO.getMachineList();
			    for (MachineDTO machineDetails : machineList) {
				if (machineId.equalsIgnoreCase(machineDetails.getMachineId())) {
//				    machineDetails.setWarningCount(machineDetails.getWarningCount() + 1);
				    List<WarningDTO> warningList = machineDetails.getWarningList();
				    warningList.add(warningDTO);
				    machineDetails.setWarningList(warningList);
				    break;
				}

			    }
			}
			break;
		    }
		}

	    }

	} else

	{
	    if (firstHitsObject == null) {
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    }
	}
	// TODO add exception in else block.

	AlarmSummaryDTO response = new AlarmSummaryDTO();
	response.setMonth(requestDTO.getMonth());

	response.setYear(requestDTO.getYear());
	response.setSiteId(requestDTO.getSiteId());
	response.setUnitId(requestDTO.getEquipmentId());
	alarmList.sort(Comparator.comparing(AlarmDTO::getAlarmName));
	response.setAlarmList(alarmList);

	for (AlarmDTO alarmDTO : alarmList) {
	    List<MachineDTO> macList = alarmDTO.getMachineList();
	    if (macList != null) {
		for (MachineDTO mac : macList) {
		    if (!mac.getWarningList().isEmpty()) {
			alarmDTO.setTotalMachines(alarmDTO.getTotalMachines() + 1);
			int uniqueWarningCount = ReportUtils.getUniqueWarningCount(mac.getWarningList());
			mac.setWarningCount(uniqueWarningCount);
			alarmDTO.setTotalWarnings(alarmDTO.getTotalWarnings() + uniqueWarningCount);
		    }
		}
	    }
	}
	response.setMaxDate(maxDateForReport);
	response.setMinDate(requestDTO.getFromDate());
	response.setSiteDTO(siteDTO);
	return response;
    }

    public AlarmSummaryDTO realTimeAlarmSummary(ReportRequestDTO requestDTO) throws Exception {
	requestParameterValidation(requestDTO, Constants.PRIVILEGE_NAMES.ALARM_SUMMARY_REPORT);
	SiteDTO siteDTO = getSiteDetails(requestDTO);
	String siteTimeZone = siteDTO.getTimeZone();
	EquipmentDTO equipment = getEquipment(requestDTO, siteDTO);
	String maxDateForReport = null;
	String query = createESQuery(requestDTO, Constants.REPORTS.ALARM_SUMMARY_QUERY, equipment.getDeviceId(),
		siteTimeZone);

	ConfigReader configReader = ConfigReader.getObject();
	JsonObject responseObject = executeESQuery(requestDTO, siteDTO, query, siteTimeZone);

	handleEsError(responseObject);
	List<AlarmDTO> alarmList = new LinkedList<>();

	Map<String, Map<String, Object>> machineNameMap = new LinkedHashMap<>();
	if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.WASHER_EXTRACTOR)) {
	    List<WasherMetaDataDTO> washerList = equipment.getWasherList();
	    for (WasherMetaDataDTO washer : washerList) {
		Map<String, Object> mMap = new LinkedHashMap<>();
		mMap.put(Constants.REPORTS.NAME, washer.getLm2Seq() + "." + washer.getName());
		mMap.put(Constants.REPORTS.CAPACITY, washer.getLoad());
		mMap.put(Constants.REPORTS.LM2_SEQ, washer.getLm2Seq());
		machineNameMap.put(washer.getLm2Seq(), mMap);
	    }
	} else {
	    List<TunnelDTO> tunnelList = equipment.getTunnelList();
	    for (TunnelDTO tunnel : tunnelList) {
		Map<String, Object> mMap = new LinkedHashMap<>();
		mMap.put(Constants.REPORTS.NAME, tunnel.getLm2Seq() + "." + tunnel.getName());
		mMap.put(Constants.REPORTS.CAPACITY, tunnel.getLoad());
		mMap.put(Constants.REPORTS.LM2_SEQ, tunnel.getLm2Seq());
		machineNameMap.put(tunnel.getLm2Seq(), mMap);
	    }
	}

	if (Constants.EquipmentType.TUNNEL.equals(equipment.getEquipmentType())) {
	    REPORTS.REAL_TIME_TUNNEL_ALARMS.forEach((alarmId, alarmName) -> {
		AlarmDTO alarmDetails = new AlarmDTO();
		alarmDetails.setAlarmId(alarmId);
		alarmDetails.setAlarmName(alarmName);
		alarmDetails.setHeaderList(ReportUtils.getHeaderList(alarmId));
		if (!ReportUtils.isSystemAlarm(ReportUtils.getEquivalentAlarmCode(alarmId))) {
		    alarmDetails.setMachineList(ReportUtils.creatingMachineList(machineNameMap));
		}
		alarmList.add(alarmDetails);
	    });
	} else {
	    REPORTS.REAL_TIME_ALARMS.forEach((alarmId, alarmName) -> {
		AlarmDTO alarmDetails = new AlarmDTO();
		alarmDetails.setAlarmId(alarmId);
		alarmDetails.setAlarmName(alarmName);
		alarmDetails.setHeaderList(ReportUtils.getHeaderList(alarmId));
		if (!ReportUtils.isSystemAlarm(ReportUtils.getEquivalentAlarmCode(alarmId))) {
		    alarmDetails.setMachineList(ReportUtils.creatingMachineList(machineNameMap));
		}
		alarmList.add(alarmDetails);
	    });
	}

	AlarmSummaryDTO alarmSummary = new AlarmSummaryDTO();
	alarmSummary.setAlarmList(alarmList);

	JsonObject firstHitsObject = (JsonObject) responseObject.get(Constants.REPORTS.HITS);
	if (firstHitsObject != null) {
	    JsonArray jsonArray = ReportUtils.fieldsQuery(firstHitsObject);
	    if (jsonArray == null || jsonArray.size() <= 0) {
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    }

	    maxDateForReport = getMaxDate(requestDTO, siteDTO, equipment);

	    String machineId = null;
	    if (siteDTO.isStreamingEnabled()
		    && (Constants.EquipmentType.TUNNEL).equalsIgnoreCase(equipment.getEquipmentType())) {
		machineId = "" + ((SiteDao) hydroDao).getLm2Sequence(equipment.getDeviceId());

	    }

	    for (int i = 0; i < jsonArray.size(); i++) {
		JsonObject event = (JsonObject) jsonArray.get(i);
		LOG.debug("Processing event:: " + i + " (" + event.get("id") + ")");
		JsonElement eventJsonElement = event.get(Constants.REPORTS.EVENT_TYPE);
		JsonElement alarmJsonElement = event.get(Constants.REPORTS.ALARM_CODE);
		if (alarmJsonElement == null) {
		    continue;
		}
		int alarmCode = alarmJsonElement.getAsInt();

		int equivalentAlarm = ReportUtils.getEquivalentAlarmCode(alarmCode);

		if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.TUNNEL)) {
		    if (event.get(Constants.REPORTS.MACHINE_TUNNEL) != null && !siteDTO.isStreamingEnabled()) {
			machineId = event.get(Constants.REPORTS.MACHINE_TUNNEL).getAsString();
		    }
		} else {
		    if (event.get(Constants.REPORTS.MACHINE_WASHER) != null) {
			machineId = event.get(Constants.REPORTS.MACHINE_WASHER).getAsString();
		    }
		}

		int missedEvent = Integer.parseInt(configReader.getAppConfig(Constants.REPORTS.MISSED_PHASE));
		if (eventJsonElement != null) {
		    int eventType = eventJsonElement.getAsInt();
		    if (eventType == missedEvent) {
			equivalentAlarm = missedEvent;
		    }
		}
		if (Constants.EquipmentType.TUNNEL.equals(equipment.getEquipmentType())
			&& (equivalentAlarm == Constants.REPORTS.MISSED_PHASE_ALARM
				|| equivalentAlarm == Constants.REPORTS.UNFINISHED_CYCLE_ALARM)) {
		    continue;
		}
		if (alarmCode == missedEvent) {
		    equivalentAlarm = 0;
		}
		WarningDTO warningDTO = null;
		if (alarmCode != missedEvent) {
		    warningDTO = ReportUtils.getWarning(event, siteDTO.getMetricUnit(), equivalentAlarm, siteTimeZone,
			    siteDTO.isStreamingEnabled(), equipment.getEquipmentType());
		}
		for (AlarmDTO alarmDTO : alarmList) {
		    if (alarmDTO.getAlarmId() == equivalentAlarm) {
			if (alarmDTO.getTotalWarnings() == null || alarmDTO.getTotalMachines() == null) {
			    alarmDTO.setTotalWarnings(0);
			    alarmDTO.setTotalMachines(0);
			}
//			alarmDTO.setTotalWarnings(alarmDTO.getTotalWarnings() + 1);
			if (warningDTO == null) {
			    List<WarningDTO> systemWarningList = ReportUtils.getSystemWarningList(equivalentAlarm,
				    alarmDTO.getSystemWarningList(), event, alarmCode, equipment.getProductMap(),
				    siteTimeZone, siteDTO.isStreamingEnabled(), equipment.getEquipmentType());
			    if (systemWarningList != null) {
				alarmDTO.setSystemWarningList(systemWarningList);
				alarmDTO.setTotalMachines(0);
				alarmDTO.setTotalWarnings(systemWarningList.size());
			    }
			} else {
			    List<MachineDTO> machineList = alarmDTO.getMachineList();
			    for (MachineDTO machineDetails : machineList) {
				if (machineId != null && machineId.equalsIgnoreCase(machineDetails.getMachineId())) {
//				    machineDetails.setWarningCount(machineDetails.getWarningCount() + 1);
				    List<WarningDTO> warningList = machineDetails.getWarningList();
				    warningList.add(warningDTO);
				    machineDetails.setWarningList(warningList);
				    break;
				}

			    }
			}
			break;
		    }
		}

	    }

	} else

	{
	    if (firstHitsObject == null) {
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    }
	}
	// TODO add exception in else block.

	AlarmSummaryDTO response = new AlarmSummaryDTO();
	response.setMonth(requestDTO.getMonth());

	response.setYear(requestDTO.getYear());
	response.setSiteId(requestDTO.getSiteId());
	response.setUnitId(requestDTO.getEquipmentId());
	alarmList.sort(Comparator.comparing(AlarmDTO::getAlarmName));
	response.setAlarmList(alarmList);

	for (AlarmDTO alarmDTO : alarmList) {
	    List<MachineDTO> macList = alarmDTO.getMachineList();
	    if (macList != null) {
		for (MachineDTO mac : macList) {
		    if (!mac.getWarningList().isEmpty()) {
			alarmDTO.setTotalMachines(alarmDTO.getTotalMachines() + 1);
			int uniqueWarningCount = ReportUtils.getUniqueWarningCount(mac.getWarningList());
			mac.setWarningCount(uniqueWarningCount);
			alarmDTO.setTotalWarnings(alarmDTO.getTotalWarnings() + uniqueWarningCount);
		    }
		}
	    }
	}
	response.setMaxDate(maxDateForReport);
	response.setMinDate(requestDTO.getFromDate());
	response.setSiteDTO(siteDTO);
	return response;
    }

    /**
     * Test Reports DataBase Connection
     * 
     * @return
     */

    public boolean testReportsDbConnection() {
	return ((SiteDao) hydroDao).testSiteDbConnection();
    }

    public ObservationDTO createObservation(ObservationDTO observationDTO, SiteDTO siteDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.GENERATE_REPORT);
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.OBS_REC_REPORT);
	List<Object> params = getInsufficientParamsListCreateObservation(observationDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	if (!equipmentIdExists(observationDTO)) {

	    throw new SystemException(ErrorCodes.INVALID_EQUIPMENT_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);

	}
	return ((SiteDao) hydroDao).createObservation(user, observationDTO);

    }

    public boolean updateObservation(ObservationDTO observationDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.GENERATE_REPORT);
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.OBS_REC_REPORT);
	List<Object> params = getInsufficientParamsListUpdateObservation(observationDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	return ((SiteDao) hydroDao).updateObservation(user, observationDTO);

    }

    public boolean deleteObservation(ObservationDTO observationDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.GENERATE_REPORT);
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.OBS_REC_REPORT);
	if (StringUtils.isEmpty(observationDTO.getObservationId())) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}

	return ((SiteDao) hydroDao).deleteObservation(user, observationDTO);

    }

    public ObservationListResponseDTO getObservationList(ObservationDTO observationDTO) throws Exception {
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.GENERATE_REPORT);
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.OBS_REC_REPORT);
	List<Object> params = getInsufficientParamsListGetObservation(observationDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	return ((SiteDao) hydroDao).getObservationList(user, observationDTO);

    }

    public boolean equipmentIdExists(ObservationDTO observationDTO) throws Exception {
	if (StringUtils.isEmpty(observationDTO.getEquipmentId())) {
	    List<Object> paramsList = new LinkedList<>();
	    paramsList.add(ErrorCodes.InsufficientParams.EQUIPMENT_ID);
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, paramsList);

	}
	if (StringUtils.isEmpty(((SiteDao) hydroDao).equipmentIdExists(observationDTO))) {
	    return false;
	}
	return true;
    }

    protected List<Object> getInsufficientParamsListCreateObservation(ObservationDTO observationDTO) {
	List<Object> params = new LinkedList<>();
	if (observationDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.OBSERVATION_OBJECT);
	}
	if (StringUtils.isEmpty(observationDTO.getSiteId())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_ID);
	}
	if (StringUtils.isEmpty(observationDTO.getEquipmentId())) {
	    params.add(ErrorCodes.InsufficientParams.EQUIPMENT_ID);
	}
	if (StringUtils.isEmpty(observationDTO.getObservation())
		&& StringUtils.isEmpty(observationDTO.getRecommendation())) {
	    params.add(ErrorCodes.InsufficientParams.OBSERVATION);
	    params.add(ErrorCodes.InsufficientParams.RECOMMENDATION);
	}

	return params;
    }

    protected List<Object> getInsufficientParamsListUpdateObservation(ObservationDTO observationDTO) {
	List<Object> params = new LinkedList<>();
	if (observationDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.OBSERVATION_OBJECT);
	}
	if (StringUtils.isEmpty(observationDTO.getObservationId())) {
	    params.add(ErrorCodes.InsufficientParams.OBSERVATION_ID);
	}
	if (StringUtils.isEmpty(observationDTO.getObservation())
		&& StringUtils.isEmpty(observationDTO.getRecommendation())) {
	    params.add(ErrorCodes.InsufficientParams.OBSERVATION);
	    params.add(ErrorCodes.InsufficientParams.RECOMMENDATION);
	}
	return params;
    }

    protected List<Object> getInsufficientParamsListGetObservation(ObservationDTO observationDTO) {
	List<Object> params = new LinkedList<>();
	if (observationDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.OBSERVATION_OBJECT);
	}
	if (StringUtils.isEmpty(observationDTO.getSiteId())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_ID);
	}
	if (StringUtils.isEmpty(observationDTO.getEquipmentId())) {
	    params.add(ErrorCodes.InsufficientParams.EQUIPMENT_ID);
	}
	return params;
    }

    public StreamingOutput getExcelReportForProductionSummary(ReportRequestDTO reportRequest) throws Exception {
	WasherProductionDTO data = washerProductionSummaryUtility(reportRequest);
	List<EquipmentReportDTO> equipmentList = data.getEquipmentList();
	XSSFWorkbook workbook = new XSSFWorkbook();
	try {
	    if (equipmentList.isEmpty() || equipmentList == null) {
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    }

	    SiteDTO siteDTO = data.getSiteDTO();
	    String actualWeightUnit = MetricUnit.WEIGHT;
	    if (siteDTO.getMetricUnit().equals(UsUnit.ID)) {
		actualWeightUnit = UsUnit.WEIGHT;
	    }

	    XSSFSheet sheet = workbook.createSheet(Constants.WASHER_PRODUCTION_SUMMARY);

	    int rowCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_ROW_COUNT;
	    int cellCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;

	    sheet = ExcelUtils.createTopHeadings(workbook, sheet, rowCount, cellCount, siteDTO,
		    Constants.WASHER_PRODUCTION_SUMMARY_REPORT_TAG, data.getMaxDate(), data.getMinDate(),
		    reportRequest);

	    rowCount = sheet.getLastRowNum() + 2;
	    XSSFRow row = sheet.createRow(rowCount);
	    int firstRowForBorder = rowCount;
	    Cell cell = row.createCell(cellCount);
	    cell.setCellStyle(ExcelUtils.cellStyleFormulaHeading(sheet));
	    cell.setCellValue(Constants.TOTAL + Constants.REPORT_EXPORT_CONSTANTS.SPACE
		    + reportRequest.getMeasurementUnit() + Constants.REPORT_EXPORT_CONSTANTS.COLON
		    + (Double) Precision.round(ExcelUtils.lbsKgConversion(reportRequest.getMeasurementUnit(),
			    data.getTotalProduction(), actualWeightUnit), 3)
		    + Constants.REPORT_EXPORT_CONSTANTS.NEW_LINE + Constants.TOTAL_LOADS
		    + Constants.REPORT_EXPORT_CONSTANTS.COLON + data.getTotalLoads());
	    sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.PRODUCTION_HEADING);

	    Map<String, Integer> equipmentMap = new LinkedHashMap<String, Integer>();
	    int equipmentMapValue = 1;
	    for (EquipmentReportDTO equipment : equipmentList) {
		cell = ExcelUtils.createCell(row, ++cellCount, equipment.getName().trim());
		int firstColumnCount = cellCount;
		int lastColumnCount = firstColumnCount + 3;
		if (equipmentList.size() > 1)
		    sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, cellCount++, cellCount));
		if (equipmentList.size() == 1)
		    sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, firstColumnCount, lastColumnCount));
		cell.setCellStyle(ExcelUtils.cellStyle(sheet));
		equipmentMap.put(equipment.getName().trim(), equipmentMapValue);
		equipmentMapValue = equipmentMapValue + 2;
	    }

	    // create sub heading
	    row = sheet.createRow(++rowCount);
	    int columnCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;
	    for (String mapKey : equipmentMap.keySet()) {
		columnCount = equipmentMap.get(mapKey);
		cell = ExcelUtils.createCell(row, columnCount, Constants.WASHED
			+ Constants.REPORT_EXPORT_CONSTANTS.SPACE + reportRequest.getMeasurementUnit());
		cell.setCellStyle(ExcelUtils.cellStyleSubHeading(sheet));
		sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.PRODUCTION_SUB_HEADING);
		cell = ExcelUtils.createCell(row, ++columnCount, Constants.LOADS_WASHED);
		cell.setCellStyle(ExcelUtils.cellStyleSubHeading(sheet));
		sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.PRODUCTION_SUB_HEADING);
	    }

	    cell = ExcelUtils.createCell(row, ++columnCount,
		    Constants.TOTAL + Constants.REPORT_EXPORT_CONSTANTS.SPACE + reportRequest.getMeasurementUnit());
	    cell.setCellStyle(ExcelUtils.cellStyleSubHeading(sheet));
	    sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.PRODUCTION_SUB_HEADING);
	    cell = ExcelUtils.createCell(row, ++columnCount, Constants.TOTAL_LOADS);
	    cell.setCellStyle(ExcelUtils.cellStyleSubHeading(sheet));
	    sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.PRODUCTION_SUB_HEADING);
	    int lastColumnForBorder = columnCount;

	    Map<String, Integer> formulaMap = new LinkedHashMap<String, Integer>();
	    List<String> formulaList = new LinkedList<>();
	    for (EquipmentReportDTO equipment : equipmentList) {
		List<FormulaDTO> formulaListForEquipment = equipment.getFormulaList();
		if (!formulaListForEquipment.isEmpty() || formulaListForEquipment != null) {
		    for (FormulaDTO formula : formulaListForEquipment) {
			if (!formulaList.contains(formula.getFormulaName()))
			    formulaList.add(formula.getFormulaName());
		    }
		}
	    }

	    // creating hashmap for formula using formulaList
	    for (String formula : formulaList) {
		formulaMap.put(formula, ++rowCount);
		row = sheet.createRow(rowCount);
		cell = ExcelUtils.createCell(row, Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT, formula);
		cell.setCellStyle(ExcelUtils.cellStyleSideHeading(sheet));
	    }
	    // adding total to formulaList
	    formulaMap.put(Constants.TOTAL, ++rowCount);
	    row = sheet.createRow(rowCount);
	    cell = ExcelUtils.createCell(row, Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT, Constants.TOTAL);
	    int lastRowForBorder = rowCount;
	    cell.setCellStyle(ExcelUtils.cellStyleSideHeading(sheet));

	    // pushing formula data to different columns depending on HashMap
	    for (EquipmentReportDTO equipment : equipmentList) {
		List<FormulaDTO> formulaListForEquipment = equipment.getFormulaList();

		if (!formulaListForEquipment.isEmpty() || formulaListForEquipment != null) {
		    for (FormulaDTO formula : formulaListForEquipment) {
			row = sheet.getRow(formulaMap.get(formula.getFormulaName()));
			cell = row.createCell(equipmentMap.get(equipment.getName().trim()));
			cell.setCellValue(
				(Double) Precision.round(ExcelUtils.lbsKgConversion(reportRequest.getMeasurementUnit(),
					formula.getWashedWeight(), actualWeightUnit), 3));
			cell = row.createCell(equipmentMap.get(equipment.getName().trim()) + 1);
			cell.setCellValue((Integer) formula.getLoads());
		    }

		}
		row = sheet.getRow(formulaMap.get(Constants.TOTAL));
		cell = row.createCell(equipmentMap.get(equipment.getName().trim()));
		cell.setCellValue(
			(Double) Precision.round(ExcelUtils.lbsKgConversion(reportRequest.getMeasurementUnit(),
				equipment.getTotalProduction(), actualWeightUnit), 3));
		cell = row.createCell(equipmentMap.get(equipment.getName().trim()) + 1);
		cell.setCellValue((Integer) equipment.getTotalLoads());
	    }
	    List<FormulaDTO> washerFormulaList = data.getFormulaList();
	    for (FormulaDTO formula : washerFormulaList) {
		if (formulaMap != null && formulaMap.get(formula.getFormulaName()) != null) {
		    row = sheet.getRow(formulaMap.get(formula.getFormulaName()));
		    int equipmentSize = (equipmentMap.size() * 2);
		    if (formula != null && row != null) {
			cell = row.createCell(++equipmentSize);
			cell.setCellValue(
				(Double) Precision.round(ExcelUtils.lbsKgConversion(reportRequest.getMeasurementUnit(),
					formula.getWashedWeight(), actualWeightUnit), 3));
			cell = row.createCell(++equipmentSize);
			cell.setCellValue((Integer) formula.getLoads());
		    }
		}
	    }
	    ExcelUtils.bordersAcrossCellRange(sheet, firstRowForBorder, lastRowForBorder,
		    Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT, lastColumnForBorder);
	    ExcelUtils.setBordersToMergedCellsInRow(sheet);
	} catch (Exception e) {
	    LOG.error("Error occured while generating excel file : " + ExceptionUtils.getFullStackTrace(e));
	    throw e;
	}
	return HydroReportsBL.createStreamOutputForFile(workbook);
    }

    public StreamingOutput getExcelReportForChemicalSummary(ReportRequestDTO reportRequest) throws Exception {

	ChemicalSummaryDTO data = chemicalSummaryUtility(reportRequest);
	List<ChemicalDTO> chemicalList = data.getChemicalList();
	XSSFWorkbook workbook = new XSSFWorkbook();

	try {
	    Cell cell;
	    if (chemicalList.isEmpty() || chemicalList == null) {
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    }
	    SiteDTO siteDetails = data.getSiteDTO();
	    String actualVolumeUnit = MetricUnit.VOLUME;
	    if (siteDetails.getMetricUnit().equals(UsUnit.ID)) {
		actualVolumeUnit = UsUnit.VOLUME;
	    }
	    XSSFSheet sheet = workbook.createSheet(Constants.CHEMICAL_SUMMARY);
	    int rowCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_ROW_COUNT;
	    int cellCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;
	    sheet = ExcelUtils.createTopHeadings(workbook, sheet, rowCount, cellCount, siteDetails,
		    Constants.CHEMICAL_SUMMARY_REPORT_TAG, data.getMaxDate(), data.getMinDate(), reportRequest);
	    rowCount = sheet.getLastRowNum() + 2;
	    XSSFRow row = sheet.createRow(rowCount);

	    Map<String, Integer> chemicalMap = new LinkedHashMap<String, Integer>();
	    int chemicalMapValue = 1;
	    int lastColumnForBorder = 0;
	    int firstRowForBorder = rowCount;
	    if (permissionList.contains(Constants.PRIVILEGE_NAMES.CHEMICAL_SUMMARY_EST_USAGE)) {
		// for users other than site manager and site user.
		cell = ExcelUtils.createCell(row, Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT,
			Constants.FORMULA_NAME_FIELD);
		cell.setCellStyle(ExcelUtils.cellStyleFormulaHeading(sheet));
		sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.CHEMICAL_HEADING);
		for (ChemicalDTO chemical : chemicalList) {
		    cell = ExcelUtils.createCell(row, ++cellCount, chemical.getName());
		    sheet.addMergedRegion(new CellRangeAddress(rowCount, rowCount, cellCount++, cellCount));
		    cell.setCellStyle(ExcelUtils.cellStyle(sheet));
		    chemicalMap.put(chemical.getName(), chemicalMapValue);
		    chemicalMapValue = chemicalMapValue + 2;
		}
		lastColumnForBorder = chemicalMapValue;

		row = sheet.createRow(++rowCount);
		int columnCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;
		for (String mapKey : chemicalMap.keySet()) {
		    columnCount = chemicalMap.get(mapKey);
		    cell = ExcelUtils.createCell(row, columnCount,
			    Constants.ACTUAL_USAGE + Constants.REPORT_EXPORT_CONSTANTS.OPEN_PARENTHESES
				    + reportRequest.getMeasurementUnit()
				    + Constants.REPORT_EXPORT_CONSTANTS.CLOSE_PARETHESES);
		    cell.setCellStyle(ExcelUtils.cellStyleSubHeading(sheet));
		    sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.CHEMICAL_SUB_HEADING);
		    cell = ExcelUtils.createCell(row, ++columnCount, Constants.ERROR);
		    cell.setCellStyle(ExcelUtils.cellStyleSubHeading(sheet));
		    sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.CHEMICAL_SUB_HEADING);
		}
	    }

	    if (!permissionList.contains(Constants.PRIVILEGE_NAMES.CHEMICAL_SUMMARY_EST_USAGE)) {
		// for users other than site manager and site user.
		cell = ExcelUtils.createCell(row, Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT,
			Constants.FORMULA_NAME_FIELD);
		cell.setCellStyle(ExcelUtils.cellStyleSideHeading(sheet));
		sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.CHEMICAL_HEADING);
		for (ChemicalDTO chemical : chemicalList) {
		    cell = ExcelUtils.createCell(row, ++cellCount, chemical.getName());
		    cell.setCellStyle(ExcelUtils.cellStyle(sheet));
		    chemicalMap.put(chemical.getName(), chemicalMapValue++);
		}
		lastColumnForBorder = chemicalMapValue;

		row = sheet.createRow(++rowCount);
		int columnCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;
		for (String mapKey : chemicalMap.keySet()) {
		    columnCount = chemicalMap.get(mapKey);
		    cell = ExcelUtils.createCell(row, columnCount,
			    Constants.ACTUAL_USAGE + Constants.REPORT_EXPORT_CONSTANTS.OPEN_PARENTHESES
				    + reportRequest.getMeasurementUnit()
				    + Constants.REPORT_EXPORT_CONSTANTS.CLOSE_PARETHESES);
		    cell.setCellStyle(ExcelUtils.cellStyleSubHeading(sheet));
		    sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.CHEMICAL_SUB_HEADING);
		}
	    }

	    Map<String, Integer> formulaMap = new LinkedHashMap<String, Integer>();
	    List<String> formulaList = new LinkedList<>();
	    for (ChemicalDTO chemical : chemicalList) {
		List<FormulaDTO> formulaListForChemical = chemical.getFormulaList();
		if (!formulaListForChemical.isEmpty() || formulaListForChemical != null) {
		    for (FormulaDTO formula : formulaListForChemical) {
			if (!formulaList.contains(formula.getFormulaName()))
			    formulaList.add(formula.getFormulaName());
		    }
		}
	    }
	    // creating hashmap for formula using formulaList
	    for (String formula : formulaList) {
		formulaMap.put(formula, ++rowCount);
		row = sheet.createRow(rowCount);
		cell = ExcelUtils.createCell(row, Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT, formula);
		cell.setCellStyle(ExcelUtils.cellStyleSideHeading(sheet));
	    }
	    // adding total to formulaList
	    formulaMap.put(Constants.TOTAL, ++rowCount);
	    int lastRowForBorder = rowCount;
	    row = sheet.createRow(rowCount);
	    cell = ExcelUtils.createCell(row, Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT, Constants.TOTAL);
	    cell.setCellStyle(ExcelUtils.cellStyleSideHeading(sheet));

	    // pushing chemical data in excel sheet.
	    for (ChemicalDTO chemical : chemicalList) {
		List<FormulaDTO> formulaListForChemical = chemical.getFormulaList();
		if (!formulaListForChemical.isEmpty() || formulaListForChemical != null) {
		    for (FormulaDTO formula : formulaListForChemical) {
			row = sheet.getRow(formulaMap.get(formula.getFormulaName()));
			cell = row.createCell(chemicalMap.get(chemical.getName()));
			cell.setCellValue(
				(Double) Precision.round(ExcelUtils.galKgConversion(reportRequest.getMeasurementUnit(),
					formula.getActualUsage(), actualVolumeUnit), 3));
			if (formula.getErrorUsage() != null && formula.getErrorUsage() != 0) {
			    cell = row.createCell(chemicalMap.get(chemical.getName()) + 1);
			    cell.setCellValue((Double) formula.getErrorUsage());
			}

		    }
		}
		row = sheet.getRow(formulaMap.get(Constants.TOTAL));
		cell = row.createCell(chemicalMap.get(chemical.getName()));
		cell.setCellValue(
			(Double) Precision.round(ExcelUtils.galKgConversion(reportRequest.getMeasurementUnit(),
				chemical.getTotalActualUsage(), actualVolumeUnit), 3));
		if (chemical.getTotalErrorUsage() != null && chemical.getTotalErrorUsage() != 0) {
		    cell = row.createCell(chemicalMap.get(chemical.getName()) + 1);
		    cell.setCellValue((Double) chemical.getTotalErrorUsage());
		}
	    }
	    ExcelUtils.bordersAcrossCellRange(sheet, firstRowForBorder, lastRowForBorder,
		    Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT, --lastColumnForBorder);
	    ExcelUtils.setBordersToMergedCellsInRow(sheet);
	} catch (Exception e) {
	    LOG.error("Error occured while generating excel file : " + ExceptionUtils.getFullStackTrace(e));
	    throw e;
	}
	return HydroReportsBL.createStreamOutputForFile(workbook);
    }

    public StreamingOutput getExcelReportForCostSummary(ReportRequestDTO reportRequest) throws Exception {
	CostSummaryDTO data = costSummaryUtility(reportRequest);
	List<FormulaDTO> formulaList = data.getFormulaList();
	XSSFWorkbook workbook = new XSSFWorkbook();
	try {
	    Cell cell;
	    if (formulaList.isEmpty() || formulaList == null) {
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    }
	    SiteDTO siteDTO = data.getSiteDTO();
	    String actualWeightUnit = MetricUnit.WEIGHT;
	    String cwtLabelForActualMetric = MetricUnit.CW;
	    if (siteDTO.getMetricUnit().equals(UsUnit.ID)) {
		actualWeightUnit = UsUnit.WEIGHT;
		cwtLabelForActualMetric = UsUnit.CW;
	    }
	    XSSFSheet sheet = workbook.createSheet(Constants.COST_SUMMARY);
	    int rowCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_ROW_COUNT;
	    int cellCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;
	    int lastColumnForBorder = 0;
	    sheet = ExcelUtils.createTopHeadings(workbook, sheet, rowCount, cellCount, siteDTO,
		    Constants.COST_SUMMARY_REPORT_TAG, data.getMaxDate(), data.getMinDate(), reportRequest);

	    rowCount = sheet.getLastRowNum() + 2;
	    Row row = sheet.createRow(rowCount);

	    row = sheet.createRow(++rowCount);

	    String cwtLabel = (Constants.REAL_COST + Constants.REPORT_EXPORT_CONSTANTS.OPEN_PARENTHESES
		    + Constants.REPORT_EXPORT_CONSTANTS.PER + ExcelUtils
			    .realCwtLabel(reportRequest.getMeasurementUnit(), actualWeightUnit, cwtLabelForActualMetric)
		    + Constants.REPORT_EXPORT_CONSTANTS.CLOSE_PARETHESES);

	    Map<String, Integer> costMap = new LinkedHashMap<String, Integer>() {
		int columnCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;

		{
		    put(Constants.WASHED + Constants.REPORT_EXPORT_CONSTANTS.SPACE + reportRequest.getMeasurementUnit(),
			    ++columnCount);
		    put(Constants.REAL_COST + Constants.REPORT_EXPORT_CONSTANTS.OPEN_PARENTHESES
			    + Constants.REPORT_EXPORT_CONSTANTS.ABSOLUTE
			    + Constants.REPORT_EXPORT_CONSTANTS.CLOSE_PARETHESES, ++columnCount);
		    put(cwtLabel, ++columnCount);
		    put(Constants.ERROR, ++columnCount);
		}
	    };

	    int columnCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;

	    cell = ExcelUtils.createCell(row, Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT,
		    Constants.FORMULA_NAME_FIELD);
	    cell.setCellStyle(ExcelUtils.cellStyleFormulaHeading(sheet));
	    sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.COST_SIDE_HEADING);
	    int firstRowForBorder = rowCount;
	    for (String costKey : costMap.keySet()) {
		columnCount = costMap.get(costKey);
		cell = ExcelUtils.createCell(row, columnCount, costKey);
		cell.setCellStyle(ExcelUtils.cellStyleFormulaHeading(sheet));
		sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.COST_HEADING);
	    }

	    for (FormulaDTO formula : formulaList) {
		row = sheet.createRow(++rowCount);
		cell = ExcelUtils.createCell(row, Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT,
			formula.getFormulaName());
		cell.setCellStyle(ExcelUtils.cellStyleSideHeading(sheet));
		cell = row.createCell(costMap.get(Constants.WASHED + Constants.REPORT_EXPORT_CONSTANTS.SPACE
			+ reportRequest.getMeasurementUnit()));
		cell.setCellValue(
			(Double) Precision.round(ExcelUtils.lbsKgConversion(reportRequest.getMeasurementUnit(),
				formula.getWashedWeight(), actualWeightUnit), 3));
		cell = row
			.createCell(costMap.get(Constants.REAL_COST + Constants.REPORT_EXPORT_CONSTANTS.OPEN_PARENTHESES
				+ Constants.REPORT_EXPORT_CONSTANTS.ABSOLUTE
				+ Constants.REPORT_EXPORT_CONSTANTS.CLOSE_PARETHESES));
		cell.setCellValue(formula.getRealCost());
		cell = row.createCell(costMap.get(cwtLabel));
		cell.setCellValue(ExcelUtils.realCwtCalculation(formula.getRealCost(), formula.getWashedWeight(),
			reportRequest.getMeasurementUnit(), actualWeightUnit, formula.getRealCw()));
		lastColumnForBorder = costMap.get(cwtLabel);
		if (formula.getErrorCost() != 0) {
		    cell = row.createCell(costMap.get(Constants.ERROR));
		    cell.setCellValue(formula.getErrorCost());
		}
	    }

	    row = sheet.createRow(++rowCount);
	    int lastRowForBorder = rowCount;
	    cell = ExcelUtils.createCell(row, 0, Constants.TOTAL);
	    cell.setCellStyle(ExcelUtils.cellStyleSideHeading(sheet));
	    cell = row.createCell(costMap.get(
		    Constants.WASHED + Constants.REPORT_EXPORT_CONSTANTS.SPACE + reportRequest.getMeasurementUnit()));
	    cell.setCellValue((Double) Precision.round(ExcelUtils.lbsKgConversion(reportRequest.getMeasurementUnit(),
		    data.getTotalWeight(), actualWeightUnit), 3));
	    cell = row.createCell(costMap.get(Constants.REAL_COST + Constants.REPORT_EXPORT_CONSTANTS.OPEN_PARENTHESES
		    + Constants.REPORT_EXPORT_CONSTANTS.ABSOLUTE + Constants.REPORT_EXPORT_CONSTANTS.CLOSE_PARETHESES));
	    cell.setCellValue(data.getTotalRealCost());
	    cell = row.createCell(costMap.get(cwtLabel));
	    cell.setCellValue(ExcelUtils.realCwtCalculation(data.getTotalRealCost(), data.getTotalWeight(),
		    reportRequest.getMeasurementUnit(), actualWeightUnit, data.getTotalRealCw()));
	    ExcelUtils.bordersAcrossCellRange(sheet, firstRowForBorder, lastRowForBorder,
		    Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT, ++lastColumnForBorder);
	    ExcelUtils.setBordersToMergedCellsInRow(sheet);
	} catch (Exception e) {
	    LOG.error("Error occured while generating excel file : " + ExceptionUtils.getFullStackTrace(e));
	    throw e;
	}
	return HydroReportsBL.createStreamOutputForFile(workbook);
    }

    public StreamingOutput getExcelReportForAlarmSummary(ReportRequestDTO reportRequest) throws Exception {
	AlarmSummaryDTO data = alarmSummary(reportRequest);
	List<AlarmDTO> alarmList = data.getAlarmList();
	XSSFWorkbook workbook = new XSSFWorkbook();
	SiteDTO site = new SiteDTO();
	site.setSiteId(reportRequest.getSiteId());
	site = ((SiteDao) hydroDao).getSiteDetails(site);
	boolean streamingEnabled = site.isStreamingEnabled();
	try {
	    Cell cell;
	    if (alarmList == null || alarmList.isEmpty()) {
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    }

	    SiteDTO siteDTO = data.getSiteDTO();
	    String actualVolumeUnit = MetricUnit.ALARM_VOLUME;
	    if (siteDTO.getMetricUnit().equals(UsUnit.ID)) {
		actualVolumeUnit = UsUnit.ALARM_VOLUME;
	    }

	    XSSFSheet sheet = workbook.createSheet(Constants.ALARM_SUMMARY);
	    int rowCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_ROW_COUNT;
	    int cellCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;
	    sheet = ExcelUtils.createTopHeadings(workbook, sheet, rowCount, cellCount, siteDTO,
		    Constants.ALARM_SUMMARY_REPORT_TAG, data.getMaxDate(), data.getMinDate(), reportRequest);

	    rowCount = sheet.getLastRowNum() + 2;
	    Row row = sheet.createRow(rowCount);

	    int columnCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;

	    rowCount = sheet.getLastRowNum();

	    int firstRowForBorder = rowCount;

	    Map<String, Integer> alarmHeading = new LinkedHashMap<String, Integer>();
	    alarmHeading.put(Constants.WARNINGS, ++columnCount);
	    cell = ExcelUtils.createCell(row, columnCount, Constants.WARNINGS);
	    cell.setCellStyle(ExcelUtils.cellStyleFormulaHeading(sheet));
	    sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.ALARM_HEADING);
	    alarmHeading.put(Constants.MACHINES, ++columnCount);
	    cell = ExcelUtils.createCell(row, columnCount, Constants.MACHINES);
	    cell.setCellStyle(ExcelUtils.cellStyleFormulaHeading(sheet));
	    sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.ALARM_HEADING);

	    Row headingRowCount = sheet.getRow(rowCount);
	    List<String> machineHeading = new LinkedList<>();
	    Map<String, Integer> alarmMap = new LinkedHashMap<String, Integer>();
	    for (AlarmDTO alarm : alarmList) {
		if (alarm.getMachineList() != null && !ReportUtils.isSystemAlarm(alarm.getAlarmId())) {
		    for (MachineDTO machine : alarm.getMachineList()) {
			String heading = machine.getMachineName().trim();
			if (!machineHeading.contains(heading)) {
			    machineHeading.add(heading);
			    alarmHeading.put(heading, ++columnCount);
			    cell = ExcelUtils.createCell(headingRowCount, columnCount, heading);
			    cell.setCellStyle(ExcelUtils.cellStyleFormulaHeading(sheet));
			    sheet.setColumnWidth(cell.getColumnIndex(),
				    Constants.REPORT_EXPORT_CONSTANTS.ALARM_HEADING);
			}

		    }
		}
		row = sheet.createRow(++rowCount);
		cell = ExcelUtils.createCell(row, 0, alarm.getAlarmName());
		cell.setCellStyle(ExcelUtils.cellStyleSideHeading(sheet));
		sheet.setColumnWidth(cell.getColumnIndex(), Constants.REPORT_EXPORT_CONSTANTS.ALARM_SIDE_HEADING);
		alarmMap.put(alarm.getAlarmName(), rowCount);
	    }
	    int lastColumnForBorder = columnCount;
	    int lastRowForBorder = rowCount;

	    for (AlarmDTO alarm : alarmList) {
		if (alarm.getTotalWarnings() != null && alarm.getTotalMachines() != null) {
		    row = sheet.getRow(alarmMap.get(alarm.getAlarmName()));
		    cell = row.createCell(alarmHeading.get(Constants.WARNINGS));
		    cell.setCellValue(alarm.getTotalWarnings());
		    cell = row.createCell(alarmHeading.get(Constants.MACHINES));
		    cell.setCellValue(alarm.getTotalMachines());
		    if (alarm.getMachineList() != null && row != null) {
			List<MachineDTO> machineList = alarm.getMachineList();
			for (MachineDTO machine : machineList) {
			    if (machine.getWarningCount() != 0) {
				cell = row.createCell(alarmHeading.get(machine.getMachineName().trim()));
				cell.setCellValue(machine.getWarningCount());
			    }
			}
		    }
		}
	    }
	    ExcelUtils.bordersAcrossCellRange(sheet, firstRowForBorder, lastRowForBorder,
		    Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT, lastColumnForBorder);
	    ExcelUtils.setBordersToMergedCellsInRow(sheet);
	    // creating separate alarm pages, if data is present for machine.

	    XSSFSheet equipmentSheet = null;
	    for (AlarmDTO alarm : alarmList) {
		List<String> alarmHeader = alarm.getHeaderList();
		int equipmentColumnCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT;
		int equipmentRowCount = Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_ROW_COUNT;
		List<MachineDTO> alarmMachineList = alarm.getMachineList();
		if (!ReportUtils.isSystemAlarm(alarm.getAlarmId()) && alarm.getTotalWarnings() != null
			&& alarmMachineList != null && alarm.getTotalMachines() != null && alarmHeader != null) {
		    equipmentSheet = workbook.createSheet(alarm.getAlarmName());

		    ExcelUtils.createTopHeadingsForAlarmSubScreen(workbook, equipmentSheet,
			    equipmentSheet.getLastRowNum(), cellCount, siteDTO, Constants.ALARM_SUMMARY_REPORT_TAG,
			    data.getMaxDate(), data.getMinDate(), alarm.getAlarmName(), reportRequest);
		    equipmentRowCount = equipmentSheet.getLastRowNum() + 1;
		    row = equipmentSheet.createRow(equipmentRowCount++);
		    for (MachineDTO machine : alarmMachineList) {
			if (machine.getWarningList() != null && machine.getWarningCount() != 0) {
			    row = equipmentSheet.createRow(equipmentRowCount++);
			    cell = ExcelUtils.createCell(row, equipmentColumnCount, machine.getMachineName());
			    cell.setCellStyle(ExcelUtils.cellStyleFormulaHeading(equipmentSheet));
			    int warningfirstRowForBorder = equipmentRowCount;
			    HashMap<String, Integer> machineHeader = ExcelUtils.createMachineHeader(equipmentSheet,
				    equipmentRowCount++, alarmHeader);
			    for (WarningDTO warning : machine.getWarningList()) {
				if (siteDTO.isStreamingEnabled()) {
				    ExcelUtils.pushingMachineDataToExcel(equipmentSheet, row,
					    equipmentSheet.getLastRowNum() + 1, alarm.getAlarmId(), warning,
					    reportRequest.getMeasurementUnit(), actualVolumeUnit, machineHeader);
				} else {
				    ExcelUtils.pushingMDBMachineDataToExcel(equipmentSheet, row,
					    equipmentSheet.getLastRowNum() + 1, alarm.getAlarmId(), warning,
					    reportRequest.getMeasurementUnit(), actualVolumeUnit, machineHeader);
				}
			    }
			    ExcelUtils.bordersAcrossCellRange(equipmentSheet, warningfirstRowForBorder,
				    equipmentSheet.getLastRowNum(),
				    Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT, alarmHeader.size() - 1);
			    equipmentRowCount = equipmentSheet.getLastRowNum() + 1;
			    row = equipmentSheet.createRow(equipmentRowCount++);
			}
			ExcelUtils.setBordersToMergedCellsInRow(equipmentSheet);
		    }
		}
		if (ReportUtils.isSystemAlarm(alarm.getAlarmId()) && alarm.getSystemWarningList() != null) {
		    equipmentSheet = workbook.createSheet(alarm.getAlarmName());
		    ExcelUtils.createTopHeadingsForAlarmSubScreen(workbook, equipmentSheet,
			    equipmentSheet.getLastRowNum(), cellCount, siteDTO, Constants.ALARM_SUMMARY_REPORT_TAG,
			    data.getMaxDate(), data.getMinDate(), alarm.getAlarmName(), reportRequest);
		    equipmentRowCount = equipmentSheet.getLastRowNum() + 1;
		    int warningfirstRowForBorder = equipmentRowCount;
		    row = equipmentSheet.createRow(equipmentRowCount++);
		    HashMap<String, Integer> machineHeader = ExcelUtils.createMachineHeader(equipmentSheet,
			    equipmentRowCount++, alarmHeader);
		    if (machineHeader != null) {
			for (WarningDTO warning : alarm.getSystemWarningList()) {
			    if (siteDTO.isStreamingEnabled()) {
				ExcelUtils.pushingMachineDataToExcel(equipmentSheet, row,
					equipmentSheet.getLastRowNum() + 1, alarm.getAlarmId(), warning,
					reportRequest.getMeasurementUnit(), actualVolumeUnit, machineHeader);
			    } else {
				ExcelUtils.pushingMDBMachineDataToExcel(equipmentSheet, row,
					equipmentSheet.getLastRowNum() + 1, alarm.getAlarmId(), warning,
					reportRequest.getMeasurementUnit(), actualVolumeUnit, machineHeader);
			    }
			}
			ExcelUtils.bordersAcrossCellRange(equipmentSheet, warningfirstRowForBorder,
				equipmentSheet.getLastRowNum(), Constants.REPORT_EXPORT_CONSTANTS.DEFAULT_COLUMN_COUNT,
				alarmHeader.size() - 1);
		    }
		    ExcelUtils.setBordersToMergedCellsInRow(equipmentSheet);
		}
	    }

	} catch (Exception e) {
	    LOG.error("Error occured while generating excel file : " + ExceptionUtils.getFullStackTrace(e));
	}

	return HydroReportsBL.createStreamOutputForFile(workbook);
    }

    public static StreamingOutput createStreamOutputForFile(Workbook workbook) throws Exception {
	StreamingOutput streamOutput = new StreamingOutput() {

	    @Override
	    public void write(OutputStream out) throws IOException, WebApplicationException {
		workbook.write(out);
	    }
	};
	return streamOutput;
    }

    public StreamingOutput errorResponse(String errorMessage) throws Exception {
	XSSFWorkbook workbook = new XSSFWorkbook();
	XSSFSheet sheet = workbook.createSheet(Constants.REPORT_EXPORT_CONSTANTS.ERROR_SHEET);
	Row row = sheet.createRow(sheet.getLastRowNum());
	Cell cell = ExcelUtils.createCell(row, 0, errorMessage);
	cell.setCellStyle(ExcelUtils.cellStyleError(sheet));
	return HydroReportsBL.createStreamOutputForFile(workbook);
    }

    protected List<Object> getInsufficientParamsReport(ReportRequestDTO reportRequestDTO) {
	List<Object> params = new LinkedList<>();
	if (reportRequestDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.REPORT_REQUEST_OBJECT);
	}
	if (StringUtils.isEmpty(reportRequestDTO.getSiteId())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_ID);
	}
	if (StringUtils.isEmpty(reportRequestDTO.getEquipmentId())) {
	    params.add(ErrorCodes.InsufficientParams.EQUIPMENT_ID);
	}
	if (StringUtils.isEmpty(reportRequestDTO.getToDate())) {
	    params.add(ErrorCodes.InsufficientParams.TO_DATE);
	}
	if (StringUtils.isEmpty(reportRequestDTO.getFromDate())) {
	    params.add(ErrorCodes.InsufficientParams.FROM_DATE);
	}

	return params;
    }

    public DailyReportResponseDTO generateRealTimeReport(DailyReportRequestDTO requestDTO) throws Exception {
	DailyReportResponseDTO responseDTO = new DailyReportResponseDTO();
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.GENERATE_REPORT);
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.REAL_TIME_REPORT);
	List<Object> params = getInsufficientParamsRealTimeReport(requestDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	SiteDTO siteDTO = new SiteDTO();
	siteDTO.setSiteId(requestDTO.getSiteId());
	siteDTO = ((SiteDao) hydroDao).getSiteDetails(siteDTO);

	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	EquipmentListDTO eq = siteBl.getEquipmentSpecification(siteDTO);
	List<EquipmentDTO> eqList = eq.getEquipmentList();
	EquipmentDTO equipment = null;
	for (EquipmentDTO obj : eqList) {
	    if (obj.getEquipmentId().equalsIgnoreCase(requestDTO.getEquipmentId())) {
		equipment = obj;
		break;
	    }
	}
	if (equipment == null) {
	    throw new SystemException(ErrorCodes.INVALID_EQUIPMENT_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}

	// String currentDate = ReportUtils.getCurrentDate(siteDTO.getTimeZone());
	String currentDate = ReportUtils.getCurrentUTCDate(siteDTO.getTimeZone());

	String[] dateArr = currentDate.split("-");
	requestDTO.setSiteId(siteDTO.getSiteId());

	// checking if equipment type is washer, if true then pass json query
	if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.WASHER_EXTRACTOR))
	    responseDTO = washerDailyReportUtility(requestDTO, equipment, siteDTO);
	else if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.TUNNEL))
	    // call tunnel logic
	    responseDTO = tunnelDailyReportUtility(requestDTO, equipment, siteDTO);
	else
	    throw new SystemException(ErrorCodes.INVALID_EQUIPMENT_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);

	return responseDTO;
    }

    public DailyReportResponseDTO generateDayWiseHistoricalReport(DailyReportRequestDTO requestDTO) throws Exception {
	DailyReportUtils dailyReportUtils = new DailyReportUtils();
	DailyReportResponseDTO responseDTO = new DailyReportResponseDTO();
	ConfigReader config = new ConfigReader();
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.GENERATE_REPORT);
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.REAL_TIME_REPORT);
	List<Object> params = getInsufficientParamsDayWiseHistoricalReport(requestDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	SiteDTO siteDTO = new SiteDTO();
	siteDTO.setSiteId(requestDTO.getSiteId());
	siteDTO = ((SiteDao) hydroDao).getSiteDetails(siteDTO);

	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	EquipmentListDTO eq = siteBl.getEquipmentSpecification(siteDTO);
	List<EquipmentDTO> eqList = eq.getEquipmentList();
	EquipmentDTO equipment = null;
	for (EquipmentDTO obj : eqList) {
	    if (obj.getEquipmentId().equalsIgnoreCase(requestDTO.getEquipmentId())) {
		equipment = obj;
		break;
	    }
	}
	if (equipment == null) {
	    throw new SystemException(ErrorCodes.INVALID_EQUIPMENT_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	requestDTO.setSiteId(siteDTO.getSiteId());
	requestDTO.setSetEvent(true);
	requestDTO.setHistoricalReport(true);
	requestDTO.setDate(requestDTO.getDate());
	requestDTO.setIndexDate(requestDTO.getDate());

	// check if selected shift list contains "Full Day", if present then
	// remove other shifts.
	List<ShiftDTO> selectedShift = new ArrayList<>();
	ShiftDTO defaultShift = dailyReportUtils.getDefaultShift();
	if (requestDTO.getSelectedShifts() != null) {
	    selectedShift = requestDTO.getSelectedShifts();
	    for (ShiftDTO shift : selectedShift) {
		if (shift.getShiftName().equalsIgnoreCase(config.getAppConfig(Constants.DEFAULT_SHIFT))) {
		    selectedShift = new ArrayList<>();
		    selectedShift.add(defaultShift);
		}
	    }
	} else {
	    selectedShift = new ArrayList<>();
	    selectedShift.add(defaultShift);
	}

	requestDTO.setSelectedShifts(selectedShift);

	// checking if equipment type is washer, if true then pass json query
	if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.WASHER_EXTRACTOR))
	    responseDTO = washerDailyReportUtility(requestDTO, equipment, siteDTO);
	else if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.TUNNEL))
	    // call tunnel logic
	    responseDTO = tunnelDailyReportUtility(requestDTO, equipment, siteDTO);
	else
	    throw new SystemException(ErrorCodes.INVALID_EQUIPMENT_ID, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);

	return responseDTO;
    }

    private String getDailyIndex(Date date, String siteTimeZone, String siteId, boolean startOfday) throws Exception {
	Calendar calendar = Calendar.getInstance();
	calendar.setTime(CommonUtils.convertUtilZonedDateToUTC(date, siteTimeZone, startOfday));
	return ReportUtils.getIndexName(siteId, calendar.get(Calendar.MONTH) + 1, calendar.get(Calendar.YEAR));
    }

    protected List<Object> getInsufficientParamsRealTimeReport(DailyReportRequestDTO reportDTO) {
	List<Object> params = new LinkedList<>();
	if (reportDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.REPORT_REQUEST_OBJECT);
	}
	if (StringUtils.isEmpty(reportDTO.getSiteId())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_ID);
	}
	if (StringUtils.isEmpty(reportDTO.getEquipmentId())) {
	    params.add(ErrorCodes.InsufficientParams.EQUIPMENT_ID);
	}
	return params;
    }

    protected List<Object> getInsufficientParamsDayWiseHistoricalReport(DailyReportRequestDTO reportDTO) {
	List<Object> params = new LinkedList<>();
	if (reportDTO == null) {
	    params.add(ErrorCodes.InsufficientParams.REPORT_REQUEST_OBJECT);
	}
	if (StringUtils.isEmpty(reportDTO.getSiteId())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_ID);
	}
	if (StringUtils.isEmpty(reportDTO.getEquipmentId())) {
	    params.add(ErrorCodes.InsufficientParams.EQUIPMENT_ID);
	}
	if (StringUtils.isEmpty(reportDTO.getDate().toString())) {
	    params.add(ErrorCodes.InsufficientParams.DATE);
	}
	return params;
    }

    public static void handleEsError(JsonObject responseObject) throws Exception {
	if (responseObject == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonObject esError = (JsonObject) responseObject.get(Constants.REPORTS.ERROR);
	if (esError != null) {
	    LOG.error("ES Error" + responseObject);
	    JsonArray jArray = esError.getAsJsonArray(Constants.REPORTS.ROOT_CAUSE);
	    esError = jArray.get(0).getAsJsonObject();
	    String esErrorType = esError.get(Constants.REPORTS.TYPE).getAsString();
	    switch (esErrorType) {
	    case Constants.ES_EXCEPTION_TYPE.INDEX_NOT_FOUND_EXCEPTION:
		throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	    default:
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	}
    }

    /**
     * Getting the 3 months average for a production summary report.
     * 
     * @return washer production summary report for prev. months.
     * @throws Exception
     */
    public WasherProductionDTO washerProductionSummaryAvgForPrevMonth(ReportRequestDTO requestDTO) throws Exception {
	int avgReferenceMonth = requestDTO.getAvgReference();
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.GENERATE_REPORT);
	permissionDeniedCheck(Constants.PRIVILEGE_NAMES.WASHER_PRODUCTION_SUMMARY_REPORT);
	List<Object> params = getInsufficientParamsReport(requestDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}

	if (avgReferenceMonth == 0) {
	    avgReferenceMonth = 3;
	}

	SiteDTO siteDTO = getSiteDetails(requestDTO);
	if (!((SiteDao) hydroDao).hasVisibility(user, siteDTO)) {
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_ACCESSIBLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	EquipmentDTO equipment = getEquipment(requestDTO, siteDTO);

	WasherProductionDTO response = null;

	if (siteDTO.isStreamingEnabled()
		&& (Constants.EquipmentType.TUNNEL).equalsIgnoreCase(equipment.getEquipmentType())) {
	    response = TunnelEdgeAvgForPrevMonthReportProcessing(requestDTO, siteDTO, equipment, avgReferenceMonth);
	} else {
	    response = mdbAvgForPrevMonthReportProcessing(requestDTO, siteDTO, equipment, avgReferenceMonth);
	}

	return response;

    }

    private WasherProductionDTO TunnelEdgeAvgForPrevMonthReportProcessing(ReportRequestDTO requestDTO, SiteDTO siteDTO,
	    EquipmentDTO equipment, int avgReferenceMonth) throws Exception {
	String siteTimeZone = siteDTO.getTimeZone();

	StringBuilder sb = getThreemothsBatchIds(requestDTO, siteDTO, equipment, siteTimeZone);

	String query = createAvgMonthESQuery(requestDTO, Constants.REPORTS.TUNNEL_EDGE_PROD_SUMMARY_QUERY, equipment,
		avgReferenceMonth, siteTimeZone);

	query = query.replace(Constants.BATCH_IDS_VAL, sb);
	ConfigReader configReader = ConfigReader.getObject();
	JsonObject responseObject = executeAvgMonthESQuery(requestDTO, avgReferenceMonth, query, configReader,
		siteTimeZone);
	JsonObject agg = handleError(responseObject);

	// check if any of the index present in indexList contributed in
	// creating response, if not then not further calculations are required.
	JsonObject contributedIndicesForResponse = (JsonObject) (agg).get(Constants.INDEX_AGGREGATION);
	JsonArray contributedIndicesForResponseArray = contributedIndicesForResponse
		.getAsJsonArray(Constants.REPORTS.BUCKETS);
	int contributedIndicesSize = contributedIndicesForResponseArray.size();
	List<String> avgCalculatedForMonths = new LinkedList<>();

	if (contributedIndicesSize > 0) {
	    for (int i = 0; i < contributedIndicesForResponseArray.size(); i++) {
		JsonObject indexJson = contributedIndicesForResponseArray.get(i).getAsJsonObject();
		String key = indexJson.get(Constants.REPORTS.KEY).getAsString();
		String[] keyValue = key.split("-");
		String monthYearValue = Month.of(Integer.parseInt(keyValue[2])).name() + "-" + keyValue[3];
		avgCalculatedForMonths.add(monthYearValue);
	    }
	}

	Map<String, String> formulaMap = getFormulaMap(equipment);
	List<FormulaDTO> formulaReportList = createFormulaReportList(equipment.getFormulaList());

	JsonObject formulaAggregation = (JsonObject) (agg).get(Constants.REPORTS.FORMULA_AGGREGATION);
	if (formulaAggregation == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonArray formulaJArray = formulaAggregation.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (formulaJArray == null || formulaJArray.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	String maxDateForReport = getMaxDate(requestDTO, siteDTO, equipment);

	EquipmentReportDTO unit = new EquipmentReportDTO();
	unit.setId(equipment.getLm2Seq());
	List<FormulaDTO> formulaList = null;
	List<EquipmentReportDTO> equipmentList = new LinkedList<>();
	int totalProductionLoads = 0;
	int totalProductionWeight = 0;
	int totalLoads = 0;
	long totalWeight = 0;
	formulaList = new LinkedList<>();
	for (int j = 0; j < formulaJArray.size(); j++) {
	    JsonObject formulaJson = formulaJArray.get(j).getAsJsonObject();
	    JsonObject canal = null;
	    String formulaName = formulaJson.get(Constants.REPORTS.KEY).getAsString();
	    if (!StringUtils.isEmpty(formulaName)) {
		formulaName = formulaName.trim();
		FormulaDTO formula = new FormulaDTO();
		formula.setFormulaName(formulaName.toUpperCase());
		if (StringUtils.isEmpty(formulaMap.get(formulaName))) {
		    formulaMap.put(formulaName, formulaName);
		    FormulaDTO tempFormula = new FormulaDTO();
		    tempFormula.setFormulaId(formulaName);
		    tempFormula.setFormulaName(formulaName);
		    tempFormula.setLoads(0);
		    tempFormula.setWashedWeight((long) 0);
		    formulaReportList.add(tempFormula);
		}
		formula.setFormulaId(formulaMap.get(formulaName));
		long weight = 0;
		int load = 0;
		try {
		    /*
		     * canal = ((JsonArray) ((JsonObject)
		     * formulaJson.get(Constants.REPORTS.BATCH_AGGREGATION))
		     * .get(Constants.REPORTS.BUCKETS)).get(0).getAsJsonObject(); weight =
		     * ((JsonObject)
		     * canal.get(Constants.REPORTS.AVG_REAL_KG)).get(Constants.REPORTS.VALUE)
		     * .getAsLong();
		     */

		    weight = ((JsonObject) formulaJson.get(Constants.REPORTS.SUM_REAL)).get(Constants.REPORTS.VALUE)
			    .getAsLong();

		    weight = (long) Math.round(((double) weight / contributedIndicesSize));

		    formula.setWashedWeight(weight);
		    totalWeight += weight;

		    load = ((JsonArray) ((JsonObject) formulaJson.get(Constants.REPORTS.BATCH_AGGREGATION))
			    .get(Constants.REPORTS.BUCKETS)).size();
		    load = (int) Math.round(((double) load / contributedIndicesSize));
		} catch (Exception e) {
		    LOG.error("Error Fetching load count for FOrmula : " + formulaName + " Error: " + e.getMessage());
		    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		}
		for (FormulaDTO rootFormula : formulaReportList) {
		    if (!StringUtils.isEmpty(rootFormula.getFormulaName())
			    && rootFormula.getFormulaName().equalsIgnoreCase(formulaName)) {
			rootFormula.setLoads(getLoadsWashed(rootFormula.getLoads() + load));
			rootFormula.setWashedWeight(getWeightWashed(rootFormula.getWashedWeight() + weight));
		    }

		}
		formula.setLoads(load);
		totalLoads += load;
		if (!StringUtils.isEmpty(formulaName)) {
		    formulaList.add(formula);
		}

	    }
	}

	List<TunnelDTO> tunnelList = equipment.getTunnelList();
	for (TunnelDTO tunnel : tunnelList) {
	    unit.setName(tunnel.getName());
	    unit.setCapacity(tunnel.getLoad());
	    unit.setLm2Seq(tunnel.getLm2Seq());
	}

	totalProductionWeight += totalWeight;
	totalProductionLoads += totalLoads;
	unit.setTotalProduction(totalWeight);
	unit.setTotalLoads(totalLoads);
	formulaList.sort(Comparator.comparing(FormulaDTO::getFormulaName));
	unit.setFormulaList(formulaList);
	unit.setName(unit.getLm2Seq() + "." + unit.getName());
	equipmentList.add(unit);

	// JsonArray jArray = ReportUtils.aggregationsQuery(aggregationsObject);
	populateEquipmentDTO(equipmentList, totalProductionLoads, totalProductionWeight);

	WasherProductionDTO response;
	response = populateWasherProductionDTO(requestDTO, siteDTO, maxDateForReport, equipmentList,
		totalProductionLoads, totalProductionWeight, formulaReportList, avgCalculatedForMonths, siteTimeZone);
	return response;
    }

    private WasherProductionDTO mdbAvgForPrevMonthReportProcessing(ReportRequestDTO requestDTO, SiteDTO siteDTO,
	    EquipmentDTO equipment, int avgReferenceMonth) throws SystemException, Exception {
	String query = null;
	String siteTimeZone = siteDTO.getTimeZone();
	String reportQueryName = null;

	if (Constants.EquipmentType.TUNNEL.equalsIgnoreCase(equipment.getEquipmentType())) {
	    reportQueryName = Constants.REPORTS.TUNNEL_PROD_SUMMARY_QUERY;
	} else if (Constants.EquipmentType.WASHER_EXTRACTOR.equalsIgnoreCase(equipment.getEquipmentType())) {
	    reportQueryName = Constants.REPORTS.WE_PROD_SUMMARY_QUERY;
	}

	query = createAvgMonthESQuery(requestDTO, reportQueryName, equipment, avgReferenceMonth, siteTimeZone);

	ConfigReader configReader = ConfigReader.getObject();

	JsonObject responseObject = executeAvgMonthESQuery(requestDTO, avgReferenceMonth, query, configReader,
		siteTimeZone);
	handleEsError(responseObject);
	JsonObject agg = (JsonObject) responseObject.get(Constants.REPORTS.AGGREGATIONS);
	if (agg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	// check if any of the index present in indexList contributed in
	// creating response, if not then not further calculations are required.
	JsonObject contributedIndicesForResponse = (JsonObject) (agg).get(Constants.INDEX_AGGREGATION);
	JsonArray contributedIndicesForResponseArray = contributedIndicesForResponse
		.getAsJsonArray(Constants.REPORTS.BUCKETS);
	int contributedIndicesSize = contributedIndicesForResponseArray.size();
	List<String> avgCalculatedForMonths = new LinkedList<>();

	if (contributedIndicesSize > 0) {
	    for (int i = 0; i < contributedIndicesForResponseArray.size(); i++) {
		JsonObject indexJson = contributedIndicesForResponseArray.get(i).getAsJsonObject();
		String key = indexJson.get(Constants.REPORTS.KEY).getAsString();
		String[] keyValue = key.split("-");
		String monthYearValue = Month.of(Integer.parseInt(keyValue[2])).name() + "-" + keyValue[3];
		avgCalculatedForMonths.add(monthYearValue);
	    }
	}

	JsonObject machineAgg = (JsonObject) (agg).get(Constants.REPORTS.MACHINE_AGGREGATION);
	if (machineAgg == null) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}
	JsonArray unitBuckets = machineAgg.getAsJsonArray(Constants.REPORTS.BUCKETS);
	if (unitBuckets == null || unitBuckets.size() <= 0) {
	    throw new SystemException(ErrorCodes.NO_DATA_FOUND, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.DATA_NOT_FOUND, null);
	}

	String maxDateForReport = getMaxDate(requestDTO, siteDTO, equipment);

	List<EquipmentReportDTO> equipmentList = new LinkedList<>();
	int totalProductionLoads = 0;
	int totalProductionWeight = 0;
	List<FormulaDTO> formulaReportList = new LinkedList<>();
	if (unitBuckets != null && unitBuckets.size() > 0) {
	    List<FormulaMetaDataDTO> formulaMetaList = equipment.getFormulaList();
	    Map<String, String> formulaMap = new LinkedHashMap<>();
	    for (FormulaMetaDataDTO formulaMetaDataDTO : formulaMetaList) {
		formulaMap.put(formulaMetaDataDTO.getName().trim(), formulaMetaDataDTO.getFormulaId());
		FormulaDTO formula = new FormulaDTO();
		formula.setFormulaName(formulaMetaDataDTO.getName().trim());
		formula.setFormulaId(formulaMetaDataDTO.getFormulaId());
		formula.setLoads(0);
		formula.setWashedWeight((long) 0);
		formulaReportList.add(formula);
	    }
	    for (int i = 0; i < unitBuckets.size(); i++) {
		EquipmentReportDTO unit = new EquipmentReportDTO();
		JsonObject machine = unitBuckets.get(i).getAsJsonObject();
		Integer machineSeq = machine.get(Constants.REPORTS.KEY).getAsInt();
		unit.setId(machineSeq);
		JsonObject formulaAggregation = (JsonObject) machine.get(Constants.REPORTS.FORMULA_AGGREGATION);
		JsonArray formulaJArray = formulaAggregation.getAsJsonArray(Constants.REPORTS.BUCKETS);
		List<FormulaDTO> formulaList = null;
		int totalLoads = 0;
		long totalWeight = 0;
		if (formulaJArray != null && formulaJArray.size() > 0) {
		    formulaList = new LinkedList<>();
		    for (int j = 0; j < formulaJArray.size(); j++) {
			JsonObject formulaJson = formulaJArray.get(j).getAsJsonObject();
			JsonObject canal = null;
			String formulaName = formulaJson.get(Constants.REPORTS.KEY).getAsString();
			if (!StringUtils.isEmpty(formulaName)) {
			    formulaName = formulaName.trim();
			    FormulaDTO formula = new FormulaDTO();
			    formula.setFormulaName(formulaName.toUpperCase());
			    if (StringUtils.isEmpty(formulaMap.get(formulaName))) {
				formulaMap.put(formulaName, formulaName);
				FormulaDTO tempFormula = new FormulaDTO();
				tempFormula.setFormulaId(formulaName);
				tempFormula.setFormulaName(formulaName);
				tempFormula.setLoads(0);
				tempFormula.setWashedWeight((long) 0);
				formulaReportList.add(tempFormula);
			    }
			    formula.setFormulaId(formulaMap.get(formulaName));
			    long weight = 0;
			    int load = 0;
			    try {
				/**
				 * {weight} should be initialized based upon {EquipmentType}, because a new
				 * {canal_aggregator} has been introduced for TUNNEL. Earlier, the {SUM_REAL}
				 * was in the same tree. Now, then, if it is {WASHER_EXTRACTOR}, then get it
				 * from the {formulaJson}
				 */
				if (equipment.getEquipmentType()
					.equalsIgnoreCase(Constants.EquipmentType.WASHER_EXTRACTOR)) {
				    weight = ((JsonObject) formulaJson.get(Constants.REPORTS.SUM_REAL))
					    .get(Constants.REPORTS.VALUE).getAsLong();
				} else {
				    canal = ((JsonArray) ((JsonObject) formulaJson
					    .get(Constants.REPORTS.CANAL_AGGREGATION)).get(Constants.REPORTS.BUCKETS))
						    .get(0).getAsJsonObject();
				    // If it is {TUNNEL}, then get it from
				    // the
				    // {canal}.
				    weight = ((JsonObject) canal.get(Constants.REPORTS.SUM_REAL))
					    .get(Constants.REPORTS.VALUE).getAsLong();
				}
				// weight =
				// CommonUtils.convertKgToLbs(weight);
				weight = (long) Math.round(((double) weight / contributedIndicesSize));
				formula.setWashedWeight(weight);
				totalWeight += weight;
				if (equipment.getEquipmentType()
					.equalsIgnoreCase(Constants.EquipmentType.WASHER_EXTRACTOR)) {
				    load = ((JsonArray) ((JsonObject) formulaJson
					    .get(Constants.REPORTS.CYCLE_AGGREGATION)).get(Constants.REPORTS.BUCKETS))
						    .size();

				} else {
				    load = ((JsonArray) ((JsonObject) canal.get(Constants.REPORTS.PUMP_AGGREGATION))
					    .get(Constants.REPORTS.BUCKETS)).get(0).getAsJsonObject()
						    .get(Constants.REPORTS.DOC_COUNT).getAsInt();
				}
			    } catch (Exception e) {
				LOG.error("Error Fetching load count for FOrmula : " + formulaName + " Error: "
					+ e.getMessage());
				LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
			    }

			    load = (int) Math.round(((double) load / contributedIndicesSize));

			    for (FormulaDTO rootFormula : formulaReportList) {
				if (!StringUtils.isEmpty(rootFormula.getFormulaName())
					&& rootFormula.getFormulaName().equalsIgnoreCase(formulaName)) {
				    rootFormula.setLoads(getLoadsWashed(rootFormula.getLoads() + load));
				    rootFormula
					    .setWashedWeight(getWeightWashed(rootFormula.getWashedWeight() + weight));
				}

			    }
			    formula.setLoads(load);
			    totalLoads += load;
			    if (!StringUtils.isEmpty(formulaName)) {
				formulaList.add(formula);
			    }
			}
		    }
		}

		int equipmentSeq;
		if (equipment.getEquipmentType().equalsIgnoreCase(Constants.EquipmentType.WASHER_EXTRACTOR)) {
		    List<WasherMetaDataDTO> washerList = equipment.getWasherList();
		    for (WasherMetaDataDTO washer : washerList) {
			equipmentSeq = 0;
			try {
			    equipmentSeq = Integer.parseInt(washer.getLm2Seq());
			} catch (Exception e) {
			    LOG.error("Invalid lm2 sequence : " + e.getMessage());
			}
			if (equipmentSeq == unit.getId()) {
			    unit.setName(washer.getName().toUpperCase());
			    unit.setCapacity(washer.getLoad());
			    unit.setLm2Seq(washer.getLm2Seq());
			    break;
			}
		    }
		} else {
		    List<TunnelDTO> tunnelList = equipment.getTunnelList();
		    for (TunnelDTO tunnel : tunnelList) {
			equipmentSeq = 0;
			try {
			    equipmentSeq = Integer.parseInt(tunnel.getLm2Seq());
			} catch (Exception e) {
			    LOG.error("Invalid lm2 sequence : " + e.getMessage());
			}
			if (equipmentSeq == unit.getId()) {
			    unit.setName(tunnel.getName());
			    unit.setCapacity(tunnel.getLoad());
			    unit.setLm2Seq(tunnel.getLm2Seq());
			    break;
			}
		    }
		}

		totalProductionWeight += totalWeight;
		totalProductionLoads += totalLoads;
		unit.setTotalProduction(totalWeight);
		unit.setTotalLoads(totalLoads);
		formulaList.sort(Comparator.comparing(FormulaDTO::getFormulaName));
		unit.setFormulaList(formulaList);
		unit.setName(unit.getLm2Seq() + "." + unit.getName());
		equipmentList.add(unit);
	    }
	}

	populateEquipmentDTO(equipmentList, totalProductionLoads, totalProductionWeight);

	WasherProductionDTO response;

	response = populateWasherProductionDTO(requestDTO, siteDTO, maxDateForReport, equipmentList,
		totalProductionLoads, totalProductionWeight, formulaReportList, avgCalculatedForMonths, siteTimeZone);
	return response;

    }

    public DailyReportResponseDTO washerDailyReportUtility(DailyReportRequestDTO requestDTO, EquipmentDTO equipment,
	    SiteDTO siteDTO) throws Exception {
	DailyReportUtils dailyReportUtils = new DailyReportUtils();
	String shiftName = null;
	LOG.debug("Inside daily report utility file");
	String siteTimeZone = siteDTO.getTimeZone();
	ConfigReader config = new ConfigReader();
	List<String> indexList = null;

	DailyReportResponseDTO response = new DailyReportResponseDTO();

	long currentTime = ReportUtils.convertStringToDate(ReportUtils.getCurrentDateTime(siteDTO.getTimeZone()))
		.getTime();

	String shiftStartTime = config.getAppConfig(Constants.DEFAULT_SHIFT_START_TIME);
	String shiftEndTime = config.getAppConfig(Constants.DEFAULT_SHIFT_END_TIME);
	String startShift = null;
	String endShift = null;
	// creating default shift, with all default values from app.properties
	LOG.debug("creating default shift, with all default values from app.properties");
	List<ShiftDTO> finalShiftsForProcessing = new LinkedList<>();

	String query = ReportUtils.getQuery(Constants.REPORTS.REAL_TIME_REPORT);

	ShiftDTO shift = new ShiftDTO();
	List<ShiftDTO> userConfiguredShifts = siteBl.getShiftDetailsForSite(siteDTO).getShiftList();
	if (!requestDTO.isHistoricalReport()) {
	    // In case of real time report, find the current time falls in which
	    // shift and for that shift create data

	    shift = dailyReportUtils.getShiftForRealTime(userConfiguredShifts, siteDTO);
	    shiftStartTime = shift.getStartTime();
	    shiftEndTime = shift.getEndTime();
	    finalShiftsForProcessing.add(shift);
	    shiftName = shift.getShiftName();
	    startShift = CommonUtils.convertZonedToUTC(
		    DailyReportUtils.formDate(ReportUtils.getCurrentDate(siteTimeZone), shiftStartTime), siteTimeZone);
	    endShift = CommonUtils.convertZonedToUTC(
		    DailyReportUtils.formDate(ReportUtils.getCurrentDate(siteTimeZone), shiftEndTime), siteTimeZone);
	    List<String> dateList = new ArrayList<>(Arrays.asList(CommonUtils.getDateFromDateObject(startShift),
		    CommonUtils.getDateFromDateObject(endShift)));
	    indexList = ReportUtils.getExistingDailyIndices(dateList, siteDTO);
	} else {
	    // In case of historical report use the shifts sent from UI.
	    // date = ReportUtils.getDate(requestDTO.getDate());
	    List<ShiftDTO> selectedShift = requestDTO.getSelectedShifts();
	    finalShiftsForProcessing = dailyReportUtils.getShiftsForHistoricalReport(selectedShift,
		    userConfiguredShifts);
	    shiftName = dailyReportUtils.getShiftName(selectedShift);
	    // form shift start and end w.r.t time zone, post that convert to UTC for
	    // querying to ES.
	    startShift = CommonUtils.convertZonedToUTC(
		    DailyReportUtils.formDate(CommonUtils.getDateObject(requestDTO.getDate()), shiftStartTime),
		    siteTimeZone);
	    endShift = CommonUtils.convertZonedToUTC(
		    DailyReportUtils.formDate(CommonUtils.getDateObject(requestDTO.getDate()), shiftEndTime),
		    siteTimeZone);
	    indexList = ReportUtils.getExistingIndices(CommonUtils.getDateFromDateObject(startShift),
		    CommonUtils.getDateFromDateObject(endShift), siteDTO);
	}

	query = query.replace(Constants.START_TIME, startShift);
	query = query.replace(Constants.END_TIME, endShift);
	String deviceId = equipment.getDeviceId();
	if (deviceId == null) {
	    throw new SystemException(ErrorCodes.DEVICE_DOES_NOT_EXIST, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
	query = query.replace(Constants.DEVICE_ID_VAL, deviceId);

	LOG.info("Query::" + query);

	// fetching machine data from ES
	JsonObject responseObject = dailyReportUtils.executeDailyReportQuery(query, indexList);

//	JsonObject responseObject = SampleData.getSampleData();

	LOG.debug("responseObject::" + responseObject);

	// assigning washer details to each shift, helper shift data for
	// creating final historical data set

	if (requestDTO.isHistoricalReport() && finalShiftsForProcessing != null) {
	    finalShiftsForProcessing.forEach(
		    shiftDetails -> shiftDetails.setWasherHashMap(dailyReportUtils.createWasherMap(equipment)));
	}

	// creating master washer
	// assigning washer details to each shift
	// master shift
	shift.setWasherHashMap(dailyReportUtils.createWasherMap(equipment));

	ShiftDTO masterShift = shift;

	try {
	    handleEsError(responseObject);
	} catch (Exception e) {
	    LOG.info("Index not found" + e.getStackTrace());
	    // if no index found return the blank machines

	    ShiftDTO shiftDetails = shift;
	    Map<Integer, DailyReportWasherDTO> washerMapDetails = shiftDetails.getWasherHashMap();
	    if (!requestDTO.isHistoricalReport())
		dailyReportUtils.updateIdleTime(washerMapDetails, siteDTO, startShift, currentTime);
	    response.setShift(shift);
	    return response;
	}

	JsonObject firstHitsObject = (JsonObject) responseObject.get(Constants.REPORTS.HITS);

	Map<Integer, RealTimeAlarmDTO> systemAlarmMap = new LinkedHashMap<>();
	// fetch shiftDetails

	if (firstHitsObject != null) {
	    JsonArray jsonArray = ReportUtils.fieldsQuery(firstHitsObject);
	    if (jsonArray == null || jsonArray.size() <= 0) {
		ShiftDTO shiftDetails = shift;
		Map<Integer, DailyReportWasherDTO> washerMapDetails = shiftDetails.getWasherHashMap();
		if (!requestDTO.isHistoricalReport())
		    dailyReportUtils.updateIdleTime(washerMapDetails, siteDTO, startShift, currentTime);
		response.setShift(shift);
		return response;
	    }

	    // parsing through each json event and creating response
	    for (int i = 0; i < jsonArray.size(); i++) {
		LOG.debug("Processing event:: " + i);

		JsonObject event = (JsonObject) jsonArray.get(i);

		if (requestDTO.isHistoricalReport()) {
		    shift = dailyReportUtils
			    .checkEventShift(finalShiftsForProcessing,
				    CommonUtils.convertStringUTCToZonedTime(
					    CommonUtils.extractFechaDateInProcessableFormat(
						    event.get(Constants.REPORTS.DATE_TIME).getAsString()),
					    siteTimeZone));
		    if (shift != null) {
			startShift = CommonUtils.getShiftDateTimeUTC(requestDTO.getDate(), shift.getStartTime(),
				siteTimeZone);
			endShift = CommonUtils.getShiftDateTimeUTC(requestDTO.getDate(), shift.getEndTime(),
				siteTimeZone);
		    } else {
			continue;
		    }
		}

		// if real time report then calculate alarm details. For
		// historical report alarms are not required.
		if (!requestDTO.isHistoricalReport()) {
		    systemAlarmMap = dailyReportUtils.getSystemAlarm(systemAlarmMap, event, siteDTO, response,
			    equipment.getEquipmentType());
		}

		Map<Integer, DailyReportWasherDTO> washerMapDetails = shift.getWasherHashMap();
		Map<Integer, DailyReportWasherDTO> masterWasherMapDetails = masterShift.getWasherHashMap();
		int machineId = 0;
		if (event.get(Constants.REPORTS.MACHINE_WASHER) != null)
		    machineId = event.get(Constants.REPORTS.MACHINE_WASHER).getAsInt();
		else {
		    LOG.error("Data not proper for the washer event : " + event);
		}

		if (washerMapDetails.containsKey(machineId)) {
		    String eventType = event.get(Constants.REPORTS.EVENT_TYPE).getAsString();
		    String startEvent = config.getAppConfig(Constants.REPORTS.EVENT_TYPE_START_OF_CYCLE);
		    Date eventDate = ReportUtils.convertStringToDate(CommonUtils
			    .extractFechaDateInProcessableFormat(event.get(Constants.REPORTS.DATE_TIME).getAsString()));
		    String phaseString = event.get(Constants.REPORTS.PHASE).getAsString();
		    String endEvent = config.getAppConfig(Constants.REPORTS.EVENT_TYPE_END_OF_CYCLE);
		    String zeroPhase = config.getAppConfig(Constants.REPORTS.ZERO_PHASE);
		    DailyReportWasherDTO washerDetails = washerMapDetails.get(machineId);
		    DailyReportWasherDTO masterWasherDetails = masterWasherMapDetails.get(machineId);
		    Map<Integer, CycleDTO> cycleMapDetails = washerDetails.getCycleHashMap();
		    Map<Integer, CycleDTO> masterCycleMapDetails = new LinkedHashMap<>();
		    masterCycleMapDetails.putAll(masterWasherDetails.getCycleHashMap());
		    int cycleVal = event.get(Constants.REPORTS.PROCESS).getAsInt();
		    System.out.println("cycleval::" + cycleVal);
		    if (cycleMapDetails == null || cycleMapDetails.isEmpty()) {
			cycleMapDetails = new HashMap<>();
		    }

		    // If first cycle in the shift is spilled, then get all
		    // information of cycle from start.

		    if (!cycleMapDetails.containsKey(cycleVal)) {
			CycleDTO cycle = dailyReportUtils.createCycle(event);
			cycleMapDetails.put(cycleVal, cycle);
			masterCycleMapDetails.put(cycleVal, cycle);
			washerDetails.setLbs(cycle.getLbs());
			masterWasherDetails.setLbs(cycle.getLbs());
			Integer firstKey = cycleMapDetails.keySet().stream().findFirst().get();
			if ((firstKey == null || firstKey == cycleVal) && !eventType.equals(startEvent)) {
			    String rtdate = null;
			    if (requestDTO.isHistoricalReport()) {
				rtdate = CommonUtils.getDateObject(requestDTO.getDate());
			    } else {
				rtdate = ReportUtils.getCurrentDate(siteTimeZone);
			    }
			    cycle = dailyReportUtils.incompleteCycleData(siteDTO, requestDTO, cycleVal,
				    equipment.getEquipmentId(), event, cycleMapDetails,
				    CommonUtils.convertZonedToUTC(
					    DailyReportUtils.formDate(rtdate, shift.getStartTime()), siteTimeZone),
				    cycle, siteTimeZone);
			    cycleMapDetails.put(cycleVal, cycle);
			    masterCycleMapDetails.put(cycleVal, cycle);
			}

		    }

		    CycleDTO cycle = cycleMapDetails.get(cycleVal);

		    // creating normal shift data, normal shift is further used
		    // for calculating avg. turn time, idle time, & effi. for
		    // master shift.
		    if (cycle != null && cycle.getCycleId() == cycleVal) {
			if (eventType.equals(startEvent)) {
			    cycle.setStartCycleTime(eventDate);
			}
			if (eventType.equals(endEvent) && phaseString.equals(zeroPhase)) {
			    cycle.setCycleCompleted(true);
			    cycle.setEndCycleTime(eventDate);
			}
		    }

		    washerDetails.setCycleHashMap(cycleMapDetails);
		    washerMapDetails.put(machineId, washerDetails);
		    shift.setWasherHashMap(washerMapDetails);

		    PhaseDTO phase = new PhaseDTO();

		    // creating master shift data
		    if (cycle != null) {
			DailyReportFormulaDTO formula = cycle.getFormula();
			Map<Integer, PhaseDTO> phaseMap = formula.getPhaseMap();
			int previousActivePhase = cycle.getCyclePreviousActivePhase();

			if (cycle.getCyclePreviousActivePhase() != null)
			    previousActivePhase = cycle.getCyclePreviousActivePhase();
			if (cycle.getCycleId() == cycleVal) {
			    if (eventType.equals(startEvent)) {
				cycle.setStartCycleTime(eventDate);
			    }
			    if (eventType.equals(endEvent) && phaseString.equals(zeroPhase)) {
				cycle.setCycleCompleted(true);
				cycle.setEndCycleTime(eventDate);
				phase = phaseMap.get(previousActivePhase);

				if (!phase.getPhaseStatus().equals(ReportUtils.PHASE_STATUS.MISSED_PHASE)) {
				    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.SUCCESSFUL);
				}
				phase.setActivePhase(false);

				// setting cycle active time, when start and end of
				// cycle time is present.

			    }
			    if (!eventType.equals(startEvent) && !eventType.equals(endEvent)) {
				cycle.setEndCycleTime(eventDate);
			    }
			    // setting cycle active time, when end of cycle is not
			    // present
			}
			String missedPhaseString = config.getAppConfig(Constants.REPORTS.MISSED_PHASE);
			if (previousActivePhase != event.get(Constants.REPORTS.PHASE).getAsInt()
				&& !eventType.equals(missedPhaseString) && !phaseString.equals(zeroPhase)) {

			    if (previousActivePhase != 0) {
				phase = phaseMap.get(previousActivePhase);
				phase.setPhaseStatus(ReportUtils.PHASE_STATUS.SUCCESSFUL);
				phase.setActivePhase(false);
			    }
			    phase = phaseMap.get(event.get(Constants.REPORTS.PHASE).getAsInt());
			    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.IN_PROGRESS);
			    phase.setActivePhase(true);
			}
			if (previousActivePhase == event.get(Constants.REPORTS.PHASE).getAsInt()
				&& !eventType.equals(missedPhaseString)
				&& !event.get(Constants.REPORTS.PHASE).getAsString().equals(zeroPhase)) {
			    phase = phaseMap.get(previousActivePhase);
			    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.IN_PROGRESS);
			    phase.setActivePhase(true);
			}
			if (eventType.equals(missedPhaseString)
				&& !event.get(Constants.REPORTS.PHASE).getAsString().equals(zeroPhase)) {
			    phase = phaseMap.get(event.get(Constants.REPORTS.PHASE).getAsInt());
			    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.MISSED_PHASE);
			    phase.setActivePhase(false);
			}
			if (eventType.equals(endEvent) && !phaseString.equals(zeroPhase) && previousActivePhase != 0) {
			    phase = phaseMap.get(previousActivePhase);
			    phase.setPhaseStatus(ReportUtils.PHASE_STATUS.SUCCESSFUL);
			    phase.setActivePhase(false);
			}
			if (ReportUtils.setPrevPhase(event)) {
			    cycle.setCyclePreviousActivePhase(event.get(Constants.REPORTS.PHASE).getAsInt());
			}
			phase = phaseMap.get(event.get(Constants.REPORTS.PHASE).getAsInt());
			if (phase != null && phase.isValidPhase() != false)
			    dailyReportUtils.createEvent(event, phase);
		    }

		    masterWasherDetails.setCycleHashMap(masterCycleMapDetails);
		    dailyReportUtils.createFormulaMap(masterWasherDetails, event);
		    masterWasherMapDetails.put(machineId, masterWasherDetails);
		    masterShift.setWasherHashMap(masterWasherMapDetails);

		}
	    }
	}

	// Traversing elements of temporary shift list
	ListIterator<ShiftDTO> shiftIterator1 = finalShiftsForProcessing.listIterator();
	while (shiftIterator1.hasNext()) {
	    String rtdate = null;
	    ShiftDTO shiftDetails = shiftIterator1.next();
	    if (requestDTO.isHistoricalReport()) {
		rtdate = CommonUtils.getDateObject(requestDTO.getDate());
	    } else {
		rtdate = ReportUtils.getCurrentDate(siteTimeZone);
	    }
	    startShift = CommonUtils.convertZonedToUTC(DailyReportUtils.formDate(rtdate, shiftDetails.getStartTime()),
		    siteTimeZone);
	    endShift = CommonUtils.convertZonedToUTC(DailyReportUtils.formDate(rtdate, shiftDetails.getEndTime()),
		    siteTimeZone);
	    Map<Integer, DailyReportWasherDTO> washerMapDetails = shiftDetails.getWasherHashMap();
	    dailyReportUtils.updateIdleTime(washerMapDetails, siteDTO, startShift, currentTime);
	    dailyReportUtils.setWasherTurnTime(washerMapDetails, startShift, endShift, siteDTO, currentTime);
	    dailyReportUtils.setMachineEfficiency(washerMapDetails, startShift, endShift, currentTime);
	}

	Map<Integer, DailyReportWasherDTO> washerMapDetails = masterShift.getWasherHashMap();
	if (washerMapDetails != null && !washerMapDetails.isEmpty()) {
	    // Add System alarms to AlarmMap in response for real time report.
	    if (!requestDTO.isHistoricalReport()) {
		Map<Integer, RealTimeAlarmDTO> alarmMap = new HashMap<>();
		washerMapDetails.forEach((key, washer) -> {
		    CycleDTO cycle = washer.getCycleHashMap().get(washer.getLastCycleKey());
		    washer.setCurrentCycle(cycle);
		    response.setAlarmsMap(dailyReportUtils.createAlarmMap(cycle, alarmMap));
		    washer.setCycleHashMap(null);
		});
		response.setAlarmsMap(dailyReportUtils.getAlarmList(systemAlarmMap, response.getAlarmsMap()));
	    } else {
		dailyReportUtils.totalLbs(washerMapDetails);
		dailyReportUtils.formulaCostCalculation(washerMapDetails);
		dailyReportUtils.setCycleTurnRunTime(washerMapDetails,
			dailyReportUtils.getShiftWithLeastStartTime(finalShiftsForProcessing));
	    }
	}

	dailyReportUtils.setEfficiencyAndTurnTime(finalShiftsForProcessing, masterShift);
	masterShift.setShiftName(shiftName);
	response.setShift(masterShift);
	if (requestDTO.isHistoricalReport()) {
	    DailyReportUtils.convertWasherDayWiseTimeEventTimetoSiteZone(masterShift, siteTimeZone);
	} else {
	    DailyReportUtils.convertWasherRealTimeEventTimetoSiteZone(masterShift, siteTimeZone);
	}
	return response;
    }

    public DailyReportResponseDTO tunnelDailyReportUtility(DailyReportRequestDTO requestDTO, EquipmentDTO equipment,
	    SiteDTO siteDTO) throws ParseException {
	boolean isHistoricalReport = requestDTO.isHistoricalReport();
	DailyReportUtils dailyReportUtils = new DailyReportUtils();
	List<ShiftDTO> finalShiftsForProcessing = new LinkedList<>();
	ConfigReader config = new ConfigReader();
	ShiftDTO shift = new ShiftDTO();
	ShiftDTO masterShiftDTO = new ShiftDTO();
	DailyReportTunnelDTO tunnelInfo;
	DailyReportResponseDTO response = new DailyReportResponseDTO();
	int lastTransferNo = 0;
	int transferNo = 0;
	String shiftName = null;
	TransferDTO currentTransfer = null;
	String siteTimeZone = siteDTO.getTimeZone();
	List<String> indexList = null;
	try {
	    LOG.debug("Inside daily report utility file");
	    long currentTime = ReportUtils.convertStringToDate(ReportUtils.getCurrentDateTime(siteDTO.getTimeZone()))
		    .getTime();
	    String shiftStartTime = config.getAppConfig(Constants.DEFAULT_SHIFT_START_TIME);
	    String shiftEndTime = config.getAppConfig(Constants.DEFAULT_SHIFT_END_TIME);
	    String date;
	    String startShift = null;
	    String endShift = null;
	    // creating default shift, with all default values from app.properties
	    LOG.debug("creating default shift, with all default values from app.properties");

	    String query = ReportUtils.getQuery(Constants.REPORTS.REAL_TIME_REPORT);

	    List<ShiftDTO> userConfiguredShifts = siteBl.getShiftDetailsForSite(siteDTO).getShiftList();
	    if (!isHistoricalReport) {
		// In case of real time report, find the current time falls in which
		// shift and for that shift create data
		shift = dailyReportUtils.getShiftForRealTime(userConfiguredShifts, siteDTO);
		shiftEndTime = shift.getEndTime();
		finalShiftsForProcessing.add(shift);
		shiftName = shift.getShiftName();
		// form shift start and end w.r.t time zone, post that convert to UTC for
		// querying to ES.
		startShift = CommonUtils.convertZonedToUTC(
			DailyReportUtils.formDate(ReportUtils.getCurrentDate(siteTimeZone), shiftStartTime),
			siteTimeZone);
		endShift = CommonUtils.convertZonedToUTC(
			DailyReportUtils.formDate(ReportUtils.getCurrentDate(siteTimeZone), shiftEndTime),
			siteTimeZone);
		List<String> dateList = new ArrayList<>(Arrays.asList(CommonUtils.getDateFromDateObject(startShift),
			CommonUtils.getDateFromDateObject(endShift)));
		indexList = ReportUtils.getExistingDailyIndices(dateList, siteDTO);
	    } else {
		// In case of historical report use the shifts sent from UI.
		// date = ReportUtils.getDate(requestDTO.getDate());
		List<ShiftDTO> selectedShift = requestDTO.getSelectedShifts();
		finalShiftsForProcessing = dailyReportUtils.getShiftsForHistoricalReport(selectedShift,
			userConfiguredShifts);
		shiftName = dailyReportUtils.getShiftName(selectedShift);
		// form shift start and end w.r.t time zone, post that convert to UTC for
		// querying to ES.
		startShift = CommonUtils.convertZonedToUTC(
			DailyReportUtils.formDate(CommonUtils.getDateObject(requestDTO.getDate()), shiftStartTime),
			siteTimeZone);
		endShift = CommonUtils.convertZonedToUTC(
			DailyReportUtils.formDate(CommonUtils.getDateObject(requestDTO.getDate()), shiftEndTime),
			siteTimeZone);
		indexList = ReportUtils.getExistingIndices(CommonUtils.getDateFromDateObject(startShift),
			CommonUtils.getDateFromDateObject(endShift), siteDTO);
	    }

	    query = query.replace(Constants.START_TIME, startShift);
	    query = query.replace(Constants.END_TIME, endShift);
	    String deviceId = equipment.getDeviceId();
	    if (deviceId == null) {
		throw new SystemException(ErrorCodes.DEVICE_DOES_NOT_EXIST, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    query = query.replace(Constants.DEVICE_ID_VAL, deviceId);

	    LOG.debug("Query:::::::::::" + query);

	    // fetching machine data from ES
	    JsonObject responseObject = dailyReportUtils.executeDailyReportQuery(query, indexList);

//	    JsonObject responseObject = SampleData.getSampleData();

//	    LOG.debug("responseObject::" + responseObject);

	    // creating master washer
	    // assigning washer details to each shift
	    // master shift

	    tunnelInfo = dailyReportUtils.getTunnelInfo(equipment);
	    if (isHistoricalReport)
		tunnelInfo.setModuleHashMap(null);
	    shift.setTunnelDetails(tunnelInfo);
	    masterShiftDTO.setTunnelDetails(tunnelInfo);

	    Map<Integer, TransferDTO> transferMap = new LinkedHashMap<>();
	    masterShiftDTO.setShiftName(shiftName);

	    try {
		handleEsError(responseObject);
	    } catch (Exception e) {
		LOG.info("Index not found" + e.getStackTrace());
		response.setShift(masterShiftDTO);
		return response;
	    }

	    JsonObject firstHitsObject = (JsonObject) responseObject.get(Constants.REPORTS.HITS);

	    Map<Integer, RealTimeAlarmDTO> systemAlarmMap = new LinkedHashMap<>();

	    // fetch shiftDetails

	    if (firstHitsObject != null) {
		JsonArray jsonArray = ReportUtils.fieldsQuery(firstHitsObject);
		if (jsonArray == null || jsonArray.size() <= 0) {
		    response.setShift(masterShiftDTO);
		    return response;
		}

		// assigning washer details to each shift, helper shift data for
		// creating final historical data set

		Map<Integer, BatchDTO> masterBatchMap = new LinkedHashMap<>();

		masterShiftDTO.setBatchMap(masterBatchMap);
		int moduleId = 0;

		Map<Integer, TransferDTO> tempTransferMap = new LinkedHashMap<>();
		// parsing through each json event and creating response
		for (int i = 0; i < jsonArray.size(); i++) {
		    // maintain a map of batch to store all the events occurred w.r.t batch

		    JsonObject event = (JsonObject) jsonArray.get(i);

		    LOG.debug("Processing event:: " + i + event.get("id").getAsInt());

		    // if real time report then calculate alarm details. For
		    // historical report alarms are not required.
		    if (!requestDTO.isHistoricalReport()) {
			systemAlarmMap = dailyReportUtils.getSystemAlarm(systemAlarmMap, event, siteDTO, response,
				equipment.getEquipmentType());
		    } else {
			shift = dailyReportUtils
				.checkEventShift(finalShiftsForProcessing,
					CommonUtils.convertStringUTCToZonedTime(
						CommonUtils.extractFechaDateInProcessableFormat(
							event.get(Constants.REPORTS.DATE_TIME).getAsString()),
						siteTimeZone));
		    }

		    int eventType = event.get(Constants.REPORTS.EVENT_TYPE).getAsInt();

		    if (shift != null && eventType != 200 && eventType != 100) {
			int batchId = event.get(Constants.REPORTS.BATCH_ID).getAsInt();
			transferNo = event.get(Constants.REPORTS.TRANSFER_NUMBER).getAsInt();

			int startEvent = Integer
				.parseInt(config.getAppConfig(Constants.REPORTS.EVENT_TYPE_START_OF_CYCLE));
			String eventTime = CommonUtils.extractFechaDateInProcessableFormat(
				event.get(Constants.REPORTS.DATE_TIME).getAsString());
			int formulaId = event.get(Constants.REPORTS.FORMULA).getAsInt();
			String formulaName = event.get(Constants.REPORTS.FORMULA_NAME).getAsString();
			int productId = event.get(Constants.REPORTS.PRODUCT_ID).getAsInt();
			int maxModule = tunnelInfo.getModuleCount();
			moduleId = event.get(Constants.REPORTS.MODULE).getAsInt();
			masterBatchMap = masterShiftDTO.getBatchMap();
			BatchDTO masterBatchDTO = null;
			TransferDTO transferDTO = new TransferDTO();
			masterBatchDTO = dailyReportUtils.getBatchDTO(masterBatchMap, transferMap, event, siteDTO,
				requestDTO, startShift, maxModule, equipment, tempTransferMap, endShift, siteTimeZone);
			// update or create transfer details w.r.t condition's
			transferDTO = dailyReportUtils.getTransferDetails(transferMap.containsKey(transferNo), event,
				transferMap, equipment);
			if (eventType == startEvent) {
			    if (transferDTO.getStartTime() == null) {
				transferDTO.setStartTime(ReportUtils.convertStringToDate(eventTime));
			    }
			    tempTransferMap.put(transferNo, transferDTO);
			    transferMap.put(transferNo, transferDTO);
			}

			// create snapshot which can be used by next transfer in case if event is not
			// dispensing any data for module.
			Map<Integer, ModuleDTO> moduleMapSnapshot = transferDTO.getModuleMap();
			if (moduleMapSnapshot != null && !moduleMapSnapshot.isEmpty()
				&& moduleMapSnapshot.containsKey(moduleId)
				&& (eventType != Constants.REPORTS.EVENT_TYPE_11)) {
			    ModuleDTO moduleDTO = moduleMapSnapshot.get(moduleId);
			    moduleDTO.setBatch(dailyReportUtils.createBatch(event, formulaId, formulaName));
			    moduleMapSnapshot.put(moduleId, moduleDTO);
			    transferMap.put(transferNo, transferDTO);
			}

			// updating the transfer snapshots
			lastTransferNo = dailyReportUtils.updateTransferModuleDetails(transferNo, lastTransferNo,
				transferMap, isHistoricalReport, transferDTO, eventTime);
			masterBatchMap.put(batchId, masterBatchDTO);

			currentTransfer = dailyReportUtils.getLastTransfer(transferMap);

			if (!isHistoricalReport && currentTransfer != null
				&& (eventType != Constants.REPORTS.EVENT_TYPE_11)) {
			    Map<Integer, ModuleDTO> moduleDetails = currentTransfer.getModuleMap();
			    ModuleDTO moduleDTO = moduleDetails.get(moduleId);
			    if (moduleDTO != null) {
				BatchDTO batchDTO = dailyReportUtils.createBatch(event, formulaId, formulaName);
				batchDTO.setEventList(null);
				Map<Integer, Boolean> productMap = moduleDTO.getProductMap();
				if (productMap != null) {
				    productMap.forEach((productKey, productValue) -> {
					productValue = (productKey == productId) ? true : false;
					productMap.put(productKey, productValue);
				    });
				}
				moduleDTO.setBatch(batchDTO);
				moduleDTO.setProductMap(productMap);
				tunnelInfo.setModuleHashMap(moduleDetails);
			    }
			}
		    }
		}

		masterBatchMap.putAll(dailyReportUtils.getSortedBatchMap(masterBatchMap));

		if (isHistoricalReport) {
		    date = ReportUtils.getDate(requestDTO.getDate());
		    DailyReportTunnelDTO tempTunnelDTO = dailyReportUtils.getTunnelTurnRunTime(masterBatchMap);
		    if (tempTunnelDTO.getBatchMap() != null) {
			masterBatchMap.putAll(tempTunnelDTO.getBatchMap());
		    }
		    tunnelInfo.setBatchMap(masterBatchMap);
		    // get formula details w.r.t the batch of data inserted using final batch map.
		    tunnelInfo.setFormulaMap(dailyReportUtils.getFormulaProcessedInfo(masterBatchMap));
		    // get turn time & run time details
		} else {
		    date = ReportUtils.getCurrentDate(siteTimeZone);
		    // get alarm details for the last batch
		    if (currentTransfer != null) {
			response.setAlarmsMap(dailyReportUtils.getAlarmList(systemAlarmMap,
				dailyReportUtils.getAlarmDetailsForBatchEvents(currentTransfer.getEventList())));
		    }
		}

		tunnelInfo.setEfficiency(dailyReportUtils.getTunnelEfficiency(finalShiftsForProcessing, currentTime,
			masterBatchMap, date, siteTimeZone));
		Map<Integer, BatchDTO> batchMap = dailyReportUtils.getBatchsWithEndTime(masterBatchMap,
			finalShiftsForProcessing, isHistoricalReport, siteTimeZone);
		tunnelInfo.setTotalCycleProcessed(batchMap.size());
		tunnelInfo.setTotalLbsProcessed(dailyReportUtils.getTotalLbsProcessed(batchMap));
		DailyReportTunnelDTO tempData = dailyReportUtils.getActiveTimeDetails(finalShiftsForProcessing,
			currentTime, dailyReportUtils.getTransfersEndTime(tempTransferMap), date, isHistoricalReport,
			siteTimeZone);
		long avgTransferTime = tempData.getAverageCycleTime();
		tunnelInfo.setAverageCycleTime(avgTransferTime);
		tunnelInfo.setCurrentCycleTime(tempData.getCurrentCycleTime());
		tunnelInfo.setEfficiency(
			dailyReportUtils.getTunnelEfficiency(avgTransferTime, siteDTO.getTunnelTurnMinute()));
		masterShiftDTO.setTunnelDetails(tunnelInfo);
		if (isHistoricalReport) {
		    DailyReportUtils.convertTunnelEventTimetoSiteZone(masterShiftDTO, siteTimeZone);
		} else {
		    DailyReportUtils.convertTunnelRealTimeEventTimetoSiteZone(masterShiftDTO, siteTimeZone);
		}
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}

	masterShiftDTO.setBatchMap(null);
	response.setShift(masterShiftDTO);
	return response;
    }
}
