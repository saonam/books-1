package com.hydro.api.base.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.math3.util.Precision;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Interval;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.hydro.api.base.dao.ESRestDAO;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.DailyReportProductDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.reports.DailyReportResponseDTO;
import com.hydro.api.dto.reports.FormulaDTO;
import com.hydro.api.dto.reports.MachineDTO;
import com.hydro.api.dto.reports.RealTimeAlarmDTO;
import com.hydro.api.dto.reports.WarningDTO;
import com.hydro.api.exception.SystemException;

/**
 * @author Shreyas
 *
 */
public class ReportUtils {
    private static final Logger LOG = LoggerFactory.getLogger(ReportUtils.class);

    public static String getQuery(String query) {
	InputStream is = null;
	try {
	    is = (ReportUtils.class.getClassLoader().getResourceAsStream(query));
	    query = IOUtils.toString(is, "UTF-8");
	} catch (IOException e) {
	    e.printStackTrace();
	    LOG.error("Error : " + e.getMessage());
	} finally {
	    try {
		if (is != null) {
		    is.close();
		}
	    } catch (Exception e1) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
	    }
	}
	return query;
    }

    public static List<String> prepareQueries(String[] queryFiles, String[][] replaceMap)
	    throws SystemException, Exception {
	String query = null;
	List<String> queries = new ArrayList<>();
	for (String queryFile : queryFiles) {
	    query = ReportUtils.getQuery(queryFile);
	    if (StringUtils.isEmpty(query)) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    for (String[] set : replaceMap) {
		query = query.replace(set[0], set[1]);
	    }
	    LOG.info("QueryTOExecute : " + query);
	    queries.add(query);
	}
	return queries;
    }

    public static String prepareQuery(String queryFile, String[][] replaceMap) throws SystemException, Exception {
	String query = ReportUtils.getQuery(queryFile);
	if (StringUtils.isEmpty(query)) {
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
	for (String[] set : replaceMap) {
	    query = query.replace(set[0], set[1]);
	}
	LOG.info("QueryTOExecute : " + query);
	return query;
    }

    public static String getIndexName(String site, int month, int year) throws Exception {
	ConfigReader config = ConfigReader.getObject();
	String index = config.getAppConfig(Constants.ES_INDEX) + site + "-" + month + "-" + year;
	return index;
    }

    public static JsonArray aggregationsQuery(JsonObject aggregationsObject) {
	Set<Entry<String, JsonElement>> aggregationsSet = aggregationsObject.entrySet();
	Map<String, String> columnToAliasMap = new LinkedHashMap<>();
	LOG.debug("Aggregation Set: " + aggregationsSet);
	Iterator<Entry<String, JsonElement>> itrAgg = aggregationsSet.iterator();
	JsonArray results = null;

	if (itrAgg.hasNext()) {
	    Entry<String, JsonElement> aggregationEntry = itrAgg.next();
	    String key = aggregationEntry.getKey();
	    JsonElement valueElement = aggregationEntry.getValue();
	    JsonObject valueObject = (JsonObject) valueElement.getAsJsonObject();
	    results = new JsonArray();
	    flattenAggregationResultsTree(key, valueObject, 0, results, new LinkedHashMap<String, JsonElement>(),
		    columnToAliasMap);
	} else {
	    // TODO: error handling
	}
	return results;
    }

    private static void flattenAggregationResultsTree(String nodeName, JsonObject node, int depth, JsonArray results,
	    LinkedHashMap<String, JsonElement> result, Map<String, String> columnToAliasMap) {

	if (node.has("buckets")) { // more work to do, recurse ...
	    JsonArray buckets = node.get("buckets").getAsJsonArray();
	    for (JsonElement bucket : buckets) {

		JsonObject bucketObject = bucket.getAsJsonObject();
		if (bucketObject.has("key")) {
		    /*
		     * Elastic Search returns implicit values as key , key_as_string for internal
		     * data types , false : 0, true : 1, epoch value for date etc. Hence checking if
		     * key_as_string is sent if so use it else use the "key"'s value
		     */
		    JsonElement valueAsString = bucketObject.get("key_as_string");
		    JsonElement value = valueAsString;
		    if (valueAsString == null) {
			value = bucketObject.get("key");
		    }

		    // We have to display this field in result
		    result.put(columnToAliasMap.get(nodeName), value);

		} else {
		    // TODO: error handling
		}

		Set<Entry<String, JsonElement>> bucketSet = bucketObject.entrySet();
		Iterator<Entry<String, JsonElement>> itrBucket = bucketSet.iterator();

		Map<String, JsonElement> m = new LinkedHashMap<String, JsonElement>();

		/*
		 * Differentiate the DSL response with value field, and without value field.
		 */
		if (buckets.toString().contains("value")) {
		    processingBucketWithValue(itrBucket, nodeName, depth, results, result, columnToAliasMap);
		} else {
		    processingBucketWithoutValue(itrBucket, nodeName, depth, results, result);
		}
	    }
	} else {
	    // corner case: aggregate without group by

	    result.put(nodeName, node.get("value"));

	    JsonObject resultFinal = createJsonObjectFromMap(result);
	    results.add(resultFinal);
	}
    }

    private static void processingBucketWithoutValue(Iterator<Entry<String, JsonElement>> itrBucket, String nodeName,
	    int depth, JsonArray results, LinkedHashMap<String, JsonElement> result) {
	while (itrBucket.hasNext()) {
	    Entry<String, JsonElement> childObject = itrBucket.next();
	    JsonElement childValue = childObject.getValue();
	    if (childObject.getKey().equalsIgnoreCase("key")) {

		result.put(nodeName, childValue);

		JsonObject resultFinal = createJsonObjectFromMap(result);
		results.add(resultFinal);
	    }
	}
    }

    /**
     * Processing the DSL response with value field in the bucket. DSL queries with
     * sub aggregations are processed here.
     * 
     * @param itrBucket
     * @param nodeName
     * @param depth
     * @param results
     * @param result
     */
    private static void processingBucketWithValue(Iterator<Entry<String, JsonElement>> itrBucket, String nodeName,
	    int depth, JsonArray results, LinkedHashMap<String, JsonElement> result,
	    Map<String, String> columnToAliasMap) {
	// Find the node that we need to send recursively to DFS, and
	// recurse.
	while (itrBucket.hasNext()) {
	    Entry<String, JsonElement> childObject = itrBucket.next();
	    JsonElement childValue = childObject.getValue();
	    if (childValue.isJsonObject() && childValue.getAsJsonObject().has("buckets")) {

		// Recursion to handle the next nested key
		flattenAggregationResultsTree(childObject.getKey(), childValue.getAsJsonObject(), depth + 1, results,
			result, columnToAliasMap);
	    } else if (childValue.isJsonObject() && childValue.getAsJsonObject().has("value")) {
		// We have found a "value" node, so consume it.
		String valueNodeName = childObject.getKey();

		result.put(valueNodeName, childValue.getAsJsonObject().get("value"));

		// Now consume all remaining adjacent "value" nodes (if
		// any) and add them to the same result entry.
		while (itrBucket.hasNext()) {
		    childObject = itrBucket.next();
		    childValue = childObject.getValue();
		    valueNodeName = childObject.getKey();

		    result.put(valueNodeName, childValue.getAsJsonObject().get("value"));

		}
		JsonObject resultFinal = createJsonObjectFromMap(result);
		results.add(resultFinal);
	    }
	}
    }

    private static JsonObject createJsonObjectFromMap(LinkedHashMap<String, JsonElement> result) {
	JsonObject jsonObject = new JsonObject();
	for (Map.Entry<String, JsonElement> entry : result.entrySet()) {
	    String key = entry.getKey();
	    JsonElement value = entry.getValue();
	    jsonObject.add(key, value);
	}
	return jsonObject;
    }

    public static JsonArray fieldsQuery(JsonObject firstHitsObject) {
	JsonArray secondHitsArray = (JsonArray) firstHitsObject.get(Constants.REPORTS.HITS);
	JsonArray jsonArray = new JsonArray();

	for (int i = 0, size = secondHitsArray.size(); i < size; i++) {
	    JsonObject document = (JsonObject) secondHitsArray.get(i);
//	    LOG.debug("Record: " + document);
	    JsonObject source = (JsonObject) document.get(Constants.REPORTS.SOURCE);
//	    LOG.debug("Source: " + source);
	    jsonArray.add(source);
	}
	return jsonArray;
    }

    public static Integer getEquivalentAlarmCode(int alarmCode) {
	switch (alarmCode) {
	case 102:
	    return 101;
	case 900:
	case 901:
	case 902:
	case 903:
	case 904:
	case 905:
	case 906:
	case 907:
	case 908:
	case 909:
	case 910:
	case 911:
	case 912:
	case 913:
	case 914:
	case 915:
	case 916:
	case 917:
	case 918:
	case 919:
	case 920:
	case 921:
	case 922:
	case 923:
	case 924:
	    return 900;
	default:
	    return alarmCode;
	}
    }

    public static WarningDTO getWarning(JsonObject jsonObject, String unit, int alarmCode, String siteTimeZone,
	    boolean streamingEnabled, String equipmentType) throws SystemException, Exception {
	WarningDTO warning = new WarningDTO();
	HashMap<String, String> data = new LinkedHashMap<>();
	switch (alarmCode) {
	case 1:
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PROCESS));
	    if (streamingEnabled && Constants.EquipmentType.TUNNEL.equals(equipmentType)) {
		data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.BATCH_ID));
	    }
	    warning.setProcess(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA));
	    warning.setFormulaId(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA_NAME));
	    warning.setFormulaName(data);
	    return warning;
	case 2:
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PROCESS));
	    if (streamingEnabled && Constants.EquipmentType.TUNNEL.equals(equipmentType)) {
		data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.BATCH_ID));
	    }
	    warning.setProcess(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA));
	    warning.setFormulaId(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA_NAME));
	    warning.setFormulaName(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PRODUCT));
	    warning.setProductName(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PHASE_DISPLAY.get(Constants.REPORTS.PHASE));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PHASE));
	    warning.setPhase(data);
	    return warning;
	case 8:
	case 9:
	case 11:
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PROCESS));
	    if (streamingEnabled && Constants.EquipmentType.TUNNEL.equals(equipmentType)) {
		data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.BATCH_ID));
	    }
	    warning.setProcess(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA));
	    warning.setFormulaId(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA_NAME));
	    warning.setFormulaName(data);
	    return warning;
	case 10:
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PROCESS));
	    if (streamingEnabled && Constants.EquipmentType.TUNNEL.equals(equipmentType)) {
		data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.BATCH_ID));
	    }
	    warning.setProcess(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA));
	    warning.setFormulaId(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA_NAME));
	    warning.setFormulaName(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_ID_DISPLAY.get(Constants.REPORTS.PRODUCT_ID));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PRODUCT_ID));
	    warning.setProductId(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PRODUCT));
	    warning.setProductName(data);
	    data = new LinkedHashMap<>();
	    String estimatedMl = getJsonObjectAsString(jsonObject, Constants.REPORTS.ESTIMATED_ML);
	    double eMl = 0;
	    try {
		eMl = Double.parseDouble(estimatedMl);
		eMl = Precision.round(eMl, 1);
	    } catch (Exception e) {
		LOG.error("Error converting the metrrics");
	    }
	    switch (unit) {
	    case Constants.Units.UsUnit.ID:
		// eMl = eMl / 10;
		// eMl = eMl;
		break;
	    }
	    estimatedMl = eMl + "";
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.ESTIMATED_USAGE_DISPLAY.get(Constants.REPORTS.ESTIMATED_ML));
	    data.put(Constants.REPORTS.VALUE, estimatedMl);
	    warning.setEstimatedChemical(data);
	    data = new LinkedHashMap<>();
	    String actualMl = getJsonObjectAsString(jsonObject, Constants.REPORTS.ACTUAL_ML);
	    double aMl = 0;
	    try {
		aMl = Double.parseDouble(actualMl);
		aMl = Precision.round(aMl, 1);
	    } catch (Exception e) {
		LOG.error("Error converting the metrrics");
	    }
	    switch (unit) {
	    case Constants.Units.UsUnit.ID:
		// aMl = aMl / 10;
		// aMl = aMl;
		break;
	    }
	    actualMl = aMl + "";
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.ACTUAL_USAGE_DISPLAY.get(Constants.REPORTS.ACTUAL_ML));
	    data.put(Constants.REPORTS.VALUE, actualMl);
	    warning.setActualChemical(data);
	    data = new LinkedHashMap<>();
	    String estimatedTime = getJsonObjectAsString(jsonObject, Constants.REPORTS.ESTIMATED_TIME);
	    try {
		double eT = Double.parseDouble(estimatedTime);
		eT = eT / 10;
		eT = Precision.round(eT, 1);
		estimatedTime = eT + "";
	    } catch (Exception e) {
		LOG.error("Error converting the metrrics");
	    }
	    // data.put(Constants.REPORTS.KEY,
	    // Constants.REPORTS.DISPLAY_FIELDS.ESTIMATED_TIME_DISPLAY.get(Constants.REPORTS.ESTIMATED_TIME));
	    // data.put(Constants.REPORTS.VALUE, estimatedTime);
	    // warning.setEstimatedTime(data);
	    // data = new LinkedHashMap<>();
	    // String actualTime = getJsonObjectAsString(jsonObject,
	    // Constants.REPORTS.ACTUAL_TIME);
	    // try {
	    // double aT = Double.parseDouble(actualTime);
	    // aT = aT / 10;
	    // aT = Precision.round(aT, 1);
	    // actualTime = aT + "";
	    // } catch (Exception e) {
	    // LOG.error("Error converting the metrrics");
	    // }
	    // data.put(Constants.REPORTS.KEY,
	    // Constants.REPORTS.DISPLAY_FIELDS.ACTUAL_TIME_DISPLAY.get(Constants.REPORTS.ACTUAL_TIME));
	    // data.put(Constants.REPORTS.VALUE, actualTime);
	    // warning.setActualTime(data);
	    return warning;
	// case 32:
	// case 33:
	// data = new LinkedHashMap<>();
	// data.put(Constants.REPORTS.KEY,
	// Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	// data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject,
	// Constants.REPORTS.DATE_TIME));
	// warning.setDateTime(data);
	// return warning;
	default:
	    // data = new LinkedHashMap<>();
	    // data.put(Constants.REPORTS.KEY,
	    // Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    // data.put(Constants.REPORTS.VALUE,
	    // getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME));
	    // warning.setDateTime(data);
	    // data = new LinkedHashMap<>();
	    // data.put(Constants.REPORTS.KEY,
	    // Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    // data.put(Constants.REPORTS.VALUE,
	    // getJsonObjectAsString(jsonObject, Constants.REPORTS.PROCESS));
	    // warning.setProcess(data);
	    // return warning;
	    return null;
	}
    }

    private static String getJsonObjectAsString(JsonObject jsonObject, String key) {
	try {
	    return jsonObject.get(key).getAsString();
	} catch (Exception e) {
	    LOG.error("Key : " + key + " value does not exist.");
	}
	return "";
    }

    public static boolean isSystemAlarm(int alarmCode) {
	switch (alarmCode) {
	case 900:
	case 927:
	case 928:
	case 32:
	case 33:
	case 16:
	    return true;
	default:
	    return false;
	}
    }

    // Start Temp 927, 928 code.
    public static List<WarningDTO> getSystemWarningList(int alarmCode, List<WarningDTO> systemWarningList,
	    JsonObject jsonObject, int actualAlarm, Map<String, String> productMap, String siteTimeZone,
	    boolean streamingEnabled, String equipmentType) throws SystemException, Exception {
	if (!isSystemAlarm(alarmCode)) {
	    return null;
	}
	String date = "";
	HashMap<String, String> data = new LinkedHashMap<>();
	WarningDTO warning = new WarningDTO();
	switch (alarmCode) {
	case 900:
	    if (systemWarningList == null) {
		systemWarningList = new LinkedList<>();
	    }

	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);
	    data = new LinkedHashMap<>();
	    String product = getJsonObjectAsString(jsonObject, Constants.REPORTS.PRODUCT);
	    if (StringUtils.isEmpty(product)) {
		int alarmVal = actualAlarm - 900;
		if (alarmVal >= 0) {
		    String prod = productMap.get(alarmVal + "");
		    if (!StringUtils.isEmpty(prod)) {
			product = prod;
		    }
		}
	    }
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    data.put(Constants.REPORTS.VALUE, product);
	    warning.setProductName(data);
	    systemWarningList.add(warning);
	    return systemWarningList;
	case 927:
	case 928:
	case 32:
	case 33:
	    if (systemWarningList == null) {
		systemWarningList = new LinkedList<>();
	    }
	    warning = new WarningDTO();
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);

	    systemWarningList.add(warning);
	    return systemWarningList;

	case 16:
	    if (systemWarningList == null) {
		systemWarningList = new LinkedList<>();
	    }
	    warning = new WarningDTO();
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PROCESS));
	    if (streamingEnabled && Constants.EquipmentType.TUNNEL.equals(equipmentType)) {
		data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.BATCH_ID));
	    }
	    warning.setProcess(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_ID_DISPLAY.get(Constants.REPORTS.PRODUCT_ID));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PRODUCT_ID));
	    warning.setProductId(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PRODUCT));
	    warning.setProductName(data);
	    systemWarningList.add(warning);
	    return systemWarningList;
	default:
	    return null;
	}
    }
    // End Temp 927, 928 code.

    public static List<String> getHeaderList(int alarmCode) {
	List<String> headerList = new LinkedList<>();
	switch (alarmCode) {
	case 1:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    return headerList;
	case 2:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PHASE_DISPLAY.get(Constants.REPORTS.PHASE));
	    return headerList;
	case 8:
	case 9:
	case 11:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    return headerList;
	case 10:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_ID_DISPLAY.get(Constants.REPORTS.PRODUCT_ID));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    headerList
		    .add(Constants.REPORTS.DISPLAY_FIELDS.ESTIMATED_USAGE_DISPLAY.get(Constants.REPORTS.ESTIMATED_ML));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.ACTUAL_USAGE_DISPLAY.get(Constants.REPORTS.ACTUAL_ML));
	    return headerList;
	case 16:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_ID_DISPLAY.get(Constants.REPORTS.PRODUCT_ID));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    return headerList;
	case 32:
	case 33:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    return headerList;
	default:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    return headerList;
	}
    }

    public static MachineDTO getMachine(WarningDTO warning, Map<String, Map<String, Object>> machineNameMap,
	    String lm2Seq) {
	MachineDTO machine = new MachineDTO();
	try {
	    machine.setCapacity((int) (machineNameMap.get(lm2Seq).get(Constants.REPORTS.CAPACITY)));
	    machine.setMachineId(lm2Seq + "");
	    machine.setMachineName(machineNameMap.get(lm2Seq).get(Constants.REPORTS.NAME).toString());
	    machine.setWarningCount(0);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error fetching machine information : " + e.getMessage());
	}
	List<WarningDTO> warningList = new LinkedList<>();
	if (warning != null) {
	    warningList.add(warning);
	}
	if (StringUtils.isEmpty(machine.getMachineName())) {
	    machine.setMachineName("");
	    machine.setMachineId("");
	}
	if (StringUtils.isEmpty(machine.getMachineId())) {
	    machine.setMachineId("");
	}
	machine.setWarningList(warningList);
	return machine;
    }

    public static HashMap<String, Object> getCompomentHealth() throws Exception {
	long startTime;
	long endTime;
	int elapsedTime;
	String ELASTIC_SEARCH = "elasticsearch";
	String USER_AGENT = "Mozilla/5.0";
	startTime = System.currentTimeMillis();
	HashMap<String, Object> responseMap = new HashMap<>();
	String elasticSearchErrorMessage = "";
	ConfigReader config = ConfigReader.getObject();
	String esHostName = config.getAppConfig(Constants.ES_HOST_NAMES);
	String esScheme = config.getAppConfig(Constants.ES_SCHEME);
	String esPortNumber = config.getAppConfig(Constants.ES_PORTS);
	if (StringUtils.isEmpty(esHostName) || esHostName.equalsIgnoreCase("null")) {
	    LOG.error("********ES Host Name environment variable is not set");
	    throw new IllegalArgumentException("ES Host Name environment variable is not set");
	}
	if (StringUtils.isEmpty(esPortNumber) || esPortNumber.equalsIgnoreCase("null")) {
	    LOG.error("********ES Port number environment variable is not set");
	    throw new IllegalArgumentException("ES Port number environment variable is not set");
	}
	String url = esScheme + "://" + esHostName + ":" + esPortNumber + "/_cluster/health";

	StringBuffer response = null;
	CloseableHttpClient httpClient = null;
	BufferedReader reader = null;
	try {
	    httpClient = HttpClients.createDefault();
	    HttpGet httpGet = new HttpGet(url);
	    httpGet.addHeader("User-Agent", USER_AGENT);

	    CloseableHttpResponse httpResponse = httpClient.execute(httpGet);
	    reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

	    String inputLine;
	    response = new StringBuffer();

	    while ((inputLine = reader.readLine()) != null) {
		response.append(inputLine);
	    }
	} catch (Exception e) {
	    elasticSearchErrorMessage = "Elastic Search Errored out with the root cause : " + e.getMessage();
	    responseMap.put(ELASTIC_SEARCH, elasticSearchErrorMessage);
	    LOG.error(elasticSearchErrorMessage);
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    return responseMap;
	} finally {
	    try {
		if (reader != null) {
		    reader.close();
		}
	    } catch (Exception e1) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e1));
	    }
	    try {
		if (httpClient != null) {
		    httpClient.close();
		}
	    } catch (Exception e2) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e2));
	    }
	}
	responseMap.put(ELASTIC_SEARCH, response);
	endTime = System.currentTimeMillis();
	elapsedTime = (int) (endTime - startTime) / 1000;
	LOG.debug("Time taken to copy log file using Files.copy: " + elapsedTime + " s");
	return responseMap;

    }

    public static String getformulaName(String formula) {
	if (StringUtils.isEmpty(formula)) {
	    return formula;
	}
	try {
	    String[] formulaBits = formula.split("_");
	    String firstBit = "";
	    if (formulaBits != null && formulaBits.length > 0) {
		if (formulaBits.length == 1) {
		    return formula;
		}
		firstBit = formulaBits[0];
		if (firstBit.matches("[1-9]")) {
		    firstBit = "0" + firstBit;
		} else {
		    return formula;
		}
		firstBit = firstBit + "_";
		for (int i = 1; i < formulaBits.length; i++) {
		    String bit = formulaBits[i];
		    firstBit += bit;
		}
	    }
	    if (!StringUtils.isEmpty(firstBit)) {
		formula = firstBit;
	    }
	} catch (Exception e) {
	    // TODO: handle exception
	    LOG.error("Error fetching value. Error : " + e.getMessage());
	}
	return formula;
    }

    public static List<MachineDTO> creatingMachineList(Map<String, Map<String, Object>> machineNameMap) {
	List<MachineDTO> masterMaschineList = new LinkedList<>();
	machineNameMap.forEach((lm2Seq, mMap) -> {
	    MachineDTO machine = new MachineDTO();
	    machine.setMachineName(mMap.get(Constants.REPORTS.NAME).toString());
	    int machineSeq = 0;
	    try {
		machineSeq = Integer.parseInt(mMap.get(Constants.REPORTS.LM2_SEQ).toString());
	    } catch (Exception e) {
		LOG.error("Invalid lm2 sequence : " + e.getMessage());
	    }
	    int capacity = 0;
	    try {
		capacity = Integer.parseInt(mMap.get(Constants.REPORTS.CAPACITY).toString());
	    } catch (Exception e) {
		LOG.error("Invalid machine capacity : " + e.getMessage());
	    }
	    machine.setWarningCount(0);
	    machine.setCapacity(capacity);
	    machine.setLm2Seq(machineSeq);
	    machine.setMachineId(machineSeq + "");
	    List<WarningDTO> warningList = new LinkedList<>();
	    machine.setWarningList(warningList);
	    masterMaschineList.add(machine);
	});
	masterMaschineList.sort(Comparator.comparing(MachineDTO::getLm2Seq));
	return masterMaschineList;
    }

    public static void unsetFormulaEstimatedValue(List<FormulaDTO> formulaList) {
	for (FormulaDTO formula : formulaList) {
	    formula.setErrorUsage(null);
	    formula.setEstimatedUsage(null);
	    formula.setEstimatedCost(null);
	    formula.setEstimatedCw(null);
	    formula.setErrorCost(null);
	}
    }

    public static void unsetFormulaActualValue(List<FormulaDTO> formulaList) {
	for (FormulaDTO formula : formulaList) {
	    formula.setActualUsage(null);
	    formula.setErrorUsage(null);
	    formula.setRealCost(null);
	    formula.setRealCw(null);
	    formula.setErrorCost(null);
	}
    }

    public static List<String> createIndexList(LocalDate startDate, LocalDate endDate, SiteDTO siteDTO) {
	Set<String> indexSet = new HashSet<>();
	while (startDate.isBefore(endDate) || startDate.isEqual(endDate)) {
	    try {
		indexSet.add(
			ReportUtils.getIndexName(siteDTO.getSiteId(), startDate.getMonthValue(), startDate.getYear()));
	    } catch (Exception e) {
		e.printStackTrace();
	    }

	    long intervalDays = ChronoUnit.DAYS.between(startDate, endDate);
	    if (intervalDays >= 30) {
		startDate = startDate.plusMonths(1);
	    } else {
		startDate = startDate.plusDays(1);
	    }
	}

	return new LinkedList<>(indexSet);
    }

    public static List<String> getExistingIndices(String fromDate, String toDate, SiteDTO siteDTO) {
	// hydro-siteid-*-year
	String getExistingIndices = "";
	List<String> indexList = null;
	ESRestDAO esDao = null;
	if (!StringUtils.isEmpty(fromDate) && !StringUtils.isEmpty(toDate)) {
	    try {
		esDao = new ESRestDAO();
		LocalDate startDate = ExcelUtils.convertStringToLocalDate(fromDate);
		LocalDate endDate = ExcelUtils.convertStringToLocalDate(toDate);
		indexList = createIndexList(startDate, endDate, siteDTO);
		ConfigReader config = ConfigReader.getObject();
		while (startDate.getYear() <= endDate.getYear()) {
		    getExistingIndices = String.valueOf(getExistingIndices) + config.getAppConfig(Constants.ES_INDEX)
			    + siteDTO.getSiteId() + Constants.HYPHEN + Constants.ASTERISK + Constants.HYPHEN
			    + startDate.getYear() + Constants.COMMA;
		    startDate = startDate.plusYears(1);
		}
		getExistingIndices = getExistingIndices.replaceAll(",$", "");
		List<String> existingIndices = esDao.getIndexForSite(getExistingIndices);
		indexList.retainAll(existingIndices);
		LOG.info("ES indices to be queried : " + indexList);
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    } finally {
		if (esDao != null) {
		    esDao.closeRestClient();
		}
	    }
	}
	return indexList;
    }

    public static List<String> createDailyIndexList(List<String> dateList, SiteDTO siteDTO) {
	List<String> indexList = new LinkedList<String>();
	if (dateList != null)
	    try {
		for (String s : dateList) {
		    LocalDate date = ExcelUtils.convertStringToLocalDate(s);
		    indexList.add(ReportUtils.getDailyIndexName(siteDTO.getSiteId(), date.getDayOfMonth(),
			    date.getMonthValue(), date.getYear()));
		}
	    } catch (Exception e) {
		e.printStackTrace();
	    }
	return indexList;
    }

    public static List<String> getExistingDailyIndices(List<String> dateList, SiteDTO siteDTO) {
	// daily-hydro-*-month-year-site_id
	String getExistingIndices = "";
	List<String> indexList = null;
	ESRestDAO esDao = null;
	if (dateList != null) {
	    try {
		esDao = new ESRestDAO();
		indexList = createDailyIndexList(dateList, siteDTO);
		ConfigReader config = ConfigReader.getObject();
		for (String s : dateList) {
		    LocalDate date = ExcelUtils.convertStringToLocalDate(s);
		    getExistingIndices = String.valueOf(getExistingIndices)
			    + config.getAppConfig(Constants.ES_DAILY_INDEX) + Constants.ASTERISK + Constants.HYPHEN
			    + date.getMonthValue() + Constants.HYPHEN + date.getYear() + Constants.HYPHEN
			    + siteDTO.getSiteId() + Constants.COMMA;
		}
		getExistingIndices = getExistingIndices.replaceAll(",$", "");
		List<String> existingIndices = esDao.getIndexForSite(getExistingIndices);
		if (indexList != null) {
		    indexList.retainAll(existingIndices);
		}
		LOG.info("ES indices to be queried : " + indexList);
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    } finally {
		if (esDao != null) {
		    esDao.closeRestClient();
		}
	    }
	}
	return indexList;

    }

    public static List<String> processingESResponse(String rawBody) {
	ObjectMapper mapper = new ObjectMapper();
	List<String> indices = null;
	List<Map<String, String>> list = null;
	try {
	    if (!StringUtils.isEmpty(rawBody)) {
		list = mapper.readValue(rawBody, new TypeReference<List<HashMap<String, String>>>() {
		});
	    }
	    if (list != null) {
		indices = list.stream().map(x -> x.get(Constants.INDEX)).collect(Collectors.toList());
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return indices;

    }

    public static String getDailyIndexName(String site, int day, int month, int year) throws Exception {
	ConfigReader config = ConfigReader.getObject();
	String index = config.getAppConfig(Constants.ES_DAILY_INDEX) + day + "-" + month + "-" + year + "-" + site;
	return index;
    }

    public static String getCurrentTime(String timeZone) {
	DateFormat timeFormatter = null;
	String time = null;
	try {
	    DateFormat formatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.DATE_FORMAT);
	    Date utcdate = new Date();
	    formatter.setTimeZone(TimeZone.getTimeZone(Constants.UTC));
	    LOG.debug("Current UTC date time:: " + formatter.format(utcdate));

	    timeFormatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);
	    timeFormatter.setTimeZone(TimeZone.getTimeZone(timeZone));
	    time = timeFormatter.format(utcdate);
	    // currentTime = timeFormat.parse(formatter.format(utcdate));
	    // LOG.debug("TimeZone based time::" + timeZone + "time::" + time);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return time;
    }

    public static String getCurrentDateTime(String timeZone) {
	DateFormat timeFormatter = null;
	String time = null;
	try {
	    DateFormat formatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.DATE_FORMAT);
	    Date utcdate = new Date();
	    formatter.setTimeZone(TimeZone.getTimeZone(Constants.UTC));
	    LOG.debug("Current UTC date time:: " + formatter.format(utcdate));

	    timeFormatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	    time = timeFormatter.format(utcdate);
	    // currentTime = timeFormat.parse(formatter.format(utcdate));
	    // LOG.debug("TimeZone based time::" + timeZone + "time::" + time);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return time;
    }

    public static String getCurrentDate(String timeZone) {
	DateFormat timeFormatter = null;
	String time = null;
	try {
	    DateFormat formatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.DATE_FORMAT);
	    Date utcdate = new Date();
	    formatter.setTimeZone(TimeZone.getTimeZone(Constants.UTC));
	    LOG.debug("Current UTC date time:: " + formatter.format(utcdate));

	    timeFormatter = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT);
	    timeFormatter.setTimeZone(TimeZone.getTimeZone(timeZone));
	    time = timeFormatter.format(utcdate);
	    // currentTime = timeFormat.parse(formatter.format(utcdate));
	    // LOG.debug("TimeZone based time::" + timeZone + "time::" + time);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return time;
    }

    public static RealTimeAlarmDTO getAlarmDetails(Integer alarmType, Integer eventType, String product) {
	// send only alarm na
	RealTimeAlarmDTO alarm = new RealTimeAlarmDTO();
	switch (eventType) {
	case 0:
	    switch (alarmType) {
	    case 8:
	    case 9:
	    case 10:
	    case 11:
		alarm.setAlarmName(Constants.REPORTS.REAL_TIME_ALARMS.get(alarmType));
		return alarm;
	    default:
		if (!Constants.REPORTS.SYSTEM_ALARMS.containsKey(alarmType))
		    alarm.setAlarmName(Constants.REPORTS.OTHER_ALARM);
		return alarm;
	    }
	case 11:
	    switch (alarmType) {
	    case 1:
	    case 2:
		alarm.setAlarmName(Constants.REPORTS.REAL_TIME_ALARMS.get(alarmType));
		return alarm;
	    default:
		if (!Constants.REPORTS.SYSTEM_ALARMS.containsKey(alarmType))
		    alarm.setAlarmName(Constants.REPORTS.OTHER_ALARM);
		return alarm;
	    }
	default:
	    if (!Constants.REPORTS.SYSTEM_ALARMS.containsKey(alarmType))
		alarm.setAlarmName(Constants.REPORTS.OTHER_ALARM);
	    return alarm;
	}
    }

    public static RealTimeAlarmDTO createSystemAlarm(Integer alarmType, JsonObject event,
	    DailyReportResponseDTO response, RealTimeAlarmDTO alarmDTO) throws Exception {
	// send only alarm na
	RealTimeAlarmDTO alarm = new RealTimeAlarmDTO();
	Integer eventType = event.get(Constants.REPORTS.EVENT_TYPE).getAsInt();
	String product = event.get(Constants.REPORTS.PRODUCT).getAsString();
	switch (eventType) {
	case 100:
	    switch (alarmType) {
	    case 16:
		Map<Integer, DailyReportProductDTO> productMap;
		if (alarmDTO == null) {
		    alarmDTO = new RealTimeAlarmDTO();
		    alarmDTO.setAlarmName(Constants.REPORTS.REAL_TIME_ALARMS.get(alarmType));
		    productMap = new LinkedHashMap<Integer, DailyReportProductDTO>();

		} else {
		    productMap = alarmDTO.getProductMap();
		}

		DailyReportProductDTO productDetails = new DailyReportProductDTO();
		productDetails.setProductId(event.get(Constants.REPORTS.PRODUCT_ID).getAsInt());
		productDetails.setProductName(product);
		productDetails.setTime(ReportUtils.convertStringToDate(CommonUtils
			.extractFechaDateInProcessableFormat(event.get(Constants.REPORTS.DATE_TIME).getAsString())));
		productMap.put(event.get(Constants.REPORTS.PRODUCT_ID).getAsInt(), productDetails);
		alarmDTO.setProductMap(productMap);
		return alarmDTO;
	    default:
		alarm.setAlarmName(Constants.REPORTS.OTHER_ALARM);
		return alarmDTO;
	    }
	case 200:
	    switch (alarmType) {
	    case 32:
	    case 33:
		alarm.setAlarmName(Constants.REPORTS.REAL_TIME_ALARMS.get(alarmType));
		response.setClearAlarm(false);
		return alarm;
	    default:
		alarm.setAlarmName(Constants.REPORTS.OTHER_ALARM);
		return alarm;
	    }
	default:
	    alarm.setAlarmName(Constants.REPORTS.OTHER_ALARM);
	    return alarm;
	}
    }

    public static List<Integer> bitPositions(int number) {
	List<Integer> positions = new LinkedList<>();
	int position = 1;
	while (number != 0) {
	    if ((number & 1) != 0) {
		positions.add(position);
	    }
	    position++;
	    number = number >>> 1;
	}
	return positions;
    }

    public interface PHASE_STATUS {
	Integer SUCCESSFUL = 0;
	Integer IN_PROGRESS = 1;
	Integer MISSED_PHASE = 2;
	Integer YET_TO_START = 3;

	HashMap<Integer, String> phaseStatusConstants = new LinkedHashMap<Integer, String>() {
	    {
		put(SUCCESSFUL, "SUCCESSFUL");
		put(IN_PROGRESS, "IN_PROGRESS");
		put(MISSED_PHASE, "MISSED_PHASE");
		put(YET_TO_START, "YET_TO_START");
	    }
	};
    }

    public static String getTimeFromDate(Date date) {
	SimpleDateFormat timeFormat = null;
	try {
	    timeFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return timeFormat.format(date);
    }

    public static Integer cycleId(JsonObject event) {
	int cycleId = -1;
	try {
	    cycleId = event.get(Constants.REPORTS.PROCESS).getAsInt();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return cycleId;
    }

    public static Date convertStringToDate(String date) throws Exception {
	SimpleDateFormat localDateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	Date convertedDate;
	try {
	    convertedDate = localDateFormat.parse(date);
	} catch (ParseException e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, date);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, date);
	}
	return convertedDate;
    }

    public static String getDate(Date date) throws Exception {
	String validDate;
	try {
	    DateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT);
	    validDate = dateFormat.format(date);
	    return validDate;
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, date);
	}
    }

    public static String getTime(Date date) throws Exception {
	String validDate;
	try {
	    DateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.TIME_FORMAT);
	    validDate = dateFormat.format(date);
	    return validDate;
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, date);
	}
    }

    public static String convertDateToString(Date date) throws SystemException, Exception {
	String validDate;
	try {
	    DateFormat dateFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME);
	    validDate = dateFormat.format(date);
	    return validDate;
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.INVAILD_TIME_STAMP, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, date);
	}
    }

    public static boolean setPrevPhase(JsonObject event) {
	ConfigReader config = new ConfigReader();
	if (!event.get(Constants.REPORTS.EVENT_TYPE).getAsString()
		.equals(config.getAppConfig(Constants.REPORTS.MISSED_PHASE))) {
	    if (!event.get(Constants.REPORTS.PHASE).getAsString()
		    .equals(config.getAppConfig(Constants.REPORTS.ZERO_PHASE))) {
		return true;
	    }
	}
	return false;
    }

    public static String dayWiseReportIndex(SiteDTO site, String reportType, String startShift) throws Exception {

	ConfigReader config = new ConfigReader();
	String date = CommonUtils.getDateFromDateObject(startShift);
	String time = CommonUtils.getTimeFromDateObject(startShift);
	DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT);
	String indexName = null;
	switch (reportType) {

	case "0": // real time
		  // current running shift is on 14th nov and cycle spilled from 13th
		  // nov, then create index name for 13th nov. Otherwise use same
		  // index.

	    if (time.equals(config.getAppConfig(Constants.DEFAULT_SHIFT_START_TIME))) {
		LocalDate ld = ExcelUtils.convertStringToLocalDate(LocalDate.parse(date).minusDays(1).toString());
		return ReportUtils.getDailyIndexName(site.getSiteId(), ld.getDayOfMonth(), ld.getMonthValue(),
			ld.getYear());
	    } else {
		LocalDate ld = ExcelUtils.convertStringToLocalDate(date);
		indexName = ReportUtils.getDailyIndexName(site.getSiteId(), ld.getDayOfMonth(), ld.getMonthValue(),
			ld.getYear());
	    }

	case "1":// historical
		 // if current running shift occurs on 1st of nov then index of
		 // october should be used. Otherwise use same index.
	    if (date != null) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(CommonUtils.convertStringToDate(startShift));
		int month = calendar.get(Calendar.MONTH) + 1;
		int year = calendar.get(Calendar.YEAR);
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
		if (month == 1 || dayOfMonth == 1) {
		    LocalDate actualDateOne = LocalDate
			    .parse(parseDate(CommonUtils.convertStringToDate(startShift)), timeFormatter).minusDays(1);
		    return ReportUtils.getIndexName(site.getSiteId(), actualDateOne.getMonthValue(),
			    actualDateOne.getYear());
		} else {
		    indexName = ReportUtils.getIndexName(site.getSiteId(), month, year);
		}
	    }
	}
	return indexName;
    }

    public static String parseDate(Date dateObj) {
	String pattern = Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT;
	SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
	return simpleDateFormat.format(dateObj);
    }

    public static long getCycleActiveTimeInShift(Date cycleStartTime, Date cycleEndTime, String startShift,
	    String endShift, long currentTime) {
	// cycle is not completed
	if (cycleStartTime != null && cycleEndTime == null) {
	    long cycleStartTimeLong = cycleStartTime.getTime();
	    long endShiftLong;
	    try {
		endShiftLong = CommonUtils.convertStringToLongDateTime(endShift);
		long startShiftLong = CommonUtils.convertStringToLongDateTime(startShift);
		if (cycleStartTimeLong < startShiftLong) {
		    return (endShiftLong - startShiftLong);
		}

		// Since, there was slight time difference in system time
		// and server time cycleActiveTime was coming -ve.
		// Hence to avoid that check if cycleStart < currentTime
		if (currentTime < endShiftLong && cycleStartTimeLong < currentTime) {
		    return (currentTime - cycleStartTimeLong);
		} else if (cycleStartTimeLong < endShiftLong && currentTime > endShiftLong) {
		    return (endShiftLong - cycleStartTimeLong);

		}
	    } catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }

	}
	// cycle is completed and current time doesn't fall in cycle time
	if (cycleStartTime != null && cycleEndTime != null) {
	    long cycleStartTimeLong = cycleStartTime.getTime();
	    long cycleEndTimeLong = cycleEndTime.getTime();
	    long endShiftLong;
	    long startShiftLong;

	    if (startShift != null && endShift != null) {
		try {
		    endShiftLong = CommonUtils.convertStringToLongDateTime(endShift);
		    startShiftLong = CommonUtils.convertStringToLongDateTime(startShift);
		    if (cycleStartTimeLong == cycleEndTimeLong) {
			return 0;
		    } else {
			if (cycleStartTimeLong < cycleEndTimeLong) {
			    // if cycle start before shift and end's after shift
			    if (cycleStartTimeLong < startShiftLong && cycleEndTimeLong > endShiftLong) {
				return (endShiftLong - startShiftLong);
			    }
			    // if cycle start before shift and end's within the shift
			    if (cycleStartTimeLong <= startShiftLong && cycleEndTimeLong >= startShiftLong
				    && cycleEndTimeLong < endShiftLong) {
				return (cycleEndTimeLong - startShiftLong);
			    }
			    // if cycle start within the shift and end's after the shift
			    if (cycleStartTimeLong >= startShiftLong && cycleStartTimeLong < endShiftLong
				    && cycleEndTimeLong >= endShiftLong) {
				return (endShiftLong - cycleStartTimeLong);
			    }
			    // if cycle start within the shift and end's within the
			    // shift
			    if (cycleStartTimeLong >= startShiftLong && cycleStartTimeLong < endShiftLong
				    && cycleEndTimeLong <= endShiftLong) {
				return (cycleEndTimeLong - cycleStartTimeLong);
			    }
			} else {
			    return 0;
			}
		    }
		} catch (Exception e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		}
	    }
	    return 0;
	}

	return 0;
    }

    /**
     * Get the prev months index for monthly index as per the totalMonth value. If
     * totalMonth = 3, then prev 3 months index will be created w.r.t the current
     * month.
     * 
     * @param date
     * @param avgReferenceMonth
     * @param siteId
     * @return list of index
     */

    public static List<String> getPreviousMonthsIndex(String fromdate, int avgReferenceMonth, String siteId) {
	List<String> indexList = null;
	if (avgReferenceMonth != 0 && fromdate != null) {
	    indexList = new LinkedList<>();
	    LocalDate currentDate = LocalDate.parse(fromdate);
	    String index;
	    ConfigReader config = new ConfigReader();
	    LocalDate prevDate = currentDate;
	    while (avgReferenceMonth > 0) {
		index = config.getAppConfig(Constants.ES_INDEX) + siteId + Constants.HYPHEN + prevDate.getMonthValue()
			+ Constants.HYPHEN + prevDate.getYear();
		prevDate = prevDate.minusMonths(1);
		indexList.add(index);
		avgReferenceMonth--;
	    }
	}
	return indexList;
    }

    public static String getToDateForMonthAvgCalculation(String fromDate) {
	ConfigReader config = new ConfigReader();
	LocalDate fromLocalDate = LocalDate.parse(fromDate);
	YearMonth yearMonth = YearMonth.from(fromLocalDate);
	// LocalDate end = yearMonth.atEndOfMonth();
	String toDate = yearMonth.atEndOfMonth().toString() + Constants.T
		+ config.getAppConfig(Constants.DEFAULT_SHIFT_END_TIME);
	return toDate;

    }

    public static String getFromDateForMonthAvgCalculation(String monthlyFromDate, int avgReferenceMonth) {
	ConfigReader config = new ConfigReader();
	avgReferenceMonth = avgReferenceMonth - 1;
	LocalDate fromLocalDate = LocalDate.parse(monthlyFromDate);
	YearMonth yearMonth = YearMonth.from(fromLocalDate);
	yearMonth = yearMonth.minusMonths(avgReferenceMonth);
	// LocalDate start = yearMonth.atDay(1);
	String fromDate = yearMonth.atDay(1).toString() + Constants.T
		+ config.getAppConfig(Constants.DEFAULT_SHIFT_START_TIME);
	return fromDate;
    }

    public static String convertMillsecToHHMMSS(long milliseconds) {
	int hrs = (int) TimeUnit.MILLISECONDS.toHours(milliseconds);
	int min = (int) TimeUnit.MILLISECONDS.toMinutes(milliseconds) % 60;
	int sec = (int) TimeUnit.MILLISECONDS.toSeconds(milliseconds) % 60;
	String hms = String.format("%02d:%02d:%02d", hrs, min, sec);
	return hms;
    }

    public static Interval getBatchActiveTime(Date cycleStartTime, Date cycleEndTime, String startShift,
	    String endShift, long currentTime) {
	List<Interval> intervals = new LinkedList<>();
	if (cycleStartTime != null && cycleEndTime == null) {
	    long cycleStartTimeLong = cycleStartTime.getTime();
	    long endShiftLong;
	    try {
		endShiftLong = CommonUtils.convertStringToLongDateTime(endShift);
		long startShiftLong = CommonUtils.convertStringToLongDateTime(startShift);
		if (cycleStartTimeLong < startShiftLong) {
		    cycleStartTimeLong = startShiftLong;
		}
		if (currentTime < endShiftLong && cycleStartTimeLong < currentTime) {
		    // Since, there was slight time difference in system time
		    // and server time cycleActiveTime was coming -ve.
		    // Hence to avoid that check if cycleStart < currentTime
		    return new Interval(currentTime, cycleStartTimeLong);
		} else if (cycleStartTimeLong < endShiftLong && currentTime > endShiftLong) {
		    return new Interval(cycleStartTimeLong, endShiftLong);
		}
	    } catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	    }

	}

	if (cycleStartTime != null && cycleEndTime != null) {
	    long cycleStartTimeLong = cycleStartTime.getTime();
	    long cycleEndTimeLong = cycleEndTime.getTime();
	    long endShiftLong;
	    long startShiftLong;

	    if (startShift != null && endShift != null) {
		try {
		    endShiftLong = CommonUtils.convertStringToLongDateTime(endShift);
		    startShiftLong = CommonUtils.convertStringToLongDateTime(startShift);
		    if (cycleStartTimeLong == cycleEndTimeLong) {
			intervals.add(new Interval(0, 0));
		    } else {
			if (cycleStartTimeLong < cycleEndTimeLong) {
			    // if cycle start before shift and end's after shift
			    if (cycleStartTimeLong < startShiftLong && cycleEndTimeLong > endShiftLong) {
				return new Interval(startShiftLong, endShiftLong);
			    }
			    // if cycle start before shift and end's within the shift
			    if (cycleStartTimeLong <= startShiftLong && cycleEndTimeLong >= startShiftLong
				    && cycleEndTimeLong < endShiftLong) {
				return new Interval(startShiftLong, cycleEndTimeLong);
			    }
			    // if cycle start within the shift and end's after the shift
			    if (cycleStartTimeLong >= startShiftLong && cycleStartTimeLong < endShiftLong
				    && cycleEndTimeLong >= endShiftLong) {
				return new Interval(cycleStartTimeLong, endShiftLong);
			    }
			    // if cycle start within the shift and end's within the
			    // shift
			    if (cycleStartTimeLong >= startShiftLong && cycleStartTimeLong < endShiftLong
				    && cycleEndTimeLong <= endShiftLong) {
				return new Interval(cycleStartTimeLong, cycleEndTimeLong);
			    }
			} else {
			    return new Interval(0, 0);
			}
		    }
		} catch (Exception e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		}
	    }
	}
	return new Interval(0, 0);
    }

    public static List<String> mdbHeaderList(int alarmCode) {
	List<String> headerList = new LinkedList<>();
	switch (alarmCode) {
	case 2:
	case 3:
	case 5:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    return headerList;
	case 4:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    headerList
		    .add(Constants.REPORTS.DISPLAY_FIELDS.ESTIMATED_USAGE_DISPLAY.get(Constants.REPORTS.ESTIMATED_ML));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.ACTUAL_USAGE_DISPLAY.get(Constants.REPORTS.ACTUAL_ML));
	    headerList
		    .add(Constants.REPORTS.DISPLAY_FIELDS.ESTIMATED_TIME_DISPLAY.get(Constants.REPORTS.ESTIMATED_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.ACTUAL_TIME_DISPLAY.get(Constants.REPORTS.ACTUAL_TIME));
	    return headerList;
	case 900:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    return headerList;
	case 101:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    return headerList;
	case 111:

	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.PHASE_DISPLAY.get(Constants.REPORTS.PHASE));
	    return headerList;
	case 927:
	case 928:
	    headerList.add(Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    return headerList;
	default:
	    return null;
	}
    }

    public static WarningDTO mdbWarning(JsonObject jsonObject, String unit, int alarmCode, String siteTimeZone)
	    throws SystemException, Exception {
	WarningDTO warning = new WarningDTO();
	HashMap<String, String> data = new LinkedHashMap<>();
	switch (alarmCode) {
	case 2:
	case 3:
	case 5:
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PROCESS));
	    warning.setProcess(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA));
	    warning.setFormulaId(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA_NAME));
	    warning.setFormulaName(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PRODUCT));
	    warning.setProductName(data);
	    return warning;
	case 4:
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PROCESS));
	    warning.setProcess(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA));
	    warning.setFormulaId(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA_NAME));
	    warning.setFormulaName(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PRODUCT));
	    warning.setProductName(data);
	    data = new LinkedHashMap<>();
	    String estimatedMl = getJsonObjectAsString(jsonObject, Constants.REPORTS.ESTIMATED_ML);
	    double eMl = 0;
	    try {
		eMl = Double.parseDouble(estimatedMl);
		eMl = Precision.round(eMl, 1);
	    } catch (Exception e) {
		LOG.error("Error converting the metrrics");
	    }
	    switch (unit) {
	    case Constants.Units.UsUnit.ID:
		eMl = eMl / 10;
		break;
	    }
	    estimatedMl = eMl + "";
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.ESTIMATED_USAGE_DISPLAY.get(Constants.REPORTS.ESTIMATED_ML));
	    data.put(Constants.REPORTS.VALUE, estimatedMl);
	    warning.setEstimatedChemical(data);
	    data = new LinkedHashMap<>();
	    String actualMl = getJsonObjectAsString(jsonObject, Constants.REPORTS.ACTUAL_ML);
	    double aMl = 0;
	    try {
		aMl = Double.parseDouble(actualMl);
		aMl = Precision.round(aMl, 1);
	    } catch (Exception e) {
		LOG.error("Error converting the metrrics");
	    }
	    switch (unit) {
	    case Constants.Units.UsUnit.ID:
		aMl = aMl / 10;
		break;
	    }
	    actualMl = aMl + "";
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.ACTUAL_USAGE_DISPLAY.get(Constants.REPORTS.ACTUAL_ML));
	    data.put(Constants.REPORTS.VALUE, actualMl);
	    warning.setActualChemical(data);
	    data = new LinkedHashMap<>();
	    String estimatedTime = getJsonObjectAsString(jsonObject, Constants.REPORTS.ESTIMATED_TIME);
	    try {
		double eT = Double.parseDouble(estimatedTime);
		eT = eT / 10;
		eT = Precision.round(eT, 1);
		estimatedTime = eT + "";
	    } catch (Exception e) {
		LOG.error("Error converting the metrrics");
	    }
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.ESTIMATED_TIME_DISPLAY.get(Constants.REPORTS.ESTIMATED_TIME));
	    data.put(Constants.REPORTS.VALUE, estimatedTime);
	    warning.setEstimatedTime(data);
	    data = new LinkedHashMap<>();
	    String actualTime = getJsonObjectAsString(jsonObject, Constants.REPORTS.ACTUAL_TIME);
	    try {
		double aT = Double.parseDouble(actualTime);
		aT = aT / 10;
		aT = Precision.round(aT, 1);
		actualTime = aT + "";
	    } catch (Exception e) {
		LOG.error("Error converting the metrrics");
	    }
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.ACTUAL_TIME_DISPLAY.get(Constants.REPORTS.ACTUAL_TIME));
	    data.put(Constants.REPORTS.VALUE, actualTime);
	    warning.setActualTime(data);
	    return warning;
	case 101:
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PROCESS));
	    warning.setProcess(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA));
	    warning.setFormulaId(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA_NAME));
	    warning.setFormulaName(data);
	    return warning;
	case 111:
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.DATE_DISPLAY.get(Constants.REPORTS.DATE_TIME));
	    data.put(Constants.REPORTS.VALUE,
		    CommonUtils.convertUTCtoZonedReportDate(CommonUtils.extractFechaDateInProcessableFormat(
			    getJsonObjectAsString(jsonObject, Constants.REPORTS.DATE_TIME)), siteTimeZone));
	    warning.setDateTime(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PROCESS_DISPLAY.get(Constants.REPORTS.PROCESS));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PROCESS));
	    warning.setProcess(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_ID_DISPLAY.get(Constants.REPORTS.FORMULA));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA));
	    warning.setFormulaId(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.FORMULA_NAME_DISPLAY.get(Constants.REPORTS.FORMULA_NAME));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.FORMULA_NAME));
	    warning.setFormulaName(data);
	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PRODUCT_NAME_DISPLAY.get(Constants.REPORTS.PRODUCT));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PRODUCT));
	    warning.setProductName(data);

	    data = new LinkedHashMap<>();
	    data.put(Constants.REPORTS.KEY,
		    Constants.REPORTS.DISPLAY_FIELDS.PHASE_DISPLAY.get(Constants.REPORTS.PHASE));
	    data.put(Constants.REPORTS.VALUE, getJsonObjectAsString(jsonObject, Constants.REPORTS.PHASE));
	    warning.setPhase(data);
	    return warning;
	default:
	    return null;
	}
    }

    public static String getCurrentUTCDate(String siteTimeZone) {
	String currentDate = null;
	try {
	    LocalDateTime localNow = LocalDateTime.now(TimeZone.getTimeZone(siteTimeZone).toZoneId());
	    ZonedDateTime utc = ZonedDateTime.of(localNow, ZoneOffset.UTC);
	    currentDate = utc.format(DateTimeFormatter.ISO_LOCAL_DATE);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return currentDate;
    }

    public static String getCurrentUTCDateTime(String siteTimeZone) {

	String currentDateTime = null;
	try {
	    LocalDateTime localNow = LocalDateTime.now(TimeZone.getTimeZone(siteTimeZone).toZoneId());
	    ZonedDateTime utc = ZonedDateTime.of(localNow, ZoneOffset.UTC);
	    currentDateTime = utc
		    .format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return currentDateTime;
    }

    public static String getCurrentUTCTime(String siteTimeZone) {

	String currentDateTime = null;
	try {
	    LocalDateTime localNow = LocalDateTime.now(TimeZone.getTimeZone(siteTimeZone).toZoneId());
	    ZonedDateTime utc = ZonedDateTime.of(localNow, ZoneOffset.UTC);
	    currentDateTime = utc.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.TIME_FORMAT));

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return currentDateTime;
    }

    public static long getLongCurrentUTCTime(String siteTimeZone) {

	long currentTime = 0;
	try {
	    LocalDateTime today = LocalDateTime.now();
	    ZonedDateTime currentISTime = today.atZone(ZoneId.of(siteTimeZone));
	    ZonedDateTime currentETime = currentISTime.withZoneSameInstant(ZoneId.of(Constants.UTC));
	    String currentDateTime = currentETime
		    .format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
	    return CommonUtils.convertStringToLongDateTime(currentDateTime);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return currentTime;
    }

    public static String getTimeZonedCurrentDateTime(String siteTimeZone) {

	String currentDateTime = null;
	try {
	    LocalDateTime localNow = LocalDateTime.now(TimeZone.getTimeZone(siteTimeZone).toZoneId());

	    currentDateTime = localNow
		    .format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return currentDateTime;
    }

    public static String getTimeZonedCurrentTime(String siteTimeZone) {

	String currentDateTime = null;
	try {
	    LocalDateTime localNow = LocalDateTime.now(TimeZone.getTimeZone(siteTimeZone).toZoneId());

	    currentDateTime = localNow.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.TIME_FORMAT));

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
	return currentDateTime;
    }

    public static Date convertUtilDateToZonedUtilDate(Date dateToconvert, String siteTimeZone) throws ParseException {

	SimpleDateFormat sdf = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.DATE_FORMAT);
	sdf.setTimeZone(TimeZone.getTimeZone(siteTimeZone));
	return new SimpleDateFormat(Constants.DATE_TIME_FORMAT.DATE_FORMAT).parse(sdf.format(dateToconvert));

    }

    public static Date convertUtilDateToUTCDate(Date dateToconvert, String siteTimeZone) {
	// ZonedDateTime zonedDt =
	// ZonedDateTime.ofInstant(dateToconvert.toInstant(),TimeZone.getTimeZone(siteTimeZone).toZoneId());
	// LocalDateTime ldt= zonedDt.toLocalDateTime();
	// Date.from( ldt.atZone( ZoneId.systemDefault()).toInstant());
	return new DateTime(dateToconvert).withZone(DateTimeZone.forID(siteTimeZone)).toLocalDateTime().toDate();
    }

    public static int getUniqueWarningCount(List<WarningDTO> warningList) {
	Map<HashMap<String, String>, Long> countMap = warningList.stream()
		.collect(Collectors.groupingBy(WarningDTO::getProcess, Collectors.counting()));
	return countMap.size();
    }
}
