package com.hydro.api.company.dao.concrete;



import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.CompanyDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;

public final class PartialHydroCompanyDao extends HydroCompanyDao {

	@Override
	public CompanyDTO createCompany(UserDTO user, CompanyDTO company) throws Exception {
		throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
				ErrorCodes.StatusCodes.FORBIDDEN, null);
	}

	@Override
	public boolean updateCompany(UserDTO user, CompanyDTO companyDTO) throws Exception {
		throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
				ErrorCodes.StatusCodes.FORBIDDEN, null);
	}

	@Override
	public boolean hasVisibility(UserDTO user, CompanyDTO company) throws Exception {
		if (user.getAssociationId().equals(company.getCompanyId())) {
			return true;
		}
		return false;
	}

}
