package com.hydro.api.service;

import java.security.Principal;
import java.util.LinkedList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.StreamingOutput;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.net.HttpHeaders;
import com.hydro.api.base.common.CommonConstants;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.EquipmentFormulaDTO;
import com.hydro.api.dto.EquipmentListDTO;
import com.hydro.api.dto.EquipmentPumpDTO;
import com.hydro.api.dto.EquipmentPumpMachinery;
import com.hydro.api.dto.FormulaMetaDataDTO;
import com.hydro.api.dto.ObservationDTO;
import com.hydro.api.dto.ObservationListResponseDTO;
import com.hydro.api.dto.ProductDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.StatusDTO;
import com.hydro.api.dto.TunnelDTO;
import com.hydro.api.dto.WasherMetaDataDTO;
import com.hydro.api.dto.reports.AlarmSummaryDTO;
import com.hydro.api.dto.reports.ChemicalSummaryDTO;
import com.hydro.api.dto.reports.CostSummaryDTO;
import com.hydro.api.dto.reports.DailyReportRequestDTO;
import com.hydro.api.dto.reports.ReportRequestDTO;
import com.hydro.api.dto.reports.DailyReportResponseDTO;
import com.hydro.api.dto.reports.WasherProductionDTO;
import com.hydro.api.exception.ExceptionHandler;
import com.hydro.api.exception.SystemException;
import com.hydro.api.reports.business.HydroReportsBL;
import com.hydro.api.service.helper.ServiceHelper;

/**
 * Base Service : Entry Point to the JSON APIs.
 * 
 * @author Shreyas, Srishti
 *
 */
// No Base context root for the Services. Each services have their respective
// Endpoints.
@Path("/report")
@Produces({ MediaType.APPLICATION_JSON })
public class HydroSummaryService extends HydroBaseService {
    private static final Logger LOG = LoggerFactory.getLogger(HydroSummaryService.class);
    @Context
    SecurityContext securityContext;

    public HydroSummaryService(@Context SecurityContext securityContext,
	    @HeaderParam(Constants.TIME_ZONE_HEADER) String timeZone) throws Exception {
	super();
	Principal principal = securityContext.getUserPrincipal();
	String username = principal.getName();
	BL = new HydroReportsBL(username, timeZone);
    }

    /**
     * Test API.
     * 
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/test")
    public String test() {
	long start = System.currentTimeMillis();
	resStr = "{\"messgae\":\"Summary APIs Works Fine!\"}";
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * 
     * 
     * @param body
     * @return
     * @throws Exception
     */

    @POST
    @Path("/washerProductionSummary")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String washerProductionSummary(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);
	    WasherProductionDTO response = ((HydroReportsBL) BL).washerProductionSummary(requestDTO);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/chemicalSummary")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String chemicalSummary(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);
	    ChemicalSummaryDTO response = ((HydroReportsBL) BL).chemicalSummary(requestDTO);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/costSummary")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String costSummary(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);
	    CostSummaryDTO response = ((HydroReportsBL) BL).costSummary(requestDTO);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/alarmSummary")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String alarmSummary(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);

	    AlarmSummaryDTO response = ((HydroReportsBL) BL).alarmSummary(requestDTO);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/createObservation")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String createObservation(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    ObservationDTO observation = (ObservationDTO) ServiceHelper.buildJsonString(body, ObservationDTO.class);
	    SiteDTO site = new SiteDTO();
	    site.setSiteId(observation.getSiteId());
	    observation = ((HydroReportsBL) BL).createObservation(observation, site);
	    responseDTO.setResponseObject(observation);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @PUT
    @Path("/updateObservation")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String updateObservation(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    ObservationDTO observation = (ObservationDTO) ServiceHelper.buildJsonString(body, ObservationDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroReportsBL) BL).updateObservation(observation));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @DELETE
    @Path("/deleteObservation")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String deleteObservation(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    ObservationDTO observation = (ObservationDTO) ServiceHelper.buildJsonString(body, ObservationDTO.class);
	    StatusDTO status = new StatusDTO();
	    status.setStatus(((HydroReportsBL) BL).deleteObservation(observation));
	    responseDTO.setResponseObject(status);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/getObservationList")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getObservationList(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();

	    ObservationDTO observation = (ObservationDTO) ServiceHelper.buildJsonString(body, ObservationDTO.class);

	    ObservationListResponseDTO response = new ObservationListResponseDTO();
	    response = ((HydroReportsBL) BL).getObservationList(observation);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/getEquipmentSpecification")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getEquipmentSpecification(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    EquipmentListDTO response = new EquipmentListDTO();
	    EquipmentDTO equipment = new EquipmentDTO();
	    List<EquipmentDTO> equipmentList = new LinkedList<>();
	    // SiteDTO siteDTO = new SiteDTO();
	    // siteDTO.setSiteName("sitename");
	    // siteDTO.setSiteId("siteID");
	    // equipment.setSiteDetails(siteDTO);
	    equipment.setEquipmentId("EquipmentID1");
	    equipment.setAlias("EquipmentName");
	    equipment.setCreatedBy("createdBy");
	    equipment.setCreatedDate("date");
	    equipment.setChannelCount(2);
	    equipment.setPumpCount(3);

	    equipment.setEquipmentType("equipmentType");
	    List<EquipmentPumpDTO> pumpList = new LinkedList<>();
	    EquipmentPumpDTO equipmentPumpDTO = new EquipmentPumpDTO();
	    equipmentPumpDTO.setPumpId("pumpId");
	    equipmentPumpDTO.setPumpName("pumpName1");
	    equipmentPumpDTO.setPumpValue("value");
	    pumpList.add(equipmentPumpDTO);
	    equipmentPumpDTO = new EquipmentPumpDTO();
	    equipmentPumpDTO.setPumpId("pumpId2");
	    equipmentPumpDTO.setPumpName("pumpName2");
	    equipmentPumpDTO.setPumpValue("valu2");
	    pumpList.add(equipmentPumpDTO);
	    equipment.setEquipmentPumpList(pumpList);
	    List<EquipmentFormulaDTO> equipmentFormulaList = new LinkedList<>();
	    EquipmentFormulaDTO equipmentFormulaDTO = new EquipmentFormulaDTO();
	    equipmentFormulaDTO.setFormulaId("FormulaID");
	    equipmentFormulaDTO.setFormulaName("formulaName");
	    equipmentFormulaDTO.setFormulaValue("formulaValue");
	    equipmentFormulaList.add(equipmentFormulaDTO);

	    equipmentFormulaDTO = new EquipmentFormulaDTO();
	    equipmentFormulaDTO.setFormulaId("FormulaID2");
	    equipmentFormulaDTO.setFormulaName("formulaName2");
	    equipmentFormulaDTO.setFormulaValue("formulaValue2");
	    equipmentFormulaList.add(equipmentFormulaDTO);
	    equipment.setEquipmentFormulaList(equipmentFormulaList);
	    equipment.setFormulaCount(equipmentFormulaList.size());
	    List<EquipmentPumpMachinery> pumpMachineriesList = new LinkedList<>();
	    EquipmentPumpMachinery pumpMachinery = new EquipmentPumpMachinery();
	    pumpMachinery.setPumpMachineId("pumpMachId");
	    pumpMachinery.setPumpMachineName("pumpMachineName");
	    pumpMachinery.setPumpMachineValue("MachValues");
	    pumpMachineriesList.add(pumpMachinery);
	    pumpMachinery = new EquipmentPumpMachinery();
	    pumpMachinery.setPumpMachineId("pumpMachId2");
	    pumpMachinery.setPumpMachineName("pumpMachineName2");
	    pumpMachinery.setPumpMachineValue("MachValues2");
	    pumpMachineriesList.add(pumpMachinery);
	    equipment.setEquipmentPumpMachineriesList(pumpMachineriesList);
	    List<ProductDTO> productList = new LinkedList<>();
	    ProductDTO productDTO = new ProductDTO();
	    productDTO.setProductId("productId");
	    productDTO.setName("name");
	    productDTO.setPrice("price");
	    productDTO.setKf("kf");
	    productDTO.setDensity("density");
	    productDTO.setConcentration(10);
	    productDTO.setFrequency("frequency");
	    productDTO.setCalibration("calibration");
	    productList.add(productDTO);
	    productDTO = new ProductDTO();
	    productDTO.setProductId("productId2");
	    productDTO.setName("name2");
	    productDTO.setPrice("price2");
	    productDTO.setKf("kf");
	    productDTO.setDensity("density");
	    productDTO.setConcentration(12);
	    productDTO.setFrequency("frequency");
	    productDTO.setCalibration("calibration2");
	    productList.add(productDTO);
	    equipment.setProductList(productList);
	    equipment.setProductCount(productList.size());
	    List<FormulaMetaDataDTO> formulaList = new LinkedList<>();
	    FormulaMetaDataDTO formulaMetaDataDTO = new FormulaMetaDataDTO();
	    formulaMetaDataDTO.setFormulaId("formulaId");
	    formulaMetaDataDTO.setName("formulaName");
	    formulaMetaDataDTO.setPhases("phases");
	    formulaMetaDataDTO.setLoad(50);
	    formulaMetaDataDTO.setColor("color");
	    formulaMetaDataDTO.setCreatedBy("createdBy");
	    formulaMetaDataDTO.setCreatedDate("createdDate");
	    formulaList.add(formulaMetaDataDTO);
	    formulaMetaDataDTO = new FormulaMetaDataDTO();
	    formulaMetaDataDTO.setFormulaId("formulaId2");
	    formulaMetaDataDTO.setName("formulaName22");
	    formulaMetaDataDTO.setPhases("phases2");
	    formulaMetaDataDTO.setLoad(50);
	    formulaMetaDataDTO.setColor("color");
	    formulaMetaDataDTO.setCreatedBy("createdBy");
	    formulaMetaDataDTO.setCreatedDate("createdDate");
	    formulaList.add(formulaMetaDataDTO);
	    equipment.setFormulaList(formulaList);
	    List<WasherMetaDataDTO> washerList = new LinkedList<>();
	    WasherMetaDataDTO washerMetaDataDTO = new WasherMetaDataDTO();
	    washerMetaDataDTO.setWasherId("washerID");
	    washerMetaDataDTO.setName("washerName");
	    washerMetaDataDTO.setLoad(10);
	    washerMetaDataDTO.setCreatedBy("createdBy");
	    washerMetaDataDTO.setCreatedDate("createdDate");
	    washerList.add(washerMetaDataDTO);
	    washerMetaDataDTO = new WasherMetaDataDTO();
	    washerMetaDataDTO.setWasherId("washerID");
	    washerMetaDataDTO.setName("washerName");
	    washerMetaDataDTO.setLoad(10);
	    washerMetaDataDTO.setCreatedBy("createdBy");
	    washerMetaDataDTO.setCreatedDate("createdDate");
	    washerList.add(washerMetaDataDTO);
	    washerMetaDataDTO = new WasherMetaDataDTO();
	    washerMetaDataDTO.setWasherId("washerID");
	    washerMetaDataDTO.setName("washerName");
	    washerMetaDataDTO.setLoad(10);
	    washerMetaDataDTO.setCreatedBy("createdBy");
	    washerMetaDataDTO.setCreatedDate("createdDate");
	    washerList.add(washerMetaDataDTO);
	    washerMetaDataDTO = new WasherMetaDataDTO();
	    washerMetaDataDTO.setWasherId("washerID");
	    washerMetaDataDTO.setName("washerName");
	    washerMetaDataDTO.setLoad(50);
	    washerMetaDataDTO.setCreatedBy("createdBy");
	    washerMetaDataDTO.setCreatedDate("createdDate");
	    washerList.add(washerMetaDataDTO);
	    equipment.setWasherList(washerList);
	    equipment.setWasherCount(washerList.size());
	    List<TunnelDTO> tunnelList = new LinkedList<>();
	    TunnelDTO tunnelDTO = new TunnelDTO();
	    tunnelDTO.setName("tunnelName");
	    tunnelDTO.setTunnelId("TunnelId");
	    tunnelDTO.setLoad(50);
	    tunnelDTO.setCreatedBy("createdBy");
	    tunnelDTO.setCreatedDate("date");
	    tunnelList.add(tunnelDTO);
	    tunnelDTO = new TunnelDTO();
	    tunnelDTO.setName("tunnelName");
	    tunnelDTO.setTunnelId("TunnelId");
	    tunnelDTO.setLoad(50);
	    tunnelDTO.setCreatedBy("createdBy");
	    tunnelDTO.setCreatedDate("date");
	    tunnelList.add(tunnelDTO);
	    tunnelDTO = new TunnelDTO();
	    tunnelDTO.setName("tunnelName");
	    tunnelDTO.setTunnelId("TunnelId");
	    tunnelDTO.setLoad(50);
	    tunnelDTO.setCreatedBy("createdBy");
	    tunnelDTO.setCreatedDate("date");
	    tunnelList.add(tunnelDTO);
	    tunnelDTO = new TunnelDTO();
	    tunnelDTO.setName("tunnelName");
	    tunnelDTO.setTunnelId("TunnelId");
	    tunnelDTO.setLoad(50);
	    tunnelDTO.setCreatedBy("createdBy");
	    tunnelDTO.setCreatedDate("date");
	    tunnelList.add(tunnelDTO);
	    equipment.setTunnelList(tunnelList);
	    equipment.setTunnelCount(tunnelList.size());
	    equipmentList.add(equipment);

	    equipment = new EquipmentDTO();
	    equipment.setEquipmentId("EquipmentID1");
	    equipment.setAlias("EquipmentName");
	    equipment.setCreatedBy("createdBy");
	    equipment.setCreatedDate("date");
	    equipment.setEquipmentType("equipmentType");
	    pumpList = new LinkedList<>();
	    equipmentPumpDTO = new EquipmentPumpDTO();
	    equipmentPumpDTO.setPumpId("pumpId");
	    equipmentPumpDTO.setPumpName("pumpName1");
	    equipmentPumpDTO.setPumpValue("value");
	    pumpList.add(equipmentPumpDTO);
	    equipment.setEquipmentPumpList(pumpList);
	    equipmentFormulaList = new LinkedList<>();
	    equipmentFormulaDTO = new EquipmentFormulaDTO();
	    equipmentFormulaDTO.setFormulaId("FormulaID");
	    equipmentFormulaDTO.setFormulaName("formulaName");
	    equipmentFormulaDTO.setFormulaValue("formulaValue");
	    equipmentFormulaList.add(equipmentFormulaDTO);
	    equipment.setEquipmentFormulaList(equipmentFormulaList);
	    equipment.setFormulaCount(formulaList.size());
	    pumpMachineriesList = new LinkedList<>();
	    pumpMachinery = new EquipmentPumpMachinery();
	    pumpMachinery.setPumpMachineId("pumpMachId");
	    pumpMachinery.setPumpMachineName("pumpMachineName");
	    pumpMachinery.setPumpMachineValue("MachValues");
	    pumpMachineriesList.add(pumpMachinery);
	    equipment.setEquipmentPumpMachineriesList(pumpMachineriesList);
	    productList = new LinkedList<>();
	    productDTO = new ProductDTO();
	    productDTO.setProductId("productId");
	    productDTO.setName("name");
	    productDTO.setPrice("price");
	    productDTO.setKf("kf");
	    productDTO.setDensity("density");
	    productDTO.setConcentration(10);
	    productDTO.setFrequency("frequency");
	    productDTO.setCalibration("calibration");
	    productList.add(productDTO);
	    equipment.setProductList(productList);
	    equipment.setProductCount(productList.size());
	    formulaList = new LinkedList<>();
	    formulaMetaDataDTO = new FormulaMetaDataDTO();
	    formulaMetaDataDTO.setFormulaId("formulaId");
	    formulaMetaDataDTO.setName("formulaName");
	    formulaMetaDataDTO.setPhases("phases");
	    formulaList.add(formulaMetaDataDTO);
	    equipment.setFormulaList(formulaList);
	    washerList = new LinkedList<>();
	    washerMetaDataDTO = new WasherMetaDataDTO();
	    washerMetaDataDTO.setWasherId("washerID");
	    washerMetaDataDTO.setName("washerName");
	    washerMetaDataDTO.setLoad(50);
	    washerMetaDataDTO.setCreatedBy("createdBy");
	    washerMetaDataDTO.setCreatedDate("createdDate");
	    washerList.add(washerMetaDataDTO);
	    washerMetaDataDTO = new WasherMetaDataDTO();
	    washerMetaDataDTO.setWasherId("washerID");
	    washerMetaDataDTO.setName("washerName");
	    washerMetaDataDTO.setLoad(50);
	    washerMetaDataDTO.setCreatedBy("createdBy");
	    washerMetaDataDTO.setCreatedDate("createdDate");
	    washerList.add(washerMetaDataDTO);
	    washerMetaDataDTO = new WasherMetaDataDTO();
	    washerMetaDataDTO.setWasherId("washerID");
	    washerMetaDataDTO.setName("washerName");
	    washerMetaDataDTO.setLoad(50);
	    washerMetaDataDTO.setCreatedBy("createdBy");
	    washerMetaDataDTO.setCreatedDate("createdDate");
	    washerList.add(washerMetaDataDTO);
	    washerMetaDataDTO = new WasherMetaDataDTO();
	    washerMetaDataDTO.setWasherId("washerID");
	    washerMetaDataDTO.setName("washerName");
	    washerMetaDataDTO.setLoad(50);
	    washerMetaDataDTO.setCreatedBy("createdBy");
	    washerMetaDataDTO.setCreatedDate("createdDate");
	    washerList.add(washerMetaDataDTO);
	    equipment.setWasherList(washerList);
	    equipment.setWasherCount(washerList.size());
	    tunnelList = new LinkedList<>();
	    tunnelDTO = new TunnelDTO();
	    tunnelDTO.setName("tunnelName");
	    tunnelDTO.setTunnelId("TunnelId");
	    tunnelDTO.setLoad(50);
	    tunnelDTO.setCreatedBy("createdBy");
	    tunnelDTO.setCreatedDate("date");
	    tunnelList.add(tunnelDTO);
	    tunnelDTO = new TunnelDTO();
	    tunnelDTO.setName("tunnelName");
	    tunnelDTO.setTunnelId("TunnelId");
	    tunnelDTO.setLoad(50);
	    tunnelDTO.setCreatedBy("createdBy");
	    tunnelDTO.setCreatedDate("date");
	    tunnelList.add(tunnelDTO);
	    tunnelDTO = new TunnelDTO();
	    tunnelDTO.setName("tunnelName");
	    tunnelDTO.setTunnelId("TunnelId");
	    tunnelDTO.setLoad(50);
	    tunnelDTO.setCreatedBy("createdBy");
	    tunnelDTO.setCreatedDate("date");
	    tunnelList.add(tunnelDTO);
	    tunnelDTO = new TunnelDTO();
	    tunnelDTO.setName("tunnelName");
	    tunnelDTO.setTunnelId("TunnelId");
	    tunnelDTO.setLoad(50);
	    tunnelDTO.setCreatedBy("createdBy");
	    tunnelDTO.setCreatedDate("date");
	    tunnelList.add(tunnelDTO);
	    equipment.setTunnelList(tunnelList);
	    equipment.setTunnelCount(tunnelList.size());
	    equipmentList.add(equipment);
	    response.setSiteId("siteId");
	    response.setSiteName("siteName");
	    response.setSiteIPAddress("ip add");
	    response.setEquipmentList(equipmentList);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/washerProductionSummaryExcelReport")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response washerProductionSummaryExcelReport(String body) throws Exception {
	long start = System.currentTimeMillis();
	StreamingOutput entity = null;
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);
	    entity = ((HydroReportsBL) BL).getExcelReportForProductionSummary(requestDTO);
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	    entity = ((HydroReportsBL) BL).errorResponse(resStr);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error : " + e.getMessage());
	    entity = ((HydroReportsBL) BL).errorResponse(Constants.ERROR_MESSAGE);
	}

	recordTime(start, resStr);
	return Response.ok(entity).header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=PRODUCTION_REPORT.xlsx")
		.type("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet").build();
    }

    @POST
    @Path("/chemicalSummaryExcelReport")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response chemicalSummaryExcelReport(String body) throws Exception {
	long start = System.currentTimeMillis();
	StreamingOutput entity = null;
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);
	    entity = ((HydroReportsBL) BL).getExcelReportForChemicalSummary(requestDTO);
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	    entity = ((HydroReportsBL) BL).errorResponse(resStr);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error : " + e.getMessage());
	    entity = ((HydroReportsBL) BL).errorResponse(Constants.ERROR_MESSAGE);
	}

	recordTime(start, resStr);
	return Response.ok(entity).header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=PRODUCTION_REPORT.xlsx")
		.type("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet").build();
    }

    @POST
    @Path("/costSummaryExcelReport")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response costSummaryExcelReport(String body) throws Exception {
	long start = System.currentTimeMillis();
	StreamingOutput entity = null;
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);
	    entity = ((HydroReportsBL) BL).getExcelReportForCostSummary(requestDTO);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	    entity = null;
	    entity = ((HydroReportsBL) BL).errorResponse(resStr);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error : " + e.getMessage());
	    entity = null;
	    entity = ((HydroReportsBL) BL).errorResponse(Constants.ERROR_MESSAGE);
	}

	recordTime(start, resStr);
	return Response.ok(entity).header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=PRODUCTION_REPORT.xlsx")
		.type("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet").build();
    }

    @POST
    @Path("/alarmSummaryExcelReport")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_OCTET_STREAM)
    public Response alarmSummaryExcelReport(String body) throws Exception {
	long start = System.currentTimeMillis();
	StreamingOutput entity = null;
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);
	    entity = ((HydroReportsBL) BL).getExcelReportForAlarmSummary(requestDTO);

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	    entity = ((HydroReportsBL) BL).errorResponse(resStr);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error : " + e.getMessage());
	    entity = ((HydroReportsBL) BL).errorResponse(Constants.ERROR_MESSAGE);
	}

	recordTime(start, resStr);
	return Response.ok(entity).header(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=PRODUCTION_REPORT.xlsx")
		.type("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet").build();
    }

    
    
    
    @POST
    @Path("/realTimeReport")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String realTimeReport(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    DailyReportRequestDTO requestDTO = (DailyReportRequestDTO) ServiceHelper.buildJsonString(body,
		    DailyReportRequestDTO.class);
	    DailyReportResponseDTO response = ((HydroReportsBL) BL).generateRealTimeReport(requestDTO);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/dayWiseHistoricalReport")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String dayWiseHistoricalReport(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    DailyReportRequestDTO requestDTO = (DailyReportRequestDTO) ServiceHelper.buildJsonString(body,
		    DailyReportRequestDTO.class);
	    DailyReportResponseDTO response = ((HydroReportsBL) BL).generateDayWiseHistoricalReport(requestDTO);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * 
     * 
     * @param body
     * @return
     * @throws Exception
     */

    @POST
    @Path("/washerProductionSummaryAvgForPrevMonth")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String washerProductionSummaryThreeMonthAvg(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);
	    WasherProductionDTO response = ((HydroReportsBL) BL).washerProductionSummaryAvgForPrevMonth(requestDTO);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/costSummaryAvgForPrevMonth")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String costSummaryAvgForPrevMonth(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);
	    CostSummaryDTO response = ((HydroReportsBL) BL).costSummaryAvgForPrevMonth(requestDTO);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/chemicalSummaryAvgForPrevMonth")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String chemicalSummaryAvgForPrevMonth(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    ReportRequestDTO requestDTO = (ReportRequestDTO) ServiceHelper.buildJsonString(body,
		    ReportRequestDTO.class);
	    ChemicalSummaryDTO response = ((HydroReportsBL) BL).chemicalSummaryAvgForPrevMonth(requestDTO);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
		LOG.error(e.getMessage());
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
		e.printStackTrace();
	} catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
				ErrorCodes.StatusCodes.FAILURE, null);
		resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

  
}
