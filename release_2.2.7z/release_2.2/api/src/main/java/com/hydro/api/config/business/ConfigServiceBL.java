package com.hydro.api.config.business;

import java.util.Map;
import javax.ws.rs.WebApplicationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.google.gson.Gson;
import com.hydro.api.base.business.HydroBL;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.dto.ResponseStatusDTO;

public class ConfigServiceBL extends HydroBL {

    private static Logger LOG = LoggerFactory.getLogger(ConfigServiceBL.class);

    private Gson gson = new Gson();

    public ConfigServiceBL(String userId, String timeZone) {
	super(userId, timeZone);
    }

    /**
     * 
     * @param deviceId
     * 
     */

    public ResponseStatusDTO updateDeviceCache(String body) throws Exception {
	ResponseStatusDTO responseEntity = new ResponseStatusDTO();

	try {

	    ConfigReader configReader = ConfigReader.getObject();

	    Map<Object, Object> requestQuery = gson.fromJson(body, Map.class);

	    String action = (String) requestQuery.get("action");
	    String deviceId = (String) requestQuery.get("deviceId");
	    if (deviceId != null && deviceId.trim().isEmpty())
		deviceId = null;

	    if (action == null || action.trim().isEmpty() || (!action.equalsIgnoreCase("CREATE")
		    && !action.equalsIgnoreCase("UPDATE") && !action.equalsIgnoreCase("DELETE"))) {
		LOG.error("Bad request entity - ACTION missing or unsupported.");
		responseEntity.setResponseStatus("400");
		responseEntity.setMessage("Bad request entity - ACTION missing or unsupported.");
		return responseEntity;
	    }
	    if (action.equalsIgnoreCase("CREATE")) {
		if (deviceId == null) {
		    LOG.error("Bad request entity - Device Id cannot be missing for CREATE ACTION.");
		    responseEntity.setResponseStatus("400");
		    responseEntity.setMessage("Bad request entity - Device Id cannot be missing for CREATE ACTION.");
		    return responseEntity;
		}
		configReader.updateDeviceCache(deviceId, false);
	    } else if (action.equalsIgnoreCase("UPDATE")) {

		configReader.updateDeviceCache(deviceId, true);

	    } else if (action.equalsIgnoreCase("DELETE")) {

		if (deviceId == null) {
		    LOG.error("Bad request entity - Device Id cannot be missing for DELETE ACTION.");
		    responseEntity.setResponseStatus("400");
		    responseEntity.setMessage("Bad request entity - Device Id cannot be missing for DELETE ACTION.");
		    return responseEntity;
		}

		configReader.deleteDeviceFromCache(deviceId);
	    }

	    responseEntity.setResponseStatus("200");
	    responseEntity.setMessage(action + " successful.");
	} catch (WebApplicationException wae) {
	    responseEntity.setResponseStatus(Integer.toString(wae.getResponse().getStatus()));
	    responseEntity.setMessage(wae.getMessage());
	}
	return responseEntity;
    }
}
