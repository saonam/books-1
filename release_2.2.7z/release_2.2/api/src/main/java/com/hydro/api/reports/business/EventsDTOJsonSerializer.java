package com.hydro.api.reports.business;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.hydro.api.dto.reports.EventsDTO;

public class EventsDTOJsonSerializer implements JsonSerializer<EventsDTO> {

    @Override
    public JsonElement serialize(EventsDTO event, Type typeOfSrc, JsonSerializationContext context) {
	JsonObject jsonObj = new JsonObject();
	jsonObj.add("productName", context.serialize(event.getProductName()));
	jsonObj.add("productId", context.serialize(event.getProductId()));
	if(event.getCost() != null) {
	    jsonObj.add("cost", context.serialize(event.getCost()));
	}
	jsonObj.add("timeEstimated", context.serialize(event.getTimeEstimated()));
	jsonObj.add("timeActual", context.serialize(event.getTimeActual()));
	jsonObj.add("eventType", context.serialize(event.getEventType()));
	jsonObj.add("eventStartTime", context.serialize(event.getEventStartTime()));
	if(event.getModule() != null) {
	    jsonObj.add("module", context.serialize(event.getModule()));
	}
	if(event.getPhase()!=null) {
	    jsonObj.add("phase", context.serialize(event.getPhase()));
	}
	jsonObj.add("mlReal", context.serialize(event.getMl()));
	jsonObj.add("mlEstimated", context.serialize(event.getMlEstimated()));
	return jsonObj;
    }

}
