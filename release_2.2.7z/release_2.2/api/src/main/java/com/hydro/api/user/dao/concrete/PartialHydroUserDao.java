package com.hydro.api.user.dao.concrete;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;

public class PartialHydroUserDao extends HydroUserDao {

	private static final Logger LOG = LoggerFactory.getLogger(PartialHydroUserDao.class);

	@Override
	public boolean deActivateUser(UserDTO user, UserDTO userDTO) throws Exception {
		throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
				ErrorCodes.StatusCodes.FORBIDDEN, null);
	}

	@Override
	public boolean activateUser(UserDTO user, UserDTO userDTO) throws Exception {
		throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
				ErrorCodes.StatusCodes.FORBIDDEN, null);
	}

	public UserDTO createUser(UserDTO user, UserDTO userDTO, boolean fullPrivilege) throws Exception {
		throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
				ErrorCodes.StatusCodes.FORBIDDEN, null);
	}

	public boolean updateUser(UserDTO user, UserDTO userDTO, boolean fullPrivilege) throws Exception {
		throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
				ErrorCodes.StatusCodes.FORBIDDEN, null);
	}

	public boolean hasVisibility(UserDTO user, UserDTO userDTO) throws Exception {
		if (!user.getAssociationId().equals(userDTO.getAssociationId())) {
			return false;
		}
		return true;
	}

}
