package com.hydro.api.base.common;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.TokenDTO;
import com.hydro.api.exception.SystemException;

public class TokenCache {

    private static final Logger LOG = LoggerFactory.getLogger(TokenCache.class);

    private HashMap<String, HashMap<String, TokenDTO>> tokenMap = null;

    public TokenCache() {
	tokenMap = new HashMap<String, HashMap<String, TokenDTO>>();
    }

    /**
     * Check whether the token exists in server cache, if exists invalid.
     * 
     * @param userId
     * @param token
     * @throws Exception
     */
    public boolean isValidToken(String userId, String token) throws Exception {
	try {
	    HashMap<String, TokenDTO> cache = tokenMap.get(userId);
	    if (cache != null && cache.get(token) != null) {
		return false;
	    }
	} catch (Exception e) {
	    LOG.error("Invalid JWT through logout" + e.getMessage());
	    return false;
	} finally {
	    removeExpiredTokenFromCache(userId);
	}
	return true;
    }

    /**
     * Add token to cache with userId as key. If userId already exists, add to
     * same entry. If not, create new entry with userId and values.
     * 
     * @param token
     * @param userId
     * @param expiry
     * @throws Exception
     */
    public void addTokenToCache(String token, String userId, long exp) throws Exception {
	try {
	    if (!isValidToken(userId, token)) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	    HashMap<String, TokenDTO> user = tokenMap.get(userId);
	    if (user != null) {
		TokenDTO dto = new TokenDTO();
		dto.setExpiry(exp);
		user.put(token, dto);
	    } else {
		HashMap<String, TokenDTO> map = new HashMap<String, TokenDTO>();
		TokenDTO dto = new TokenDTO();
		dto.setExpiry(exp);
		map.put(token, dto);
		tokenMap.put(userId, map);
	    }
	} catch (Exception e) {
	    LOG.error("Error while adding token to server cache" + e.getMessage());
	} finally {
	    removeExpiredTokenFromCache(userId);
	}
    }

    /**
     * Check the token got expired or not, if expired remove from server cache.
     *
     * @param userId
     * @throws Exception
     */
    private void removeExpiredTokenFromCache(String userId) {

	try {
	    ZonedDateTime utc = ZonedDateTime.now(ZoneOffset.UTC);
	    long currentTime = utc.toEpochSecond();
	    HashMap<String, TokenDTO> user = tokenMap.get(userId);
	    if (user != null && !user.isEmpty()) {
		for (Entry<String, TokenDTO> e : user.entrySet()) {
		    int tokenCacheBufferTime = 0;
		    try {
			ConfigReader config = ConfigReader.getObject();
			String buffer = config.getAppConfig(Constants.TOKEN_CACHE_BUFFER_TIME);
			tokenCacheBufferTime = Integer.parseInt(buffer);
		    } catch (Exception e1) {
			LOG.error("Invalid TOKEN_CACHE_BUFFER_TIME config in application.properties" + e1.getMessage());
		    }
		    long expiryTime = e.getValue().getExpiry() + tokenCacheBufferTime;
		    if (expiryTime <= currentTime) {
			user.remove(e.getKey());
			if (user.isEmpty()) {
			    tokenMap.remove(userId);
			}
		    }
		}
	    }
	} catch (Exception e) {
	    LOG.error("Error while removing expired token from server cache" + e);
	}
    }
}
