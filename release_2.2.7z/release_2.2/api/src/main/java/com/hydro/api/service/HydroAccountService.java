package com.hydro.api.service;

import java.security.Principal;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.account.business.HydroAccountBL;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.AccountDTO;
import com.hydro.api.dto.AccountListResponseDTO;
import com.hydro.api.dto.StatusDTO;
import com.hydro.api.exception.ExceptionHandler;
import com.hydro.api.exception.SystemException;
import com.hydro.api.service.helper.ServiceHelper;

/**
 * Base Service : Entry Point to the JSON APIs.
 * 
 * @author Shreyas
 *
 */
// No Base context root for the Services. Each services have their respective
// Endpoints.
@Path("/account")
@Produces({ MediaType.APPLICATION_JSON })
public class HydroAccountService extends HydroBaseService {
    private static final Logger LOG = LoggerFactory.getLogger(HydroAccountService.class);

    public HydroAccountService(@Context SecurityContext securityContext,
	    @HeaderParam(Constants.TIME_ZONE_HEADER) String timeZone) throws Exception {
	super();
	Principal principal = securityContext.getUserPrincipal();
	String username = principal.getName();
	BL = new HydroAccountBL(username, timeZone);
    }

    /**
     * Test API.
     * 
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/test")
    public String test() {
	long start = System.currentTimeMillis();
	resStr = "{\"messgae\":\"Account APIs Works Fine!\"}";
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * Testing the DB connection.
     * 
     * @return
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/testDbConnection")
    public String testDbConnection() {
	long start = System.currentTimeMillis();

	try {
	    BL.initRoutine();
	    // Check for the Database connection.
	    boolean flag = ((HydroAccountBL) BL).testAccountDbConnection();
	    if (flag) {
		resStr = "{ \"connected\":true}";
	    } else {
		resStr = "{ \"connected\":false}";
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @GET
    @Path("/getAccountList")
    @Produces(MediaType.APPLICATION_JSON)

    public String getAccountList(@QueryParam("createdStartDate") String createdStartDate,
	    @QueryParam("createdEndDate") String createdEndDate, @QueryParam("sortByName") boolean sortByName)
	    throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    AccountDTO account = new AccountDTO(sortByName, createdEndDate, createdStartDate);
	    AccountListResponseDTO aResponse = ((HydroAccountBL) BL).getAccountList(account);
	    responseDTO.setResponseObject(aResponse);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/getAccountDetails")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getAccountDetails(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    AccountDTO accountDTO = (AccountDTO) ServiceHelper.buildJsonString(body, AccountDTO.class);
	    accountDTO = ((HydroAccountBL) BL).getAccountDetails(accountDTO);
	    responseDTO.setResponseObject(accountDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/accountNameExists")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String accountNameExists(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    AccountDTO accountDTO = (AccountDTO) ServiceHelper.buildJsonString(body, AccountDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroAccountBL) BL).accountNameExists(accountDTO));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/createAccount")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String createAccount(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    AccountDTO accountDTO = (AccountDTO) ServiceHelper.buildJsonString(body, AccountDTO.class);
	    accountDTO = ((HydroAccountBL) BL).createAccount(accountDTO);
	    responseDTO.setResponseObject(accountDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @PUT
    @Path("/updateAccount")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String updateAccount(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    AccountDTO accountDTO = (AccountDTO) ServiceHelper.buildJsonString(body, AccountDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroAccountBL) BL).updateAccount(accountDTO));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

}
