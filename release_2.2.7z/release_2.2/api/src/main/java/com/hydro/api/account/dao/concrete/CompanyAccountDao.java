package com.hydro.api.account.dao.concrete;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.account.dao.AccountDao;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.AccountDTO;
import com.hydro.api.dto.AccountListResponseDTO;
import com.hydro.api.dto.ContactDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;

/**
 *
 * @author Shreyas
 * 
 */
public class CompanyAccountDao extends AccountDao {
    private static final Logger LOG = LoggerFactory.getLogger(CompanyAccountDao.class);

    @Override
    public AccountListResponseDTO getAccountList(UserDTO user, AccountDTO account) throws SystemException, Exception {
	Database database = null;
	try {
	    database = new Database();
	    String query = SQLConstants.Company.full.GET_ACCOUNT_LIST;
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.BusinessTypes.ACCOUNT);
	    params.add(user.getAssociationId());
	    if (account.getCreatedDateStart() != null && account.getCreatedDateEnd() != null) {
		query = SQLConstants.Company.full.GET_ACCOUNT_LIST_CREATED_DATE_FILTER;
		params.addAll(getAccountListOnStartEndDate(account));
	    } else if (account.isSortByName()) {
		query = SQLConstants.Company.full.GET_ACCOUNT_LIST_SORTED_ON_NAME;
	    }
	    LOG.debug("query>>>>" + query);
	    return getAccountListData(database.executeQuery(query, params), user.getTimeZone());
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean hasVisibility(UserDTO user, AccountDTO accountDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.full.GET_ACCOUNT_ASSOCIATION_ID;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.BusinessTypes.ACCOUNT);
	    params.add(accountDTO.getAccountId());
	    params.add(user.getAssociationId());
	    ResultSet rSet = database.executeQuery(query, params);
	    if (rSet.next()) {
		return true;
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public List<SiteDTO> getSiteListForAccount(UserDTO user, AccountDTO accountDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.Company.full.GET_SITES_FOR_ACCOUNT;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(accountDTO.getAccountId());
	    params.add(user.getAssociationId());
	    database = new Database();
	    return getAccountSiteData(database.executeQuery(query, params));
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean updateAccount(UserDTO user, AccountDTO accountDTO) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    @Override
    public String accountNameExists(AccountDTO accountDTO) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    @Override
    public List<ContactDTO> getContactListForAccount(AccountDTO account) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    @Override
    public AccountDTO createAccount(UserDTO user, AccountDTO accountDTO) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }
}
