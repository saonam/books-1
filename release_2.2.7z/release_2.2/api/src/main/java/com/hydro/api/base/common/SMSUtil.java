package com.hydro.api.base.common;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.constants.Constants;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class SMSUtil {
    private static final Logger LOG = LoggerFactory.getLogger(SMSUtil.class);

    public static void sendSMS(String phoneNum, String smsMessage) {
	try {
	    ConfigReader config = ConfigReader.getObject();
	    String accountSid = config.getAppConfig(Constants.SMS_ACCOUNT_SID);
	    String authToken = config.getAppConfig(Constants.SMS_AUTH_TOKEN);
	    String fromPhone = config.getAppConfig(Constants.SMS_HYDRO_PHONE_NUMBER);

	    LOG.debug("SMSUtil:" + accountSid + ":" + authToken + ":" + fromPhone);

	    if (accountSid != null && !accountSid.isEmpty() && authToken != null && !authToken.isEmpty()
		    && fromPhone != null && !fromPhone.isEmpty()) {
		Twilio.init(accountSid, authToken);
		Message message = Message.creator(new PhoneNumber(phoneNum), new PhoneNumber(fromPhone), smsMessage)
			.create();
	    } else {
		LOG.error("Failed to send SMS due to missing configuration.");
	    }

	    // LOG.debug("SMS sent to :" + phoneNum + " SID :" +
	    // message.getSid());

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    LOG.error("Error : " + e.getMessage());
	}
    }
}
