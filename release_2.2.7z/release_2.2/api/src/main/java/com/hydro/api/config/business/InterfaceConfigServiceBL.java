package com.hydro.api.config.business;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.config.ChannelDTO;
import com.hydro.api.config.ConfigExtractionRule;
import com.hydro.api.config.ConfigurationDTO;
import com.hydro.api.config.EquipmentConfigDTO;
import com.hydro.api.config.FormulaDTO;
import com.hydro.api.config.FormulaPhaseDTO;
import com.hydro.api.config.FormulaProductDTO;
import com.hydro.api.config.LaundryDTO;
import com.hydro.api.config.MachineDTO;
import com.hydro.api.config.ProductConfigDTO;
import com.hydro.api.config.UnitDTO;
import com.hydro.api.config.WaterDTO;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.reports.DataRequestDTO;
import com.hydro.api.exception.SystemException;

public class InterfaceConfigServiceBL {

    private static final Logger LOG = LoggerFactory.getLogger(InterfaceConfigServiceBL.class);

    private static final SimpleDateFormat dateFormat = new SimpleDateFormat(
	    Constants.DATE_TIME_FORMAT.REPORT_DATE_FORMAT);
    private static final SimpleDateFormat datetimeFormat = new SimpleDateFormat(Constants.DATE_TIME_FORMAT.DATE_FORMAT);

    private static InterfaceConfigServiceBL service;

    private InterfaceConfigServiceBL() {

    }

    public static InterfaceConfigServiceBL getInstance() {
	if (service == null) {
	    service = new InterfaceConfigServiceBL();
	}
	return service;
    }

    public ConfigurationDTO getConfiguration(DataRequestDTO requestDto) throws Exception {
	
	List<Object> params = getInsufficientParamsDaywiseHistoricalReport(requestDto);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	
	LinkedList<Object> parameters = new LinkedList<>();
	parameters.add(requestDto.getSiteId());
	Database database = new Database();
	try {
	    ConfigurationDTO configuration = new ConfigurationDTO();
//	    configuration.setData_source(Constants.DataSource.UNIT);
//	    configuration.setData_type(Constants.DataType.CONFIG);

	 // Get site details
	    Map<String, Object> laundry = getSiteDetail(parameters, database, requestDto.getSiteId());
	    configuration.setSite(laundry);

	    List<Map<String, Object>> units = getUnitsDetail(parameters, database);

	    List<EquipmentConfigDTO> equipments = new LinkedList<>();
	    configuration.setUnits(equipments);

	    // Iterate over the list to populate the config attributes
	    for (Map<String, Object> unit : units) {
		EquipmentConfigDTO equipment = new EquipmentConfigDTO();
		equipment.setEquipment(unit);

		parameters.clear();
		parameters.add(unit.get(UnitDTO.EQUIPMENT_ID));

		List<Map<String,Object>> channels = getChannelsDetail(parameters, database);
		equipment.setNum_channels(CollectionUtils.size(channels));
		equipment.setChannels(channels);

		List<Map<String,Object>> waters = getWatersDetail(parameters, database);
		equipment.setWater(waters);

		List<Map<String,Object>> products = getProductsDetail(parameters, database);
		equipment.setNum_products(CollectionUtils.size(products));
		equipment.setProducts(products);

		if (Constants.EquipmentType.TUNNEL.equals(unit.get(UnitDTO.UNIT_TYPE))) {
		    List<Map<String, Object>> machines = getTunnelsDetail(parameters, database);
		    equipment.setNum_machines(machines.size());
		    equipment.setMachines(machines);
		} else if (Constants.EquipmentType.WASHER_EXTRACTOR.equals(unit.get(UnitDTO.UNIT_TYPE))) {
		    List<Map<String, Object>> machines = getWashersDetail(parameters, database);
		    equipment.setNum_machines(machines.size());
		    equipment.setMachines(machines);
		}

		List<Map<String,Object>> formulas = getFormulasDetail(parameters, database);
		equipment.setFormulas(formulas);
		equipment.setNum_formulas(formulas.size());

		for (Map<String,Object> formula : formulas) {
		    parameters.clear();
		    parameters.add(unit.get(UnitDTO.EQUIPMENT_ID));
		    parameters.add(formula.get(FormulaDTO.ID));

		    List<Map<String,Object>> phases = getFormulaPhasesDetail(parameters, database);
		    formula.put(FormulaDTO.FORMULAS_PHASES, phases);

		    for (Map<String,Object> phase : phases) {
			parameters.clear();
			parameters.add(phase.get(FormulaPhaseDTO.F_PHASE_ID));

			List<Map<String,Object>> dosages = getFormulaProductsDetail(parameters, database);
			phase.put(FormulaPhaseDTO.PRODUCTS, dosages);

			phase.remove(FormulaPhaseDTO.F_PHASE_ID);
		    }
		    formula.remove(FormulaDTO.ID);
		}

		equipments.add(equipment);
	    }

	    return configuration;
	} finally {
	    if (database != null) {
		database.closeConnection();
	    }
	}
    }

    public Map<String, Object> getSiteDetail(LinkedList<Object> parameters, Database database, String siteId)
	    throws Exception {

	ResultSet result = null;
	Map<String, Object> entity = LaundryDTO.fetchRule.getContainer();
	try {
	    result = database.executeQuery(SQLConstants.GET_LAUNDRY_DETAIL, parameters);

	    if (!result.first()) {
		throw new SystemException(ErrorCodes.BAD_REQUEST, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST,
			String.format("Data not available for site id : %s", siteId));
	    }

	    populateEntity(entity, result, LaundryDTO.fetchRule);
	} finally {
	    if (result != null && !result.isClosed()) {
		result.close();
	    }
	}
	return entity;
    }

    public List<Map<String, Object>> getUnitsDetail(LinkedList<Object> parameters, Database database) throws Exception {
	List<Map<String, Object>> units = new LinkedList<>();
	ResultSet result = null;
	try {
	    result = database.executeQuery(SQLConstants.GET_UNITS_DETAIL, parameters);

	    while (result.next()) {
		Map<String, Object> unit = UnitDTO.unitFetchRule.getContainer();
		populateEntity(unit, result, UnitDTO.unitFetchRule);

		units.add(unit);
	    }
	} catch (SQLException sqle) {
	    // TODO : exception handling
	    throw new SystemException(sqle, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while querying for site_master details"));
	} catch (Exception e) {
	    // TODO : exception handling
	    throw new SystemException(e, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while getting site details."));
	} finally {
	    if (result != null && !result.isClosed()) {
		result.close();
	    }
	}

	return units;
    }

    public List<Map<String, Object>> getChannelsDetail(LinkedList<Object> parameters, Database database)
	    throws SystemException, Exception {
	List<Map<String, Object>> channels = new LinkedList<>();

	ResultSet result = null;
	try {
	    result = database.executeQuery(SQLConstants.GET_CHANNELS_DETAIL, parameters);

	    while (result.next()) {
		Map<String, Object> channel = ChannelDTO.channelFetchRule.getContainer();
		populateEntity(channel, result, ChannelDTO.channelFetchRule);

		channels.add(channel);
	    }
	} catch (SQLException sqle) {
	    // TODO : exception handling
	    throw new SystemException(sqle, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while querying for channel_master details"));
	} catch (Exception e) {
	    // TODO : exception handling
	    throw new SystemException(e, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while getting channel details."));
	} finally {
	    if (result != null && !result.isClosed()) {
		result.close();
	    }
	}

	return channels;
    }

    public List<Map<String,Object>> getWatersDetail(LinkedList<Object> parameters, Database database)
	    throws SystemException, Exception {
	List<Map<String,Object>> waters = new LinkedList<>();
	ResultSet result = null;
	try {
	    result = database.executeQuery(SQLConstants.GET_WATERS_DETAIL, parameters);
	    
	    while (result.next()) {
		Map<String,Object> water = WaterDTO.waterFetchRule.getContainer();
		populateEntity(water, result, WaterDTO.waterFetchRule);

		waters.add(water);
	    }
	} catch (SQLException sqle) {
	    // TODO : exception handling
	    throw new SystemException(sqle, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while querying for water_master details"));
	} catch (Exception e) {
	    // TODO : exception handling
	    throw new SystemException(e, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while getting water details."));
	} finally {
	    if (result != null && !result.isClosed()) {
		result.close();
	    }
	}

	return waters;
    }

    public List<Map<String,Object>> getProductsDetail(LinkedList<Object> parameters, Database database)
	    throws SystemException, Exception {
	List<Map<String,Object>> products = new LinkedList<>();
	ResultSet result = null;
	try {
	    result = database.executeQuery(SQLConstants.GET_PRODUCTS_DETAIL, parameters);
	    
	    while (result.next()) {
		Map<String,Object> product = ProductConfigDTO.productFetchRule.getContainer();
		populateEntity(product, result, ProductConfigDTO.productFetchRule);

		products.add(product);
	    }
	} catch (SQLException sqle) {
	    // TODO : exception handling
	    throw new SystemException(sqle, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while querying for product_master details"));
	} catch (Exception e) {
	    // TODO : exception handling
	    throw new SystemException(e, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while getting product details."));
	} finally {
	    if (result != null && !result.isClosed()) {
		result.close();
	    }
	}

	return products;
    }

    public List<Map<String, Object>> getTunnelsDetail(LinkedList<Object> parameters, Database database)
	    throws SystemException, Exception {
	List<Map<String, Object>> machines = new LinkedList<>();
	ResultSet result = null;
	try {
	    result = database.executeQuery(SQLConstants.GET_TUNNELS_DETAIL, parameters);

	    while (result.next()) {
		Map<String, Object> machine = MachineDTO.tunnelFetchRule.getContainer();
		populateEntity(machine, result, MachineDTO.tunnelFetchRule);

		machines.add(machine);
	    }
	} catch (SQLException sqle) {
	    // TODO : exception handling
	    throw new SystemException(sqle, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while querying for tunnel_master details"));
	} catch (Exception e) {
	    // TODO : exception handling
	    throw new SystemException(e, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while getting tunnel details."));
	} finally {
	    if (result != null && !result.isClosed()) {
		result.close();
	    }
	}

	return machines;
    }

    public List<Map<String, Object>> getWashersDetail(LinkedList<Object> parameters, Database database)
	    throws SystemException, Exception {
	List<Map<String, Object>> machines = new LinkedList<>();
	ResultSet result = null;
	try {
	    result = database.executeQuery(SQLConstants.GET_WASHERS_DETAIL, parameters);

	    while (result.next()) {
		Map<String, Object> machine = MachineDTO.washerFetchRule.getContainer();
		populateEntity(machine, result, MachineDTO.washerFetchRule);

		machines.add(machine);
	    }
	} catch (SQLException sqle) {
	    // TODO : exception handling
	    throw new SystemException(sqle, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while querying for washer_master details"));
	} catch (Exception e) {
	    // TODO : exception handling
	    throw new SystemException(e, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while getting washer details."));
	} finally {
	    if (result != null && !result.isClosed()) {
		result.close();
	    }
	}

	return machines;
    }

    public List<Map<String,Object>> getFormulasDetail(LinkedList<Object> parameters, Database database)
	    throws SystemException, Exception {
	List<Map<String,Object>> formulas = new LinkedList<>();
	ResultSet result = null;
	try {
	    result = database.executeQuery(SQLConstants.GET_FORMULAS_DETAIL, parameters);
	    
	    while (result.next()) {
		Map<String,Object> formula = FormulaDTO.formulaFetchRule.getContainer();
		populateEntity(formula, result, FormulaDTO.formulaFetchRule);

		formulas.add(formula);
	    }
	} catch (SQLException sqle) {
	    // TODO : exception handling
	    throw new SystemException(sqle, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while querying for formula_master details"));
	} catch (Exception e) {
	    // TODO : exception handling
	    throw new SystemException(e, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while getting washer details."));
	} finally {
	    if (result != null && !result.isClosed()) {
		result.close();
	    }
	}

	return formulas;
    }

    public List<Map<String,Object>> getFormulaPhasesDetail(LinkedList<Object> parameters, Database database)
	    throws SystemException, Exception {
	List<Map<String,Object>> phases = new LinkedList<>();
	ResultSet result = null;
	try {
	    result = database.executeQuery(SQLConstants.GET_FORMULA_PHASES_DETAIL, parameters);

	    while (result.next()) {
		Map<String,Object> phase = FormulaPhaseDTO.phaseFetchRule.getContainer();
		populateEntity(phase, result, FormulaPhaseDTO.phaseFetchRule);

		phases.add(phase);
	    }
	} catch (SQLException sqle) {
	    // TODO : exception handling
	    throw new SystemException(sqle, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while querying for formula_phases details"));
	} catch (Exception e) {
	    // TODO : exception handling
	    throw new SystemException(e, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while getting formula_phases details."));
	} finally {
	    if (result != null && !result.isClosed()) {
		result.close();
	    }
	}

	return phases;
    }

    public List<Map<String,Object>> getFormulaProductsDetail(LinkedList<Object> parameters, Database database)
	    throws SystemException, Exception {
	List<Map<String,Object>> products = new LinkedList<>();
	ResultSet result = null;
	try {
	    result = database.executeQuery(SQLConstants.GET_FORMULA_DOSAGES_DETAIL, parameters);
	    
	    while (result.next()) {
		Map<String,Object> product = FormulaProductDTO.doseFetchRule.getContainer();
		populateEntity(product, result, FormulaProductDTO.doseFetchRule);

		products.add(product);
	    }
	} catch (SQLException sqle) {
	    // TODO : exception handling
	    throw new SystemException(sqle, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while querying for formula_dosages details"));
	} catch (Exception e) {
	    // TODO : exception handling
	    throw new SystemException(e, ErrorCodes.INTERNAL_ERROR, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, String.format("Error while getting formula_dosages details."));
	} finally {
	    if (result != null && !result.isClosed()) {
		result.close();
	    }
	}

	return products;
    }

    private void populateEntity(Map<String, Object> entity, ResultSet rs, ConfigExtractionRule rule)
	    throws SQLException {

	ResultSetMetaData metadata = rs.getMetaData();
	int colCount = metadata.getColumnCount();

	// this block has to do with the order of properties
	if (ConfigExtractionRule.ResultOrder.CUSTOM_ORDER.equals(rule.getResultOrder())
		&& (rule.getIncluded() != null || rule.getIncluded().length > 0)) {
	    for (String key : rule.getIncluded()) {
		entity.put(key, StringUtils.EMPTY);
	    }
	}

	for (int i = 1; i <= colCount; i++) {
	    int colType = metadata.getColumnType(i);
	    String colName = metadata.getColumnName(i);
	    if (!isAddCandidate(colName, rule)) {
		continue;
	    }
	    String value = getValue(rs, colName, colType);

	    entity.put(rule.getAlias(colName), value);
	}
    }

    private boolean isAddCandidate(String colName, ConfigExtractionRule rule) {
	if (rule.getIncluded() == null) {
	    if (rule.getExcluded() == null) {
		return true;
	    } else {
		return !rule.isExcluded(colName);
	    }
	} else {
	    return rule.isIncluded(colName);
	}
    }

    private String getValue(ResultSet rs, String colName, int colType) throws SQLException {
	String value = null;
	switch (colType) {
	case Types.TINYINT:
	case Types.SMALLINT:
	case Types.INTEGER:
	    Integer i = rs.getInt(colName);
	    value = (i == null) ? StringUtils.EMPTY : StringUtils.defaultString(String.valueOf(i));
	    break;
	case Types.DOUBLE:
	case Types.FLOAT:
	case Types.DECIMAL:
	    Double d = rs.getDouble(colName);
	    value = (d == null) ? StringUtils.EMPTY : StringUtils.defaultString(String.valueOf(d));
	    break;
	case Types.VARCHAR:
	case Types.NVARCHAR:
	    value = StringUtils.defaultString(rs.getString(colName));
	    break;
	case Types.DATE:
	case Types.TIMESTAMP:
	    value = StringUtils.defaultString(rs.getString(colName));
	    break;
	default:
	    // TODO : throw exception : type not supported
	}
	return value;
    }

    private List<Object> getInsufficientParamsDaywiseHistoricalReport(DataRequestDTO reportRequest) {
	List<Object> params = new LinkedList<>();
	if (reportRequest == null) {
	    params.add(ErrorCodes.InsufficientParams.REPORT_REQUEST_OBJECT);
	    return params;
	}
	if (reportRequest.getSiteId() == null || StringUtils.isEmpty(reportRequest.getSiteId())) {
	    params.add(ErrorCodes.InsufficientParams.SITE_ID);
	}
	return params;
    }
}
