package com.hydro.api.event.business;

import static java.time.DayOfWeek.MONDAY;
import static java.time.DayOfWeek.SUNDAY;
import static java.time.temporal.TemporalAdjusters.nextOrSame;
import static java.time.temporal.TemporalAdjusters.previousOrSame;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.time.Clock;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.hydro.api.base.business.HydroBL;
import com.hydro.api.base.common.CommonConstants;
import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.base.common.SMSUtil;
import com.hydro.api.base.dao.Database;
import com.hydro.api.base.dao.ElasticSearchDAO;
import com.hydro.api.config.Config;
import com.hydro.api.config.FormulaMaster;
import com.hydro.api.config.MData;
import com.hydro.api.config.MachineMaster;
import com.hydro.api.config.ProductMaster;
import com.hydro.api.config.TData;
import com.hydro.api.config.UData;
import com.hydro.api.config.UnitMaster;
import com.hydro.api.config.WaterMaster;
import com.hydro.api.config.dao.ConfigDao;
import com.hydro.api.config.dao.ConfigDaoImpl;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.EventDTO;
import com.hydro.api.dto.FormulaMetaDataDTO;
import com.hydro.api.dto.ProductDTO;
import com.hydro.api.dto.ShiftDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.event.dao.EventDao;
import com.hydro.api.exception.SystemException;
import com.hydro.api.site.dao.SiteDao;

public class HydroEventBL extends HydroBL {
    private static final Logger LOG = LoggerFactory.getLogger(HydroEventBL.class);

    private Gson gson;
    private static HashMap<String, List<ProductDTO>> equipProdHm = new HashMap<>();

    public HydroEventBL() throws SystemException, Exception {
	super();
	LOG.debug("In Hydro Event BL.");
	hydroDao = new EventDao();
	GsonBuilder gsonBuilder = new GsonBuilder();
	gsonBuilder.serializeNulls();
	gson = gsonBuilder.create();
    }

    public boolean processEvent(EventDTO eventDTO) throws SystemException, Exception {
	List<Object> params = getInsufficientParamsList(eventDTO);
	if (params.size() > 0) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.BAD_REQUEST, params);
	}
	if (eventDTO.getDevice_id() != null || !StringUtils.isEmpty(eventDTO.getDevice_id())) {
	    String siteId = ConfigReader.getObject().getSiteIdUsingDeviceId(eventDTO.getDevice_id());
	    eventDTO.setSite_id(siteId);
	    EventDTO event = ((EventDao) hydroDao).getSiteDetails(siteId);
	    if (event.getAssociationId() == null) {
		LOG.error("Please associate a business to site");
		return true;
	    }
	    if (event.getAlertSetting() == 0) {
		LOG.error("site doesn't have alert-setting set to 'yes'. Hence, notification can't be sent.");
		return true;
	    }

	    eventDTO.setTimeZone(event.getTimeZone());
	    eventDTO.setSiteName(event.getSiteName());
	}

	// Handling alerts
	int alarm = eventDTO.getTipo_alarma();
	if (alarm != 0) {
	    // String siteId = eventDTO.getSite_id();
	    EquipmentDTO equipment = ((EventDao) hydroDao).getEquipmentDetail(eventDTO.getDevice_id());
	    if (equipment != null) {
		eventDTO.setUnit_name(equipment.getAlias());
	    }

	    Integer equipmentType = eventDTO.getEquipment_type();
	    if (equipmentType == Integer.parseInt(Constants.EquipmentType.TUNNEL)) {
		((EventDao) hydroDao).populateTunnelDetail(eventDTO);
	    }

	    if (Constants.REPORTS.OLD_ALARMS.get(alarm) != null) {
		try {
		    Map<String, List<String>> notifyMap = getSubscribersDetails(eventDTO);
		    String fecha = eventDTO.getFecha();
		    String eventDateTimeZone = LocalDateTime
			    .parse(fecha,
				    DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))
			    .atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.of(eventDTO.getTimeZone()))
			    .format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
		    // sendEmails
		    eventDTO.setFecha(eventDateTimeZone);
		    if (notifyMap.containsKey(SQLColumns.EMAIL)) {
			sendEmailNotifications(eventDTO, notifyMap.get(SQLColumns.EMAIL));
		    }
		    // sendSMSs
		    if (notifyMap.containsKey(SQLColumns.SMS)) {
			sendSMSNotifications(eventDTO, notifyMap.get(SQLColumns.SMS));
		    }

		} catch (Exception exp) {
		    LOG.error("Exception in processEvent::" + exp.getMessage());

		}

	    }

	}
	return true;
    }

    private HashMap<String, List<String>> getSubscribersDetails(EventDTO event) throws Exception {
	String siteId = event.getSite_id();
	int alarmId = event.getTipo_alarma();
	int equipmentSeq = event.getLm2_seq();

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	DateTimeFormatter ddtformatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	HashMap<String, List<String>> details = new HashMap<String, List<String>>();
	// First Fetch Records From {Alarm_Master} using {business_id} and
	// {alarm_id}
	List<String> roles = new ArrayList<String>();
	HashMap<String, String> rolesMap = new HashMap<String, String>();
	// LocalDateTime incomingAlarmTimeStamp =
	// LocalDateTime.of(2018,11,26,15,45);
	String eventDateTimeStr = event.getFecha();
	Database database = null;
	try {
	    // get shifts for site
	    SiteDTO site = new SiteDTO();
	    site.setSiteId(event.getSite_id());
	    List<ShiftDTO> shifts = SiteDao.getShiftDetailsForSite(site);

	    EventDao eventDao = new EventDao();
	    EventDTO eventDto = eventDao.getSiteDetails(event.getSite_id());
	    String zoneId = eventDto.getTimeZone();// "America/Montreal";
	    // LOG.debug("Site zoneId::" + zoneId);
	    String query = SQLConstants.alarms.GET_SITE_ALARM_PREFERENCES;

	    // current datetime in the sitezone
	    LocalDateTime lzdt = ZonedDateTime.now(ZoneId.of(zoneId)).toLocalDateTime();

	    LocalDateTime evtldt = LocalDateTime
		    .parse(eventDateTimeStr,
			    DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))
		    .atZone(ZoneOffset.UTC).withZoneSameInstant(ZoneId.of(zoneId)).toLocalDateTime();
	    LOG.debug("eventDateTime::" + eventDateTimeStr + " evtldt:::" + evtldt
		    .format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME)));
	    eventDateTimeStr = evtldt
		    .format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));

	    String curDateStr = ddtformatter.format(lzdt);
	    String curDateTimeStr = lzdt
		    .format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME)); // CommonUtils.getCurrentTimeForZone(zoneId)

	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(event.getTipo_alarma());
	    params.add(event.getDevice_id());
	    LOG.debug("query>>>>" + query);
	    LOG.debug(event.getTipo_alarma() + ":" + event.getSite_id());
	    ResultSet rs = database.executeQuery(query, params);
	    while (rs.next()) {
		boolean isValidCondition = false;
		boolean updateFirst = false;// to update if the firstdatetime is
					    // not valid
		// String row_id = rs.getString(SQLColumns.ID);
		int roleId = rs.getInt(SQLColumns.ROLE_ID);
		String duration = rs.getString(SQLColumns.THRESHOLD_REFRESH_VALUE);
		int alarmCount = 0;
		String alarmFirstDateTimeStr = rs.getString(SQLColumns.ALARM_FIRST_DATE_TIME);
		LocalDateTime afdt = null;
		if (alarmFirstDateTimeStr != null)
		    afdt = LocalDateTime.parse(alarmFirstDateTimeStr, formatter).atZone(ZoneOffset.UTC)
			    .withZoneSameInstant(ZoneId.of(zoneId)).toLocalDateTime();

		if (duration.equalsIgnoreCase(Constants.ThresholdResetConstants.SHIFT)) {
		    ShiftDTO curShift = null;
		    // check if event datetime falls in any shift
		    LocalDateTime sszdt = null;
		    LocalDateTime sezdt = null;
		    for (ShiftDTO shift : shifts) {
			// does event fall in today shift & current time at
			// source is in shift
			sszdt = LocalDateTime.parse(curDateStr + " " + shift.getStartTime(), formatter);
			sezdt = LocalDateTime.parse(curDateStr + " " + shift.getEndTime(), formatter);
			LOG.debug("Current: " + lzdt + " event:" + evtldt + "shift st:" + sszdt + "shift end:" + sezdt);

			// Is event date in valid shift and currently the same
			// shift is running
			if ((evtldt.isAfter(sszdt) && evtldt.isBefore(sezdt))
				&& (lzdt.isAfter(sszdt) && lzdt.isBefore(sezdt))) {
			    curShift = shift;
			    break;
			}
		    }
		    // LOG.debug("curShift::" + curShift);
		    // event belongs to a shift of today
		    if (curShift != null) {
			if (alarmFirstDateTimeStr != null) {
			    // is existing count related to today and same shift
			    LOG.debug("afdt:" + afdt + " :shift St" + sszdt + " shiftend:" + sezdt);
			    if (afdt.isAfter(sszdt) && afdt.isBefore(sezdt)) {
				LOG.debug("Same Day Same shift");
				alarmCount = rs.getInt(SQLColumns.ALARM_COUNTER) + 1;
			    } else {
				updateFirst = true;
				alarmCount = 1;
			    }
			} else
			    alarmCount = 1;

			isValidCondition = true;
		    }

		} else if (duration.equalsIgnoreCase(Constants.ThresholdResetConstants.DAY)) {
		    boolean isEventToday = CommonUtils.isDateInSameDay(eventDateTimeStr, curDateTimeStr);
		    if (isEventToday) {
			if (alarmFirstDateTimeStr != null) {
			    // is existing count related to today
			    LocalDateTime dayStart = evtldt.with(LocalTime.MIN);
			    LocalDateTime dayEnd = evtldt.with(LocalTime.MAX);
			    if (afdt.isAfter(dayStart) && afdt.isBefore(dayEnd)) {
				LOG.debug("Same Day");
				alarmCount = rs.getInt(SQLColumns.ALARM_COUNTER) + 1;
			    } else {
				updateFirst = true;
				alarmCount = 1;
			    }
			} else
			    alarmCount = 1;

			isValidCondition = true;
		    }
		} else if (duration.equalsIgnoreCase(Constants.ThresholdResetConstants.WEEK)) {
		    boolean isEventThisWeek = CommonUtils.isDateInSameWeek(eventDateTimeStr, curDateTimeStr);
		    if (isEventThisWeek) {
			if (alarmFirstDateTimeStr != null) {
			    // is existing count related to this week
			    LocalDateTime weekStart = evtldt.with(previousOrSame(MONDAY)).with(LocalTime.MIN);
			    LocalDateTime weekEnd = evtldt.with(nextOrSame(SUNDAY)).with(LocalTime.MAX);
			    if (afdt.isAfter(weekStart) && afdt.isBefore(weekEnd)) {
				LOG.debug("Same Week");
				alarmCount = rs.getInt(SQLColumns.ALARM_COUNTER) + 1;
			    } else {
				updateFirst = true;
				alarmCount = 1;
			    }
			} else
			    alarmCount = 1;

			isValidCondition = true;
		    }
		} else if (duration.equalsIgnoreCase(Constants.ThresholdResetConstants.MONTH)) {
		    boolean isEventThisMonth = CommonUtils.isDateInSameMonth(eventDateTimeStr, curDateTimeStr);
		    if (isEventThisMonth) {
			if (alarmFirstDateTimeStr != null) {
			    // is existing count related to this week
			    LocalDateTime monthStart = evtldt.with(TemporalAdjusters.firstDayOfMonth())
				    .with(LocalTime.MIN);
			    LocalDateTime monthEnd = evtldt.with(TemporalAdjusters.lastDayOfMonth())
				    .with(LocalTime.MAX);
			    if (afdt.isAfter(monthStart) && afdt.isBefore(monthEnd)) {
				LOG.debug("Same Month");
				alarmCount = rs.getInt(SQLColumns.ALARM_COUNTER) + 1;
			    } else {
				updateFirst = true;
				alarmCount = 1;
			    }
			} else
			    alarmCount = 1;
		    }

		    isValidCondition = true;
		}

		int threshold = rs.getInt(SQLColumns.THRESHOLD);
		LOG.debug(" isValidCondition:" + isValidCondition + " Alarmcount:" + alarmCount + " threshold:"
			+ threshold + " updateFirst:" + updateFirst);
		if (isValidCondition) {
		    // check threshold & update
		    if (alarmCount >= threshold) {
			// add role to list
			roles.add(rs.getString(SQLColumns.ROLE_ID));
			rolesMap.put(rs.getString(SQLColumns.ROLE_ID),
				(rs.getString(SQLColumns.EMAIL).equals("1") ? SQLColumns.EMAIL : "-") + ":"
					+ (rs.getString(SQLColumns.SMS).equals("1") ? SQLColumns.SMS : "-"));
			// TODO clear counter & date
			LinkedList<Object> parameters = new LinkedList<>();
			parameters.add("0");
			parameters.add(null);
			parameters.add(event.getDevice_id());
			parameters.add(alarmId);
			parameters.add(roleId);
			database.executeUpdate(SQLConstants.alarms.UPDATE_SITE_ALARM_PREFERENCE, parameters);
		    } else {
			// TODO update counter
			String iquery = SQLConstants.alarms.UPDATE_SITE_ALARM_PREFERENCE_COUNT;
			LinkedList<Object> parameters = new LinkedList<>();
			parameters.add(alarmCount);

			if (alarmFirstDateTimeStr == null || updateFirst) {
			    parameters.add(evtldt.format(formatter));
			    iquery = SQLConstants.alarms.UPDATE_SITE_ALARM_PREFERENCE;
			}
			parameters.add(event.getDevice_id());
			parameters.add(alarmId);
			parameters.add(roleId);
			database.executeUpdate(iquery, parameters);
		    }

		} /*
		   * else { // TODO clear counter & date LinkedList<Object> parameters = new
		   * LinkedList<>(); parameters.add("0"); parameters.add("NULL");
		   * parameters.add(row_id); database.executeUpdate(SQLConstants.alarms.
		   * UPDATE_SITE_ALARM_PREFERENCE, parameters); }
		   */
	    }
	    /*
	     * // get emails & phones of valid users
	     */
	    LOG.debug("RolesList::" + roles);
	    // LOG.debug("RolesMap::" + rolesMap);

	    if (!roles.isEmpty()) {
		details = findEmailAndPhoneSubscribers(database, event.getSite_id(), event.getTipo_alarma(), rolesMap);
		LOG.debug("details::" + details);
	    }

	    // details.put(SQLColumns.EMAIL, new ArrayList());
	} catch (Exception e) {
	    LOG.error("Exception in getSubscribers" + e.getMessage());
	    throw e;
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	} /**
	   * Return all collected roles. 1. If it is EMPTY, it specifies that, any alarm
	   * count has not reached the threshold.
	   */
	return details;

    }

    private String prepareMessage(EventDTO event, String dest) throws Exception {

	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
	int alarm = event.getTipo_alarma();
	String siteName = event.getSiteName();
	String weName = event.getWasherextractor_name();
	String alarmValue = Constants.REPORTS.OLD_ALARMS.get(alarm);
	Date oDate = ReportUtils.convertStringToDate(event.getFecha());
	int weId = event.getDestino();
	String formula = event.getFormula_nombre();
	int formulaId = event.getFormula();
	int cycle = event.getProceso();
	int phase = event.getFase();
	int productId = event.getProduct_id();
	String productName = event.getNombre();
	String mlEst = event.getMl_estimados();
	String mlReal = event.getMl_reales();
	String unitName = event.getUnit_name();

	String message = "";
	if (dest.equalsIgnoreCase(SQLColumns.EMAIL)) {
	    message = "ALERT! ";
	    if (alarm != 16 && alarm != 32 && alarm != 33)
		message += weName + " at ";
	    message += "Site: " + siteName + " has exceeded the alarm threshold for - " + alarmValue;
	    message += "<br /><u>Details:</u>";
	    message += "<br />Time: " + formatter.format(oDate);
	    message += "<br />Unit: " + unitName;

	    if (alarm != 16 && alarm != 32 && alarm != 33)
		message += "<br />Machine ID/Name: " + weId + "/" + weName;

	    if (alarm == 1 || alarm == 2 || alarm == 8 || alarm == 9 || alarm == 10 || alarm == 11) {
		message += "<br />Cycle #: " + cycle;

		if (alarm == 10 || alarm == 11)
		    message += "<br />Phase : " + phase;

		message += "<br />Formula #/Name: " + formulaId + "/" + formula;
	    }

	    if (alarm == 10 || alarm == 16)
		message += "<br />Product ID/Name: " + productId + "/" + productName;
	    if (alarm == 10)
		message += "<br />Volume Est/Act: " + mlEst + "/" + mlReal;

	} else if (dest.equalsIgnoreCase(SQLColumns.SMS)) {
	    message = "";
	    // message = message.replaceAll("<br />", "-").replaceAll("</u>",
	    // "").replaceAll("<u>", "");
	    if (alarm != 16 && alarm != 32 && alarm != 33)
		message += weName + " at \n";

	    message += siteName + " site \n";
	    message += "has " + alarmValue + (alarmValue.endsWith("Alarm") ? "" : " Alarm") + " \n";

	    if (alarm != 16 && alarm != 32 && alarm != 33) {
		message += "Cycle: " + cycle;
	    }

	}

	// System.out.println("Message:" + message);
	return message;
    }

    private void sendEmailNotifications(EventDTO event, List<String> emailList) {
	try {
	    // Send email notification
	    CommonUtils.sendEmail(emailList, Constants.ALARM_EMAIL_SUBJECT, prepareMessage(event, SQLColumns.EMAIL));
	} catch (Exception exp) {
	    LOG.error("Exception in sending email:" + exp.getMessage());
	}
    }

    private void sendSMSNotifications(EventDTO event, List<String> phoneList) {
	try {
	    // Send SMS notification
	    String message = prepareMessage(event, SQLColumns.SMS);
	    for (String phoneNum : phoneList) {
		SMSUtil.sendSMS(phoneNum, message);
	    }
	} catch (Exception exp) {
	    LOG.error("Exception in sending sms:" + exp.getMessage());
	}

    }

    protected List<Object> getInsufficientParamsList(EventDTO event) {
	List<Object> params = new LinkedList<>();
	if (event == null) {
	    params.add(ErrorCodes.InsufficientParams.EVENT_OBJECT);
	}
	if (StringUtils.isEmpty(event.getDevice_id())) {
	    params.add(ErrorCodes.InsufficientParams.DEVICE_ID);
	}
	if (StringUtils.isEmpty(event.getFecha())) {
	    params.add(ErrorCodes.InsufficientParams.FECHA);
	}
	if (StringUtils.isEmpty(event.getNombre())) {
	    params.add(ErrorCodes.InsufficientParams.PRODUCT_NAME);
	}
	return params;
    }

    public HashMap<String, List<String>> findEmailAndPhoneSubscribers(Database database, String siteId, int alarmId,
	    HashMap<String, String> rolesMap) throws Exception {
	HashMap<String, List<String>> collectedSubscriberDetails = new HashMap<String, List<String>>();
	List<String> emailIds = new ArrayList<>();
	List<String> phoneNumbers = new ArrayList<>();

	String query = "select user_id,email, phone_number, role_id from user_master where user_id in (select t1.user_id from (select user_id  from user_master UM where user_id in(select user_id from user_site_association where site_id='"
		+ siteId
		+ "' union all select user_id  from user_master where business_id is null union all select user_id from user_master where user_role ='"
		+ Constants.CHEMICAL_COMPANY_ADMIN
		+ "' and business_id=(select business_id from site_master where site_id='" + siteId
		+ "')) and role_id in (" + String.join(",", (new ArrayList<>(rolesMap.keySet())))
		+ ") ) t1 left join (select * from user_alarm_preference where alarm_id=" + alarmId
		+ " and active=0) t2 on t1.user_id= t2.user_id where t2.user_id is null)";
	// String query = SQLConstants.alarms.GET_USER_DETAILS_FOR_ROLES;
	LOG.debug("query for EmailAndPhoneSubscribers::" + query);

	LinkedList<Object> params = new LinkedList<>();
	/*
	 * params.add(siteId); params.add(Constants.CHEMICAL_COMPANY_ADMIN);
	 * params.add(siteId); params.add(String.join(",", (new
	 * ArrayList<>(rolesMap.keySet())))); params.add(alarmId);
	 */

	ResultSet rs = database.executeQuery(query, params);

	while (rs.next()) {
	    LOG.debug(rolesMap.get(rs.getString(SQLColumns.ROLE_ID)));
	    // LOG.debug(rs.getString(SQLColumns.EMAIL) + ":" +
	    // rs.getString(SQLColumns.PHONE_NUMBER) + ":"
	    // + rs.getString(SQLColumns.ROLE_ID));
	    String email = rs.getString(SQLColumns.EMAIL);
	    String phone = rs.getString(SQLColumns.PHONE_NUMBER);

	    String rolePreference = rolesMap.get(rs.getString(SQLColumns.ROLE_ID));
	    // System.out.println("rolePreference"+rolePreference);
	    if (email != null && rolePreference.indexOf(SQLColumns.EMAIL) != -1 && !emailIds.contains(email))
		emailIds.add(email);
	    if (phone != null && rolePreference.indexOf(SQLColumns.SMS) != -1 && !phoneNumbers.contains(phone))
		phoneNumbers.add(phone.replaceAll("-", "").replaceAll(" ", ""));
	}

	collectedSubscriberDetails.put(SQLColumns.EMAIL, emailIds);
	collectedSubscriberDetails.put(SQLColumns.SMS, phoneNumbers);

	return collectedSubscriberDetails;
    }

    public boolean getMachineIdleNotification() throws SystemException, Exception {
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	DateTimeFormatter ddtformatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
	Database database = null;
	ConfigReader config = ConfigReader.getObject();
	LocalDateTime currentDateTime = LocalDateTime.now(Clock.systemUTC());
	LocalDateTime earlierDateTime = currentDateTime.minusMinutes(
		Integer.parseInt(config.getAppConfig(Constants.MACHINE_IDLE_QUERY_TIME_RANGE_IN_HRS)) * 60);
	try {
	    String query = SQLConstants.GET_SITES_LIST_FROM_PREFERENCE_TABLE;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    ElasticSearchDAO esDAO = null;
	    database.setAutoCommitFalse();
	    ResultSet rs = database.executeQuery(query, null);

	    while (rs.next()) {
		esDAO = new ElasticSearchDAO(false, config.getEsConfig());
		String groupedSiteId = rs.getString(SQLColumns.GROUPED_SITE_ID);

		String timeZone = rs.getString(SQLColumns.TIME_ZONE);
		List<String> siteList = Arrays.asList(groupedSiteId.split(Constants.COMMA_SEPARATED_PATTERN));
		LOG.debug("siteList" + siteList + ":" + "timeZone" + timeZone);
		List<String> indexList = CommonUtils.createMonthlyIndexList(siteList);
		LOG.debug("indexList" + indexList);
		query = ReportUtils.getQuery(Constants.REPORTS.MACHINE_IDLE_LONG);
		LocalDateTime convertedCurrentDateTime = currentDateTime.atZone(ZoneId.of(Constants.UTC))
			.withZoneSameInstant(ZoneId.of(timeZone)).toLocalDateTime().withNano(0);
		LocalDateTime convertedEarlierDateTime = earlierDateTime.atZone(ZoneId.of(Constants.UTC))
			.withZoneSameInstant(ZoneId.of(timeZone)).toLocalDateTime().withNano(0);
		query = query.replace(Constants.FROM_DATE_VAL, convertedEarlierDateTime.toString());
		query = query.replace(Constants.TO_DATE_VAL, convertedCurrentDateTime.toString());
		LOG.debug("Query" + query);
		// JsonObject responseObject = SampleData.getSampleData();
		JsonObject responseObject = esDAO.executeQuery(query, indexList,
			config.getAppConfig(Constants.ES_TYPE));
		LOG.debug("responseObject" + responseObject);
		CommonUtils.esError(responseObject);

		JsonObject agg = ((JsonObject) responseObject.get(Constants.REPORTS.AGGREGATIONS));
		if (agg != null) {
		    JsonObject siteAgg = (JsonObject) (agg).get(Constants.REPORTS.SITE_AGGREGATION);
		    if (siteAgg != null) {
			JsonArray siteBuckets = siteAgg.getAsJsonArray(Constants.REPORTS.BUCKETS);
			for (int i = 0; i < siteBuckets.size(); i++) {
			    JsonObject site = siteBuckets.get(i).getAsJsonObject();

			    JsonObject unitAggregation = (JsonObject) site.get(Constants.REPORTS.UNIT_AGGREGATION);
			    JsonArray unitBuckets = unitAggregation.getAsJsonArray(Constants.REPORTS.BUCKETS);
			    for (int j = 0; j < unitBuckets.size(); j++) {
				JsonObject unit = unitBuckets.get(j).getAsJsonObject();
				JsonObject machineAggregation = (JsonObject) unit
					.get(Constants.REPORTS.MACHINE_AGGREGATION);
				JsonArray machineBuckets = machineAggregation.getAsJsonArray(Constants.REPORTS.BUCKETS);
				for (int k = 0; k < machineBuckets.size(); k++) {
				    JsonObject groupDocs = machineBuckets.get(k).getAsJsonObject();
				    JsonObject documentAggregation = (JsonObject) groupDocs
					    .get(Constants.REPORTS.GROUP_DOCUMENT);
				    JsonObject hitsObject = documentAggregation.getAsJsonObject(Constants.REPORTS.HITS);
				    JsonArray hitsArray = ReportUtils.fieldsQuery(hitsObject);

				    // processing each event to find if machine
				    // idle
				    // long has happened.
				    if (hitsArray != null && hitsArray.size() > 0) {
					Gson gson = new Gson();
					JsonObject event = hitsArray.get(0).getAsJsonObject();
					EventDTO eventDTO = gson.fromJson(event.toString(), EventDTO.class);

					int alarmId = Constants.MACHINE_IDLE_TOO_LONG_TIME_ALARM_CODE;
					String siteId = eventDTO.getSite_id();
					String deviceId = eventDTO.getDevice_id();
					int machineId = eventDTO.getDestino();
					int equipmentType = eventDTO.getEquipment_type();
					// check if for a site alert-setting is
					// set to yes or not. If not then no
					// need to
					// process the event.
					EventDTO siteDetails = ((EventDao) hydroDao).getSiteDetails(siteId);
					if (siteDetails.getAlertSetting() == 0) {
					    LOG.error(
						    "site doesn't have alert-setting set to 'yes'. Hence, notification can't be sent.");
					    return true;
					}

					List<String> roles = new ArrayList<String>();
					HashMap<String, String> rolesMap = new HashMap<String, String>();
					query = SQLConstants.alarms.GET_SITE_PREDEFINED_ALARM_PREFERENCE;
					LinkedList<Object> params = new LinkedList<>();
					params.add(alarmId);
					params.add(siteId);
					params.add(deviceId);
					params.add(machineId);
					LOG.debug("query>>>>" + query);
					LOG.debug(alarmId + ":" + siteId);

					ResultSet result = database.executeQuery(query, params);
					while (result.next()) {
					    if (eventDTO.getEvent_type().equals(
						    config.getAppConfig(Constants.REPORTS.EVENT_TYPE_END_OF_CYCLE))) {
						LocalDateTime fecha = LocalDateTime.parse(CommonUtils
							.extractFechaDateInProcessableFormat(eventDTO.getFecha()));
						fecha = fecha.atZone(ZoneId.of(Constants.UTC))
							.withZoneSameInstant(ZoneId.of(timeZone)).toLocalDateTime()
							.withNano(0);

						LocalDateTime notificationSentTime = null;
						if (result.getString(SQLColumns.ALARM_FIRST_DATE_TIME) != null) {
						    String date = result.getString(SQLColumns.ALARM_FIRST_DATE_TIME);
						    date = date.replace(" ", "T");
						    notificationSentTime = LocalDateTime.parse(date);
						    // date object stored in DB
						    // are
						    // of
						    // utc timezone, hence
						    // change it
						    // to
						    // zone timezone
						    notificationSentTime = notificationSentTime
							    .atZone(ZoneId.of(Constants.UTC))
							    .withZoneSameInstant(ZoneId.of(timeZone)).toLocalDateTime()
							    .withNano(0);
						}

						eventDTO.setSiteName(siteDetails.getSiteName());
						int idleTime;
						if (event.get(Constants.REPORTS.EQUIPMENT_TYPE).getAsString()
							.equals(Constants.EquipmentType.TUNNEL)) {
						    idleTime = siteDetails.getTunnelIdleTime();
						} else {
						    idleTime = siteDetails.getWasherIdleTime();
						}

						if (notificationSentTime != null && notificationSentTime.isBefore(fecha)
							|| notificationSentTime == null) {
						    long timeDifference = ((EventDao) hydroDao).calTimeDifference(fecha,
							    convertedCurrentDateTime);
						    if (timeDifference >= idleTime) {
							String eventDateTimeStr = fecha
								.format(DateTimeFormatter.ofPattern(
									Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));

							// current datetime in
							// the sitezone
							LocalDateTime lzdt = convertedCurrentDateTime;
							LocalDateTime evtldt = fecha;

							// get shifts for site
							SiteDTO siteDTO = new SiteDTO();
							siteDTO.setSiteId(siteId);
							List<ShiftDTO> shifts = SiteDao.getShiftDetailsForSite(siteDTO);

							// changing the format
							// of current date time
							String curDateStr = ddtformatter.format(lzdt);
							String curDateTimeStr = convertedCurrentDateTime
								.format(DateTimeFormatter.ofPattern(
									Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));

							boolean isValidCondition = false;
							boolean updateFirst = false;

							int roleId = result.getInt(SQLColumns.ROLE_ID);
							String duration = result
								.getString(SQLColumns.THRESHOLD_REFRESH_VALUE);
							int alarmCount = 0;

							LocalDateTime afdt = null;
							if (notificationSentTime != null)
							    afdt = notificationSentTime;

							if (duration.equalsIgnoreCase(
								Constants.ThresholdResetConstants.SHIFT)) {
							    ShiftDTO curShift = null;

							    LocalDateTime sszdt = null;
							    LocalDateTime sezdt = null;
							    for (ShiftDTO shift : shifts) {

								sszdt = LocalDateTime.parse(
									curDateStr + " " + shift.getStartTime(),
									formatter);
								sezdt = LocalDateTime.parse(
									curDateStr + " " + shift.getEndTime(),
									formatter);
								LOG.debug("Current: " + lzdt + " event:" + evtldt
									+ "shift st:" + sszdt + "shift end:" + sezdt);

								if ((evtldt.isAfter(sszdt) && evtldt.isBefore(sezdt))
									&& (lzdt.isAfter(sszdt)
										&& lzdt.isBefore(sezdt))) {
								    curShift = shift;
								    break;
								}
							    }

							    if (curShift != null) {
								if (notificationSentTime != null) {

								    LOG.debug("afdt:" + afdt + " :shift St" + sszdt
									    + " shiftend:" + sezdt);
								    if (afdt.isAfter(sszdt) && afdt.isBefore(sezdt)) {
									LOG.debug("Same Day Same shift");
									alarmCount = result
										.getInt(SQLColumns.ALARM_COUNTER) + 1;
								    } else {
									updateFirst = true;
									alarmCount = 1;
								    }
								} else
								    alarmCount = 1;

								isValidCondition = true;
							    }

							} else if (duration.equalsIgnoreCase(
								Constants.ThresholdResetConstants.DAY)) {
							    boolean isEventToday = CommonUtils
								    .isDateInSameDay(eventDateTimeStr, curDateTimeStr);
							    if (isEventToday) {
								if (notificationSentTime != null) {

								    LocalDateTime dayStart = evtldt.with(LocalTime.MIN);
								    LocalDateTime dayEnd = evtldt.with(LocalTime.MAX);
								    if (afdt.isAfter(dayStart)
									    && afdt.isBefore(dayEnd)) {
									LOG.debug("Same Day");
									alarmCount = result
										.getInt(SQLColumns.ALARM_COUNTER) + 1;
								    } else {
									updateFirst = true;
									alarmCount = 1;
								    }
								} else
								    alarmCount = 1;

								isValidCondition = true;
							    }
							} else if (duration.equalsIgnoreCase(
								Constants.ThresholdResetConstants.WEEK)) {
							    boolean isEventThisWeek = CommonUtils
								    .isDateInSameWeek(eventDateTimeStr, curDateTimeStr);
							    if (isEventThisWeek) {
								if (notificationSentTime != null) {

								    LocalDateTime weekStart = evtldt
									    .with(previousOrSame(MONDAY))
									    .with(LocalTime.MIN);
								    LocalDateTime weekEnd = evtldt
									    .with(nextOrSame(SUNDAY))
									    .with(LocalTime.MAX);
								    if (afdt.isAfter(weekStart)
									    && afdt.isBefore(weekEnd)) {
									LOG.debug("Same Week");
									alarmCount = result
										.getInt(SQLColumns.ALARM_COUNTER) + 1;
								    } else {
									updateFirst = true;
									alarmCount = 1;
								    }
								} else
								    alarmCount = 1;

								isValidCondition = true;
							    }
							} else if (duration.equalsIgnoreCase(
								Constants.ThresholdResetConstants.MONTH)) {
							    boolean isEventThisMonth = CommonUtils.isDateInSameMonth(
								    eventDateTimeStr, curDateTimeStr);
							    if (isEventThisMonth) {
								if (notificationSentTime != null) {
								    // is
								    // existing
								    // count
								    // related
								    // to this
								    // week
								    LocalDateTime monthStart = evtldt
									    .with(TemporalAdjusters.firstDayOfMonth())
									    .with(LocalTime.MIN);
								    LocalDateTime monthEnd = evtldt
									    .with(TemporalAdjusters.lastDayOfMonth())
									    .with(LocalTime.MAX);
								    if (afdt.isAfter(monthStart)
									    && afdt.isBefore(monthEnd)) {
									LOG.debug("Same Month");
									alarmCount = result
										.getInt(SQLColumns.ALARM_COUNTER) + 1;
								    } else {
									updateFirst = true;
									alarmCount = 1;
								    }
								} else
								    alarmCount = 1;
							    }

							    isValidCondition = true;
							}
							int threshold = result.getInt(SQLColumns.THRESHOLD);
							LOG.debug(" isValidCondition:" + isValidCondition
								+ " Alarmcount:" + alarmCount + " threshold:"
								+ threshold + " updateFirst:" + updateFirst);
							if (isValidCondition) {
							    // check threshold &
							    // update
							    if (alarmCount >= threshold) {
								// add role to
								// list
								roles.add(result.getString(SQLColumns.ROLE_ID));
								rolesMap.put(result.getString(SQLColumns.ROLE_ID),
									(result.getString(SQLColumns.EMAIL).equals("1")
										? SQLColumns.EMAIL
										: "-")
										+ ":"
										+ (result.getString(SQLColumns.SMS)
											.equals("1") ? SQLColumns.SMS
												: "-"));
								// TODO clear
								// counter &
								// date
								LinkedList<Object> parameters = new LinkedList<>();
								parameters.add("0");
								parameters.add(siteId);
								parameters.add(deviceId);
								parameters.add(alarmId);
								parameters.add(roleId);
								database.executeUpdate(
									SQLConstants.alarms.UPDATE_SITE_PREDEFINED_ALARM_COUNTER,
									parameters);

								parameters = new LinkedList<>();
								// parameters.add(machineCount);
								// convert time
								// zone
								// of
								// datetime to
								// store
								// in
								// DB
								// in UTC.
								LocalDateTime convertedDateTimeUTC = fecha
									.atZone(ZoneId.of(timeZone))
									.withZoneSameInstant(ZoneId.of(Constants.UTC))
									.toLocalDateTime().withNano(0);
								DateTimeFormatter formatterDateTime = DateTimeFormatter
									.ofPattern(
										Constants.DATE_TIME_FORMAT.DATE_FORMAT);
								String formatedDateTime = convertedDateTimeUTC
									.format(formatterDateTime);
								parameters.add(formatedDateTime);
								parameters.add(siteId);
								parameters.add(deviceId);
								parameters.add(alarmId);
								parameters.add(machineId);
								parameters.add(roleId);
								database.executeUpdate(
									SQLConstants.alarms.UPDATE_SITE_PREDEFINED_ALARM_FECHA,
									parameters);
							    } else {
								String iquery = SQLConstants.alarms.UPDATE_SITE_PREDEFINED_ALARM_COUNTER;
								LinkedList<Object> parameters = new LinkedList<>();
								parameters.add(alarmCount);
								parameters.add(siteId);
								parameters.add(deviceId);
								parameters.add(alarmId);
								parameters.add(roleId);
								database.executeUpdate(iquery, parameters);

								iquery = SQLConstants.alarms.UPDATE_SITE_PREDEFINED_ALARM_FECHA;
								parameters = new LinkedList<>();
								// parameters.add(machineCount);
								// convert time
								// zone
								// of
								// datetime to
								// store
								// in
								// DB
								// in UTC.
								LocalDateTime convertedDateTimeUTC = fecha
									.atZone(ZoneId.of(timeZone))
									.withZoneSameInstant(ZoneId.of(Constants.UTC))
									.toLocalDateTime().withNano(0);
								DateTimeFormatter formatterDateTime = DateTimeFormatter
									.ofPattern(
										Constants.DATE_TIME_FORMAT.DATE_FORMAT);
								String formatedDateTime = convertedDateTimeUTC
									.format(formatterDateTime);
								parameters.add(formatedDateTime);
								parameters.add(siteId);
								parameters.add(deviceId);
								parameters.add(alarmId);
								parameters.add(machineId);
								parameters.add(roleId);
								database.executeUpdate(iquery, parameters);
							    }

							    EquipmentDTO equipment = ((EventDao) hydroDao)
								    .getEquipmentDetail(eventDTO.getDevice_id());
							    if (equipment != null) {
								eventDTO.setUnit_name(equipment.getAlias());
							    }

							    if (equipmentType == Integer
								    .parseInt(Constants.EquipmentType.TUNNEL)) {
								((EventDao) hydroDao).populateTunnelDetail(eventDTO);
							    }

							    // getting user
							    // details
							    if (!roles.isEmpty()) {
								Map<String, List<String>> details = findEmailAndPhoneSubscribers(
									database, siteId,
									Constants.MACHINE_IDLE_TOO_LONG_TIME_ALARM_CODE,
									rolesMap);
								eventDTO.setTipo_alarma(alarmId);
								LOG.debug("details::" + details);

								String eventDateTimeZone = fecha
									.format(DateTimeFormatter.ofPattern(
										Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
								// sendEmails
								eventDTO.setFecha(eventDateTimeZone);

								// sendEmails
								if (details.containsKey(SQLColumns.EMAIL)) {
								    sendEmailNotifications(eventDTO,
									    details.get(SQLColumns.EMAIL));
								}
								// sendSMSs
								if (details.containsKey(SQLColumns.SMS)) {
								    sendSMSNotifications(eventDTO,
									    details.get(SQLColumns.SMS));
								}
							    }

							}
						    }
						}
					    }
					}

				    }
				}
			    }
			}
		    }
		}
		esDAO.closeJestClient();
		database.commit();
	    }
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
	return true;
    }

    public void processJsonConfigPayload(Config config) throws Exception {

	if (CommonConstants.CONFIG.equalsIgnoreCase(config.getDataType())) {

	    ConfigDao configdao = new ConfigDaoImpl();
	    MData mData = config.getmData();
	    String fileId = getGuid();

	    ConfigReader configReader = new ConfigReader();
	    String deviceId = configReader.getDeviseIdUsingSerialNo(mData.getSerialNumber());
	    String siteId = configReader.getSiteIdUsingSerialNo(mData.getSerialNumber());
	    configdao.createFileMaster(siteId, config, fileId, deviceId);

	    List<UData> uDataList = config.getuData();

	    for (UData data : uDataList) {
		TData tData = data.gettData();
		if (null != tData) {
		    List<UnitMaster> unitMastersList = tData.getUnit_master();
		    if (CollectionUtils.isNotEmpty(unitMastersList)) {
			UnitMaster unitMaster = unitMastersList.get(0);

			String equipId = unitMaster.getEquipment_id() + "_" + getGuid();
			int equipmentType = unitMaster.getEquipment_type();
			configdao.createEquipmentMaster(unitMaster, equipId, siteId, fileId, deviceId);
			processTData(configdao, equipId, tData, equipmentType);
		    }
		}
	    }

	    // configdao.updateSiteMaster(fileId, siteId);

	}
    }

    private void processTData(ConfigDao configdao, String equipId, TData tData, int equipmentType) throws Exception {

	List<FormulaMaster> formulaMastersList = tData.getFormula_master();
	List<ProductMaster> productMastersList = tData.getProduct_master();
	List<MachineMaster> machineMastersList = tData.getMachine_master();
	List<WaterMaster> waterMastersList = tData.getWater_master();

	if (CollectionUtils.isNotEmpty(formulaMastersList)) {
	    for (FormulaMaster formulaMaster : formulaMastersList) {
		configdao.createFormulaMaster(formulaMaster, equipId);

	    }
	}

	if (CollectionUtils.isNotEmpty(productMastersList)) {
	    for (ProductMaster productMaster : productMastersList) {
		configdao.createProductMaster(productMaster, equipId);
	    }
	}

	if (CollectionUtils.isNotEmpty(waterMastersList)) {
	    for (WaterMaster waterMaster : waterMastersList) {
		configdao.createWaterMaster(waterMaster, equipId);
	    }
	}

	if (CollectionUtils.isNotEmpty(machineMastersList)) {
	    for (MachineMaster machineMaster : machineMastersList) {
		configdao.createWasherOrTunnelMaster(machineMaster, equipId, equipmentType);
	    }
	}

    }

    private static String getGuid() {
	return UUID.randomUUID().toString();
    }

    public void saveEvent(String dataStr) throws Exception {
	String eventInfo = "";
	try {
	    ConfigReader config = new ConfigReader();

	    // Convert event string to Json object
	    JsonObject data = validateAndConvertEventData(dataStr);

	    JsonElement serialNumberEle = data.get(Constants.MDATA).getAsJsonObject().get(Constants.SERIAL_NUMBER);

	    String serialNumber = serialNumberEle.getAsString();

	    JsonElement eventEle = data.get(Constants.EDATA);
	    JsonObject event = eventEle.getAsJsonObject();

	    EventDTO eventDto = gson.fromJson(event, EventDTO.class);

	    eventInfo = "SerNo: " + serialNumber + " Id:" + eventDto.getId() + " EventId:" + eventDto.getEvent_id()
		    + " UnitId:" + eventDto.getUnit_id() + " LaundryId:" + eventDto.getLaundry_id() + " WasherName:"
		    + eventDto.getWasherextractor_name();

	    // get site id for the serial number
	    EventDTO deviceDetail = getSiteDetail(serialNumber);

	    populateFormulaNameInEventObject(deviceDetail, eventDto);

	    event.addProperty(Constants.SITE_ID, deviceDetail.getSite_id());
	    eventDto.setSite_id(deviceDetail.getSite_id());
	    event.addProperty(Constants.DEVICEID, deviceDetail.getDevice_id());
	    eventDto.setDevice_id(deviceDetail.getDevice_id());
	    event.addProperty(Constants.SOURCE, Constants.EDGE);
	    event.addProperty(Constants.REPORTS.FORMULA_NAME, eventDto.getFormula_nombre());
	    event.addProperty(Constants.REPORTS.COST_ESTIMADO, eventDto.getCoste_estimado());
	    event.addProperty(Constants.REPORTS.COST_REAL, eventDto.getCoste_real());

	    // convert fecha string to date
	    // ZonedDateTime eventDateTime =
	    // CommonUtils.convertUTCtoZonedTime(eventDto.getFecha(),
	    // deviceDetail.getTimeZone());
	    ZonedDateTime eventDateTime = CommonUtils.parseAsUtcZoneTime(eventDto.getFecha());
	    Duration timeDiff = CommonUtils.getTimeDifferenceWrtCurrentTime(eventDateTime);
	    // event.addProperty(Constants.REPORTS.DATE_TIME,
	    // eventDateTime.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME)));
	    // eventDto.setFecha(eventDateTime.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME)));

	    // write the event to monthly index
	    String eventId = eventDto.getEvent_id();
	    String monthlyIndex = ReportUtils.getIndexName(deviceDetail.getSite_id(), eventDateTime.getMonthValue(),
		    eventDateTime.getYear());
	    String eventType = ConfigReader.getObject().getAppConfig(Constants.ES_TYPE);
	    ElasticSearchDAO esDAO = new ElasticSearchDAO(false, config.getEsConfig());
	    esDAO.indexDocument(gson.toJson(event), monthlyIndex, eventType, eventId);

	    // write the event to daily index if the event date is not greater
	    // than threshold days
	    if (timeDiff.toDays() < 0) {
		LOG.error(
			"Issue with event date-time: either current time is back dated or the event date-time is future dated.");
	    }
	    String esDailyIndexThreshold = config.getAppConfig(Constants.ES_DAILY_INDEX_THRESHOLD);

	    if (timeDiff.abs().toDays() < Long.valueOf(esDailyIndexThreshold)) {
		String dailyIndex = ReportUtils.getDailyIndexName(deviceDetail.getSite_id(),
			eventDateTime.getDayOfMonth(), eventDateTime.getMonthValue(), eventDateTime.getYear());
		esDAO.indexDocument(gson.toJson(event), dailyIndex, eventType, eventId);

		if (eventDto.getTipo_alarma() != 0) {
		    processEvent(eventDto);
		}
	    } else {
		LOG.info("Skipping as Event is older than " + esDailyIndexThreshold + " days. Event Date:: "
			+ eventDateTime.format(
				DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME)));
	    }

	    if (esDAO != null)
		esDAO.closeJestClient();

	} catch (Exception e) {
	    LOG.info("Event processing failed::: " + eventInfo);
	    LOG.error("Exception in saveEvent : " + ExceptionUtils.getFullStackTrace(e));
	    throw e;
	}
    }

    private JsonObject validateAndConvertEventData(String dataStr) throws Exception {
	JsonObject data = gson.fromJson(dataStr, JsonObject.class);
	JsonElement mdata = data.get(Constants.MDATA);
	if (mdata == null || mdata.isJsonNull() || !mdata.isJsonObject()) {
	    throw new SystemException(Constants.SERIAL_NUMBER + " property missing in input event.",
		    ErrorCodes.INSUFFICIENT_INFORMATION, ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}
	JsonElement serialNumberEle = mdata.getAsJsonObject().get(Constants.SERIAL_NUMBER);
	if (serialNumberEle == null || serialNumberEle.isJsonNull() || serialNumberEle.getAsString().isEmpty()) {
	    throw new SystemException(Constants.SERIAL_NUMBER + " property missing in input event.",
		    ErrorCodes.INSUFFICIENT_INFORMATION, ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}

	JsonElement eventEle = data.get(Constants.EDATA);
	if (eventEle.isJsonNull() || !eventEle.isJsonObject()) {
	    throw new SystemException(Constants.EDATA + " property missing in input event.",
		    ErrorCodes.INSUFFICIENT_INFORMATION, ErrorCodes.StatusCodes.BAD_REQUEST, null);
	}

	return data;
    }

    private EventDTO getSiteDetail(String serialNumber) throws Exception {
	List<String> messages = new ArrayList<>();
	ConfigReader configReader = ConfigReader.getObject();
	String siteId = configReader.getSiteIdUsingSerialNo(serialNumber);

	if (StringUtils.isBlank(siteId)) {
	    messages.add("Site Id not available for Serial Number = \"" + serialNumber + "\".");
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, messages);
	}

	// get site's details - making this call to get the time zone of the
	// site
	EventDTO deviceDetail = ((EventDao) hydroDao).getSiteDetails(siteId);
	deviceDetail.setSite_id(siteId);

	// get device id for the serial number
	String deviceId = configReader.getDeviseIdUsingSerialNo(serialNumber);

	if (StringUtils.isBlank(deviceId)) {
	    messages.add("Device Id not available for Serial Number = \"" + serialNumber + "\".");
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, messages);
	}

	deviceDetail.setDevice_id(deviceId.trim());
	return deviceDetail;
    }

    private void populateFormulaNameInEventObject(EventDTO deviceDetail, EventDTO event) throws Exception {
	List<String> messages = new ArrayList<>();

	int formulaSeq = event.getFormula();

	// get equipment id for the device id
	EquipmentDTO equipment = ((EventDao) hydroDao).getEquipmentDetail(deviceDetail.getDevice_id());
	if (equipment == null) {
	    messages.add("Equiment Id not available for device Id \"" + deviceDetail.getDevice_id() + "\".");
	    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, messages);
	}

	populateCostInfo(event, equipment);
	// get formula name using equipment id and event's formula field(lm2_seq
	// of
	// formula_master)

	FormulaMetaDataDTO formula = ((EventDao) hydroDao).getFormulaDetail(equipment.getEquipmentId(), formulaSeq);

	if (formula == null || formula.getName() == null || StringUtils.isEmpty(formula.getName().trim())) {
	    LOG.error("Formula Name not available for Equipment Id \"" + equipment.getEquipmentId()
		    + "\" and formula sequence = " + formulaSeq);
	} else {
	    event.setFormula_nombre(formula.getName().trim());
	}
    }

    private void populateCostInfo(EventDTO event, EquipmentDTO equipment) throws Exception {
	List<ProductDTO> productList = equipProdHm.get(equipment.getEquipmentId());

	if (productList == null) {
	    productList = ((EventDao) hydroDao).getProductList(equipment);
	    equipProdHm.put(equipment.getEquipmentId(), productList);
	}
	try {
	    BigDecimal productPrice = getProductPrice(productList, event.getProduct_id());

	    if (productPrice.compareTo(BigDecimal.ZERO) == 0) {
		// event.setCoste_estimado("0");
		// event.setCoste_real("0");
	    } else {

		BigDecimal costPerOz = productPrice.divide(new BigDecimal(Constants.Units.OZ_GALLON));
		MathContext mc = new MathContext(5);
		event.setCoste_estimado(
			String.valueOf(costPerOz.multiply(new BigDecimal(event.getMl_estimados()), mc)));
		event.setCoste_real(String.valueOf(costPerOz.multiply(new BigDecimal(event.getMl_reales()), mc)));
	    }
	} catch (NumberFormatException e) {
	    LOG.error("product price or ML_ESTIMADOS or ML_REALES does not have proper value for Equipment Id \""
		    + equipment.getEquipmentId());
	}
    }

    private BigDecimal getProductPrice(List<ProductDTO> productList, int product_id) {
	for (ProductDTO productDTO : productList) {
	    if (productDTO.getLm2Seq().equalsIgnoreCase("" + product_id)) {
		return productDTO.getPrecio();
	    }
	}
	return BigDecimal.ZERO;
    }

}
