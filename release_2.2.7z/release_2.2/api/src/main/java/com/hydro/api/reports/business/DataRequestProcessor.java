package com.hydro.api.reports.business;

import java.util.Map;

import com.hydro.api.dto.reports.DataRequestDTO;

public interface DataRequestProcessor {
    Object getData(DataRequestDTO dataRequest, Map<RequestContextEntity,Object> context) throws Exception;
    
    enum RequestContextEntity {
	SITE,
	EQUIPMENT
    }
}
