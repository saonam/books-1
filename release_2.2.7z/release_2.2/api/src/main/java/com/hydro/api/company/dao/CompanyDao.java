package com.hydro.api.company.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.base.dao.HydroDao;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.AlertDTO;
import com.hydro.api.dto.CompanyDTO;
import com.hydro.api.dto.CompanyListResponseDTO;
import com.hydro.api.dto.ContactDTO;
import com.hydro.api.dto.EquipmentDTO;
import com.hydro.api.dto.RoleDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;

/**
 *
 * @author Shreyas, Srishti
 * 
 */
public abstract class CompanyDao extends HydroDao {
    private static final Logger LOG = LoggerFactory.getLogger(CompanyDao.class);

    public abstract CompanyListResponseDTO getCompanyList(UserDTO user, CompanyDTO company) throws Exception;

    public abstract boolean hasVisibility(UserDTO user, CompanyDTO company) throws Exception;

    public abstract CompanyDTO createCompany(UserDTO user, CompanyDTO company) throws Exception;

    public abstract boolean updateCompany(UserDTO user, CompanyDTO company) throws Exception;

    public abstract List<SiteDTO> getSiteList(UserDTO user) throws Exception;

    public abstract List<ContactDTO> getContactListForCompany(UserDTO user, CompanyDTO company) throws Exception;

    public CompanyDTO getAlarmDetails() throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_ALARM_LIST;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    return getDefaultAlarmListData(database.executeQuery(query, params));
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

    }

    /**
     * Method to Check if the Business's Name exists. Has the super implementation.
     * For users other than Hydro Admin, special checks will be performed.
     * 
     * @param user
     * @param companyDTO
     * @return
     * @throws Exception
     */
    public String companyNameExists(UserDTO user, CompanyDTO companyDTO) throws Exception {

	Database database = null;
	try {
	    String query = SQLConstants.BUSINESS_NAME_EXISTS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();

	    params.add(Constants.BusinessTypes.COMPANY);
	    params.add(companyDTO.getName().toLowerCase());
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return rs.getString(SQLColumns.BUSINESS_ID);
	    }
	    return null;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
    }

    public boolean testCompanyDbConnection() {
	Database database = null;
	try {
	    database = new Database();

	    if (database.connection != null) {
		return true;
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    return false;
	} finally {
	    if (database != null) {
		try {
		    database.closeConnection();
		} catch (SQLException e) {
		    LOG.error("Error : " + e.getMessage());
		    e.printStackTrace();
		}
	    }
	}
	return false;
    }

    protected CompanyListResponseDTO getCompanyListData(ResultSet rs, String timeZone) throws SQLException {
	CompanyListResponseDTO response = new CompanyListResponseDTO();
	List<CompanyDTO> companyList = new LinkedList<>();
	while (rs.next()) {
	    CompanyDTO company = new CompanyDTO();
	    company.setCompanyId(rs.getString(SQLColumns.BUSINESS_ID));
	    company.setName(rs.getString(SQLColumns.NAME));
	    company.setState(rs.getString(SQLColumns.STATE));
	    company.setCity(rs.getString(SQLColumns.CITY));
	    company.setZipCode(rs.getString(SQLColumns.ZIPCODE));
	    company.setCreatedBy(rs.getString(SQLColumns.CREATED_BY));
	    company.setCountry(rs.getString(SQLColumns.COUNTRY));
	    company.setCreatedDate(CommonUtils.convertDate(rs.getString(SQLColumns.CREATED_DATE), timeZone));
	    companyList.add(company);
	}
	response.setCompanyList(companyList);
	return response;
    }

    /**
     * Method to fetch company details.
     * 
     * @param companyDTO
     * @return
     * @throws Exception
     */
    public CompanyDTO getCompanyDetails(CompanyDTO companyDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_COMPANY_DETAILS;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.BusinessTypes.COMPANY);
	    params.add(companyDTO.getCompanyId());

	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		companyDTO = new CompanyDTO();
		companyDTO.setCompanyId(rs.getString(SQLColumns.BUSINESS_ID));
		companyDTO.setName(rs.getString(SQLColumns.NAME));
		companyDTO.setAddress1(rs.getString(SQLColumns.ADDRESS1));
		companyDTO.setAddress2(rs.getString(SQLColumns.ADDRESS2));
		companyDTO.setState(rs.getString(SQLColumns.STATE));
		companyDTO.setCountry(rs.getString(SQLColumns.COUNTRY));
		companyDTO.setCity(rs.getString(SQLColumns.CITY));
		companyDTO.setZipCode(rs.getString(SQLColumns.ZIPCODE));
		companyDTO.setDescription(rs.getString(SQLColumns.DESCRIPTION));
		return companyDTO;
	    } else {
		throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public List<SiteDTO> getSiteListForCompany(CompanyDTO company) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_SITES_FOR_COMPANY;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(company.getCompanyId());
	    database = new Database();
	    return getCompanySiteData(database.executeQuery(query, params));
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    protected List<SiteDTO> getCompanySiteData(ResultSet rs) throws SQLException {
	List<SiteDTO> siteList = new LinkedList<>();
	while (rs.next()) {
	    SiteDTO siteDTO = new SiteDTO();
	    siteDTO.setSiteId(rs.getString(SQLColumns.SITE_ID));
	    siteDTO.setSiteName(rs.getString(SQLColumns.SITE_NAME));
	    siteDTO.setCity(rs.getString(SQLColumns.CITY));
	    siteDTO.setZipCode(rs.getString(SQLColumns.ZIPCODE));
	    siteDTO.setAccountId(rs.getString(SQLColumns.BUSINESS_ID));
	    siteDTO.setAccountName(rs.getString(SQLColumns.NAME));
	    siteList.add(siteDTO);
	}
	return siteList;
    }

    protected List<ContactDTO> getCompanyContactData(ResultSet rs) throws SQLException {
	List<ContactDTO> contactList = new LinkedList<>();
	while (rs.next()) {
	    ContactDTO contact = new ContactDTO();
	    contact.setContactId(rs.getString(SQLColumns.CONTACT_ID));
	    contact.setEmail(rs.getString(SQLColumns.CONTACT_EMAIL));
	    contact.setName(rs.getString(SQLColumns.CONTACT_NAME));
	    contact.setNumber(rs.getString(SQLColumns.CONTACT_NUMBER));
	    contact.setTitle(rs.getString(SQLColumns.CONTACT_TITLE));
	    contactList.add(contact);

	}
	return contactList;
    }

    public static HashSet<String> getContactAssociatedToCompany(CompanyDTO company) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_CONTACT_ID_FOR_BUSINESS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(company.getCompanyId());
	    HashSet<String> ContactIdSet = new HashSet<>();
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    while (rs.next()) {
		ContactIdSet.add(rs.getString(SQLColumns.CONTACT_ID));
	    }
	    return ContactIdSet;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static CompanyDTO getCompanyPreferenceData(ResultSet rs) throws Exception {
	CompanyDTO company = new CompanyDTO();
	try {
	    // "select distinct PM.alarm_id,PM.role_id,RM.user_role ,PM.sms,
	    // PM.email,
	    // PM.threshold,PM.predefined_alarm_threshold,PM.threshold_refresh_interval,AM.alarm_type,AM.alarm_name,AM.description
	    // from hydro.preference_master PM left join hydro.alarm_master AM
	    // on AM.alarm_id= PM.alarm_id left join hydro.role_master RM on
	    // RM.role_id=PM.role_id where PM.business_id =? and site_id is
	    // null"
	    Map<Integer, AlertDTO> systemAlarmMap = new HashMap<>();
	    Map<Integer, AlertDTO> customAlarmMap = new HashMap<>();
	    while (rs.next()) {
		AlertDTO alert = new AlertDTO();
		RoleDTO role = new RoleDTO();
		List<RoleDTO> roleDTOs = new LinkedList<>();
		int alarmId = rs.getInt(SQLColumns.ALARM_ID);
		if (systemAlarmMap.containsKey(alarmId)) {
		    alert = systemAlarmMap.get(alarmId);
		    roleDTOs = alert.getUserGroup();
		}
		if (customAlarmMap.containsKey(alarmId)) {
		    alert = customAlarmMap.get(alarmId);
		    roleDTOs = alert.getUserGroup();
		}
		role.setRoleId(rs.getString(SQLColumns.ROLE_ID));
		role.setUserRole(rs.getString(SQLColumns.USER_ROLE));
		role.setSms(rs.getBoolean(SQLColumns.SMS));
		role.setEmail(rs.getBoolean(SQLColumns.EMAIL));
		role.setThreshold(rs.getInt(SQLColumns.THRESHOLD));
		role.setThresholdResetValue(rs.getString(SQLColumns.THRESHOLD_REFRESH_VALUE));
		roleDTOs.add(role);
		alert.setUserGroup(roleDTOs);
		alert.setAlarmDescription(rs.getString(SQLColumns.DESCRIPTION));
		alert.setAlarmName(rs.getString(SQLColumns.ALARM_NAME));
		alert.setAlarmId(alarmId);
		roleDTOs.sort(Comparator.comparing(RoleDTO::getRoleId));
		String alarmType = rs.getString(SQLColumns.ALARM_TYPE);
		alert.setAlarmType(alarmType);
		if (alarmType.equals(Constants.AlarmType.SYSTEM))
		    systemAlarmMap.put(alarmId, alert);
		else
		    customAlarmMap.put(alarmId, alert);
	    }
	    company.setSystemAlarmMap(systemAlarmMap);
	    company.setPreDefinedAlarmMap(customAlarmMap);
	    return company;
	} catch (SQLException e) {
	    LOG.error("Error : " + ExceptionUtils.getFullStackTrace(e));
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
    }

    protected CompanyDTO getDefaultAlarmListData(ResultSet rs) throws SystemException, Exception {
	Database database = null;
	String query = SQLConstants.GET_USER_ROLE_LIST;
	CompanyDTO company = new CompanyDTO();
	Map<Integer, AlertDTO> systemAlarmMap = new HashMap<>();
	Map<Integer, AlertDTO> customAlarmMap = new HashMap<>();
	LinkedList<Object> params = new LinkedList<>();
	try {
	    database = new Database();
	    List<RoleDTO> roleList = getDefaultUserGroupData(database.executeQuery(query, params));

	    while (rs.next()) {
		AlertDTO alert = new AlertDTO();
		int alarmId = rs.getInt(SQLColumns.ALARM_ID);
		String alarmType = rs.getString(SQLColumns.ALARM_TYPE);
		alert.setAlarmType(alarmType);
		alert.setAlarmId(alarmId);
		alert.setAlarmName(rs.getString(SQLColumns.ALARM_NAME));
		alert.setAlarmDescription(rs.getString(SQLColumns.DESCRIPTION));
		alert.setUserGroup(roleList);
		if (alarmType.equals(Constants.AlarmType.SYSTEM))
		    systemAlarmMap.put(alarmId, alert);
		else
		    customAlarmMap.put(alarmId, alert);
	    }
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Error : " + e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		e.printStackTrace();
	    }
	}
	company.setSystemAlarmMap(systemAlarmMap);
	company.setPreDefinedAlarmMap(customAlarmMap);
	return company;
    }

    protected static List<RoleDTO> getDefaultUserGroupData(ResultSet rs) throws SQLException {
	List<RoleDTO> roleList = new LinkedList<>();
	while (rs.next()) {
	    RoleDTO role = new RoleDTO();
	    String roleId = rs.getString(SQLColumns.ROLE_ID);
	    role.setRoleId(roleId);
	    role.setUserRole(rs.getString(SQLColumns.USER_ROLE));
	    if (!roleId.equals("0"))
		roleList.add(role);
	}
	return roleList;
    }

    public static void createSiteAlarmDataForExistingSite(CompanyDTO company, UserDTO user, Database database)
	    throws SystemException, Exception {
	try {
	    List<String> siteList = getSitesForBusiness(company.getCompanyId());
	    if (siteList.size() > 0) {
		for (String siteId : siteList) {
		    if (!checkIfPreferenceAlreadyExistForSite(siteId, company.getCompanyId())) {
			CompanyDao.createPreference(company, database, user, siteId);
		    }
		}
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
    }

    public static boolean checkCompanyPreferenceExist(String companyId) throws SystemException, Exception {
	Database database = null;
	try {
	    String query = SQLConstants.CHECK_COMPANY_PREFERENCE_EXIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(companyId);
	    ResultSet rSet = database.executeQuery(query, params);
	    if (rSet.next()) {
		return true;
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static List<String> getSitesForBusiness(String companyId) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_SITES_FOR_BUSINESS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(companyId);
	    List<String> siteList = new LinkedList<>();
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    while (rs.next()) {
		siteList.add(rs.getString(SQLColumns.SITE_ID));
	    }
	    return siteList;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static CompanyDTO getCompanyPreferenceDetails(UserDTO user, String companyId) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_COMPNAY_PREFERENCE_DETAILS;
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(companyId);
	    CompanyDTO company = getCompanyPreferenceData(database.executeQuery(query, params));
	    company.setCompanyId(companyId);
	    return company;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static boolean checkIfPreferenceAlreadyExistForSite(String siteId, String companyId) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.BUSINESS_SITE_PREFERENCE_EXIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(siteId);
	    params.add(companyId);
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		return true;
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static void createPreference(CompanyDTO company, Database database, UserDTO user, String siteId)
	    throws SystemException, Exception {
	try {
	    Map<Integer, AlertDTO> alertMap = company.getSystemAlarmMap();
	    String query = SQLConstants.INSERT_INTO_PREFERENCE_MASTER;
	    LinkedList<Object> params = new LinkedList<>();
	    if (siteId != null && !StringUtils.isEmpty(siteId)) {
		database.createBatch(query);
		List<EquipmentDTO> equipmentList = getEquipmentList(siteId);
		if (equipmentList != null) {
		    for (EquipmentDTO equipment : equipmentList) {
			List<String> machineList = getMachineListForUnit(equipment);
			for (String machineId : machineList) {
			    // "INSERT into preference_master(id,
			    // business_id,site_id, unit_id, machine_id,role_id,
			    // alarm_id, sms, email, threshold,
			    // threshold_refresh_interval,created_by,
			    // created_date, modified_by, modified_date)
			    // VALUES(?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,?,utc_timestamp)"
			    if (alertMap != null && alertMap.size() > 0) {
				for (Integer alertKey : alertMap.keySet()) {
				    for (RoleDTO role : alertMap.get(alertKey).getUserGroup()) {
					String uuid = CommonUtils.guidGenerator(null, null);
					params = new LinkedList<>();
					params.add(uuid);
					params.add(company.getCompanyId());
					params.add(siteId);
					params.add(equipment.getDeviceId());
					params.add(machineId);
					params.add(role.getRoleId());
					params.add(alertMap.get(alertKey).getAlarmId());
					params.add(role.isSms());
					params.add(role.isEmail());
					int threshold = role.getThreshold();
					if (!CommonUtils.thresholdValidation(threshold)) {
					    throw new SystemException(ErrorCodes.INVALID_THRESHOLD,
						    ConfigReader.getObject().getErrorConfig(),
						    ErrorCodes.StatusCodes.BAD_REQUEST, null);
					}
					params.add(threshold);
					params.add(role.getThresholdResetValue());
					params.add(user.getFirstName() + " " + user.getLastName());
					params.add(user.getFirstName() + " " + user.getLastName());
					database.addBatch(query, params);
				    }
				}
			    }
			    Map<Integer, AlertDTO> preDefinedAlarmMap = company.getPreDefinedAlarmMap();
			    // creating predefinedAlarm data
			    if (preDefinedAlarmMap != null && preDefinedAlarmMap.size() > 0) {
				for (Integer alertKey : preDefinedAlarmMap.keySet()) {
				    for (RoleDTO role : preDefinedAlarmMap.get(alertKey).getUserGroup()) {
					String uuid = CommonUtils.guidGenerator(null, null);
					params = new LinkedList<>();
					params.add(uuid);
					params.add(company.getCompanyId());
					params.add(siteId);
					params.add(equipment.getDeviceId());
					params.add(machineId);
					params.add(role.getRoleId());
					params.add(preDefinedAlarmMap.get(alertKey).getAlarmId());
					params.add(role.isSms());
					params.add(role.isEmail());
					int threshold = role.getThreshold();
					if (!CommonUtils.thresholdValidation(threshold)) {
					    throw new SystemException(ErrorCodes.INVALID_THRESHOLD,
						    ConfigReader.getObject().getErrorConfig(),
						    ErrorCodes.StatusCodes.BAD_REQUEST, null);
					}
					params.add(threshold);
					params.add(role.getThresholdResetValue());
					params.add(user.getFirstName() + " " + user.getLastName());
					params.add(user.getFirstName() + " " + user.getLastName());
					database.addBatch(query, params);
				    }
				}
			    }
			}
		    }
		}

	    } else {
		if (alertMap != null && alertMap.size() > 0) {
		    database.createBatch(query);
		    for (Integer alertKey : alertMap.keySet()) {
			for (RoleDTO role : alertMap.get(alertKey).getUserGroup()) {
			    String uuid = CommonUtils.guidGenerator(null, null);
			    params = new LinkedList<>();
			    params.add(uuid);
			    params.add(company.getCompanyId());
			    params.add(siteId);
			    params.add(null);
			    params.add(null);
			    params.add(role.getRoleId());
			    params.add(alertMap.get(alertKey).getAlarmId());
			    params.add(role.isSms());
			    params.add(role.isEmail());
			    int threshold = role.getThreshold();
			    if (!CommonUtils.thresholdValidation(threshold)) {
				throw new SystemException(ErrorCodes.INVALID_THRESHOLD,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
					null);
			    }
			    params.add(threshold);
			    params.add(role.getThresholdResetValue());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    database.addBatch(query, params);
			}
		    }
		}
		Map<Integer, AlertDTO> preDefinedAlarmMap = company.getPreDefinedAlarmMap();
		// creating predefinedAlarm data
		if (preDefinedAlarmMap != null && preDefinedAlarmMap.size() > 0) {
		    for (Integer alertKey : preDefinedAlarmMap.keySet()) {
			for (RoleDTO role : preDefinedAlarmMap.get(alertKey).getUserGroup()) {
			    String uuid = CommonUtils.guidGenerator(null, null);
			    params = new LinkedList<>();
			    params.add(uuid);
			    params.add(company.getCompanyId());
			    params.add(siteId);
			    params.add(null);
			    params.add(null);
			    params.add(role.getRoleId());
			    params.add(preDefinedAlarmMap.get(alertKey).getAlarmId());
			    params.add(role.isSms());
			    params.add(role.isEmail());
			    int threshold = role.getThreshold();
			    if (!CommonUtils.thresholdValidation(threshold)) {
				throw new SystemException(ErrorCodes.INVALID_THRESHOLD,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
					null);
			    }
			    params.add(threshold);
			    params.add(role.getThresholdResetValue());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    database.addBatch(query, params);
			}
		    }
		}
	    }
	    int[] result = database.executeBatch();
	    if (result != null && result.length > 0) {
		for (int i = 0; i < result.length; i++) {
		    if (result[i] != 1) {
			throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		}

	    }
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
    }

    public static void updatePreference(CompanyDTO companyDTO, Database database, UserDTO user) throws Exception {
	try {
	    // update alarm details
	    Map<Integer, AlertDTO> systemAlarmMap = companyDTO.getSystemAlarmMap();
	    Map<Integer, AlertDTO> customAlarmMap = companyDTO.getPreDefinedAlarmMap();
	    LinkedList<Object> params = new LinkedList<>();
	    String query = SQLConstants.HydroAdmin.UPDATE_PREFERENCE_MASTER;
	    // UPDATE preference_master set
	    // role_id=?,alarm_id=?,sms=?,email=?,threshold=?,threshold_refresh_interval=?,
	    // modified_by=?, modified_date=utc_timestamp where id=?
	    if (systemAlarmMap != null && systemAlarmMap.size() > 0) {
		for (Integer alertKey : systemAlarmMap.keySet()) {
		    // check if alarm id exist or not
		    query = SQLConstants.alarms.ALARM_ID_EXISTS;
		    LOG.debug("query>>>>" + query);
		    params = new LinkedList<>();
		    // select equipment_id from EQUIPMENT_MASTER where
		    // equipment_id=?
		    // and site_id=?
		    int alarmId = systemAlarmMap.get(alertKey).getAlarmId();
		    params.add(companyDTO.getCompanyId());
		    params.add(alarmId);
		    ResultSet rs = database.executeQuery(query, params);
		    if (!rs.next()) {
			// creating alarm preference if not exist
			createAlarmPreferenceIfNotExist(companyDTO, database, user, alarmId);
		    }

		    // updating alarm preference
		    query = SQLConstants.HydroAdmin.UPDATE_PREFERENCE_MASTER;
		    database.createBatch(query);
		    for (RoleDTO role : systemAlarmMap.get(alertKey).getUserGroup()) {
			params = new LinkedList<>();
			params.add(role.isSms());
			params.add(role.isEmail());
			int threshold = role.getThreshold();
			if (!CommonUtils.thresholdValidation(threshold)) {
			    throw new SystemException(ErrorCodes.INVALID_THRESHOLD,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
				    null);
			}
			params.add(threshold);
			params.add(role.getThresholdResetValue());
			params.add(user.getFirstName() + " " + user.getLastName());
			params.add(companyDTO.getCompanyId());
			params.add(role.getRoleId());
			params.add(alarmId);
			database.addBatch(query, params);
		    }

		    // executing batch
		    int[] result = database.executeBatch();
		    if (result != null && result.length > 0) {
			for (int i = 0; i < result.length; i++) {
			    if (result[i] < 0) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }
			}

		    }
		}
	    }
	    // processing customAlarmMap data
	    if (customAlarmMap != null && customAlarmMap.size() > 0) {
		for (Integer alertKey : customAlarmMap.keySet()) {
		    // check if alarm id exist or not
		    query = SQLConstants.alarms.ALARM_ID_EXISTS;
		    LOG.debug("query>>>>" + query);
		    params = new LinkedList<>();
		    // select equipment_id from EQUIPMENT_MASTER where
		    // equipment_id=?
		    // and site_id=?
		    int alarmId = customAlarmMap.get(alertKey).getAlarmId();
		    params.add(companyDTO.getCompanyId());
		    params.add(alarmId);
		    ResultSet rs = database.executeQuery(query, params);
		    if (!rs.next()) {
			// creating alarm preference if not exist
			createAlarmPreferenceIfNotExist(companyDTO, database, user, alarmId);
		    }

		    // updating alarm preference
		    query = SQLConstants.HydroAdmin.UPDATE_PREFERENCE_MASTER;
		    database.createBatch(query);
		    for (RoleDTO role : customAlarmMap.get(alertKey).getUserGroup()) {
			params = new LinkedList<>();
			params.add(role.isSms());
			params.add(role.isEmail());
			int threshold = role.getThreshold();
			if (!CommonUtils.thresholdValidation(threshold)) {
			    throw new SystemException(ErrorCodes.INVALID_THRESHOLD,
				    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
				    null);
			}
			params.add(threshold);
			params.add(role.getThresholdResetValue());
			params.add(user.getFirstName() + " " + user.getLastName());
			params.add(companyDTO.getCompanyId());
			params.add(role.getRoleId());
			params.add(customAlarmMap.get(alertKey).getAlarmId());
			database.addBatch(query, params);
		    }
		    // executing batch
		    int[] result = database.executeBatch();
		    if (result != null && result.length > 0) {
			for (int i = 0; i < result.length; i++) {
			    if (result[i] < 0) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }
			}

		    }
		}
	    }
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
    }

    public static List<String> getMachineListForUnit(EquipmentDTO equipment) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_MACHINE_FOR_TUNNEL;
	    if (equipment.getEquipmentType().equals(Constants.EquipmentType.WASHER_EXTRACTOR))
		query = SQLConstants.GET_MACHINE_FOR_WASHER;
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(equipment.getEquipmentId());
	    ResultSet rs = database.executeQuery(query, params);
	    List<String> machineList = new LinkedList<>();
	    while (rs.next()) {
		machineList.add(rs.getString(SQLColumns.LM2_SEQ));
	    }
	    return machineList;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}

    }

    public static List<EquipmentDTO> getEquipmentList(String siteId) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.GET_EQUIPMENT_LIST;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    params.add(siteId);
	    ResultSet rs = database.executeQuery(query, params);
	    List<EquipmentDTO> equipmentList = new LinkedList<>();

	    while (rs.next()) {
		EquipmentDTO equipment = new EquipmentDTO();
		equipment.setEquipmentId(rs.getString(SQLColumns.EQUIPMENT_ID));
		equipment.setEquipmentName(rs.getString(SQLColumns.ALIAS));
		equipment.setDeviceId(rs.getString(SQLColumns.DEVICE_ID));
		equipment.setEquipmentType(rs.getString(SQLColumns.EQUIPMENT_TYPE));
		equipment.setFileId(rs.getString(SQLColumns.FILE_ID));
		equipmentList.add(equipment);
	    }

	    return equipmentList;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    public static void createAlarmPreferenceIfNotExist(CompanyDTO company, Database database, UserDTO user, int alarmId)
	    throws SystemException, Exception {
	try {
	    String query = SQLConstants.alarms.GET_SITE_LIST_FOR_BUSINESS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    String companyId = company.getCompanyId();
	    params.add(companyId);
	    ResultSet rs = database.executeQuery(query, params);
	    query = SQLConstants.GET_USER_ROLE_LIST;
	    params = new LinkedList<>();
	    List<RoleDTO> roleList = getDefaultUserGroupData(database.executeQuery(query, params));
	    query = SQLConstants.INSERT_INTO_PREFERENCE_MASTER;
	    database.createBatch(query);
	    if (roleList != null) {
		while (rs.next()) {
		    String siteId = rs.getString(SQLColumns.SITE_ID);
		    if (siteId != null) {
			List<EquipmentDTO> equipmentList = getEquipmentList(siteId);
			if (equipmentList != null) {
			    for (EquipmentDTO equipment : equipmentList) {
				List<String> machineList = getMachineListForUnit(equipment);
				for (String machineId : machineList) {
				    for (RoleDTO role : roleList) {
					String uuid = CommonUtils.guidGenerator(null, null);
					params = new LinkedList<>();
					params.add(uuid);
					params.add(companyId);
					params.add(siteId);
					params.add(equipment.getDeviceId());
					params.add(machineId);
					params.add(role.getRoleId());
					params.add(alarmId);
					params.add(role.isSms());
					params.add(role.isEmail());
					int threshold = role.getThreshold();
					if (!CommonUtils.thresholdValidation(threshold)) {
					    throw new SystemException(ErrorCodes.INVALID_THRESHOLD,
						    ConfigReader.getObject().getErrorConfig(),
						    ErrorCodes.StatusCodes.BAD_REQUEST, null);
					}
					params.add(threshold);
					params.add(role.getThresholdResetValue());
					params.add(user.getFirstName() + " " + user.getLastName());
					params.add(user.getFirstName() + " " + user.getLastName());
					database.addBatch(query, params);
				    }
				}
			    }
			}
		    } else {
			for (RoleDTO role : roleList) {
			    String uuid = CommonUtils.guidGenerator(null, null);
			    params = new LinkedList<>();
			    params.add(uuid);
			    params.add(companyId);
			    params.add(siteId);
			    params.add(null);
			    params.add(null);
			    params.add(role.getRoleId());
			    params.add(alarmId);
			    params.add(role.isSms());
			    params.add(role.isEmail());
			    int threshold = role.getThreshold();
			    if (!CommonUtils.thresholdValidation(threshold)) {
				throw new SystemException(ErrorCodes.INVALID_THRESHOLD,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
					null);
			    }
			    params.add(threshold);
			    params.add(role.getThresholdResetValue());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    database.addBatch(query, params);
			}
		    }

		}
	    }

	    // executing batch
	    int[] result = database.executeBatch();
	    if (result != null && result.length > 0) {
		for (int i = 0; i < result.length; i++) {
		    if (result[i] < 0) {
			throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE, null);
		    }
		}

	    }

	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
    }

    public LinkedList<Object> getCompanyListOnStartEndDate(CompanyDTO company) {
	String createdStartDate = company.getCreatedDateStart();
	String createdEndDate = company.getCreatedDateEnd();
	LinkedList<Object> params = new LinkedList<>();
	if (createdStartDate != null && createdEndDate != null) {
	    params.add(createdStartDate);
	    params.add(createdEndDate);
	}
	return params;
    }
}
