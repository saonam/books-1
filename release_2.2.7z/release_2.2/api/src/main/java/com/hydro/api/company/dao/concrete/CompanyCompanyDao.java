package com.hydro.api.company.dao.concrete;

import java.sql.SQLException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.company.dao.CompanyDao;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.CompanyDTO;
import com.hydro.api.dto.CompanyListResponseDTO;
import com.hydro.api.dto.ContactDTO;
import com.hydro.api.dto.ContactOperationsDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;

/**
 *
 * @author Shreyas, Srishti
 * 
 */
public class CompanyCompanyDao extends CompanyDao {
    private static final Logger LOG = LoggerFactory.getLogger(CompanyCompanyDao.class);

    @Override
    public CompanyListResponseDTO getCompanyList(UserDTO user, CompanyDTO company) throws Exception {
	Database database = null;
	try {
	    database = new Database();
	    String query = SQLConstants.Company.GET_COMPANY_LIST;
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.BusinessTypes.COMPANY);
	    params.add(user.getAssociationId());
	    if (company.getCreatedDateStart() != null && company.getCreatedDateEnd() != null) {
		query = SQLConstants.Company.GET_COMPANY_LIST_CREATED_DATE_FILTER;
		params.addAll(getCompanyListOnStartEndDate(company));
	    } else if (company.isSortByName()) {
		query = SQLConstants.Company.GET_COMPANY_LIST_SORTED_ON_NAME;
	    }
	    return getCompanyListData(database.executeQuery(query, params), user.getTimeZone());
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean hasVisibility(UserDTO user, CompanyDTO company) throws Exception {
	if (user.getAssociationId().equals(company.getCompanyId())) {
	    return true;
	}
	return false;
    }

    @Override
    public CompanyDTO createCompany(UserDTO user, CompanyDTO company) throws Exception {
	throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		ErrorCodes.StatusCodes.FORBIDDEN, null);
    }

    @Override
    public boolean updateCompany(UserDTO user, CompanyDTO companyDTO) throws Exception {
	if (!user.getAssociationId().equals(companyDTO.getCompanyId())) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	Database database = new Database();
	try {
	    String query = SQLConstants.Company.full.UPDATE_BUSINESS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();

	    params.add(companyDTO.getAddress1());
	    params.add(companyDTO.getAddress2());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(companyDTO.getState());
	    params.add(companyDTO.getCountry());
	    params.add(companyDTO.getCity());
	    params.add(companyDTO.getZipCode());
	    params.add(companyDTO.getDescription());

	    params.add(companyDTO.getCompanyId());
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    if (count > 0) {
		ContactOperationsDTO contactOperations = companyDTO.getContactOperations();
		if (contactOperations != null) {
		    HashSet<String> contactIdList = CompanyDao.getContactAssociatedToCompany(companyDTO);
		    List<ContactDTO> contactUpdate = contactOperations.getUpdateContact();
		    if (contactUpdate != null && contactUpdate.size() > 0) {
			contactIdList = null;
			for (ContactDTO contact : contactUpdate) {
			    contactIdList = CompanyDao.getContactAssociatedToCompany(companyDTO);
			    if (!contactIdList.contains(contact.getContactId())) {
				throw new SystemException(ErrorCodes.INVALID_CONTACT_ID,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
					null);
			    }
			    query = SQLConstants.HydroAdmin.UPDATE_CONTACT_INFO;
			    LOG.debug("query>>>>" + query);
			    params = new LinkedList<>();
			    database.createBatch(query);

			    for (ContactDTO contactDTO : contactUpdate) {
				// UPDATE CONTACT_MASTER SET contact_email =?,
				// contact_name=?, contact_number = ?,
				// contact_title =
				// ?, modified_by =? WHERE contact_id=?
				params = new LinkedList<>();
				params.add(contactDTO.getEmail());
				params.add(contactDTO.getName());
				params.add(contactDTO.getNumber());
				params.add(contactDTO.getTitle());
				params.add(user.getFirstName() + " " + user.getLastName());
				params.add(contactDTO.getContactId());
				database.addBatch(query, params);
			    }
			    int[] result = database.executeBatch();
			    if (result != null && result.length > 0) {
				for (int i = 0; i < result.length; i++) {
				    if (result[i] != 1) {
					throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
						ConfigReader.getObject().getErrorConfig(),
						ErrorCodes.StatusCodes.FAILURE, null);
				    }
				}
			    }
			}
		    }
		    // Check if contactId is associated to site.
		    List<ContactDTO> contactDelete = contactOperations.getDeleteContact();
		    if (contactDelete != null && contactDelete.size() > 0) {
			if (contactIdList == null) {
			    contactIdList = CompanyDao.getContactAssociatedToCompany(companyDTO);
			}
			for (ContactDTO contact : contactDelete) {
			    if (!contactIdList.contains(contact.getContactId())) {
				throw new SystemException(ErrorCodes.INVALID_CONTACT_ID,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
					null);
			    }
			    params = new LinkedList<>();
			    query = SQLConstants.HydroAdmin.DELETE_CONTACT_INFO + " ( "
				    + CommonUtils.generateQueryParams(contactDelete.size()) + " )";
			    LOG.debug("query>>>>" + query);
			    for (ContactDTO contactDTO : contactDelete) {
				params.add(contactDTO.getContactId());
			    }

			    int countDelete = database.executeUpdate(query, params);
			    if (countDelete < 0) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }

			}
		    }

		    // Inserting new Contact Details.
		    List<ContactDTO> contactCreate = contactOperations.getCreateContact();
		    if (contactCreate != null && contactCreate.size() > 0) {

			query = SQLConstants.HydroAdmin.CREATE_CONTACT_INFO;
			LOG.debug("query>>>>" + query);

			// INSERT INTO
			// CONTACT_MASTER(contact_id,business_id,
			// site_id,email,name, number, title,created_by,
			// modified_by) values(?,?,?,?,?,?,?,?,?)
			params = new LinkedList<>();
			database.createBatch(query);
			for (ContactDTO contactDTO : contactCreate) {
			    String uuid = CommonUtils.guidGenerator(null, null);
			    params = new LinkedList<>();
			    params.add(uuid);
			    params.add(companyDTO.getCompanyId());
			    params.add(null);
			    params.add(contactDTO.getEmail());
			    params.add(contactDTO.getName());
			    params.add(contactDTO.getNumber());
			    params.add(contactDTO.getTitle());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    database.addBatch(query, params);
			}
			int[] result = database.executeBatch();
			if (result != null && result.length > 0) {
			    for (int i = 0; i < result.length; i++) {
				if (result[i] != 1) {
				    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					    null);
				}
			    }

			}
		    }

		}
		// create alarm details
		if (!CompanyDao.checkCompanyPreferenceExist(user.getAssociationId())) {
		    CompanyDao.createPreference(companyDTO, database, user, null);
		    createSiteAlarmDataForExistingSite(companyDTO, user, database);
		} else {
		    // update alarm details
		    createSiteAlarmDataForExistingSite(companyDTO, user, database);
		    CompanyDao.updatePreference(companyDTO, database, user);
		}
	    }
	    database.commit();
	    return true;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public String companyNameExists(UserDTO user, CompanyDTO companyDTO) throws Exception {
	String companyId = super.companyNameExists(user, companyDTO);
	if (!user.getAssociationId().equals(companyId)) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	return companyId;
    }

    @Override
    public List<SiteDTO> getSiteList(UserDTO user) throws Exception {
	CompanyDTO company = new CompanyDTO();
	company.setCompanyId(user.getAssociationId());
	return super.getSiteListForCompany(company);
    }

    @Override
    public List<ContactDTO> getContactListForCompany(UserDTO user, CompanyDTO company) throws Exception {
	if (!user.getAssociationId().equals(company.getCompanyId())) {
	    throw new SystemException(ErrorCodes.INSUFFICIENT_PRIVILEGES, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FORBIDDEN, null);
	}
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_CONTACT_LIST_FOR_BUSINESS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(user.getAssociationId());
	    database = new Database();
	    return getCompanyContactData(database.executeQuery(query, params));
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }
}
