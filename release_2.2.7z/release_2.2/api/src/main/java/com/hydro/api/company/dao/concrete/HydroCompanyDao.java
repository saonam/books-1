package com.hydro.api.company.dao.concrete;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.company.dao.CompanyDao;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLColumns;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.CompanyDTO;
import com.hydro.api.dto.CompanyListResponseDTO;
import com.hydro.api.dto.ContactDTO;
import com.hydro.api.dto.ContactOperationsDTO;
import com.hydro.api.dto.SiteDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;

/**
 *
 * @author Shreyas
 * 
 */
public class HydroCompanyDao extends CompanyDao {
    private static final Logger LOG = LoggerFactory.getLogger(HydroCompanyDao.class);

    @Override
    public CompanyListResponseDTO getCompanyList(UserDTO user, CompanyDTO company) throws Exception {
	Database database = null;
	try {
	    database = new Database();
	    String query = SQLConstants.HydroAdmin.GET_COMPANY_LIST;
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.BusinessTypes.COMPANY);
	    if (company.getCreatedDateStart() != null && company.getCreatedDateEnd() != null) {
		query = SQLConstants.HydroAdmin.GET_COMPANY_LIST_CREATED_DATE_FILTER;
		LOG.debug("query>>>>" + query);
		params.addAll(getCompanyListOnStartEndDate(company));
	    } else if (company.isSortByName()) {
		query = SQLConstants.HydroAdmin.GET_COMPANY_LIST_SORTED_ON_NAME;
	    }
	    return getCompanyListData(database.executeQuery(query, params), user.getTimeZone());
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean hasVisibility(UserDTO user, CompanyDTO company) throws Exception {
	return true;
    }

    /**
     * 
     */
    @Override
    public CompanyDTO createCompany(UserDTO user, CompanyDTO company) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.CREATE_COMPANY;
	    // INSERT INTO BUSINESS_MASTER (`business_id`, `name`,
	    // `business_type`,
	    // `address1`, `address2`, `created_by`, `modified_by`, `state`,
	    // country,`city`, `zipcode`, `description`) VALUES (?, ?, ?, ?, ?,
	    // ?, ?, ?, ?, ?, ?, ?)
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    String guid = CommonUtils.guidGenerator(null, null);
	    params.add(guid);
	    params.add(company.getName());
	    params.add(Constants.BusinessTypes.COMPANY);
	    params.add(company.getAddress1());
	    params.add(company.getAddress2());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(company.getState());
	    params.add(company.getCountry());
	    params.add(company.getCity());
	    params.add(company.getZipCode());
	    params.add(company.getDescription());

	    /**
	     * Creating Transaction to incorporate the insertion to Business Master and Site
	     * Business association in batch.
	     */
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    if (count > 0) {
		CompanyDTO companyResponse = new CompanyDTO();
		companyResponse.setCompanyId(guid);
		query = SQLConstants.HydroAdmin.UPDATE_SITE_BUSINESS;
		List<SiteDTO> siteList = company.getSiteList();
		if (siteList != null && siteList.size() > 0) {
		    if (isSiteListPresent(siteList)) {
			for (SiteDTO siteDTO : siteList) {
			    params = new LinkedList<>();
			    params.add(companyResponse.getCompanyId());
			    params.add(siteDTO.getSiteId());
			    int siteCount = database.executeUpdate(query, params);
			    if (siteCount <= 0) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }
			}

		    } else {
			throw new SystemException(ErrorCodes.INVALID_SITE_IN_LIST,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST, null);
		    }
		}
		ContactOperationsDTO contactOperations = company.getContactOperations();
		if (contactOperations != null && contactOperations.getCreateContact() != null
			&& contactOperations.getCreateContact().size() > 0) {
		    List<ContactDTO> contactCreate = contactOperations.getCreateContact();
		    query = SQLConstants.HydroAdmin.CREATE_CONTACT_INFO;
		    LOG.debug("query>>>>" + query);

		    // INSERT INTO
		    // CONTACT_MASTER(contact_id,business_id,
		    // site_id,email,name, number, title,created_by,
		    // modified_by) values(?,?,?,?,?,?,?,?,?)
		    params = new LinkedList<>();
		    database.createBatch(query);
		    for (ContactDTO contactDTO : contactCreate) {
			String uuid = CommonUtils.guidGenerator(null, null);
			params = new LinkedList<>();
			params.add(uuid);
			params.add(guid);
			params.add(null);
			params.add(contactDTO.getEmail());
			params.add(contactDTO.getName());
			params.add(contactDTO.getNumber());
			params.add(contactDTO.getTitle());
			params.add(user.getFirstName() + " " + user.getLastName());
			params.add(user.getFirstName() + " " + user.getLastName());
			database.addBatch(query, params);
		    }
		    int[] result = database.executeBatch();
		    if (result != null && result.length > 0) {
			for (int i = 0; i < result.length; i++) {
			    if (result[i] != 1) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }
			}

		    }
		}

		/// creating alarmMap data
		company.setCompanyId(companyResponse.getCompanyId());
		CompanyDao.createPreference(company, database, user, null);
		database.commit();
		return companyResponse;
	    }

	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (SystemException e) {
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw e;
	} catch (SQLException e) {
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    private boolean isSiteListPresent(List<SiteDTO> siteList) throws Exception {

	Database database = null;
	try {
	    if (siteList == null || siteList.size() <= 0) {
		return false;
	    }
	    String query = SQLConstants.GET_VALID_SITES_COUNT + " ( " + CommonUtils.generateQueryParams(siteList.size())
		    + " )";

	    LinkedList<Object> params = new LinkedList<>();
	    for (SiteDTO site : siteList) {
		String siteId = site.getSiteId();
		if (StringUtils.isEmpty(siteId)) {
		    List<Object> paramsList = new LinkedList<>();
		    paramsList.add(ErrorCodes.InsufficientParams.SITE_ID);
		    throw new SystemException(ErrorCodes.INSUFFICIENT_INFORMATION,
			    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST, paramsList);
		}
		params.add(site.getSiteId());
	    }
	    database = new Database();
	    ResultSet rs = database.executeQuery(query, params);
	    if (rs.next()) {
		int count = rs.getInt(SQLColumns.SITE_COUNT);
		if (count == siteList.size()) {
		    return true;
		}
	    }
	    return false;
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean updateCompany(UserDTO user, CompanyDTO companyDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.UPDATE_BUSINESS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();

	    params.add(companyDTO.getName());
	    params.add(companyDTO.getAddress1());
	    params.add(companyDTO.getAddress2());
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(companyDTO.getState());
	    params.add(companyDTO.getCountry());
	    params.add(companyDTO.getCity());
	    params.add(companyDTO.getZipCode());
	    params.add(companyDTO.getDescription());

	    params.add(companyDTO.getCompanyId());
	    database = new Database();
	    database.setAutoCommitFalse();
	    int count = database.executeUpdate(query, params);
	    if (count > 0) {
		// Setting all the Company originally set to the company is set
		// to empty.
		query = SQLConstants.HydroAdmin.UPDATE_SITE_SPECIFIC_BUSINESS;
		params = new LinkedList<>();
		params.add(null);
		params.add(companyDTO.getCompanyId());
		database.executeUpdate(query, params);

		query = SQLConstants.HydroAdmin.UPDATE_SITE_BUSINESS;
		List<SiteDTO> siteList = companyDTO.getSiteList();
		if (siteList != null && siteList.size() > 0) {
		    if (isSiteListPresent(siteList)) {
			for (SiteDTO siteDTO : siteList) {
			    params = new LinkedList<>();
			    params.add(companyDTO.getCompanyId());
			    params.add(siteDTO.getSiteId());
			    database.executeUpdate(query, params);
			}
		    } else {
			throw new SystemException(ErrorCodes.INVALID_SITE_IN_LIST,
				ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST, null);
		    }

		}
		ContactOperationsDTO contactOperations = companyDTO.getContactOperations();
		if (contactOperations != null) {
		    HashSet<String> contactIdList = CompanyDao.getContactAssociatedToCompany(companyDTO);
		    List<ContactDTO> contactUpdate = contactOperations.getUpdateContact();
		    if (contactUpdate != null && contactUpdate.size() > 0) {
			contactIdList = null;
			for (ContactDTO contact : contactUpdate) {
			    contactIdList = CompanyDao.getContactAssociatedToCompany(companyDTO);
			    if (!contactIdList.contains(contact.getContactId())) {
				throw new SystemException(ErrorCodes.INVALID_CONTACT_ID,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
					null);
			    }
			    query = SQLConstants.HydroAdmin.UPDATE_CONTACT_INFO;
			    LOG.debug("query>>>>" + query);
			    params = new LinkedList<>();
			    database.createBatch(query);

			    for (ContactDTO contactDTO : contactUpdate) {
				// UPDATE CONTACT_MASTER SET contact_email =?,
				// contact_name=?, contact_number = ?,
				// contact_title =
				// ?, modified_by =? WHERE contact_id=?
				params = new LinkedList<>();
				params.add(contactDTO.getEmail());
				params.add(contactDTO.getName());
				params.add(contactDTO.getNumber());
				params.add(contactDTO.getTitle());
				params.add(user.getFirstName() + " " + user.getLastName());
				params.add(contactDTO.getContactId());
				database.addBatch(query, params);
			    }
			    int[] result = database.executeBatch();
			    if (result != null && result.length > 0) {
				for (int i = 0; i < result.length; i++) {
				    if (result[i] != 1) {
					throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
						ConfigReader.getObject().getErrorConfig(),
						ErrorCodes.StatusCodes.FAILURE, null);
				    }
				}
			    }
			}
		    }
		    // Check if contactId is associated to site.
		    List<ContactDTO> contactDelete = contactOperations.getDeleteContact();
		    if (contactDelete != null && contactDelete.size() > 0) {
			if (contactIdList == null) {
			    contactIdList = CompanyDao.getContactAssociatedToCompany(companyDTO);
			}
			for (ContactDTO contact : contactDelete) {
			    if (!contactIdList.contains(contact.getContactId())) {
				throw new SystemException(ErrorCodes.INVALID_CONTACT_ID,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.BAD_REQUEST,
					null);
			    }
			    params = new LinkedList<>();
			    query = SQLConstants.HydroAdmin.DELETE_CONTACT_INFO + " ( "
				    + CommonUtils.generateQueryParams(contactDelete.size()) + " )";
			    LOG.debug("query>>>>" + query);
			    for (ContactDTO contactDTO : contactDelete) {
				params.add(contactDTO.getContactId());
			    }

			    int countDelete = database.executeUpdate(query, params);
			    if (countDelete < 0) {
				throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					null);
			    }

			}
		    }

		    // Inserting new Contact Details.
		    List<ContactDTO> contactCreate = contactOperations.getCreateContact();
		    if (contactCreate != null && contactCreate.size() > 0) {

			query = SQLConstants.HydroAdmin.CREATE_CONTACT_INFO;
			LOG.debug("query>>>>" + query);

			// INSERT INTO
			// CONTACT_MASTER(contact_id,business_id,
			// site_id,email,name, number, title,created_by,
			// modified_by) values(?,?,?,?,?,?,?,?,?)
			params = new LinkedList<>();
			database.createBatch(query);
			for (ContactDTO contactDTO : contactCreate) {
			    String uuid = CommonUtils.guidGenerator(null, null);
			    params = new LinkedList<>();
			    params.add(uuid);
			    params.add(companyDTO.getCompanyId());
			    params.add(null);
			    params.add(contactDTO.getEmail());
			    params.add(contactDTO.getName());
			    params.add(contactDTO.getNumber());
			    params.add(contactDTO.getTitle());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    params.add(user.getFirstName() + " " + user.getLastName());
			    database.addBatch(query, params);
			}
			int[] result = database.executeBatch();
			if (result != null && result.length > 0) {
			    for (int i = 0; i < result.length; i++) {
				if (result[i] != 1) {
				    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION,
					    ConfigReader.getObject().getErrorConfig(), ErrorCodes.StatusCodes.FAILURE,
					    null);
				}
			    }

			}
		    }

		}
		// create alarm details
		if (!CompanyDao.checkCompanyPreferenceExist(companyDTO.getCompanyId())) {
		    CompanyDao.createPreference(companyDTO, database, user, null);
		    createSiteAlarmDataForExistingSite(companyDTO, user, database);
		} else {
		    createSiteAlarmDataForExistingSite(companyDTO, user, database);
		    CompanyDao.updatePreference(companyDTO, database, user);
		}
		database.commit();
		return true;
	    } else {
		throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }

	} catch (SystemException e) {
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw e;
	} catch (SQLException e) {
	    try {
		if (database != null) {
		    database.rollBack();
		}
	    } catch (Exception ex) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(ex));
	    }
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public String companyNameExists(UserDTO user, CompanyDTO companyDTO) throws Exception {
	return super.companyNameExists(user, companyDTO);
    }

    @Override
    public List<SiteDTO> getSiteList(UserDTO user) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_SITES;
	    database = new Database();
	    return getCompanySiteData(database.executeQuery(query, null));
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public List<ContactDTO> getContactListForCompany(UserDTO user, CompanyDTO company) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_CONTACT_LIST_FOR_BUSINESS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(company.getCompanyId());

	    database = new Database();
	    return getCompanyContactData(database.executeQuery(query, params));
	} catch (SystemException e) {
	    LOG.error("Error : " + e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error("Error : " + e.getMessage());
	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		LOG.error("Error : " + e1.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

}
