package com.hydro.api.user.dao.concrete;

import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.dao.Database;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.constants.SQLConstants;
import com.hydro.api.dto.AlertDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.dto.UserListResponseDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.user.dao.UserDao;

/**
 *
 * @author Shreyas, Srishti Tiwari
 * 
 */
public class HydroUserDao extends UserDao {
    private static final Logger LOG = LoggerFactory.getLogger(HydroUserDao.class);

    @Override
    public UserListResponseDTO getAllUserList(UserDTO userDTO, UserDTO targetUser) throws SystemException, Exception {

	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.GET_USER_LIST;
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(userDTO.getUserId());
	    if (targetUser.getCreatedDateStart() != null && targetUser.getCreatedDateEnd() != null) {
		query = SQLConstants.HydroAdmin.GET_USER_LIST_CREATED_DATE_FILTER;
		params.addAll(getUserListOnStartEndDate(targetUser));
	    }
	    LOG.debug("query>>>>" + query);
	    database = new Database();
	    return getUserListFromRs(database.executeQuery(query, params), userDTO.getTimeZone());
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    }

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean deActivateUser(UserDTO user, UserDTO userDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.TOGGLE_ACTIVATE_USER;
	    LOG.debug("query>>>>" + query);
	    // UPDATE USER_MASTER SET is_active=?, modified_by=? WHERE user_id=?
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.ACTIVE_STATE.INACTIVE);
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(userDTO.getUserId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }
	    database.closeConnection();
	    return true;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public boolean activateUser(UserDTO user, UserDTO userDTO) throws Exception {
	Database database = null;
	try {
	    String query = SQLConstants.HydroAdmin.TOGGLE_ACTIVATE_USER;
	    LOG.debug("query>>>>" + query);
	    // UPDATE USER_MASTER SET is_active=?, modified_by=? WHERE user_id=?
	    LinkedList<Object> params = new LinkedList<>();
	    params.add(Constants.ACTIVE_STATE.ACTIVE);
	    params.add(user.getFirstName() + " " + user.getLastName());
	    params.add(userDTO.getUserId());
	    database = new Database();
	    int count = database.executeUpdate(query, params);
	    if (count <= 0) {
		throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.BAD_REQUEST, null);
	    }
	    database.closeConnection();
	    return true;
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {

	    try {
		LOG.error(e.getMessage());
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);

	    } catch (SQLException e1) {
		throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
			ErrorCodes.StatusCodes.FAILURE, null);
	    }
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }

    @Override
    public List<AlertDTO> getUserSpecificPreference(UserDTO user) throws Exception {
	Database database = null;
	ConfigReader config = new ConfigReader();
	// select distinct t1.alarm_id, t1.alarm_name,
	// t1.description,COALESCE(t2.active, true) as active from(Select
	// PM.alarm_id, AM.alarm_name, AM.description, true as active from
	// preference_master PM left join alarm_master AM on
	// AM.alarm_id=PM.alarm_id where (sms is true or email is true) and
	// role_id = ?) t1 Left join (select UAP.alarm_id, active from
	// user_alarm_preference UAP where user_id=? and UAP.alarm_id in (select
	// distinct alarm_id from preference_master where (sms is true or email
	// is true) and role_id=?)) t2 on t1.alarm_id =t2.alarm_id
	try {
	    String query = SQLConstants.HydroAdmin.GET_USER_PREFERENCE_DETAILS;
	    LOG.debug("query>>>>" + query);
	    LinkedList<Object> params = new LinkedList<>();
	    database = new Database();
	    String userId = user.getUserId();
	    String roleId = config.getRoleId(user.getOrgType(), user.getUserRole());
	    params.add(roleId);
	    params.add(userId);
	    params.add(roleId);
	    return UserDao.getUserSpecificPreferenceData(database.executeQuery(query, params), user.getAssociationId());
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    throw e;
	} catch (SQLException e) {
	    LOG.error(e.getMessage());
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);

	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.GENERIC_EXCEPTION, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	} finally {
	    try {
		if (database != null) {
		    database.closeConnection();
		}
	    } catch (Exception e) {
		LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    }
	}
    }
}
