package com.hydro.api.reports.business;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;
import com.hydro.api.dto.BatchDTO;

public class BatchDTOJsonSerializer implements JsonSerializer<BatchDTO> {

    @Override
    public JsonElement serialize(BatchDTO batch, Type typeOfSrc, JsonSerializationContext context) {
	// TODO Auto-generated method stub
	JsonObject jsonObj = new JsonObject();
	jsonObj.add("batchId", context.serialize(batch.getBatchId()));
	jsonObj.add("runTime", context.serialize(batch.getRunTime()));
	jsonObj.add("formulaId", context.serialize(batch.getFormulaId()));
	jsonObj.add("formulaName", context.serialize(batch.getFormulaName()));
	jsonObj.add("lbsWashed", context.serialize(batch.getLbsWashed()));
	jsonObj.add("startDate", context.serialize(batch.getStartDate()));
	jsonObj.add("endDate", context.serialize(batch.getEndDate()));
	jsonObj.add("totalMlReal", context.serialize(batch.getTotalMlActual()));
	jsonObj.add("totalMlEstimated", context.serialize(batch.getTotalMlEstimated()));
	jsonObj.add("eventList", context.serialize(batch.getEventList()));
	return jsonObj;
    }

}
