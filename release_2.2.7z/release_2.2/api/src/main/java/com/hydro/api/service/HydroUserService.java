package com.hydro.api.service;

import java.security.Principal;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.StatusDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.dto.UserListResponseDTO;
import com.hydro.api.dto.UserPreferenceResponseDTO;
import com.hydro.api.exception.ExceptionHandler;
import com.hydro.api.exception.SystemException;
import com.hydro.api.service.helper.ServiceHelper;
import com.hydro.api.user.business.HydroUserBL;

/**
 * Base Service : Entry Point to the JSON APIs.
 * 
 * @author Shreyas
 *
 */
// No Base context root for the Services. Each services have their respective
// Endpoints.
@Path("/user")
@Produces({ MediaType.APPLICATION_JSON })
public class HydroUserService extends HydroBaseService {

    private static final Logger LOG = LoggerFactory.getLogger(HydroUserService.class);
    @Context
    SecurityContext securityContext;

    public HydroUserService(@Context SecurityContext securityContext,
	    @HeaderParam(Constants.TIME_ZONE_HEADER) String timeZone) throws Exception {
	super();
	Principal principal = securityContext.getUserPrincipal();
	String username = principal.getName();
	BL = new HydroUserBL(username, timeZone);
    }

    /**
     * Test API.
     * 
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/test")
    public String test() {
	long start = System.currentTimeMillis();
	resStr = "{\"message\":\"User APIs Works Fine!\"}";
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * Testing the DB connection.
     * 
     * @return
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/testDbConnection")
    public String testDbConnection() {
	long start = System.currentTimeMillis();

	try {
	    BL.initRoutine();
	    // Check for the Database connection.
	    boolean flag = ((HydroUserBL) BL).testUserDbConnection();
	    if (flag) {
		resStr = "{ \"connected\":true}";
	    } else {
		resStr = "{ \"connected\":false}";
	    }
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    /**
     * Get User List
     * 
     * @throws Exception
     */
    @GET
    @Path("/getUserList")
    @Produces(MediaType.APPLICATION_JSON)

    public String getUserList(@QueryParam("createdStartDate") String createdStartDate,
	    @QueryParam("createdEndDate") String createdEndDate) {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    UserDTO user = new UserDTO(createdEndDate, createdStartDate);
	    UserListResponseDTO userListResponse = ((HydroUserBL) BL).getUserList(user);
	    responseDTO.setResponseObject(userListResponse);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;

    }

    @POST
    @Path("/createUser")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String createUser(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    UserDTO usertDTO = (UserDTO) ServiceHelper.buildJsonString(body, UserDTO.class);
	    usertDTO = ((HydroUserBL) BL).createUser(usertDTO);
	    responseDTO.setResponseObject(usertDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/userSignInNameExists")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String userSignInNameExists(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    UserDTO usertDTO = (UserDTO) ServiceHelper.buildJsonString(body, UserDTO.class);
	    Boolean response = ((HydroUserBL) BL).userSignInNameExists(usertDTO);
	    responseDTO.setResponseObject(response);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @PUT
    @Path("/updateUser")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String updateUser(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    UserDTO usertDTO = (UserDTO) ServiceHelper.buildJsonString(body, UserDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroUserBL) BL).updateUser(usertDTO));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;

    }

    @PUT
    @Path("/deActivateUser")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String deActivateUser(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    UserDTO usertDTO = (UserDTO) ServiceHelper.buildJsonString(body, UserDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroUserBL) BL).deActivateUser(usertDTO));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;

    }

    @PUT
    @Path("/activateUser")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String activateUser(String body) throws Exception {
	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    UserDTO usertDTO = (UserDTO) ServiceHelper.buildJsonString(body, UserDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroUserBL) BL).activateUser(usertDTO));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;

    }

    @POST
    @Path("/emailExists")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String emailExists(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    UserDTO userDTO = (UserDTO) ServiceHelper.buildJsonString(body, UserDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus(((HydroUserBL) BL).emailExists(userDTO));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/getUserDetails")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getUserDetails(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    UserDTO user = (UserDTO) ServiceHelper.buildJsonString(body, UserDTO.class);
	    user = (((HydroUserBL) BL).getUserDetails(user));
	    responseDTO.setResponseObject(user);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @GET
    @Path("/getUserPreferenceDetails")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String getUserAlarmDetails() throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();

	    UserPreferenceResponseDTO userResponse = (((HydroUserBL) BL).getUserPreferenceDetails());
	    responseDTO.setResponseObject(userResponse);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/updateUserPreference")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String updateUserPreference(String body) throws Exception {

	long start = System.currentTimeMillis();
	try {
	    BL.initRoutine();
	    UserPreferenceResponseDTO user = (UserPreferenceResponseDTO) ServiceHelper.buildJsonString(body,
		    UserPreferenceResponseDTO.class);
	    StatusDTO statusDTO = new StatusDTO();
	    statusDTO.setStatus((((HydroUserBL) BL).updateUserPreference(user)));
	    responseDTO.setResponseObject(statusDTO);
	    responseDTO.setResponseStatus(true);
	    resStr = ServiceHelper.buildJsonString(responseDTO);

	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}
	recordTime(start, resStr);
	return resStr;
    }

}
