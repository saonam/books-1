package com.hydro.api.service;

import java.time.LocalDateTime;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializer;
import com.hydro.api.config.ConfigurationDTO;
import com.hydro.api.config.ConfigurationResponse;
import com.hydro.api.config.EventsExtractResponse;
import com.hydro.api.config.business.InterfaceConfigServiceBL;
import com.hydro.api.dto.BatchDTO;
import com.hydro.api.dto.ExceptionResponseDTO;
import com.hydro.api.dto.ShiftDTO;
import com.hydro.api.dto.reports.CycleDTO;
import com.hydro.api.dto.reports.DataRequestDTO;
import com.hydro.api.dto.reports.EventsDTO;
import com.hydro.api.event.business.HydroEventBL;
import com.hydro.api.exception.SystemException;
import com.hydro.api.reports.business.BatchDTOJsonSerializer;
import com.hydro.api.reports.business.CycleDTOJsonSerializer;
import com.hydro.api.reports.business.DataRequestProcessor;
import com.hydro.api.reports.business.DataRequestProcessorFactory;
import com.hydro.api.reports.business.DataRequestProcessorFactory.RequestProcessor;
import com.hydro.api.reports.business.EventsDTOJsonSerializer;
import com.hydro.api.service.helper.ServiceHelper;

/**
 * ----------------------------------------------------------------------
 * IMPORTANT NOTE: This Service should hold only the APIs accessed by external
 * interfaces Only Daemon applications - Non User based.
 * 
 * -----------------------------------------------------------------------
 * BaseService : Entry Point to the JSON APIs.
 * 
 * @author Khader
 *
 */
// No Base context root for the Services. Each services have their respective
// Endpoints.
@Path("/interface")
@Produces({ MediaType.APPLICATION_JSON })
public class HydroInterfaceService extends HydroBaseService {

    private static final Logger LOG = LoggerFactory.getLogger(HydroInterfaceService.class);
    private static final JsonSerializer<LocalDateTime> SER = (dateTime, typeOfSrc, context) -> dateTime == null ? null
	    : new JsonPrimitive(dateTime.toString());
    private Gson dailyEventsGson;

    public HydroInterfaceService() throws Exception {
	super();
	BL = new HydroEventBL();
	
	dailyEventsGson = new GsonBuilder().registerTypeAdapter(LocalDateTime.class, SER)
		.registerTypeAdapter(BatchDTO.class, new BatchDTOJsonSerializer())
		.registerTypeAdapter(EventsDTO.class, new EventsDTOJsonSerializer())
		.registerTypeAdapter(CycleDTO.class, new CycleDTOJsonSerializer())
		.create();
    }

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/test")
    public String test() {
	long start = System.currentTimeMillis();
	resStr = "{\"message\":\"Interface APIs Works Fine!\"}";
	recordTime(start, resStr);
	return resStr;
    }

    @POST
    @Path("/dailyEventsData")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response dailyEventsData(String body) throws Exception {

	LOG.debug("dailyEventsData - body:::::::" + body);
	long start = System.currentTimeMillis();
	Response response = null;
	try {

	    DataRequestDTO requestDTO = (DataRequestDTO) ServiceHelper.buildJsonString(body, DataRequestDTO.class);

	    DataRequestProcessor requestProcessor = DataRequestProcessorFactory
		    .getRequestProcessor(RequestProcessor.DAYWISE);
	    Object data = requestProcessor.getData(requestDTO, null);
	    
	    EventsExtractResponse eventsExtract = new EventsExtractResponse();
	    eventsExtract.setEventsExtract((ShiftDTO) data);
	    
	    response = Response.status(Status.OK).entity(ServiceHelper.buildJsonString(eventsExtract, dailyEventsGson)).build();

	} catch (SystemException e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    ExceptionResponseDTO errorResponse = new ExceptionResponseDTO(e.getMessage(), e.getParams());
	    return Response.status(Status.fromStatusCode(Integer.valueOf(e.getStatus()))).entity(ServiceHelper.buildJsonString(errorResponse)).build();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    ExceptionResponseDTO errorResponse = new ExceptionResponseDTO(Status.INTERNAL_SERVER_ERROR.getReasonPhrase());
	    return Response.status(Status.INTERNAL_SERVER_ERROR).entity(ServiceHelper.buildJsonString(errorResponse)).build();
	}
	recordTime(start, resStr);
	return response;
    }

    @POST
    @Path("/exportConfiguration")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response exportConfiguration(String body) throws Exception {
	long start = System.currentTimeMillis();
	Response response = null;
	try {

	    DataRequestDTO requestDTO = (DataRequestDTO) ServiceHelper.buildJsonString(body, DataRequestDTO.class);
	    
	    ConfigurationDTO configuration = InterfaceConfigServiceBL.getInstance().getConfiguration(requestDTO);
	    
	    ConfigurationResponse configResponse = new ConfigurationResponse();
	    configResponse.setSiteconfiguration(configuration);
	    
	    response = Response.status(Status.OK).entity(ServiceHelper.buildJsonString(configResponse)).build();

	} catch (SystemException e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    ExceptionResponseDTO errorResponse = new ExceptionResponseDTO(e.getMessage(), e.getParams());
	    return Response.status(Status.fromStatusCode(Integer.valueOf(e.getStatus()))).entity(ServiceHelper.buildJsonString(errorResponse)).build();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    ExceptionResponseDTO errorResponse = new ExceptionResponseDTO(Status.INTERNAL_SERVER_ERROR.getReasonPhrase());
	    return Response.status(Status.INTERNAL_SERVER_ERROR).entity(ServiceHelper.buildJsonString(errorResponse)).build();
	}
	recordTime(start, resStr);
	return response;
    }

}
