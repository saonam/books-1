package com.hydro.api.service;

import java.security.Principal;
import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.SecurityContext;

import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.config.business.ConfigServiceBL;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.ResponseStatusDTO;
import com.hydro.api.exception.ExceptionHandler;
import com.hydro.api.exception.SystemException;
import com.hydro.api.service.helper.ServiceHelper;
import com.google.gson.Gson;

@Path("/config")
@Produces({ MediaType.APPLICATION_JSON })
public class HydroConfigService extends HydroBaseService {

    private static Logger LOG = LoggerFactory.getLogger(HydroConfigService.class);

    @Context
    SecurityContext securityContext;

    private Gson gson = new Gson();

    public HydroConfigService(@Context SecurityContext securityContext,
	    @HeaderParam(Constants.TIME_ZONE_HEADER) String timeZone) throws Exception {
	super();
	Principal principal = securityContext.getUserPrincipal();
	String username = principal.getName();
	BL = new ConfigServiceBL(username, timeZone);
    }

    @PUT
    @Path("/updateDeviceCache")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public String updateDeviceCache(String body) throws Exception {
	long start = System.currentTimeMillis();

	ResponseStatusDTO responseEntity = new ResponseStatusDTO();

	try {

	    BL.initRoutine();

	    responseEntity = ((ConfigServiceBL) BL).updateDeviceCache(body);
	    resStr = ServiceHelper.buildJsonString(responseEntity);
	} catch (SystemException e) {
	    LOG.error(e.getMessage());
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(e, errorMessages));
	    e.printStackTrace();
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    SystemException ex = new SystemException(e, ErrorCodes.GENERIC_EXCEPTION, errorMessages,
		    ErrorCodes.StatusCodes.FAILURE, null);
	    resStr = ServiceHelper.buildJsonString(ExceptionHandler.getServiceResponseErrorMessage(ex, errorMessages));
	}

	recordTime(start, resStr);

	return resStr;
    }

}
