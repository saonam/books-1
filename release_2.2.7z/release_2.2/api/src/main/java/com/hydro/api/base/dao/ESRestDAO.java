package com.hydro.api.base.dao;

import java.lang.reflect.Field;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.http.Header;
import org.apache.http.HttpHost;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.action.DocWriteRequest;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.bytes.BytesArray;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.rest.RestStatus;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.base.common.ConfigReader;
import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.constants.Constants;
import com.hydro.api.constants.Constants.BULK_STATE;
import com.hydro.api.constants.ErrorCodes;
import com.hydro.api.dto.BulkResponseDTO;
import com.hydro.api.dto.EsErrorLogDTO;
import com.hydro.api.dto.UserDTO;
import com.hydro.api.exception.SystemException;
import com.hydro.api.site.dao.SiteDao;

/**
 * Data Access Layer for Elastic Search
 * 
 * @author Shreyas K C
 *
 * 
 */
public class ESRestDAO {
    private static Logger LOG = LoggerFactory.getLogger(ESRestDAO.class);
    RestHighLevelClient client;
    private static int retryCount;
    private static int retryTime = 30000;
    private BulkRequest bulkBuilder;

    /**
     * private Constructor.
     * 
     * @throws Exception
     */
    public ESRestDAO() throws Exception {

	// retryCount = config.getRetryCount();
	ConfigReader configReader = ConfigReader.getObject();
	String[] esHosts = configReader.getAppConfig(Constants.ES_HOST_NAMES).split(",");
	String[] esPorts = configReader.getAppConfig(Constants.ES_PORTS).split(",");
	String esScheme = configReader.getAppConfig(Constants.ES_SCHEME);
	String username = configReader.getAppConfig(Constants.ES_USERNAME);
	String password = configReader.getAppConfig(Constants.ES_PASSWORD);
	if (esHosts.length != esPorts.length) {
	    LOG.error("The number of hosts is not equal to the number of ports for ES.");
	    throw new SystemException(ErrorCodes.RESOURCE_NOT_AVAILABLE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}
	HttpHost[] hosts = new HttpHost[esHosts.length];
	for (int i = 0; i < hosts.length; i++) {
	    hosts[i] = new HttpHost(esHosts[i], Integer.parseInt(esPorts[i]), esScheme);
	}
	String basicAuth = CommonUtils.getBasicAuthentication(username, password);
	Header[] headers = { new BasicHeader(Constants.AUTHORIZATION, "Basic " + basicAuth) };
	client = new RestHighLevelClient(RestClient.builder(hosts).setDefaultHeaders(headers));
	SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();

    }

    /**
     * Method returning the Singleton Instance.
     * 
     * @param isTest
     * @return
     */

    /**
     * Saves the json to ES
     * 
     * @param payload   - json
     * @param id        - id of the document
     * @param type      - index type
     * @param indexName - indexName
     */

    public void closeRestClient() {
	try {
	    bulkBuilder = null;
	    client.close();
	} catch (Exception e) {
	    LOG.error("Error closing jest client : " + e.getMessage());
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	}
    }

    /**
     * Common method to Retry
     * 
     * @param count
     * @return
     */
    public boolean retry(int count) {
	if (count >= retryCount) {
	    LOG.error("Exceeded the number of retries..." + retryCount + " hence aborting connection to ES.");
	    return false;
	}
	// Increments 30 Second for every retry.
	int delayTime = count * retryTime;
	LOG.info("Max ES Retry Count :" + retryCount);
	LOG.info("Sleeping for " + delayTime + "seconds before connecting to elastic search");
	LOG.info("Retrying for the " + count + " time. Delay time: " + delayTime);
	try {
	    Thread.sleep(delayTime);
	} catch (InterruptedException e) {
	    e.printStackTrace();
	    LOG.error("Exception : " + e.getLocalizedMessage());
	    return false;
	}
	return true;
    }

    /**
     * Prepares the bulk body to be inserted into Elasticsearch
     * 
     * @param esIndex
     * @param esType
     * @param id
     * @param toJson
     * @throws Exception
     * @throws SystemException
     */

    public void prepareBulk(String esIndex, String esType, String id, String toJson, boolean updateIfExists)
	    throws Exception {
	IndexRequest request = new IndexRequest(esIndex, esType, id);
	request.source(toJson, XContentType.JSON);
	if (!updateIfExists) {
	    request.opType(DocWriteRequest.OpType.CREATE);
	}
	if (bulkBuilder == null) {
	    bulkBuilder = new BulkRequest();
	}
	try {
	    bulkBuilder.add(request);
	} catch (Exception e) {
	    LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
	    throw new SystemException(ErrorCodes.FAILED_DURING_DATA_STORAGE, ConfigReader.getObject().getErrorConfig(),
		    ErrorCodes.StatusCodes.FAILURE, null);
	}

    }

    public BulkResponseDTO executeBulk(String siteId, String fileId, UserDTO user) throws Exception {
	BulkResponseDTO bulkResponseDTO = new BulkResponseDTO();
	LinkedList<EsErrorLogDTO> conflictsList = new LinkedList<EsErrorLogDTO>();

	BulkResponse bulkResponse = client.bulk(bulkBuilder);
	int bulkSize = bulkBuilder.numberOfActions();
	int count = 0;
	StringBuilder conflicts = new StringBuilder();
	if (bulkResponse.hasFailures()) {
	    for (BulkItemResponse bulkItemResponse : bulkResponse) {
		if (bulkItemResponse.isFailed()) {
		    BulkItemResponse.Failure failure = bulkItemResponse.getFailure();
		    EsErrorLogDTO errorLogDTO = new EsErrorLogDTO();
		    String document = "";
		    String indexName = "";
		    String typeName = "";
		    try {
			document = bulkBuilder.requests().get(bulkItemResponse.getItemId()).toString();
			try {
			    DocWriteRequest obj = bulkBuilder.requests().get(bulkItemResponse.getItemId());
			    Field f = obj.getClass().getDeclaredField(Constants.SOURCE);
			    f.setAccessible(true);
			    BytesArray byteArray = (BytesArray) f.get(obj);
			    String val = new String(byteArray.array());
			    val = val.trim();
			    if (!StringUtils.isEmpty(val)) {
				document = val;
			    }
			} catch (Exception e) {
			    LOG.error("Error Extracting the document : " + e.getMessage());
			}
			indexName = bulkItemResponse.getIndex();

			typeName = bulkBuilder.requests().get(bulkItemResponse.getItemId()).type();
		    } catch (Exception e) {
			LOG.error("Error extracting ES Error : " + e.getMessage());
			LOG.error("Stack Trace : " + ExceptionUtils.getFullStackTrace(e));
		    }
		    errorLogDTO.setEsDocument(document);
		    errorLogDTO.setIndexName(indexName);
		    errorLogDTO.setEsType(typeName);
		    errorLogDTO.setFileId(fileId);
		    errorLogDTO.setSiteId(siteId);
		    errorLogDTO.setEsError(failure.getMessage());
		    errorLogDTO.setErrorType(failure.getStatus().toString());
		    if (RestStatus.CONFLICT == failure.getStatus()) {
			conflicts.append("Error inserting document. Error Message : " + errorLogDTO.getEsError() + "\n"
				+ "Error Type : " + errorLogDTO.getErrorType() + "\n" + "Index Name : "
				+ errorLogDTO.getIndexName() + "\n" + "Type Name : " + errorLogDTO.getEsType() + "\n"
				+ "Document Failed : " + errorLogDTO.getEsDocument());
			// conflictsList.add(errorLogDTO);
		    }
		    String[] indexNameArray = indexName.split("-");
		    errorLogDTO.setMonth(Integer.parseInt(indexNameArray[indexNameArray.length - 2]));
		    errorLogDTO.setYear(Integer.parseInt(indexNameArray[indexNameArray.length - 1]));

		    if (RestStatus.CONFLICT != failure.getStatus()) {
			count++;
			if (bulkItemResponse.getOpType() == DocWriteRequest.OpType.INDEX
				|| bulkItemResponse.getOpType() == DocWriteRequest.OpType.CREATE) {
			    errorLogDTO.setDescription(Constants.ES_ERROR_DESCRIPTION.CREATE);
			    SiteDao.insertEsErrorLog(errorLogDTO, user);
			} else if (bulkItemResponse.getOpType() == DocWriteRequest.OpType.UPDATE) {

			} else if (bulkItemResponse.getOpType() == DocWriteRequest.OpType.DELETE) {

			}
		    }
		}

	    }
	}
	// Creating new bulk request.
	bulkBuilder = new BulkRequest();
	if (count == bulkSize) {
	    bulkResponseDTO.setBulkState(BULK_STATE.FAILED);
	} else if (count > 0) {
	    bulkResponseDTO.setBulkState(BULK_STATE.PARTIAL_SUCCESS);
	} else {
	    bulkResponseDTO.setBulkState(BULK_STATE.SUCCESS);
	}
	bulkResponseDTO.setConflicts(conflicts.toString());
	// bulkResponseDTO.setConflictsList(conflictsList);
	return bulkResponseDTO;
    }

    public List<String> getIndexForSite(String catIndicesIndex) throws Exception {
	Response response = client.getLowLevelClient().performRequest(Constants.GET_METHOD,
		Constants.CAT_INDICES + catIndicesIndex + Constants.JSON_FORMAT);
	String rawBody = null;
	if (response != null)
	    rawBody = EntityUtils.toString(response.getEntity());
	return ReportUtils.processingESResponse(rawBody);
    }

    public static void main(String args[]) throws Exception {
	ESRestDAO esDAO = new ESRestDAO();
	String payload = "{\"key\":1,\"val\":\"hello\"}";
	esDAO.prepareBulk("test-2-1", "test", "1", payload, false);
	payload = "{\"key\":2,\"val\":\"hello2\"}";
	esDAO.prepareBulk("test-2-1", "test", "2", payload, false);
	payload = "{\"key\":3,\"val\":\"hello3\"}";
	esDAO.prepareBulk("test-2-1", "test", "3", payload, false);
	payload = "{\"key\":1,\"val\":\"hello4\"}";
	esDAO.prepareBulk("test-2-1", "test", "1", payload, false);
	payload = "{\"key\":4,\"val\":\"hello4\"}";
	esDAO.prepareBulk("test-2-1", "test", "4", payload, false);
	UserDTO user = new UserDTO();
	esDAO.executeBulk("siteId", "fileId", user);
    }
}
