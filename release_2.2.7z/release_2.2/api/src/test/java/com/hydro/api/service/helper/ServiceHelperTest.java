package com.hydro.api.service.helper;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

/**
 * 
 * @author Shreyas
 *
 */

public class ServiceHelperTest {
    class TestObject {
	String keyName;
    }

    @Test
    public void testBuildJsonString() throws Exception {
	TestObject tObject = new TestObject();
	tObject.keyName = "Value";
	String expected = "{\"keyName\":\"Value\"}";
	String actual = ServiceHelper.buildJsonString(tObject);
	assertEquals(expected, actual);
    }

}
