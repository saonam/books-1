package com.hydro.api.common;

/**
 * 
 */
import static org.junit.Assert.assertEquals;

import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

import org.junit.Test;

import com.hydro.api.base.common.ReportUtils;
import com.hydro.api.dto.reports.FormulaDTO;
import com.hydro.api.service.helper.ServiceHelper;

/**
 * Validate the hashed password generated using getHashPassword() 
 */

/**
 * @author Shreyas
 *
 */
public class ReportUtilsTest {

    /**
     * 
     * @throws Exception
     */

    @Test
    public void testGetformulaName() throws Exception {
	String formula = "11_formula";
	String expected = ReportUtils.getformulaName(formula);
	String actual = formula;
	assertEquals(expected, actual);

	formula = "1_formula";
	expected = ReportUtils.getformulaName(formula);
	actual = "0" + formula;
	assertEquals(expected, actual);

	formula = "";
	expected = ReportUtils.getformulaName(formula);
	actual = formula;
	assertEquals(expected, actual);

	formula = null;
	expected = ReportUtils.getformulaName(formula);
	actual = formula;
	assertEquals(expected, actual);

	formula = "1formula";
	expected = ReportUtils.getformulaName(formula);
	actual = formula;
	assertEquals(expected, actual);
    }

    @Test
    public void testSortedFormulaName() throws Exception {
	List<FormulaDTO> formulaList = new LinkedList<>();
	FormulaDTO formulaDTO = new FormulaDTO();
	String formula = "1_formula";
	formula = ReportUtils.getformulaName(formula);
	formulaDTO.setFormulaName(formula);
	formulaList.add(formulaDTO);

	formulaDTO = new FormulaDTO();
	formula = "11_formula";
	formula = ReportUtils.getformulaName(formula);
	formulaDTO.setFormulaName(formula);
	formulaList.add(formulaDTO);

	formulaDTO = new FormulaDTO();
	formula = "2_formula";
	formula = ReportUtils.getformulaName(formula);
	formulaDTO.setFormulaName(formula);
	formulaList.add(formulaDTO);

	formulaDTO = new FormulaDTO();
	formula = "1_aformula";
	formula = ReportUtils.getformulaName(formula);
	formulaDTO.setFormulaName(formula);
	formulaList.add(formulaDTO);
	formulaDTO = new FormulaDTO();
	formula = "10_formula";
	formula = ReportUtils.getformulaName(formula);
	formulaDTO.setFormulaName(formula);
	formulaList.add(formulaDTO);

	formulaList.sort(Comparator.comparing(FormulaDTO::getFormulaName));
	String actual = ServiceHelper.buildJsonString(formulaList);
	String expected = "[{\"formulaName\":\"01_aformula\"},{\"formulaName\":\"01_formula\"},{\"formulaName\":\"02_formula\"},{\"formulaName\":\"10_formula\"},{\"formulaName\":\"11_formula\"}]";
	assertEquals(expected, actual);
    }

    @Test
    public void testProcessingESResponse() throws Exception {
	String json = "[{\"health\":\"green\",\"status\":\"open\",\"index\":\"hydro-d3f9f980c28143c3a2f56ccce0daa7d3-3-2017\",\"uuid\":\"8Q3l6UAsS46p8aDrF3tTqA\",\"pri\":\"3\",\"rep\":\"1\",\"docs.count\":\"12726\",\"docs.deleted\":\"0\",\"store.size\":\"11mb\",\"pri.store.size\":\"5.5mb\"},{\"health\":\"green\",\"status\":\"open\",\"index\":\"hydro-d3f9f980c28143c3a2f56ccce0daa7d3-4-2017\",\"uuid\":\"8Q3l6UAsS46p8aDrF3tTqA\",\"pri\":\"3\",\"rep\":\"1\",\"docs.count\":\"12726\",\"docs.deleted\":\"0\",\"store.size\":\"11mb\",\"pri.store.size\":\"5.5mb\"}]";
	List<String> expected = ReportUtils.processingESResponse(json);
	List<String> actual = new LinkedList<>();
	actual.add("hydro-d3f9f980c28143c3a2f56ccce0daa7d3-3-2017");
	actual.add("hydro-d3f9f980c28143c3a2f56ccce0daa7d3-4-2017");
	assertEquals(expected, actual);
    }

    @Test
    public void testBitPositions() throws Exception {
	List<Integer> expectedBitList = new LinkedList<>();
	expectedBitList.add(1);
	expectedBitList.add(2);
	expectedBitList.add(3);
	List<Integer> actualBitList = ReportUtils.bitPositions(7);
	assertEquals(expectedBitList, actualBitList);
    }

}
