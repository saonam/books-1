package com.hydro.api.common;

/**
 * 
 */
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.joda.time.Interval;
import org.jose4j.jwk.HttpsJwks;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;
import org.jose4j.keys.resolvers.HttpsJwksVerificationKeyResolver;
import org.junit.Test;

import com.hydro.api.base.common.CommonUtils;
import com.hydro.api.constants.Constants;
import com.hydro.api.dto.MetaDataDTO;
import com.hydro.api.dto.MetricDTO;
import com.hydro.api.dto.PermissionDTO;
import com.hydro.api.dto.RoleDTO;
import com.hydro.api.service.helper.ServiceHelper;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;

/**
 * Validate the hashed password generated using getHashPassword() 
 */

/**
 * @author Shreyas
 *
 */
public class CommonUtilsTest {

    /**
     * 
     * @throws Exception
     */

    @Test
    public void testGetJWTToken() throws Exception {
	Map<String, Object> claim = new LinkedHashMap<>();
	claim.put("userId", 123);
	claim.put("userType", "HydroAdmin");
	claim.put("isActive", true);
	long currMs = System.currentTimeMillis();
	Date expiry = new Date(currMs + 1000);

	String jwt = CommonUtils.generateJWTToken(claim, expiry, "Subject");
	assertNotNull(jwt);
    }

    @Test
    public void testGetClaims() throws Exception {
	Map<String, Object> claim = new LinkedHashMap<>();
	claim.put("userId", 123);
	claim.put("userType", "HydroAdmin");
	claim.put("isActive", true);
	long currMs = System.currentTimeMillis();
	Date expiry = new Date(currMs + 1000);

	String jwt = CommonUtils.generateJWTToken(claim, expiry, "Subject");
	Jws<Claims> claims = CommonUtils.getClaims(jwt);
	int userId = (int) claims.getBody().get("userId");
	String userType = (String) claims.getBody().get("userType");
	boolean active = (boolean) claims.getBody().get("isActive");
	assertEquals(123, userId);
	assertEquals("HydroAdmin", userType);
	assertTrue(active);
	assertNotNull(jwt);
    }

    @Test
    public void testGuidConsistenct() throws Exception {
	String expected = CommonUtils.guidGenerator(null, null);
	String actual = CommonUtils.guidGenerator(null, null);
	assertNotEquals(expected, actual);
    }

    @Test
    public void testUserNamePattern() throws Exception {
	boolean expected = CommonUtils.userNamePattern(null);
	boolean actual = false;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("Abc");
	actual = false;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("abc");
	actual = true;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("");
	actual = false;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("abc1");
	actual = true;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("abc1ab");
	actual = true;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("a1");
	actual = true;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("aa1bca1aa");
	actual = true;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("a1bca1");
	actual = true;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("1bca1aa");
	actual = false;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("1");
	actual = false;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("abc1!");
	actual = false;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("abc!");
	actual = false;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("abc ");
	actual = false;
	assertEquals(expected, actual);

	expected = CommonUtils.userNamePattern("abc a");
	actual = false;
	assertEquals(expected, actual);

    }

    @Test
    public void testGenerateQueryParams() throws Exception {
	String actual = CommonUtils.generateQueryParams(5);
	String expected = "?,?,?,?,?";
	assertEquals(expected, actual);

	actual = CommonUtils.generateQueryParams(0);
	expected = "";
	assertEquals(expected, actual);

	actual = CommonUtils.generateQueryParams(-1);
	expected = "";
	assertEquals(expected, actual);

	actual = CommonUtils.generateQueryParams(1);
	expected = "?";
	assertEquals(expected, actual);

	actual = CommonUtils.generateQueryParams(2);
	expected = "?,?";
	assertEquals(expected, actual);
    }

    @Test
    public void azureB2CTest() throws Exception {
	String jwt = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ing0Nzh4eU9wbHNNMUg3TlhrN1N4MTd4MXVwYyIsImtpZCI6Ing0Nzh4eU9wbHNNMUg3TlhrN1N4MTd4MXVwYyJ9.eyJhdWQiOiJhOTM4ODYxZC1mNzE2LTRiMGItYTUyZS1mYzczZGYxYjIxNmUiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC9mNjQ0NTlmNi0zMmU5LTQ1YTctOTQxOS03MWE4ODI2ZDhmNmIvIiwiaWF0IjoxNTEyNDUxMjUyLCJuYmYiOjE1MTI0NTEyNTIsImV4cCI6MTUxMjQ1NTE1MiwiYWlvIjoiWTJOZ1lHaThIQ09vdnlLeC9FOGdRKzZIVi9ZWHJHZGxhVi90U3BycUhPWjlQZURrSVZVQSIsImFtciI6WyJwd2QiXSwiZmFtaWx5X25hbWUiOiJOYXJheWFuYW4iLCJnaXZlbl9uYW1lIjoiU2hhbmthciIsImlwYWRkciI6IjIwMy4yMDAuMjA1LjI1MyIsIm5hbWUiOiJTaGFua2FyIiwibm9uY2UiOiJiYjE0MTMyZC00N2Q2LTRjNGQtYjdkNS00NmI3NTQzZWY1OWIiLCJvaWQiOiI1MDdhMThiNi0wNTkxLTQzZTAtYjkxMC0yMWRkMWUyNjM0MDAiLCJzdWIiOiJIcjhHMnd6bk1JV2IxaHJnMUxaSGJPYklVY0dybkNFR1BFNVV6VDFQOFJzIiwidGlkIjoiZjY0NDU5ZjYtMzJlOS00NWE3LTk0MTktNzFhODgyNmQ4ZjZiIiwidW5pcXVlX25hbWUiOiJzaGFua2FyQGRvdmVyaHlkcm8ub25taWNyb3NvZnQuY29tIiwidXBuIjoic2hhbmthckBkb3Zlcmh5ZHJvLm9ubWljcm9zb2Z0LmNvbSIsInV0aSI6Ind3dy1JYWkyWFVxcHZkYlZNQlpXQUEiLCJ2ZXIiOiIxLjAifQ.AGKXGzvPYXIirMqxZgN-aDbf2Y6hP5UzM2uJHaLwR2931oEYp1k_i3w-O4_Zd5M-63Ue8L5jLACEDgIjOQBMjFiD4hmpbB1Qnzxk-DZe1yihsZl8jQPNCGNg4sDVFKlx_wDYxQhK6AgsqaiMmr6x2smIa6fVuBgCHUobBCqOxrm91VKTaqkF3MwsXWsrjQ-uVY03yQJXoGbmjdJX78qOUVItHujzkoAVCSxKFB48G_kiTYBVu5WNhXAhKQChU5qRh2MysTyhEdzlRiuiFTTCxNEsZeQJZwTgpCVWHMmrzvPfW6MFeb3gRK9RfpLhJ-Ytmu6W6BAIGUoJhlqDbQBNwg";
	HttpsJwks httpsJkws = new HttpsJwks(
		"https://login.microsoftonline.com/fabrikamb2c.onmicrosoft.com/discovery/v2.0/keys");
	HttpsJwksVerificationKeyResolver httpsJwksKeyResolver = new HttpsJwksVerificationKeyResolver(httpsJkws);
	JwtConsumer jwtConsumer = new JwtConsumerBuilder().setRequireExpirationTime() // the
		// JWT
		// must
		// have
		// an
		// expiration
		// time
		.setAllowedClockSkewInSeconds(3600) // allow some leeway in
		// validating time based
		// claims to account for
		// clock skew
		.setRequireSubject() // the JWT must have a subject claim
		.setExpectedIssuer("https://sts.windows.net/f64459f6-32e9-45a7-9419-71a8826d8f6b/")
		// whom
		// the
		// JWT
		// needs
		// to
		// have
		// been
		// issued
		// by
		.setExpectedAudience("a938861d-f716-4b0b-a52e-fc73df1b216e") // to
		// whom the JWT is intended for
		.setVerificationKeyResolver(httpsJwksKeyResolver).build();

	try {
	    // Validate the JWT and process it to the Claims
	    JwtClaims jwtClaims = jwtConsumer.processToClaims(jwt);
	    System.out.println("JWT validation succeeded! " + jwtClaims);
	} catch (InvalidJwtException e) {
	    // InvalidJwtException will be thrown, if the JWT failed processing
	    // or validation in anyway.
	    // Hopefully with meaningful explanations(s) about what went wrong.
	    System.out.println("Invalid JWT! " + e);
	}

    }

    /*
     * Test Case to check if all the privileges fields are present in list.
     *
     */
    @Test
    public void checkPrivilegesName() throws Exception {
	/*
	 * PermissionDTO expected = new PermissionDTO(); Set<String> permissionList =
	 * new LinkedHashSet<>();
	 * 
	 * // Check SITE-VIEW permission is given to user. expected.setSITE_VIEW(true);
	 * permissionList.add(Constants.PRIVILEGE_NAMES.SITE_VIEW); expected = new
	 * PermissionDTO(); expected.setSITE_VIEW(true);
	 * 
	 * PermissionDTO actual = CommonUtils.getPrivilegesName(permissionList);
	 * assertEquals(expected, actual);
	 * 
	 * 
	 * permissionList = new LinkedHashSet<>();
	 * permissionList.add(Constants.PRIVILEGE_NAMES.DEVICE_MANAGEMENT_CREATE);
	 * expected = new PermissionDTO(); expected.setDEVICE_MANAGEMENT_CREATE(true);
	 * actual = CommonUtils.getPrivilegesName(permissionList);
	 * assertEquals(expected, actual);
	 * 
	 * permissionList = new LinkedHashSet<>();
	 * permissionList.add(Constants.PRIVILEGE_NAMES.DEVICE_MANAGEMENT_UPDATE);
	 * expected = new PermissionDTO(); expected.setDEVICE_MANAGEMENT_UPDATE(true);
	 * actual = CommonUtils.getPrivilegesName(permissionList);
	 * assertEquals(expected, actual);
	 * 
	 * permissionList = new LinkedHashSet<>();
	 * permissionList.add(Constants.PRIVILEGE_NAMES.DEVICE_MANAGEMENT_DELETE);
	 * expected = new PermissionDTO(); expected.setDEVICE_MANAGEMENT_DELETE(true);
	 * actual = CommonUtils.getPrivilegesName(permissionList);
	 * assertEquals(expected, actual);
	 * 
	 * permissionList = new LinkedHashSet<>();
	 * permissionList.add(Constants.PRIVILEGE_NAMES.DEVICE_MANAGEMENT_LIST);
	 * expected = new PermissionDTO(); expected.setDEVICE_MANAGEMENT_LIST(true);
	 * actual = CommonUtils.getPrivilegesName(permissionList);
	 * assertEquals(expected, actual);
	 * 
	 * permissionList = new LinkedHashSet<>();
	 * permissionList.add(Constants.PRIVILEGE_NAMES.DEVICE_MANAGEMENT_VIEW);
	 * expected = new PermissionDTO(); expected.setDEVICE_MANAGEMENT_VIEW(true);
	 * actual = CommonUtils.getPrivilegesName(permissionList);
	 * assertEquals(expected, actual);
	 */
    }

    @Test
    public void testGetGraphApiToken() throws Exception {
	String token = CommonUtils.getGraphApiToken();
	assertNotNull(token);
    }

    @Test
    public void testGetEventId() {
	StringBuilder sBuilder = new StringBuilder();
	for (int i = 0; i < 100; i++) {
	    sBuilder.append(CommonUtils.guidGenerator(null, null));
	}
	String expected = CommonUtils.getEventId(sBuilder);
	String actual = CommonUtils.getEventId(sBuilder);
	assertEquals(expected, actual);

    }

    @Test
    public void testMetricList() {

	LinkedList<MetricDTO> actual = CommonUtils.getMetricList();
	MetaDataDTO metadata = new MetaDataDTO();
	metadata.setMetricList(actual);
	System.out.println(ServiceHelper.buildJsonString(metadata));
    }

    @Test
    public void testRemoveAfterLastOccurence() {
	String original = "";
	String delimiter = "";
	String actual = CommonUtils.removeAfterLastOccurence(original, delimiter);
	String expected = "";
	assertEquals(expected, actual);
	// Both Null
	original = null;
	delimiter = null;
	actual = CommonUtils.removeAfterLastOccurence(original, delimiter);
	expected = null;
	assertEquals(expected, actual);
	// Empty delimiter
	original = "a";
	delimiter = "";
	actual = CommonUtils.removeAfterLastOccurence(original, delimiter);
	expected = "a";
	assertEquals(expected, actual);

	original = "";
	delimiter = "a";
	actual = CommonUtils.removeAfterLastOccurence(original, delimiter);
	expected = "";
	assertEquals(expected, actual);

	original = null;
	delimiter = "_";
	actual = CommonUtils.removeAfterLastOccurence(original, delimiter);
	expected = null;
	assertEquals(expected, actual);

	original = "abc";
	delimiter = "_";
	actual = CommonUtils.removeAfterLastOccurence(original, delimiter);
	expected = "abc";
	assertEquals(expected, actual);

	original = "1_2";
	delimiter = "_";
	actual = CommonUtils.removeAfterLastOccurence(original, delimiter);
	expected = "2";
	assertEquals(expected, actual);

	original = "1_2_3";
	delimiter = "_";
	actual = CommonUtils.removeAfterLastOccurence(original, delimiter);
	expected = "2_3";
	assertEquals(expected, actual);

    }

    @Test
    public void testRoleExists() {
	List<RoleDTO> roleList = null;
	String userRole = null;
	assertFalse(CommonUtils.roleExists(roleList, userRole));

	roleList = new LinkedList<>();
	userRole = null;
	assertFalse(CommonUtils.roleExists(roleList, userRole));

	roleList = new LinkedList<>();
	userRole = "";
	assertFalse(CommonUtils.roleExists(roleList, userRole));

	roleList = new LinkedList<>();
	RoleDTO roleDTO = new RoleDTO();
	roleList.add(roleDTO);
	userRole = null;
	assertFalse(CommonUtils.roleExists(roleList, userRole));

	roleList = new LinkedList<>();
	roleDTO = new RoleDTO();
	roleDTO.setUserRole(null);
	roleList.add(roleDTO);
	userRole = null;
	assertFalse(CommonUtils.roleExists(roleList, userRole));

	roleList = new LinkedList<>();
	roleDTO = new RoleDTO();
	roleDTO.setUserRole("");
	roleList.add(roleDTO);
	userRole = null;
	assertFalse(CommonUtils.roleExists(roleList, userRole));

	roleList = new LinkedList<>();
	roleDTO = new RoleDTO();
	roleDTO.setUserRole("");
	roleList.add(roleDTO);
	userRole = "";
	assertFalse(CommonUtils.roleExists(roleList, userRole));

	roleList = new LinkedList<>();
	roleDTO = new RoleDTO();
	roleDTO.setUserRole("test");
	roleList.add(roleDTO);
	userRole = null;
	assertFalse(CommonUtils.roleExists(roleList, userRole));

	roleList = new LinkedList<>();
	roleDTO = new RoleDTO();
	roleDTO.setUserRole("test");
	roleList.add(roleDTO);

	roleDTO = new RoleDTO();
	roleDTO.setUserRole("test1");
	roleList.add(roleDTO);

	roleDTO = new RoleDTO();
	roleDTO.setUserRole("test2");
	roleList.add(roleDTO);
	userRole = "test3";
	assertFalse(CommonUtils.roleExists(roleList, userRole));

	roleList = new LinkedList<>();
	roleDTO = new RoleDTO();
	roleDTO.setUserRole("test");
	roleList.add(roleDTO);

	roleDTO = new RoleDTO();
	roleDTO.setUserRole("test1");
	roleList.add(roleDTO);

	roleDTO = new RoleDTO();
	roleDTO.setUserRole("test2");
	roleList.add(roleDTO);
	userRole = "test2";
	assertTrue(CommonUtils.roleExists(roleList, userRole));
    }

    @Test
    public void testMail() {
	assertTrue(CommonUtils.isValidMail("c-test@dovercorp.com"));
	assertTrue(CommonUtils.isValidMail("test.test@object-frontier.com"));
	assertTrue(CommonUtils.isValidMail("!#$%^&*-+_/{}=|'/?@gmail.com"));
	assertTrue(CommonUtils.isValidMail("123456789@gmail.co.in"));
	assertTrue(CommonUtils.isValidMail("123@test.com"));
	assertTrue(CommonUtils.isValidMail("abcd@abc.in"));
	assertTrue(CommonUtils.isValidMail("test@a.b.c.1.2.3.co"));
	assertTrue(CommonUtils.isValidMail("test@gm-ail.com"));
	assertTrue(CommonUtils.isValidMail("test@g-m-ail.com"));
	assertFalse(CommonUtils.isValidMail("abcd@gmail.ab"));
	assertFalse(CommonUtils.isValidMail("test@a.b.c.1.2.12"));
	assertFalse(CommonUtils.isValidMail("a.b.c@a.b.c.1.2.c"));
	assertFalse(CommonUtils.isValidMail("()[];:'<>,.@test.com"));
    }

    @Test
    public void testCreateInterval() throws Exception {
	boolean assertFlag = true;
	for (int i = 0; i < 100; i++) {
	    int actualInterval = new Interval(CommonUtils.convertStringToLongTime("10:09:45"),
		    CommonUtils.convertStringToLongTime("20:14:21")).hashCode();
	    int expectedInterval = CommonUtils.createInterval(CommonUtils.convertStringToLongTime("10:09:45"),
		    CommonUtils.convertStringToLongTime("20:14:21")).hashCode();
	    assertFlag = assertFlag && (actualInterval == expectedInterval);
	    if (!assertFlag) {
		break;
	    }
	}
	assertTrue(assertFlag);
    }
    
    @Test
    public void testGetTimeDifferenceWrtCurrentTime() {
	String eventTime = "2019-06-26T12:00:00";
//	System.out.println("eventTime = " + eventTime);
	LocalDateTime localTime = LocalDateTime.parse(eventTime, DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME));
	ZonedDateTime zonedTime = ZonedDateTime.of(localTime, ZoneId.of("Asia/Kolkata"));
	System.out.println("localTime = " + zonedTime.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME)));
	Duration duration = CommonUtils.getTimeDifferenceWrtCurrentTime(zonedTime);
	System.out.println("difference in days = " + duration.abs().toDays());
	assertTrue(duration.abs().toDays()>3L);
    }
    
    @Test
    public void testConvertUTCtoZonedTime() {
	String utcTime = "2019-07-01T19:00:00";
	String zone = "America/Panama";
	ZonedDateTime zonedTime = CommonUtils.convertUTCtoZonedTime(utcTime, zone);
	System.out.println(zonedTime.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME)));
	assertTrue("2019-07-01T14:00:00".equalsIgnoreCase(zonedTime.format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT.REAL_TIME_REPORT_DATE_TIME))));
    }
}
