package com.hydro.api.dto;

import java.util.Set;

public class RoleDTO {
    private String userRole;
    private String roleId;
    private Integer clearanceLevel;
    private String orgType;
    private Set<String> permissions;
    private boolean sms;
    private boolean email;
    private int threshold;
    private String predefinedAlarmThreshold;

    public String getPredefinedAlarmThreshold() {
	return predefinedAlarmThreshold;
    }

    public void setPredefinedAlarmThreshold(String predefinedAlarmThreshold) {
	this.predefinedAlarmThreshold = predefinedAlarmThreshold;
    }

    private String thresholdResetValue;
    private String preferenceId;

    public String getPreferenceId() {
	return preferenceId;
    }

    public void setPreferenceId(String preferenceId) {
	this.preferenceId = preferenceId;
    }

    public boolean isSms() {
	return sms;
    }

    public void setSms(boolean sms) {
	this.sms = sms;
    }

    public boolean isEmail() {
	return email;
    }

    public void setEmail(boolean email) {
	this.email = email;
    }

    public int getThreshold() {
	return threshold;
    }

    public void setThreshold(int threshold) {
	this.threshold = threshold;
    }

    public String getThresholdResetValue() {
	return thresholdResetValue;
    }

    public void setThresholdResetValue(String thresholdResetValue) {
	this.thresholdResetValue = thresholdResetValue;
    }

    public String getUserRole() {
	return userRole;
    }

    public void setUserRole(String user_role) {
	this.userRole = user_role;
    }

    public String getRoleId() {
	return roleId;
    }

    public void setRoleId(String role_id) {
	this.roleId = role_id;
    }

    public Integer getClearanceLevel() {
	return clearanceLevel;
    }

    public void setClearanceLevel(Integer clearanceLevel) {
	this.clearanceLevel = clearanceLevel;
    }

    public String getOrgType() {
	return orgType;
    }

    public void setOrgType(String orgType) {
	this.orgType = orgType;
    }

    public Set<String> getPermissions() {
	return permissions;
    }

    public void setPermissions(Set<String> permissions) {
	this.permissions = permissions;
    }
}
