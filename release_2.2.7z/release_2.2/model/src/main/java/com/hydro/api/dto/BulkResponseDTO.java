package com.hydro.api.dto;

import java.util.List;

import com.hydro.api.constants.Constants.BULK_STATE;

/**
 * @author Suganya Arumugam
 *
 */
public class BulkResponseDTO {

    private BULK_STATE bulkState;
    private String conflicts;
    private List<EsErrorLogDTO> conflictsList;

    public BULK_STATE getBulkState() {
	return bulkState;
    }

    public void setBulkState(BULK_STATE bulkState) {
	this.bulkState = bulkState;
    }

    public List<EsErrorLogDTO> getConflictsList() {
	return conflictsList;
    }

    public void setConflictsList(List<EsErrorLogDTO> conflictsList) {
	this.conflictsList = conflictsList;
    }

    public String getConflicts() {
	return conflicts;
    }

    public void setConflicts(String conflicts) {
	this.conflicts = conflicts;
    }

}
