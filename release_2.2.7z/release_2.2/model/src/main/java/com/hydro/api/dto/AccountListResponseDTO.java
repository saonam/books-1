/**
 * 
 */
package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */

public class AccountListResponseDTO {
    private List<AccountDTO> accountList;

    /**
     * @return the userList
     */
    public List<AccountDTO> getAccountList() {
	return accountList;
    }

    /**
     * @param userList
     *            the userList to set
     */
    public void setAccountList(List<AccountDTO> accountList) {
	this.accountList = accountList;
    }

}
