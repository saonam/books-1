/**
 * 
 */
package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class EsErrorLogDTO {
    // error_id, site_id, file_id, description, error_type, es_error,
    // index_name, es_document, created_by, created_date, modified_by,
    // modified_date, version, es_type, month, year

    private String errorId;
    private String siteId;
    private String fileId;
    private String description;
    private String errorType;
    private String esError;
    private String indexName;
    private String esDocument;
    private String createdBy;
    private String createdDate;
    private String modifiedBy;
    private String modifiedDate;
    private String esType;
    private int month;
    private int year;

    public String getErrorId() {
	return errorId;
    }

    public void setErrorId(String errorId) {
	this.errorId = errorId;
    }

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getFileId() {
	return fileId;
    }

    public void setFileId(String fileId) {
	this.fileId = fileId;
    }

    public String getDescription() {
	return description;
    }

    public void setDescription(String description) {
	this.description = description;
    }

    public String getErrorType() {
	return errorType;
    }

    public void setErrorType(String errorType) {
	this.errorType = errorType;
    }

    public String getEsError() {
	return esError;
    }

    public void setEsError(String esError) {
	this.esError = esError;
    }

    public String getIndexName() {
	return indexName;
    }

    public void setIndexName(String indexName) {
	this.indexName = indexName;
    }

    public String getEsDocument() {
	return esDocument;
    }

    public void setEsDocument(String esDocument) {
	this.esDocument = esDocument;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public String getModifiedBy() {
	return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
	return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
    }

    public String getEsType() {
	return esType;
    }

    public void setEsType(String esType) {
	this.esType = esType;
    }

    public int getMonth() {
	return month;
    }

    public void setMonth(int month) {
	this.month = month;
    }

    public int getYear() {
	return year;
    }

    public void setYear(int year) {
	this.year = year;
    }

}
