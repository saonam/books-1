package com.hydro.api.dto;

import java.util.List;

public class ShiftListResponseDTO {
    private List<ShiftDTO> shiftList;

    public List<ShiftDTO> getShiftList() {
	return shiftList;
    }

    public void setShiftList(List<ShiftDTO> shiftList) {
	this.shiftList = shiftList;
    }
}
