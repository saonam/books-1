package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */
public class AlertDTO {
    private String id;// id is referred to as table id.
    private int alarmId;
    private String alarmName;
    private String alarmDescription;
    private List<RoleDTO> userGroup;
    private boolean active;
    private String alarmType;

    public int getAlarmId() {
	return alarmId;
    }

    public void setAlarmId(int alarmId) {
	this.alarmId = alarmId;
    }

    public String getAlarmName() {
	return alarmName;
    }

    public void setAlarmName(String alarmName) {
	this.alarmName = alarmName;
    }

    public String getAlarmDescription() {
	return alarmDescription;
    }

    public void setAlarmDescription(String alarmDescription) {
	this.alarmDescription = alarmDescription;
    }

    public List<RoleDTO> getUserGroup() {
	return userGroup;
    }

    public void setUserGroup(List<RoleDTO> userGroup) {
	this.userGroup = userGroup;
    }

    public boolean isActive() {
	return active;
    }

    public void setActive(boolean active) {
	this.active = active;
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getAlarmType() {
	return alarmType;
    }

    public void setAlarmType(String alarmType) {
	this.alarmType = alarmType;
    }

}
