/**
 * 
 */
package com.hydro.api.dto.reports;

import java.util.List;

/**
 * @author Shreyas K C
 *
 */
public class MachineDTO {

    private String machineName;
    private String machineId;
    private Integer warningCount;
    private Integer capacity;
    private List<WarningDTO> warningList;
    private Integer lm2Seq;

    public String getMachineName() {
	return machineName;
    }

    public void setMachineName(String machineName) {
	this.machineName = machineName;
    }

    public String getMachineId() {
	return machineId;
    }

    public void setMachineId(String machineId) {
	this.machineId = machineId;
    }

    public int getWarningCount() {
	return warningCount;
    }

    public void setWarningCount(int warningCount) {
	this.warningCount = warningCount;
    }

    public int getCapacity() {
	return capacity;
    }

    public void setCapacity(int capacity) {
	this.capacity = capacity;
    }

    public List<WarningDTO> getWarningList() {
	return warningList;
    }

    public void setWarningList(List<WarningDTO> warningList) {
	this.warningList = warningList;
    }

    public Integer getLm2Seq() {
	return lm2Seq;
    }

    public void setLm2Seq(Integer lm2Seq) {
	this.lm2Seq = lm2Seq;
    }
}
