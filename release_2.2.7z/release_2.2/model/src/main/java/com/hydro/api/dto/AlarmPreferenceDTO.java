package com.hydro.api.dto;

import java.util.Date;

public class AlarmPreferenceDTO {
	private String id;
	private String businessId;
	private String roleId;
	private String alarmId;
	private int sms;
	private int email;
	private int threshold;
	private String thresholdRefreshInterval;
	private int shiftCounter;
	private Date shiftFirstAlarmTime;
	private int dayCounter;
	private Date dayFirstAlarmTime;
	private int weekCounter;
	private Date weekFirstAlarmTime;
	private int monthCounter;
	private Date monthFirstAlarmTime;
	private String createdBy;
	private Date createdDate;
	private String modifiedBy;
	private Date modifiedDate;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBusinessId() {
		return businessId;
	}
	public void setBusinessId(String businessId) {
		this.businessId = businessId;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getAlarmId() {
		return alarmId;
	}
	public void setAlarmId(String alarmId) {
		this.alarmId = alarmId;
	}
	public int getSms() {
		return sms;
	}
	public void setSms(int sms) {
		this.sms = sms;
	}
	public int getEmail() {
		return email;
	}
	public void setEmail(int email) {
		this.email = email;
	}
	public int getThreshold() {
		return threshold;
	}
	public void setThreshold(int threshold) {
		this.threshold = threshold;
	}
	public String getThresholdRefreshInterval() {
		return thresholdRefreshInterval;
	}
	public void setThresholdRefreshInterval(String thresholdRefreshInterval) {
		this.thresholdRefreshInterval = thresholdRefreshInterval;
	}
	public int getShiftCounter() {
		return shiftCounter;
	}
	public void setShiftCounter(int shiftCounter) {
		this.shiftCounter = shiftCounter;
	}
	public Date getShiftFirstAlarmTime() {
		return shiftFirstAlarmTime;
	}
	public void setShiftFirstAlarmTime(Date shiftFirstAlarmTime) {
		this.shiftFirstAlarmTime = shiftFirstAlarmTime;
	}
	public int getDayCounter() {
		return dayCounter;
	}
	public void setDayCounter(int dayCounter) {
		this.dayCounter = dayCounter;
	}
	public Date getDayFirstAlarmTime() {
		return dayFirstAlarmTime;
	}
	public void setDayFirstAlarmTime(Date dayFirstAlarmTime) {
		this.dayFirstAlarmTime = dayFirstAlarmTime;
	}
	public int getWeekCounter() {
		return weekCounter;
	}
	public void setWeekCounter(int weekCounter) {
		this.weekCounter = weekCounter;
	}
	public Date getWeekFirstAlarmTime() {
		return weekFirstAlarmTime;
	}
	public void setWeekFirstAlarmTime(Date weekFirstAlarmTime) {
		this.weekFirstAlarmTime = weekFirstAlarmTime;
	}
	public int getMonthCounter() {
		return monthCounter;
	}
	public void setMonthCounter(int monthCounter) {
		this.monthCounter = monthCounter;
	}
	public Date getMonthFirstAlarmTime() {
		return monthFirstAlarmTime;
	}
	public void setMonthFirstAlarmTime(Date monthFirstAlarmTime) {
		this.monthFirstAlarmTime = monthFirstAlarmTime;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	
	
	

}
