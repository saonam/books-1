/**
 * 
 */
package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */
public class UserDTO {
    private String userId;
    private String firstName;
    private String middleName;
    private String userName;
    private String email;
    private String lastName;
    private String profileImage;
    private String phoneNumber;
    private String userRole;
    private String orgType;
    private String associationId;
    private String associationName;
    private String createdBy;
    private String createdDate;
    private String address1;
    private boolean isActive;
    private String address2;
    private String state;
    private String country;
    private String city;
    private String zipCode;
    private String roleId;
    private String timeZone;
    private Integer clearanceLevel;
    private List<SiteDTO> siteList;
    private PermissionDTO permissions;
    private boolean fullPrivilege;
    private List<AlertDTO> alertList;
    private String createdDateStart;
    private String createdDateEnd;

    public String getUserId() {
	return userId;
    }

    public void setUserId(String userId) {
	this.userId = userId;
    }

    public String getFirstName() {
	return firstName;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public String getMiddleName() {
	return middleName;
    }

    public void setMiddleName(String middleName) {
	this.middleName = middleName;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getLastName() {
	return lastName;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public String getProfileImage() {
	return profileImage;
    }

    public void setProfileImage(String profileImage) {
	this.profileImage = profileImage;
    }

    public String getPhoneNumber() {
	return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
    }

    public String getUserRole() {
	return userRole;
    }

    public void setUserRole(String roleType) {
	this.userRole = roleType;
    }

    public String getOrgType() {
	return orgType;
    }

    public void setOrgType(String userType) {
	this.orgType = userType;
    }

    public String getAssociationId() {
	return associationId;
    }

    public void setAssociationId(String associationId) {
	this.associationId = associationId;
    }

    public String getAssociationName() {
	return associationName;
    }

    public void setAssociationName(String associationName) {
	this.associationName = associationName;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public String getAddress1() {
	return address1;
    }

    public void setAddress1(String address1) {
	this.address1 = address1;
    }

    public String getAddress2() {
	return address2;
    }

    public void setAddress2(String address2) {
	this.address2 = address2;
    }

    public String getState() {
	return state;
    }

    public void setState(String state) {
	this.state = state;
    }

    public String getCity() {
	return city;
    }

    public void setCity(String city) {
	this.city = city;
    }

    public String getZipCode() {
	return zipCode;
    }

    public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
    }

    // public UserType getUserRoleType() {
    // return userRoleType;
    // }
    //
    // public void setUserRoleType(UserType userRoleType) {
    // this.userRoleType = userRoleType;
    // }

    public boolean isActive() {
	return isActive;
    }

    public void setActive(boolean isActive) {
	this.isActive = isActive;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public PermissionDTO getPermissions() {
	return permissions;
    }

    public void setPermissions(PermissionDTO permissions) {
	this.permissions = permissions;
    }

    public String getRoleId() {
	return roleId;
    }

    public void setRoleId(String roleId) {
	this.roleId = roleId;
    }

    public String getTimeZone() {
	return timeZone;
    }

    public void setTimeZone(String timeZone) {
	this.timeZone = timeZone;
    }

    public String getUserName() {
	return userName;
    }

    public void setUserName(String userName) {
	this.userName = userName;
    }

    public Integer getClearanceLevel() {
	return clearanceLevel;
    }

    public void setClearanceLevel(Integer clearanceLevel) {
	this.clearanceLevel = clearanceLevel;
    }

    public List<SiteDTO> getSiteList() {
	return siteList;
    }

    public void setSiteList(List<SiteDTO> siteList) {
	this.siteList = siteList;
    }

    public boolean isFullPrivilege() {
	return fullPrivilege;
    }

    public void setFullPrivilege(boolean fullPrivilege) {
	this.fullPrivilege = fullPrivilege;
    }

    public List<AlertDTO> getAlertList() {
	return alertList;
    }

    public void setAlertList(List<AlertDTO> alertList) {
	this.alertList = alertList;
    }

    public String getCreatedDateStart() {
	return createdDateStart;
    }

    public void setCreatedDateStart(String createdDateStart) {
	this.createdDateStart = createdDateStart;
    }

    public String getCreatedDateEnd() {
	return createdDateEnd;
    }

    public void setCreatedDateEnd(String createdDateEnd) {
	this.createdDateEnd = createdDateEnd;
    }

    public UserDTO() {
    }

    public UserDTO(String createdDateEnd, String createdDateStart) {
	this.createdDateEnd = createdDateEnd;
	this.createdDateStart = createdDateStart;
    }

}
