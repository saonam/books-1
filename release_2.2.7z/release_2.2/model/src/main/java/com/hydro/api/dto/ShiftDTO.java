package com.hydro.api.dto;

import java.util.List;
import java.util.Map;

import com.hydro.api.dto.reports.DailyReportFormulaDTO;
import com.hydro.api.dto.reports.DailyReportWasherDTO;
import com.hydro.api.dto.reports.TransferDTO;

/**
 * @author Srishti Tiwari
 *
 */

public class ShiftDTO {
    private String shiftId;
    private String shiftName;
    private String startTime;
    private String endTime;
    private Map<Integer, DailyReportWasherDTO> washerHashMap;
    private Map<Integer, DailyReportFormulaDTO> formulaMap;
    private Map<Integer, TransferDTO> transferMap;
    private DailyReportTunnelDTO tunnelDetails;
    private Map<Integer, BatchDTO> batchMap;
    private List<DailyReportEquipmentDTO> equipments = null;

    public String getShiftId() {
	return shiftId;
    }

    public void setShiftId(String shiftId) {
	this.shiftId = shiftId;
    }

    public String getShiftName() {
	return shiftName;
    }

    public void setShiftName(String shiftName) {
	this.shiftName = shiftName;
    }

    public String getStartTime() {
	return startTime;
    }

    public void setStartTime(String startTime) {
	this.startTime = startTime;
    }

    public String getEndTime() {
	return endTime;
    }

    public void setEndTime(String endTime) {
	this.endTime = endTime;
    }

    public Map<Integer, DailyReportFormulaDTO> getFormulaMap() {
	return formulaMap;
    }

    public void setFormulaMap(Map<Integer, DailyReportFormulaDTO> formulaMap) {
	this.formulaMap = formulaMap;
    }

    public Map<Integer, DailyReportWasherDTO> getWasherHashMap() {
	return washerHashMap;
    }

    public void setWasherHashMap(Map<Integer, DailyReportWasherDTO> washerHashMap) {
	this.washerHashMap = washerHashMap;
    }

    public String toString() {
	return this.shiftName + ":" + this.startTime + ":" + this.endTime;
    }

    public DailyReportTunnelDTO getTunnelDetails() {
	return tunnelDetails;
    }

    public void setTunnelDetails(DailyReportTunnelDTO tunnelDetails) {
	this.tunnelDetails = tunnelDetails;
    }

    public Map<Integer, BatchDTO> getBatchMap() {
	return batchMap;
    }

    public void setBatchMap(Map<Integer, BatchDTO> batchMap) {
	this.batchMap = batchMap;
    }

    public Map<Integer, TransferDTO> getTransferMap() {
	return transferMap;
    }

    public void setTransferMap(Map<Integer, TransferDTO> transferMap) {
	this.transferMap = transferMap;
    }

    public List<DailyReportEquipmentDTO> getEquipments() {
        return equipments;
    }

    public void setEquipments(List<DailyReportEquipmentDTO> equipments) {
        this.equipments = equipments;
    }
    
    public void addEquipment(DailyReportEquipmentDTO equipment) {
	this.equipments.add(equipment);
    }

}
