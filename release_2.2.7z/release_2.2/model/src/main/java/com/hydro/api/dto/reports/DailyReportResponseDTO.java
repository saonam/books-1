package com.hydro.api.dto.reports;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.hydro.api.dto.ShiftDTO;

/**
 * @author Srishti Tiwari
 *
 */
public class DailyReportResponseDTO {
    // washer parameters
    private Map<Integer, RealTimeAlarmDTO> alarmsMap;
    private String siteId;
    private ShiftDTO shift;
    private Date date;
    private boolean clearAlarm = true;
    private List<ShiftDTO> selectedShifts;

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public Map<Integer, RealTimeAlarmDTO> getAlarmsMap() {
	return alarmsMap;
    }

    public void setAlarmsMap(Map<Integer, RealTimeAlarmDTO> alarmsMap) {
	this.alarmsMap = alarmsMap;
    }

    public Date getDate() {
	return date;
    }

    public void setDate(Date date) {
	this.date = date;
    }

    public boolean isClearAlarm() {
	return clearAlarm;
    }

    public void setClearAlarm(boolean clearAlarm) {
	this.clearAlarm = clearAlarm;
    }

    public List<ShiftDTO> getSelectedShifts() {
	return selectedShifts;
    }

    public void setSelectedShifts(List<ShiftDTO> selectedShifts) {
	this.selectedShifts = selectedShifts;
    }

    public ShiftDTO getShift() {
	return shift;
    }

    public void setShift(ShiftDTO shift) {
	this.shift = shift;
    }
}
