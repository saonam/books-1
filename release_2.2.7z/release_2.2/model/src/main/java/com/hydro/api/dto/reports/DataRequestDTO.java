package com.hydro.api.dto.reports;

public class DataRequestDTO {
    private String siteId;
    private String equipmentId;
    private String equipmentType;
    private String fromDate;
    private String toDate;
    public String getSiteId() {
        return siteId;
    }
    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }
    public String getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    public String getEquipmentType() {
        return equipmentType;
    }
    public void setEquipmentType(String equipmentType) {
        this.equipmentType = equipmentType;
    }
    
    public String getFromDate() {
        return fromDate;
    }
    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }
    public String getToDate() {
        return toDate;
    }
    public void setToDate(String toDate) {
        this.toDate = toDate;
    }

    public static enum EquipmentType {
	TUNNEL(0),
	WASHER(1),
	BOTH(-1);
	
	private Integer id;
	
	private EquipmentType(Integer id) {
	    this.id = id;
	}
	
	public Integer id() {
	    return this.id;
	}
    }
}
