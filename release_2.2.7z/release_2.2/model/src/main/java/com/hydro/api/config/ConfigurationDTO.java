package com.hydro.api.config;

import java.util.List;
import java.util.Map;

public class ConfigurationDTO {
    private String data_source;
    private String data_type;
    private Map<String,Object> site;
    private List<EquipmentConfigDTO> units;
    public String getData_source() {
        return data_source;
    }
    public void setData_source(String data_source) {
        this.data_source = data_source;
    }
    public String getData_type() {
        return data_type;
    }
    public void setData_type(String data_type) {
        this.data_type = data_type;
    }
    public List<EquipmentConfigDTO> getUnits() {
        return units;
    }
    public Map<String, Object> getSite() {
        return site;
    }
    public void setSite(Map<String, Object> site) {
        this.site = site;
    }
    public void setUnits(List<EquipmentConfigDTO> units) {
        this.units = units;
    }

}
