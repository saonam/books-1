package com.hydro.api.dto.reports;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */

public class PhaseDTO {
    private Integer phase;
    private boolean validPhase;
    private boolean activePhase;
    private Integer phaseStatus;
    private List<EventsDTO> eventList;

    public boolean isValidPhase() {
	return validPhase;
    }

    public void setValidPhase(boolean validPhase) {
	this.validPhase = validPhase;
    }

    public Integer getPhase() {
	return phase;
    }

    public void setPhase(Integer phase) {
	this.phase = phase;
    }

    public Integer getPhaseStatus() {
	return phaseStatus;
    }

    public void setPhaseStatus(Integer phaseStatus) {
	this.phaseStatus = phaseStatus;
    }

    public List<EventsDTO> getEventList() {
	return eventList;
    }

    public void setEventList(List<EventsDTO> eventList) {
	this.eventList = eventList;
    }

    public boolean isActivePhase() {
	return activePhase;
    }

    public void setActivePhase(boolean activePhase) {
	this.activePhase = activePhase;
    }
}
