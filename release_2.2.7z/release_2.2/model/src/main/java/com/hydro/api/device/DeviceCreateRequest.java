package com.hydro.api.device;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class DeviceCreateRequest implements Serializable {
    private String Id = "";
    private String serialNumber;
    private String deviceType;
    private String name;
    private boolean isActive = true;
    private String siteName;
    private List<Association> associatedDevices;
    private List<DeviceCreateRequestProperties> properties;
    private List<String> security;
    private List<String> softwareupdate;
    private boolean isEdgeDevice;
    private String companyName;

    public String getId() {
	return Id;
    }

    public void setId(String id) {
	Id = id;
    }

    public String getSerialNumber() {
	return serialNumber;
    }

    public String getCompanyName() {
	return companyName;
    }

    public void setCompanyName(String companyName) {
	this.companyName = companyName;
    }

    public void setSerialNumber(String serialNumber) {
	this.serialNumber = serialNumber;
    }

    public String getDeviceType() {
	return deviceType;
    }

    public void setDeviceType(String deviceType) {
	this.deviceType = deviceType;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public boolean isActive() {
	return isActive;
    }

    public void setActive(boolean isActive) {
	this.isActive = isActive;
    }

    public String getSiteName() {
	return siteName;
    }

    public void setSiteName(String siteName) {
	this.siteName = siteName;
    }

    public List<Association> getAssociatedDevices() {
	return associatedDevices;
    }

    public void setAssociatedDevices(List<Association> associatedDevices) {
	this.associatedDevices = associatedDevices;
    }

    public List<String> getSecurity() {
	return security;
    }

    public void setSecurity(List<String> security) {
	this.security = security;
    }

    public List<String> getSoftwareupdate() {
	return softwareupdate;
    }

    public void setSoftwareupdate(List<String> softwareupdate) {
	this.softwareupdate = softwareupdate;
    }

    public boolean isEdgeDevice() {
	return isEdgeDevice;
    }

    public void setEdgeDevice(boolean isEdgeDevice) {
	this.isEdgeDevice = isEdgeDevice;
    }

    public List<DeviceCreateRequestProperties> getProperties() {
	return properties;
    }

    public void setProperties(List<DeviceCreateRequestProperties> properties) {
	this.properties = properties;
    }

    @Override
    public String toString() {
	return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
