/**
 * 
 */
package com.hydro.api.dto;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Class defines the metric skeletal structure for units used for a given site.
 * 
 * @author Shreyas K C
 *
 */
public class MetricDTO {

    private String id;
    private String weightUnit;
    private String volumeUnit;
    private String costUnit;
    private String displayName;
    private String alarmVolumeUnit;
    private String costCw;
    private String weightUnitDisplay;
    private String volumeUnitDisplay;
    private String alarmVolumeUnitDisplay;
    Map<String, CalculationDTO> weightCalculation;
    Map<String, CalculationDTO> volumeCalculation;
    Map<String, CalculationDTO> alarmVolumeCalculation;
    Map<String, CalculationDTO> chemicalPerCwCalculation;

    /**
     * Constructor for creating the metric object.
     * 
     * @param weightUnit
     * @param volumeUnit
     * @param costUnit
     * @param displayName
     * @param alarmVolumeUnit
     */
    public MetricDTO(String id, String weightUnit, String volumeUnit, String costUnit, String displayName,
	    String alarmVolumeUnit, String weightUnitDisplay, String volumeUnitDisplay, String alarmVolumeUnitDisplay,
	    String costCw) {
	this.id = id;
	this.weightUnit = weightUnit;
	this.volumeUnit = volumeUnit;
	this.costUnit = costUnit;
	this.displayName = displayName;
	this.alarmVolumeUnit = alarmVolumeUnit;
	this.weightUnitDisplay = weightUnitDisplay;
	this.volumeUnitDisplay = volumeUnitDisplay;
	this.alarmVolumeUnitDisplay = alarmVolumeUnitDisplay;
	weightCalculation = new HashMap<>();
	volumeCalculation = new HashMap<>();
	alarmVolumeCalculation = new HashMap<>();
	chemicalPerCwCalculation = new HashMap<>();
	this.costCw = costCw;
    }

    public String getWeightUnit() {
	return weightUnit;
    }

    public void setWeightUnit(String weightUnit) {
	this.weightUnit = weightUnit;
    }

    public String getVolumeUnit() {
	return volumeUnit;
    }

    public void setVolumeUnit(String volumeUnit) {
	this.volumeUnit = volumeUnit;
    }

    public String getCostUnit() {
	return costUnit;
    }

    public void setCostUnit(String costUnit) {
	this.costUnit = costUnit;
    }

    public String getDisplayName() {
	return displayName;
    }

    public void setDisplayName(String displayName) {
	this.displayName = displayName;
    }

    public String getAlarmVolumeUnit() {
	return alarmVolumeUnit;
    }

    public void setAlarmVolumeUnit(String alarmVolumeUnit) {
	this.alarmVolumeUnit = alarmVolumeUnit;
    }

    public Map<String, CalculationDTO> getWeightCalculation() {
	return weightCalculation;
    }

    public void setWeightCalculation(String key, CalculationDTO calculation) {
	this.weightCalculation.put(key, calculation);
    }

    public Map<String, CalculationDTO> getVolumeCalculation() {
	return volumeCalculation;
    }

    public void setVolumeCalculation(String key, CalculationDTO calculation) {
	this.volumeCalculation.put(key, calculation);
    }

    public Map<String, CalculationDTO> getAlarmVolumeCalculation() {
	return alarmVolumeCalculation;
    }

    public void setAlarmVolumeCalculation(String key, CalculationDTO calculation) {
	this.alarmVolumeCalculation.put(key, calculation);
    }

    public Map<String, CalculationDTO> getChemicalPerCwCalculation() {
	return chemicalPerCwCalculation;
    }

    public void setChemicalPerCwCalculation(String key, CalculationDTO calculation) {
	this.chemicalPerCwCalculation.put(key, calculation);
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getCostCw() {
	return costCw;
    }

    public void setCostCw(String costCw) {
	this.costCw = costCw;
    }

}
