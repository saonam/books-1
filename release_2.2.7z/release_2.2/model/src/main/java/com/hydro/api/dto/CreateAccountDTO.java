/**
 * 
 */
package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class CreateAccountDTO {
    private String accountId;

    /**
     * @return the accountId
     */
    public String getAccountId() {
	return accountId;
    }

    /**
     * @param accountId
     *            the accountId to set
     */
    public void setAccountId(String accountId) {
	this.accountId = accountId;
    }

}
