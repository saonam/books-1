/**
 * 
 */
package com.hydro.api.dto;

import com.hydro.api.constants.Constants;

/**
 * Class defines the metric skeletal structure for units used for a given site.
 * 
 * @author Shreyas K C
 *
 */
public class CalculationDTO {
    private Constants.Units.Operations operation;
    private String formula;

    public Constants.Units.Operations getOperation() {
	return operation;
    }

    public void setOperation(Constants.Units.Operations operation) {
	this.operation = operation;
    }

    public String getFormula() {
	return formula;
    }

    public void setFormula(String formula) {
	this.formula = formula;
    }

}
