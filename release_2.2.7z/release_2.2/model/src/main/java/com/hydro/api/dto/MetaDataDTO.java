/**
 * 
 */
package com.hydro.api.dto;

import java.util.HashMap;
import java.util.List;

/**
 * @author Shreyas K C
 *
 */
public class MetaDataDTO {
    private UserDTO user;
    private List<UserCreationRolesDTO> userCreationRoles;
    private String companyName;
    private HashMap<String, String> fileStatus;
    private List<MetricDTO> metricList;
    private HashMap<Integer, String> phaseStatus;
    private List<String> thresholdReset;

    public UserDTO getUser() {
	return user;
    }

    public void setUser(UserDTO user) {
	this.user = user;
    }

    public List<UserCreationRolesDTO> getUserCreationRoles() {
	return userCreationRoles;
    }

    public void setUserCreationRoles(List<UserCreationRolesDTO> userCreationRoles) {
	this.userCreationRoles = userCreationRoles;
    }

    public String getCompanyName() {
	return companyName;
    }

    public void setCompanyName(String companyName) {
	this.companyName = companyName;
    }

    public HashMap<String, String> getFileStatus() {
	return fileStatus;
    }

    public void setFileStatus(HashMap<String, String> fileStatus) {
	this.fileStatus = fileStatus;
    }

    public List<MetricDTO> getMetricList() {
	return metricList;
    }

    public void setMetricList(List<MetricDTO> metricList) {
	this.metricList = metricList;
    }

    public HashMap<Integer, String> getPhaseStatus() {
	return phaseStatus;
    }

    public void setPhaseStatus(HashMap<Integer, String> phaseStatus) {
	this.phaseStatus = phaseStatus;
    }

    public List<String> getThresholdReset() {
	return thresholdReset;
    }

    public void setThresholdReset(List<String> thresholdReset) {
	this.thresholdReset = thresholdReset;
    }
}
