package com.hydro.api.dto;

public class EventDTO {
    private String id;
    private String fecha;
    private int destino;
    private int kg;
    private int proceso;
    private int cliente;
    private int kg_reales;
    private int formula;
    private String formula_nombre;
    private int fase;
    private int canal;
    private String nombre;
    private String precio;
    private String dosis;
    private String ml_estimados;
    private String ml_reales;
    private String t_estimado;
    private String t_real;
    private String cost_estimated;
    private String coste_real;
    private int tipo_alarma;
    private int laundry_id;
    private long unit_id;
    private String event_type;
    private String washerextractor_name;
    private int formula_phases;
    private String formula_cost;
    private int product_id;
    private int info;
    private int gr_informula;
    private String gr_real;
    private String coste_estimado;
    private int lm2_seq;
    private String unit_name;
    private int equipment_type;
    private String nombre_bomba;
    private String event_id;
    
    private String device_id;

    private String site_id;
    private String siteName;

    private String timeZone;
    private int washerIdleTime;
    private int tunnelIdleTime;

    private String associationId;

    private int alertSetting;

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getFecha() {
	return fecha;
    }

    public void setFecha(String fecha) {
	this.fecha = fecha;
    }

    public int getDestino() {
	return destino;
    }

    public void setDestino(int destino) {
	this.destino = destino;
    }

    public int getKg() {
	return kg;
    }

    public void setKg(int kg) {
	this.kg = kg;
    }

    public int getProceso() {
	return proceso;
    }

    public void setProceso(int proceso) {
	this.proceso = proceso;
    }

    public int getCliente() {
	return cliente;
    }

    public void setCliente(int cliente) {
	this.cliente = cliente;
    }

    public int getKg_reales() {
	return kg_reales;
    }

    public void setKg_reales(int kg_reales) {
	this.kg_reales = kg_reales;
    }

    public int getFormula() {
	return formula;
    }

    public void setFormula(int formula) {
	this.formula = formula;
    }

    public String getFormula_nombre() {
	return formula_nombre;
    }

    public void setFormula_nombre(String formula_nombre) {
	this.formula_nombre = formula_nombre;
    }

    public int getFase() {
	return fase;
    }

    public void setFase(int fase) {
	this.fase = fase;
    }

    public int getCanal() {
	return canal;
    }

    public void setCanal(int canal) {
	this.canal = canal;
    }

    public String getNombre() {
	return nombre;
    }

    public void setNombre(String nombre) {
	this.nombre = nombre;
    }

    public String getPrecio() {
	return precio;
    }

    public void setPrecio(String precio) {
	this.precio = precio;
    }

    public String getDosis() {
	return dosis;
    }

    public void setDosis(String dosis) {
	this.dosis = dosis;
    }

    public String getMl_estimados() {
	return ml_estimados;
    }

    public void setMl_estimados(String ml_estimados) {
	this.ml_estimados = ml_estimados;
    }

    public String getMl_reales() {
	return ml_reales;
    }

    public void setMl_reales(String ml_reales) {
	this.ml_reales = ml_reales;
    }

    public String getT_estimado() {
	return t_estimado;
    }

    public void setT_estimado(String t_estimado) {
	this.t_estimado = t_estimado;
    }

    public String getT_real() {
	return t_real;
    }

    public void setT_real(String t_real) {
	this.t_real = t_real;
    }

    public String getCost_estimated() {
	return cost_estimated;
    }

    public void setCost_estimated(String cost_estimated) {
	this.cost_estimated = cost_estimated;
    }

    public String getCoste_real() {
	return coste_real;
    }

    public void setCoste_real(String coste_real) {
	this.coste_real = coste_real;
    }

    public int getTipo_alarma() {
	return tipo_alarma;
    }

    public void setTipo_alarma(int tipo_alarma) {
	this.tipo_alarma = tipo_alarma;
    }

    public int getLaundry_id() {
	return laundry_id;
    }

    public void setLaundry_id(int laundry_id) {
	this.laundry_id = laundry_id;
    }

    public long getUnit_id() {
	return unit_id;
    }

    public void setUnit_id(long unit_id) {
	this.unit_id = unit_id;
    }

    public String getEvent_type() {
	return event_type;
    }

    public void setEvent_type(String event_type) {
	this.event_type = event_type;
    }

    public String getWasherextractor_name() {
	return washerextractor_name;
    }

    public void setWasherextractor_name(String washerextractor_name) {
	this.washerextractor_name = washerextractor_name;
    }

    public int getFormula_phases() {
	return formula_phases;
    }

    public void setFormula_phases(int formula_phases) {
	this.formula_phases = formula_phases;
    }

    public String getFormula_cost() {
	return formula_cost;
    }

    public void setFormula_cost(String formula_cost) {
	this.formula_cost = formula_cost;
    }

    public int getProduct_id() {
	return product_id;
    }

    public void setProduct_id(int product_id) {
	this.product_id = product_id;
    }

    public int getInfo() {
	return info;
    }

    public void setInfo(int info) {
	this.info = info;
    }

    public int getGr_informula() {
	return gr_informula;
    }

    public void setGr_informula(int gr_informula) {
	this.gr_informula = gr_informula;
    }

    public String getGr_real() {
	return gr_real;
    }

    public void setGr_real(String gr_real) {
	this.gr_real = gr_real;
    }

    public String getCoste_estimado() {
	return coste_estimado;
    }

    public void setCoste_estimado(String coste_estimado) {
	this.coste_estimado = coste_estimado;
    }

    public int getLm2_seq() {
	return lm2_seq;
    }

    public void setLm2_seq(int lm2_seq) {
	this.lm2_seq = lm2_seq;
    }

    public String getUnit_name() {
	return unit_name;
    }

    public void setUnit_name(String unit_name) {
	this.unit_name = unit_name;
    }

    public int getEquipment_type() {
	return equipment_type;
    }

    public void setEquipment_type(int equipment_type) {
	this.equipment_type = equipment_type;
    }

    public String getNombre_bomba() {
	return nombre_bomba;
    }

    public void setNombre_bomba(String nombre_bomba) {
	this.nombre_bomba = nombre_bomba;
    }

    public String getEvent_id() {
	return event_id;
    }

    public void setEvent_id(String event_id) {
	this.event_id = event_id;
    }

    public String getSiteName() {
	return siteName;
    }

    public void setSiteName(String siteName) {
	this.siteName = siteName;
    }

    public String getTimeZone() {
	return timeZone;
    }

    public void setTimeZone(String timeZone) {
	this.timeZone = timeZone;
    }

    public String getAssociationId() {
	return associationId;
    }

    public void setAssociationId(String associationId) {
	this.associationId = associationId;
    }

	public String getDevice_id() {
		return device_id;
	}

	public void setDevice_id(String device_id) {
		this.device_id = device_id;
	}

	public String getSite_id() {
	return site_id;
    }

    public void setSite_id(String site_id) {
	this.site_id = site_id;
    }

    public int getAlertSetting() {
	return alertSetting;
    }

    public void setAlertSetting(int alertSetting) {
	this.alertSetting = alertSetting;
    }

    public int getWasherIdleTime() {
	return washerIdleTime;
    }

    public void setWasherIdleTime(int washerIdleTime) {
	this.washerIdleTime = washerIdleTime;
    }

    public int getTunnelIdleTime() {
	return tunnelIdleTime;
    }

    public void setTunnelIdleTime(int tunnelIdleTime) {
	this.tunnelIdleTime = tunnelIdleTime;
    }
}
