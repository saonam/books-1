package com.hydro.api.dto.reports;

import java.util.HashMap;

public class AlarmDisplayList {
    private HashMap<Integer, AlarmDTO> alarmList;

}
