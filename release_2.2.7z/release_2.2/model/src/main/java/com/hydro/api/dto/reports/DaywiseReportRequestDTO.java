package com.hydro.api.dto.reports;

import java.util.Date;
import java.util.List;

import com.hydro.api.dto.ShiftDTO;

public class DaywiseReportRequestDTO extends DataRequestDTO {
    private String equipmentId;
    private Date date;
    private String siteId;
    private String startShift;
    private String endShift;
    private boolean historicalReport;
    private List<ShiftDTO> selectedShifts;
    public String getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    public Date getDate() {
        return date;
    }
    public void setDate(Date date) {
        this.date = date;
    }
    public String getSiteId() {
        return siteId;
    }
    public void setSiteId(String siteId) {
        this.siteId = siteId;
    }
    public String getStartShift() {
        return startShift;
    }
    public void setStartShift(String startShift) {
        this.startShift = startShift;
    }
    public String getEndShift() {
        return endShift;
    }
    public void setEndShift(String endShift) {
        this.endShift = endShift;
    }
    public boolean isHistoricalReport() {
        return historicalReport;
    }
    public void setHistoricalReport(boolean historicalReport) {
        this.historicalReport = historicalReport;
    }
    public List<ShiftDTO> getSelectedShifts() {
        return selectedShifts;
    }
    public void setSelectedShifts(List<ShiftDTO> selectedShifts) {
        this.selectedShifts = selectedShifts;
    }

}
