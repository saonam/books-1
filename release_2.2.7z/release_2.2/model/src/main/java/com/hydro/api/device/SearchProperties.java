package com.hydro.api.device;

import java.io.Serializable;
import java.util.List;

public class SearchProperties implements  Serializable {

	private String propertyKey;
	private List<String> propertyValue;
	public String getPropertyKey() {
		return propertyKey;
	}
	public void setPropertyKey(String propertyKey) {
		this.propertyKey = propertyKey;
	}
	public List<String> getPropertyValue() {
		return propertyValue;
	}
	public void setPropertyValue(List<String> propertyValue) {
		this.propertyValue = propertyValue;
	}
	
	
	
}
