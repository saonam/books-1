/**
 * 
 */
package com.hydro.api.dto.reports;

import java.util.List;

/**
 * @author Shreyas K C
 *
 */
public class AlarmDTO {

    private String alarmName;
    private Integer alarmId;
    private Integer totalWarnings;
    private Integer totalMachines;
    private List<MachineDTO> machineList;
    private List<String> headerList;
    private List<WarningDTO> systemWarningList;
    private boolean alarmStatus;

    public String getAlarmName() {
	return alarmName;
    }

    public void setAlarmName(String alarmName) {
	this.alarmName = alarmName;
    }

    public Integer getAlarmId() {
	return alarmId;
    }

    public void setAlarmId(Integer alarmId) {
	this.alarmId = alarmId;
    }

    public Integer getTotalWarnings() {
	return totalWarnings;
    }

    public void setTotalWarnings(Integer totalWarnings) {
	this.totalWarnings = totalWarnings;
    }

    public Integer getTotalMachines() {
	return totalMachines;
    }

    public void setTotalMachines(Integer totalMachines) {
	this.totalMachines = totalMachines;
    }

    public List<MachineDTO> getMachineList() {
	return machineList;
    }

    public void setMachineList(List<MachineDTO> machineList) {
	this.machineList = machineList;
    }

    public List<String> getHeaderList() {
	return headerList;
    }

    public void setHeaderList(List<String> headerList) {
	this.headerList = headerList;
    }

    public List<WarningDTO> getSystemWarningList() {
	return systemWarningList;
    }

    public void setSystemWarningList(List<WarningDTO> systemWarningList) {
	this.systemWarningList = systemWarningList;
    }

    public boolean isAlarmStatus() {
	return alarmStatus;
    }

    public void setAlarmStatus(boolean alarmStatus) {
	this.alarmStatus = alarmStatus;
    }
}
