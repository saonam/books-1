package com.hydro.api.dto.reports;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.hydro.api.dto.ShiftDTO;

/**
 * @author Srishti Tiwari
 *
 */
public class DailyReportDTO {
    private Map<Integer, RealTimeAlarmDTO> alarmsMap;
    private Map<Integer, RealTimeAlarmDTO> systemAlarmMap;
    private String siteId;
    private String unitId;
    private String equipmentId;
    private String measurementUnit;
    private ShiftDTO shift;
    private Date date;
    private Double timeElapsedInShift;
    private boolean clearAlarm = true;
    private List<ShiftDTO> selectedShifts;
    private List<ShiftDTO> shiftList;

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getUnitId() {
	return unitId;
    }

    public void setUnitId(String unitId) {
	this.unitId = unitId;
    }

    public String getEquipmentId() {
	return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
	this.equipmentId = equipmentId;
    }

    public String getMeasurementUnit() {
	return measurementUnit;
    }

    public void setMeasurementUnit(String measurementUnit) {
	this.measurementUnit = measurementUnit;
    }

    public Map<Integer, RealTimeAlarmDTO> getAlarmsMap() {
	return alarmsMap;
    }

    public void setAlarmsMap(Map<Integer, RealTimeAlarmDTO> alarmsMap) {
	this.alarmsMap = alarmsMap;
    }

    public Date getDate() {
	return date;
    }

    public void setDate(Date date) {
	this.date = date;
    }

    public Double getTimeElapsedInShift() {
	return timeElapsedInShift;
    }

    public void setTimeElapsedInShift(Double timeElapsedInShift) {
	this.timeElapsedInShift = timeElapsedInShift;
    }

    public Map<Integer, RealTimeAlarmDTO> getSystemAlarmMap() {
	return systemAlarmMap;
    }

    public void setSystemAlarmMap(Map<Integer, RealTimeAlarmDTO> systemAlarmMap) {
	this.systemAlarmMap = systemAlarmMap;
    }

    public boolean isClearAlarm() {
	return clearAlarm;
    }

    public void setClearAlarm(boolean clearAlarm) {
	this.clearAlarm = clearAlarm;
    }

    public List<ShiftDTO> getSelectedShifts() {
	return selectedShifts;
    }

    public void setSelectedShifts(List<ShiftDTO> selectedShifts) {
	this.selectedShifts = selectedShifts;
    }

    public ShiftDTO getShift() {
	return shift;
    }

    public void setShift(ShiftDTO shift) {
	this.shift = shift;
    }

    public List<ShiftDTO> getShiftList() {
	return shiftList;
    }

    public void setShiftList(List<ShiftDTO> shiftList) {
	this.shiftList = shiftList;
    }
}
