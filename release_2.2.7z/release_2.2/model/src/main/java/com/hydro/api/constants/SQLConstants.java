package com.hydro.api.constants;

/**
 * Class holding the queries used across the application.
 * 
 * @author Shreyas, Srishti
 * 
 *         NOTE: All insert statements should have created-date and modified
 *         date as utc_timestamp All modify statements should have modified_date
 *         = utc_timestamp.
 *
 */
public interface SQLConstants {
    // Common Constants
    // Account
    String CREATE_USER = "INSERT INTO USER_MASTER(`user_id`, `first_name`, `middle_name`, `last_name`,`user_name`, `created_by`, `modified_by`,`address1`, `address2`, `city`, `state`,country, `zipcode`, `business_id`,`org_type`, `user_role`,  `phone_number`, `email`,`role_id`, created_date,modified_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
    String UPDATE_USER = "UPDATE USER_MASTER SET first_name=?,middle_name=?,last_name=?, address1=?,address2=?, modified_by=? , state=?,country=?,city=? , zipcode=?, business_id=?, org_type=?,user_role=?, phone_number=?, role_id=?, modified_date = utc_timestamp WHERE user_id=?";
    String BUSINESS_NAME_EXISTS = "SELECT business_id from BUSINESS_MASTER where business_type = ? and LOWER(name) = ? and is_active=1";
    String EMAIL_EXISTS = "SELECT user_id from USER_MASTER where LOWER(email) = ?";
    String USER_NAME_EXISTS = "SELECT user_name from USER_MASTER where LOWER(user_name) = ? and is_active=1";

    String GET_ACCOUNT_DETAILS = "SELECT business_id,name,address1,address2,state,zipcode,city,country,description FROM BUSINESS_MASTER where business_type = ? and business_id = ?";
    // Company
    String GET_COMPANY_DETAILS = "SELECT business_id,name,address1,address2,state,country,zipcode,city,description FROM BUSINESS_MASTER where business_type = ? and business_id = ?";
    String GET_SITES_FOR_COMPANY = "SELECT site_id,site_name,SM.city,SM.zipcode,site_owner,BM.name, BM.business_id,SM.metric_unit from SITE_MASTER SM, BUSINESS_MASTER BM  where SM.site_owner = BM.business_id and  SM.business_id=? and SM.is_active=1 order by SM.created_date desc";
    // Site
    String GET_SITE_DETAILS = "select site_id,BM.name,site_name,SM.description, SM.address1, SM.address2, SM.city, SM.state, SM.zipcode, SM.country,site_owner,metric_unit,SM.business_id,SM.washer_turn_minute,SM.washer_idle_minute,SM.washer_efficiency_threshold,SM.tunnel_turn_minute,SM.tunnel_idle_minute,SM.tunnel_efficiency_threshold,time_zone,alert_setting,streaming_enabled from site_master SM left join business_master BM on SM.business_id =BM.business_id where site_id=?";
    String GET_VALID_SITES_COUNT = "SELECT count(1) AS SITE_COUNT from SITE_MASTER where site_id in ";
    String BUSINESS_ID_EXISTS = "SELECT business_id from BUSINESS_MASTER where business_type = ? and business_id = ?";
    String USER_PERMISSION = "select privilege_name from privilege_master where privilege_id in(select privilege_id from role_privilege_association where role_id=(select role_id from user_master where user_id =?))";
    String GET_USER_DETAILS = "SELECT user_id,first_name,middle_name,last_name,user_name,email,phone_number,UM.user_role,"
	    + "UM.business_id,site_id,UM.org_type,UM.created_date,UM.address1,UM.address2,UM.is_active,UM.state,UM.country,UM.city,UM.created_by,"
	    + "UM.zipcode,BM.name, RM.clearance_level "
	    + "FROM ROLE_MASTER RM,USER_MASTER UM left join BUSINESS_MASTER BM on UM.business_id = BM.business_id "
	    + "where user_id = ? and RM.role_id = (select role_id from user_master where user_id= UM.user_id)";
    String GET_ROLES = "SELECT user_role,role_id, clearance_level,org_type from ROLE_MASTER";

    // File
    String CREATE_FILE = "INSERT INTO FILE_MASTER(file_id, name, created_by, status, description, site_id, modified_by, created_date, modified_date) values(?,?,?,?,?,?,?, utc_timestamp,utc_timestamp) ";
    String INSERT_FILE = "INSERT INTO FILE_MASTER (file_id, name, created_by, status, site_id, description, detailed_description, version, modified_by, file_type, device_id, is_active, created_date, modified_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, utc_timestamp,utc_timestamp)";
    String UPDATE_LM2FILE = "UPDATE FILE_MASTER set status=?, description=?, version=?, lm2_file=?, modified_by=?, file_type=?,modified_date=utc_timestamp where file_id=?";
    String UPDATE_EQUIIP_LM2FILE = "UPDATE FILE_MASTER set status=?, description=?, detailed_description=?, version=?, file_type=?, modified_date=utc_timestamp where file_id=?";
    String UPDATE_EQUIIP_LM2FILE_ACTIVE = "UPDATE FILE_MASTER set is_active=0, modified_date=utc_timestamp where file_id!=? AND device_id=?";
    String GET_LM2_UPLOAD_COUNT = "SELECT count(site_id) as lm2_upload_count FROM FILE_MASTER where site_id =?";
    String UPDATE_FILE_STATUS = "update FILE_MASTER set status=?, description=?, detailed_description=?, modified_date = utc_timestamp where file_id=?";
    String UPDATE_FILE_STATUS_FAILURE = "update FILE_MASTER set status=?, description=?, detailed_description=?, modified_date = utc_timestamp where status in (?,?,?)";
    String FILE_ID_EXIST = "select file_id from FILE_MASTER where file_id =?";
    String MDB_FILE_STATUS = "UPDATE FILE_MASTER set status=?, description=?,version=?, modified_by=?, file_type=?, modified_date=utc_timestamp where file_id=?";
    String UPDATE_FILE_ID_IN_SITE_MASTER = "update SITE_MASTER SET file_id=?, modified_date = utc_timestamp where site_id=?";
    String INSERT_ES_ERROR_LOG = "INSERT into ES_ERROR_LOG(error_id, site_id, file_id, description, error_type, es_error, index_name, es_document, created_by, created_date, modified_by, modified_date, es_type, month, year) values(?,?,?,?,?,?,?,?,?, utc_timestamp,?, utc_timestamp,?,?,?)";
    String GET_CONFIG_UPLOAD_COUNT = "SELECT count(site_id) as config_upload_count FROM hydro.FILE_MASTER where site_id =? and file_type = ?";
    String UPDATE_JSONFILE = "UPDATE FILE_MASTER set status=?, description=?, file_type=?,version=?, lm2_file=?, modified_by=?, file_type=?,modified_date=utc_timestamp where file_id=?";
    String UPDATE_JSON_LM2_FILE_STATUS = "update FILE_MASTER set status=?, description=?, detailed_description=?, modified_date = utc_timestamp, is_active = 1 where file_id=?";
    String UPDATE_CONFIGFILE_INACTIVE = "UPDATE FILE_MASTER set is_active=0, modified_date=utc_timestamp where file_id!=? AND unit_id = ? AND site_id = ? AND is_active=1 AND file_type = 6";
    // Equipment Data

    String GET_EQUIPMENT_LIST = "SELECT equipment_id, lm2_seq,device_id,alias,equipment_type,file_id FROM EQUIPMENT_MASTER where  file_id IN (select file_id from FILE_MASTER where site_id = ? and is_active=1 and device_id is not null)  order by lm2_seq";
    String GET_EQUIPMENT_LIST_FOR_TYPE = "SELECT equipment_id, lm2_seq,device_id,alias,equipment_type,file_id FROM EQUIPMENT_MASTER where %s file_id IN (select file_id from FILE_MASTER where site_id = ? and is_active=1 and device_id is not null)  order by lm2_seq";
    String GET_WASHER_LIST = "SELECT washer_id, lm2_seq,wm.name,wm.load FROM WASHER_MASTER wm where equipment_id =  ?";
    String GET_TUNNEL_LIST = "SELECT tunnel_id, lm2_seq,tm.name,tm.load,modules_count FROM TUNNEL_MASTER tm where equipment_id =  ?";
    String GET_FORMULA_LIST = "SELECT formula_id, lm2_seq,name FROM FORMULA_MASTER where equipment_id =  ?";
    String GET_FORMULA_FOR_LM2 = "SELECT formula_id, lm2_seq, name FROM FORMULA_MASTER where equipment_id =  ? and lm2_seq=?";
    String EQUIPMENT_ID_EXISTS = "select equipment_id from EQUIPMENT_MASTER where equipment_id=? and site_id=?";
    String GET_PRODUCT_LIST = "SELECT product_id, lm2_seq,name,concentration,FORMAT, price FROM PRODUCT_MASTER where equipment_id =  ?";
    String GET_TUNNEL_DETAIL_FOR_DEVICE = "select tunnel_id, lm2_seq, name from tunnel_master where equipment_id = (select equipment_id from equipment_master where file_id=(select file_id from file_master where device_id=? and is_active=1))";
    String GET_EQUIPMENT_DETAIL_FOR_DEVICE = "select equipment_id, site_id, lm2_seq, alias, equipment_type, file_id, device_id from equipment_master where file_id=(select file_id from file_master where device_id=? and is_active=1)";
    String GET_EQUIPMENT = "SELECT equipment_id, lm2_seq,device_id,alias,equipment_type,file_id FROM EQUIPMENT_MASTER where site_id=? and equipment_id=?";
    // Observation
    String CREATE_OBSERVATION = "INSERT INTO OBSERVATION_MASTER(observation_id,site_id,lm2_seq, observation, recommendation, created_by,modified_by,equipment_id, month, year,created_date,modified_date, device_id) values(?,?,(select lm2_seq from EQUIPMENT_MASTER where equipment_id=?),?,?,?,?,?,?,?,utc_timestamp,utc_timestamp,(select device_id from EQUIPMENT_MASTER where equipment_id=?))";

    // LM2 data.

    String INSERT_INTO_EQUIPMENT_MASTER = "Insert into EQUIPMENT_MASTER(equipment_id, lm2_seq, site_id, alias, equipment_type, slave, ip_address, observations, washer_count, tunnel_count, w_machine_chnl_count, pump_count, channel_count, is_active, created_by, modified_by, version, file_id, created_date,modified_date,device_id) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp,?)";
    String INSERT_INTO_EQUIPMENT_PUMP = "INSERT into EQUIPMENT_PUMP(pump_id, equipment_id, pump_name, pump_value) values(?,?,?,?)";
    String INSERT_INTO_FORMULA_MASTER = "INSERT into FORMULA_MASTER(formula_id, equipment_id, lm2_seq, name, `load`, phases, color, created_by, modified_by,created_date,modified_date) value(?,?,?,?,?,?,?,?,?, utc_timestamp,utc_timestamp)";
    String INSERT_INTO_EQUIPMENT_FORMULA = "INSERT into equipment_formula(formula_id, equipment_id, formula_name, formula_value) VALUES(?,?,?,?)";
    String INSERT_INTO_EQUIPMENT_PUMP_MACHINERY = "INSERT INTO EQUIPMENT_PUMP_MACHINERY(pump_machine_id, equipment_id, pump_machine_name, pump_machine_value) value(?,?,?,?)";
    String INSERT_INTO_EQUIPMENT_TUNEEL_CHANNEL = "INSERT into EQUIPMENT_TUNNEL_CHANNEL(tunnel_channel_id, equipment_id, tunnel_channel_name, tunnel_channel_value) values(?,?,?,?)";
    String INSERT_INTO_PRODUCT_MASTER = "INSERT into PRODUCT_MASTER(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow, frequency, docification_mode, priority, contact, alarms_ignored, percentage, drag_type, pump_speed, format, price, calibration, color1, color2, created_by,modified_by,created_date,modified_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
    String INSERT_INTO_WATER_MASTER = "INSERT into WATER_MASTER(water_id, equipment_id,lm2_seq, name, kf, flow, water_time, cellphone_minute, docification_mode, seperation_ml, ignored_alarms, percentage, diameter, pump_type, created_by,modified_by,created_date,modified_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, utc_timestamp,utc_timestamp)";
    String INSERT_INTO_WASHER_MASTER = "INSERT into WASHER_MASTER(washer_id, equipment_id, lm2_seq, name, `load`, modifiable_load, ltr_drag, cellular_minutes, id_formula, work_mode, reset_mode, reset_signal, reset_formula, unused_machine, unused_time_delay, unused_timeout, t_acceptation, t_repetition, t_lock, type_programmer, signal_count, signal_voltage, signal_connection, observation, created_by,modified_by,created_date,modified_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
    String INSERT_INTO_TUNNEL_MASTER = "INSERT into TUNNEL_MASTER(tunnel_id, equipment_id, lm2_seq, name, `load`, modules_count, module_count_dosif, load_min, load_max, formula_id, ltr, cellular_minutes, modules_per_channel, created_by, modified_by,created_date,modified_date) value(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
    String INSERT_INTO_TUNNEL_MODULE_PRODUCT_ASSOCIATION = "INSERT into TUNNEL_MODULE_PRODUCT_ASSOCIATION(id, tunnel_id, module_id, product_id, created_by, modified_by,created_date,modified_date) value(?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
    String INSERT_INTO_FORMULA_PDB = "INSERT into FORMULA_PDB(pdb_id, formula_id, pdb_name, pdb_value) value(?,?,?,?)";
    String INSERT_INTO_TUNNEL_PRODUCTS = "INSERT into TUNNEL_PRODUCTS(tunnel_id, product_id, product_name, product_value) value(?,?,?,?)";
    String GET_SITES_ASSOCIATED_TO_COMPANY = "SELECT site_id,site_name from SITE_MASTER where business_id=? and is_active=1";
    String GET_SITE_LIST = "   SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by,SM.alert_setting,"
	    + " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
	    + "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
	    + "FROM SITE_MASTER SM, BUSINESS_MASTER BM , BUSINESS_MASTER BM2 "
	    + "where  BM.business_id= SM.site_owner and" + " BM2.business_id = SM.BUSINESS_ID"
	    + " and SM. business_id = ? and SM.is_active=1 order by SM.created_date desc";
    String GET_SITE_LIST_PARTIAL = "   SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by,SM.alert_setting,"
	    + " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
	    + "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
	    + "FROM SITE_MASTER SM, BUSINESS_MASTER BM , BUSINESS_MASTER BM2 "
	    + "where  BM.business_id= SM.site_owner and" + " BM2.business_id = SM.BUSINESS_ID"
	    + "  and SM.is_active=1  and SM. business_id in ( ";
    String SITE_LIST_BY_SITENAME = " ) order by SM.site_name asc";
    String SITE_LIST_BY_CT_DATE = " ) order by SM.created_date desc";

    String GET_SITE_LIST_SORTED_BY_NAME = "   SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by,SM.alert_setting,"
	    + " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
	    + "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
	    + "FROM SITE_MASTER SM, BUSINESS_MASTER BM , BUSINESS_MASTER BM2 "
	    + "where  BM.business_id= SM.site_owner and" + " BM2.business_id = SM.BUSINESS_ID"
	    + " and SM. business_id = ? and SM.is_active=1 order by SM.site_name asc";

    String GET_COMPANY_NAME_SITE_NAME = "select BM.name,site_name,SM.metric_unit from business_master BM left join site_master SM on BM.business_id=SM.business_id where BM.business_type=? and BM.business_id=(select business_id from site_master where site_id=?) and site_id=?";

    String GET_ALARM_LIST = "select alarm_id, alarm_type, alarm_name, description from alarm_master";
    String GET_USER_ROLE_LIST = "select role_id, user_role from role_master";
    String GET_COMPNAY_PREFERENCE_DETAILS = "select distinct PM.alarm_id,PM.role_id,RM.user_role ,PM.sms, PM.email, PM.threshold,PM.threshold_refresh_interval,AM.alarm_type,AM.alarm_name,AM.description from hydro.preference_master PM left join hydro.alarm_master AM on AM.alarm_id= PM.alarm_id left join hydro.role_master RM on RM.role_id=PM.role_id where PM.business_id =? and site_id is null";
    String INSERT_INTO_PREFERENCE_MASTER = "INSERT into preference_master(id, business_id,site_id, unit_id, machine_id,role_id, alarm_id, sms, email, threshold, threshold_refresh_interval,created_by, created_date, modified_by, modified_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,?,utc_timestamp)";

    String CHECK_USER_PREFERENCE_EXIST = "select user_id from user_alarm_preference where user_id=?";
    String USER_PREFERENCE = "select UAP.alarm_id, AM.alarm_name, AM.description,UAP.active from user_alarm_preference UAP left join alarm_master AM on AM.alarm_id=UAP.alarm_id where user_id=?";
    String INSERT_INTO_USER_ALARM_PREFERENCE = "INSERT into user_alarm_preference(id, user_id, alarm_id, active, created_by, created_date, modified_by, modified_date) VALUES(?,?,?,?,?,utc_timestamp,?,utc_timestamp)";
    String UPDATE_USER_ALARM_PREFERENCE = "UPDATE user_alarm_preference set active=?,modified_by=?, modified_date=utc_timestamp where id=?";
    String CHECK_COMPANY_PREFERENCE_EXIST = "select business_id from preference_master where business_id=?";
    String CHECK_SITE_PREFERENCE = "select distinct site_id, business_id from preference_master where site_id=?";
    String GET_DEFAULT_USER_PREFERENCE = "select alarm_id,alarm_name, description from alarm_master where alarm_id in(select alarm_id from preference_master where business_id=? and role_id=? and (sms is true or email is true))";
    String DELETE_USER_PREFERENCE = "DELETE from user_alarm_preference where user_id=? ";
    String GET_ALARM_ID = "UAP.alarm_id in (select alarm_id from preference_master where business_id=? and (sms is true or email is true) and role_id=?";
    String DISTINCT_BUSINESS_QUERY = "(select distinct business_id from preference_master ) and role_id=? and (email=true or sms=true) )";

    String GET_SITES_FOR_BUSINESS = "select site_id from site_master where business_id=?";
    String DELETE_PREFERENCE_DETAILS = "DELETE from preference_master where site_id=?";

    String BUSINESS_SITE_PREFERENCE_EXIST = "select site_id from preference_master where site_id=? and business_id =?";

    String DELETE_USER_SITE_ASSOCIATION = "DELETE from user_site_association where site_id=?";
    String GET_MACHINE_FOR_TUNNEL = "select lm2_seq from tunnel_master where equipment_id =?";
    String GET_MACHINE_FOR_WASHER = "select lm2_seq from washer_master where equipment_id =?";

    String GET_SITES_LIST_FROM_PREFERENCE_TABLE = "select GROUP_CONCAT(site_id) as grouped_site_id, time_zone from site_master where site_id in (select distinct site_id from preference_master where site_id is not null) group by time_zone";
    String GET_DEVICE_ID_FOR_EQUIPMENT = "select device_id from file_master where file_id = (select file_id from equipment_master where equipment_id = ?)";

    // Configuration INSERT
    String CONFIG_INSERT_FILE_MASTER = "insert into file_master (file_id, name, created_by, status, description, site_id, lm2_file, file_type,device_id,is_active) VALUES (?,?,?,?,?,?,?,?,?,?)";
    String CONFIG_INSERT_FORMULA_MASTER = "INSERT into FORMULA_MASTER(formula_id,  equipment_id, lm2_seq, name,  phases, uid) values(?,?,?,?,?,?)";
    String CONFIG_INSERT_PRODUCT_MASTER = "INSERT into PRODUCT_MASTER(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow,  docification_mode, priority,  alarms_ignored,  price,uid) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
    String CONFIG_INSERT_WASHER_MASTER = "INSERT into WASHER_MASTER(washer_id, equipment_id, lm2_seq, name, `load`,  id_formula, uid) values(?,?,?,?,?,?,?)";
    String CONFIG_INSERT_TUNNEL_MASTER = "INSERT into TUNNEL_MASTER(tunnel_id, equipment_id, lm2_seq, name, `load`,  formula_id , uid) values(?,?,?,?,?,?,?)";
    String CONFIG_INSERT_WATER_MASTER = "INSERT into WATER_MASTER(water_id, equipment_id,lm2_seq,  kf, flow,uid) values(?,?,?,?,?,?)";
    String CONFIG_INSERT_EQUIPMENT_MASTER = "insert into equipment_master (equipment_id, site_id, file_id, equipment_type, alias, version, ip_address, washer_count, w_machine_chnl_count, lm2_seq,device_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
    String CONFIG_UPDATE_SITE_MASTER = "update site_master SET file_id= ? where site_id= ?";
    String CONFIG_GET_SITE_ID = "select site_id from site_master where site_Name= ? ";

    // get module details
    String GET_MODULE_PRODUCT_DETAILS = "select module_id, product_id from tunnel_module_product_association where tunnel_id = (select tunnel_id from tunnel_master where equipment_id = ?) and product_id != \"\\n\" and module_id !=\"\\n\"";

    String GET_LAUNDRY_DETAIL = "SELECT * from site_master WHERE site_id=?";
    String GET_UNITS_DETAIL = "SELECT * FROM equipment_master WHERE file_id in (select file_id from file_master where site_id=? and is_active=1)";
    String GET_CHANNELS_DETAIL = "SELECT * FROM channel_master WHERE equipment_id=?";
    String GET_WATERS_DETAIL = "SELECT * FROM water_master WHERE equipment_id=?";
    String GET_PRODUCTS_DETAIL = "SELECT * FROM product_master WHERE equipment_id=?";
    String GET_WASHERS_DETAIL = "SELECT * FROM washer_master wm WHERE equipment_id = ?";
    String GET_TUNNELS_DETAIL = "SELECT * FROM tunnel_master WHERE equipment_id = ?";
    String GET_FORMULAS_DETAIL = "SELECT * FROM formula_master WHERE equipment_id=?;";
    String GET_FORMULA_PHASES_DETAIL = "SELECT * FROM formula_phases WHERE equipment_id=? and id_formula = ?";
    String GET_FORMULA_DOSAGES_DETAIL = "SELECT * FROM formula_dosages WHERE f_phase_id=?";
    String CREATE_FAILED_EVENTS_ENTRY = "INSERT INTO cloud_failed_events(id, site_id, unit_id, serial_number, event_id, event_time, event_blob, created_date) values(?,?,?,?,?,?,?,utc_timestamp)";

    /**
     * Queries used by the hydroadmin.
     * 
     * @author Shreyas K C, Srishti Tiwari
     *
     */
    interface HydroAdmin {

	// Queries for file
	String GET_FILE_HISTORY = "Select site_name,version,name, FM.file_id, FM.is_active, FM.created_by, FM.created_date, status, FM.description, FM.file_type from SITE_MASTER SM inner join FILE_MASTER FM on SM.site_id = FM.site_id where FM.device_id is null ORDER BY created_date DESC LIMIT 300";

	// Contact Master
	String DELETE_CONTACT_INFO = "DELETE FROM CONTACT_MASTER WHERE contact_id in ";
	String CREATE_CONTACT_INFO = "INSERT INTO CONTACT_MASTER(contact_id,business_id, site_id,email,name, number, title,created_by, modified_by,created_date,modified_date) values(?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
	String UPDATE_CONTACT_INFO = "UPDATE CONTACT_MASTER SET email =?, name=?, number = ?, title = ?, modified_by =?, modified_date = utc_timestamp WHERE contact_id=?";
	String GET_CONTACT_LIST_FOR_BUSINESS = "SELECT contact_id,email, name, number, title from CONTACT_MASTER where business_id = ?";
	String GET_CONTACT_ID_FOR_BUSINESS = "select contact_id from CONTACT_MASTER where business_id = ?";
	String GET_CONTACT_ID_FOR_SITE = "select contact_id from CONTACT_MASTER where site_id=?";
	String GET_CONTACT_LIST_FOR_SITE = "SELECT contact_id,email, name, number, title from CONTACT_MASTER where site_id =?";

	// Account Screen Queries
	String GET_ACCOUNT_LIST = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and is_active=1 order by created_date desc";
	String GET_ACCOUNT_LIST_SORTED_ON_NAME = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and is_active=1 order by name asc";
	String UPDATE_LOGIN_DETAILS = "UPDATE USER_MASTER SET modified_by=USER_ID ,modified_date=utc_timestamp,jwt_token=?  WHERE password_hash=? AND email=?";
	String SEARCH_USER_LIST = "SELECT user_id,first_name,last_name,profile_image,email,created_by FROM USER_MASTER where concat_ws('',last_name,first_name,email,address,state,zipcode) REGEXP ?";
	String GET_SITES_FOR_ACCOUNT = "SELECT site_id,site_name from SITE_MASTER where site_owner = ? and is_active=1";
	String CREATE_ACCOUNT = "INSERT INTO BUSINESS_MASTER (`business_id`, `name`, `business_type`,  `address1`, `address2`, `created_by`, `modified_by`, `state`,country,`city`, `zipcode`, `description`, created_date,modified_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,utc_timestamp,utc_timestamp)";
	String UPDATE_BUSINESS = "UPDATE BUSINESS_MASTER set  name=?, address1=?,address2=?, modified_by=? , state=?,country=?,city=? , zipcode=?, description=?, modified_date = utc_timestamp where business_id=?";

	// Company Screen Queries
	String GET_COMPANY_LIST = "SELECT business_id,created_date , name,state,zipcode,city, created_by, country FROM BUSINESS_MASTER where business_type = ? and is_active=1 order by created_date desc ";
	String GET_COMPANY_LIST_SORTED_ON_NAME = "SELECT business_id,created_date , name,state,zipcode,city, created_by, country FROM BUSINESS_MASTER where business_type = ? and is_active=1 order by name asc ";
	String GET_COMPANY_DETAILS = "SELECT business_id,name,address1,address2,state,country,zipcode,city,description,contact_title,contact_name,contact_number,contact_email  FROM BUSINESS_MASTER where business_type = ? and business_id = ?";
	String GET_SITES = "SELECT site_id,site_name,SM.city,SM.zipcode,site_owner,BM.name, BM.business_id,SM.created_date,SM.metric_unit from SITE_MASTER SM, BUSINESS_MASTER BM  where SM.site_owner = BM.business_id and SM.is_active=1 order by SM.created_date desc";
	String CREATE_COMPANY = "INSERT INTO BUSINESS_MASTER (`business_id`, `name`, `business_type`,  `address1`, `address2`, `created_by`, `modified_by`, `state`,country,`city`, `zipcode`, `description`, created_date,modified_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,utc_timestamp,utc_timestamp)";
	// Site Screen Queries
	String GET_SITE_LIST = "SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by, SM.alert_setting,"
		+ " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
		+ "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
		+ "FROM SITE_MASTER SM  left join BUSINESS_MASTER BM on  "
		+ "BM.business_id = SM.site_owner left join BUSINESS_MASTER BM2 on  "
		+ " BM2.business_id = SM.BUSINESS_ID where SM.is_active = 1 order by SM.created_date desc ";

	String GET_SITE_LIST_SORTED_ON_NAME = "SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by, SM.alert_setting,"
		+ " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
		+ "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
		+ "FROM SITE_MASTER SM  left join BUSINESS_MASTER BM on  "
		+ "BM.business_id = SM.site_owner left join BUSINESS_MASTER BM2 on  "
		+ " BM2.business_id = SM.BUSINESS_ID where SM.is_active = 1 order by SM.site_name asc ";

	String GET_SITE_LIST_CREATED_DATE_FILTER = "SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by, SM.alert_setting,"
		+ " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
		+ "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
		+ "FROM SITE_MASTER SM  left join BUSINESS_MASTER BM on  "
		+ "BM.business_id = SM.site_owner left join BUSINESS_MASTER BM2 on  "
		+ " BM2.business_id = SM.BUSINESS_ID where SM.is_active = 1 and SM.created_date between ? and ? order by SM.created_date desc ";

	String CREATE_SITE = "INSERT INTO SITE_MASTER(`site_id`, `site_name`, `description`, `created_by`, `modified_by`,`address1`, `address2`, `country`, `city`, `state`, `zipcode`,site_owner,metric_unit, created_date,modified_date, business_id,washer_turn_minute,washer_idle_minute,washer_efficiency_threshold,tunnel_turn_minute,tunnel_idle_minute,tunnel_efficiency_threshold,time_zone,alert_setting, streaming_enabled) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp,?,?,?,?,?,?,?,?,?,?)";
	// String UPDATE_SITE = "UPDATE SITE_MASTER SET site_name =
	// ifnull(@site_name, ?), address1 = ifnull(@address1,?),address2 =
	// ifnull(@address2,?),state = ifnull(@state,?),city =
	// ifnull(@city,?),zipcode = ifnull(@zipcode,?),description =
	// ifnull(@description,?), contact_title =
	// ifnull(@contact_title,?),contact_name = ifnull(@contact_name,?),
	// contact_number = ifnull(@contact_number,?), contact_email =
	// ifnull(@contact_email,?) WHERE site_name=?";
	String UPDATE_SITE = "UPDATE SITE_MASTER SET site_name=?, address1=?,address2=?,modified_by=?, state=?,country=?,city=? , zipcode=?, description=?,metric_unit=?,modified_date = utc_timestamp, site_owner=?,business_id=?,washer_turn_minute=?,washer_idle_minute=?,washer_efficiency_threshold=?,tunnel_turn_minute=?,tunnel_idle_minute=?,tunnel_efficiency_threshold=?,time_zone=?,alert_setting=?,streaming_enabled=? WHERE site_id=?";
	String SITE_NAME_EXIST = "select site_id from SITE_MASTER where LOWER(site_name) =? and site_owner =? and is_active=1";
	String UPDATE_SITE_BUSINESS = "update site_master set business_id = ? where site_id = ?";
	String UPDATE_SITE_SPECIFIC_BUSINESS = "update site_master set business_id = ? where business_id = ? ";
	// User Page
	String GET_USER_LIST = "SELECT user_id,first_name,middle_name,last_name,user_name,email,phone_number,UM.user_role,UM.business_id,site_id,UM.org_type,UM.created_date,UM.created_by,UM.address1,UM.address2,UM.is_active,UM.state,UM.country,UM.city,UM.zipcode,BM.name,clearance_level FROM ROLE_MASTER,USER_MASTER UM left join BUSINESS_MASTER BM on UM.business_id = BM.business_id WHERE UM.user_id != ? and UM.is_active = 1 and ROLE_MASTER.role_id = (select role_id from user_master where user_id = UM.user_id) order by UM.created_date desc";
	String GET_USER_LIST_CREATED_DATE_FILTER = "SELECT user_id,first_name,middle_name,last_name,user_name,email,phone_number,UM.user_role,UM.business_id,site_id,UM.org_type,UM.created_date,UM.created_by,UM.address1,UM.address2,UM.is_active,UM.state,UM.country,UM.city,UM.zipcode,BM.name,clearance_level FROM ROLE_MASTER,USER_MASTER UM left join BUSINESS_MASTER BM on UM.business_id = BM.business_id WHERE UM.user_id != ? and UM.is_active = 1 and ROLE_MASTER.role_id = (select role_id from user_master where user_id = UM.user_id) and UM.created_date between ? and ? order by UM.created_date desc ";
	String TOGGLE_ACTIVATE_USER = "UPDATE USER_MASTER SET is_active=?, modified_by=?, modified_date = utc_timestamp  WHERE user_id=?";
	// Observation Master

	String UPDATE_OBSERVATION = "update OBSERVATION_MASTER set observation=?, recommendation=?, modified_by=?,modified_date = utc_timestamp where observation_id=?";
	String DELETE_OBSERVATION = "delete from OBSERVATION_MASTER where observation_id =?";
	String GET_OBSERVATION_LIST = "select observation_id, observation, recommendation, created_by, created_date, modified_by, modified_date from OBSERVATION_MASTER where site_id=? and month=? and year=? and device_id=(select device_id from EQUIPMENT_MASTER where equipment_id=?) order by created_date desc";

	// Shift Master
	String CREATE_SHIFT = "INSERT INTO SHIFT_MASTER(site_id,shift_id, shift_name,start_time,end_time,created_by, modified_by,created_date,modified_date) values(?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
	String GET_SHIFT_DETAILS_FOR_SITE = "select shift_id, shift_name,start_time,end_time from SHIFT_MASTER where site_id=?";
	String UPDATE_SHIFT_INFO = "UPDATE SHIFT_MASTER SET shift_name =?, start_time=?, end_time = ?, modified_by =?, modified_date = utc_timestamp WHERE shift_id=?";
	String DELETE_SHIFT_INFO = "DELETE FROM SHIFT_MASTER WHERE shift_id in ";
	String DELETE_SHIFT_FOR_SITE = "DELETE FROM SHIFT_MASTER WHERE site_id =?";

	String UPDATE_PREFERENCE_MASTER = "UPDATE preference_master set sms=?,email=?,threshold=?,threshold_refresh_interval=?, modified_by=?, modified_date=utc_timestamp where business_id=? and role_id=? and alarm_id=?";

	String GET_USER_PREFERENCE_DETAILS = "select distinct t1.alarm_id, t1.alarm_name, t1.alarm_type, t1.description,COALESCE(t2.active, true) as active from(Select PM.alarm_id, AM.alarm_name, AM.alarm_type, AM.description, true as active from preference_master PM left join alarm_master AM on AM.alarm_id=PM.alarm_id  where (sms is true or email is true) and role_id = ?) t1 Left join (select UAP.alarm_id, active from user_alarm_preference UAP where user_id=? and UAP.alarm_id in (select distinct alarm_id from preference_master where (sms is true or email is true) and role_id=?)) t2 on t1.alarm_id =t2.alarm_id";

	String GET_COMPANY_LIST_CREATED_DATE_FILTER = "SELECT business_id,created_date , name,state,zipcode,city, created_by, country FROM BUSINESS_MASTER where business_type = ? and is_active=1 and created_date between ? and ? order by created_date desc ";

	String GET_ACCOUNT_LIST_CREATED_DATE_FILTER = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and is_active=1 and created_date between ? and ? order by created_date desc";
    }

    /**
     * Company Admin related queries.
     * 
     * @author 11013988, Srishti
     *
     */
    interface Company {
	String GET_COMPANY_LIST = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and business_id =? order by created_date";
	String GET_COMPANY_LIST_SORTED_ON_NAME = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and business_id =? order by name asc";
	String GET_CONTACT_LIST_FOR_SITE = "SELECT contact_id,email, name, number, title from CONTACT_MASTER where site_id =(select site_id from site_master where site_id=? and business_id =?)";
	String SITE_NAME_EXIST = "select site_id from SITE_MASTER where LOWER(site_name) =? and site_owner = (select site_owner from site_master where site_id =?) and is_active=1";
	String GET_COMPANY_LIST_CREATED_DATE_FILTER = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and business_id =? and created_date between ? and ? order by created_date";

	interface full {
	    // Account Screen Queries
	    String GET_ACCOUNT_LIST = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and business_id in (select site_owner from SITE_MASTER where business_id =?) and is_active=1 order by created_date desc";
	    String GET_ACCOUNT_LIST_SORTED_ON_NAME = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and business_id in (select site_owner from SITE_MASTER where business_id =?) and is_active=1 order by name asc";
	    String GET_ACCOUNT_ASSOCIATION_ID = "SELECT business_id FROM BUSINESS_MASTER where business_type = ? and business_id = ? and business_id in (select site_owner from SITE_MASTER where business_id =?) ";
	    String GET_SITES_FOR_ACCOUNT = "SELECT site_id,site_name from SITE_MASTER where site_owner = ? and business_id =? and is_active=1 order by created_date desc";
	    // Company Screen Queries
	    // Site Screen Queries
	    String GET_SITE_LIST = "SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by, SM.alert_setting,"
		    + " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
		    + "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
		    + "FROM SITE_MASTER SM, BUSINESS_MASTER BM , BUSINESS_MASTER BM2 "
		    + "where  BM.business_id= SM.site_owner and" + " BM2.business_id = SM.BUSINESS_ID"
		    + " and SM. business_id = ? and SM.is_active=1 order by SM.created_date desc";

	    String GET_SITE_LIST_SORTED_ON_NAME = "SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by, SM.alert_setting,"
		    + " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
		    + "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
		    + "FROM SITE_MASTER SM, BUSINESS_MASTER BM , BUSINESS_MASTER BM2 "
		    + "where  BM.business_id= SM.site_owner and" + " BM2.business_id = SM.BUSINESS_ID"
		    + " and SM. business_id = ? and SM.is_active=1 order by SM.site_name asc";

	    String GET_SITE_ASSOCIATED_TO_COMPANY = "SELECT site_id from SITE_MASTER where business_id=? and site_id = ?";
	    // File services
	    String GET_FILE_HISTORY = "Select SITE_MASTER.site_name, FILE_MASTER.name, FILE_MASTER.file_id, FILE_MASTER.is_active, FILE_MASTER.created_by, FILE_MASTER.created_date, status, FILE_MASTER.description, FILE_MASTER.file_type from FILE_MASTER left join SITE_MASTER on FILE_MASTER.site_id=SITE_MASTER.site_id where FILE_MASTER.site_id in(SELECT site_id from SITE_MASTER where  business_id =? ) AND FILE_MASTER.device_id is null order by FILE_MASTER.created_date desc limit 300";
	    // OBSERVATION MASTER
	    String UPDATE_OBSERVATION = "update OBSERVATION_MASTER set observation=?, recommendation=?,modified_by=?, modified_date = utc_timestamp where observation_id=? and equipment_id in(select equipment_id from EQUIPMENT_MASTER where site_id in(select site_id from SITE_MASTER where business_id = ?))";
	    String DELETE_OBSERVATION = "delete from OBSERVATION_MASTER where observation_id =? and equipment_id in(select equipment_id from EQUIPMENT_MASTER where site_id in(select site_id from SITE_MASTER where business_id = ?))";
	    String GET_OBSERVATION_LIST = "select observation_id, observation, recommendation, created_by, created_date,modified_by, modified_date from OBSERVATION_MASTER where device_id = (select device_id from EQUIPMENT_MASTER where equipment_id=? and site_id =(select site_id from SITE_MASTER where business_id =? and site_id =?))and month=? and year=? and site_id=? order by created_date desc";

	    String GET_USER_LIST = "SELECT user_id,first_name,middle_name,last_name,user_name,email,phone_number,UM.user_role,"
		    + "UM.business_id,site_id,UM.org_type,UM.created_date,UM.address1,"
		    + " UM.address2,UM.is_active,UM.state,UM.country,UM.city,"
		    + "UM.zipcode,BM.name,UM.created_by,UM.created_date, clearance_level "
		    + "FROM ROLE_MASTER RM,USER_MASTER UM left join BUSINESS_MASTER BM on UM.business_id = BM.business_id where "
		    + "UM.user_id != ? and UM.business_id = ?  and RM.role_id = UM.role_id and "
		    + " RM.clearance_level >= ? and UM.is_active =1 " + "order by UM.created_date desc";

	    String GET_USER_LIST_CREATED_DATE_FILTER = "SELECT user_id,first_name,middle_name,last_name,user_name,email,phone_number,UM.user_role,"
		    + "UM.business_id,site_id,UM.org_type,UM.created_date,UM.address1,"
		    + " UM.address2,UM.is_active,UM.state,UM.country,UM.city,"
		    + "UM.zipcode,BM.name,UM.created_by,UM.created_date, clearance_level "
		    + "FROM ROLE_MASTER RM,USER_MASTER UM left join BUSINESS_MASTER BM on UM.business_id = BM.business_id where "
		    + "UM.user_id != ? and UM.business_id = ?  and RM.role_id = UM.role_id and "
		    + " RM.clearance_level >= ? and UM.is_active =1 and UM.created_date between ? and ? "
		    + "order by UM.created_date desc";

	    String UPDATE_BUSINESS = "UPDATE BUSINESS_MASTER set address1=?,address2=?, modified_by=? , state=?,country=?,city=? , zipcode=?, description=?, modified_date = utc_timestamp where business_id=?";

	    String GET_USER_PREFERENCE_DETAILS = "select distinct t1.alarm_id, t1.alarm_name, t1.alarm_type, t1.description,COALESCE(t2.active, true) as active from(Select PM.alarm_id, AM.alarm_name, AM.alarm_type, AM.description, true as active from preference_master PM left join alarm_master AM on AM.alarm_id=PM.alarm_id  where business_id =? and (sms is true or email is true) and role_id = ?) t1 Left join (select UAP.alarm_id, active from user_alarm_preference UAP where user_id=? and UAP.alarm_id in (select distinct alarm_id from preference_master where business_id=? and (sms is true or email is true) and role_id=?)) t2 on t1.alarm_id =t2.alarm_id";
	    String GET_SITE_LIST_CREATED_DATE_FILTER = "SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by, SM.alert_setting,"
		    + " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
		    + "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
		    + "FROM SITE_MASTER SM, BUSINESS_MASTER BM , BUSINESS_MASTER BM2 "
		    + "where  BM.business_id= SM.site_owner and" + " BM2.business_id = SM.BUSINESS_ID"
		    + " and SM. business_id = ? and SM.is_active=1 and SM.created_date between ? and ? order by SM.created_date desc";
	    String GET_ACCOUNT_LIST_CREATED_DATE_FILTER = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and business_id in (select site_owner from SITE_MASTER where business_id =?) and is_active=1 and created_date between ? and ? order by created_date desc";

	}

	interface partial {
	    String SITE_FILTER = "select site_id from site_master where site_id in"
		    + " (select site_id from user_site_association where user_id =?) "
		    + " and site_id in(select site_id from site_master "
		    + " where business_id in (select business_id from user_master, user_site_association where user_master.user_id = user_site_association.user_id)) and is_active=1";
	    String GET_ACCOUNT_LIST = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and is_active=1 and business_id in (select site_owner from SITE_MASTER where "
		    + "site_id in ( " + SITE_FILTER + ") ) order by created_date desc";
	    String GET_ACCOUNT_LIST_SORTED_ON_NAME = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and is_active=1 and business_id in (select site_owner from SITE_MASTER where "
		    + "site_id in ( " + SITE_FILTER + ") ) order by name asc";
	    String GET_ACCOUNT_ASSOCIATION_ID = "SELECT business_id FROM BUSINESS_MASTER where business_type = ? and business_id = ? and business_id in (select site_owner from SITE_MASTER where site_id in ( "
		    + SITE_FILTER + ") ) ";
	    String GET_SITES_FOR_ACCOUNT = "SELECT site_id,site_name from SITE_MASTER where site_owner = ? and site_id in ( "
		    + SITE_FILTER + ")  order by created_date desc";

	    String GET_SITES_FOR_USER = "SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by, SM.alert_setting,"
		    + " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
		    + "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
		    + "FROM SITE_MASTER SM  left join BUSINESS_MASTER BM on  "
		    + "BM.business_id = SM.site_owner left join BUSINESS_MASTER BM2 on  "
		    + " BM2.business_id = SM.BUSINESS_ID where  SM.site_id in ( " + SITE_FILTER
		    + ") and SM.is_active = 1 order by SM.created_date desc ";
	    String GET_SITE_LIST = "SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by, SM.alert_setting,"
		    + " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
		    + "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
		    + "FROM SITE_MASTER SM, BUSINESS_MASTER BM , BUSINESS_MASTER BM2 "
		    + "where  BM.business_id= SM.site_owner and" + " BM2.business_id = SM.BUSINESS_ID"
		    + " and SM.site_id in ( " + SITE_FILTER + ") and BM2.BUSINESS_ID=? order by SM.created_date desc";

	    String GET_SITE_LIST_SORTED_ON_NAME = "SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by, SM.alert_setting,"
		    + " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
		    + "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
		    + "FROM SITE_MASTER SM, BUSINESS_MASTER BM , BUSINESS_MASTER BM2 "
		    + "where  BM.business_id= SM.site_owner and" + " BM2.business_id = SM.BUSINESS_ID"
		    + " and SM.site_id in ( " + SITE_FILTER + ") and BM2.BUSINESS_ID=? order by SM.site_name asc";

	    String GET_SITE_ASSOCIATED_TO_COMPANY = "select site_id from site_master where site_id  = ? and site_id in ( "
		    + SITE_FILTER + ")  ";

	    String GET_FILE_HISTORY = "Select SITE_MASTER.site_name, FILE_MASTER.name, FILE_MASTER.file_id, FILE_MASTER.is_active, FILE_MASTER.created_by, FILE_MASTER.created_date, status, FILE_MASTER.description, FILE_MASTER.file_type from FILE_MASTER left join SITE_MASTER on FILE_MASTER.site_id=SITE_MASTER.site_id where FILE_MASTER.site_id in ( "
		    + SITE_FILTER
		    + " ) AND FILE_MASTER.device_id is null order by FILE_MASTER.created_date desc limit 300";

	    String GET_OBSERVATION_LIST = "select observation_id, observation, recommendation, created_by, created_date,modified_by, modified_date from OBSERVATION_MASTER where device_id = (select device_id from EQUIPMENT_MASTER where equipment_id=? and site_id =( select site_id from site_master where site_id in (select site_id from user_site_association where user_id =? and site_id=?)  and site_id in(select site_id from site_master  where business_id in (select business_id from user_master, user_site_association where user_master.user_id = user_site_association.user_id))) )and month=? and year=? and site_id=? order by created_date desc";

	    String ASSOCIATE_SITE_TO_USER = "INSERT into user_site_association(user_id, site_id, created_by, created_date, modified_by, modified_date) VALUES(?,?,?,utc_timestamp,?,utc_timestamp)";
	    String DELETE_SITE_ASSOCIATED_TO_USER = "DELETE FROM user_site_association WHERE user_id = ? ";
	    String GET_PERMISSION_LIST = "SELECT role_id, privilege_name FROM privilege_master p_m , role_privilege_association r_p_a where p_m.privilege_id = r_p_a.privilege_id order by role_id";
	    String GET_SITE_FOR_COMPANY = "SELECT site_id,site_name from site_master where business_id = ? and is_active=1 and site_id in (select site_id from user_site_association where user_id = ?)";
	    String UPDATE_SITE = "UPDATE SITE_MASTER SET site_name=?, address1=?,address2=?,modified_by=?, state=?,country=?,city=? , zipcode=?, description=?,metric_unit=?,modified_date = utc_timestamp,washer_turn_minute=?,washer_idle_minute=?,washer_efficiency_threshold=?,tunnel_turn_minute=?,tunnel_idle_minute=?,tunnel_efficiency_threshold=?,time_zone=?,alert_setting=?,streaming_enabled=? WHERE site_id=?";

	    String GET_USER_LIST = "SELECT user_id,first_name,middle_name,last_name,user_name,email,phone_number,UM.user_role,UM.business_id,site_id,UM.org_type,UM.created_date,UM.address1,UM.address2,UM.is_active,UM.state,UM.country,UM.city,UM.zipcode,BM.name,UM.created_by,UM.created_date, clearance_level	FROM role_master RM, USER_MASTER UM left join BUSINESS_MASTER BM on UM.business_id = BM.business_id where UM.user_id in (select user_id from user_site_association where site_id in (select site_id from site_master where site_id in (select site_id from user_site_association where user_id =? and site_id in(select site_id from site_master where business_id in (select business_id from user_master, user_site_association where user_master.user_id = user_site_association.user_id))) and user_id !=?)) and UM.business_id= ? and RM.role_id = UM.role_id and RM.clearance_level>? and UM.is_active=1 order by UM.created_date desc";
	    String GET_USER_LIST_CREATED_DATE_FILTER = "SELECT user_id,first_name,middle_name,last_name,user_name,email,phone_number,UM.user_role,UM.business_id,site_id,UM.org_type,UM.created_date,UM.address1,UM.address2,UM.is_active,UM.state,UM.country,UM.city,UM.zipcode,BM.name,UM.created_by,UM.created_date, clearance_level	FROM role_master RM, USER_MASTER UM left join BUSINESS_MASTER BM on UM.business_id = BM.business_id where UM.user_id in (select user_id from user_site_association where site_id in (select site_id from site_master where site_id in (select site_id from user_site_association where user_id =? and site_id in(select site_id from site_master where business_id in (select business_id from user_master, user_site_association where user_master.user_id = user_site_association.user_id))) and user_id !=?)) and UM.business_id= ? and RM.role_id = UM.role_id and RM.clearance_level>? and UM.is_active=1 and UM.created_date between ? and ? order by UM.created_date desc";
	    String GET_SITE_LIST_CREATED_DATE_FILTER = "SELECT SM.site_id, SM.created_date, SM.site_name,SM.country,SM.city,SM.state,SM.zipcode, SM.created_by, SM.alert_setting,"
		    + " BM.business_id, BM.name as ACCOUNT_NAME,BM2.name as COMPANY_NAME, BM2.business_id AS COMPANY_ID, "
		    + "SM.description, SM.address1,SM.address2, SM.metric_unit, SM.streaming_enabled "
		    + "FROM SITE_MASTER SM, BUSINESS_MASTER BM , BUSINESS_MASTER BM2 "
		    + "where  BM.business_id= SM.site_owner and" + " BM2.business_id = SM.BUSINESS_ID"
		    + " and SM.site_id in ( " + SITE_FILTER
		    + ") and BM2.BUSINESS_ID=? and SM.created_date between ? and ? order by SM.created_date desc";
	    String GET_ACCOUNT_LIST_CREATED_DATE_FILTER = "SELECT business_id,created_date,name,state,zipcode,city,created_by,country FROM BUSINESS_MASTER where business_type = ? and is_active=1 and business_id in (select site_owner from SITE_MASTER where "
		    + "site_id in ( " + SITE_FILTER + ") ) and created_date between ? and ? order by created_date desc";
	}
    }

    /* Queries for alarm notifications */
    interface alarms {
	String GET_SITE_ALARM_PREFERENCES = "SELECT distinct business_id, role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, alarm_counter, alarm_first_date_time FROM preference_master t1 where alarm_id =? AND (sms=1 OR email=1) AND unit_id = ?";
	String UPDATE_SITE_ALARM_PREFERENCE = "update preference_master set alarm_counter= ?,alarm_first_date_time=? WHERE unit_id=? and alarm_id=? and role_id=?";
	String UPDATE_SITE_ALARM_PREFERENCE_COUNT = "update preference_master set alarm_counter= ? WHERE unit_id=? and alarm_id=? and role_id=?";
	String GET_USER_DETAILS_FOR_ROLES = "select user_id,email, phone_number, role_id from user_master where user_id in (select t1.user_id from (select user_id  from user_master UM where user_id in(select user_id from user_site_association where site_id=? union all select user_id  from user_master where business_id is null union all select user_id from user_master where user_role =? and business_id=(select business_id from site_master where site_id=?)) and role_id in (?) ) t1 left join (select * from user_alarm_preference where alarm_id=? and active=0) t2 on t1.user_id= t2.user_id where t2.user_id is null)";
	String GET_USER_FOR_ROLE = "SELECT * FROM hydro.user_master where role_id =?";
	String UPDATE_SITE_PREDEFINED_ALARM_PREFERENCE = "update preference_master set alarm_counter= ?,alarm_first_date_time=? WHERE site_id=? and unit_id=? and alarm_id=?";
	String GET_SITE_PREDEFINED_ALARM_PREFERENCE = "SELECT distinct id, business_id, site_id, unit_id,  role_id, alarm_id, sms, email, threshold, threshold_refresh_interval, alarm_counter, alarm_first_date_time FROM preference_master t1 where alarm_id =? AND (sms=1 OR email=1) AND site_id=? and unit_id = ? and machine_id = ? and threshold_refresh_interval is not null and threshold_refresh_interval !='0'";
	String UPDATE_SITE_PREDEFINED_ALARM_PREFERENCE_COUNT = "update preference_master set alarm_counter= ? WHERE site_id=? and unit_id=? and alarm_id=? AND (sms=1 OR email=1)";
	String SELECT_ROLES_FROM_PREFERENCE_MASTER = "select distinct role_id, email, sms, threshold, alarm_counter from preference_master where alarm_counter>=threshold and alarm_id =? and site_id=? and threshold !=0 and (sms=1 OR email=1) and unit_id=?";
	String UPDATE_PREFERENCES_FOR_PREDEFINED_ALARMS = "update preference_master set alarm_counter= ?,alarm_first_date_time=? where role_id=? and unit_id=? and site_id=? and alarm_id=?";
	String ALARM_ID_EXISTS = "select alarm_id from preference_master where business_id=? and alarm_id=? limit 1";
	String GET_SITE_LIST_FOR_BUSINESS = "select distinct site_id from preference_master where business_id=?";
	String UPDATE_SITE_PREDEFINED_ALARM_COUNTER = "update preference_master set alarm_counter = ? WHERE site_id=? and unit_id=? and alarm_id=? AND (sms=1 OR email=1) and role_id = ?";
	String UPDATE_SITE_PREDEFINED_ALARM_FECHA = "update preference_master set alarm_first_date_time=? WHERE site_id=? and unit_id=? and alarm_id=? AND (sms=1 OR email=1) and machine_id=? and role_id = ?";

    }

    interface JsonParsing {
	String INSERT_INTO_EQUIPMENT_MASTER = "Insert into EQUIPMENT_MASTER(equipment_id, lm2_seq, site_id, alias, equipment_type, ip_address, washer_count, version, file_id, device_id, unit_id, warning_level, revision, start_up_date, date_power_on, `language`, units_system, products_channel_1, products_channel_2, products_channel_3, date_reset_statistics, date_last_sync, date_last_estadisticas_sync, `checksum`, first_conf_upload, first_formulas_upload, call_center, email, report_period, warning_cycles, warning_water, warning_product, created_by, modified_by, created_date, modified_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
	String UPDATE_JSONFILE = "UPDATE FILE_MASTER set status=?, description=?, file_type=?, version=?, lm2_file=?, modified_by=?, modified_date=utc_timestamp where file_id=?";
	String INSERT_INTO_CHANNEL_MASTER = "INSERT into channel_master(channel_id, uid, alarms_skipped, alarms_tolerance, date_last_change, dosing_mode, flush_air_ml, flush_air_time, flush_type, `name`, pump_type, water_test, equipment_id) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
	String INSERT_INTO_WATER_MASTER = "INSERT into water_master(water_id, equipment_id, kf, lm2_seq, flow,uid, channel, date_calibration, date_last_change, created_by, modified_by, created_date, modified_date) values(?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
	String INSERT_INTO_PRODUCT_MASTER = "INSERT into product_master(product_id, equipment_id, lm2_seq, name, density, concentration, kf, flow, priority, contact, alarms_ignored, price, calibration, created_by,  modified_by,  uid, alarms_tolerance, date_last_change, dosing_mode, estate, pump_safe_stop, rotameter_sensor, statistic_production, statistic_warnings,created_date,modified_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
	String INSERT_INTO_WASHER_MASTER = "INSERT into washer_master(washer_id, equipment_id, lm2_seq, name, `load`, id_formula, t_acceptation, t_repetition, t_lock, created_by, modified_by, uid, date_last_change, end_formula, end_mode, end_signal_pump, flush_l, hold_delay, hold_mode, hold_timeout, kg_sel, trigger_mode,created_date,modified_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp);";
	String INSERT_INTO_FILE_MASTER = "INSERT INTO FILE_MASTER (file_id, name, created_by, status, site_id, description, detailed_description, version, modified_by, file_type, device_id, is_active, unit_id , created_date, modified_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?, utc_timestamp,utc_timestamp)";
	String GET_CONFIG_UPLOAD_COUNT = "SELECT count(site_id) as config_upload_count FROM hydro.FILE_MASTER where site_id =? and file_type = ? and unit_id = ?";
	String GET_EQUIPMENT_ASSOCIATED_TO_UNIT = "select equipment_id from equipment_master where file_id = (SELECT file_id FROM FILE_MASTER where site_id =? and file_type = ? and unit_id = ? and is_active = 1 limit 1)";
	String INSERT_INTO_FORMULA_MASTER = "INSERT into formula_master(formula_id, equipment_id, lm2_seq, name, phases, created_by, modified_by,uid, percentage, date_last_change, used_phases, statistic_production, updated,modified_date,created_date) values(?,?,?,?,?,?,?,?,?,?,?,?,?,utc_timestamp,utc_timestamp)";
	String INSERT_INTO_FORMULA_PHASE = "INSERT into formula_phases(f_phase_id, id, id_formula, num_phase, delay_1, delay_2, uid, equipment_id, formula_id) values(?,?,?,?,?,?,?,?,?)";
	String INSERT_INTO_FORMULA_DOSAGES = "INSERT into formula_dosages(f_dosage_id, id, id_phase, dosage_order, id_product, dose, delay_bit, uid, product_uid, f_phase_id) values(?,?,?,?,?,?,?,?,?,?)";
	String UPDATE_UNITID = "UPDATE FILE_MASTER set unit_id = ?, modified_date=utc_timestamp where file_id=?";
	String GET_ACTIVE_CONFIG_DETAILS = "SELECT FM.file_id, ip_address, file_type FROM FILE_MASTER FM inner join equipment_master EM on EM.file_id =FM.file_id where FM.site_id = ? and FM.device_id is not null and file_type!=6 and FM.is_active = 1 and FM.file_id not like ?";
	String GET_OTHER_DEVICE_FILE_ID = "select file_id from file_master where file_id like ? and not file_id = ? and is_active = 1 and device_id is not null";
	String UPDATE_FILE_STATUS_TO_INACTIVE = "UPDATE FILE_MASTER set is_active=0, modified_date=utc_timestamp where file_id=?";
	String SET_FOREIGN_KEY_CHECKS = "SET FOREIGN_KEY_CHECKS=?";
	String DELETE_EXISTING_FORMULA_ENTRIES = "DELETE from formula_master where equipment_id = ?";
    }
}
