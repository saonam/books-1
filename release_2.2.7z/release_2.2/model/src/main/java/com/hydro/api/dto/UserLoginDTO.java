/**
 * 
 */
package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class UserLoginDTO {
    private String emailID;
    private String password;
    private String jwtToken;

    /**
     * @return the emailID
     */
    public String getEmailID() {
	return emailID;
    }

    /**
     * @param emailID
     *            the emailID to set
     */
    public void setEmailID(String emailID) {
	this.emailID = emailID;
    }

    /**
     * @return the password
     */
    public String getPassword() {
	return password;
    }

    /**
     * @param password
     *            the password to set
     */
    public void setPassword(String password) {
	this.password = password;
    }

    /**
     * @return the jwtToken
     */
    public String getJwtToken() {
	return jwtToken;
    }

    /**
     * @param jwtToken
     *            the jwtToken to set
     */
    public void setJwtToken(String jwtToken) {
	this.jwtToken = jwtToken;
    }

}
