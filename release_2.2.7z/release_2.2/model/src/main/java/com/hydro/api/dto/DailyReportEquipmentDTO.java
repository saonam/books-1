package com.hydro.api.dto;

import java.util.Map;

import com.hydro.api.dto.reports.DailyReportWasherDTO;

public class DailyReportEquipmentDTO {
    private String equipmentId;
    private String equipmentType;
    private String equipmentName;
    private Map<Integer, DailyReportWasherDTO> washerHashMap;
    private DailyReportTunnelDTO tunnel;
    public String getEquipmentId() {
        return equipmentId;
    }
    public void setEquipmentId(String equipmentId) {
        this.equipmentId = equipmentId;
    }
    public String getEquipmentType() {
        return equipmentType;
    }
    public void setEquipmentType(String equipmentType) {
        this.equipmentType = equipmentType;
    }
    public String getEquipmentName() {
        return equipmentName;
    }
    public void setEquipmentName(String equipmentName) {
        this.equipmentName = equipmentName;
    }
    public Map<Integer, DailyReportWasherDTO> getWasherHashMap() {
        return washerHashMap;
    }
    public void setWasherHashMap(Map<Integer, DailyReportWasherDTO> washerHashMap) {
        this.washerHashMap = washerHashMap;
    }
    public DailyReportTunnelDTO getTunnel() {
        return tunnel;
    }
    public void setTunnel(DailyReportTunnelDTO tunnel) {
        this.tunnel = tunnel;
    }
}
