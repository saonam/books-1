package com.hydro.api.dto;

public class ObservationDTO {
    // observation_id, observation, recommendation, created_by, created_date,
    // modified_by, modified_date, equipment_id, month, year
    private String observationId;
    private String observation;
    private String recommendation;
    private String createdBy;
    private String createdDate;
    private String modifiedBy;
    private String modifiedDate;
    private String equipmentId;
    private int month;
    private int year;
    private String siteId;
    private String timeZone;

    public String getObservationId() {
	return observationId;
    }

    public void setObservationId(String observationId) {
	this.observationId = observationId;
    }

    public String getObservation() {
	return observation;
    }

    public void setObservation(String observation) {
	this.observation = observation;
    }

    public String getRecommendation() {
	return recommendation;
    }

    public void setRecommendation(String recommendation) {
	this.recommendation = recommendation;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public String getModifiedBy() {
	return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
	return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
    }

    public int getMonth() {
	return month;
    }

    public void setMonth(int month) {
	this.month = month;
    }

    /**
     * @return the year
     */
    public int getYear() {
	return year;
    }

    /**
     * @param year
     *            the year to set
     */
    public void setYear(int year) {
	this.year = year;
    }

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getEquipmentId() {
	return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
	this.equipmentId = equipmentId;
    }

    public String getTimeZone() {
	return timeZone;
    }

    public void setTimeZone(String timeZone) {
	this.timeZone = timeZone;
    }

}
