package com.hydro.api.dto.reports;

import java.util.Date;

/**
 * @author Srishti Tiwari
 *
 */
public class CycleDTO {
    private Integer cycleId;
    private String runTime;
    private Date startCycleTime;
    private Date endCycleTime;
    private Long cycleActiveTime;
    private Long currentActiveEventTime;
    private String turnTime;
    private Double formulaCost;
    private Integer lbs;
    private Double loads;
    private Integer cyclePreviousActivePhase = 0;
    private boolean cycleCompleted;
    private Double totalMlEstimated;
    private Double totalMlActual;
    private DailyReportFormulaDTO formula;

    public Integer getCycleId() {
	return cycleId;
    }

    public void setCycleId(Integer cycleId) {
	this.cycleId = cycleId;
    }

    public DailyReportFormulaDTO getFormula() {
	return formula;
    }

    public void setFormula(DailyReportFormulaDTO formula) {
	this.formula = formula;
    }

    public Long getCycleActiveTime() {
	return cycleActiveTime;
    }

    public void setCycleActiveTime(Long cycleActiveTime) {
	this.cycleActiveTime = cycleActiveTime;
    }

    public Date getStartCycleTime() {
	return startCycleTime;
    }

    public void setStartCycleTime(Date startCycleTime) {
	this.startCycleTime = startCycleTime;
    }

    public Date getEndCycleTime() {
	return endCycleTime;
    }

    public void setEndCycleTime(Date endCycleTime) {
	this.endCycleTime = endCycleTime;
    }

    public Integer getCyclePreviousActivePhase() {
	return cyclePreviousActivePhase;
    }

    public void setCyclePreviousActivePhase(Integer cyclePreviousActivePhase) {
	this.cyclePreviousActivePhase = cyclePreviousActivePhase;
    }

    public Double getFormulaCost() {
	return formulaCost;
    }

    public void setFormulaCost(Double formulaCost) {
	this.formulaCost = formulaCost;
    }

    public Double getLoads() {
	return loads;
    }

    public void setLoads(Double loads) {
	this.loads = loads;
    }

    public Integer getLbs() {
	return lbs;
    }

    public void setLbs(Integer lbs) {
	this.lbs = lbs;
    }

    public Long getCurrentActiveEventTime() {
	return currentActiveEventTime;
    }

    public void setCurrentActiveEventTime(Long currentActiveEventTime) {
	this.currentActiveEventTime = currentActiveEventTime;
    }

    public String getRunTime() {
	return runTime;
    }

    public void setRunTime(String runTime) {
	this.runTime = runTime;
    }

    public String getTurnTime() {
	return turnTime;
    }

    public void setTurnTime(String turnTime) {
	this.turnTime = turnTime;
    }

    public boolean isCycleCompleted() {
	return cycleCompleted;
    }

    public void setCycleCompleted(boolean cycleCompleted) {
	this.cycleCompleted = cycleCompleted;
    }

    public Double getTotalMlEstimated() {
        return totalMlEstimated;
    }

    public void setTotalMlEstimated(Double totalMlEstimated) {
        this.totalMlEstimated = totalMlEstimated;
    }

    public Double getTotalMlActual() {
        return totalMlActual;
    }

    public void setTotalMlActual(Double totalMlActual) {
        this.totalMlActual = totalMlActual;
    }

}
