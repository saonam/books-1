package com.hydro.api.dto;

/**
 * @author Suganya Arumugam
 *
 */

public class TokenDTO {
    private long expiry;

    public long getExpiry() {
	return expiry;
    }

    public void setExpiry(long expiry) {
	this.expiry = expiry;
    }
}
