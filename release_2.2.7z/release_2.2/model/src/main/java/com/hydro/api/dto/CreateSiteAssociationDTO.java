/**
 * 
 */
package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class CreateSiteAssociationDTO {
    private String associationId;

    /**
     * @return the associationId
     */
    public String getAssociationId() {
	return associationId;
    }

    /**
     * @param associationId
     *            the associationId to set
     */
    public void setAssociationId(String associationId) {
	this.associationId = associationId;
    }

}
