package com.hydro.api.dto;

import java.util.List;

public class ObservationListResponseDTO {
    private List<ObservationDTO> observationList;

    public List<ObservationDTO> getObservationList() {
	return observationList;
    }

    public void setObservationList(List<ObservationDTO> observationList) {
	this.observationList = observationList;
    }

}
