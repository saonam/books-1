package com.hydro.api.dto;

import java.sql.Blob;
import java.util.HashMap;

import com.hydro.api.exception.ExceptionHandler;

/**
 * @author Srishti Tiwari
 *
 */
public class FileDTO extends ExceptionHandler implements Cloneable {
    // file_id, name, created_by, created_date, status, site_id, description,
    // version, lm2_file, modified_by, modified_date, file_type
    private String fileId;
    private String siteName;
    private String name;
    private String createdBy;
    private String createdDate;
    private String status;
    private String siteId;
    private String description;
    private int version;
    private Blob lm2File;
    private String modifiedBy;
    private String modifiedDate;
    private int fileType;
    private String detailedDescription;
    private String timeZone;
    private String device_id;
    private int is_active;

    @Override
    public Object clone() throws CloneNotSupportedException {
	return super.clone();
    }

    public String getDevice_id() {
	return device_id;
    }

    public void setDevice_id(String device_id) {
	this.device_id = device_id;
    }

    public int getIs_active() {
	return is_active;
    }

    public void setIs_active(int is_active) {
	this.is_active = is_active;
    }

    public String getFileId() {
	return fileId;
    }

    public void setFileId(String fileId) {
	this.fileId = fileId;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public String getStatus() {
	return status;
    }

    public void setStatus(String status) {
	this.status = status;
    }

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getDescription() {
	return description;
    }

    public void setDescription(String description) {
	this.description = description;
    }

    public int getVersion() {
	return version;
    }

    public void setVersion(int version) {
	this.version = version;
    }

    public Blob getLm2File() {
	return lm2File;
    }

    public void setLm2File(Blob lm2File) {
	this.lm2File = lm2File;
    }

    public String getModifiedBy() {
	return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
	return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
    }

    public int getFileType() {
	return fileType;
    }

    public void setFileType(int fileType) {
	this.fileType = fileType;
    }

    public String getSiteName() {
	return siteName;
    }

    public void setSiteName(String siteName) {
	this.siteName = siteName;
    }

    public void setDescription(String errorCode, HashMap<String, String> errorConfig) {
	ExceptionHandler.getMessage(errorCode, errorConfig);
	this.description = ExceptionHandler.getMessage(errorCode, errorConfig);
    }

    public String getDetailedDescription() {
	return detailedDescription;
    }

    public void setDetailedDescription(String detailedDescription) {
	this.detailedDescription = detailedDescription;
    }

    public String getTimeZone() {
	return timeZone;
    }

    public void setTimeZone(String timeZone) {
	this.timeZone = timeZone;
    }

}
