package com.hydro.api.config;

public class ConfigurationResponse {
    private ConfigurationDTO siteconfiguration;

    public ConfigurationDTO getSiteconfiguration() {
        return siteconfiguration;
    }

    public void setSiteconfiguration(ConfigurationDTO siteconfiguration) {
        this.siteconfiguration = siteconfiguration;
    }
    
}
