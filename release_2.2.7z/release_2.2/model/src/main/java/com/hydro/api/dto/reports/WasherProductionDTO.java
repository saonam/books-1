/**
 * 
 */
package com.hydro.api.dto.reports;

import java.util.List;

import com.hydro.api.dto.SiteDTO;

/**
 * @author Shreyas K C
 *
 */
public class WasherProductionDTO {
    private long totalProduction;
    private int totalLoads;
    private List<EquipmentReportDTO> washerList;
    private List<FormulaDTO> formulaList;
    private String siteId;
    private String unitId;
    private int month;
    private int year;
    private String maxDate;
    private String minDate;
    private SiteDTO siteDTO;
    private List<String> avgCalculatedForMonths;

    public long getTotalProduction() {
	return totalProduction;
    }

    public void setTotalProduction(long totalProduction) {
	this.totalProduction = totalProduction;
    }

    public int getTotalLoads() {
	return totalLoads;
    }

    public void setTotalLoads(int totalLoads) {
	this.totalLoads = totalLoads;
    }

    public List<EquipmentReportDTO> getEquipmentList() {
	return washerList;
    }

    public void setEquipmentList(List<EquipmentReportDTO> equipmentList) {
	this.washerList = equipmentList;
    }

    public List<FormulaDTO> getFormulaList() {
	return formulaList;
    }

    public void setFormulaList(List<FormulaDTO> formulaList) {
	this.formulaList = formulaList;
    }

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getUnitId() {
	return unitId;
    }

    public void setUnitId(String unitId) {
	this.unitId = unitId;
    }

    public int getMonth() {
	return month;
    }

    public void setMonth(int month) {
	this.month = month;
    }

    public int getYear() {
	return year;
    }

    public void setYear(int year) {
	this.year = year;
    }

    public String getMaxDate() {
	return maxDate;
    }

    public void setMaxDate(String maxDate) {
	this.maxDate = maxDate;
    }

    public String getMinDate() {
	return minDate;
    }

    public void setMinDate(String minDate) {
	this.minDate = minDate;
    }

    public SiteDTO getSiteDTO() {
	return siteDTO;
    }

    public void setSiteDTO(SiteDTO siteDTO) {
	this.siteDTO = siteDTO;
    }

    public List<String> getAvgCalculatedForMonths() {
	return avgCalculatedForMonths;
    }

    public void setAvgCalculatedForMonths(List<String> avgCalculatedForMonths) {
	this.avgCalculatedForMonths = avgCalculatedForMonths;
    }
}
