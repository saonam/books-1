package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class FormulaPDBDTO {
    // pdb_id, formula_id, pdb_name, pdb_value
    private String pdbId;
    private String formulaId;
    private String pdbName;
    private String pdbValue;

    public String getPdbId() {
	return pdbId;
    }

    public void setPdbId(String pdbId) {
	this.pdbId = pdbId;
    }

    public String getFormulaId() {
	return formulaId;
    }

    public void setFormulaId(String formulaId) {
	this.formulaId = formulaId;
    }

    public String getPdbName() {
	return pdbName;
    }

    public void setPdbName(String pdbName) {
	this.pdbName = pdbName;
    }

    public String getPdbValue() {
	return pdbValue;
    }

    public void setPdbValue(String pdbValue) {
	this.pdbValue = pdbValue;
    }

}
