package com.hydro.api.dto;

public class FailedEventsDTO {
    private EventDTO eventDTO;
    private String reasonForFailure;
    private String errorCode;
    private String requestPayload;

    public EventDTO getEventDTO() {
	return eventDTO;
    }

    public void setEventDTO(EventDTO eventDTO) {
	this.eventDTO = eventDTO;
    }

    public String getReasonForFailure() {
	return reasonForFailure;
    }

    public void setReasonForFailure(String reasonForFailure) {
	this.reasonForFailure = reasonForFailure;
    }

    public String getErrorCode() {
	return errorCode;
    }

    public void setErrorCode(String errorCode) {
	this.errorCode = errorCode;
    }

    public String getRequestPayload() {
	return requestPayload;
    }

    public void setRequestPayload(String requestPayload) {
	this.requestPayload = requestPayload;
    }

}
