/**
 * 
 */
package com.hydro.api.dto.reports;

import java.util.List;

import com.hydro.api.dto.SiteDTO;

/**
 * @author Shreyas K C
 *
 */
public class ChemicalSummaryDTO {

    private List<ChemicalDTO> chemicalList;
    private List<FormulaDTO> formulaList;
    private String siteId;
    private String unitId;
    private int month;
    private int year;
    private String maxDate;
    private String minDate;
    private SiteDTO siteDTO;
    private List<String> avgCalculatedForMonths;

    public List<FormulaDTO> getFormulaList() {
	return formulaList;
    }

    public void setFormulaList(List<FormulaDTO> formulaList) {
	this.formulaList = formulaList;
    }

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getUnitId() {
	return unitId;
    }

    public void setUnitId(String unitId) {
	this.unitId = unitId;
    }

    public int getMonth() {
	return month;
    }

    public void setMonth(int month) {
	this.month = month;
    }

    public int getYear() {
	return year;
    }

    public void setYear(int year) {
	this.year = year;
    }

    public List<ChemicalDTO> getChemicalList() {
	return chemicalList;
    }

    public void setChemicalList(List<ChemicalDTO> chemicalList) {
	this.chemicalList = chemicalList;
    }

    public String getMaxDate() {
	return maxDate;
    }

    public void setMaxDate(String maxDate) {
	this.maxDate = maxDate;
    }

    public String getMinDate() {
	return minDate;
    }

    public void setMinDate(String minDate) {
	this.minDate = minDate;
    }

    public SiteDTO getSiteDTO() {
	return siteDTO;
    }

    public void setSiteDTO(SiteDTO siteDTO) {
	this.siteDTO = siteDTO;
    }

    public List<String> getAvgCalculatedForMonths() {
	return avgCalculatedForMonths;
    }

    public void setAvgCalculatedForMonths(List<String> avgCalculatedForMonths) {
	this.avgCalculatedForMonths = avgCalculatedForMonths;
    }
}
