package com.hydro.api.dto;

import java.util.List;

public class UserPreferenceResponseDTO {
    private String userId;
    private List<AlertDTO> alertList;

    public String getUserId() {
	return userId;
    }

    public void setUserId(String userId) {
	this.userId = userId;
    }

    public List<AlertDTO> getAlertList() {
	return alertList;
    }

    public void setAlertList(List<AlertDTO> alertList) {
	this.alertList = alertList;
    }

}
