package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class EquipmentPumpMachinery {
    // pump_machine_id, equipment_id, pump_machine_name, pump_machine_value
    private String pumpMachineId;
    private String equipmentId;
    private String pumpMachineName;
    private String pumpMachineValue;

    public String getPumpMachineId() {
	return pumpMachineId;
    }

    public void setPumpMachineId(String pumpMachineId) {
	this.pumpMachineId = pumpMachineId;
    }

    public String getEquipmentId() {
	return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
	this.equipmentId = equipmentId;
    }

    public String getPumpMachineName() {
	return pumpMachineName;
    }

    public void setPumpMachineName(String pumpMachineName) {
	this.pumpMachineName = pumpMachineName;
    }

    public String getPumpMachineValue() {
	return pumpMachineValue;
    }

    public void setPumpMachineValue(String pumpMachineValue) {
	this.pumpMachineValue = pumpMachineValue;
    }

}
