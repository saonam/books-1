package com.hydro.api.config;

import java.util.List;

public class FormulaConfig {
    private String data_source;
    private String data_type;
    private String unit_id;
    private List<FormulaDTO> formulas;

    public String getData_source() {
	return data_source;
    }

    public void setData_source(String data_source) {
	this.data_source = data_source;
    }

    public String getData_type() {
	return data_type;
    }

    public void setData_type(String data_type) {
	this.data_type = data_type;
    }

    public String getUnit_id() {
	return unit_id;
    }

    public void setUnit_id(String unit_id) {
	this.unit_id = unit_id;
    }

    public List<FormulaDTO> getFormulas() {
	return formulas;
    }

    public void setFormulas(List<FormulaDTO> formulas) {
	this.formulas = formulas;
    }
}
