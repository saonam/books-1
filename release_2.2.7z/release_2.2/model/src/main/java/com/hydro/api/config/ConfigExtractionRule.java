package com.hydro.api.config;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

public class ConfigExtractionRule {
    private String[] included;
    private String[] excluded;
    private List<String> includedList;
    private List<String> excludedList;
    private ResultOrder resultOrder;
    private String[][] nameToAlias;
    private Map<String,String> nameToAliasMapping;
    
    public void setIncluded (String...strings) {
	this.included = strings;
	this.includedList = Arrays.asList(strings);
    }
    
    public void setExcluded (String...strings) {
	this.excluded = strings;
	this.excludedList = Arrays.asList(strings);
    }
    public boolean isIncluded(String str) {
	return this.includedList.contains(str);
    }
    
    public boolean isExcluded(String str) {
	return this.excludedList.contains(str);
    }
    
    public String[] getIncluded () {
	return this.included;
    }
    
    public String[] getExcluded () {
	return this.excluded;
    }
    
    public void setResultOrder(ResultOrder order) {
	this.resultOrder = order;
    }
    
    public ResultOrder getResultOrder() {
	return this.resultOrder;
    }
    
    public String[][] getNameToAlias() {
        return nameToAlias;
    }

    public void setNameToAlias(String[][] nameToAlias) {
        this.nameToAlias = nameToAlias;
        this.nameToAliasMapping = new HashMap<>();
        for(String[] pair : nameToAlias) {
            if(pair.length == 2) {
        	String actual = pair[0];
        	String alias = pair[1]; 
        	if(StringUtils.isBlank(actual) || StringUtils.isBlank(alias)) {
        	    continue;
        	}
        	this.nameToAliasMapping.put(actual, alias);
            }
        }
    }

    public Map<String,Object> getContainer() {
	if(ResultOrder.NATURAL_ORDER.equals(resultOrder)) {
	    return new TreeMap<String,Object>();
	} else {
	    return new LinkedHashMap<String,Object>();
	}
    }
    
    public String getAlias(String actual) {
	if(this.nameToAlias == null || !this.nameToAliasMapping.containsKey(actual)) {
	    return actual;
	}
	return this.nameToAliasMapping.get(actual);
    }
    
    public static enum ResultOrder {
	FETCH_ORDER,
	NATURAL_ORDER,
	CUSTOM_ORDER
    }
}
