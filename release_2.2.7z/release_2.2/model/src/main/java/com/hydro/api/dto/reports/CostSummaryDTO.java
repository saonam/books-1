/**
 * 
 */
package com.hydro.api.dto.reports;

import java.util.List;

import com.hydro.api.dto.SiteDTO;

/**
 * @author Shreyas K C
 *
 */
public class CostSummaryDTO {

    private List<FormulaDTO> formulaList;
    private Long totalWeight;
    private Double totalEstimatedCost;
    private Double totalEstimatedCw;
    private Double totalRealCost;
    private Double totalRealCw;
    private String siteId;
    private String unitId;
    private int month;
    private int year;
    private String maxDate;
    private String minDate;
    private SiteDTO siteDTO;
    private List<String> avgCalculatedForMonths;

    public List<FormulaDTO> getFormulaList() {
	return formulaList;
    }

    public void setFormulaList(List<FormulaDTO> formulaList) {
	this.formulaList = formulaList;
    }

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getUnitId() {
	return unitId;
    }

    public void setUnitId(String unitId) {
	this.unitId = unitId;
    }

    public int getMonth() {
	return month;
    }

    public void setMonth(int month) {
	this.month = month;
    }

    public int getYear() {
	return year;
    }

    public void setYear(int year) {
	this.year = year;
    }

    public Long getTotalWeight() {
	return totalWeight;
    }

    public void setTotalWeight(Long totalWeight) {
	this.totalWeight = totalWeight;
    }

    public Double getTotalEstimatedCost() {
	return totalEstimatedCost;
    }

    public void setTotalEstimatedCost(Double totalEstimatedCost) {
	this.totalEstimatedCost = totalEstimatedCost;
    }

    public Double getTotalEstimatedCw() {
	return totalEstimatedCw;
    }

    public void setTotalEstimatedCw(Double totalEstimatedCw) {
	this.totalEstimatedCw = totalEstimatedCw;
    }

    public Double getTotalRealCost() {
	return totalRealCost;
    }

    public void setTotalRealCost(Double totalRealCost) {
	this.totalRealCost = totalRealCost;
    }

    public Double getTotalRealCw() {
	return totalRealCw;
    }

    public void setTotalRealCw(Double totalRealCw) {
	this.totalRealCw = totalRealCw;
    }

    public String getMaxDate() {
	return maxDate;
    }

    public void setMaxDate(String maxDate) {
	this.maxDate = maxDate;
    }

    public String getMinDate() {
	return minDate;
    }

    public void setMinDate(String minDate) {
	this.minDate = minDate;
    }

    public SiteDTO getSiteDTO() {
	return siteDTO;
    }

    public void setSiteDTO(SiteDTO siteDTO) {
	this.siteDTO = siteDTO;
    }

    public List<String> getAvgCalculatedForMonths() {
	return avgCalculatedForMonths;
    }

    public void setAvgCalculatedForMonths(List<String> avgCalculatedForMonths) {
	this.avgCalculatedForMonths = avgCalculatedForMonths;
    }
}
