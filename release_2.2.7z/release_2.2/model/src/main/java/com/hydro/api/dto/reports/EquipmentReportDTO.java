/**
 * 
 */
package com.hydro.api.dto.reports;

import java.util.List;

/**
 * @author Shreyas K C
 *
 */
public class EquipmentReportDTO {
    private String name;
    private Integer id;
    private Integer capacity;
    private Long totalProduction;
    private Double totalProductionContribution;
    private Integer totalLoads;
    private Double totalLoadsContribution;
    private List<FormulaDTO> formulaList;
    private String lm2Seq;

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public int getCapacity() {
	return capacity;
    }

    public void setCapacity(int capacity) {
	this.capacity = capacity;
    }

    public long getTotalProduction() {
	return totalProduction;
    }

    public void setTotalProduction(long totalProduction) {
	this.totalProduction = totalProduction;
    }

    public double getTotalProductionContribution() {
	return totalProductionContribution;
    }

    public void setTotalProductionContribution(double totalProductionContribution) {
	this.totalProductionContribution = totalProductionContribution;
    }

    public int getTotalLoads() {
	return totalLoads;
    }

    public void setTotalLoads(int totalLoads) {
	this.totalLoads = totalLoads;
    }

    public double getTotalLoadsContribution() {
	return totalLoadsContribution;
    }

    public void setTotalLoadsContribution(double totalLoadsContribution) {
	this.totalLoadsContribution = totalLoadsContribution;
    }

    public List<FormulaDTO> getFormulaList() {
	return formulaList;
    }

    public void setFormulaList(List<FormulaDTO> formulaList) {
	this.formulaList = formulaList;
    }

    public int getId() {
	return id;
    }

    public void setId(int id) {
	this.id = id;
    }

    public String getLm2Seq() {
	return lm2Seq;
    }

    public void setLm2Seq(String lm2Seq) {
	this.lm2Seq = lm2Seq;
    }

}
