package com.hydro.api.config;

public class UnitDTO {
    public static final String EQUIPMENT_ID = "equipment_id";
    public static final String EQUIPMENT_TYPE = "equipment_type";
    public static final String ID = "lm2_seq";
    public static final String UNIT_ID = "unit_id";
    public static final String UNIT_TYPE = "unit_type";
    public static final String NAME = "alias";
    public static final String VERSION = "version";
    public static final String REVISION = "revision";
    public static final String START_UP_DATE = "start_up_date";
    public static final String DATE_POWER_ON = "date_power_on";
    public static final String IP = "ip_address";
    public static final String LANGUAGE = "language";
    public static final String UNITS_SYSTEM = "units_system";
    public static final String MACHINES_COUNT = "machines_count";
    public static final String PRODUCTS_CHANNEL_1 = "products_channel_1";
    public static final String PRODUCTS_CHANNEL_2 = "products_channel_2";
    public static final String PRODUCST_CHANNEL_3 = "products_channel_3";
    public static final String DATE_RESET_STATISTICS = "date_reset_statistics";
    public static final String DATE_LAST_SYNC = "date_last_sync";
    public static final String DATE_LAST_ESTADISTICAS_SYNC = "date_last_estadisticas_sync";
    public static final String CHECKSUM = "checksum";
    public static final String FIRST_CONF_UPLOAD = "first_conf_upload";
    public static final String FIRST_FORMULAS_UPLOAD = "first_formulas_upload";
    public static final String CALL_CENTER = "call_center";
    public static final String EMAIL = "email";
    public static final String REPORT_PERIOD = "report_period";
    public static final String WARNING_CYCLES = "warning_cycles";
    public static final String WARNING_WATER = "warning_water";
    public static final String WARNING_PRODUCT = "warning_product";
    public static final String WARNING_LEVEL = "warning_level";
    public static final ConfigExtractionRule  unitFetchRule;
    static {
	unitFetchRule = new ConfigExtractionRule();
	unitFetchRule.setExcluded("site_id", "is_active", "created_by", "created_date",  "modified_by", "modified_date", "file_id", "device_id");
	unitFetchRule.setNameToAlias(new String[][] {{"lm2_seq","id"}, {"equipment_type", "unit_type"}});
    }
    private String equipment_id;
    private String equipment_type;
    private String id;
    private String unit_id;
    private String unit_type;
    private String name;
    private String version;
    private String revision;
    private String start_up_date;
    private String date_power_on;
    private String ip;
    private String language;
    private String units_system;
    private String washer_extractors;
    private String products_channel_1;
    private String products_channel_2;
    private String products_channel_3;
    private String date_reset_statistics;
    private String date_last_sync;
    private String date_last_estadisticas_sync;
    private String checksum;
    private String first_conf_upload;
    private String first_formulas_upload;
    private String call_center;
    private String email;
    private String report_period;
    private String warning_cycles;
    private String warning_water;
    private String warning_product;
    private String warning_level;
    private String deviceId;
    private String fileId;
    private String siteId;

    public String getEquipment_id() {
        return equipment_id;
    }

    public void setEquipment_id(String equipment_id) {
        this.equipment_id = equipment_id;
    }

    public String getEquipment_type() {
        return equipment_type;
    }

    public void setEquipment_type(String equipment_type) {
        this.equipment_type = equipment_type;
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getUnit_id() {
	return unit_id;
    }

    public void setUnit_id(String unit_id) {
	this.unit_id = unit_id;
    }

    public String getUnit_type() {
	return unit_type;
    }

    public void setUnit_type(String unit_type) {
	this.unit_type = unit_type;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getVersion() {
	return version;
    }

    public void setVersion(String version) {
	this.version = version;
    }

    public String getRevision() {
	return revision;
    }

    public void setRevision(String revision) {
	this.revision = revision;
    }

    public String getStart_up_date() {
	return start_up_date;
    }

    public void setStart_up_date(String start_up_date) {
	this.start_up_date = start_up_date;
    }

    public String getDate_power_on() {
	return date_power_on;
    }

    public void setDate_power_on(String date_power_on) {
	this.date_power_on = date_power_on;
    }

    public String getIp() {
	return ip;
    }

    public void setIp(String ip) {
	this.ip = ip;
    }

    public String getLanguage() {
	return language;
    }

    public void setLanguage(String language) {
	this.language = language;
    }

    public String getUnits_system() {
	return units_system;
    }

    public void setUnits_system(String units_system) {
	this.units_system = units_system;
    }

    public String getWasher_extractors() {
	return washer_extractors;
    }

    public void setWasher_extractors(String washer_extractors) {
	this.washer_extractors = washer_extractors;
    }

    public String getProducts_channel_1() {
	return products_channel_1;
    }

    public void setProducts_channel_1(String products_channel_1) {
	this.products_channel_1 = products_channel_1;
    }

    public String getProducts_channel_2() {
	return products_channel_2;
    }

    public void setProducts_channel_2(String products_channel_2) {
	this.products_channel_2 = products_channel_2;
    }

    public String getProducts_channel_3() {
	return products_channel_3;
    }

    public void setProducts_channel_3(String products_channel_3) {
	this.products_channel_3 = products_channel_3;
    }

    public String getDate_reset_statistics() {
	return date_reset_statistics;
    }

    public void setDate_reset_statistics(String date_reset_statistics) {
	this.date_reset_statistics = date_reset_statistics;
    }

    public String getDate_last_sync() {
	return date_last_sync;
    }

    public void setDate_last_sync(String date_last_sync) {
	this.date_last_sync = date_last_sync;
    }

    public String getDate_last_estadisticas_sync() {
	return date_last_estadisticas_sync;
    }

    public void setDate_last_estadisticas_sync(String date_last_estadisticas_sync) {
	this.date_last_estadisticas_sync = date_last_estadisticas_sync;
    }

    public String getChecksum() {
	return checksum;
    }

    public void setChecksum(String checksum) {
	this.checksum = checksum;
    }

    public String getFirst_conf_upload() {
	return first_conf_upload;
    }

    public void setFirst_conf_upload(String first_conf_upload) {
	this.first_conf_upload = first_conf_upload;
    }

    public String getFirst_formulas_upload() {
	return first_formulas_upload;
    }

    public void setFirst_formulas_upload(String first_formulas_upload) {
	this.first_formulas_upload = first_formulas_upload;
    }

    public String getCall_center() {
	return call_center;
    }

    public void setCall_center(String call_center) {
	this.call_center = call_center;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getReport_period() {
	return report_period;
    }

    public void setReport_period(String report_period) {
	this.report_period = report_period;
    }

    public String getWarning_cycles() {
	return warning_cycles;
    }

    public void setWarning_cycles(String warning_cycles) {
	this.warning_cycles = warning_cycles;
    }

    public String getWarning_water() {
	return warning_water;
    }

    public void setWarning_water(String warning_water) {
	this.warning_water = warning_water;
    }

    public String getWarning_product() {
	return warning_product;
    }

    public void setWarning_product(String warning_product) {
	this.warning_product = warning_product;
    }

    public String getWarning_level() {
	return warning_level;
    }

    public void setWarning_level(String warning_level) {
	this.warning_level = warning_level;
    }

    public String getDeviceId() {
	return deviceId;
    }

    public void setDeviceId(String deviceId) {
	this.deviceId = deviceId;
    }

    public String getFileId() {
	return fileId;
    }

    public void setFileId(String fileId) {
	this.fileId = fileId;
    }

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

}
