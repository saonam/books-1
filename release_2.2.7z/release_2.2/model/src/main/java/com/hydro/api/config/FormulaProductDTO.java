package com.hydro.api.config;

public class FormulaProductDTO {
    public static final String ID = "id";
    public static final String ID_PHASE = "id_phase";
    public static final String DOSAGE_ORDER = "dosage_order";
    public static final String ID_PRODUCT = "id_product";
    public static final String DOSE = "dose";
    public static final String DELAY_BIT = "delay_bit";
    public static final String UID = "uid";
    public static final String PRODUCT_UID = "product_uid";
    public static final ConfigExtractionRule  doseFetchRule;
    static {
	doseFetchRule = new ConfigExtractionRule();
	doseFetchRule.setExcluded("f_dosage_id", "f_phase_id");
    }
    private String id;
    private String id_phase;
    private String dosage_order;
    private String id_product;
    private String dose;
    private String delay_bit;
    private String uid;
    private String product_uid;

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getId_phase() {
	return id_phase;
    }

    public void setId_phase(String id_phase) {
	this.id_phase = id_phase;
    }

    public String getDosage_order() {
	return dosage_order;
    }

    public void setDosage_order(String dosage_order) {
	this.dosage_order = dosage_order;
    }

    public String getId_product() {
	return id_product;
    }

    public void setId_product(String id_product) {
	this.id_product = id_product;
    }

    public String getDose() {
	return dose;
    }

    public void setDose(String dose) {
	this.dose = dose;
    }

    public String getDelay_bit() {
	return delay_bit;
    }

    public void setDelay_bit(String delay_bit) {
	this.delay_bit = delay_bit;
    }

    public String getUid() {
	return uid;
    }

    public void setUid(String uid) {
	this.uid = uid;
    }

    public String getProduct_uid() {
	return product_uid;
    }

    public void setProduct_uid(String product_uid) {
	this.product_uid = product_uid;
    }

}
