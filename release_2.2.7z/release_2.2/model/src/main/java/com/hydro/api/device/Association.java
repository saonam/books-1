package com.hydro.api.device;

import java.io.Serializable;
import java.util.List;

public class Association implements  Serializable{

	private String associationKey;
	
	private List<String> associationValue;
	

	public String getAssociationKey() {
		return associationKey;
	}

	public void setAssociationKey(String associationKey) {
		this.associationKey = associationKey;
	}

	public List<String> getAssociationValue() {
		return associationValue;
	}

	public void setAssociationValue(List<String> associationValue) {
		this.associationValue = associationValue;
	}

	@Override
	public String toString() {
		return "Association [associationKey=" + associationKey + ", associationValue=" + associationValue + "]";
	}
	
	
	
}
