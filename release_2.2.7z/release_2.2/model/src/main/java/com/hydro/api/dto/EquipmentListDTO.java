package com.hydro.api.dto;

import java.util.List;

public class EquipmentListDTO {
    private String siteName;
    private String siteId;
    private String siteIPAddress; // siteUniqueId.
    private List<EquipmentDTO> equipmentList;

    public List<EquipmentDTO> getEquipmentList() {
	return equipmentList;
    }

    public void setEquipmentList(List<EquipmentDTO> equipmentList) {
	this.equipmentList = equipmentList;
    }

    public String getSiteName() {
	return siteName;
    }

    public void setSiteName(String siteName) {
	this.siteName = siteName;
    }

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getSiteIPAddress() {
	return siteIPAddress;
    }

    public void setSiteIPAddress(String siteIPAddress) {
	this.siteIPAddress = siteIPAddress;
    }

}
