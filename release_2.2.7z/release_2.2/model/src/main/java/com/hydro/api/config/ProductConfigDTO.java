package com.hydro.api.config;

public class ProductConfigDTO {
    public static final String ID = "lm2_seq";
    public static final String UID = "uid";
    public static final String ALARMS_CONTACT = "contact";
    public static final String ALARMS_SKIPPED = "alarms_ignored";
    public static final String ALARMS_TOLERANCE = "alarms_tolerance";
    public static final String CONCENTRATION = "concentration";
    public static final String DATE_CALIBRATION = "calibration";
    public static final String DATE_LAST_CHANGE = "date_last_change";
    public static final String DENSITY = "density";
    public static final String DOSING_MODE = "dosing_mode";
    public static final String ESTATE = "estate";
    public static final String FLOW_RATE = "flow";
    public static final String KF = "kf";
    public static final String NAME = "name";
    public static final String PRICE = "price";
    public static final String PRIORITY = "priority";
    public static final String PUMP_SAFE_STOP = "pump_safe_stop";
    public static final String ROTAMETER_SENSOR = "rotameter_sensor";
    public static final String STATISTIC_PRODUCTION = "statistic_production";
    public static final String STATISTIC_WARNINGS = "statistic_warnings";
    public static final ConfigExtractionRule  productFetchRule;
    static {
	productFetchRule = new ConfigExtractionRule();
	productFetchRule.setExcluded("product_id", "equipment_id", "created_by", "created_date",  "modified_by", "modified_date");
	productFetchRule.setNameToAlias(new String[][] {{"lm2_seq","id"}, {"contact","alarms_contact"}, {"alarms_ignored","alarms_skipped"},{"calibration","date_calibration"}, {"flow", "flow_rate"}});
    }
    private String id;
    private String uid;
    private String alarms_contact;
    private String alarms_skipped;
    private String alarms_tolerance;
    private String concentration;
    private String date_calibration;
    private String date_last_change;
    private String density;
    private String dosing_mode;
    private String estate;
    private String flow_rate;
    private String kf;
    private String name;
    private String price;
    private String priority;
    private String pump_safe_stop;
    private String rotameter_sensor;
    private String statistic_production;
    private String statistic_warnings;

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getUid() {
	return uid;
    }

    public void setUid(String uid) {
	this.uid = uid;
    }

    public String getAlarms_contact() {
	return alarms_contact;
    }

    public void setAlarms_contact(String alarms_contact) {
	this.alarms_contact = alarms_contact;
    }

    public String getAlarms_skipped() {
	return alarms_skipped;
    }

    public void setAlarms_skipped(String alarms_skipped) {
	this.alarms_skipped = alarms_skipped;
    }

    public String getAlarms_tolerance() {
	return alarms_tolerance;
    }

    public void setAlarms_tolerance(String alarms_tolerance) {
	this.alarms_tolerance = alarms_tolerance;
    }

    public String getConcentration() {
	return concentration;
    }

    public void setConcentration(String concentration) {
	this.concentration = concentration;
    }

    public String getDate_calibration() {
	return date_calibration;
    }

    public void setDate_calibration(String date_calibration) {
	this.date_calibration = date_calibration;
    }

    public String getDate_last_change() {
	return date_last_change;
    }

    public void setDate_last_change(String date_last_change) {
	this.date_last_change = date_last_change;
    }

    public String getDensity() {
	return density;
    }

    public void setDensity(String density) {
	this.density = density;
    }

    public String getDosing_mode() {
	return dosing_mode;
    }

    public void setDosing_mode(String dosing_mode) {
	this.dosing_mode = dosing_mode;
    }

    public String getEstate() {
	return estate;
    }

    public void setEstate(String estate) {
	this.estate = estate;
    }

    public String getFlow_rate() {
	return flow_rate;
    }

    public void setFlow_rate(String flow_rate) {
	this.flow_rate = flow_rate;
    }

    public String getKf() {
	return kf;
    }

    public void setKf(String kf) {
	this.kf = kf;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getPrice() {
	return price;
    }

    public void setPrice(String price) {
	this.price = price;
    }

    public String getPriority() {
	return priority;
    }

    public void setPriority(String priority) {
	this.priority = priority;
    }

    public String getPump_safe_stop() {
	return pump_safe_stop;
    }

    public void setPump_safe_stop(String pump_safe_stop) {
	this.pump_safe_stop = pump_safe_stop;
    }

    public String getRotameter_sensor() {
	return rotameter_sensor;
    }

    public void setRotameter_sensor(String rotameter_sensor) {
	this.rotameter_sensor = rotameter_sensor;
    }

    public String getStatistic_production() {
	return statistic_production;
    }

    public void setStatistic_production(String statistic_production) {
	this.statistic_production = statistic_production;
    }

    public String getStatistic_warnings() {
	return statistic_warnings;
    }

    public void setStatistic_warnings(String statistic_warnings) {
	this.statistic_warnings = statistic_warnings;
    }

}
