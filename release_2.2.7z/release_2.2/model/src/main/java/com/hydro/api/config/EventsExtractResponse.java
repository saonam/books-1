package com.hydro.api.config;

import com.hydro.api.dto.ShiftDTO;

public class EventsExtractResponse {
    private ShiftDTO eventsExtract;

    public ShiftDTO getEventsExtract() {
        return eventsExtract;
    }

    public void setEventsExtract(ShiftDTO eventsExtract) {
        this.eventsExtract = eventsExtract;
    }
    
}
