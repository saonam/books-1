package com.hydro.api.config;

import java.util.List;

public class MasterConfigDTO {
    private String data_source;
    private String data_type;
    private LaundryDTO laundry;
    private UnitDTO unit;
    private int num_channels;
    private List<ChannelDTO> channels;
    private List<WaterDTO> water;
    private int num_products;
    private List<ProductConfigDTO> products;
    private int num_machines;
    private List<MachineDTO> machines;
    private List<EquipmentConfigDTO> units;

    public int getNum_products() {
	return num_products;
    }

    public void setNum_products(int num_products) {
	this.num_products = num_products;
    }

    public String getData_source() {
	return data_source;
    }

    public void setData_source(String data_source) {
	this.data_source = data_source;
    }

    public String getData_type() {
	return data_type;
    }

    public void setData_type(String data_type) {
	this.data_type = data_type;
    }

    public int getNum_channels() {
	return num_channels;
    }

    public void setNum_channels(int num_channels) {
	this.num_channels = num_channels;
    }

    public int getNum_machines() {
	return num_machines;
    }

    public void setNum_machines(int num_machines) {
	this.num_machines = num_machines;
    }

    public LaundryDTO getLaundry() {
	return laundry;
    }

    public void setLaundry(LaundryDTO laundry) {
	this.laundry = laundry;
    }

    public UnitDTO getUnit() {
	return unit;
    }

    public void setUnit(UnitDTO unit) {
	this.unit = unit;
    }

    public List<ChannelDTO> getChannels() {
	return channels;
    }

    public void setChannels(List<ChannelDTO> channels) {
	this.channels = channels;
    }

    public List<WaterDTO> getWater() {
	return water;
    }

    public void setWater(List<WaterDTO> water) {
	this.water = water;
    }

    public List<ProductConfigDTO> getProducts() {
	return products;
    }

    public void setProducts(List<ProductConfigDTO> products) {
	this.products = products;
    }

    public List<MachineDTO> getMachines() {
	return machines;
    }

    public void setMachines(List<MachineDTO> machines) {
	this.machines = machines;
    }

    public List<EquipmentConfigDTO> getUnits() {
        return units;
    }

    public void setUnits(List<EquipmentConfigDTO> units) {
        this.units = units;
    }

}
