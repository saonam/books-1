/**
 * 
 */
package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */
public class SiteAssociationListResponseDTO {
    private List<SiteAssociationDTO> associationList;

    /**
     * @return the siteAssociationList
     */
    public List<SiteAssociationDTO> getSiteAssociationList() {
	return associationList;
    }

    /**
     * @param siteAssociationList
     *            the siteAssociationList to set
     */
    public void setSiteAssociationList(List<SiteAssociationDTO> associationList) {
	this.associationList = associationList;
    }

    /**
     * @return the associationList
     */

}
