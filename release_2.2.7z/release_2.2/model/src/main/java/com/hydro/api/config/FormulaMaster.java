package com.hydro.api.config;

import java.io.Serializable;

public class FormulaMaster implements  Serializable {

	private static final long serialVersionUID = 1L;
	private String uid;
	private String name;
	private int lm2_seq;//1
	private int phases; //31
	
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLm2_seq() {
		return lm2_seq;
	}
	public void setLm2_seq(int lm2_seq) {
		this.lm2_seq = lm2_seq;
	}
	public int getPhases() {
		return phases;
	}
	public void setPhases(int phases) {
		this.phases = phases;
	}
	
	
	
}
