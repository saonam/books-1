/**
 * 
 */
package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class UserListRequestDTO {
    public String userId;
    public String accessToken;

    /**
     * @return the userId
     */
    public String getUserId() {
	return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(String userId) {
	this.userId = userId;
    }

    /**
     * @return the accessToken
     */
    public String getAccessToken() {
	return accessToken;
    }

    /**
     * @param accessToken
     *            the accessToken to set
     */
    public void setAccessToken(String accessToken) {
	this.accessToken = accessToken;
    }

}
