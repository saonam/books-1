package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class EquipmentTunnelChannel {
    // tunnel_channel_id, equipment_id, tunnel_channel_name,
    // tunnel_channel_value
    private String tunnelChannelId;
    private String equipmentId;
    private String tunnelChannelName;
    private String tunnelChannelValue;

    public String getTunnelChannelId() {
	return tunnelChannelId;
    }

    public void setTunnelChannelId(String tunnelChannelId) {
	this.tunnelChannelId = tunnelChannelId;
    }

    public String getEquipmentId() {
	return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
	this.equipmentId = equipmentId;
    }

    public String getTunnelChannelName() {
	return tunnelChannelName;
    }

    public void setTunnelChannelName(String tunnelChannelName) {
	this.tunnelChannelName = tunnelChannelName;
    }

    public String getTunnelChannelValue() {
	return tunnelChannelValue;
    }

    public void setTunnelChannelValue(String tunnelChannelValue) {
	this.tunnelChannelValue = tunnelChannelValue;
    }

}
