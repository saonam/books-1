/**
 * 
 */
package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */
public class CompanyListResponseDTO {
    private List<CompanyDTO> companyList;

    /**
     * @return the userList
     */
    public List<CompanyDTO> getCompanyList() {
	return companyList;
    }

    /**
     * @param userList
     *            the userList to set
     */
    public void setCompanyList(List<CompanyDTO> companyList) {
	this.companyList = companyList;
    }

}
