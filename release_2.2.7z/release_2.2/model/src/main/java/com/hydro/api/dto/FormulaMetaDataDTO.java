package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */
public class FormulaMetaDataDTO {
    // formula_id, equipment_id, lm2_id, name, load, phases, color,
    // created_by, created_date, modified_by, modified_date
    private String formulaId;
    private String lm2Id;
    private String name;
    private Integer load;
    private String phases;
    private String color;
    private String createdBy;
    private String createdDate;
    private String modifiedBy;
    private String modifiedDate;
    private List<FormulaPDBDTO> formulaPDBList;

    public String getFormulaId() {
	return formulaId;
    }

    public void setFormulaId(String formulaId) {
	this.formulaId = formulaId;
    }

    public String getLm2Id() {
	return lm2Id;
    }

    public void setLm2Id(String lm2Id) {
	this.lm2Id = lm2Id;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public Integer getLoad() {
	return load;
    }

    public void setLoad(Integer load) {
	this.load = load;
    }

    public String getPhases() {
	return phases;
    }

    public void setPhases(String phases) {
	this.phases = phases;
    }

    public String getColor() {
	return color;
    }

    public void setColor(String color) {
	this.color = color;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public String getModifiedBy() {
	return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
	return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
    }

    public List<FormulaPDBDTO> getFormulaPDBList() {
	return formulaPDBList;
    }

    public void setFormulaPDBList(List<FormulaPDBDTO> formulaPDBList) {
	this.formulaPDBList = formulaPDBList;
    }

}
