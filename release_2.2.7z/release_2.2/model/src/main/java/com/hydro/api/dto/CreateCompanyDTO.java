/**
 * 
 */
package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class CreateCompanyDTO {
    private String companyId;

    /**
     * @return the companyId
     */
    public String getCompanyId() {
	return companyId;
    }

    /**
     * @param companyId
     *            the companyId to set
     */
    public void setCompanyId(String companyId) {
	this.companyId = companyId;
    }

}
