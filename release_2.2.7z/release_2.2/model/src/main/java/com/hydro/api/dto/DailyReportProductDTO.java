package com.hydro.api.dto;

import java.util.Date;

public class DailyReportProductDTO {
    private String productName;
    private Date time;
    private Integer productId;

    public String getProductName() {
	return productName;
    }

    public void setProductName(String productName) {
	this.productName = productName;
    }

    public Date getTime() {
	return time;
    }

    public void setTime(Date time) {
	this.time = time;
    }

    public Integer getProductId() {
	return productId;
    }

    public void setProductId(Integer productId) {
	this.productId = productId;
    }

}
