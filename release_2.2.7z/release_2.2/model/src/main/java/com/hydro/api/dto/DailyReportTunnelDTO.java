package com.hydro.api.dto;

import java.util.Map;

import com.hydro.api.dto.reports.DailyReportFormulaDTO;
import com.hydro.api.dto.reports.ModuleDTO;
import com.hydro.api.dto.reports.TransferDTO;

public class DailyReportTunnelDTO {
    // tunnel parameters
    private String name;
    private Long currentCycleTime;
    private long averageCycleTime;
    private Integer totalCycleProcessed;
    private Integer totalLbsProcessed;
    private Double efficiency;
    private Map<Integer, BatchDTO> batchMap;
    private Map<Integer, ModuleDTO> moduleHashMap;
    private Map<Integer, TransferDTO> transferMap;
    private TransferDTO transferDetails;
    private int moduleCount;
    private Integer moduleCapacity = 0;
    private Map<Integer, DailyReportFormulaDTO> formulaMap;
    private BatchDTO batchDetails;

    public Long getCurrentCycleTime() {
	return currentCycleTime;
    }

    public void setCurrentCycleTime(Long currentCycleTime) {
	this.currentCycleTime = currentCycleTime;
    }

    public Integer getTotalCycleProcessed() {
	return totalCycleProcessed;
    }

    public void setTotalCycleProcessed(Integer totalCycleProcessed) {
	this.totalCycleProcessed = totalCycleProcessed;
    }

    public Double getEfficiency() {
	return efficiency;
    }

    public void setEfficiency(Double efficiency) {
	this.efficiency = efficiency;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public Map<Integer, ModuleDTO> getModuleHashMap() {
	return moduleHashMap;
    }

    public void setModuleHashMap(Map<Integer, ModuleDTO> moduleHashMap) {
	this.moduleHashMap = moduleHashMap;
    }

    public Map<Integer, BatchDTO> getBatchMap() {
	return batchMap;
    }

    public void setBatchMap(Map<Integer, BatchDTO> batchMap) {
	this.batchMap = batchMap;
    }

    public Map<Integer, TransferDTO> getTransferMap() {
	return transferMap;
    }

    public void setTransferMap(Map<Integer, TransferDTO> transferMap) {
	this.transferMap = transferMap;
    }

    public TransferDTO getTransferDetails() {
	return transferDetails;
    }

    public void setTransferDetails(TransferDTO transferDetails) {
	this.transferDetails = transferDetails;
    }

    public BatchDTO getBatchDetails() {
	return batchDetails;
    }

    public void setBatchDetails(BatchDTO batchDetails) {
	this.batchDetails = batchDetails;
    }

    public int getModuleCount() {
	return moduleCount;
    }

    public void setModuleCount(int moduleCount) {
	this.moduleCount = moduleCount;
    }

    public Map<Integer, DailyReportFormulaDTO> getFormulaMap() {
	return formulaMap;
    }

    public void setFormulaMap(Map<Integer, DailyReportFormulaDTO> formulaMap) {
	this.formulaMap = formulaMap;
    }

    public Integer getTotalLbsProcessed() {
	return totalLbsProcessed;
    }

    public void setTotalLbsProcessed(Integer totalLbsProcessed) {
	this.totalLbsProcessed = totalLbsProcessed;
    }

    public long getAverageCycleTime() {
	return averageCycleTime;
    }

    public void setAverageCycleTime(long averageCycleTime) {
	this.averageCycleTime = averageCycleTime;
    }

    public Integer getModuleCapacity() {
        return moduleCapacity;
    }

    public void setModuleCapacity(Integer moduleCapacity) {
        this.moduleCapacity = moduleCapacity;
    }

}
