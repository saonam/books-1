package com.hydro.api.config;

import java.io.Serializable;
import java.util.List;


public class Config implements  Serializable {

	private static final long serialVersionUID = 1L;
	
	private String dataType;
	private MData mData;
	private List<UData> uData;
	
	
	public String getDataType() {
		return dataType;
	}
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}
	public MData getmData() {
		return mData;
	}
	public void setmData(MData mData) {
		this.mData = mData;
	}
	public List<UData> getuData() {
		return uData;
	}
	public void setuData(List<UData> uData) {
		this.uData = uData;
	}
	
	
	

}
