package com.hydro.api.config;

public class ChannelDTO {
    public static final String UID = "uid";
    public static final String ALARMS_SKIPPED = "alarms_skipped";
    public static final String ALARMS_TOLERANCE = "alarms_tolerance";
    public static final String DATE_LAST_CHANGE = "date_last_change";
    public static final String DOSING_MODE = "dosing_mode";
    public static final String FLUSH_AIR_ML = "flush_air_ml";
    public static final String FLUSH_AIR_TIME = "flush_air_time";
    public static final String FLUSH_TYPE = "flush_type";
    public static final String NAME = "name";
    public static final String PUMP_TYPE = "pump_type";
    public static final String WATER_TEST = "water_test";
    public static final ConfigExtractionRule  channelFetchRule;
    static {
	channelFetchRule = new ConfigExtractionRule();
	channelFetchRule.setExcluded("channel_id", "equipment_id");
    }
    private String uid;
    private String alarms_skipped;
    private String alarms_tolerance;
    private String date_last_change;
    private String dosing_mode;
    private String flush_air_ml;
    private String flush_air_time;
    private String flush_type;
    private String name;
    private String pump_type;
    private String water_test;

    public String getUid() {
	return uid;
    }

    public void setUid(String uid) {
	this.uid = uid;
    }

    public String getAlarms_skipped() {
	return alarms_skipped;
    }

    public void setAlarms_skipped(String alarms_skipped) {
	this.alarms_skipped = alarms_skipped;
    }

    public String getAlarms_tolerance() {
	return alarms_tolerance;
    }

    public void setAlarms_tolerance(String alarms_tolerance) {
	this.alarms_tolerance = alarms_tolerance;
    }

    public String getDate_last_change() {
	return date_last_change;
    }

    public void setDate_last_change(String date_last_change) {
	this.date_last_change = date_last_change;
    }

    public String getDosing_mode() {
	return dosing_mode;
    }

    public void setDosing_mode(String dosing_mode) {
	this.dosing_mode = dosing_mode;
    }

    public String getFlush_air_ml() {
	return flush_air_ml;
    }

    public void setFlush_air_ml(String flush_air_ml) {
	this.flush_air_ml = flush_air_ml;
    }

    public String getFlush_air_time() {
	return flush_air_time;
    }

    public void setFlush_air_time(String flush_air_time) {
	this.flush_air_time = flush_air_time;
    }

    public String getFlush_type() {
	return flush_type;
    }

    public void setFlush_type(String flush_type) {
	this.flush_type = flush_type;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getPump_type() {
	return pump_type;
    }

    public void setPump_type(String pump_type) {
	this.pump_type = pump_type;
    }

    public String getWater_test() {
	return water_test;
    }

    public void setWater_test(String water_test) {
	this.water_test = water_test;
    }

}
