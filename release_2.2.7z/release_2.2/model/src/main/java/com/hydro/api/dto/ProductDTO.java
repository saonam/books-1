package com.hydro.api.dto;

import java.math.BigDecimal;

/**
 * @author Srishti Tiwari
 *
 */
public class ProductDTO {
    // product_id, equipment_id, lm2_id, name, density, concentration, kf, flow,
    // frequency, docification_mode, priority, contact, alarms_ignored,
    // percentage,
    // drag_type, pump_speed, format, price, calibration, color1, color2,
    // created_by, created_date, modified_by, modified_date
    private String productId;
    private String equipmentId;
    private String lm2Seq;
    private String name;
    private String density;
    private int concentration;
    private String kf;
    private String flow;
    private String frequency;
    private String docimicationMode;
    private String priority;
    private String contact;
    private String alarmsIgnored;
    private String percentage;
    private String dragType;
    private String pumpSpeed;
    private int format;
    private String price;
    private String calibration;
    private String color1;
    private String color2;
    private String createdBy;
    private String createdDate;
    private String modifiedBy;
    private String modifiedDate;
    private BigDecimal precio;

    public String getProductId() {
	return productId;
    }

    public void setProductId(String productId) {
	this.productId = productId;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getDensity() {
	return density;
    }

    public void setDensity(String density) {
	this.density = density;
    }

    public int getConcentration() {
	return concentration;
    }

    public void setConcentration(int concentration) {
	this.concentration = concentration;
    }

    public String getKf() {
	return kf;
    }

    public void setKf(String kf) {
	this.kf = kf;
    }

    public String getFlow() {
	return flow;
    }

    public void setFlow(String flow) {
	this.flow = flow;
    }

    public String getFrequency() {
	return frequency;
    }

    public void setFrequency(String frequency) {
	this.frequency = frequency;
    }

    public String getDocimicationMode() {
	return docimicationMode;
    }

    public void setDocimicationMode(String docimicationMode) {
	this.docimicationMode = docimicationMode;
    }

    public String getPriority() {
	return priority;
    }

    public void setPriority(String priority) {
	this.priority = priority;
    }

    public String getContact() {
	return contact;
    }

    public void setContact(String contact) {
	this.contact = contact;
    }

    public String getAlarmsIgnored() {
	return alarmsIgnored;
    }

    public void setAlarmsIgnored(String alarmsIgnored) {
	this.alarmsIgnored = alarmsIgnored;
    }

    public String getPercentage() {
	return percentage;
    }

    public void setPercentage(String percentage) {
	this.percentage = percentage;
    }

    public String getDragType() {
	return dragType;
    }

    public void setDragType(String dragType) {
	this.dragType = dragType;
    }

    public String getPumpSpeed() {
	return pumpSpeed;
    }

    public void setPumpSpeed(String pumpSpeed) {
	this.pumpSpeed = pumpSpeed;
    }

    public int getFormat() {
	return format;
    }

    public void setFormat(int format) {
	this.format = format;
    }

    public String getPrice() {
	return price;
    }

    public void setPrice(String price) {
	this.price = price;
    }

    public String getCalibration() {
	return calibration;
    }

    public void setCalibration(String calibration) {
	this.calibration = calibration;
    }

    public String getColor1() {
	return color1;
    }

    public void setColor1(String color1) {
	this.color1 = color1;
    }

    public String getColor2() {
	return color2;
    }

    public void setColor2(String color2) {
	this.color2 = color2;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public String getModifiedBy() {
	return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
	return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
    }

    public String getEquipmentId() {
	return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
	this.equipmentId = equipmentId;
    }

    public String getLm2Seq() {
	return lm2Seq;
    }

    public void setLm2Seq(String lm2Seq) {
	this.lm2Seq = lm2Seq;
    }

    public BigDecimal getPrecio() {
	return precio;
    }

    public void setPrecio(BigDecimal precio) {
	this.precio = precio;
    }

    @Override
    public String toString() {
	return "ProductDTO [productId=" + productId + ", equipmentId=" + equipmentId + ", lm2Seq=" + lm2Seq + ", name="
		+ name + ", density=" + density + ", concentration=" + concentration + ", kf=" + kf + ", flow=" + flow
		+ ", frequency=" + frequency + ", docimicationMode=" + docimicationMode + ", priority=" + priority
		+ ", contact=" + contact + ", alarmsIgnored=" + alarmsIgnored + ", percentage=" + percentage
		+ ", dragType=" + dragType + ", pumpSpeed=" + pumpSpeed + ", format=" + format + ", price=" + price
		+ ", calibration=" + calibration + ", color1=" + color1 + ", color2=" + color2 + ", createdBy="
		+ createdBy + ", createdDate=" + createdDate + ", modifiedBy=" + modifiedBy + ", modifiedDate="
		+ modifiedDate + ", precio=" + precio + "]";
    }

}
