package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class WasherMetaDataDTO {
    // washer_id, equipment_id, lm2_id, name, load, modifiable_load, ltr_drag,
    // cellular_minutes,
    // id_formula, work_mode, reset_mode, reset_signal, reset_formula,
    // unused_machine, unused_time_
    // delay, unused_timeout, t_acceptation, t_repetition, t_lock,
    // type_programmer, signal_count,
    // signal_voltage, signal_connection, observation, created_by, created_date,
    // modified_by, modified_date

    private String washerId;
    private String equipmentId;
    private String lm2Seq;
    private String name;
    private Integer load;
    private String modifiableLoad;
    private String ltrDrag;
    private String cellularMinutes;
    private String idFormula;
    private String workMode;
    private String resetMode;
    private String resetSignal;
    private String resetFormula;
    private String unusedMachine;
    private String unusedTimeDelay;
    private String unusedTimeout;
    private String tAcceptation;
    private String tRepetition;
    private String tLock;
    private String typeProgrammer;
    private String signalCount;
    private String signalVoltage;
    private String signalConnection;
    private String observation;
    private String createdBy;
    private String createdDate;
    private String modifiedBy;
    private String modifiedDate;

    public String getWasherId() {
	return washerId;
    }

    public void setWasherId(String washerId) {
	this.washerId = washerId;
    }

    public String getEquipmentId() {
	return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
	this.equipmentId = equipmentId;
    }

    public String getLm2Seq() {
	return lm2Seq;
    }

    public void setLm2Seq(String lm2Seq) {
	this.lm2Seq = lm2Seq;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public Integer getLoad() {
	return load;
    }

    public void setLoad(Integer load) {
	this.load = load;
    }

    public String getModifiableLoad() {
	return modifiableLoad;
    }

    public void setModifiableLoad(String modifiableLoad) {
	this.modifiableLoad = modifiableLoad;
    }

    public String getLtrDrag() {
	return ltrDrag;
    }

    public void setLtrDrag(String ltrDrag) {
	this.ltrDrag = ltrDrag;
    }

    public String getCellularMinutes() {
	return cellularMinutes;
    }

    public void setCellularMinutes(String cellularMinutes) {
	this.cellularMinutes = cellularMinutes;
    }

    public String getIdFormula() {
	return idFormula;
    }

    public void setIdFormula(String idFormula) {
	this.idFormula = idFormula;
    }

    public String getWorkMode() {
	return workMode;
    }

    public void setWorkMode(String workMode) {
	this.workMode = workMode;
    }

    public String getResetMode() {
	return resetMode;
    }

    public void setResetMode(String resetMode) {
	this.resetMode = resetMode;
    }

    public String getResetSignal() {
	return resetSignal;
    }

    public void setResetSignal(String resetSignal) {
	this.resetSignal = resetSignal;
    }

    public String getResetFormula() {
	return resetFormula;
    }

    public void setResetFormula(String resetFormula) {
	this.resetFormula = resetFormula;
    }

    public String getUnusedMachine() {
	return unusedMachine;
    }

    public void setUnusedMachine(String unusedMachine) {
	this.unusedMachine = unusedMachine;
    }

    public String getUnusedTimeDelay() {
	return unusedTimeDelay;
    }

    public void setUnusedTimeDelay(String unusedTimeDelay) {
	this.unusedTimeDelay = unusedTimeDelay;
    }

    public String getUnusedTimeout() {
	return unusedTimeout;
    }

    public void setUnusedTimeout(String unusedTimeout) {
	this.unusedTimeout = unusedTimeout;
    }

    public String gettRepetition() {
	return tRepetition;
    }

    public void settRepetition(String tRepetition) {
	this.tRepetition = tRepetition;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public String getModifiedBy() {
	return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
	return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
    }

    public String gettAcceptation() {
	return tAcceptation;
    }

    public void settAcceptation(String tAcceptation) {
	this.tAcceptation = tAcceptation;
    }

    public String gettLock() {
	return tLock;
    }

    public void settLock(String tLock) {
	this.tLock = tLock;
    }

    public String getTypeProgrammer() {
	return typeProgrammer;
    }

    public void setTypeProgrammer(String typeProgrammer) {
	this.typeProgrammer = typeProgrammer;
    }

    public String getSignalCount() {
	return signalCount;
    }

    public void setSignalCount(String signalCount) {
	this.signalCount = signalCount;
    }

    public String getSignalVoltage() {
	return signalVoltage;
    }

    public void setSignalVoltage(String signalVoltage) {
	this.signalVoltage = signalVoltage;
    }

    public String getSignalConnection() {
	return signalConnection;
    }

    public void setSignalConnection(String signalConnection) {
	this.signalConnection = signalConnection;
    }

    public String getObservation() {
	return observation;
    }

    public void setObservation(String observation) {
	this.observation = observation;
    }

}
