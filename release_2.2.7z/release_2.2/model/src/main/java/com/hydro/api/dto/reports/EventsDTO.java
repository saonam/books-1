package com.hydro.api.dto.reports;

import java.util.Date;

/**
 * @author Srishti Tiwari
 *
 */
public class EventsDTO {
    private String eventId;
    private Boolean currentStatus = false;
    private String productName;
    private Integer productId;
    private Double cost;
    private String timeEstimated;
    private String timeActual;
    private Integer eventType;
    private Date eventStartTime;
    private Integer phase;
    private Integer module;
    private Double ml;
    private Double mlEstimated;
    private Integer alarmType;

    public Integer getPhase() {
	return phase;
    }

    public void setPhase(Integer phase) {
	this.phase = phase;
    }

    public Boolean getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(Boolean currentStatus) {
        this.currentStatus = currentStatus;
    }

    public String getProductName() {
	return productName;
    }

    public void setProductName(String productName) {
	this.productName = productName;
    }

    public String getTimeEstimated() {
	return timeEstimated;
    }

    public void setTimeEstimated(String timeEstimated) {
	this.timeEstimated = timeEstimated;
    }

    public String getTimeActual() {
	return timeActual;
    }

    public void setTimeActual(String timeActual) {
	this.timeActual = timeActual;
    }

    public String getEventId() {
	return eventId;
    }

    public void setEventId(String eventId) {
	this.eventId = eventId;
    }

    public Integer getEventType() {
	return eventType;
    }

    public void setEventType(Integer eventType) {
	this.eventType = eventType;
    }

    public Integer getProductId() {
	return productId;
    }

    public void setProductId(Integer productId) {
	this.productId = productId;
    }

    public Date getEventStartTime() {
	return eventStartTime;
    }

    public void setEventStartTime(Date eventStartTime) {
	this.eventStartTime = eventStartTime;
    }

    public Double getMl() {
	return ml;
    }

    public void setMl(Double ml) {
	this.ml = ml;
    }

    public Double getMlEstimated() {
        return mlEstimated;
    }

    public void setMlEstimated(Double mlEstimated) {
        this.mlEstimated = mlEstimated;
    }

    public Double getCost() {
	return cost;
    }

    public void setCost(Double cost) {
	this.cost = cost;
    }

    public Integer getAlarmType() {
	return alarmType;
    }

    public void setAlarmType(Integer alarmType) {
	this.alarmType = alarmType;
    }

    public Integer getModule() {
	return module;
    }

    public void setModule(Integer module) {
	this.module = module;
    }

}
