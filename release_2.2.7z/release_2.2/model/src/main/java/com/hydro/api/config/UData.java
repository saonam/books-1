package com.hydro.api.config;

import java.io.Serializable;

public class UData implements  Serializable {

	private static final long serialVersionUID = 1L;
	private TData tData;
	
	public TData gettData() {
		return tData;
	}
	public void settData(TData tData) {
		this.tData = tData;
	}
	
	
}
