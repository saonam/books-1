/// **
// *
// */
// package com.hydro.api.dto;
//
// import java.util.Set;
//
/// **
// * @author Srishti Tiwari
// *
// */
// public class PermissionListDTO {
// private Set<String> permissionList;
//
// public Set<String> getPermissionList() {
// return permissionList;
// }
//
// public void setPermissionList(Set<String> permissionList) {
// this.permissionList = permissionList;
// }
//
// }
