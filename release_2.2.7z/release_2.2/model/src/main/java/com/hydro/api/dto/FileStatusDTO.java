package com.hydro.api.dto;

/**
 * @author suganya
 *
 */
public class FileStatusDTO {
	private boolean uploaded;
	private String uploadUid;
	private boolean status;
	public boolean isUploaded() {
		return uploaded;
	}
	public void setUploaded(boolean uploaded) {
		this.uploaded = uploaded;
	}
	public String getUploadUid() {
	    return uploadUid;
	}
	public void setUploadUid(String uploadUid) {
	    this.uploadUid = uploadUid;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	 
}
