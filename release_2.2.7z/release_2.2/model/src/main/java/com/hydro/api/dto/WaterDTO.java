package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class WaterDTO {
    // water_id, equipment_id, name, kf, flow, water_time, cellphone_minute,
    // docification_mode, seperation_ml, ignored_alarms,
    // percentage, diameter, pump_type, created_by, created_date, modified_by,
    // modified_date
    private String waterId;
    private String equipmentId;
    private String name;
    private String kf;
    private String flow;
    private String waterTime;
    private String cellphoneMinute;
    private String docificationMode;
    private String seperationMl;
    private String ignoredAlarms;
    private String percentage;
    private String diameter;
    private String pumpType;
    private String createdBy;
    private String createdDate;
    private String modifiedBy;
    private String modifiedDate;

    public String getWaterId() {
	return waterId;
    }

    public void setWaterId(String waterId) {
	this.waterId = waterId;
    }

    public String getEquipmentId() {
	return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
	this.equipmentId = equipmentId;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getKf() {
	return kf;
    }

    public void setKf(String kf) {
	this.kf = kf;
    }

    public String getFlow() {
	return flow;
    }

    public void setFlow(String flow) {
	this.flow = flow;
    }

    public String getWaterTime() {
	return waterTime;
    }

    public void setWaterTime(String waterTime) {
	this.waterTime = waterTime;
    }

    public String getCellphoneMinute() {
	return cellphoneMinute;
    }

    public void setCellphoneMinute(String cellphoneMinute) {
	this.cellphoneMinute = cellphoneMinute;
    }

    public String getDocificationMode() {
	return docificationMode;
    }

    public void setDocificationMode(String docificationMode) {
	this.docificationMode = docificationMode;
    }

    public String getSeperationMl() {
	return seperationMl;
    }

    public void setSeperationMl(String seperationMl) {
	this.seperationMl = seperationMl;
    }

    public String getIgnoredAlarms() {
	return ignoredAlarms;
    }

    public void setIgnoredAlarms(String ignoredAlarms) {
	this.ignoredAlarms = ignoredAlarms;
    }

    public String getPercentage() {
	return percentage;
    }

    public void setPercentage(String percentage) {
	this.percentage = percentage;
    }

    public String getDiameter() {
	return diameter;
    }

    public void setDiameter(String diameter) {
	this.diameter = diameter;
    }

    public String getPumpType() {
	return pumpType;
    }

    public void setPumpType(String pumpType) {
	this.pumpType = pumpType;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public String getModifiedBy() {
	return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
	return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
    }

}
