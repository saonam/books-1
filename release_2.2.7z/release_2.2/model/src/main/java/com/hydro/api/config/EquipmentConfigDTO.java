package com.hydro.api.config;

import java.util.List;
import java.util.Map;

public class EquipmentConfigDTO {
    private Map<String,Object> equipment;
    private int num_channels;
    private List<Map<String,Object>> channels;
    private List<Map<String,Object>> water;
    private int num_products;
    private List<Map<String,Object>> products;
    private int num_machines;
    private List<Map<String,Object>> machines;
    private int num_formulas;
    private List<Map<String,Object>> formulas;
//    public Map<String, Object> getUnit() {
//        return unit;
//    }
//    public void setUnit(Map<String, Object> unit) {
//        this.unit = unit;
//    }
    public Map<String, Object> getEquipment() {
        return equipment;
    }
    public void setEquipment(Map<String, Object> equipment) {
        this.equipment = equipment;
    }
    public int getNum_channels() {
        return num_channels;
    }
    public void setNum_channels(int num_channels) {
        this.num_channels = num_channels;
    }
    public List<Map<String, Object>> getChannels() {
        return channels;
    }
    public void setChannels(List<Map<String, Object>> channels) {
        this.channels = channels;
    }
    public List<Map<String, Object>> getWater() {
        return water;
    }
    public void setWater(List<Map<String, Object>> water) {
        this.water = water;
    }
    public int getNum_products() {
        return num_products;
    }
    public void setNum_products(int num_products) {
        this.num_products = num_products;
    }
    public List<Map<String, Object>> getProducts() {
        return products;
    }
    public void setProducts(List<Map<String, Object>> products) {
        this.products = products;
    }
    public int getNum_machines() {
        return num_machines;
    }
    public void setNum_machines(int num_machines) {
        this.num_machines = num_machines;
    }
    public List<Map<String, Object>> getMachines() {
        return machines;
    }
    public void setMachines(List<Map<String, Object>> machines) {
        this.machines = machines;
    }
    public int getNum_formulas() {
        return num_formulas;
    }
    public void setNum_formulas(int num_formulas) {
        this.num_formulas = num_formulas;
    }
    public List<Map<String, Object>> getFormulas() {
        return formulas;
    }
    public void setFormulas(List<Map<String, Object>> formulas) {
        this.formulas = formulas;
    }
}
