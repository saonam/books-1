package com.hydro.api.config;

public class MachineDTO {
    public static final String UID = "uid";
    public static final String DATE_LAST_CHANGE = "date_last_change";
    public static final String END_FORMULA = "end_formula";
    public static final String END_MODE = "end_mode";
    public static final String END_SIGNAL_PUMP = "end_signal_pump";
    public static final String FLUSH_L = "flush_l";
    public static final String FORMULA_ID = "id_formula";
    public static final String HOLD_DELAY = "hold_delay";
    public static final String HOLD_MODE = "hold_mode";
    public static final String HOLD_TIMEOUT = "hold_timeout";
    public static final String KG = "load";
    public static final String KG_SEL = "kg_sel";
    public static final String NAME = "name";
    public static final String TIME_ACCEPTANCE = "t_acceptation";
    public static final String TIME_LOCK = "t_lock";
    public static final String TIME_REPETITION = "t_repetition";
    public static final String TRIGGER_MODE = "trigger_mode";
    public static final ConfigExtractionRule  tunnelFetchRule;
    public static final ConfigExtractionRule  washerFetchRule;
    static {
	tunnelFetchRule = new ConfigExtractionRule();
	tunnelFetchRule.setExcluded("tunnel_id", "equipment_id", "created_by", "created_date",  "modified_by", "modified_date");
	
	washerFetchRule = new ConfigExtractionRule();
	washerFetchRule.setExcluded("washer_id", "equipment_id", "created_by", "created_date",  "modified_by", "modified_date");
	washerFetchRule.setNameToAlias(new String[][] {{"id_formula","formula_id"}, {"load", "kg"}, {"t_acceptation","time_acceptance"}, {"t_lock","time_lock"}, {"t_repetition", "time_repetition"}});
    }
    private String uid;
    private String date_last_change;
    private String end_formula;
    private String end_mode;
    private String end_signal_pump;
    private String flush_l;
    private String formula_id;
    private String hold_delay;
    private String hold_mode;
    private String hold_timeout;
    private String kg;
    private String kg_sel;
    private String name;
    private String time_acceptance;
    private String time_lock;
    private String time_repetition;
    private String trigger_mode;

    public String getUid() {
	return uid;
    }

    public void setUid(String uid) {
	this.uid = uid;
    }

    public String getDate_last_change() {
	return date_last_change;
    }

    public void setDate_last_change(String date_last_change) {
	this.date_last_change = date_last_change;
    }

    public String getEnd_formula() {
	return end_formula;
    }

    public void setEnd_formula(String end_formula) {
	this.end_formula = end_formula;
    }

    public String getEnd_mode() {
	return end_mode;
    }

    public void setEnd_mode(String end_mode) {
	this.end_mode = end_mode;
    }

    public String getEnd_signal_pump() {
	return end_signal_pump;
    }

    public void setEnd_signal_pump(String end_signal_pump) {
	this.end_signal_pump = end_signal_pump;
    }

    public String getFlush_l() {
	return flush_l;
    }

    public void setFlush_l(String flush_l) {
	this.flush_l = flush_l;
    }

    public String getFormula_id() {
	return formula_id;
    }

    public void setFormula_id(String formula_id) {
	this.formula_id = formula_id;
    }

    public String getHold_delay() {
	return hold_delay;
    }

    public void setHold_delay(String hold_delay) {
	this.hold_delay = hold_delay;
    }

    public String getHold_mode() {
	return hold_mode;
    }

    public void setHold_mode(String hold_mode) {
	this.hold_mode = hold_mode;
    }

    public String getHold_timeout() {
	return hold_timeout;
    }

    public void setHold_timeout(String hold_timeout) {
	this.hold_timeout = hold_timeout;
    }

    public String getKg() {
	return kg;
    }

    public void setKg(String kg) {
	this.kg = kg;
    }

    public String getKg_sel() {
	return kg_sel;
    }

    public void setKg_sel(String kg_sel) {
	this.kg_sel = kg_sel;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getTime_acceptance() {
	return time_acceptance;
    }

    public void setTime_acceptance(String time_acceptance) {
	this.time_acceptance = time_acceptance;
    }

    public String getTime_lock() {
	return time_lock;
    }

    public void setTime_lock(String time_lock) {
	this.time_lock = time_lock;
    }

    public String getTime_repetition() {
	return time_repetition;
    }

    public void setTime_repetition(String time_repetition) {
	this.time_repetition = time_repetition;
    }

    public String getTrigger_mode() {
	return trigger_mode;
    }

    public void setTrigger_mode(String trigger_mode) {
	this.trigger_mode = trigger_mode;
    }

}
