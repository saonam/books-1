package com.hydro.api.config;

import java.io.Serializable;
import java.util.List;


public class TData implements  Serializable {

	private static final long serialVersionUID = 1L;
	
	private List<ProductMaster> product_master;
	private List<MachineMaster> machine_master;
	private List<FormulaMaster> formula_master;
	private List<WaterMaster> water_master;
	private List<UnitMaster> unit_master;
	
	
	public List<ProductMaster> getProduct_master() {
		return product_master;
	}
	public void setProduct_master(List<ProductMaster> product_master) {
		this.product_master = product_master;
	}
	
	public List<FormulaMaster> getFormula_master() {
		return formula_master;
	}
	public void setFormula_master(List<FormulaMaster> formula_master) {
		this.formula_master = formula_master;
	}
	public List<WaterMaster> getWater_master() {
		return water_master;
	}
	public void setWater_master(List<WaterMaster> water_master) {
		this.water_master = water_master;
	}
	public List<MachineMaster> getMachine_master() {
		return machine_master;
	}
	public void setMachine_master(List<MachineMaster> machine_master) {
		this.machine_master = machine_master;
	}
	public List<UnitMaster> getUnit_master() {
		return unit_master;
	}
	public void setUnit_master(List<UnitMaster> unit_master) {
		this.unit_master = unit_master;
	}
	

	
	
}
