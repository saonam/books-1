/**
 * 
 */
package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */
public class UserListResponseDTO {
    private List<UserDTO> userList;

    /**
     * @return the userList
     */
    public List<UserDTO> getUserList() {
	return userList;
    }

    /**
     * @param userList
     *            the userList to set
     */
    public void setUserList(List<UserDTO> userList) {
	this.userList = userList;
    }

}
