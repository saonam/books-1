/**
 * 
 */
package com.hydro.api.dto.reports;

/**
 * @author Shreyas K C
 *
 */
public class FormulaDTO {
    private String formulaName;
    private String formulaId;

    // For Washer Production Summary
    private Long washedWeight;
    private Integer loads;

    // For Chemical Usage Summary.
    private Double estimatedUsage;
    private Double actualUsage;
    private Double errorUsage;

    // For Cost Summary
    private Double estimatedCost;
    private Double estimatedCw;
    private Double realCost;
    private Double realCw;
    private Double errorCost;

    public Long getWashedWeight() {
	return washedWeight;
    }

    public void setWashedWeight(Long washedWeight) {
	this.washedWeight = washedWeight;
    }

    public int getLoads() {
	return loads;
    }

    public void setLoads(int loads) {
	this.loads = loads;
    }

    public String getFormulaName() {
	return formulaName;
    }

    public void setFormulaName(String formulaName) {
	this.formulaName = formulaName;
    }

    public String getFormulaId() {
	return formulaId;
    }

    public void setFormulaId(String formulaId) {
	this.formulaId = formulaId;
    }

    public Double getEstimatedUsage() {
	return estimatedUsage;
    }

    public void setEstimatedUsage(Double estimatedUsage) {
	this.estimatedUsage = estimatedUsage;
    }

    public Double getActualUsage() {
	return actualUsage;
    }

    public void setActualUsage(Double actualUsage) {
	this.actualUsage = actualUsage;
    }

    public Double getErrorUsage() {
	return errorUsage;
    }

    public void setErrorUsage(Double errorUsage) {
	this.errorUsage = errorUsage;
    }

    public void setLoads(Integer loads) {
	this.loads = loads;
    }

    public Double getEstimatedCost() {
	return estimatedCost;
    }

    public void setEstimatedCost(Double estimatedCost) {
	this.estimatedCost = estimatedCost;
    }

    public Double getEstimatedCw() {
	return estimatedCw;
    }

    public void setEstimatedCw(Double estimatedCw) {
	this.estimatedCw = estimatedCw;
    }

    public Double getRealCost() {
	return realCost;
    }

    public void setRealCost(Double realCost) {
	this.realCost = realCost;
    }

    public Double getRealCw() {
	return realCw;
    }

    public void setRealCw(Double realCw) {
	this.realCw = realCw;
    }

    public Double getErrorCost() {
	return errorCost;
    }

    public void setErrorCost(Double errorCost) {
	this.errorCost = errorCost;
    }
}
