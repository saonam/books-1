package com.hydro.api.config;

public class WaterDTO {
    public static final String UID = "uid";
    public static final String CHANNEL = "channel";
    public static final String DATE_CALIBRATION = "date_calibration";
    public static final String DATE_LAST_CHANGE = "date_last_change";
    public static final String FLOW_RATE = "flow";
    public static final String KF = "kf";
    public static final ConfigExtractionRule  waterFetchRule;
    static {
	waterFetchRule = new ConfigExtractionRule();
	waterFetchRule.setExcluded("water_id", "equipment_id", "created_by", "created_date",  "modified_by", "modified_date");
	waterFetchRule.setNameToAlias(new String[][] {{"lm2_seq","id"},{"flow","flow_rate"}});
    }
    private String uid;
    private String channel;
    private String date_calibration;
    private String date_last_change;
    private String flow_rate;
    private String kf;

    public String getUid() {
	return uid;
    }

    public void setUid(String uid) {
	this.uid = uid;
    }

    public String getChannel() {
	return channel;
    }

    public void setChannel(String channel) {
	this.channel = channel;
    }

    public String getDate_calibration() {
	return date_calibration;
    }

    public void setDate_calibration(String date_calibration) {
	this.date_calibration = date_calibration;
    }

    public String getDate_last_change() {
	return date_last_change;
    }

    public void setDate_last_change(String date_last_change) {
	this.date_last_change = date_last_change;
    }

    public String getFlow_rate() {
	return flow_rate;
    }

    public void setFlow_rate(String flow_rate) {
	this.flow_rate = flow_rate;
    }

    public String getKf() {
	return kf;
    }

    public void setKf(String kf) {
	this.kf = kf;
    }

}
