/**
 * 
 */
package com.hydro.api.dto;

import java.util.HashMap;
import java.util.List;

/**
 * @author Shreyas K C
 *
 */
public class UserCreationRolesDTO {
    private String orgType;
    private String uri;
    // private HashMap<String, List<RoleDTO>> userRole;
    // private List<String> userRole;
    private List<HashMap<String, Object>> userRole;

    public String getOrgType() {
	return orgType;
    }

    public void setOrgType(String orgType) {
	this.orgType = orgType;
    }

    public String getUri() {
	return uri;
    }

    public void setUri(String uri) {
	this.uri = uri;
    }

    public List<HashMap<String, Object>> getUserRole() {
	return userRole;
    }

    public void setUserRole(List<HashMap<String, Object>> userRole) {
	this.userRole = userRole;
    }

    // public List<String> getUserRole() {
    // return userRole;
    // }
    //
    // public void setUserRole(List<String> userRole) {
    // this.userRole = userRole;
    // }

}
