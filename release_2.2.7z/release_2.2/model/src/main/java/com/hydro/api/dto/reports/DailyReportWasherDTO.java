package com.hydro.api.dto.reports;

import java.util.Date;
import java.util.Map;

/**
 * @author Srishti Tiwari
 *
 */
public class DailyReportWasherDTO {
    private String washerName;
    private String activeFormulaName;
    private String currentShiftLoad;
    private String currentShiftLbs;
    private Date startTime;
    private Double efficiency;
    private Integer totalPhases;
    private String averageTurnTime;
    private String idleTime;
    private String lm2Seq;
    private String washerId;
    private Integer loads;
    private Integer lbs;
    private CycleDTO currentCycle;
    private Integer lastCycleKey;
    private Integer firstCycleKey;
    private Integer totalCapacity;
    private Integer totalLbs;
    private Map<Integer, CycleDTO> cycleHashMap;
    private Double timeElapsedInShift;
    private Long totalCycleActiveTime = 0L;
    private Long totalTurnTimeCount = 0L;
    private Long totalTurnTime = 0L;
    private String washerTurnTimeAverage;
    private String washerTurnTimeTotal;
    private String washerRunTimeAverage;
    private String washerRunTimeTotal;

    private Map<Integer, DailyReportFormulaDTO> formulaHashMap;

    public String getWasherName() {
	return washerName;
    }

    public void setWasherName(String washerName) {
	this.washerName = washerName;
    }

    public String getWasherId() {
	return washerId;
    }

    public void setWasherId(String washerId) {
	this.washerId = washerId;
    }

    public String getActiveFormulaName() {
	return activeFormulaName;
    }

    public void setActiveFormulaName(String activeFormulaName) {
	this.activeFormulaName = activeFormulaName;
    }

    public String getCurrentShiftLoad() {
	return currentShiftLoad;
    }

    public void setCurrentShiftLoad(String currentShiftLoad) {
	this.currentShiftLoad = currentShiftLoad;
    }

    public String getCurrentShiftLbs() {
	return currentShiftLbs;
    }

    public void setCurrentShiftLbs(String currentShiftLbs) {
	this.currentShiftLbs = currentShiftLbs;
    }

    public Integer getTotalPhases() {
	return totalPhases;
    }

    public void setTotalPhases(Integer totalPhases) {
	this.totalPhases = totalPhases;
    }

    public String getAverageTurnTime() {
	return averageTurnTime;
    }

    public void setAverageTurnTime(String averageTurnTime) {
	this.averageTurnTime = averageTurnTime;
    }

    public String getIdleTime() {
	return idleTime;
    }

    public void setIdleTime(String idleTime) {
	this.idleTime = idleTime;
    }

    public String getLm2Seq() {
	return lm2Seq;
    }

    public void setLm2Seq(String lm2Seq) {
	this.lm2Seq = lm2Seq;
    }

    public Integer getLoads() {
	return loads;
    }

    public void setLoads(Integer loads) {
	this.loads = loads;
    }

    public Integer getLbs() {
	return lbs;
    }

    public void setLbs(Integer lbs) {
	this.lbs = lbs;
    }

    public Map<Integer, CycleDTO> getCycleHashMap() {
	return cycleHashMap;
    }

    public void setCycleHashMap(Map<Integer, CycleDTO> cycleHashMap) {
	this.cycleHashMap = cycleHashMap;
    }

    public Date getStartTime() {
	return startTime;
    }

    public void setStartTime(Date startTime) {
	this.startTime = startTime;
    }

    public Double getEfficiency() {
	return efficiency;
    }

    public void setEfficiency(Double efficiency) {
	this.efficiency = efficiency;
    }

    public CycleDTO getCurrentCycle() {
	return currentCycle;
    }

    public void setCurrentCycle(CycleDTO currentCycle) {
	this.currentCycle = currentCycle;
    }

    public Integer getLastCycleKey() {
	return lastCycleKey;
    }

    public void setLastCycleKey(Integer lastCycleKey) {
	this.lastCycleKey = lastCycleKey;
    }

    public Integer getTotalLbs() {
	return totalLbs;
    }

    public void setTotalLbs(Integer totalLbs) {
	this.totalLbs = totalLbs;
    }

    public Integer getTotalCapacity() {
	return totalCapacity;
    }

    public void setTotalCapacity(Integer totalCapacity) {
	this.totalCapacity = totalCapacity;
    }

    public Map<Integer, DailyReportFormulaDTO> getFormulaHashMap() {
	return formulaHashMap;
    }

    public void setFormulaHashMap(Map<Integer, DailyReportFormulaDTO> formulaHashMap) {
	this.formulaHashMap = formulaHashMap;
    }

    public Integer getFirstCycleKey() {
	return firstCycleKey;
    }

    public void setFirstCycleKey(Integer firstCycleKey) {
	this.firstCycleKey = firstCycleKey;
    }

    public Double getTimeElapsedInShift() {
	return timeElapsedInShift;
    }

    public void setTimeElapsedInShift(Double timeElapsedInShift) {
	this.timeElapsedInShift = timeElapsedInShift;
    }

    public Long getTotalCycleActiveTime() {
        return totalCycleActiveTime;
    }

    public void setTotalCycleActiveTime(Long totalCycleActiveTime) {
        this.totalCycleActiveTime = totalCycleActiveTime;
    }

    public Long getTotalTurnTimeCount() {
        return totalTurnTimeCount;
    }

    public void setTotalTurnTimeCount(Long totalTurnTimeCount) {
        this.totalTurnTimeCount = totalTurnTimeCount;
    }

    public Long getTotalTurnTime() {
        return totalTurnTime;
    }

    public void setTotalTurnTime(Long totalTurnTime) {
        this.totalTurnTime = totalTurnTime;
    }

    public String getWasherTurnTimeAverage() {
	return washerTurnTimeAverage;
    }

    public void setWasherTurnTimeAverage(String washerTurnTimeAverage) {
	this.washerTurnTimeAverage = washerTurnTimeAverage;
    }

    public String getWasherTurnTimeTotal() {
	return washerTurnTimeTotal;
    }

    public void setWasherTurnTimeTotal(String washerTurnTimeTotal) {
	this.washerTurnTimeTotal = washerTurnTimeTotal;
    }

    public String getWasherRunTimeAverage() {
	return washerRunTimeAverage;
    }

    public void setWasherRunTimeAverage(String washerRunTimeAverage) {
	this.washerRunTimeAverage = washerRunTimeAverage;
    }

    public String getWasherRunTimeTotal() {
	return washerRunTimeTotal;
    }

    public void setWasherRunTimeTotal(String washerRunTimeTotal) {
	this.washerRunTimeTotal = washerRunTimeTotal;
    }
}
