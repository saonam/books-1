package com.hydro.api.dto.reports;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.hydro.api.dto.DailyReportProductDTO;

public class RealTimeAlarmDTO {
    private String alarmName;
    private Map<Integer, DailyReportProductDTO> productMap;
    private List<String> alarmParameters = new ArrayList<>();

    public String getAlarmName() {
	return alarmName;
    }

    public void setAlarmName(String alarmName) {
	this.alarmName = alarmName;
    }

    public List<String> getAlarmParameters() {
	return alarmParameters;
    }

    public void setAlarmParameters(List<String> alarmParameters) {
	this.alarmParameters = alarmParameters;
    }

    public Map<Integer, DailyReportProductDTO> getProductMap() {
	return productMap;
    }

    public void setProductMap(Map<Integer, DailyReportProductDTO> productMap) {
	this.productMap = productMap;
    }

}
