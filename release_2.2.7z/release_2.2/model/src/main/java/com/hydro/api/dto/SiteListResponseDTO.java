/**
 * 
 */
package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */
public class SiteListResponseDTO {
    private List<SiteDTO> siteList;

    /**
     * @return the siteList
     */
    public List<SiteDTO> getSiteList() {
	return siteList;
    }

    /**
     * @param siteList
     *            the siteList to set
     */
    public void setSiteList(List<SiteDTO> siteList) {
	this.siteList = siteList;
    }

}
