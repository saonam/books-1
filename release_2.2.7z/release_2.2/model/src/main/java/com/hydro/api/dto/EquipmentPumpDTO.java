package com.hydro.api.dto;

public class EquipmentPumpDTO {
//	pump_id, equipment_id, pump_name, pump_value
	private String pumpId;
	private String equipmentId;
	private String pumpName;
	private String pumpValue;
	public String getPumpId() {
		return pumpId;
	}
	public void setPumpId(String pumpId) {
		this.pumpId = pumpId;
	}
	public String getEquipmentId() {
		return equipmentId;
	}
	public void setEquipmentId(String equipmentId) {
		this.equipmentId = equipmentId;
	}
	public String getPumpName() {
		return pumpName;
	}
	public void setPumpName(String pumpName) {
		this.pumpName = pumpName;
	}
	public String getPumpValue() {
		return pumpValue;
	}
	public void setPumpValue(String pumpValue) {
		this.pumpValue = pumpValue;
	}
	
	

}
