/**
 * 
 */
package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */
public class AccountDTO {
    private String accountId;
    private String name;
    private String address1;
    private String address2;
    private String state;
    private String country;
    private String city;
    private String zipCode;
    private String description;
    private String createdBy;
    private List<SiteDTO> siteList;
    private ContactOperationsDTO contactOperations;
    private List<ContactDTO> contactList;
    private String createdDateStart;
    private String createdDateEnd;
    private String createdDate;
    private boolean sortByName;

    public String getAccountId() {
	return accountId;
    }

    public void setAccountId(String accountId) {
	this.accountId = accountId;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getDescription() {
	return description;
    }

    public void setDescription(String description) {
	this.description = description;
    }

    public String getAddress1() {
	return address1;
    }

    public void setAddress1(String address1) {
	this.address1 = address1;
    }

    public String getAddress2() {
	return address2;
    }

    public void setAddress2(String address2) {
	this.address2 = address2;
    }

    public String getState() {
	return state;
    }

    public void setState(String state) {
	this.state = state;
    }

    public String getCity() {
	return city;
    }

    public void setCity(String city) {
	this.city = city;
    }

    public String getZipCode() {
	return zipCode;
    }

    public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
    }

    public List<ContactDTO> getContactList() {
	return contactList;
    }

    public void setContactList(List<ContactDTO> contactList) {
	this.contactList = contactList;
    }

    public List<SiteDTO> getSiteList() {
	return siteList;
    }

    public void setSiteList(List<SiteDTO> siteList) {
	this.siteList = siteList;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public ContactOperationsDTO getContactOperations() {
	return contactOperations;
    }

    public void setContactOperations(ContactOperationsDTO contactDetails) {
	this.contactOperations = contactDetails;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getCreatedDateStart() {
	return createdDateStart;
    }

    public void setCreatedDateStart(String createdDateStart) {
	this.createdDateStart = createdDateStart;
    }

    public String getCreatedDateEnd() {
	return createdDateEnd;
    }

    public void setCreatedDateEnd(String createdDateEnd) {
	this.createdDateEnd = createdDateEnd;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public boolean isSortByName() {
	return sortByName;
    }

    public void setSortByName(boolean sortByName) {
	this.sortByName = sortByName;
    }

    public AccountDTO() {
    }

    public AccountDTO(boolean sortByName, String createdDateEnd, String createdDateStart) {
	this.sortByName = sortByName;
	this.createdDateEnd = createdDateEnd;
	this.createdDateStart = createdDateStart;
    }
}
