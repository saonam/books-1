package com.hydro.api.config;

import java.io.Serializable;

public class MachineMaster implements  Serializable {

	private static final long serialVersionUID = 1L;
	
	private String uid;
	private String name;
	private int id_formula;//1
	private long load; //200
	private int lm2_seq;
	
	
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId_formula() {
		return id_formula;
	}
	public void setId_formula(int id_formula) {
		this.id_formula = id_formula;
	}
	public long getLoad() {
		return load;
	}
	public void setLoad(long load) {
		this.load = load;
	}
	public int getLm2_seq() {
		return lm2_seq;
	}
	public void setLm2_seq(int lm2_seq) {
		this.lm2_seq = lm2_seq;
	}
	

}
