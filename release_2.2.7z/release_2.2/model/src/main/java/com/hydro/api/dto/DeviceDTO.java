package com.hydro.api.dto;

import java.util.List;
import java.util.Map;

public class DeviceDTO {
	private String id;
	private String serialNumber;
	private String siteId;
	private String ip;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	public void setSiteName(String siteName) {
		this.siteId = siteName;
	}
	
	public String getSiteName() {
		return this.siteId;
	}

	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	
	public String getSiteId() {
		return siteId;
	}
	
	public void setProperties(List<Map<String, String>> properties) {
		for(Map<String,String> property : properties) {
			if(property.get("variableName") != null && property.get("variableName").equalsIgnoreCase("IP")) {
				this.ip = property.get("variableValue");
			}
		}
		
	}
	
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	@Override
	public String toString() {
		return "DeviceDTO [id=" + id + ", serialNumber=" + serialNumber + ", siteId=" + siteId + ", ip=" + ip + "]";
	}
}
