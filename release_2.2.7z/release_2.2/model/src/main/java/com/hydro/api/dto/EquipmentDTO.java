package com.hydro.api.dto;

import java.util.List;
import java.util.Map;

public class EquipmentDTO {
    // equipment_id, lm2_id, site_id, alias, equipment_type, slave, ip_address,
    // observations, washer_count, tunnel_count, w_machine_chnl_count,
    // pump_count, channel_count, is_active, created_by, created_date,
    // modified_by, modified_date, version
    private String equipmentId;
    private Integer lm2Seq;
    private String deviceId;
    private String siteId;
    private String fileId;
    private String alias;
    private String equipmentType;
    private String slave;
    private String ipAddress;
    private String observations;
    private int washerCount;
    private int tunnelCount;
    private String wMachineChnlCount;
    private int pumpCount;
    private int channelCount;
    private String isActive;
    private String createdBy;
    private String createdDate;
    private String modifiedBy;
    private String modifiedDate;
    private String version;
    private List<EquipmentPumpDTO> equipmentPumpList;
    private List<EquipmentFormulaDTO> equipmentFormulaList;
    private List<EquipmentPumpMachinery> equipmentPumpMachineriesList;
    private List<FormulaMetaDataDTO> formulaList;
    private List<WaterDTO> waterList;
    private List<EquipmentTunnelChannel> equipmentTunnelChannelsList;
    private List<ProductDTO> productList;
    private Map<String, String> productMap;
    private List<WasherMetaDataDTO> washerList;
    private List<TunnelDTO> tunnelList;
    private List<ObservationDTO> observationList;
    private String equipmentName;
    private String siteName;
    private int productCount;
    private int formulaCount;

    public String getEquipmentId() {
	return equipmentId;
    }

    public void setEquipmentId(String equipmentId) {
	this.equipmentId = equipmentId;
    }

    public String getEquipmentName() {
	return equipmentName;
    }

    public void setEquipmentName(String equipmentName) {
	this.equipmentName = equipmentName;
    }

    public Integer getLm2Seq() {
	return lm2Seq;
    }

    public void setLm2Seq(Integer lm2Id) {
	this.lm2Seq = lm2Id;
    }

    public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getAlias() {
	return alias;
    }

    public void setAlias(String alias) {
	this.alias = alias;
    }

    public String getEquipmentType() {
	return equipmentType;
    }

    public void setEquipmentType(String equipmentType) {
	this.equipmentType = equipmentType;
    }

    public String getSlave() {
	return slave;
    }

    public void setSlave(String slave) {
	this.slave = slave;
    }

    public String getIpAddress() {
	return ipAddress;
    }

    public void setIpAddress(String ipAddress) {
	this.ipAddress = ipAddress;
    }

    public String getObservations() {
	return observations;
    }

    public void setObservations(String observations) {
	this.observations = observations;
    }

    public String getwMachineChnlCount() {
	return wMachineChnlCount;
    }

    public void setwMachineChnlCount(String wMachineChnlCount) {
	this.wMachineChnlCount = wMachineChnlCount;
    }

    public String getIsActive() {
	return isActive;
    }

    public void setIsActive(String isActive) {
	this.isActive = isActive;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public String getModifiedBy() {
	return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
	this.modifiedBy = modifiedBy;
    }

    public String getModifiedDate() {
	return modifiedDate;
    }

    public void setModifiedDate(String modifiedDate) {
	this.modifiedDate = modifiedDate;
    }

    public String getVersion() {
	return version;
    }

    public void setVersion(String version) {
	this.version = version;
    }

    public List<EquipmentPumpDTO> getEquipmentPumpList() {
	return equipmentPumpList;
    }

    public void setEquipmentPumpList(List<EquipmentPumpDTO> equipmentPumpList) {
	this.equipmentPumpList = equipmentPumpList;
    }

    public List<EquipmentFormulaDTO> getEquipmentFormulaList() {
	return equipmentFormulaList;
    }

    public void setEquipmentFormulaList(List<EquipmentFormulaDTO> equipmentFormulaList) {
	this.equipmentFormulaList = equipmentFormulaList;
    }

    public List<EquipmentPumpMachinery> getEquipmentPumpMachineriesList() {
	return equipmentPumpMachineriesList;
    }

    public void setEquipmentPumpMachineriesList(List<EquipmentPumpMachinery> equipmentPumpMachineriesList) {
	this.equipmentPumpMachineriesList = equipmentPumpMachineriesList;
    }

    public List<WaterDTO> getWaterList() {
	return waterList;
    }

    public void setWaterList(List<WaterDTO> waterList) {
	this.waterList = waterList;
    }

    public List<EquipmentTunnelChannel> getEquipmentTunnelChannelsList() {
	return equipmentTunnelChannelsList;
    }

    public void setEquipmentTunnelChannelsList(List<EquipmentTunnelChannel> equipmentTunnelChannelsList) {
	this.equipmentTunnelChannelsList = equipmentTunnelChannelsList;
    }

    public List<ProductDTO> getProductList() {
	return productList;
    }

    public void setProductList(List<ProductDTO> productList) {
	this.productList = productList;
    }

    public List<TunnelDTO> getTunnelList() {
	return tunnelList;
    }

    public void setTunnelList(List<TunnelDTO> tunnelList) {
	this.tunnelList = tunnelList;
    }

    public List<ObservationDTO> getObservationList() {
	return observationList;
    }

    public void setObservationList(List<ObservationDTO> observationList) {
	this.observationList = observationList;
    }

    public List<FormulaMetaDataDTO> getFormulaList() {
	return formulaList;
    }

    public void setFormulaList(List<FormulaMetaDataDTO> formulaList) {
	this.formulaList = formulaList;
    }

    public List<WasherMetaDataDTO> getWasherList() {
	return washerList;
    }

    public void setWasherList(List<WasherMetaDataDTO> washerList) {
	this.washerList = washerList;
    }

    public String getSiteName() {
	return siteName;
    }

    public void setSiteName(String siteName) {
	this.siteName = siteName;
    }

    public int getProductCount() {
	return productCount;
    }

    public void setProductCount(int productCount) {
	this.productCount = productCount;
    }

    public int getFormulaCount() {
	return formulaCount;
    }

    public void setFormulaCount(int formulaCount) {
	this.formulaCount = formulaCount;
    }

    public int getWasherCount() {
	return washerCount;
    }

    public void setWasherCount(int washerCount) {
	this.washerCount = washerCount;
    }

    public int getTunnelCount() {
	return tunnelCount;
    }

    public void setTunnelCount(int tunnelCount) {
	this.tunnelCount = tunnelCount;
    }

    public int getPumpCount() {
	return pumpCount;
    }

    public void setPumpCount(int pumpCount) {
	this.pumpCount = pumpCount;
    }

    public int getChannelCount() {
	return channelCount;
    }

    public void setChannelCount(int channelCount) {
	this.channelCount = channelCount;
    }

    public String getFileId() {
	return fileId;
    }

    public void setFileId(String fileId) {
	this.fileId = fileId;
    }

    public Map<String, String> getProductMap() {
	return productMap;
    }

    public void setProductMap(Map<String, String> productMap) {
	this.productMap = productMap;
    }

}
