package com.hydro.api.config;

public class UnitMaster {

	private int w_machine_chnl_count;//3
	private int version; //1
	private int lm2_seq;//1
	private int equipment_type;//1,
	private String alias; //"5",
	private String equipment_id;
	private String ip_address;
	private int washer_count;//2
	
	public int getW_machine_chnl_count() {
		return w_machine_chnl_count;
	}
	public void setW_machine_chnl_count(int w_machine_chnl_count) {
		this.w_machine_chnl_count = w_machine_chnl_count;
	}
	public int getVersion() {
		return version;
	}
	public void setVersion(int version) {
		this.version = version;
	}
	public int getLm2_seq() {
		return lm2_seq;
	}
	public void setLm2_seq(int lm2_seq) {
		this.lm2_seq = lm2_seq;
	}
	public int getEquipment_type() {
		return equipment_type;
	}
	public void setEquipment_type(int equipment_type) {
		this.equipment_type = equipment_type;
	}
	public String getAlias() {
		return alias;
	}
	public void setAlias(String alias) {
		this.alias = alias;
	}
	public String getEquipment_id() {
		return equipment_id;
	}
	public void setEquipment_id(String equipment_id) {
		this.equipment_id = equipment_id;
	}
	public String getIp_address() {
		return ip_address;
	}
	public void setIp_address(String ip_address) {
		this.ip_address = ip_address;
	}
	public int getWasher_count() {
		return washer_count;
	}
	public void setWasher_count(int washer_count) {
		this.washer_count = washer_count;
	}
	
	
	
}
