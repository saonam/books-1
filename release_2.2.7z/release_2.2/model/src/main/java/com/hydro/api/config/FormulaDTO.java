package com.hydro.api.config;

import java.util.List;

public class FormulaDTO {
    public static final String FORMULA_ID = "formula_id";
    public static final String ID = "id";
    public static final String NAME = "name";
    public static final String PERCENTAGE = "percentage";
    public static final String DATE_LAST_CHANGE = "date_last_change";
    public static final String USED_PHASES = "used_phases";
    public static final String STATISTIC_PRODUCTION = "statistic_production";
    public static final String UID = "uid";
    public static final String UPDATED = "updated";
    public static final String FORMULAS_PHASES = "formulas_phases";
    public static final ConfigExtractionRule  formulaFetchRule;
    static {
	formulaFetchRule = new ConfigExtractionRule();
	formulaFetchRule.setExcluded("equipment_id", "created_by", "created_date",  "modified_by", "modified_date");
	formulaFetchRule.setNameToAlias(new String[][] {{"lm2_seq","id"}});
    }
    private String formula_id;
    private String id;
    private String name;
    private String percentage;
    private String date_last_change;
    private String used_phases;
    private String statistic_production;
    private String uid;
    private String updated;
    private List<FormulaPhaseDTO> formulas_phases;

    public String getFormula_id() {
        return formula_id;
    }

    public void setFormula_id(String formula_id) {
        this.formula_id = formula_id;
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getPercentage() {
	return percentage;
    }

    public void setPercentage(String percentage) {
	this.percentage = percentage;
    }

    public String getDate_last_change() {
	return date_last_change;
    }

    public void setDate_last_change(String date_last_change) {
	this.date_last_change = date_last_change;
    }

    public String getUsed_phases() {
	return used_phases;
    }

    public void setUsed_phases(String used_phases) {
	this.used_phases = used_phases;
    }

    public String getStatistic_production() {
	return statistic_production;
    }

    public void setStatistic_production(String statistic_production) {
	this.statistic_production = statistic_production;
    }

    public String getUid() {
	return uid;
    }

    public void setUid(String uid) {
	this.uid = uid;
    }

    public String getUpdated() {
	return updated;
    }

    public void setUpdated(String updated) {
	this.updated = updated;
    }

    public List<FormulaPhaseDTO> getFormulas_phases() {
	return formulas_phases;
    }

    public void setFormulas_phases(List<FormulaPhaseDTO> formulas_phases) {
	this.formulas_phases = formulas_phases;
    }

}
