package com.hydro.api.config;

import java.io.Serializable;

public class ProductMaster implements  Serializable {

	private static final long serialVersionUID = 1L;
	
	private int alarms_ignored;//1,
	private String  kf; // "0.06211",
	private long concentration; // 100,
	private long density;// 1000
	private String flow;//"130.40"
	private int lm2_seq;
	private int priority;//6
	private String uid;
	private String price;//"1.0000",
	private String name;
	private int docification_mode; //2
	public int getAlarms_ignored() {
		return alarms_ignored;
	}
	public void setAlarms_ignored(int alarms_ignored) {
		this.alarms_ignored = alarms_ignored;
	}
	public String getKf() {
		return kf;
	}
	public void setKf(String kf) {
		this.kf = kf;
	}
	public long getConcentration() {
		return concentration;
	}
	public void setConcentration(long concentration) {
		this.concentration = concentration;
	}
	public long getDensity() {
		return density;
	}
	public void setDensity(long density) {
		this.density = density;
	}
	public String getFlow() {
		return flow;
	}
	public void setFlow(String flow) {
		this.flow = flow;
	}
	public int getLm2_seq() {
		return lm2_seq;
	}
	public void setLm2_seq(int lm2_seq) {
		this.lm2_seq = lm2_seq;
	}
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getDocification_mode() {
		return docification_mode;
	}
	public void setDocification_mode(int docification_mode) {
		this.docification_mode = docification_mode;
	}
	
	

}
