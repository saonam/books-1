/**
 * 
 */
package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */
public class FileHistoryListResponseDTO {
    private List<FileHistoryDTO> fileHistoryList;

    /**
     * @return the fileHistoryList
     */
    public List<FileHistoryDTO> getFileHistoryList() {
        return fileHistoryList;
    }

    /**
     * @param fileHistoryList the fileHistoryList to set
     */
    public void setFileHistoryList(List<FileHistoryDTO> fileHistoryList) {
        this.fileHistoryList = fileHistoryList;
    }

}
