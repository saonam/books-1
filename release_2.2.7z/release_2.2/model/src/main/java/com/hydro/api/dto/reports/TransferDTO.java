package com.hydro.api.dto.reports;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class TransferDTO implements Cloneable {
    private Integer transferNo;
    private Date startTime;
    private Date endTime;
    private Map<Integer, ModuleDTO> moduleMap;
    private List<EventsDTO> eventList;

    public Date getStartTime() {
	return startTime;
    }

    public void setStartTime(Date startTime) {
	this.startTime = startTime;
    }

    public Date getEndTime() {
	return endTime;
    }

    public void setEndTime(Date endTime) {
	this.endTime = endTime;
    }

    public Integer getTransferNo() {
	return transferNo;
    }

    public void setTransferNo(Integer transferNo) {
	this.transferNo = transferNo;
    }

//    public TransferDTO(TransferDTO transferDTO) {
//	this.transferNo = transferDTO.transferNo;
//	this.startTime = transferDTO.startTime;
//	this.endTime = transferDTO.endTime;
//    }
//
    @Override
    public Object clone() throws CloneNotSupportedException {
	TransferDTO transferDTO = (TransferDTO) super.clone();
	return transferDTO;
    }

    public Map<Integer, ModuleDTO> getModuleMap() {
	return moduleMap;
    }

    public void setModuleMap(Map<Integer, ModuleDTO> moduleMap) {
	this.moduleMap = moduleMap;
    }

    public List<EventsDTO> getEventList() {
	return eventList;
    }

    public void setEventList(List<EventsDTO> eventList) {
	this.eventList = eventList;
    }
}
