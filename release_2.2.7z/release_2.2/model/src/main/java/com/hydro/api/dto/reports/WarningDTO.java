/**
 * 
 */
package com.hydro.api.dto.reports;

import java.util.HashMap;

/**
 * @author Shreyas K C
 *
 */
public class WarningDTO {
    private HashMap<String, String> dateTime;
    private HashMap<String, String> process;
    private HashMap<String, String> formulaId;
    private HashMap<String, String> formulaName;
    private HashMap<String, String> productName;
    private HashMap<String, String> productId;
    private HashMap<String, String> estimatedChemical;
    private HashMap<String, String> actualChemical;
    private HashMap<String, String> estimatedTime;
    private HashMap<String, String> actualTime;
    private HashMap<String, String> phase;

    public HashMap<String, String> getDateTime() {
	return dateTime;
    }

    public void setDateTime(HashMap<String, String> dateTime) {
	this.dateTime = dateTime;
    }

    public HashMap<String, String> getProcess() {
	return process;
    }

    public void setProcess(HashMap<String, String> process) {
	this.process = process;
    }

    public HashMap<String, String> getFormulaId() {
	return formulaId;
    }

    public void setFormulaId(HashMap<String, String> formulaId) {
	this.formulaId = formulaId;
    }

    public HashMap<String, String> getFormulaName() {
	return formulaName;
    }

    public void setFormulaName(HashMap<String, String> formulaName) {
	this.formulaName = formulaName;
    }

    public HashMap<String, String> getProductName() {
	return productName;
    }

    public void setProductName(HashMap<String, String> productName) {
	this.productName = productName;
    }

    public HashMap<String, String> getProductId() {
	return productId;
    }

    public void setProductId(HashMap<String, String> productId) {
	this.productId = productId;
    }

    public HashMap<String, String> getEstimatedChemical() {
	return estimatedChemical;
    }

    public void setEstimatedChemical(HashMap<String, String> estimatedChemical) {
	this.estimatedChemical = estimatedChemical;
    }

    public HashMap<String, String> getActualChemical() {
	return actualChemical;
    }

    public void setActualChemical(HashMap<String, String> actualChemical) {
	this.actualChemical = actualChemical;
    }

    public HashMap<String, String> getEstimatedTime() {
	return estimatedTime;
    }

    public void setEstimatedTime(HashMap<String, String> estimatedTime) {
	this.estimatedTime = estimatedTime;
    }

    public HashMap<String, String> getActualTime() {
	return actualTime;
    }

    public void setActualTime(HashMap<String, String> actualTime) {
	this.actualTime = actualTime;
    }

    public HashMap<String, String> getPhase() {
	return phase;
    }

    public void setPhase(HashMap<String, String> phase) {
	this.phase = phase;
    }

}
