package com.hydro.api.config;

import java.util.List;

public class FormulaPhaseDTO {
    public static final String F_PHASE_ID = "f_phase_id";
    public static final String ID = "id";
    public static final String ID_FORMULA = "id_formula";
    public static final String NUM_PHASE = "num_phase";
    public static final String DELAY_1 = "delay_1";
    public static final String DELAY_2 = "delay_2";
    public static final String UID = "uid";
    public static final String PRODUCTS = "products";
    public static final ConfigExtractionRule  phaseFetchRule;
    static {
	phaseFetchRule = new ConfigExtractionRule();
	phaseFetchRule.setExcluded("equipment_id");
    }
    private String f_phase_id;
    private String id;
    private String id_formula;
    private String num_phase;
    private String delay_1;
    private String delay_2;
    private String uid;
    private List<FormulaProductDTO> products;

    public String getF_phase_id() {
        return f_phase_id;
    }

    public void setF_phase_id(String f_phase_id) {
        this.f_phase_id = f_phase_id;
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getId_formula() {
	return id_formula;
    }

    public void setId_formula(String id_formula) {
	this.id_formula = id_formula;
    }

    public String getNum_phase() {
	return num_phase;
    }

    public void setNum_phase(String num_phase) {
	this.num_phase = num_phase;
    }

    public String getDelay_1() {
	return delay_1;
    }

    public void setDelay_1(String delay_1) {
	this.delay_1 = delay_1;
    }

    public String getDelay_2() {
	return delay_2;
    }

    public void setDelay_2(String delay_2) {
	this.delay_2 = delay_2;
    }

    public String getUid() {
	return uid;
    }

    public void setUid(String uid) {
	this.uid = uid;
    }

    public List<FormulaProductDTO> getProducts() {
	return products;
    }

    public void setProducts(List<FormulaProductDTO> products) {
	this.products = products;
    }

}
