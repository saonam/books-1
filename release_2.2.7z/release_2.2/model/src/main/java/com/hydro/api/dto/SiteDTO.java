/**
 * 
 */
package com.hydro.api.dto;

import java.util.List;

/**
 * @author Srishti Tiwari
 *
 */
public class SiteDTO {
    private String siteId;
    private String siteName;
    private String address1;
    private String address2;
    private String state;
    private String country;
    private String city;
    private String zipCode;
    private String accountId;
    private String accountName;
    private String companyName;
    private String createdBy;
    private String companyId;
    private String description;
    private ContactOperationsDTO contactOperations;
    private List<ContactDTO> contactList;
    private String siteUniqueId;
    private String metricUnit;
    private List<ShiftDTO> shiftList;
    private Integer washerTurnMinute;
    private Integer washerIdleMinute;
    private Double washerEffThreshold;
    private Integer tunnelTurnMinute;
    private Integer tunnelIdleMinute;
    private Double tunnelEffThreshold;
    private boolean defaultShift;
    private String timeZone;
    private String alertSetting;
    private String createdDateStart;
    private String createdDateEnd;
    private String createdDate;
    private boolean streamingEnabled;
    private boolean isHydroUser;
    private boolean sortByName;
    private List<String> companyIds;

    public Integer getWasherTurnMinute() {
	return washerTurnMinute;
    }

    public void setWasherTurnMinute(Integer washerTurnMinute) {
	this.washerTurnMinute = washerTurnMinute;
    }

    public Integer getWasherIdleMinute() {
	return washerIdleMinute;
    }

    public void setWasherIdleMinute(Integer washerIdleMinute) {
	this.washerIdleMinute = washerIdleMinute;
    }

    public Double getWasherEffThreshold() {
	return washerEffThreshold;
    }

    public void setWasherEffThreshold(Double washerEffThreshold) {
	this.washerEffThreshold = washerEffThreshold;
    }

    public Integer getTunnelTurnMinute() {
	return tunnelTurnMinute;
    }

    public void setTunnelTurnMinute(Integer tunnelTurnMinute) {
	this.tunnelTurnMinute = tunnelTurnMinute;
    }

    public Integer getTunnelIdleMinute() {
	return tunnelIdleMinute;
    }

    public void setTunnelIdleMinute(Integer tunnelIdleMinute) {
	this.tunnelIdleMinute = tunnelIdleMinute;
    }

    public Double getTunnelEffThreshold() {
	return tunnelEffThreshold;
    }

    public void setTunnelEffThreshold(Double tunnelEffThreshold) {
	this.tunnelEffThreshold = tunnelEffThreshold;
    }

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getSiteName() {
	return siteName;
    }

    public void setSiteName(String siteName) {
	this.siteName = siteName;
    }

    public String getState() {
	return state;
    }

    public void setState(String state) {
	this.state = state;
    }

    public String getZipCode() {
	return zipCode;
    }

    public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
    }

    public String getCity() {
	return city;
    }

    public void setCity(String city) {
	this.city = city;
    }

    public String getAccountId() {
	return accountId;
    }

    public void setAccountId(String accountId) {
	this.accountId = accountId;
    }

    public String getAccountName() {
	return accountName;
    }

    public void setAccountName(String accountName) {
	this.accountName = accountName;
    }

    public String getAddress1() {
	return address1;
    }

    public void setAddress1(String address1) {
	this.address1 = address1;
    }

    public String getAddress2() {
	return address2;
    }

    public void setAddress2(String address2) {
	this.address2 = address2;
    }

    public String getDescription() {
	return description;
    }

    public void setDescription(String description) {
	this.description = description;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public String getCompanyName() {
	return companyName;
    }

    public void setCompanyName(String companyName) {
	this.companyName = companyName;
    }

    /**
     * @return the contactDetails
     */
    public ContactOperationsDTO getContactOperations() {
	return contactOperations;
    }

    /**
     * @param contactDetails the contactDetails to set
     */
    public void setContactOperations(ContactOperationsDTO contactDetails) {
	this.contactOperations = contactDetails;
    }

    /**
     * @return the contactList
     */
    public List<ContactDTO> getContactList() {
	return contactList;
    }

    /**
     * @param contactList the contactList to set
     */
    public void setContactList(List<ContactDTO> contactList) {
	this.contactList = contactList;
    }

    public String getCreatedBy() {
	return createdBy;
    }

    public void setCreatedBy(String createdBy) {
	this.createdBy = createdBy;
    }

    public String getSiteUniqueId() {
	return siteUniqueId;
    }

    public void setSiteUniqueId(String siteUniqueId) {
	this.siteUniqueId = siteUniqueId;
    }

    public String getMetricUnit() {
	return metricUnit;
    }

    public void setMetricUnit(String metricUnit) {
	this.metricUnit = metricUnit;
    }

    public String getCompanyId() {
	return companyId;
    }

    public void setCompanyId(String associationId) {
	this.companyId = associationId;
    }

    public boolean equals(SiteDTO obj) {
	if (obj != null && obj.siteId.equalsIgnoreCase(this.siteId)) {
	    return true;
	}
	return false;
    }

    public List<ShiftDTO> getShiftList() {
	return shiftList;
    }

    public void setShiftList(List<ShiftDTO> shiftList) {
	this.shiftList = shiftList;
    }

    public boolean getDefaultShift() {
	return defaultShift;
    }

    public void setDefaultShift(boolean defaultShift) {
	this.defaultShift = defaultShift;
    }

    public String getTimeZone() {
	return timeZone;
    }

    public void setTimeZone(String timeZone) {
	this.timeZone = timeZone;
    }

    public String getAlertSetting() {
	return alertSetting;
    }

    public void setAlertSetting(String alertSetting) {
	this.alertSetting = alertSetting;
    }

    public String getCreatedDateStart() {
	return createdDateStart;
    }

    public void setCreatedDateStart(String createdDateStart) {
	this.createdDateStart = createdDateStart;
    }

    public String getCreatedDateEnd() {
	return createdDateEnd;
    }

    public void setCreatedDateEnd(String createdDateEnd) {
	this.createdDateEnd = createdDateEnd;
    }

    public String getCreatedDate() {
	return createdDate;
    }

    public void setCreatedDate(String createdDate) {
	this.createdDate = createdDate;
    }

    public boolean isStreamingEnabled() {
	return streamingEnabled;
    }

    public void setStreamingEnabled(boolean streamingEnabled) {
	this.streamingEnabled = streamingEnabled;
    }

    public boolean isHydroUser() {
	return isHydroUser;
    }

    public void setHydroUser(boolean isHydroUser) {
	this.isHydroUser = isHydroUser;
    }

    public boolean isSortByName() {
	return sortByName;
    }

    public void setSortByName(boolean sortByName) {
	this.sortByName = sortByName;
    }

    public List<String> getCompanyIds() {
	return companyIds;
    }

    public void setCompanyIds(List<String> companyIds) {
	this.companyIds = companyIds;
    }

    public SiteDTO() {
    }

    public SiteDTO(boolean sortByName, boolean isHydroUser, String createdDateEnd, String createdDateStart) {
	this.sortByName = sortByName;
	this.isHydroUser = isHydroUser;
	this.createdDateEnd = createdDateEnd;
	this.createdDateStart = createdDateStart;
    }

}
