/**
 * 
 */
package com.hydro.api.dto.reports;

import java.util.List;

/**
 * @author Shreyas K C
 *
 */
public class ChemicalDTO {
    private String name;
    private String id;
    private String lm2Seq;
    private Double totalEstimatedUsage;
    private Double totalActualUsage;
    private Double totalErrorUsage;
    private List<FormulaDTO> formulaList;

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public Double getTotalEstimatedUsage() {
	return totalEstimatedUsage;
    }

    public void setTotalEstimatedUsage(Double totalEstimatedUsage) {
	this.totalEstimatedUsage = totalEstimatedUsage;
    }

    public Double getTotalActualUsage() {
	return totalActualUsage;
    }

    public void setTotalActualUsage(Double totalActualUsage) {
	this.totalActualUsage = totalActualUsage;
    }

    public Double getTotalErrorUsage() {
	return totalErrorUsage;
    }

    public void setTotalErrorUsage(Double totalErrorUsage) {
	this.totalErrorUsage = totalErrorUsage;
    }

    public List<FormulaDTO> getFormulaList() {
	return formulaList;
    }

    public void setFormulaList(List<FormulaDTO> formulaList) {
	this.formulaList = formulaList;
    }

    public String getLm2Seq() {
        return lm2Seq;
    }

    public void setLm2Seq(String lm2Seq) {
        this.lm2Seq = lm2Seq;
    }

    
    
    
}
