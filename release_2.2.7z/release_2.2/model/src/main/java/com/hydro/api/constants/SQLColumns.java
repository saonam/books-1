package com.hydro.api.constants;

/**
 * Class holding the Database keys names.
 * 
 * @author Shreyas, Srishti
 *
 */
public interface SQLColumns {
    String USER_ID = "user_id";
    String FIRST_NAME = "first_name";
    String MIDDLE_NAME = "middle_name";
    String LAST_NAME = "last_name";
    String USER_NAME = "user_name";
    String PROFILE_IMAGE = "profile_image";
    String EMAIL = "email";
    String CREATED_BY = "created_by";
    String BUSINESS_ID = "business_id";
    String NAME = "name";
    String STATE = "state";
    String COUNTRY = "country";
    String ZIPCODE = "zipcode";
    String CITY = "city";
    String ADDRESS1 = "address1";
    String ADDRESS2 = "address2";
    String DESCRIPTION = "description";
    String CONTACT_TITLE = "title";
    String CONTACT_NAME = "name";
    String CONTACT_NUMBER = "number";
    String CONTACT_EMAIL = "email";
    String SITE_ID = "site_id";
    String SITE_OWNER = "site_owner";
    String METRIC_UNIT = "metric_unit";
    String SITE_NAME = "site_name";
    String SITE_COUNT = "SITE_COUNT";
    String ACCOUNT_NAME = "ACCOUNT_NAME";
    String COMPANY_NAME = "COMPANY_NAME";
    String PHONE_NUMBER = "phone_number";
    String USER_ROLE = "user_role";
    String IS_ACTIVE = "is_active";
    String ORG_TYPE = "org_type";
    String CREATED_DATE = "created_date";
    String CONTACT_ID = "contact_id";
    String ROLE_ID = "role_id";
    String LM2_UPLOAD_COUNT = "lm2_upload_count";

    String EQUIPMENT_ID = "equipment_id";
    String LM2_SEQ = "lm2_seq";
    String ALIAS = "alias";
    String EQUIPMENT_TYPE = "equipment_type";

    String WASHER_ID = "washer_id";
    String TUNNEL_ID = "tunnel_id";
    String LOAD = "load";
    String FILE_ID = "FILE_ID";
    String STATUS = "status";
    String FORMULA_ID = "formula_id";
    String PRODUCT_ID = "product_id";
    String OBSERVATION_ID = "observation_id";
    String OBSERVATION = "observation";
    String RECOMMENDATION = "recommendation";

    String MODIFIED_BY = "modified_by";
    String MODIFIED_DATE = "modified_date";

    String ERROR_ID = "error_id";
    String ERROR_TYPE = "error_type";
    String ES_ERROR = "es_error";
    String INDEX_NAME = "index_name";
    String ES_DOCUMENT = "es_document";
    String VERSION = "version";
    String ES_TYPE = "es_type";
    String CONCENTRATION = "concentration";
    String FORMAT = "FORMAT";
    String CHANNEL_COUNT = "channel_count";
    String FILE_TYPE = "file_type";
    String CLEARENCE_LEVEL = "clearance_level";
    String PRIVILEGE_NAME = "privilege_name";
    String COMPANY_ID = "COMPANY_ID";

    String SHIFT_ID = "shift_id";
    String SHIFT_NAME = "shift_name";
    String START_TIME = "start_time";
    String END_TIME = "end_time";
    String WASHER_IDLE_MINUTE = "washer_idle_minute";
    String WASHER_TURN_MINUTE = "washer_turn_minute";
    String WASHER_EFFICIENCY_THRESHOLD = "washer_efficiency_threshold";
    String TUNNEL_IDLE_MINUTE = "tunnel_idle_minute";
    String TUNNEL_TURN_MINUTE = "tunnel_turn_minute";
    String TUNNEL_EFFICIENCY_THRESHOLD = "tunnel_efficiency_threshold";
    String TIME_ZONE = "time_zone";
    String ALERT_SETTING = "alert_setting";
    String TUNNEL_NAME = "name";

    String ALARM_ID = "alarm_id";
    String ALARM_NAME = "alarm_name";

    String SMS = "sms";
    String THRESHOLD = "threshold";
    String THRESHOLD_REFRESH_VALUE = "threshold_refresh_interval";
    String ALARM_COUNTER = "alarm_counter";
    String ALARM_FIRST_DATE_TIME = "alarm_first_date_time";
    String PREFERENCE_ID = "id";
    String ACTIVE = "active";
    String ID = "id";
    String ALARM_TYPE = "alarm_type";
    String PREDEFINED_ALARM_THRESHOLD = "predefined_alarm_threshold";

    String COUNT = "count";
    String GROUPED_SITE_ID = "grouped_site_id";
    String MACHINE_COUNTER = "machine_counter";
    String DEVICE_ID = "device_id";
    String MODULE_COUNT = "modules_count";
    String MODULE_ID = "module_id";
    String STREAMING_ENABLED = "streaming_enabled";
    String CONFIG_UPLOAD_COUNT = "config_upload_count";
    String IP_ADDRESS = "ip_address";
    String PRICE = "price";
}
