package com.hydro.api.dto.reports;

import java.util.Date;
import java.util.Map;

public class DailyReportFormulaDTO {
    private String formulaName;
    private Map<Integer, PhaseDTO> phaseMap;
    private Integer noOfOccurences;
    private Integer formulaId;
    private Date startTime;
    private Date stopTime;
    private Double totalCost;
    private Integer totalPhases;
    private Integer poundsRun;
    private Map<Integer, CycleDTO> cycleHashMap;

    public Integer getNoOfOccurences() {
	return noOfOccurences;
    }

    public void setNoOfOccurences(Integer noOfOccurences) {
	this.noOfOccurences = noOfOccurences;
    }

    public String getFormulaName() {
	return formulaName;
    }

    public void setFormulaName(String formulaName) {
	this.formulaName = formulaName;
    }

    public Integer getFormulaId() {
	return formulaId;
    }

    public void setFormulaId(Integer formulaId) {
	this.formulaId = formulaId;
    }

    public Date getStartTime() {
	return startTime;
    }

    public void setStartTime(Date startTime) {
	this.startTime = startTime;
    }

    public Date getStopTime() {
	return stopTime;
    }

    public void setStopTime(Date stopTime) {
	this.stopTime = stopTime;
    }

    public Integer getTotalPhases() {
	return totalPhases;
    }

    public void setTotalPhases(Integer totalPhases) {
	this.totalPhases = totalPhases;
    }

    public Map<Integer, PhaseDTO> getPhaseMap() {
	return phaseMap;
    }

    public void setPhaseMap(Map<Integer, PhaseDTO> phaseMap) {
	this.phaseMap = phaseMap;
    }

    public Map<Integer, CycleDTO> getCycleHashMap() {
	return cycleHashMap;
    }

    public void setCycleHashMap(Map<Integer, CycleDTO> cycleHashMap) {
	this.cycleHashMap = cycleHashMap;
    }

    public Double getTotalCost() {
	return totalCost;
    }

    public void setTotalCost(Double totalCost) {
	this.totalCost = totalCost;
    }

    public Integer getPoundsRun() {
	return poundsRun;
    }

    public void setPoundsRun(Integer poundsRun) {
	this.poundsRun = poundsRun;
    }
}
