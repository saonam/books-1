/**
 * 
 */
package com.hydro.api.dto.reports;

import java.util.List;

import com.hydro.api.dto.SiteDTO;

/**
 * @author Shreyas K C
 *
 */
public class AlarmSummaryDTO {

    private String siteId;
    private String unitId;
    private int month;
    private int year;
    private List<AlarmDTO> alarmList;
    private String maxDate;
    private String minDate;
    private SiteDTO siteDTO;

    public String getSiteId() {
	return siteId;
    }

    public void setSiteId(String siteId) {
	this.siteId = siteId;
    }

    public String getUnitId() {
	return unitId;
    }

    public void setUnitId(String unitId) {
	this.unitId = unitId;
    }

    public int getMonth() {
	return month;
    }

    public void setMonth(int month) {
	this.month = month;
    }

    public int getYear() {
	return year;
    }

    public void setYear(int year) {
	this.year = year;
    }

    public List<AlarmDTO> getAlarmList() {
	return alarmList;
    }

    public void setAlarmList(List<AlarmDTO> alarmList) {
	this.alarmList = alarmList;
    }

    public String getMaxDate() {
	return maxDate;
    }

    public void setMaxDate(String maxDate) {
	this.maxDate = maxDate;
    }

    public String getMinDate() {
	return minDate;
    }

    public void setMinDate(String minDate) {
	this.minDate = minDate;
    }

    public SiteDTO getSiteDTO() {
	return siteDTO;
    }

    public void setSiteDTO(SiteDTO siteDTO) {
	this.siteDTO = siteDTO;
    }
}
