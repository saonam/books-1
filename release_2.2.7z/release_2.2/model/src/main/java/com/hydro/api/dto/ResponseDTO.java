package com.hydro.api.dto;

import com.hydro.api.constants.ErrorCodes;

/**
 * Response object sent back to the client in the form of JSON string after
 * serializing (or de serializing)the data.
 * 
 * @author Shreyas
 *
 */
public class ResponseDTO {
    private Object responseObject;
    private ResponseStatusDTO status;

    /**
     * Default constructor.
     */
    public ResponseDTO() {
	super();
	status = new ResponseStatusDTO();
    }

    /**
     * Parameterized constructor receiving the response status as the argument.
     * 
     * @param responseStatus
     */
    public ResponseDTO(boolean responseStatus) {
	super();
	status = new ResponseStatusDTO();
	if (responseStatus) {
	    this.status.setResponseStatus(ErrorCodes.StatusCodes.SUCCESS);
	} else {
	    this.status.setResponseStatus(ErrorCodes.StatusCodes.FAILURE);
	}
    }

    public ResponseDTO(String responseStatus) {
	super();
	status = new ResponseStatusDTO();
	this.status.setResponseStatus(responseStatus);
    }

    /**
     * Parameterized constructor receiving the response status and response
     * object as the argument.
     * 
     * @param responseObj
     * @param responseStatus
     */
    // public ResponseDTO(String message, boolean responseStatus) {
    // this(responseStatus);
    // this.message = message;
    //
    // }

    /**
     * Method to get the response object.
     * 
     * @return the responseObj
     */
    // public String getMessage() {
    // return message;
    // }

    /**
     * Method to set the response object.
     * 
     * @param responseObj
     *            the responseObj to set
     */
    // public void setMessage(String message) {
    // this.message = message;
    // }

    /**
     * Method to get the response status.
     * 
     * @return the responseStatus
     */
    public ResponseStatusDTO getResponseStatus() {
	return this.status;
    }

    /**
     * Method to set the response status.
     * 
     * @param responseStatus
     *            the responseStatus to set
     */
    public void setResponseStatus(String responseStatus) {
	this.status.setResponseStatus(responseStatus);
    }

    /**
     * Overridden method for boolean true false for success and failure.
     * 
     * @param responseStatus
     */
    public void setResponseStatus(boolean responseStatus) {
	if (responseStatus) {
	    this.status.setResponseStatus(ErrorCodes.StatusCodes.SUCCESS);
	} else {
	    this.status.setResponseStatus(ErrorCodes.StatusCodes.FAILURE);
	}
    }

    public Object getResponseObject() {
	return responseObject;
    }

    public void setResponseObject(Object responseObject) {
	this.responseObject = responseObject;
    }
}
