package com.hydro.api.dto;

/**
 * @author suganya
 *
 */
public class FileMetaDataDTO {
	private long chunkIndex;
	private String contentType;
	private String fileName;
	private long totalFileSize;
	private long totalChunks;
	private String uploadUid;
	public long getChunkIndex() {
		return chunkIndex;
	}
	public void setChunkIndex(long chunkIndex) {
		this.chunkIndex = chunkIndex;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public long getTotalFileSize() {
		return totalFileSize;
	}
	public void setTotalFileSize(long totalFileSize) {
		this.totalFileSize = totalFileSize;
	}
	public long getTotalChunks() {
		return totalChunks;
	}
	public void setTotalChunks(long totalChunks) {
		this.totalChunks = totalChunks;
	}
	public String getUploadUid() {
		return uploadUid;
	}
	public void setUploadUid(String uploadUid) {
		this.uploadUid = uploadUid;
	}
}
