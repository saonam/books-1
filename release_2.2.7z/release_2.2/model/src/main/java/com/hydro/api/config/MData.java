package com.hydro.api.config;

import java.io.Serializable;

public class MData implements  Serializable {

	private static final long serialVersionUID = 1L;
	
	private String date_last_scan;
	private String serialNumber;
	
	
	public String getDate_last_scan() {
		return date_last_scan;
	}
	public void setDate_last_scan(String date_last_scan) {
		this.date_last_scan = date_last_scan;
	}
	
	
	public String getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(String serialNumber) {
		this.serialNumber = serialNumber;
	}
	
	
	

}
