package com.hydro.api.config;

public class LaundryDTO {
    public static final String ID = "site_id";
    public static final String NAME = "site_name";
    public static final String ADDRESS1 = "address1";
    public static final String ADDRESS2 = "address2";
    public static final String ZIP_CODE = "zipcode";
    public static final String TOWN = "city";
    public static final String COUNTRY = "country";
    public static final String EMAIL = "email";
    public static final String DATE_LAST_CHANGE = "date_last_change";
    public static final String UID = "uid";
    public static final String CHECKSUM = "checksum";
    public static final ConfigExtractionRule  fetchRule; // = new ConfigExtractionRule();
    static {
	fetchRule = new ConfigExtractionRule();
	fetchRule.setIncluded("site_id", "site_name", "latitude", "longitude",  "address1", "address2", "zipcode", "city", "country", "email", "date_last_change", "uid", "checksum");
	fetchRule.setNameToAlias(new String[][] {{"site_id","id"}, {"site_name", "name"}, {"city", "town"}});
    }
    
    private String id;
    private String name;
    private String address;
    private String zip_code;
    private String town;
    private String region;
    private String country;
    private String email;
    private String ip_url;
    private String date_last_change;
    private String uid;
    private String checksum;

    public String getId() {
	return id;
    }

    public void setId(String id) {
	this.id = id;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getAddress() {
	return address;
    }

    public void setAddress(String address) {
	this.address = address;
    }

    public String getZip_code() {
	return zip_code;
    }

    public void setZip_code(String zip_code) {
	this.zip_code = zip_code;
    }

    public String getTown() {
	return town;
    }

    public void setTown(String town) {
	this.town = town;
    }

    public String getRegion() {
	return region;
    }

    public void setRegion(String region) {
	this.region = region;
    }

    public String getCountry() {
	return country;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getIp_url() {
	return ip_url;
    }

    public void setIp_url(String ip_url) {
	this.ip_url = ip_url;
    }

    public String getDate_last_change() {
	return date_last_change;
    }

    public void setDate_last_change(String date_last_change) {
	this.date_last_change = date_last_change;
    }

    public String getUid() {
	return uid;
    }

    public void setUid(String uid) {
	this.uid = uid;
    }

    public String getChecksum() {
	return checksum;
    }

    public void setChecksum(String checksum) {
	this.checksum = checksum;
    }
    
    public static interface Constants {
    }

}
