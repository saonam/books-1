package com.hydro.api.constants;

/**
 * Error codes class holding Error codes sent as part of the exception thrown to
 * the UI.
 * 
 * @author Shreyas
 *
 */
public interface ErrorCodes {

    String GENERIC_EXCEPTION = "10001";
    String INVALID_TOKEN = "10002";
    String INVALID_ORG_TYPE = "10003";
    String INVALID_USER_ROLE = "10004";
    String INVALID_REQUEST_FORMAT = "10005";
    String RESOURCE_NOT_ACCESSIBLE = "10006";
    String RESOURCE_NOT_AVAILABLE = "10007";
    String INSUFFICIENT_INFORMATION = "10008";
    String INSUFFICIENT_PRIVILEGES = "10009";
    String NAME_EXISTS = "10010";
    String INVALID_SITE_IN_LIST = "10011";
    String INVALID_ACCOUNT_ID = "10012";
    String INVALID_COMPANY_ID = "10013";
    String DUPLICATE_SITE_NAME = "10014";
    String EMAIL_EXISTS = "10015";
    String INVALID_CONTACT_ID = "10016";
    String ERROR_CREATING_USER_IN_AD = "10017";
    String EMPTY_DATABASE_FILE = "10018";
    String FILE_FORMAT_NOT_SUPPORTED = "10019";
    String INVALID_SITE_META_DATA = "10020";
    String INVALID_EQUIPMENT_ID = "10021";
    String INVALID_MONTH_YEAR = "10022";
    String FAILED_IN_PROCESSING_FILE = "10023";
    String INVALID_FILE_STRUCTURE = "10024";
    String FAILED_DURING_DATA_STORAGE = "10025";
    String NO_DATA_FOUND = "10026";
    String USER_EXISTS = "10027";
    String INVALID_UPLOAD_ID = "10028";
    String ERROR_UPDATING_FILE_STATUS = "10029";
    String MULTIPLE_FILES_IN_ARCHIVE = "10030";
    String DATA_ERROR_IN_MDB_FILE = "10031";
    String INVALID_USER_NAME = "10032";
    String INVALID_METRIC_UNIT = "10033";
    String INVALID_MAIL_FORMAT = "10034";
    String INVALID_FILE_EXPORT_FORMAT = "10035";
    String INVALID_DATE_RANGE = "10036";
    String INVALID_SHIFT_ID = "10037";
    String INVALID_SHIFT = "10038";
    String INVAILD_TIME_STAMP = "10039";
    String INVALID_THRESHOLD = "10040";
    String INVALID_SITE = "10041";
    String USER_DOES_NOT_EXIST = "10042";
    String DEVICE_DOES_NOT_EXIST = "10045";
    String MULTIPLE_DEVICES_EXIST = "10046";
    String DEVICE_CREATION_FAILED = "10047";
    String ES_COMMUNICATION_ERROR = "10048";
    String INVALID_CONFIG_DATA_TYPE = "10049";
    String CONFIG_FILE_MISSING = "10050";
    String UNKNOWN_FORMAT_EXCEPTION = "10051";
    String DEVICE_MGMT_CONNECTION_TIMED_OUT = "10052";
    String MACHINES_NOT_FOUND = "10053";
    String BAD_REQUEST = "10054";
    String INTERNAL_ERROR = "10055";
    String MISSING_CONFIG_PROPERTY = "10056";
    String DATE_RANGE_NOT_VALID = "10057";
    String DEVICE_MANAGEMENT_EXCEPTION = "10058";
    String INVALID_DEVICE_ID = "10059";

    /**
     * HTTP response codes.
     * 
     * @author Shreyas K C
     * 
     */
    public interface StatusCodes {
	String SUCCESS = "200";
	String FAILURE = "500";
	String BAD_REQUEST = "400";
	String UN_AUTHORIZED = "401";
	String FORBIDDEN = "403";
	String DATA_NOT_FOUND = "410";
    }

    /**
     * Params list returned back on Insufficient information sent to the server.
     * 
     * @author Shreyas K C
     *
     */
    public interface InsufficientParams {
	String ACCOUNT_OBJECT = "Account Object";
	String ACCOUNT_ID = "Account Id";
	String ACCOUNT_NAME = "Account Name";
	String COMPANY_OBJECT = "Company Object";
	String SITE_OBJECT = "Site Object";
	String SITE_NAME = "Site Name";
	String COMPANY_ID = "Company Id";
	String SITE_ID = "Site Id";
	String DEVICE_ID = "Device Id";
	String COMPANY_NAME = "Company Name";
	String ADDRESS1 = "Address1";
	String STATE = "State";
	String COUNTRY = "Country";
	String ZIPCODE = "Zipcode";
	String METRIC_UNIT = "Metric Unit";
	String CONTACT_LIST = "Contact List";
	String CITY = "City";
	String USER_OBJECT = "User Object";
	String USER_ID = "User Id";
	String FIRST_NAME = "First Name";
	String LAST_NAME = "Last Name";
	String USER_ROLE = "User Role";
	String EMAIL = "Email";
	String PASSWORD = "Password";
	String CONTACT_OBJECT = "Contact Object";
	String CONTACT_ID = "Contact Id";
	String CONTACT_NAME = "Contact name";
	String CONTACT_EMAIL = "Contact email";
	String CONTACT_NUMBER = "Contact number";
	String CONTACT_TITLE = "Contact title";
	String OBSERVATION_OBJECT = "Observation Object";
	String EQUIPMENT_ID = "Equipment ID";
	String OBSERVATION = "Observation";
	String RECOMMENDATION = "Recommendation";
	String MONTH = "Month";
	String YEAR = "Year";
	String OBSERVATION_ID = "Observation ID";
	String FILE_TYPE = "File Type";
	String MEASUREMENT_UNIT = "Measurement Unit";
	String REPORT_REQUEST_OBJECT = "Report Request Object";
	String TO_DATE = "end date";
	String FROM_DATE = "start date";
	String START_SHIFT = "start shift";
	String END_SHIFT = "end shift";
	String TIME_ZONE = "time zone";
	String DATE = "date";
	String EVENT_OBJECT = "event object";
	String FECHA = "fecha";
	String PRODUCT_NAME = "product name";
	String SERIAL_NUMBER = "serialNumber";
	String MDATA = "mData";
	String EDATA = "eData";
    }

}
