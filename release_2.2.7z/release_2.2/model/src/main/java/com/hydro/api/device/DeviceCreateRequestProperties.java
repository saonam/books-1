package com.hydro.api.device;

import java.io.Serializable;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class DeviceCreateRequestProperties implements Serializable {

    private String serialNumber;
    private String name;
    private String variableName;
    private String variableValue;
    private String priority;
    private boolean isapplied = true;
    private String lastUpdateDate;
    private List<String> propertyValue;

    public String getSerialNumber() {
	return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
	this.serialNumber = serialNumber;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getVariableName() {
	return variableName;
    }

    public void setVariableName(String variableName) {
	this.variableName = variableName;
    }

    public String getVariableValue() {
	return variableValue;
    }

    public void setVariableValue(String variableValue) {
	this.variableValue = variableValue;
    }

    public String getPriority() {
	return priority;
    }

    public void setPriority(String priority) {
	this.priority = priority;
    }

    public boolean isIsapplied() {
	return isapplied;
    }

    public void setIsapplied(boolean isapplied) {
	this.isapplied = isapplied;
    }

    public String getLastUpdateDate() {
	return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
	this.lastUpdateDate = lastUpdateDate;
    }

    public List<String> getPropertyValue() {
	return propertyValue;
    }

    public void setPropertyValue(List<String> propertyValue) {
	this.propertyValue = propertyValue;
    }

    @Override
    public String toString() {
	return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
    }
}
