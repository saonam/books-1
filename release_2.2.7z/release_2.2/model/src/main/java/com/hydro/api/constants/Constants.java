package com.hydro.api.constants;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;

import com.hydro.api.dto.MetricDTO;

/**
 * Hydro constant class.
 * 
 * @author Shreyas
 *
 */
public interface Constants {
    String JWT_TOKEN = "JWT_TOKEN";
    String TIME_ZONE_HEADER = "Time-Zone";
    String AZURE_TOKEN_URL = "AZURE_TOKEN_URL";
    String AZURE_AD_TOKEN_URL = "AZURE_AD_TOKEN_URL";
    String AZURE_AD_AUDIENCE = "AZURE_AD_AUDIENCE";
    String AZURE_AD_CERTIFICATE_URL = "AZURE_AD_CERTIFICATE_URL";
    String KEYS = "keys";
    String KID = "kid";
    String TOKEN_UNIQUE_NAME = "unique_name";
    String DEFAULT_ROLE_ID = "0";
    int DEFAULT_CLEARANCE_LEVEL = 0;
    String AZURE_AD_CREATE_USER_URL = "AZURE_AD_CREATE_USER_URL";
    String AZURE_AD_AUTHORITY_URL = "AZURE_AD_AUTHORITY_URL";
    String AZURE_AD_CLIENT_ID = "AZURE_AD_CLIENT_ID";
    String AZURE_AD_CLIENT_SECRET = "AZURE_AD_CLIENT_SECRET";
    String AZURE_AD_GRAPH_RESOURCE = "AZURE_AD_GRAPH_RESOURCE";
    String AZURE_AD_DEFAULT_PASSWORD = "AZURE_AD_DEFAULT_PASSWORD";
    String AZURE_AD_HEADLESS_TOKEN_URL = "AZURE_AD_HEADLESS_TOKEN_URL";
    String AZURE_AD_HEADLESS_CERTIFICATE_URL = "AZURE_AD_HEADLESS_CERTIFICATE_URL";
    String MAIL_SMTP = "MAIL_SMTP";
    String MAIL_PORT = "MAIL_PORT";
    String MAIL_USER = "MAIL_USER";
    String MAIL_PASSWORD = "MAIL_PASSWORD";
    String MAIL_HEADER = "MAIL_HEADER";
    String MAIL_ADDRESS = "MAIL_ADDRESS";
    String APP_URL = "APP_URL";
    String AUTHORIZATION = "Authorization";
    String CONTENT_TYPE = "Content-Type";
    String APPLICATION_JSON = "application/json";
    String FILE_UPLOAD_PATH = "FILE_UPLOAD_PATH";
    String TMP_MDB_FILE_PATH = "TMP_MDB_FILE_PATH";
    String PASSWORD_POLICIES = "passwordPolicies";
    String DISABLE_PASSWORD_EXPIRATION = "DisablePasswordExpiration";
    String ACCOUNT_ENABLED = "accountEnabled";
    String CREATION_TYPE = "creationType";
    String USER_PRINCIPAL_NAME = "userPrincipalName";
    String PASSWORD = "password";
    String SIGN_IN_NAMES = "signInNames";
    String TYPE = "type";
    String VALUE = "value";
    String EMAIL_ADDRESS = "emailAddress";
    String USER_NAME = "userName";
    String CREATIONTYPE = "creationType";
    String LOCAL_ACCOUNT = "LocalAccount";
    String DISPLAY_NAME = "displayName";
    String MAIL_NICK_NAME = "mailNickname";
    String FORCE_CHANGE_PASSWORD_NEXT_LOGIN = "forceChangePasswordNextLogin";
    String PASSWORD_PROFILE = "passwordProfile";
    String OBJECT_ID = "objectId";
    String OTHER_MAILS = "otherMails";
    String ES_TYPE = "ES_TYPE";
    String ES_INDEX = "ES_INDEX";
    String ES_DAILY_INDEX_THRESHOLD = "ES_DAILY_INDEX_THRESHOLD";
    String MAX_ES_CONN_TIMEOUT = "MAX_ES_CONN_TIMEOUT";
    String MAX_ES_READ_TIMEOUT = "MAX_ES_READ_TIMEOUT";
    String MAX_ES_CONNECTIONS = "MAX_ES_CONNECTIONS";
    String CONTROL = "CONTROL";
    String LM2_SEQ = "lm2_seq";
    String SITE_ID = "site_id";
    String EQUIPMENT_TYPE = "equipment_type";
    String FILE_ID = "file_id";
    String EVENT_ID = "event_id";
    String LM2_FILE_ID = "lm2_file_id";
    String LM2 = "LM2";
    String MDB = "MDB";
    String ZIP = "ZIP";
    String PROCESSING = "processing";
    String SUCCESS = "success";
    String FAILURE = "failure";
    String UPLOADED = "uploaded";
    String UPLOADING = "uploading";
    String PARTIAL_SUCCESS = "partial success";
    String CANAL_FOR_TUNNEL_REPORT = "CANAL_FOR_TUNNEL_REPORT";
    String TO_DATE_VAL = "TO_DATE_VAL";
    String FROM_DATE_VAL = "FROM_DATE_VAL";
    String SITE_ID_VAL = "SITE_ID_VAL";
    String EQUIPMENT_ID_VAL = "EQUIPMENT_ID_VAL";
    String NUM_CANALES_TUNEL1 = "NUM_CANALES_TUNEL1";
    String ES_HOST_NAMES = "ES_HOST_NAMES";
    String ES_PORTS = "ES_PORTS";
    String ES_SCHEME = "ES_SCHEME";
    String ES_BATCH_SIZE = "ES_BATCH_SIZE";
    String SOURCE = "source";
    String AZURE_AD_COMPANY_NAME = "AZURE_AD_COMPANY_NAME";
    String EVENTOS1 = "EVENTOS1";
    String ACCDB = "ACCDB";
    String SERVER_STARTUP_FAILURE = "Failed due to an unexpected system error. Please retry uploading the file. If the problem persists, please contact administrator for further details.";
    String EVENTOS = "EVENTOS";
    String ES_USERNAME = "ES_USERNAME";
    String ES_PASSWORD = "ES_PASSWORD";
    String ES_CONFLICTS = "esconflicts";
    String AUDIT_LOGS = "auditlogs";
    String FILE_NEWLY_CREATED_STATUS = "1";
    String FILE_THREE = "3";
    String FILE_FOUR = "4";
    String PG_MAX_DAYS_THRESHOLD = "PG_MAX_DAYS_THRESHOLD";

    String UTF_8 = "UTF-8";
    String UNDERSCORE = "_";
    String LOGOUT_URI = "/hydro/api/logout";
    String LOGIN_URI = "/hydro/api/login";
    String EXP = "exp";
    String TOKEN_CACHE_BUFFER_TIME = "TOKEN_CACHE_BUFFER_TIME";
    String SOLID_PRODUCT_FORMAT = "SOLID_PRODUCT_FORMAT";
    String ASTERISK = "*";

    String CLEARANCE_LEVEL = "clearanceLevel";
    String USER_ROLE = "userRole";
    String DEFAULT = "DEFAULT";

    String WASHER_PRODUCTION_SUMMARY = "WASHER_PRODUCTION_SUMMARY";
    String FORMULA_NAME_FIELD = "FORMULA NAME";
    String WASHED = "WASHED";
    String LOADS_WASHED = "LOADS WASHED";
    String WASHER_PRODUCTION_SUMMARY_REPORT_TAG = "Production summary report for";
    String CHEMICAL_SUMMARY = "CHEMICAL_SUMMARY";
    String CHEMICAL_SUMMARY_REPORT_TAG = "Chemical summary report for";
    String COST_SUMMARY = "COST_SUMMARY";
    String COST_SUMMARY_REPORT_TAG = "Cost summary report for";
    String ALARM_SUMMARY_REPORT_TAG = "Alarm summary report for";
    String DEFAULT_TIME_ZONE = "Etc/UTC";
    String COMMA = ",";
    String GET_METHOD = "GET";
    String CAT_INDICES = "/_cat/indices/";
    String UTC = "UTC";
    String WASHER_EXTRACTOR = "Washer Extractor";
    String TUNNEL = "Tunnel";
    String ALARM_EMAIL_SUBJECT = "Alert Notification!";
    String SMS_AUTH_TOKEN = "SMS_AUTH_TOKEN";
    String SMS_ACCOUNT_SID = "SMS_ACCOUNT_SID";
    String SMS_HYDRO_PHONE_NUMBER = "SMS_HYDRO_PHONE_NUMBER";

    String SEARCH_SERVICE_URL = "SEARCH_SERVICE_URL";
    String SEARCH_DEVICE_ID = "/id";
    String SEARCH_DEVICE_ID_PROP_NAME = "SEARCH_DEVICE_ID";
    String SEARCH_DEVICE_ALL = "/all";
    String SEARCH_DEVICE_ALL_PROP_NAME = "SEARCH_DEVICE_ALL";
    String ADVANCE_SEARCH_DEVICE = "ADVANCE_SEARCH_DEVICE";
    String DATA = "data";
    String SITE_NAME = "siteName";
    String SERIAL_NUMBER = "serialNumber";
    String IP_ADDRESS = "ipaddress";
    String SITE_ID_SEARCH = "SiteId";
    String SITE_ID_NOT_PRESENT = "SiteId is not present in device management API";
    String DEVICE_ID_NOT_PRESENT = "DeviceId is not present in device management API";
    String DEVICE_ID = "Device_ID";
    String DEVICEID = "device_id";
    String EDGE = "edge";
    String DESCRIPTION = "Description";
    String MDATA = "mData";
    String EDATA = "eData";

    public interface AlarmType {
	String SYSTEM = "0";
	String CUSTOM = "1";
    }

    public interface DayWiseReportType {
	String HISTORICAL = "1";
	String REAL_TIME = "0";
    }

    public interface BusinessTypes {
	String ACCOUNT = "0";
	String COMPANY = "1";
    }

    public interface LM2_STATUS {
	String INACTIVE = "0";
	String ACTIVE = "1";
    }

    public interface FileStatus {

	String FAILURE = "FAILURE";
	String UPLOADED = "UPLOADED";
	String PROCESSING = "PROCESSING";
	String SUCCESS = "SUCCESS";
	String PARTIAL_SUCCESS = "PARTIAL_SUCCESS";
	String UPLOADING = "UPLOADING";

	HashMap<String, String> fileStatusConstants = new LinkedHashMap<String, String>() {
	    {
		put(FAILURE, "0");
		put(UPLOADED, "1");
		put(PROCESSING, "2");
		put(SUCCESS, "3");
		put(PARTIAL_SUCCESS, "4");
		put(UPLOADING, "5");

	    }
	};
    }

    public interface ThresholdResetConstants {

	String SHIFT = "Shift";
	String DAY = "Day";
	String WEEK = "Week";
	String MONTH = "Month";

	LinkedList<String> resetValueList = new LinkedList<String>(Arrays.asList(SHIFT, DAY, WEEK, MONTH));
    }

    public enum BULK_STATE {
	FAILED, SUCCESS, PARTIAL_SUCCESS
    }

    public interface ACTIVE_STATE {
	String ACTIVE = "1";
	String INACTIVE = "0";
    }

    public interface PRIVILEGE_NAMES {
	String SITE_LIST = "SITE_LIST";
	String SITE_VIEW = "SITE_VIEW";
	String SITE_CREATE = "SITE_CREATE";
	String SITE_UPDATE = "SITE_UPDATE";
	String SITE_DELETE = "SITE_DELETE";
	String ACCOUNT_LIST = "ACCOUNT_LIST";
	String ACCOUNT_VIEW = "ACCOUNT_VIEW";
	String ACCOUNT_CREATE = "ACCOUNT_CREATE";
	String ACCOUNT_UPDATE = "ACCOUNT_UPDATE";
	String ACCOUNT_DELETE = "ACCOUNT_DELETE";
	String COMPANY_LIST = "COMPANY_LIST";
	String COMPANY_VIEW = "COMPANY_VIEW";
	String COMPANY_CREATE = "COMPANY_CREATE";
	String COMPANY_UPDATE = "COMPANY_UPDATE";
	String COMPANY_DELETE = "COMPANY_DELETE";
	String USER_LIST = "USER_LIST";
	String USER_VIEW = "USER_VIEW";
	String USER_CREATE = "USER_CREATE";
	String USER_UPDATE = "USER_UPDATE";
	String USER_DELETE = "USER_DELETE";
	String GENERATE_REPORT = "GENERATE_REPORT";
	String FILE_UPLOAD = "FILE_UPLOAD";
	String FILE_HISTORY = "FILE_HISTORY";
	String OBSERVATION_RECOMMENDATION_VIEW = "OBSERVATION_RECOMMENDATION_VIEW";
	String OBSERVATION_RECOMMENDATION_UPDATE = "OBSERVATION_RECOMMENDATION_UPDATE";
	String OBSERVATION_RECOMMENDATION_DELETE = "OBSERVATION_RECOMMENDATION_DELETE";
	String OBSERVATION_RECOMMENDATION_CREATE = "OBSERVATION_RECOMMENDATION_CREATE";
	String PRODUCTION_SUMMARY_LBS_WASHED = "PRODUCTION_SUMMARY_LBS_WASHED";
	String PRODUCTION_SUMMARY_LOADS_WASHED = "PRODUCTION_SUMMARY_LOADS_WASHED";
	String CHEMICAL_SUMMARY_ACTUAL_USAGE = "CHEMICAL_SUMMARY_ACTUAL_USAGE";
	String CHEMICAL_SUMMARY_ERROR = "CHEMICAL_SUMMARY_ERROR";
	String COST_SUMMARY_ABS_COST = "COST_SUMMARY_ABS_COST";
	String COST_SUMMARY_ERROR = "COST_SUMMARY_ERROR";
	String WASHER_PRODUCTION_SUMMARY_REPORT = "WASHER_PRODUCTION_SUMMARY_REPORT";
	String ALARM_SUMMARY_REPORT = "ALARM_SUMMARY_REPORT";
	String COST_SUMMARY_REPORT = "COST_SUMMARY_REPORT";
	String CHEMICAL_SUMMARY_REPORT = "CHEMICAL_SUMMARY_REPORT";
	String FULL_PRIVILEGE = "FULL_PRIVILEGE";
	String USER_CREATION_FULL_PRIVILEGE = "FULL-PRIVILEGE";
	String CHEMICAL_SUMMARY_EST_USAGE = "CHEMICAL_SUMMARY_EST_USAGE";
	String COST_SUMMARY_EST_COST = "COST_SUMMARY_EST_COST";
	String COST_SUMMARY_COST_PER_CWT = "COST_SUMMARY_COST_PER_CWT";
	String CREATE_SAME_LEVEL_USER = "CREATE_SAME_LEVEL_USER";
	String SITE_FULL_EDIT = "SITE_FULL_EDIT";
	String OBS_REC_REPORT = "OBS_REC_REPORT";
	String REAL_TIME_REPORT = "REAL_TIME_REPORT";
	String ALERT_SETTING = "ALERT_SETTING";
	String DEVICE_MANAGEMENT_CREATE = "DEVICE_MANAGEMENT_CREATE";
	String DEVICE_MANAGEMENT_DELETE = "DEVICE_MANAGEMENT_DELETE";
	String DEVICE_MANAGEMENT_LIST = "DEVICE_MANAGEMENT_LIST";
	String DEVICE_MANAGEMENT_UPDATE = "DEVICE_MANAGEMENT_UPDATE";
	String DEVICE_MANAGEMENT_VIEW = "DEVICE_MANAGEMENT_VIEW";
    }

    public interface COMPANY_MODULES {

	String CONTEXT = "/company";
	String GET_ALL_LIST = "/getCompanyList";
    }

    HashSet<String> SUPPORTED_EXTENSIONS = new HashSet<String>() {
	{
	    add("LM2");
	    add("MDB");
	    add("ZIP");
	    add("ACCDB");
	    add("JSON");
	}
    };
    String NAME = "name";
    String WELCOME_HEADER = "Welcome to Hydro";
    String WELCOME_SUBJECT = "WELCOME_SUBJECT";

    public interface EventColumns {

	HashSet<String> DATE_TIME = new HashSet<String>() {
	    {
		add("fecha");
	    }
	};
	HashSet<String> PROD_NAME = new HashSet<String>() {
	    {
		add("nombre");
	    }
	};
	HashSet<String> PUMPS = new HashSet<String>() {
	    {
		add("bomba");
	    }
	};
	HashSet<String> EVENT_ID_GENERATOR = new HashSet<String>() {
	    {
		add("fecha");
		add("proceso");
		add("maquinaria");
		add("destino");
		add("formula");
		add("formula_nombre");
		add("fase");
		add("tipo_alarma");
		add("nombre");
	    }
	};

    }

    public static enum EventType {
	NORMAL_DOSAGE(0), UNFINISHED_DOSAGE(2), BEGINNING_OF_NEW_CYCLE(10), END_OF_CYCLE(11), LEVEL_ALARM(100),
	TRIGGER_ALARM(200);

	private final Integer id;

	private EventType(Integer id) {
	    this.id = id;
	}

	public Integer id() {
	    return id;
	}
    }

    public interface REPORTS {
	String EQUIPMENT_TYPE = "equipment_type";
	String WE_PROD_SUMMARY_QUERY = "WEProductionSummary.json";
	String BATCH_DATA_QUERY = "BatchData.json";
	String TUNNEL_PROD_SUMMARY_QUERY = "TunnelProductionSummary.json";
	String GET_PROCESSED_LOADS_FOR_TUNNEL = "GetProcessedLoadsForTunnel.json";
	String TUNNEL_EDGE_PROD_SUMMARY_QUERY = "TunnelEdgeProductionSummary.json";
	String TUNNEL_EDGE_COST_SUMMARY_QUERY = "TunnelEdgeCostSummary.json";
	String MACHINE_IDLE_LONG = "MachineIdleLong.json";
	String WE_COST_SUMMARY_QUERY = "WECostSummary.json";
	String TUNNEL_COST_SUMMARY_QUERY = "TunnelCostSummary.json";
	String CHEMICAL_SUMMARY_QUERY = "ChemicalSummaryQuery.json";
	String ALARM_SUMMARY_QUERY = "AlarmSummary.json";
	String MAX_EVENT_DATE_QUERY = "MaxEventDate.json";
	String AGGREGATIONS = "aggregations";
	String CANAL_AGGREGATION = "canal_aggregation";
	String MACHINE_AGGREGATION = "machine_aggregation";
	String PRODUCT_AGGREGATION = "product_aggregation";
	String FORMULA_AGGREGATION = "formula_aggregation";
	String CYCLE_AGGREGATION = "cycle_aggregation";
	String PUMP_AGGREGATION = "pump_aggregation";
	String SITE_AGGREGATION = "site_aggregation";
	String BATCH_AGGREGATION = "batch_aggregation";
	String UNIT_AGGREGATION = "unit_aggregation";
	String GROUP_DOCUMENT = "group_docs";
	String ERROR = "error";
	String RESPONSES = "responses";
	String BUCKETS = "buckets";
	String KEY = "key";
	String VALUE = "value";
	String SUM_REAL = "sum_real";
	String SUM_REAL_COST = "sum_real_cost";
	String SUM_REAL_ESTIATED = "sum_cost_estimated";
	String TOTAL_SUM_REAL = "total_sum_real";
	String TOTAL_SUM_REAL_COST = "total_sum_real_cost";
	String TOTAL_SUM_COST_ESTIMATED = "total_sum_cost_estimated";
	String TOTAL_SUM_ESTIMATED = "total_sum_estimated";
	String DOC_COUNT = "doc_count";
	String SUM_ESTIMATED_ML = "sum_estimated_ml";
	String SUM_ML = "sum_ml";
	String HITS = "hits";
	String SOURCE = "_source";
	String ALARM_CODE = "tipo_alarma";
	String NAME = "name";
	String CAPACITY = "capacity";
	String DATE_TIME = "fecha";
	String FORMULA = "formula";
	String FORMULA_NAME = "formula_nombre";
	String MACHINE_TUNNEL = "maquinaria";
	String MACHINE_WASHER = "destino";
	String ESTIMATED_ML = "ml_estimados";
	String ACTUAL_ML = "ml_reales";

	String COST = "ml_estimados";

	String ESTIMATED_TIME = "t_estimado";
	String ACTUAL_TIME = "t_real";
	String PROCESS = "proceso";
	String PRODUCT = "nombre";
	String PHASE = "fase";
	String LM2_SEQ = "lm2_seq";
	String ROOT_CAUSE = "root_cause";
	String TYPE = "type";
	String SUM_PUMP_AGG = "sum_pump_agg";
	String SUM_PUMP_REAL_KG = "sum_pump_real_kg";
	String MAX_DATE = "max_date";
	String MIN_DATE = "min_date";
	String REAL_TIME_REPORT = "RealTimeReport.json";
	String EVENT_ID = "event_id";
	String EVENT_TYPE = "event_type";
	String REAL_TIME_REPORT_CONFIG = "RealTimeReportConfigData.json";
	String KG_REALS = "kg_reales";
	String EVENT_TYPE_START_OF_CYCLE = "EVENT_TYPE_START_OF_CYCLE";
	String EVENT_TYPE_END_OF_CYCLE = "EVENT_TYPE_END_OF_CYCLE";
	int EVENT_TYPE_11 = 11;
	String ZERO_PHASE = "ZERO_PHASE";
	String MISSED_PHASE = "MISSED_PHASE";
	String DEFAULT_INDEX = "DEFAULT_INDEX";
	String PHASE_CONSTANT = "PHASE_CONSTANT";
	String FORMULA_COST = "formula_cost";
	String OFF_SHIFT = "OFF_SHIFT";
	String COST_REAL = "coste_real";
	String COST_ESTIMADO = "coste_estimado";
	String AVG_REAL_KG = "avg_real_kg";
	HashMap<Integer, String> EVENTS = new HashMap<Integer, String>() {
	    {
		put(0, "Normal dosage");
		put(1, "Reserved");
		put(2, "unfinished dosage");
		put(10, "Begining of a new cycle");
		put(11, "End of cycle");
		put(927, "Air pressure failure");
		put(928, "Unit locked");
		put(100, "Level alarm");
		put(200, "Trigger alarm");
	    }
	};

	HashMap<Integer, String> ALARMS_ASSOCIATED_TO_EVENTS = new HashMap<Integer, String>() {
	    {
		put(0, "No alarms");
		put(1, "Unfinished cycle");
		put(2, "Missing phases");
		put(8, "Leak test failure");
		put(9, "Water test failure");
		put(10, "Product dosage alarm");
		put(11, "Flush alarm");
		put(16, "Level alarm");
		put(32, "Unit Locked");
		put(33, "Air Pressure failure");
	    }
	};

	HashMap<Integer, String> MDB_ALARMS = new HashMap<Integer, String>() {
	    {
		put(2, "Leak test");
		put(3, "Water test");
		put(4, "Flow meter error for product dosage");
		put(5, "Flow meter error for water flush");
		put(900, "Minimum levels of product");
		put(927, "Air pressure failure");
		put(928, "Unit locked");
		put(101, "Unfinished cycles");
		put(111, "Cycles with missed phases");
	    }
	};

	HashMap<Integer, String> MDB_TUNNEL_ALARMS = new HashMap<Integer, String>() {
	    {
		put(2, "Leak test");
		put(3, "Water test");
		put(4, "Flow meter error for product dosage");
		put(5, "Flow meter error for water flush");
		put(900, "Minimum levels of product");
		put(927, "Air pressure failure");
		put(928, "Unit locked");
	    }
	};

	HashMap<Integer, String> OLD_ALARMS = new HashMap<Integer, String>() {
	    {
		put(0, "No alarms");
		put(1, "Unfinished cycle");
		put(2, "Missing phases");
		put(3, "Water test");
		put(4, "Flow meter error for product dosage");
		put(5, "Flow meter error for water flush");
		put(8, "Leak test failure");
		put(9, "Water test failure");
		put(10, "Product dosage Alarm");
		put(11, "Flush Alarm");
		put(16, "Level Alarm");
		put(32, "Emergency stop Alarm");
		put(33, "Air Pressure failure");
		put(900, "Minimum levels of product");
		put(927, "Air pressure failure");
		put(928, "Unit locked");
		put(101, "Machine Idle Too Long");
		put(111, "Cycles with missed phases");
	    }
	};

	HashMap<Integer, String> REAL_TIME_ALARMS = new HashMap<Integer, String>() {
	    {
		put(1, "Unfinished Cycle");
		put(2, "Cycles with missed phases");
		put(8, "Leak Test Failure");
		put(9, "Water Test Failure");
		put(10, "Flow meter error for product dosage");
		put(11, "Flow meter error for water flush");
		put(16, "Minimum levels of product");
		put(32, "Unit locked");
		put(33, "Air Pressure failure");
	    }
	};

	HashMap<Integer, String> REAL_TIME_TUNNEL_ALARMS = new HashMap<Integer, String>() {
	    {
		put(8, "Leak Test Failure");
		put(9, "Water Test Failure");
		put(10, "Flow meter error for product dosage");
		put(11, "Flow meter error for water flush");
		put(16, "Minimum levels of product");
		put(32, "Unit locked");
		put(33, "Air Pressure failure");
	    }
	};

	HashMap<Integer, String> SYSTEM_ALARMS = new HashMap<Integer, String>() {
	    {
		put(16, "Minimum levels of product");
		put(32, "Unit locked");
		put(33, "Air Pressure failure");
	    }
	};

	String PRODUCT_ID = "product_id";
	String PRODUCT_NAME = "product_name";
	String TOTAL_PHASES = "formula_phases";
	String WASHER_EXTRACTOR_NAME = "washerextractor_name";
	String OTHER_ALARM = "Other Alarm";
	Integer UNIT_LOCKED_ALARM = 32;
	Integer AIR_PRESSURE_ALARM = 33;
	Integer UNFINISHED_CYCLE_ALARM = 1;
	Integer MISSED_PHASE_ALARM = 2;

	Integer OUT_OF_PRODUCT = 16;
	String CYCLE_DETAILS = "CycleDetails.json";
	String BATCH_ID = "batch";
	String MODULE = "module";
	String CHANNEL = "channel";
	String TRANSFER_NUMBER = "transfer_number";
	String WE_LOAD_PROCESSED_QUERY = "WELoadProcessed.json";

	public interface DISPLAY_FIELDS {
	    HashMap<String, String> DATE_DISPLAY = new HashMap<String, String>() {
		{
		    put("fecha", "Time");
		}
	    };
	    HashMap<String, String> PROCESS_DISPLAY = new HashMap<String, String>() {
		{
		    put("proceso", "Process");
		}
	    };
	    HashMap<String, String> PRODUCT_ID_DISPLAY = new HashMap<String, String>() {
		{
		    put("product_id", "Product#");
		}
	    };
	    HashMap<String, String> FORMULA_ID_DISPLAY = new HashMap<String, String>() {
		{
		    put("formula", "Formula#");
		}
	    };
	    HashMap<String, String> FORMULA_NAME_DISPLAY = new HashMap<String, String>() {
		{
		    put("formula_nombre", "Formula Name");
		}
	    };
	    HashMap<String, String> PRODUCT_NAME_DISPLAY = new HashMap<String, String>() {
		{
		    put("nombre", "Product Name");
		}
	    };
	    HashMap<String, String> PHASE_DISPLAY = new HashMap<String, String>() {
		{
		    put("fase", "Phase");
		}
	    };
	    HashMap<String, String> ESTIMATED_USAGE_DISPLAY = new HashMap<String, String>() {
		{
		    put("ml_estimados", "Est");
		}
	    };
	    HashMap<String, String> ACTUAL_USAGE_DISPLAY = new HashMap<String, String>() {
		{
		    put("ml_reales", "Actual");
		}
	    };
	    HashMap<String, String> ESTIMATED_TIME_DISPLAY = new HashMap<String, String>() {
		{
		    put("t_estimado", "Estimated Time (Sec)");
		}
	    };
	    HashMap<String, String> ACTUAL_TIME_DISPLAY = new HashMap<String, String>() {
		{
		    put("t_real", "Actual Time (Sec)");
		}
	    };
	}
    }

    public interface EquipmentType {
	String TUNNEL = "0";
	String WASHER_EXTRACTOR = "1";
    }

    public interface DataSource {
	final String UNIT = "unit";
    }

    public interface DataType {
	final String CONFIG = "config";
    }

    public interface FILE_TYPE {

	String LM2 = "1";
	String MDB = "2";
	String ZIP = "3";
	String STREAM = "4";
	String CONFIG_JSON = "5";
	String FORMULA_JSON = "6";
    }

    public interface DATA_TYPE {
	String FORMULAS = "formulas";
	String CONFIG = "config";
    }

    public interface PUMP_NAME {
	String BOMBAS1 = "BOMBAS1";
	String BOMBAS2 = "BOMBAS2";
	String BOMBAS3 = "BOMBAS3";
	String BOMBAS4 = "BOMBAS4";
	String BOMBAS5 = "BOMBAS5";
	String BOMBAS6 = "BOMBAS6";
	String BOMBAS7 = "BOMBAS7";
	String BOMBAS8 = "BOMBAS8";
	String BOMBAS9 = "BOMBAS9";
	String BOMBAS10 = "BOMBAS10";
    }

    public interface FORMULA_NAME {
	String FORMULAS0 = "FORMULAS0";
	String FORMULAS1 = "FORMULAS1";
	String FORMULAS2 = "FORMULAS2";
    }

    public interface PUMP_MACHINE_NAME {
	String BOMBAS_MAQUINARIA0 = "BOMBAS_MAQUINARIA0";
	String BOMBAS_MAQUINARIA1 = "BOMBAS_MAQUINARIA1";
	String BOMBAS_MAQUINARIA2 = "BOMBAS_MAQUINARIA2";
    }

    public interface PDB_NAME {
	String PDB1 = "PDB1";
	String PDB2 = "PDB2";
	String PDB3 = "PDB3";
	String PDB4 = "PDB4";
	String PDB5 = "PDB5";
	String PDB6 = "PDB6";
	String PDB7 = "PDB7";
	String PDB8 = "PDB8";
	String PDB9 = "PDB9";
	String PDB10 = "PDB10";
    }

    public interface PRODUCT_MODULO {
	String PRODUCTOS_MODULO1 = "PRODUCTOS_MODULO1";
	String PRODUCTOS_MODULO2 = "PRODUCTOS_MODULO2";
	String PRODUCTOS_MODULO3 = "PRODUCTOS_MODULO3";
	String PRODUCTOS_MODULO4 = "PRODUCTOS_MODULO4";
	String PRODUCTOS_MODULO5 = "PRODUCTOS_MODULO5";
	String PRODUCTOS_MODULO6 = "PRODUCTOS_MODULO6";
	String PRODUCTOS_MODULO7 = "PRODUCTOS_MODULO7";
	String PRODUCTOS_MODULO8 = "PRODUCTOS_MODULO8";
	String PRODUCTOS_MODULO9 = "PRODUCTOS_MODULO9";
	String PRODUCTOS_MODULO10 = "PRODUCTOS_MODULO10";

    }

    public interface DATE_TIME_FORMAT {
	String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";
	String REPORT_DATE_FORMAT = "yyyy-MM-dd";
	String TIME_FORMAT = "HH:mm:ss";
	String REAL_TIME_REPORT_DATE_TIME = "yyyy-MM-dd'T'HH:mm:ss";
	String DAILY_INDEX_FORMAT = "dd-MM-yyyy";
	String DATE_TIME_FORMAT_WITHOUT_SEC = "yyyy-MM-dd'T'HH:mm";
	String PROCESSABLE_EVENT_DATETIME_FORMAT = "^([0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}\\:[0-9]{2}\\:[0-9]{2})(.*)$";
    }

    public interface ES_EXCEPTION_TYPE {
	String INDEX_NOT_FOUND_EXCEPTION = "index_not_found_exception";
    }

    public interface ES_STATUS {
	String VERSION_CONFLICT = "409";
    }

    public interface ES_ERROR_DESCRIPTION {
	String CREATE = "CREATE OPERATION IN ES FAILED";
	String DELETE = "DELETE OPERATION IN ES FAILED";
	String UPDATE = "UPDATE OPERATION IN ES FAILED";
    }

    public interface Units {
	String KG = "kg";
	String LBS = "lbs";
	String GAL = "gal";
	String OZ = "Oz";
	String ML = "ml";
	String CW_LABEL = "CWT";
	String KILO = "KILO";
	String KG_DISPLAY = "Kilogram";
	String LBS_DISPLAY = "Pounds";
	String GAL_DISPLAY = "Gallons";
	String OZ_DISPLAY = "Ounce";
	String ML_DISPLAY = "Millilitre";
	String KG_LBS = "2.2046226218";
	String GALLON_KG = "3.78541";
	String OZ_ML = "29.5735";
	String ML_KG = "1000";
	String ML_GALLON = "3785.41";
	String OZ_GALLON = "128";
	Double PRICE = 10000.00;
	String OZ_KG = "33.814";
	String PER_CW = "100";
	Double lbsKgConversion = 2.2046226218;
	Double galToKgConversion = 3.78541;
	Double ozToMlConversion = 29.5735;

	LinkedList<String> weightList = new LinkedList<String>(Arrays.asList(KG, LBS));
	LinkedList<String> volumeList = new LinkedList<String>(Arrays.asList(GAL, KG, ML, OZ));

	public interface UsUnit {
	    String ID = "1";
	    String WEIGHT = LBS;
	    String VOLUME = GAL;
	    String COST = "USD";
	    String DISPLAY_NAME = "US";
	    String ALARM_VOLUME = OZ;
	    String WEIGHT_DISPLAY = LBS_DISPLAY;
	    String VOLUME_DISPLAY = GAL_DISPLAY;
	    String ALARM_VOLUME_DISPLAY = OZ_DISPLAY;
	    String CW = CW_LABEL;
	}

	public interface MetricUnit {
	    String ID = "2";
	    String WEIGHT = KG;
	    String VOLUME = KG;
	    String COST = "EURO";
	    String DISPLAY_NAME = "Metric";
	    String ALARM_VOLUME = ML;
	    String WEIGHT_DISPLAY = KG_DISPLAY;
	    String VOLUME_DISPLAY = KG_DISPLAY;
	    String ALARM_VOLUME_DISPLAY = ML_DISPLAY;
	    String CW = KILO;
	}

	enum Operations {
	    DIVIDE, MULTIPLY, ADD, SUBTRACT, NO_OPERATION;
	}

	LinkedList<MetricDTO> METRIC_LIST = new LinkedList<MetricDTO>(Arrays.asList(
		new MetricDTO(UsUnit.ID, UsUnit.WEIGHT, UsUnit.VOLUME, UsUnit.COST, UsUnit.DISPLAY_NAME,
			UsUnit.ALARM_VOLUME, UsUnit.WEIGHT_DISPLAY, UsUnit.VOLUME_DISPLAY, UsUnit.ALARM_VOLUME_DISPLAY,
			UsUnit.CW),
		new MetricDTO(MetricUnit.ID, MetricUnit.WEIGHT, MetricUnit.VOLUME, MetricUnit.COST,
			MetricUnit.DISPLAY_NAME, MetricUnit.ALARM_VOLUME, MetricUnit.WEIGHT_DISPLAY,
			MetricUnit.VOLUME_DISPLAY, MetricUnit.ALARM_VOLUME_DISPLAY, MetricUnit.CW)));
    }

    String HYDRO = "HYDRO";
    String ACCOUNT = "ACCOUNT";
    String COMPANY = "CHEMICAL COMPANY";
    String SITE = "SITE";

    HashMap<String, String> roleUrl = new LinkedHashMap<String, String>() {
	{
	    put(HYDRO, null);
	    put(COMPANY, Constants.COMPANY_MODULES.CONTEXT + Constants.COMPANY_MODULES.GET_ALL_LIST);
	}
    };
    String TOTAL = "Total";
    String TOTAL_LOADS = "Total Loads";
    String TOTAL_PRODUCTION = "Total Production";
    String TOTAL_PRODUCTION_LOADS = "Total Production loads";
    String WASHER_PRODUCTION_SUMMARY_REPORT = "Production summary report for ";
    String ACTUAL_USAGE = "ACTUAL USAGE";
    String ERROR = "ERROR(%)";
    String REAL_COST = "REAL COST";
    String REAL_CWT = "REAL CWT";
    String ALARM_SUMMARY = "ALARM_SUMMARY";
    String WARNINGS = "WARNINGS";
    String MACHINES = "MACHINES";
    String SYSTEM_WARNING = "SYSTEM_WARNING";
    String ERROR_MESSAGE = "Error occured during creation of excel file. Please retry exporting the file. If the problem persists, please contact administrator for further details.";
    Integer SITE_MANAGER_CLEARANCE_LEVEL = 7;
    String NULL = null;
    String HYPHEN = "-";
    String INDEX = "index";
    String JSON_FORMAT = "?v&format=json";
    String DEFAULT_SHIFT = "DEFAULT_SHIFT";
    String MACHINE_IDLE_QUERY_TIME_RANGE_IN_HRS = "MACHINE_IDLE_QUERY_TIME_RANGE_IN_HRS";
    int MACHINE_IDLE_TOO_LONG_TIME_ALARM_CODE = 101;
    String DEFAULT_SHIFT_START_TIME = "DEFAULT_SHIFT_START_TIME";
    String DEFAULT_SHIFT_END_TIME = "DEFAULT_SHIFT_END_TIME";
    String TIME24HOURS_PATTERN = "([01]?[0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9]";
    String COMMA_SEPARATED_PATTERN = "\\s*,\\s*";

    public interface REPORT_EXPORT_CONSTANTS {
	String SITE = "Site";
	String COMPANY = "Company";
	String UNDERSCORE = "_";
	int DEFAULT_ROW_COUNT = 0;
	int DEFAULT_COLUMN_COUNT = 0;
	String NEW_LINE = "\n";
	String COLON = ":";
	String SPACE = " ";
	String OPEN_PARENTHESES = "(";
	String CLOSE_PARETHESES = ")";
	String TO = "to";
	String ERROR_SHEET = "ERROR";
	String PER = "PER";
	String ABSOLUTE = "ABSOLUTE";
	String NO_COMPANY_ASSOCIATED = "No Company Associated";
	int ALARM_SIDE_HEADING = 6000;
	int ALARM_HEADING = 5000;
	int ALARM_SUB_SCREEN_HEADING = 6000;
	int COST_HEADING = 5000;
	int COST_SIDE_HEADING = 6000;
	int CHEMICAL_HEADING = 6000;
	int CHEMICAL_SUB_HEADING = 4000;
	int PRODUCTION_HEADING = 6000;
	int PRODUCTION_SUB_HEADING = 4000;
	String ALARM_NAME_TAG = "Alarm name";
	String UNIT_NAME = "Unit";
    }

    String ES_DAILY_INDEX = "ES_DAILY_INDEX";
    String START_TIME = "START_TIME";
    String END_TIME = "END_TIME";
    String WASHER_EXTRACTOR_NAME = "washerextractor_name";
    String FORMULA_NAME_REAL_TIME = "formula_nombre";
    String KG = "kg";
    String TOTAL_PHASE = "formula_phases";
    String PHASE = "fase";
    String T = "T";
    String CYCLE_ID = "CYCLE_ID";// processo
    String MACHINE_ID = "MACHINE_ID";// destino
    String CHEMICAL_COMPANY_ADMIN = "CHEMICAL COMPANY ADMIN";
    String INDEX_AGGREGATION = "index_aggregation";
    String OFF_SHIFT = "Off Shift";
    String DEVICE_ID_VAL = "DEVICE_ID_VAL";
    String BATCH_IDS_VAL = "BATCH_IDS_VAL";
    String BATCH_ID = "batch";
    String BATCH_ID_VAL = "BATCH_ID";
    String MODULE_VAL = "MODULE_VAL";
    String ID = "Id";
    String JSON = "json";
    String CONFIG_JSON = "config json";
    String FORMULA_JSON = "formula json";
    String CONFIG_DEVICE = "config device";
    String DEFAULT_LM2SEQ = "DEFAULTLM2";
}
