package com.hydro.api.exception;

import java.util.HashMap;

/**
 * @author Srishti Tiwari
 *
 */
@SuppressWarnings("serial")
public class DeviceManagementException extends ExceptionBase {

    public DeviceManagementException(String errorCode, HashMap<String, String> errorConfig, String status,
	    Object params) {
	super(errorCode, errorConfig, status, params);
	// TODO Auto-generated constructor stub
    }

    public DeviceManagementException(String errorMessage, String errorCode, String status, Object params) {
	super(errorMessage, errorCode, status, params);
	// TODO Auto-generated constructor stub
    }

    public DeviceManagementException(Throwable throwable, String errorCode, HashMap<String, String> errorConfig,
	    String status, Object params) {
	super(throwable, errorCode, errorConfig, status, params);
	// TODO Auto-generated constructor stub
    }

    public DeviceManagementException(Throwable throwable) {
	super(throwable);
	// TODO Auto-generated constructor stub
    }

}
