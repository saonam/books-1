/**
 * 
 */
package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class PermissionDTO {
    private boolean SITE_LIST;
    private boolean SITE_VIEW;
    private boolean SITE_CREATE;
    private boolean SITE_UPDATE;
    private boolean SITE_DELETE;
    private boolean ACCOUNT_LIST;
    private boolean ACCOUNT_VIEW;
    private boolean ACCOUNT_CREATE;
    private boolean ACCOUNT_UPDATE;
    private boolean ACCOUNT_DELETE;
    private boolean COMPANY_LIST;
    private boolean COMPANY_VIEW;
    private boolean COMPANY_CREATE;
    private boolean COMPANY_UPDATE;
    private boolean COMPANY_DELETE;
    private boolean USER_LIST;
    private boolean USER_VIEW;
    private boolean USER_CREATE;
    private boolean USER_UPDATE;
    private boolean USER_DELETE;
    private boolean GENERATE_REPORT;
    private boolean FILE_UPLOAD;
    private boolean FILE_HISTORY;
    private boolean OBSERVATION_RECOMMENDATION_VIEW;
    private boolean OBSERVATION_RECOMMENDATION_UPDATE;
    private boolean OBSERVATION_RECOMMENDATION_DELETE;
    private boolean OBSERVATION_RECOMMENDATION_CREATE;
    private boolean PRODUCTION_SUMMARY_LBS_WASHED;
    private boolean PRODUCTION_SUMMARY_LOADS_WASHED;
    private boolean CHEMICAL_SUMMARY_ACTUAL_USAGE;
    private boolean CHEMICAL_SUMMARY_EST_USAGE;
    private boolean WASHER_PRODUCTION_SUMMARY_REPORT;
    private boolean ALARM_SUMMARY_REPORT;
    private boolean COST_SUMMARY_REPORT;
    private boolean CHEMICAL_SUMMARY_REPORT;
    private boolean FULL_PRIVILEGE;
    private boolean COST_SUMMARY_COST_PER_CWT;
    private boolean COST_SUMMARY_EST_COST;
    private boolean COST_SUMMARY_ABS_COST;
    private boolean COST_SUMMARY_ERROR;
    private boolean CREATE_SAME_LEVEL_USER;
    private boolean SITE_FULL_EDIT;
    private boolean OBS_REC_REPORT;
    private boolean REAL_TIME_REPORT;
    private boolean ALERT_SETTING;
    private boolean DEVICE_MANAGEMENT_CREATE;
    private boolean DEVICE_MANAGEMENT_DELETE; 
    private boolean DEVICE_MANAGEMENT_LIST;
    private boolean DEVICE_MANAGEMENT_UPDATE;
    private boolean DEVICE_MANAGEMENT_VIEW;
    
    
    

    public boolean isREAL_TIME_REPORT() {
	return REAL_TIME_REPORT;
    }

    public void setREAL_TIME_REPORT(boolean rEAL_TIME_REPORT) {
	REAL_TIME_REPORT = rEAL_TIME_REPORT;
    }

    public boolean isSITE_LIST() {
	return SITE_LIST;
    }

    public void setSITE_LIST(boolean sITE_LIST) {
	SITE_LIST = sITE_LIST;
    }

    public boolean isSITE_VIEW() {
	return SITE_VIEW;
    }

    public void setSITE_VIEW(boolean sITE_VIEW) {
	SITE_VIEW = sITE_VIEW;
    }

    public boolean isSITE_CREATE() {
	return SITE_CREATE;
    }

    public void setSITE_CREATE(boolean sITE_CREATE) {
	SITE_CREATE = sITE_CREATE;
    }

    public boolean isSITE_UPDATE() {
	return SITE_UPDATE;
    }

    public void setSITE_UPDATE(boolean sITE_UPDATE) {
	SITE_UPDATE = sITE_UPDATE;
    }

    public boolean isSITE_DELETE() {
	return SITE_DELETE;
    }

    public void setSITE_DELETE(boolean sITE_DELETE) {
	SITE_DELETE = sITE_DELETE;
    }

    public boolean isACCOUNT_LIST() {
	return ACCOUNT_LIST;
    }

    public void setACCOUNT_LIST(boolean aCCOUNT_LIST) {
	ACCOUNT_LIST = aCCOUNT_LIST;
    }

    public boolean isACCOUNT_VIEW() {
	return ACCOUNT_VIEW;
    }

    public void setACCOUNT_VIEW(boolean aCCOUNT_VIEW) {
	ACCOUNT_VIEW = aCCOUNT_VIEW;
    }

    public boolean isACCOUNT_CREATE() {
	return ACCOUNT_CREATE;
    }

    public void setACCOUNT_CREATE(boolean aCCOUNT_CREATE) {
	ACCOUNT_CREATE = aCCOUNT_CREATE;
    }

    public boolean isACCOUNT_UPDATE() {
	return ACCOUNT_UPDATE;
    }

    public void setACCOUNT_UPDATE(boolean aCCOUNT_UPDATE) {
	ACCOUNT_UPDATE = aCCOUNT_UPDATE;
    }

    public boolean isACCOUNT_DELETE() {
	return ACCOUNT_DELETE;
    }

    public void setACCOUNT_DELETE(boolean aCCOUNT_DELETE) {
	ACCOUNT_DELETE = aCCOUNT_DELETE;
    }

    public boolean isCOMPANY_LIST() {
	return COMPANY_LIST;
    }

    public void setCOMPANY_LIST(boolean cOMPANY_LIST) {
	COMPANY_LIST = cOMPANY_LIST;
    }

    public boolean isCOMPANY_VIEW() {
	return COMPANY_VIEW;
    }

    public void setCOMPANY_VIEW(boolean cOMPANY_VIEW) {
	COMPANY_VIEW = cOMPANY_VIEW;
    }

    public boolean isCOMPANY_CREATE() {
	return COMPANY_CREATE;
    }

    public void setCOMPANY_CREATE(boolean cOMPANY_CREATE) {
	COMPANY_CREATE = cOMPANY_CREATE;
    }

    public boolean isCOMPANY_UPDATE() {
	return COMPANY_UPDATE;
    }

    public void setCOMPANY_UPDATE(boolean cOMPANY_UPDATE) {
	COMPANY_UPDATE = cOMPANY_UPDATE;
    }

    public boolean isCOMPANY_DELETE() {
	return COMPANY_DELETE;
    }

    public void setCOMPANY_DELETE(boolean cOMPANY_DELETE) {
	COMPANY_DELETE = cOMPANY_DELETE;
    }

    public boolean isUSER_LIST() {
	return USER_LIST;
    }

    public void setUSER_LIST(boolean uSER_LIST) {
	USER_LIST = uSER_LIST;
    }

    public boolean isUSER_VIEW() {
	return USER_VIEW;
    }

    public void setUSER_VIEW(boolean uSER_VIEW) {
	USER_VIEW = uSER_VIEW;
    }

    public boolean isUSER_CREATE() {
	return USER_CREATE;
    }

    public void setUSER_CREATE(boolean uSER_CREATE) {
	USER_CREATE = uSER_CREATE;
    }

    public boolean isUSER_UPDATE() {
	return USER_UPDATE;
    }

    public void setUSER_UPDATE(boolean uSER_UPDATE) {
	USER_UPDATE = uSER_UPDATE;
    }

    public boolean isUSER_DELETE() {
	return USER_DELETE;
    }

    public void setUSER_DELETE(boolean uSER_DELETE) {
	USER_DELETE = uSER_DELETE;
    }

    public boolean isGENERATE_REPORT() {
	return GENERATE_REPORT;
    }

    public void setGENERATE_REPORT(boolean gENERATE_REPORT) {
	GENERATE_REPORT = gENERATE_REPORT;
    }

    public boolean isFILE_UPLOAD() {
	return FILE_UPLOAD;
    }

    public void setFILE_UPLOAD(boolean fILE_UPLOAD) {
	FILE_UPLOAD = fILE_UPLOAD;
    }

    public boolean isFILE_HISTORY() {
	return FILE_HISTORY;
    }

    public void setFILE_HISTORY(boolean fILE_HISTORY) {
	FILE_HISTORY = fILE_HISTORY;
    }

    public boolean isOBSERVATION_RECOMMENDATION_VIEW() {
	return OBSERVATION_RECOMMENDATION_VIEW;
    }

    public void setOBSERVATION_RECOMMENDATION_VIEW(boolean oBSERVATION_RECOMMENDATION_VIEW) {
	OBSERVATION_RECOMMENDATION_VIEW = oBSERVATION_RECOMMENDATION_VIEW;
    }

    public boolean isOBSERVATION_RECOMMENDATION_UPDATE() {
	return OBSERVATION_RECOMMENDATION_UPDATE;
    }

    public void setOBSERVATION_RECOMMENDATION_UPDATE(boolean oBSERVATION_RECOMMENDATION_UPDATE) {
	OBSERVATION_RECOMMENDATION_UPDATE = oBSERVATION_RECOMMENDATION_UPDATE;
    }

    public boolean isOBSERVATION_RECOMMENDATION_DELETE() {
	return OBSERVATION_RECOMMENDATION_DELETE;
    }

    public void setOBSERVATION_RECOMMENDATION_DELETE(boolean oBSERVATION_RECOMMENDATION_DELETE) {
	OBSERVATION_RECOMMENDATION_DELETE = oBSERVATION_RECOMMENDATION_DELETE;
    }

    public boolean isOBSERVATION_RECOMMENDATION_CREATE() {
	return OBSERVATION_RECOMMENDATION_CREATE;
    }

    public void setOBSERVATION_RECOMMENDATION_CREATE(boolean oBSERVATION_RECOMMENDATION_CREATE) {
	OBSERVATION_RECOMMENDATION_CREATE = oBSERVATION_RECOMMENDATION_CREATE;
    }

    public boolean isPRODUCTION_SUMMARY_LBS_WASHED() {
	return PRODUCTION_SUMMARY_LBS_WASHED;
    }

    public void setPRODUCTION_SUMMARY_LBS_WASHED(boolean pRODUCTION_SUMMARY_LBS_WASHED) {
	PRODUCTION_SUMMARY_LBS_WASHED = pRODUCTION_SUMMARY_LBS_WASHED;
    }

    public boolean isPRODUCTION_SUMMARY_LOADS_WASHED() {
	return PRODUCTION_SUMMARY_LOADS_WASHED;
    }

    public void setPRODUCTION_SUMMARY_LOADS_WASHED(boolean pRODUCTION_SUMMARY_LOADS_WASHED) {
	PRODUCTION_SUMMARY_LOADS_WASHED = pRODUCTION_SUMMARY_LOADS_WASHED;
    }

    public boolean isCHEMICAL_SUMMARY_ACTUAL_USAGE() {
	return CHEMICAL_SUMMARY_ACTUAL_USAGE;
    }

    public void setCHEMICAL_SUMMARY_ACTUAL_USAGE(boolean cHEMICAL_SUMMARY_ACTUAL_USAGE) {
	CHEMICAL_SUMMARY_ACTUAL_USAGE = cHEMICAL_SUMMARY_ACTUAL_USAGE;
    }

    public boolean isCOST_SUMMARY_ABS_COST() {
	return COST_SUMMARY_ABS_COST;
    }

    public void setCOST_SUMMARY_ABS_COST(boolean cOST_SUMMARY_ABS_COST) {
	COST_SUMMARY_ABS_COST = cOST_SUMMARY_ABS_COST;
    }

    public boolean isCOST_SUMMARY_ERROR() {
	return COST_SUMMARY_ERROR;
    }

    public void setCOST_SUMMARY_ERROR(boolean cOST_SUMMARY_ERROR) {
	COST_SUMMARY_ERROR = cOST_SUMMARY_ERROR;
    }

    public boolean isWASHER_PRODUCTION_SUMMARY_REPORT() {
	return WASHER_PRODUCTION_SUMMARY_REPORT;
    }

    public void setWASHER_PRODUCTION_SUMMARY_REPORT(boolean wASHER_PRODUCTION_SUMMARY_REPORT) {
	WASHER_PRODUCTION_SUMMARY_REPORT = wASHER_PRODUCTION_SUMMARY_REPORT;
    }

    public boolean isALARM_SUMMARY_REPORT() {
	return ALARM_SUMMARY_REPORT;
    }

    public void setALARM_SUMMARY_REPORT(boolean aLARM_SUMMARY_REPORT) {
	ALARM_SUMMARY_REPORT = aLARM_SUMMARY_REPORT;
    }

    public boolean isCOST_SUMMARY_REPORT() {
	return COST_SUMMARY_REPORT;
    }

    public void setCOST_SUMMARY_REPORT(boolean cOST_SUMMARY_REPORT) {
	COST_SUMMARY_REPORT = cOST_SUMMARY_REPORT;
    }

    public boolean isCHEMICAL_SUMMARY_REPORT() {
	return CHEMICAL_SUMMARY_REPORT;
    }

    public void setCHEMICAL_SUMMARY_REPORT(boolean cHEMICAL_SUMMARY_REPORT) {
	CHEMICAL_SUMMARY_REPORT = cHEMICAL_SUMMARY_REPORT;
    }

    public boolean isFULL_PRIVILEGE() {
	return FULL_PRIVILEGE;
    }

    public void setFULL_PRIVILEGE(boolean fULL_PRIVILEGE) {
	FULL_PRIVILEGE = fULL_PRIVILEGE;
    }

    public boolean isCHEMICAL_SUMMARY_EST_USAGE() {
	return CHEMICAL_SUMMARY_EST_USAGE;
    }

    public void setCHEMICAL_SUMMARY_EST_USAGE(boolean cHEMICAL_SUMMARY_EST_USAGE) {
	CHEMICAL_SUMMARY_EST_USAGE = cHEMICAL_SUMMARY_EST_USAGE;
    }

    public boolean isCOST_SUMMARY_EST_COST() {
	return COST_SUMMARY_EST_COST;
    }

    public void setCOST_SUMMARY_EST_COST(boolean cOST_SUMMARY_EST_COST) {
	COST_SUMMARY_EST_COST = cOST_SUMMARY_EST_COST;
    }

    public boolean isCOST_SUMMARY_COST_PER_CWT() {
	return COST_SUMMARY_COST_PER_CWT;
    }

    public void setCOST_SUMMARY_COST_PER_CWT(boolean cOST_SUMMARY_COST_PER_CWT) {
	COST_SUMMARY_COST_PER_CWT = cOST_SUMMARY_COST_PER_CWT;
    }

    public boolean isCREATE_SAME_LEVEL_USER() {
	return CREATE_SAME_LEVEL_USER;
    }

    public void setCREATE_SAME_LEVEL_USER(boolean cREATE_SAME_LEVEL_USER) {
	CREATE_SAME_LEVEL_USER = cREATE_SAME_LEVEL_USER;
    }

    public boolean isSITE_FULL_EDIT() {
	return SITE_FULL_EDIT;
    }

    public void setSITE_FULL_EDIT(boolean sITE_FULL_EDIT) {
	SITE_FULL_EDIT = sITE_FULL_EDIT;
    }

    public boolean isOBS_REC_REPORT() {
	return OBS_REC_REPORT;
    }

    public void setOBS_REC_REPORT(boolean oBS_REC_REPORT) {
	OBS_REC_REPORT = oBS_REC_REPORT;
    }
    
    
    public boolean isDEVICE_MANAGEMENT_CREATE() {
		return DEVICE_MANAGEMENT_CREATE;
	}

	public void setDEVICE_MANAGEMENT_CREATE(boolean dEVICE_MANAGEMENT_CREATE) {
		DEVICE_MANAGEMENT_CREATE = dEVICE_MANAGEMENT_CREATE;
	}

	public boolean isDEVICE_MANAGEMENT_DELETE() {
		return DEVICE_MANAGEMENT_DELETE;
	}

	public void setDEVICE_MANAGEMENT_DELETE(boolean dEVICE_MANAGEMENT_DELETE) {
		DEVICE_MANAGEMENT_DELETE = dEVICE_MANAGEMENT_DELETE;
	}

	public boolean isDEVICE_MANAGEMENT_LIST() {
		return DEVICE_MANAGEMENT_LIST;
	}

	public void setDEVICE_MANAGEMENT_LIST(boolean dEVICE_MANAGEMENT_LIST) {
		DEVICE_MANAGEMENT_LIST = dEVICE_MANAGEMENT_LIST;
	}

	public boolean isDEVICE_MANAGEMENT_UPDATE() {
		return DEVICE_MANAGEMENT_UPDATE;
	}

	public void setDEVICE_MANAGEMENT_UPDATE(boolean dEVICE_MANAGEMENT_UPDATE) {
		DEVICE_MANAGEMENT_UPDATE = dEVICE_MANAGEMENT_UPDATE;
	}

	public boolean isDEVICE_MANAGEMENT_VIEW() {
		return DEVICE_MANAGEMENT_VIEW;
	}

	public void setDEVICE_MANAGEMENT_VIEW(boolean dEVICE_MANAGEMENT_VIEW) {
		DEVICE_MANAGEMENT_VIEW = dEVICE_MANAGEMENT_VIEW;
	}

	

    public boolean isALERT_SETTING() {
	return ALERT_SETTING;
    }

    public void setALERT_SETTING(boolean aLERT_SETTING) {
	ALERT_SETTING = aLERT_SETTING;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (ACCOUNT_CREATE ? 1231 : 1237);
		result = prime * result + (ACCOUNT_DELETE ? 1231 : 1237);
		result = prime * result + (ACCOUNT_LIST ? 1231 : 1237);
		result = prime * result + (ACCOUNT_UPDATE ? 1231 : 1237);
		result = prime * result + (ACCOUNT_VIEW ? 1231 : 1237);
		result = prime * result + (ALARM_SUMMARY_REPORT ? 1231 : 1237);
		result = prime * result + (ALERT_SETTING ? 1231 : 1237);
		result = prime * result + (CHEMICAL_SUMMARY_ACTUAL_USAGE ? 1231 : 1237);
		result = prime * result + (CHEMICAL_SUMMARY_EST_USAGE ? 1231 : 1237);
		result = prime * result + (CHEMICAL_SUMMARY_REPORT ? 1231 : 1237);
		result = prime * result + (COMPANY_CREATE ? 1231 : 1237);
		result = prime * result + (COMPANY_DELETE ? 1231 : 1237);
		result = prime * result + (COMPANY_LIST ? 1231 : 1237);
		result = prime * result + (COMPANY_UPDATE ? 1231 : 1237);
		result = prime * result + (COMPANY_VIEW ? 1231 : 1237);
		result = prime * result + (COST_SUMMARY_ABS_COST ? 1231 : 1237);
		result = prime * result + (COST_SUMMARY_COST_PER_CWT ? 1231 : 1237);
		result = prime * result + (COST_SUMMARY_ERROR ? 1231 : 1237);
		result = prime * result + (COST_SUMMARY_EST_COST ? 1231 : 1237);
		result = prime * result + (COST_SUMMARY_REPORT ? 1231 : 1237);
		result = prime * result + (CREATE_SAME_LEVEL_USER ? 1231 : 1237);
		result = prime * result + (DEVICE_MANAGEMENT_CREATE ? 1231 : 1237);
		result = prime * result + (DEVICE_MANAGEMENT_DELETE ? 1231 : 1237);
		result = prime * result + (DEVICE_MANAGEMENT_LIST ? 1231 : 1237);
		result = prime * result + (DEVICE_MANAGEMENT_UPDATE ? 1231 : 1237);
		result = prime * result + (DEVICE_MANAGEMENT_VIEW ? 1231 : 1237);
		result = prime * result + (FILE_HISTORY ? 1231 : 1237);
		result = prime * result + (FILE_UPLOAD ? 1231 : 1237);
		result = prime * result + (FULL_PRIVILEGE ? 1231 : 1237);
		result = prime * result + (GENERATE_REPORT ? 1231 : 1237);
		result = prime * result + (OBSERVATION_RECOMMENDATION_CREATE ? 1231 : 1237);
		result = prime * result + (OBSERVATION_RECOMMENDATION_DELETE ? 1231 : 1237);
		result = prime * result + (OBSERVATION_RECOMMENDATION_UPDATE ? 1231 : 1237);
		result = prime * result + (OBSERVATION_RECOMMENDATION_VIEW ? 1231 : 1237);
		result = prime * result + (OBS_REC_REPORT ? 1231 : 1237);
		result = prime * result + (PRODUCTION_SUMMARY_LBS_WASHED ? 1231 : 1237);
		result = prime * result + (PRODUCTION_SUMMARY_LOADS_WASHED ? 1231 : 1237);
		result = prime * result + (REAL_TIME_REPORT ? 1231 : 1237);
		result = prime * result + (SITE_CREATE ? 1231 : 1237);
		result = prime * result + (SITE_DELETE ? 1231 : 1237);
		result = prime * result + (SITE_FULL_EDIT ? 1231 : 1237);
		result = prime * result + (SITE_LIST ? 1231 : 1237);
		result = prime * result + (SITE_UPDATE ? 1231 : 1237);
		result = prime * result + (SITE_VIEW ? 1231 : 1237);
		result = prime * result + (USER_CREATE ? 1231 : 1237);
		result = prime * result + (USER_DELETE ? 1231 : 1237);
		result = prime * result + (USER_LIST ? 1231 : 1237);
		result = prime * result + (USER_UPDATE ? 1231 : 1237);
		result = prime * result + (USER_VIEW ? 1231 : 1237);
		result = prime * result + (WASHER_PRODUCTION_SUMMARY_REPORT ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PermissionDTO other = (PermissionDTO) obj;
		if (ACCOUNT_CREATE != other.ACCOUNT_CREATE)
			return false;
		if (ACCOUNT_DELETE != other.ACCOUNT_DELETE)
			return false;
		if (ACCOUNT_LIST != other.ACCOUNT_LIST)
			return false;
		if (ACCOUNT_UPDATE != other.ACCOUNT_UPDATE)
			return false;
		if (ACCOUNT_VIEW != other.ACCOUNT_VIEW)
			return false;
		if (ALARM_SUMMARY_REPORT != other.ALARM_SUMMARY_REPORT)
			return false;
		if (ALERT_SETTING != other.ALERT_SETTING)
			return false;
		if (CHEMICAL_SUMMARY_ACTUAL_USAGE != other.CHEMICAL_SUMMARY_ACTUAL_USAGE)
			return false;
		if (CHEMICAL_SUMMARY_EST_USAGE != other.CHEMICAL_SUMMARY_EST_USAGE)
			return false;
		if (CHEMICAL_SUMMARY_REPORT != other.CHEMICAL_SUMMARY_REPORT)
			return false;
		if (COMPANY_CREATE != other.COMPANY_CREATE)
			return false;
		if (COMPANY_DELETE != other.COMPANY_DELETE)
			return false;
		if (COMPANY_LIST != other.COMPANY_LIST)
			return false;
		if (COMPANY_UPDATE != other.COMPANY_UPDATE)
			return false;
		if (COMPANY_VIEW != other.COMPANY_VIEW)
			return false;
		if (COST_SUMMARY_ABS_COST != other.COST_SUMMARY_ABS_COST)
			return false;
		if (COST_SUMMARY_COST_PER_CWT != other.COST_SUMMARY_COST_PER_CWT)
			return false;
		if (COST_SUMMARY_ERROR != other.COST_SUMMARY_ERROR)
			return false;
		if (COST_SUMMARY_EST_COST != other.COST_SUMMARY_EST_COST)
			return false;
		if (COST_SUMMARY_REPORT != other.COST_SUMMARY_REPORT)
			return false;
		if (CREATE_SAME_LEVEL_USER != other.CREATE_SAME_LEVEL_USER)
			return false;
		if (DEVICE_MANAGEMENT_CREATE != other.DEVICE_MANAGEMENT_CREATE)
			return false;
		if (DEVICE_MANAGEMENT_DELETE != other.DEVICE_MANAGEMENT_DELETE)
			return false;
		if (DEVICE_MANAGEMENT_LIST != other.DEVICE_MANAGEMENT_LIST)
			return false;
		if (DEVICE_MANAGEMENT_UPDATE != other.DEVICE_MANAGEMENT_UPDATE)
			return false;
		if (DEVICE_MANAGEMENT_VIEW != other.DEVICE_MANAGEMENT_VIEW)
			return false;
		if (FILE_HISTORY != other.FILE_HISTORY)
			return false;
		if (FILE_UPLOAD != other.FILE_UPLOAD)
			return false;
		if (FULL_PRIVILEGE != other.FULL_PRIVILEGE)
			return false;
		if (GENERATE_REPORT != other.GENERATE_REPORT)
			return false;
		if (OBSERVATION_RECOMMENDATION_CREATE != other.OBSERVATION_RECOMMENDATION_CREATE)
			return false;
		if (OBSERVATION_RECOMMENDATION_DELETE != other.OBSERVATION_RECOMMENDATION_DELETE)
			return false;
		if (OBSERVATION_RECOMMENDATION_UPDATE != other.OBSERVATION_RECOMMENDATION_UPDATE)
			return false;
		if (OBSERVATION_RECOMMENDATION_VIEW != other.OBSERVATION_RECOMMENDATION_VIEW)
			return false;
		if (OBS_REC_REPORT != other.OBS_REC_REPORT)
			return false;
		if (PRODUCTION_SUMMARY_LBS_WASHED != other.PRODUCTION_SUMMARY_LBS_WASHED)
			return false;
		if (PRODUCTION_SUMMARY_LOADS_WASHED != other.PRODUCTION_SUMMARY_LOADS_WASHED)
			return false;
		if (REAL_TIME_REPORT != other.REAL_TIME_REPORT)
			return false;
		if (SITE_CREATE != other.SITE_CREATE)
			return false;
		if (SITE_DELETE != other.SITE_DELETE)
			return false;
		if (SITE_FULL_EDIT != other.SITE_FULL_EDIT)
			return false;
		if (SITE_LIST != other.SITE_LIST)
			return false;
		if (SITE_UPDATE != other.SITE_UPDATE)
			return false;
		if (SITE_VIEW != other.SITE_VIEW)
			return false;
		if (USER_CREATE != other.USER_CREATE)
			return false;
		if (USER_DELETE != other.USER_DELETE)
			return false;
		if (USER_LIST != other.USER_LIST)
			return false;
		if (USER_UPDATE != other.USER_UPDATE)
			return false;
		if (USER_VIEW != other.USER_VIEW)
			return false;
		if (WASHER_PRODUCTION_SUMMARY_REPORT != other.WASHER_PRODUCTION_SUMMARY_REPORT)
			return false;
		return true;
	}

   
    
    

}
