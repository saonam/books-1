package com.hydro.api.dto;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import com.hydro.api.dto.reports.EventsDTO;

public class BatchDTO implements Cloneable {
    private int batchId;
    private String runTime;
    private int formulaId;
    private String formulaName;
    private int lbsWashed;
    private Date startDate;
    private Date endDate;
    private Double totalMlActual;
    private Double totalMlEstimated;
    private List<EventsDTO> eventList;
    private Date batchStartTimeForEffCalc;
    private Date batchEndTimeForEffCalc;

    public String getFormulaName() {
	return formulaName;
    }

    public void setFormulaName(String formulaName) {
	this.formulaName = formulaName;
    }

    public int getBatchId() {
	return batchId;
    }

    public void setBatchId(int batchId) {
	this.batchId = batchId;
    }

    public Date getStartDate() {
	return startDate;
    }

    public void setStartDate(Date startDate) {
	this.startDate = startDate;
    }

    public Date getEndDate() {
	return endDate;
    }

    public void setEndDate(Date endDate) {
	this.endDate = endDate;
    }

    public Double getTotalMlActual() {
        return totalMlActual;
    }

    public void setTotalMlActual(Double totalMlActual) {
        this.totalMlActual = totalMlActual;
    }

    public Double getTotalMlEstimated() {
        return totalMlEstimated;
    }

    public void setTotalMlEstimated(Double totalMlEstimated) {
        this.totalMlEstimated = totalMlEstimated;
    }

    public List<EventsDTO> getEventList() {
	return eventList;
    }

    public void setEventList(List<EventsDTO> eventList) {
	this.eventList = eventList;
    }

    public Date getBatchStartTimeForEffCalc() {
	return batchStartTimeForEffCalc;
    }

    public void setBatchStartTimeForEffCalc(Date batchStartTimeForEffCalc) {
	this.batchStartTimeForEffCalc = batchStartTimeForEffCalc;
    }

    public Date getBatchEndTimeForEffCalc() {
	return batchEndTimeForEffCalc;
    }

    public void setBatchEndTimeForEffCalc(Date batchEndTimeForEffCalc) {
	this.batchEndTimeForEffCalc = batchEndTimeForEffCalc;
    }

    public int getFormulaId() {
	return formulaId;
    }

    public void setFormulaId(int formulaId) {
	this.formulaId = formulaId;
    }

    public int getLbsWashed() {
	return lbsWashed;
    }

    public void setLbsWashed(int lbsWashed) {
	this.lbsWashed = lbsWashed;
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
	BatchDTO batchDTO = (BatchDTO) super.clone();
	batchDTO.eventList = new LinkedList<EventsDTO>(eventList);
	return batchDTO;
    }

    public String getRunTime() {
	return runTime;
    }

    public void setRunTime(String runTime) {
	this.runTime = runTime;
    }
}
