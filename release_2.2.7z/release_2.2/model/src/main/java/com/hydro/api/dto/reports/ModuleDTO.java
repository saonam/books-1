package com.hydro.api.dto.reports;

import java.util.Map;

import com.hydro.api.dto.BatchDTO;

public class ModuleDTO {
    private BatchDTO batch;
    private Map<Integer, Boolean> productMap;

    public BatchDTO getBatch() {
	return batch;
    }

    public void setBatch(BatchDTO batch) {
	this.batch = batch;
    }

    public Map<Integer, Boolean> getProductMap() {
	return productMap;
    }

    public void setProductMap(Map<Integer, Boolean> productMap) {
	this.productMap = productMap;
    }
}
