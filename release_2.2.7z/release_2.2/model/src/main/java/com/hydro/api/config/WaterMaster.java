package com.hydro.api.config;

import java.io.Serializable;

public class WaterMaster implements  Serializable {

	private static final long serialVersionUID = 1L;
	
	private String uid;
	private String kf;//"2.60000"
	private int lm2_seq;//1
	private String flow; //"2.00"
	
	
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getKf() {
		return kf;
	}
	public void setKf(String kf) {
		this.kf = kf;
	}
	public int getLm2_seq() {
		return lm2_seq;
	}
	public void setLm2_seq(int lm2_seq) {
		this.lm2_seq = lm2_seq;
	}
	public String getFlow() {
		return flow;
	}
	public void setFlow(String flow) {
		this.flow = flow;
	}
	 

}
