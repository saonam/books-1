/**
 * 
 */
package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class CreateSiteDTO {
    private String siteID;

    /**
     * @return the siteID
     */
    public String getSiteID() {
	return siteID;
    }

    /**
     * @param siteID
     *            the siteID to set
     */
    public void setSiteID(String siteID) {
	this.siteID = siteID;
    }

}
