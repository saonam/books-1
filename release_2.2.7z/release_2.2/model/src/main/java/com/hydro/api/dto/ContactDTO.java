/**
 * 
 */
package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class ContactDTO {
    private String contactId;
    private String email;
    private String name;
    private String number;
    private String title;

    public String getContactId() {
	return contactId;
    }

    public void setContactId(String contactId) {
	this.contactId = contactId;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String contactEmail) {
	this.email = contactEmail;
    }

    public String getName() {
	return name;
    }

    public void setName(String contactName) {
	this.name = contactName;
    }

    public String getNumber() {
	return number;
    }

    public void setNumber(String contactNumber) {
	this.number = contactNumber;
    }

    public String getTitle() {
	return title;
    }

    public void setTitle(String contactTitle) {
	this.title = contactTitle;
    }

}
