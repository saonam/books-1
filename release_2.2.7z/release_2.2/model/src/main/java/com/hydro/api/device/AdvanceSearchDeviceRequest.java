package com.hydro.api.device;

import java.io.Serializable;
import java.util.List;

public class AdvanceSearchDeviceRequest implements  Serializable{
	
private	int pageNumber;
private	int pageSize;
private	List<Association> association;
private List<SearchProperties> properties;
private List<DeviceProperties> deviceProperties;

public int getPageNumber() {
	return pageNumber;
}
public void setPageNumber(int pageNumber) {
	this.pageNumber = pageNumber;
}
public int getPageSize() {
	return pageSize;
}
public void setPageSize(int pageSize) {
	this.pageSize = pageSize;
}
public List<Association> getAssociation() {
	return association;
}
public void setAssociation(List<Association> association) {
	this.association = association;
}
public List<SearchProperties> getProperties() {
	return properties;
}
public void setProperties(List<SearchProperties> properties) {
	this.properties = properties;
}
public List<DeviceProperties> getDeviceProperties() {
	return deviceProperties;
}
public void setDeviceProperties(List<DeviceProperties> deviceProperties) {
	this.deviceProperties = deviceProperties;
}
@Override
public String toString() {
	return "AdvanceSearchDeviceRequest [pageNumber=" + pageNumber + ", pageSize=" + pageSize + ", association="
			+ association + ", properties=" + properties + ", deviceProperties=" + deviceProperties + "]";
}




}
