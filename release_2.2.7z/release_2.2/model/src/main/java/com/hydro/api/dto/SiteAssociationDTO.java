/**
 * 
 */
package com.hydro.api.dto;

/**
 * @author Srishti Tiwari
 *
 */
public class SiteAssociationDTO extends SiteDTO {
    private String associationId;

    public String getCompanyId() {
	return associationId;
    }

    public void setCompanyId(String associationId) {
	this.associationId = associationId;
    }

    public String getServiceName() {
	return serviceName;
    }

    public void setServiceName(String serviceName) {
	this.serviceName = serviceName;
    }

    public String getServiceImage() {
	return serviceImage;
    }

    public void setServiceImage(String serviceImage) {
	this.serviceImage = serviceImage;
    }

    private String serviceName;
    private String serviceImage;

}
